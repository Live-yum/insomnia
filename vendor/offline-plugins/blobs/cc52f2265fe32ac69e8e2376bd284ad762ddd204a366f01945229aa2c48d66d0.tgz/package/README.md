# insomnia-plugin-encode_request

The Encode Request plugin for for [Insomnia](https://insomnia.rest) takes the body of a request message, allows you to append seed data, and the end result is a SHA256withRSA encoded string.

## Installing

Go to the `Application>Preferences` menu in Insomnia, then go to the `Plugins` tab, search for `insomnia-plugin-encode_request` and install it.

If that doesn't work, execute the following command from a command line terminal:  npm i insomnia-plugin-encode_request

## Usage

On the plugin dialog...

Provide:

1. the request body (highly recommend using the Insomnia plugin "insomnia-plugin-request-body" to fetch the payload)
2. the seed data (if needed), that should be appended to the end of the request message/payload
3. the full directory location of the location of the private key (PEM) file
