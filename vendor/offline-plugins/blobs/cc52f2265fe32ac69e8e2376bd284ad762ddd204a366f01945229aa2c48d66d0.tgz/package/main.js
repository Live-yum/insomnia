const crypto = require('crypto');
const path = require('path');
const fs = require('fs');

generateEncodedSignature = function (request,seed,directory) {

    const location = directory;
    const seedData = seed;

    // Obtain key location
    let keyPath = `${location}`;

    // Read key from file
    let privateKey = fs.readFileSync(keyPath);

    // Convert string to buffer
    const data = Buffer.from(request.concat(`${seedData}`));

    // Sign the data and returned signature in buffer
    const sign = crypto.sign('RSA-SHA256', data, privateKey);

    // Convert returned buffer to base64
    const signature = sign.toString('base64');

    let authSignature = `${signature}`;

    return authSignature;
};

module.exports.templateTags = [
    {
        name: 'Authorization_Signature',
        displayName: 'Encoded Authorization Signature',
        description: 'Encode request that has appended seed data',
        args: [
            {
                displayName: 'Request Message',
                type: 'string',
                placeholder: '-- request msg --'
            },
            {
                displayName: 'Seed Data to Append to Request',
                type: 'string',
                placeholder: '-- seed data --'
            },
{
                displayName: 'Directory with private key (PEM) file',
                type: 'string',
                placeholder: '-- c:/users/<userId>/.ssh/mySubFolder/myPrivateKey.pem --'
            }
        ],
        run(context, userId = "", request = "", seed = "", directory = "") {
            return generateEncodedSignature(userId,request,seed, directory);
        }
    }
];
