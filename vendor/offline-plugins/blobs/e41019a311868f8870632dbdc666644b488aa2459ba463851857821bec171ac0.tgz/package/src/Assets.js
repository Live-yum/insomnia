"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true,
});
exports.getAsset = getAsset;
exports.getAssetData = getAssetData;
exports.getAssetFiles = getAssetFiles;
exports.getAssetSize = getAssetSize;
exports.isAssetTypeAnImage = isAssetTypeAnImage;
var _imageSize = require("./lib/imageSize");
var _pathUtils = require("./lib/pathUtils");
var AssetPaths = _interopRequireWildcard(
  require("./node-haste/lib/AssetPaths"),
);
var _nodeCrypto = _interopRequireDefault(require("node:crypto"));
var _nodeFs = _interopRequireDefault(require("node:fs"));
var _nodePath = _interopRequireDefault(require("node:path"));
function _interopRequireDefault(e) {
  return e && e.__esModule ? e : { default: e };
}
function _interopRequireWildcard(e, t) {
  if ("function" == typeof WeakMap)
    var r = new WeakMap(),
      n = new WeakMap();
  return (_interopRequireWildcard = function (e, t) {
    if (!t && e && e.__esModule) return e;
    var o,
      i,
      f = { __proto__: null, default: e };
    if (null === e || ("object" != typeof e && "function" != typeof e))
      return f;
    if ((o = t ? n : r)) {
      if (o.has(e)) return o.get(e);
      o.set(e, f);
    }
    for (const t in e)
      "default" !== t &&
        {}.hasOwnProperty.call(e, t) &&
        ((i =
          (o = Object.defineProperty) &&
          Object.getOwnPropertyDescriptor(e, t)) &&
        (i.get || i.set)
          ? o(f, t, i)
          : (f[t] = e[t]));
    return f;
  })(e, t);
}
function isAssetTypeAnImage(type) {
  return (
    [
      "png",
      "jpg",
      "jpeg",
      "bmp",
      "gif",
      "webp",
      "psd",
      "svg",
      "tiff",
      "ktx",
    ].indexOf(type) !== -1
  );
}
function getAssetSize(type, content, filePath) {
  if (!isAssetTypeAnImage(type)) {
    return null;
  }
  if (content.length === 0) {
    throw new Error(`Image asset \`${filePath}\` cannot be an empty file.`);
  }
  return (0, _imageSize.getImageDimensions)(type, content, filePath);
}
function buildAssetMap(dir, files, platform) {
  const platforms = new Set(platform != null ? [platform] : []);
  const assets = files.map((file) => AssetPaths.tryParse(file, platforms));
  const map = new Map();
  assets.forEach(function (asset, i) {
    if (asset == null) {
      return;
    }
    const file = files[i];
    const assetKey = getAssetKey(asset.assetName, asset.platform);
    let record = map.get(assetKey);
    if (!record) {
      record = {
        scales: [],
        files: [],
      };
      map.set(assetKey, record);
    }
    let insertIndex;
    const length = record.scales.length;
    for (insertIndex = 0; insertIndex < length; insertIndex++) {
      if (asset.resolution < record.scales[insertIndex]) {
        break;
      }
    }
    record.scales.splice(insertIndex, 0, asset.resolution);
    record.files.splice(insertIndex, 0, _nodePath.default.join(dir, file));
  });
  return map;
}
function getAssetKey(assetName, platform) {
  if (platform != null) {
    return `${assetName} : ${platform}`;
  } else {
    return assetName;
  }
}
async function getAbsoluteAssetRecord(assetPath, platform = null) {
  const filename = _nodePath.default.basename(assetPath);
  const dir = _nodePath.default.dirname(assetPath);
  const files = await _nodeFs.default.promises.readdir(dir);
  const assetData = AssetPaths.parse(
    filename,
    new Set(platform != null ? [platform] : []),
  );
  const map = buildAssetMap(dir, files, platform);
  let record;
  if (platform != null) {
    record =
      map.get(getAssetKey(assetData.assetName, platform)) ||
      map.get(assetData.assetName);
  } else {
    record = map.get(assetData.assetName);
  }
  if (!record) {
    throw new Error(
      `Asset not found: ${assetPath} for platform: ${platform ?? "(unspecified)"}`,
    );
  }
  return record;
}
async function getAbsoluteAssetInfo(assetPath, platform = null) {
  const nameData = AssetPaths.parse(
    assetPath,
    new Set(platform != null ? [platform] : []),
  );
  const { name, type } = nameData;
  const { scales, files } = await getAbsoluteAssetRecord(assetPath, platform);
  const hasher = _nodeCrypto.default.createHash("md5");
  const fileData = await Promise.all(
    files.map((file) => _nodeFs.default.promises.readFile(file)),
  );
  for (const data of fileData) {
    hasher.update(data);
  }
  return {
    assetInfo: {
      files,
      hash: hasher.digest("hex"),
      name,
      scales,
      type,
    },
    firstFileContent: fileData[0],
  };
}
async function getAssetData(
  assetPath,
  localPath,
  assetDataPlugins,
  platform,
  publicPath,
) {
  let assetUrlPath = localPath.startsWith("..")
    ? publicPath.replace(/\/$/, "") + "/" + _nodePath.default.dirname(localPath)
    : _nodePath.default.join(publicPath, _nodePath.default.dirname(localPath));
  assetUrlPath = (0, _pathUtils.normalizePathSeparatorsToPosix)(assetUrlPath);
  const { assetInfo, firstFileContent } = await getAbsoluteAssetInfo(
    assetPath,
    platform ?? null,
  );
  const dimensions = isAssetTypeAnImage(assetInfo.type)
    ? getAssetSize(assetInfo.type, firstFileContent, assetInfo.files[0])
    : null;
  const scale = assetInfo.scales[0];
  const assetData = {
    __packager_asset: true,
    fileSystemLocation: _nodePath.default.dirname(assetPath),
    httpServerLocation: assetUrlPath,
    width: dimensions ? dimensions.width / scale : undefined,
    height: dimensions ? dimensions.height / scale : undefined,
    scales: assetInfo.scales,
    files: assetInfo.files,
    hash: assetInfo.hash,
    name: assetInfo.name,
    type: assetInfo.type,
  };
  return await applyAssetDataPlugins(assetDataPlugins, assetData);
}
async function applyAssetDataPlugins(assetDataPlugins, assetData) {
  if (!assetDataPlugins.length) {
    return assetData;
  }
  const [currentAssetPlugin, ...remainingAssetPlugins] = assetDataPlugins;
  const mod = require(currentAssetPlugin);
  const assetPluginFunction =
    mod.__esModule === true && "default" in mod ? mod.default : mod;
  const resultAssetData = await assetPluginFunction(assetData);
  return await applyAssetDataPlugins(remainingAssetPlugins, resultAssetData);
}
async function getAssetFiles(assetPath, platform = null) {
  const assetData = await getAbsoluteAssetRecord(assetPath, platform);
  return assetData.files;
}
async function getAsset(
  relativePath,
  projectRoot,
  watchFolders,
  platform,
  assetExts,
  fileExistsInFileMap,
) {
  const assetData = AssetPaths.parse(
    relativePath,
    new Set(platform != null ? [platform] : []),
  );
  const absolutePath = _nodePath.default.resolve(projectRoot, relativePath);
  if (!assetExts.includes(assetData.type)) {
    throw new Error(
      `'${relativePath}' cannot be loaded as its extension is not registered in assetExts`,
    );
  }
  if (
    fileExistsInFileMap == null &&
    !pathBelongsToRoots(absolutePath, [projectRoot, ...watchFolders])
  ) {
    throw new Error(
      `'${relativePath}' could not be found, because it cannot be found in the project root or any watch folder`,
    );
  }
  const record = await getAbsoluteAssetRecord(absolutePath, platform ?? null);
  for (let i = 0; i < record.scales.length; i++) {
    if (record.scales[i] >= assetData.resolution) {
      if (
        fileExistsInFileMap != null &&
        !fileExistsInFileMap(record.files[i])
      ) {
        continue;
      }
      return _nodeFs.default.promises.readFile(record.files[i]);
    }
  }
  const lastFile = record.files[record.files.length - 1];
  if (fileExistsInFileMap != null && !fileExistsInFileMap(lastFile)) {
    throw new Error(
      `'${relativePath}' could not be found, because it is not within the projectRoot or watchFolders, or it is blocked via the resolver.blockList config`,
    );
  }
  return _nodeFs.default.promises.readFile(lastFile);
}
function pathBelongsToRoots(pathToCheck, roots) {
  for (const rootFolder of roots) {
    if (pathToCheck.startsWith(_nodePath.default.resolve(rootFolder))) {
      return true;
    }
  }
  return false;
}
