"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true,
});
exports.getJsOutput = getJsOutput;
exports.getModuleParams = getModuleParams;
exports.inlineModuleIdReferences = inlineModuleIdReferences;
exports.isJsModule = isJsModule;
exports.wrapModule = wrapModule;
var _isResolvedDependency = require("../../../lib/isResolvedDependency");
var _pathUtils = require("../../../lib/pathUtils");
var _invariant = _interopRequireDefault(require("invariant"));
var jscSafeUrl = _interopRequireWildcard(require("jsc-safe-url"));
var _metroTransformPlugins = require("metro-transform-plugins");
var _nodePath = _interopRequireDefault(require("node:path"));
function _interopRequireWildcard(e, t) {
  if ("function" == typeof WeakMap)
    var r = new WeakMap(),
      n = new WeakMap();
  return (_interopRequireWildcard = function (e, t) {
    if (!t && e && e.__esModule) return e;
    var o,
      i,
      f = { __proto__: null, default: e };
    if (null === e || ("object" != typeof e && "function" != typeof e))
      return f;
    if ((o = t ? n : r)) {
      if (o.has(e)) return o.get(e);
      o.set(e, f);
    }
    for (const t in e)
      "default" !== t &&
        {}.hasOwnProperty.call(e, t) &&
        ((i =
          (o = Object.defineProperty) &&
          Object.getOwnPropertyDescriptor(e, t)) &&
        (i.get || i.set)
          ? o(f, t, i)
          : (f[t] = e[t]));
    return f;
  })(e, t);
}
function _interopRequireDefault(e) {
  return e && e.__esModule ? e : { default: e };
}
function wrapModule(module, options) {
  const output = getJsOutput(module);
  if (output.type.startsWith("js/script")) {
    return output.data.code;
  }
  if (
    options.unstable_inlineDependencyMap === true &&
    options.dependencyMapReservedName != null
  ) {
    return wrapModuleWithInlinedDependencyIds(
      module,
      output.data.code,
      options.dependencyMapReservedName,
      options,
    );
  }
  const params = getModuleParams(module, options);
  return (0, _metroTransformPlugins.addParamsToDefineCall)(
    output.data.code,
    ...params,
  );
}
function getModuleVerboseName(module, options) {
  return (0, _pathUtils.normalizePathSeparatorsToPosix)(
    _nodePath.default.relative(options.projectRoot, module.path),
  );
}
function getDefaultAsyncDependencyPath(dependency, options) {
  (0, _invariant.default)(
    options.sourceUrl != null,
    "sourceUrl is required when includeAsyncPaths is true",
  );
  const { searchParams } = new URL(jscSafeUrl.toNormalUrl(options.sourceUrl));
  searchParams.set("modulesOnly", "true");
  searchParams.set("runModule", "false");
  const bundlePath = _nodePath.default.relative(
    options.serverRoot,
    dependency.absolutePath,
  );
  return (
    "/" +
    _nodePath.default.join(
      _nodePath.default.dirname(bundlePath),
      _nodePath.default.basename(
        bundlePath,
        _nodePath.default.extname(bundlePath),
      ),
    ) +
    ".bundle?" +
    searchParams.toString()
  );
}
function getModuleDependencies(module, options) {
  const moduleId = options.createModuleId(module.path);
  const paths = {};
  let hasPaths = false;
  const getAsyncDependencyPath =
    options.unstable_getAsyncDependencyPath ?? getDefaultAsyncDependencyPath;
  const dependencyMapArray = Array.from(module.dependencies.values()).map(
    (dependency) => {
      if (!(0, _isResolvedDependency.isResolvedDependency)(dependency)) {
        return null;
      }
      const id = options.createModuleId(dependency.absolutePath);
      if (options.includeAsyncPaths && dependency.data.data.asyncType != null) {
        hasPaths = true;
        const asyncDependencyPath = getAsyncDependencyPath(dependency, options);
        if (asyncDependencyPath != null) {
          paths[id] = asyncDependencyPath;
        }
      }
      return id;
    },
  );
  return {
    moduleId,
    dependencyMapArray,
    paths,
    hasPaths,
  };
}
function getModuleParams(module, options) {
  const { moduleId, dependencyMapArray, paths, hasPaths } =
    getModuleDependencies(module, options);
  const params = [moduleId];
  if (hasPaths) {
    params.push({
      ...dependencyMapArray,
      paths,
    });
  } else if (dependencyMapArray.length > 0) {
    params.push(dependencyMapArray);
  } else if (options.dev) {
    params.push(null);
  }
  if (options.dev) {
    params.push(getModuleVerboseName(module, options));
  }
  return params;
}
function wrapModuleWithInlinedDependencyIds(
  module,
  code,
  dependencyMapReservedName,
  options,
) {
  const { moduleId, dependencyMapArray, paths, hasPaths } =
    getModuleDependencies(module, options);
  const inlinedCode = inlineModuleIdReferences(
    code,
    dependencyMapReservedName,
    dependencyMapArray.map((id) => (id == null ? "null" : id)),
  );
  const params = [moduleId];
  if (hasPaths) {
    params.push({
      paths,
    });
  } else if (options.dev) {
    params.push(null);
  }
  if (options.dev) {
    params.push(getModuleVerboseName(module, options));
  }
  return (0, _metroTransformPlugins.addParamsToDefineCall)(
    inlinedCode,
    ...params,
  );
}
function inlineModuleIdReferences(
  code,
  dependencyMapReservedName,
  dependencyIds,
  { ignoreMissingDependencyMapReference = false } = {},
) {
  if (!dependencyIds.length) {
    return code;
  }
  if (!code.includes(dependencyMapReservedName)) {
    if (ignoreMissingDependencyMapReference) {
      return code;
    }
    throw new Error(
      `Module has dependencies but does not use the preconfigured dependency map name '${dependencyMapReservedName}'\n` +
        "This is an internal error in Metro.",
    );
  }
  const WS = "[\t ]*";
  const depMapReferenceRegex = new RegExp(
    escapeRegex(dependencyMapReservedName) + `${WS}\\[${WS}([0-9]+)${WS}\\]`,
    "g",
  );
  const inlinedCode = code.replace(depMapReferenceRegex, (match, depIndex) => {
    const idStr = dependencyIds[Number.parseInt(depIndex, 10)].toString();
    if (idStr.length > match.length) {
      throw new Error(
        `Module ID doesn't fit in available space; add ${idStr.length - match.length} more characters to 'dependencyMapReservedName'.`,
      );
    }
    return idStr.padEnd(match.length);
  });
  return inlinedCode;
}
function escapeRegex(str) {
  return str.replace(/([.?*+^$[\]\\(){}|-])/g, "\\$1");
}
function getJsOutput(module) {
  const jsModules = module.output.filter(({ type }) => type.startsWith("js/"));
  (0, _invariant.default)(
    jsModules.length === 1,
    `Modules must have exactly one JS output, but ${module.path ?? "unknown module"} has ${jsModules.length} JS outputs.`,
  );
  const jsOutput = jsModules[0];
  (0, _invariant.default)(
    Number.isFinite(jsOutput.data.lineCount),
    `JS output must populate lineCount, but ${module.path ?? "unknown module"} has ${jsOutput.type} output with lineCount '${jsOutput.data.lineCount}'`,
  );
  return jsOutput;
}
function isJsModule(module) {
  return module.output.filter(isJsOutput).length > 0;
}
function isJsOutput(output) {
  return output.type.startsWith("js/");
}
