"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true,
});
exports.default = void 0;
var _createFileMap = _interopRequireDefault(
  require("./DependencyGraph/createFileMap"),
);
var _createModuleResolver = _interopRequireDefault(
  require("./DependencyGraph/createModuleResolver"),
);
var _PackageCache = require("./PackageCache");
var _metroCore = require("metro-core");
var _canonicalize = _interopRequireDefault(
  require("metro-core/private/canonicalize"),
);
var _metroFileMap = require("metro-file-map");
var _metroResolver = require("metro-resolver");
var _nodeEvents = _interopRequireDefault(require("node:events"));
var _nodePath = _interopRequireDefault(require("node:path"));
var _nullthrows = _interopRequireDefault(require("nullthrows"));
function _interopRequireDefault(e) {
  return e && e.__esModule ? e : { default: e };
}
const { createActionStartEntry, createActionEndEntry, log } = _metroCore.Logger;
const NULL_PLATFORM = Symbol();
function getOrCreateMap(map, field) {
  let subMap = map.get(field);
  if (!subMap) {
    subMap = new Map();
    map.set(field, subMap);
  }
  return subMap;
}
class DependencyGraph extends _nodeEvents.default {
  #packageCache;
  #dependencyPlugin;
  constructor(config, options) {
    super();
    this._config = config;
    const { hasReducedPerformance, watch } = options ?? {};
    const initializingMetroLogEntry = log(
      createActionStartEntry("Initializing Metro"),
    );
    config.reporter.update({
      type: "dep_graph_loading",
      hasReducedPerformance: !!hasReducedPerformance,
    });
    const { fileMap, hasteMap, dependencyPlugin } = (0, _createFileMap.default)(
      config,
      {
        throwOnModuleCollision: false,
        watch,
      },
    );
    fileMap.setMaxListeners(1000);
    this._haste = fileMap;
    this._haste.on("status", (status) => this._onWatcherStatus(status));
    this._initializedPromise = fileMap.build().then(({ fileSystem }) => {
      log(createActionEndEntry(initializingMetroLogEntry));
      config.reporter.update({
        type: "dep_graph_loaded",
      });
      this._fileSystem = fileSystem;
      this._hasteMap = hasteMap;
      this.#dependencyPlugin = dependencyPlugin;
      this._haste.on("change", (changeEvent) =>
        this._onHasteChange(changeEvent),
      );
      this._haste.on("healthCheck", (result) =>
        this._onWatcherHealthCheck(result),
      );
      this._resolutionCache = new Map();
      this.#packageCache = new _PackageCache.PackageCache({
        getClosestPackage: (absoluteModulePath) =>
          this._getClosestPackage(absoluteModulePath),
      });
      this._createModuleResolver();
    });
  }
  _onWatcherHealthCheck(result) {
    this._config.reporter.update({
      type: "watcher_health_check_result",
      result,
    });
  }
  _onWatcherStatus(status) {
    this._config.reporter.update({
      type: "watcher_status",
      status,
    });
  }
  async ready() {
    await this._initializedPromise;
  }
  _onHasteChange({ changes, rootDir }) {
    this._resolutionCache = new Map();
    [
      ...changes.addedFiles,
      ...changes.modifiedFiles,
      ...changes.removedFiles,
    ].forEach(([canonicalPath]) =>
      this.#packageCache.invalidate(
        _nodePath.default.join(rootDir, canonicalPath),
      ),
    );
    this._createModuleResolver();
    this.emit("change");
  }
  _createModuleResolver() {
    this._moduleResolver = (0, _createModuleResolver.default)({
      config: this._config,
      fileSystem: this._fileSystem,
      hasteMap: this._hasteMap,
      packageCache: this.#packageCache,
    });
  }
  _getClosestPackage(absoluteModulePath) {
    const result = this._fileSystem.hierarchicalLookup(
      absoluteModulePath,
      "package.json",
      {
        breakOnSegment: "node_modules",
        invalidatedBy: null,
        subpathType: "f",
      },
    );
    return result
      ? {
          packageJsonPath: result.absolutePath,
          packageRelativePath: result.containerRelativePath,
        }
      : null;
  }
  getAllFiles() {
    return (0, _nullthrows.default)(this._fileSystem).getAllFiles();
  }
  async getOrComputeSha1(mixedPath) {
    const result = await this._fileSystem.getOrComputeSha1(mixedPath);
    if (!result || !result.sha1) {
      throw new Error(`Failed to get the SHA-1 for: ${mixedPath}.
      Potential causes:
        1) The file is not watched. Ensure it is under the configured \`projectRoot\` or \`watchFolders\`.
        2) Check \`blockList\` in your metro.config.js and make sure it isn't excluding the file path.
        3) The file may have been deleted since it was resolved - try refreshing your app.
        4) Otherwise, this is a bug in Metro or the configured resolver - please report it.`);
    }
    return result;
  }
  getWatcher() {
    return this._haste;
  }
  async end() {
    await this.ready();
    await this._haste.end();
  }
  matchFilesWithContext(from, context) {
    return this._fileSystem.matchFiles({
      rootDir: from,
      recursive: context.recursive,
      filter: context.filter,
      filterComparePosix: true,
      follow: true,
    });
  }
  resolveDependency(
    originModulePath,
    dependency,
    platform,
    resolverOptions,
    extraOptions = {
      assumeFlatNodeModules: false,
    },
  ) {
    const to = dependency.name;
    const isSensitiveToOriginFolder =
      !extraOptions.assumeFlatNodeModules ||
      to.includes("/") ||
      to === "." ||
      to === ".." ||
      originModulePath.includes(
        _nodePath.default.sep + "node_modules" + _nodePath.default.sep,
      );
    const resolverOptionsKey =
      JSON.stringify(resolverOptions ?? {}, _canonicalize.default) ?? "";
    const originKey = isSensitiveToOriginFolder
      ? _nodePath.default.dirname(originModulePath)
      : "";
    const targetKey =
      to + (dependency.data.isESMImport === true ? "\0esm" : "\0cjs");
    const platformKey = platform ?? NULL_PLATFORM;
    const mapByResolverOptions = this._resolutionCache;
    const mapByOrigin = getOrCreateMap(
      mapByResolverOptions,
      resolverOptionsKey,
    );
    const mapByTarget = getOrCreateMap(mapByOrigin, originKey);
    const mapByPlatform = getOrCreateMap(mapByTarget, targetKey);
    let resolution = mapByPlatform.get(platformKey);
    if (!resolution) {
      try {
        resolution = this._moduleResolver.resolveDependency(
          originModulePath,
          dependency,
          true,
          platform,
          resolverOptions,
        );
      } catch (error) {
        if (error instanceof _metroFileMap.DuplicateHasteCandidatesError) {
          throw new _metroCore.AmbiguousModuleResolutionError(
            originModulePath,
            error,
          );
        }
        if (error instanceof _metroResolver.InvalidPackageError) {
          throw new _metroCore.PackageResolutionError({
            packageError: error,
            originModulePath,
            targetModuleName: to,
          });
        }
        throw error;
      }
    }
    mapByPlatform.set(platformKey, resolution);
    return resolution;
  }
  doesFileExist = (filePath) => {
    return this._fileSystem.exists(filePath);
  };
  getHasteName(filePath) {
    const hasteName = this._hasteMap.getModuleNameByPath(filePath);
    if (hasteName) {
      return hasteName;
    }
    return _nodePath.default.relative(this._config.projectRoot, filePath);
  }
  getDependencies(filePath) {
    if (!this.#dependencyPlugin) {
      throw new Error(
        "getDependencies called but extractDependencies is false",
      );
    }
    return Array.from(
      (0, _nullthrows.default)(
        this.#dependencyPlugin.getDependencies(filePath),
      ),
    );
  }
}
exports.default = DependencyGraph;
