"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true,
});
exports.UnableToResolveError = exports.ModuleResolver = void 0;
var _codeFrame = require("@babel/code-frame");
var _invariant = _interopRequireDefault(require("invariant"));
var Resolver = _interopRequireWildcard(require("metro-resolver"));
var _createDefaultContext = _interopRequireDefault(
  require("metro-resolver/private/createDefaultContext"),
);
var _nodeFs = _interopRequireDefault(require("node:fs"));
var _nodePath = _interopRequireDefault(require("node:path"));
var _nodeUtil = _interopRequireDefault(require("node:util"));
function _interopRequireWildcard(e, t) {
  if ("function" == typeof WeakMap)
    var r = new WeakMap(),
      n = new WeakMap();
  return (_interopRequireWildcard = function (e, t) {
    if (!t && e && e.__esModule) return e;
    var o,
      i,
      f = { __proto__: null, default: e };
    if (null === e || ("object" != typeof e && "function" != typeof e))
      return f;
    if ((o = t ? n : r)) {
      if (o.has(e)) return o.get(e);
      o.set(e, f);
    }
    for (const t in e)
      "default" !== t &&
        {}.hasOwnProperty.call(e, t) &&
        ((i =
          (o = Object.defineProperty) &&
          Object.getOwnPropertyDescriptor(e, t)) &&
        (i.get || i.set)
          ? o(f, t, i)
          : (f[t] = e[t]));
    return f;
  })(e, t);
}
function _interopRequireDefault(e) {
  return e && e.__esModule ? e : { default: e };
}
class ModuleResolver {
  constructor(options) {
    this._options = options;
    const { projectRoot } = this._options;
    this._projectRootFakeModulePath = _nodePath.default.join(projectRoot, "_");
  }
  _getEmptyModule() {
    let emptyModule = this._cachedEmptyModule;
    if (!emptyModule) {
      emptyModule = this.resolveDependency(
        this._projectRootFakeModulePath,
        {
          data: {
            asyncType: null,
            isESMImport: false,
            key: this._options.emptyModulePath,
            locs: [],
          },
          name: this._options.emptyModulePath,
        },
        false,
        null,
        {
          dev: false,
        },
      );
      this._cachedEmptyModule = emptyModule;
    }
    return emptyModule;
  }
  resolveDependency(
    originModulePath,
    dependency,
    allowHaste,
    platform,
    resolverOptions,
  ) {
    const {
      assetExts,
      disableHierarchicalLookup,
      doesFileExist,
      extraNodeModules,
      fileSystemLookup,
      getPackage,
      getPackageForModule,
      mainFields,
      nodeModulesPaths,
      preferNativePlatform,
      resolveAsset,
      resolveRequest,
      schemeResolvers,
      sourceExts,
      unstable_conditionNames,
      unstable_conditionsByPlatform,
      unstable_enablePackageExports,
      unstable_incrementalResolution,
    } = this._options;
    try {
      const result = Resolver.resolve(
        (0, _createDefaultContext.default)(
          {
            allowHaste,
            assetExts,
            customResolverOptions: resolverOptions.customResolverOptions ?? {},
            dev: resolverOptions.dev,
            disableHierarchicalLookup,
            doesFileExist,
            extraNodeModules,
            fileSystemLookup,
            getPackage,
            getPackageForModule,
            isESMImport: dependency.data.isESMImport,
            mainFields,
            nodeModulesPaths,
            originModulePath,
            preferNativePlatform,
            resolveAsset,
            resolveHasteModule: (name) =>
              this._options.getHasteModulePath(name, platform),
            resolveHastePackage: (name) =>
              this._options.getHastePackagePath(name, platform),
            resolveRequest,
            schemeResolvers,
            sourceExts,
            unstable_conditionNames,
            unstable_conditionsByPlatform,
            unstable_enablePackageExports,
            unstable_incrementalResolution,
            unstable_logWarning: this._logWarning,
          },
          dependency,
        ),
        dependency.name,
        platform,
      );
      return this._getFileResolvedModule(result);
    } catch (error) {
      if (error instanceof Resolver.FailedToResolvePathError) {
        const { candidates } = error;
        throw new UnableToResolveError(
          originModulePath,
          dependency.name,
          "\n\nNone of these files exist:\n" +
            [candidates.file, candidates.dir]
              .filter(Boolean)
              .map(
                (candidates) =>
                  `  * ${Resolver.formatFileCandidates(this._removeRoot(candidates))}`,
              )
              .join("\n"),
          {
            cause: error,
            dependency,
          },
        );
      } else if (error instanceof Resolver.FailedToResolveUnsupportedError) {
        throw new UnableToResolveError(
          originModulePath,
          dependency.name,
          error.message,
          {
            cause: error,
            dependency,
          },
        );
      } else if (error instanceof Resolver.FailedToResolveNameError) {
        const dirPaths = error.dirPaths;
        const extraPaths = error.extraPaths;
        const displayDirPaths = dirPaths
          .filter((dirPath) => {
            const lookupResult = this._options.fileSystemLookup(dirPath);
            return lookupResult.exists && lookupResult.type === "d";
          })
          .map((dirPath) =>
            _nodePath.default.relative(this._options.projectRoot, dirPath),
          )
          .concat(extraPaths);
        const hint = displayDirPaths.length ? " or in these directories:" : "";
        throw new UnableToResolveError(
          originModulePath,
          dependency.name,
          [
            `${dependency.name} could not be found within the project${hint || "."}`,
            ...displayDirPaths.map((dirPath) => `  ${dirPath}`),
          ].join("\n"),
          {
            cause: error,
            dependency,
          },
        );
      }
      throw error;
    }
  }
  _getFileResolvedModule(resolution) {
    switch (resolution.type) {
      case "sourceFile":
        return resolution;
      case "assetFiles":
        const arbitrary = getArrayLowestItem(resolution.filePaths);
        (0, _invariant.default)(arbitrary != null, "invalid asset resolution");
        return {
          filePath: arbitrary,
          type: "sourceFile",
        };
      case "empty":
        return this._getEmptyModule();
      case "virtualModule":
        throw new Error("Virtual modules are not yet implemented.");
      default:
        resolution.type;
        throw new Error("invalid type");
    }
  }
  _logWarning = (message) => {
    this._options.reporter.update({
      message,
      type: "resolver_warning",
    });
  };
  _removeRoot(candidates) {
    if (candidates.filePathPrefix) {
      candidates.filePathPrefix = _nodePath.default.relative(
        this._options.projectRoot,
        candidates.filePathPrefix,
      );
    }
    return candidates;
  }
}
exports.ModuleResolver = ModuleResolver;
function getArrayLowestItem(a) {
  if (a.length === 0) {
    return undefined;
  }
  let lowest = a[0];
  for (let i = 1; i < a.length; ++i) {
    if (a[i] < lowest) {
      lowest = a[i];
    }
  }
  return lowest;
}
class UnableToResolveError extends Error {
  type = "UnableToResolveError";
  constructor(originModulePath, targetModuleName, message, options) {
    super();
    this.originModulePath = originModulePath;
    this.targetModuleName = targetModuleName;
    const codeFrameMessage = this.buildCodeFrameMessage(options?.dependency);
    this.message =
      _nodeUtil.default.format(
        "Unable to resolve module %s from %s: %s",
        targetModuleName,
        originModulePath,
        message,
      ) + (codeFrameMessage ? "\n" + codeFrameMessage : "");
    this.cause = options?.cause;
  }
  buildCodeFrameMessage(dependency) {
    let file;
    try {
      file = _nodeFs.default.readFileSync(this.originModulePath, "utf8");
    } catch (error) {
      if (error.code === "ENOENT" || error.code === "EISDIR") {
        return null;
      }
      throw error;
    }
    const location = dependency?.data.locs.length
      ? refineDependencyLocation(
          dependency.data.locs[0],
          file,
          this.targetModuleName,
        )
      : guessDependencyLocation(file, this.targetModuleName);
    return (0, _codeFrame.codeFrameColumns)(
      _nodeFs.default.readFileSync(this.originModulePath, "utf8"),
      location,
      {
        forceColor: process.env.NODE_ENV !== "test",
      },
    );
  }
}
exports.UnableToResolveError = UnableToResolveError;
function refineDependencyLocation(loc, fileContents, targetSpecifier) {
  const lines = fileContents.split("\n");
  for (let line = loc.end.line - 1; line >= loc.start.line - 1; line--) {
    const maxColumn =
      line === loc.end.line ? loc.end.column + 2 : lines[line].length;
    const minColumn = line === loc.start.line ? loc.start.column - 1 : 0;
    const lineStr = lines[line];
    const lineSlice = lineStr.slice(minColumn, maxColumn);
    for (
      let offset = lineSlice.lastIndexOf(targetSpecifier);
      offset !== -1 && offset > 0 && offset < lineSlice.length - 1;
      offset = lineSlice.lastIndexOf(targetSpecifier, offset - 1)
    ) {
      const maybeQuoteBefore = lineSlice[minColumn + offset - 1];
      const maybeQuoteAfter =
        lineStr[minColumn + offset + targetSpecifier.length];
      if (isQuote(maybeQuoteBefore) && maybeQuoteBefore === maybeQuoteAfter) {
        return {
          start: {
            column: minColumn + offset + 1,
            line: line + 1,
          },
        };
      }
    }
  }
  if (loc.start.line === loc.end.line) {
    return {
      end: {
        column: loc.end.column + 1,
        line: loc.end.line,
      },
      start: {
        column: loc.start.column + 1,
        line: loc.start.line,
      },
    };
  }
  return {
    start: {
      column: loc.start.column + 1,
      line: loc.start.line,
    },
  };
}
function guessDependencyLocation(fileContents, targetSpecifier) {
  const lines = fileContents.split("\n");
  let lineNumber = 0;
  let column = -1;
  for (let line = 0; line < lines.length; line++) {
    const columnLocation = lines[line].lastIndexOf(targetSpecifier);
    if (columnLocation >= 0) {
      lineNumber = line;
      column = columnLocation;
      break;
    }
  }
  return {
    start: {
      column: column + 1,
      line: lineNumber + 1,
    },
  };
}
function isQuote(str) {
  return str === '"' || str === "'" || str === "`";
}
