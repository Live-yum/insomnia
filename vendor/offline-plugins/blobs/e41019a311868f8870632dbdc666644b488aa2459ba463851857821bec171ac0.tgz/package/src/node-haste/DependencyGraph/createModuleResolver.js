"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true,
});
exports.default = createModuleResolver;
var _getSchemeResolvers = _interopRequireDefault(
  require("../../lib/getSchemeResolvers"),
);
var _ModuleResolution = require("./ModuleResolution");
var _nodePath = _interopRequireDefault(require("node:path"));
function _interopRequireDefault(e) {
  return e && e.__esModule ? e : { default: e };
}
function createModuleResolver({ config, fileSystem, hasteMap, packageCache }) {
  const fileSystemLookup = (filePath) => {
    const result = fileSystem.lookup(filePath);
    if (result.exists) {
      return {
        exists: true,
        realPath: result.realPath,
        type: result.type,
      };
    }
    return {
      exists: false,
    };
  };
  return new _ModuleResolution.ModuleResolver({
    assetExts: new Set(config.resolver.assetExts),
    disableHierarchicalLookup: config.resolver.disableHierarchicalLookup,
    doesFileExist: (filePath) => fileSystem.exists(filePath),
    emptyModulePath: config.resolver.emptyModulePath,
    extraNodeModules: config.resolver.extraNodeModules,
    fileSystemLookup,
    getHasteModulePath: (name, platform) =>
      hasteMap.getModule(name, platform, true),
    getHastePackagePath: (name, platform) =>
      hasteMap.getPackage(name, platform, true),
    getPackage: (packageJsonPath) => {
      try {
        return packageCache.getPackage(packageJsonPath).packageJson ?? null;
      } catch {
        return null;
      }
    },
    getPackageForModule: (absolutePath) =>
      packageCache.getPackageForModule(absolutePath),
    mainFields: config.resolver.resolverMainFields,
    nodeModulesPaths: config.resolver.nodeModulesPaths,
    preferNativePlatform: true,
    projectRoot: config.projectRoot,
    reporter: config.reporter,
    resolveAsset: (dirPath, assetName, extension) => {
      const basePath = dirPath + _nodePath.default.sep + assetName;
      const assets = [
        basePath + extension,
        ...config.resolver.assetResolutions.map(
          (resolution) => basePath + "@" + resolution + "x" + extension,
        ),
      ]
        .map((assetPath) => fileSystemLookup(assetPath).realPath)
        .filter(Boolean);
      return assets.length ? assets : null;
    },
    resolveRequest: config.resolver.resolveRequest,
    schemeResolvers: {
      ...(0, _getSchemeResolvers.default)(),
      ...config.resolver.schemeResolvers,
    },
    sourceExts: config.resolver.sourceExts,
    unstable_conditionNames: config.resolver.unstable_conditionNames,
    unstable_conditionsByPlatform:
      config.resolver.unstable_conditionsByPlatform,
    unstable_enablePackageExports:
      config.resolver.unstable_enablePackageExports,
    unstable_incrementalResolution:
      config.resolver.unstable_incrementalResolution,
  });
}
