import { HttpRequest } from "@aws-sdk/types";
export declare const getCanonicalQuery: ({ query }: HttpRequest) => string;
