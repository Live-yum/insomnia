/// <reference types="node" />
import * as __aws_sdk_middleware_stack from "@aws-sdk/middleware-stack";
import * as __aws_sdk_types from "@aws-sdk/types";
import * as _stream from "stream";
import { SSMConfiguration, SSMResolvedConfiguration } from "./SSMConfiguration";
import { InputTypesUnion } from "./types/InputTypesUnion";
import { OutputTypesUnion } from "./types/OutputTypesUnion";
export declare class SSMClient implements __aws_sdk_types.AWSClient<InputTypesUnion, OutputTypesUnion, _stream.Readable> {
    readonly config: SSMResolvedConfiguration;
    readonly middlewareStack: __aws_sdk_middleware_stack.MiddlewareStack<InputTypesUnion, OutputTypesUnion, _stream.Readable>;
    constructor(configuration: SSMConfiguration);
    destroy(): void;
    /**
     * This will need to be revised when the command interface lands.
     */
    send<InputType extends InputTypesUnion, OutputType extends OutputTypesUnion>(command: __aws_sdk_types.Command<InputTypesUnion, InputType, OutputTypesUnion, OutputType, SSMResolvedConfiguration, _stream.Readable>): Promise<OutputType>;
    send<InputType extends InputTypesUnion, OutputType extends OutputTypesUnion>(command: __aws_sdk_types.Command<InputTypesUnion, InputType, OutputTypesUnion, OutputType, SSMResolvedConfiguration, _stream.Readable>, cb: (err: any, data?: OutputType) => void): void;
}
