"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const __aws_sdk_config_resolver = require("@aws-sdk/config-resolver");
const __aws_sdk_middleware_content_length = require("@aws-sdk/middleware-content-length");
const __aws_sdk_middleware_header_default = require("@aws-sdk/middleware-header-default");
const __aws_sdk_middleware_serializer = require("@aws-sdk/middleware-serializer");
const __aws_sdk_middleware_stack = require("@aws-sdk/middleware-stack");
const __aws_sdk_retry_middleware = require("@aws-sdk/retry-middleware");
const __aws_sdk_signing_middleware = require("@aws-sdk/signing-middleware");
const __aws_sdk_util_user_agent_node = require("@aws-sdk/util-user-agent-node");
const SSMConfiguration_1 = require("./SSMConfiguration");
const ServiceMetadata_1 = require("./model/ServiceMetadata");
class SSMClient {
    constructor(configuration) {
        this.middlewareStack = new __aws_sdk_middleware_stack.MiddlewareStack();
        this.config = __aws_sdk_config_resolver.resolveConfiguration(configuration, SSMConfiguration_1.configurationProperties, this.middlewareStack);
        this.middlewareStack.add(__aws_sdk_middleware_serializer.serializerMiddleware(this.config.serializer), {
            step: "serialize",
            priority: 90,
            tags: { SERIALIZER: true }
        });
        this.middlewareStack.add(__aws_sdk_middleware_content_length.contentLengthMiddleware(this.config.bodyLengthChecker), {
            step: "build",
            priority: -80,
            tags: { SET_CONTENT_LENGTH: true }
        });
        if (this.config.maxRetries > 0) {
            this.middlewareStack.add(__aws_sdk_retry_middleware.retryMiddleware(this.config.maxRetries, this.config.retryDecider, this.config.delayDecider), {
                step: "finalize",
                priority: Infinity,
                tags: { RETRY: true }
            });
        }
        this.middlewareStack.add(__aws_sdk_signing_middleware.signingMiddleware(this.config.signer), {
            step: "finalize",
            priority: 0,
            tags: { SIGNATURE: true }
        });
        this.middlewareStack.add(__aws_sdk_middleware_header_default.headerDefault({
            "User-Agent": __aws_sdk_util_user_agent_node.defaultUserAgent(ServiceMetadata_1.ServiceMetadata.serviceId || ServiceMetadata_1.ServiceMetadata.endpointPrefix, ServiceMetadata_1.clientVersion)
        }), {
            step: "build",
            priority: 0,
            tags: { SET_USER_AGENT: true }
        });
    }
    destroy() {
        if (!this.config._user_injected_http_handler) {
            this.config.httpHandler.destroy();
        }
    }
    send(command, cb) {
        const handler = command.resolveMiddleware(this.middlewareStack, this.config);
        if (cb) {
            handler(command)
                .then((result) => cb(null, result), (err) => cb(err))
                .catch(
            // prevent any errors thrown in the callback from triggering an
            // unhandled promise rejection
            () => { });
        }
        else {
            return handler(command);
        }
    }
}
exports.SSMClient = SSMClient;
//# sourceMappingURL=SSMClient.js.map