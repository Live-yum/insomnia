"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const __aws_sdk_middleware_stack = require("@aws-sdk/middleware-stack");
const StartSession_1 = require("../model/operations/StartSession");
class StartSessionCommand {
    constructor(input) {
        this.input = input;
        this.model = StartSession_1.StartSession;
        this.middlewareStack = new __aws_sdk_middleware_stack.MiddlewareStack();
    }
    resolveMiddleware(clientStack, configuration) {
        const { handler } = configuration;
        const stack = clientStack.concat(this.middlewareStack);
        const handlerExecutionContext = {
            logger: {},
            model: this.model
        };
        return stack.resolve(handler(handlerExecutionContext), handlerExecutionContext);
    }
}
exports.StartSessionCommand = StartSessionCommand;
//# sourceMappingURL=StartSessionCommand.js.map