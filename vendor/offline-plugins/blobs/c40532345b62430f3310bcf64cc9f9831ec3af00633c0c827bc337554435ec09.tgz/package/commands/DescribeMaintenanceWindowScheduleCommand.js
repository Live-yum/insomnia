"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const __aws_sdk_middleware_stack = require("@aws-sdk/middleware-stack");
const DescribeMaintenanceWindowSchedule_1 = require("../model/operations/DescribeMaintenanceWindowSchedule");
class DescribeMaintenanceWindowScheduleCommand {
    constructor(input) {
        this.input = input;
        this.model = DescribeMaintenanceWindowSchedule_1.DescribeMaintenanceWindowSchedule;
        this.middlewareStack = new __aws_sdk_middleware_stack.MiddlewareStack();
    }
    resolveMiddleware(clientStack, configuration) {
        const { handler } = configuration;
        const stack = clientStack.concat(this.middlewareStack);
        const handlerExecutionContext = {
            logger: {},
            model: this.model
        };
        return stack.resolve(handler(handlerExecutionContext), handlerExecutionContext);
    }
}
exports.DescribeMaintenanceWindowScheduleCommand = DescribeMaintenanceWindowScheduleCommand;
//# sourceMappingURL=DescribeMaintenanceWindowScheduleCommand.js.map