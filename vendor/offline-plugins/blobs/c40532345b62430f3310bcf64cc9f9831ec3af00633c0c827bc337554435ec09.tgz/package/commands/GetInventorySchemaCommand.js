"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const __aws_sdk_middleware_stack = require("@aws-sdk/middleware-stack");
const GetInventorySchema_1 = require("../model/operations/GetInventorySchema");
class GetInventorySchemaCommand {
    constructor(input) {
        this.input = input;
        this.model = GetInventorySchema_1.GetInventorySchema;
        this.middlewareStack = new __aws_sdk_middleware_stack.MiddlewareStack();
    }
    resolveMiddleware(clientStack, configuration) {
        const { handler } = configuration;
        const stack = clientStack.concat(this.middlewareStack);
        const handlerExecutionContext = {
            logger: {},
            model: this.model
        };
        return stack.resolve(handler(handlerExecutionContext), handlerExecutionContext);
    }
}
exports.GetInventorySchemaCommand = GetInventorySchemaCommand;
//# sourceMappingURL=GetInventorySchemaCommand.js.map