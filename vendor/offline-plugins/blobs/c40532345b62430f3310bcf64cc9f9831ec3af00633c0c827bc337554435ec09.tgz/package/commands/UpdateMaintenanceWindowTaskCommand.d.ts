/// <reference types="node" />
import * as __aws_sdk_middleware_stack from "@aws-sdk/middleware-stack";
import * as __aws_sdk_types from "@aws-sdk/types";
import * as _stream from "stream";
import { InputTypesUnion } from "../types/InputTypesUnion";
import { OutputTypesUnion } from "../types/OutputTypesUnion";
import { UpdateMaintenanceWindowTaskInput } from "../types/UpdateMaintenanceWindowTaskInput";
import { UpdateMaintenanceWindowTaskOutput } from "../types/UpdateMaintenanceWindowTaskOutput";
import { SSMResolvedConfiguration } from "../SSMConfiguration";
export * from "../types/UpdateMaintenanceWindowTaskInput";
export * from "../types/UpdateMaintenanceWindowTaskOutput";
export * from "../types/UpdateMaintenanceWindowTaskExceptionsUnion";
export declare class UpdateMaintenanceWindowTaskCommand implements __aws_sdk_types.Command<InputTypesUnion, UpdateMaintenanceWindowTaskInput, OutputTypesUnion, UpdateMaintenanceWindowTaskOutput, SSMResolvedConfiguration, _stream.Readable> {
    readonly input: UpdateMaintenanceWindowTaskInput;
    readonly model: __aws_sdk_types.OperationModel;
    readonly middlewareStack: __aws_sdk_middleware_stack.MiddlewareStack<UpdateMaintenanceWindowTaskInput, UpdateMaintenanceWindowTaskOutput, _stream.Readable>;
    constructor(input: UpdateMaintenanceWindowTaskInput);
    resolveMiddleware(clientStack: __aws_sdk_middleware_stack.MiddlewareStack<InputTypesUnion, OutputTypesUnion, _stream.Readable>, configuration: SSMResolvedConfiguration): __aws_sdk_types.Handler<UpdateMaintenanceWindowTaskInput, UpdateMaintenanceWindowTaskOutput>;
}
