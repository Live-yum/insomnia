/// <reference types="node" />
import * as __aws_sdk_middleware_stack from "@aws-sdk/middleware-stack";
import * as __aws_sdk_types from "@aws-sdk/types";
import * as _stream from "stream";
import { InputTypesUnion } from "../types/InputTypesUnion";
import { OutputTypesUnion } from "../types/OutputTypesUnion";
import { GetMaintenanceWindowTaskInput } from "../types/GetMaintenanceWindowTaskInput";
import { GetMaintenanceWindowTaskOutput } from "../types/GetMaintenanceWindowTaskOutput";
import { SSMResolvedConfiguration } from "../SSMConfiguration";
export * from "../types/GetMaintenanceWindowTaskInput";
export * from "../types/GetMaintenanceWindowTaskOutput";
export * from "../types/GetMaintenanceWindowTaskExceptionsUnion";
export declare class GetMaintenanceWindowTaskCommand implements __aws_sdk_types.Command<InputTypesUnion, GetMaintenanceWindowTaskInput, OutputTypesUnion, GetMaintenanceWindowTaskOutput, SSMResolvedConfiguration, _stream.Readable> {
    readonly input: GetMaintenanceWindowTaskInput;
    readonly model: __aws_sdk_types.OperationModel;
    readonly middlewareStack: __aws_sdk_middleware_stack.MiddlewareStack<GetMaintenanceWindowTaskInput, GetMaintenanceWindowTaskOutput, _stream.Readable>;
    constructor(input: GetMaintenanceWindowTaskInput);
    resolveMiddleware(clientStack: __aws_sdk_middleware_stack.MiddlewareStack<InputTypesUnion, OutputTypesUnion, _stream.Readable>, configuration: SSMResolvedConfiguration): __aws_sdk_types.Handler<GetMaintenanceWindowTaskInput, GetMaintenanceWindowTaskOutput>;
}
