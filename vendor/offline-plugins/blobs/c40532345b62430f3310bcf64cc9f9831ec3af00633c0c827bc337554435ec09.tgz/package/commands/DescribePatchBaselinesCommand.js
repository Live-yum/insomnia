"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const __aws_sdk_middleware_stack = require("@aws-sdk/middleware-stack");
const DescribePatchBaselines_1 = require("../model/operations/DescribePatchBaselines");
class DescribePatchBaselinesCommand {
    constructor(input) {
        this.input = input;
        this.model = DescribePatchBaselines_1.DescribePatchBaselines;
        this.middlewareStack = new __aws_sdk_middleware_stack.MiddlewareStack();
    }
    resolveMiddleware(clientStack, configuration) {
        const { handler } = configuration;
        const stack = clientStack.concat(this.middlewareStack);
        const handlerExecutionContext = {
            logger: {},
            model: this.model
        };
        return stack.resolve(handler(handlerExecutionContext), handlerExecutionContext);
    }
}
exports.DescribePatchBaselinesCommand = DescribePatchBaselinesCommand;
//# sourceMappingURL=DescribePatchBaselinesCommand.js.map