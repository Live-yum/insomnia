/// <reference types="node" />
import * as __aws_sdk_middleware_stack from "@aws-sdk/middleware-stack";
import * as __aws_sdk_types from "@aws-sdk/types";
import * as _stream from "stream";
import { InputTypesUnion } from "../types/InputTypesUnion";
import { OutputTypesUnion } from "../types/OutputTypesUnion";
import { DeletePatchBaselineInput } from "../types/DeletePatchBaselineInput";
import { DeletePatchBaselineOutput } from "../types/DeletePatchBaselineOutput";
import { SSMResolvedConfiguration } from "../SSMConfiguration";
export * from "../types/DeletePatchBaselineInput";
export * from "../types/DeletePatchBaselineOutput";
export * from "../types/DeletePatchBaselineExceptionsUnion";
export declare class DeletePatchBaselineCommand implements __aws_sdk_types.Command<InputTypesUnion, DeletePatchBaselineInput, OutputTypesUnion, DeletePatchBaselineOutput, SSMResolvedConfiguration, _stream.Readable> {
    readonly input: DeletePatchBaselineInput;
    readonly model: __aws_sdk_types.OperationModel;
    readonly middlewareStack: __aws_sdk_middleware_stack.MiddlewareStack<DeletePatchBaselineInput, DeletePatchBaselineOutput, _stream.Readable>;
    constructor(input: DeletePatchBaselineInput);
    resolveMiddleware(clientStack: __aws_sdk_middleware_stack.MiddlewareStack<InputTypesUnion, OutputTypesUnion, _stream.Readable>, configuration: SSMResolvedConfiguration): __aws_sdk_types.Handler<DeletePatchBaselineInput, DeletePatchBaselineOutput>;
}
