"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const __aws_sdk_middleware_stack = require("@aws-sdk/middleware-stack");
const DescribeAssociationExecutionTargets_1 = require("../model/operations/DescribeAssociationExecutionTargets");
class DescribeAssociationExecutionTargetsCommand {
    constructor(input) {
        this.input = input;
        this.model = DescribeAssociationExecutionTargets_1.DescribeAssociationExecutionTargets;
        this.middlewareStack = new __aws_sdk_middleware_stack.MiddlewareStack();
    }
    resolveMiddleware(clientStack, configuration) {
        const { handler } = configuration;
        const stack = clientStack.concat(this.middlewareStack);
        const handlerExecutionContext = {
            logger: {},
            model: this.model
        };
        return stack.resolve(handler(handlerExecutionContext), handlerExecutionContext);
    }
}
exports.DescribeAssociationExecutionTargetsCommand = DescribeAssociationExecutionTargetsCommand;
//# sourceMappingURL=DescribeAssociationExecutionTargetsCommand.js.map