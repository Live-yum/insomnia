/// <reference types="node" />
import * as __aws_sdk_middleware_stack from "@aws-sdk/middleware-stack";
import * as __aws_sdk_types from "@aws-sdk/types";
import * as _stream from "stream";
import { InputTypesUnion } from "../types/InputTypesUnion";
import { OutputTypesUnion } from "../types/OutputTypesUnion";
import { DescribeMaintenanceWindowExecutionTaskInvocationsInput } from "../types/DescribeMaintenanceWindowExecutionTaskInvocationsInput";
import { DescribeMaintenanceWindowExecutionTaskInvocationsOutput } from "../types/DescribeMaintenanceWindowExecutionTaskInvocationsOutput";
import { SSMResolvedConfiguration } from "../SSMConfiguration";
export * from "../types/DescribeMaintenanceWindowExecutionTaskInvocationsInput";
export * from "../types/DescribeMaintenanceWindowExecutionTaskInvocationsOutput";
export * from "../types/DescribeMaintenanceWindowExecutionTaskInvocationsExceptionsUnion";
export declare class DescribeMaintenanceWindowExecutionTaskInvocationsCommand implements __aws_sdk_types.Command<InputTypesUnion, DescribeMaintenanceWindowExecutionTaskInvocationsInput, OutputTypesUnion, DescribeMaintenanceWindowExecutionTaskInvocationsOutput, SSMResolvedConfiguration, _stream.Readable> {
    readonly input: DescribeMaintenanceWindowExecutionTaskInvocationsInput;
    readonly model: __aws_sdk_types.OperationModel;
    readonly middlewareStack: __aws_sdk_middleware_stack.MiddlewareStack<DescribeMaintenanceWindowExecutionTaskInvocationsInput, DescribeMaintenanceWindowExecutionTaskInvocationsOutput, _stream.Readable>;
    constructor(input: DescribeMaintenanceWindowExecutionTaskInvocationsInput);
    resolveMiddleware(clientStack: __aws_sdk_middleware_stack.MiddlewareStack<InputTypesUnion, OutputTypesUnion, _stream.Readable>, configuration: SSMResolvedConfiguration): __aws_sdk_types.Handler<DescribeMaintenanceWindowExecutionTaskInvocationsInput, DescribeMaintenanceWindowExecutionTaskInvocationsOutput>;
}
