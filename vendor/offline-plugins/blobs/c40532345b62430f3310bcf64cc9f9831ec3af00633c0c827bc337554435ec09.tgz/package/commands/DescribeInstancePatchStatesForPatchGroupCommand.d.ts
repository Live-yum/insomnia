/// <reference types="node" />
import * as __aws_sdk_middleware_stack from "@aws-sdk/middleware-stack";
import * as __aws_sdk_types from "@aws-sdk/types";
import * as _stream from "stream";
import { InputTypesUnion } from "../types/InputTypesUnion";
import { OutputTypesUnion } from "../types/OutputTypesUnion";
import { DescribeInstancePatchStatesForPatchGroupInput } from "../types/DescribeInstancePatchStatesForPatchGroupInput";
import { DescribeInstancePatchStatesForPatchGroupOutput } from "../types/DescribeInstancePatchStatesForPatchGroupOutput";
import { SSMResolvedConfiguration } from "../SSMConfiguration";
export * from "../types/DescribeInstancePatchStatesForPatchGroupInput";
export * from "../types/DescribeInstancePatchStatesForPatchGroupOutput";
export * from "../types/DescribeInstancePatchStatesForPatchGroupExceptionsUnion";
export declare class DescribeInstancePatchStatesForPatchGroupCommand implements __aws_sdk_types.Command<InputTypesUnion, DescribeInstancePatchStatesForPatchGroupInput, OutputTypesUnion, DescribeInstancePatchStatesForPatchGroupOutput, SSMResolvedConfiguration, _stream.Readable> {
    readonly input: DescribeInstancePatchStatesForPatchGroupInput;
    readonly model: __aws_sdk_types.OperationModel;
    readonly middlewareStack: __aws_sdk_middleware_stack.MiddlewareStack<DescribeInstancePatchStatesForPatchGroupInput, DescribeInstancePatchStatesForPatchGroupOutput, _stream.Readable>;
    constructor(input: DescribeInstancePatchStatesForPatchGroupInput);
    resolveMiddleware(clientStack: __aws_sdk_middleware_stack.MiddlewareStack<InputTypesUnion, OutputTypesUnion, _stream.Readable>, configuration: SSMResolvedConfiguration): __aws_sdk_types.Handler<DescribeInstancePatchStatesForPatchGroupInput, DescribeInstancePatchStatesForPatchGroupOutput>;
}
