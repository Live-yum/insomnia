/// <reference types="node" />
import * as __aws_sdk_middleware_stack from "@aws-sdk/middleware-stack";
import * as __aws_sdk_types from "@aws-sdk/types";
import * as _stream from "stream";
import { InputTypesUnion } from "../types/InputTypesUnion";
import { OutputTypesUnion } from "../types/OutputTypesUnion";
import { DescribeMaintenanceWindowExecutionTasksInput } from "../types/DescribeMaintenanceWindowExecutionTasksInput";
import { DescribeMaintenanceWindowExecutionTasksOutput } from "../types/DescribeMaintenanceWindowExecutionTasksOutput";
import { SSMResolvedConfiguration } from "../SSMConfiguration";
export * from "../types/DescribeMaintenanceWindowExecutionTasksInput";
export * from "../types/DescribeMaintenanceWindowExecutionTasksOutput";
export * from "../types/DescribeMaintenanceWindowExecutionTasksExceptionsUnion";
export declare class DescribeMaintenanceWindowExecutionTasksCommand implements __aws_sdk_types.Command<InputTypesUnion, DescribeMaintenanceWindowExecutionTasksInput, OutputTypesUnion, DescribeMaintenanceWindowExecutionTasksOutput, SSMResolvedConfiguration, _stream.Readable> {
    readonly input: DescribeMaintenanceWindowExecutionTasksInput;
    readonly model: __aws_sdk_types.OperationModel;
    readonly middlewareStack: __aws_sdk_middleware_stack.MiddlewareStack<DescribeMaintenanceWindowExecutionTasksInput, DescribeMaintenanceWindowExecutionTasksOutput, _stream.Readable>;
    constructor(input: DescribeMaintenanceWindowExecutionTasksInput);
    resolveMiddleware(clientStack: __aws_sdk_middleware_stack.MiddlewareStack<InputTypesUnion, OutputTypesUnion, _stream.Readable>, configuration: SSMResolvedConfiguration): __aws_sdk_types.Handler<DescribeMaintenanceWindowExecutionTasksInput, DescribeMaintenanceWindowExecutionTasksOutput>;
}
