"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const __aws_sdk_middleware_stack = require("@aws-sdk/middleware-stack");
const GetConnectionStatus_1 = require("../model/operations/GetConnectionStatus");
class GetConnectionStatusCommand {
    constructor(input) {
        this.input = input;
        this.model = GetConnectionStatus_1.GetConnectionStatus;
        this.middlewareStack = new __aws_sdk_middleware_stack.MiddlewareStack();
    }
    resolveMiddleware(clientStack, configuration) {
        const { handler } = configuration;
        const stack = clientStack.concat(this.middlewareStack);
        const handlerExecutionContext = {
            logger: {},
            model: this.model
        };
        return stack.resolve(handler(handlerExecutionContext), handlerExecutionContext);
    }
}
exports.GetConnectionStatusCommand = GetConnectionStatusCommand;
//# sourceMappingURL=GetConnectionStatusCommand.js.map