"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const __aws_sdk_middleware_stack = require("@aws-sdk/middleware-stack");
const DescribeMaintenanceWindowTargets_1 = require("../model/operations/DescribeMaintenanceWindowTargets");
class DescribeMaintenanceWindowTargetsCommand {
    constructor(input) {
        this.input = input;
        this.model = DescribeMaintenanceWindowTargets_1.DescribeMaintenanceWindowTargets;
        this.middlewareStack = new __aws_sdk_middleware_stack.MiddlewareStack();
    }
    resolveMiddleware(clientStack, configuration) {
        const { handler } = configuration;
        const stack = clientStack.concat(this.middlewareStack);
        const handlerExecutionContext = {
            logger: {},
            model: this.model
        };
        return stack.resolve(handler(handlerExecutionContext), handlerExecutionContext);
    }
}
exports.DescribeMaintenanceWindowTargetsCommand = DescribeMaintenanceWindowTargetsCommand;
//# sourceMappingURL=DescribeMaintenanceWindowTargetsCommand.js.map