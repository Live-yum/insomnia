/// <reference types="node" />
import * as __aws_sdk_middleware_stack from "@aws-sdk/middleware-stack";
import * as __aws_sdk_types from "@aws-sdk/types";
import * as _stream from "stream";
import { InputTypesUnion } from "../types/InputTypesUnion";
import { OutputTypesUnion } from "../types/OutputTypesUnion";
import { GetMaintenanceWindowExecutionTaskInvocationInput } from "../types/GetMaintenanceWindowExecutionTaskInvocationInput";
import { GetMaintenanceWindowExecutionTaskInvocationOutput } from "../types/GetMaintenanceWindowExecutionTaskInvocationOutput";
import { SSMResolvedConfiguration } from "../SSMConfiguration";
export * from "../types/GetMaintenanceWindowExecutionTaskInvocationInput";
export * from "../types/GetMaintenanceWindowExecutionTaskInvocationOutput";
export * from "../types/GetMaintenanceWindowExecutionTaskInvocationExceptionsUnion";
export declare class GetMaintenanceWindowExecutionTaskInvocationCommand implements __aws_sdk_types.Command<InputTypesUnion, GetMaintenanceWindowExecutionTaskInvocationInput, OutputTypesUnion, GetMaintenanceWindowExecutionTaskInvocationOutput, SSMResolvedConfiguration, _stream.Readable> {
    readonly input: GetMaintenanceWindowExecutionTaskInvocationInput;
    readonly model: __aws_sdk_types.OperationModel;
    readonly middlewareStack: __aws_sdk_middleware_stack.MiddlewareStack<GetMaintenanceWindowExecutionTaskInvocationInput, GetMaintenanceWindowExecutionTaskInvocationOutput, _stream.Readable>;
    constructor(input: GetMaintenanceWindowExecutionTaskInvocationInput);
    resolveMiddleware(clientStack: __aws_sdk_middleware_stack.MiddlewareStack<InputTypesUnion, OutputTypesUnion, _stream.Readable>, configuration: SSMResolvedConfiguration): __aws_sdk_types.Handler<GetMaintenanceWindowExecutionTaskInvocationInput, GetMaintenanceWindowExecutionTaskInvocationOutput>;
}
