"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const __aws_sdk_middleware_stack = require("@aws-sdk/middleware-stack");
const RegisterPatchBaselineForPatchGroup_1 = require("../model/operations/RegisterPatchBaselineForPatchGroup");
class RegisterPatchBaselineForPatchGroupCommand {
    constructor(input) {
        this.input = input;
        this.model = RegisterPatchBaselineForPatchGroup_1.RegisterPatchBaselineForPatchGroup;
        this.middlewareStack = new __aws_sdk_middleware_stack.MiddlewareStack();
    }
    resolveMiddleware(clientStack, configuration) {
        const { handler } = configuration;
        const stack = clientStack.concat(this.middlewareStack);
        const handlerExecutionContext = {
            logger: {},
            model: this.model
        };
        return stack.resolve(handler(handlerExecutionContext), handlerExecutionContext);
    }
}
exports.RegisterPatchBaselineForPatchGroupCommand = RegisterPatchBaselineForPatchGroupCommand;
//# sourceMappingURL=RegisterPatchBaselineForPatchGroupCommand.js.map