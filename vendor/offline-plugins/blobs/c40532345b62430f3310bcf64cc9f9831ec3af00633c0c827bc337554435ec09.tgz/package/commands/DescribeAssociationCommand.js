"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const __aws_sdk_middleware_stack = require("@aws-sdk/middleware-stack");
const DescribeAssociation_1 = require("../model/operations/DescribeAssociation");
class DescribeAssociationCommand {
    constructor(input) {
        this.input = input;
        this.model = DescribeAssociation_1.DescribeAssociation;
        this.middlewareStack = new __aws_sdk_middleware_stack.MiddlewareStack();
    }
    resolveMiddleware(clientStack, configuration) {
        const { handler } = configuration;
        const stack = clientStack.concat(this.middlewareStack);
        const handlerExecutionContext = {
            logger: {},
            model: this.model
        };
        return stack.resolve(handler(handlerExecutionContext), handlerExecutionContext);
    }
}
exports.DescribeAssociationCommand = DescribeAssociationCommand;
//# sourceMappingURL=DescribeAssociationCommand.js.map