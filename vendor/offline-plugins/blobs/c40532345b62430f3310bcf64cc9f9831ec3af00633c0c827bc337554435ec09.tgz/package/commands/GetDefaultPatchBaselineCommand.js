"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const __aws_sdk_middleware_stack = require("@aws-sdk/middleware-stack");
const GetDefaultPatchBaseline_1 = require("../model/operations/GetDefaultPatchBaseline");
class GetDefaultPatchBaselineCommand {
    constructor(input) {
        this.input = input;
        this.model = GetDefaultPatchBaseline_1.GetDefaultPatchBaseline;
        this.middlewareStack = new __aws_sdk_middleware_stack.MiddlewareStack();
    }
    resolveMiddleware(clientStack, configuration) {
        const { handler } = configuration;
        const stack = clientStack.concat(this.middlewareStack);
        const handlerExecutionContext = {
            logger: {},
            model: this.model
        };
        return stack.resolve(handler(handlerExecutionContext), handlerExecutionContext);
    }
}
exports.GetDefaultPatchBaselineCommand = GetDefaultPatchBaselineCommand;
//# sourceMappingURL=GetDefaultPatchBaselineCommand.js.map