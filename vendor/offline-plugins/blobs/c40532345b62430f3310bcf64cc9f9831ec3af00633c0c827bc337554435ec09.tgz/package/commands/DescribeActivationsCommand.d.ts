/// <reference types="node" />
import * as __aws_sdk_middleware_stack from "@aws-sdk/middleware-stack";
import * as __aws_sdk_types from "@aws-sdk/types";
import * as _stream from "stream";
import { InputTypesUnion } from "../types/InputTypesUnion";
import { OutputTypesUnion } from "../types/OutputTypesUnion";
import { DescribeActivationsInput } from "../types/DescribeActivationsInput";
import { DescribeActivationsOutput } from "../types/DescribeActivationsOutput";
import { SSMResolvedConfiguration } from "../SSMConfiguration";
export * from "../types/DescribeActivationsInput";
export * from "../types/DescribeActivationsOutput";
export * from "../types/DescribeActivationsExceptionsUnion";
export declare class DescribeActivationsCommand implements __aws_sdk_types.Command<InputTypesUnion, DescribeActivationsInput, OutputTypesUnion, DescribeActivationsOutput, SSMResolvedConfiguration, _stream.Readable> {
    readonly input: DescribeActivationsInput;
    readonly model: __aws_sdk_types.OperationModel;
    readonly middlewareStack: __aws_sdk_middleware_stack.MiddlewareStack<DescribeActivationsInput, DescribeActivationsOutput, _stream.Readable>;
    constructor(input: DescribeActivationsInput);
    resolveMiddleware(clientStack: __aws_sdk_middleware_stack.MiddlewareStack<InputTypesUnion, OutputTypesUnion, _stream.Readable>, configuration: SSMResolvedConfiguration): __aws_sdk_types.Handler<DescribeActivationsInput, DescribeActivationsOutput>;
}
