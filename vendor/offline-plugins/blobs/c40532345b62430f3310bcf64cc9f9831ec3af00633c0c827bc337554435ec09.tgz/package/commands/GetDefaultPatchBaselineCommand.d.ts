/// <reference types="node" />
import * as __aws_sdk_middleware_stack from "@aws-sdk/middleware-stack";
import * as __aws_sdk_types from "@aws-sdk/types";
import * as _stream from "stream";
import { InputTypesUnion } from "../types/InputTypesUnion";
import { OutputTypesUnion } from "../types/OutputTypesUnion";
import { GetDefaultPatchBaselineInput } from "../types/GetDefaultPatchBaselineInput";
import { GetDefaultPatchBaselineOutput } from "../types/GetDefaultPatchBaselineOutput";
import { SSMResolvedConfiguration } from "../SSMConfiguration";
export * from "../types/GetDefaultPatchBaselineInput";
export * from "../types/GetDefaultPatchBaselineOutput";
export * from "../types/GetDefaultPatchBaselineExceptionsUnion";
export declare class GetDefaultPatchBaselineCommand implements __aws_sdk_types.Command<InputTypesUnion, GetDefaultPatchBaselineInput, OutputTypesUnion, GetDefaultPatchBaselineOutput, SSMResolvedConfiguration, _stream.Readable> {
    readonly input: GetDefaultPatchBaselineInput;
    readonly model: __aws_sdk_types.OperationModel;
    readonly middlewareStack: __aws_sdk_middleware_stack.MiddlewareStack<GetDefaultPatchBaselineInput, GetDefaultPatchBaselineOutput, _stream.Readable>;
    constructor(input: GetDefaultPatchBaselineInput);
    resolveMiddleware(clientStack: __aws_sdk_middleware_stack.MiddlewareStack<InputTypesUnion, OutputTypesUnion, _stream.Readable>, configuration: SSMResolvedConfiguration): __aws_sdk_types.Handler<GetDefaultPatchBaselineInput, GetDefaultPatchBaselineOutput>;
}
