"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const __aws_sdk_middleware_stack = require("@aws-sdk/middleware-stack");
const ListResourceComplianceSummaries_1 = require("../model/operations/ListResourceComplianceSummaries");
class ListResourceComplianceSummariesCommand {
    constructor(input) {
        this.input = input;
        this.model = ListResourceComplianceSummaries_1.ListResourceComplianceSummaries;
        this.middlewareStack = new __aws_sdk_middleware_stack.MiddlewareStack();
    }
    resolveMiddleware(clientStack, configuration) {
        const { handler } = configuration;
        const stack = clientStack.concat(this.middlewareStack);
        const handlerExecutionContext = {
            logger: {},
            model: this.model
        };
        return stack.resolve(handler(handlerExecutionContext), handlerExecutionContext);
    }
}
exports.ListResourceComplianceSummariesCommand = ListResourceComplianceSummariesCommand;
//# sourceMappingURL=ListResourceComplianceSummariesCommand.js.map