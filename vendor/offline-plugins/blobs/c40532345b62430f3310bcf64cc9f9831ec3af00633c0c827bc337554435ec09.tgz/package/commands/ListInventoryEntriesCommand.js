"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const __aws_sdk_middleware_stack = require("@aws-sdk/middleware-stack");
const ListInventoryEntries_1 = require("../model/operations/ListInventoryEntries");
class ListInventoryEntriesCommand {
    constructor(input) {
        this.input = input;
        this.model = ListInventoryEntries_1.ListInventoryEntries;
        this.middlewareStack = new __aws_sdk_middleware_stack.MiddlewareStack();
    }
    resolveMiddleware(clientStack, configuration) {
        const { handler } = configuration;
        const stack = clientStack.concat(this.middlewareStack);
        const handlerExecutionContext = {
            logger: {},
            model: this.model
        };
        return stack.resolve(handler(handlerExecutionContext), handlerExecutionContext);
    }
}
exports.ListInventoryEntriesCommand = ListInventoryEntriesCommand;
//# sourceMappingURL=ListInventoryEntriesCommand.js.map