/// <reference types="node" />
import * as __aws_sdk_middleware_stack from "@aws-sdk/middleware-stack";
import * as __aws_sdk_types from "@aws-sdk/types";
import * as _stream from "stream";
import { InputTypesUnion } from "../types/InputTypesUnion";
import { OutputTypesUnion } from "../types/OutputTypesUnion";
import { DeleteParameterInput } from "../types/DeleteParameterInput";
import { DeleteParameterOutput } from "../types/DeleteParameterOutput";
import { SSMResolvedConfiguration } from "../SSMConfiguration";
export * from "../types/DeleteParameterInput";
export * from "../types/DeleteParameterOutput";
export * from "../types/DeleteParameterExceptionsUnion";
export declare class DeleteParameterCommand implements __aws_sdk_types.Command<InputTypesUnion, DeleteParameterInput, OutputTypesUnion, DeleteParameterOutput, SSMResolvedConfiguration, _stream.Readable> {
    readonly input: DeleteParameterInput;
    readonly model: __aws_sdk_types.OperationModel;
    readonly middlewareStack: __aws_sdk_middleware_stack.MiddlewareStack<DeleteParameterInput, DeleteParameterOutput, _stream.Readable>;
    constructor(input: DeleteParameterInput);
    resolveMiddleware(clientStack: __aws_sdk_middleware_stack.MiddlewareStack<InputTypesUnion, OutputTypesUnion, _stream.Readable>, configuration: SSMResolvedConfiguration): __aws_sdk_types.Handler<DeleteParameterInput, DeleteParameterOutput>;
}
