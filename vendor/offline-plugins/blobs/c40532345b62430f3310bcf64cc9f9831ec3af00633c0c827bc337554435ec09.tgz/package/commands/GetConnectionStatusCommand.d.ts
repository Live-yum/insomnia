/// <reference types="node" />
import * as __aws_sdk_middleware_stack from "@aws-sdk/middleware-stack";
import * as __aws_sdk_types from "@aws-sdk/types";
import * as _stream from "stream";
import { InputTypesUnion } from "../types/InputTypesUnion";
import { OutputTypesUnion } from "../types/OutputTypesUnion";
import { GetConnectionStatusInput } from "../types/GetConnectionStatusInput";
import { GetConnectionStatusOutput } from "../types/GetConnectionStatusOutput";
import { SSMResolvedConfiguration } from "../SSMConfiguration";
export * from "../types/GetConnectionStatusInput";
export * from "../types/GetConnectionStatusOutput";
export * from "../types/GetConnectionStatusExceptionsUnion";
export declare class GetConnectionStatusCommand implements __aws_sdk_types.Command<InputTypesUnion, GetConnectionStatusInput, OutputTypesUnion, GetConnectionStatusOutput, SSMResolvedConfiguration, _stream.Readable> {
    readonly input: GetConnectionStatusInput;
    readonly model: __aws_sdk_types.OperationModel;
    readonly middlewareStack: __aws_sdk_middleware_stack.MiddlewareStack<GetConnectionStatusInput, GetConnectionStatusOutput, _stream.Readable>;
    constructor(input: GetConnectionStatusInput);
    resolveMiddleware(clientStack: __aws_sdk_middleware_stack.MiddlewareStack<InputTypesUnion, OutputTypesUnion, _stream.Readable>, configuration: SSMResolvedConfiguration): __aws_sdk_types.Handler<GetConnectionStatusInput, GetConnectionStatusOutput>;
}
