"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const __aws_sdk_middleware_stack = require("@aws-sdk/middleware-stack");
const DeleteResourceDataSync_1 = require("../model/operations/DeleteResourceDataSync");
class DeleteResourceDataSyncCommand {
    constructor(input) {
        this.input = input;
        this.model = DeleteResourceDataSync_1.DeleteResourceDataSync;
        this.middlewareStack = new __aws_sdk_middleware_stack.MiddlewareStack();
    }
    resolveMiddleware(clientStack, configuration) {
        const { handler } = configuration;
        const stack = clientStack.concat(this.middlewareStack);
        const handlerExecutionContext = {
            logger: {},
            model: this.model
        };
        return stack.resolve(handler(handlerExecutionContext), handlerExecutionContext);
    }
}
exports.DeleteResourceDataSyncCommand = DeleteResourceDataSyncCommand;
//# sourceMappingURL=DeleteResourceDataSyncCommand.js.map