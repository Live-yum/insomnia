"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const __aws_sdk_middleware_stack = require("@aws-sdk/middleware-stack");
const DescribeInstancePatchStates_1 = require("../model/operations/DescribeInstancePatchStates");
class DescribeInstancePatchStatesCommand {
    constructor(input) {
        this.input = input;
        this.model = DescribeInstancePatchStates_1.DescribeInstancePatchStates;
        this.middlewareStack = new __aws_sdk_middleware_stack.MiddlewareStack();
    }
    resolveMiddleware(clientStack, configuration) {
        const { handler } = configuration;
        const stack = clientStack.concat(this.middlewareStack);
        const handlerExecutionContext = {
            logger: {},
            model: this.model
        };
        return stack.resolve(handler(handlerExecutionContext), handlerExecutionContext);
    }
}
exports.DescribeInstancePatchStatesCommand = DescribeInstancePatchStatesCommand;
//# sourceMappingURL=DescribeInstancePatchStatesCommand.js.map