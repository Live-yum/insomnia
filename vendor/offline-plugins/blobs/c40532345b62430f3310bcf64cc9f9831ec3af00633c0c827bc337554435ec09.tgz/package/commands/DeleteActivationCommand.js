"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const __aws_sdk_middleware_stack = require("@aws-sdk/middleware-stack");
const DeleteActivation_1 = require("../model/operations/DeleteActivation");
class DeleteActivationCommand {
    constructor(input) {
        this.input = input;
        this.model = DeleteActivation_1.DeleteActivation;
        this.middlewareStack = new __aws_sdk_middleware_stack.MiddlewareStack();
    }
    resolveMiddleware(clientStack, configuration) {
        const { handler } = configuration;
        const stack = clientStack.concat(this.middlewareStack);
        const handlerExecutionContext = {
            logger: {},
            model: this.model
        };
        return stack.resolve(handler(handlerExecutionContext), handlerExecutionContext);
    }
}
exports.DeleteActivationCommand = DeleteActivationCommand;
//# sourceMappingURL=DeleteActivationCommand.js.map