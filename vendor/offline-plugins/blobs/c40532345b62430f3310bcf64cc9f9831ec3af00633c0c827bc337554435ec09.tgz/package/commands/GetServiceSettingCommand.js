"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const __aws_sdk_middleware_stack = require("@aws-sdk/middleware-stack");
const GetServiceSetting_1 = require("../model/operations/GetServiceSetting");
class GetServiceSettingCommand {
    constructor(input) {
        this.input = input;
        this.model = GetServiceSetting_1.GetServiceSetting;
        this.middlewareStack = new __aws_sdk_middleware_stack.MiddlewareStack();
    }
    resolveMiddleware(clientStack, configuration) {
        const { handler } = configuration;
        const stack = clientStack.concat(this.middlewareStack);
        const handlerExecutionContext = {
            logger: {},
            model: this.model
        };
        return stack.resolve(handler(handlerExecutionContext), handlerExecutionContext);
    }
}
exports.GetServiceSettingCommand = GetServiceSettingCommand;
//# sourceMappingURL=GetServiceSettingCommand.js.map