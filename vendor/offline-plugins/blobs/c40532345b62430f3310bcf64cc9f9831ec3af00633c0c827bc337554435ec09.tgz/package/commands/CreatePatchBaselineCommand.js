"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const __aws_sdk_middleware_stack = require("@aws-sdk/middleware-stack");
const CreatePatchBaseline_1 = require("../model/operations/CreatePatchBaseline");
class CreatePatchBaselineCommand {
    constructor(input) {
        this.input = input;
        this.model = CreatePatchBaseline_1.CreatePatchBaseline;
        this.middlewareStack = new __aws_sdk_middleware_stack.MiddlewareStack();
    }
    resolveMiddleware(clientStack, configuration) {
        const { handler } = configuration;
        const stack = clientStack.concat(this.middlewareStack);
        const handlerExecutionContext = {
            logger: {},
            model: this.model
        };
        return stack.resolve(handler(handlerExecutionContext), handlerExecutionContext);
    }
}
exports.CreatePatchBaselineCommand = CreatePatchBaselineCommand;
//# sourceMappingURL=CreatePatchBaselineCommand.js.map