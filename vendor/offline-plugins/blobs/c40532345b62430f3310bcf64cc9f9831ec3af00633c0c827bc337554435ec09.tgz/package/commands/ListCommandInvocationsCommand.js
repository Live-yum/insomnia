"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const __aws_sdk_middleware_stack = require("@aws-sdk/middleware-stack");
const ListCommandInvocations_1 = require("../model/operations/ListCommandInvocations");
class ListCommandInvocationsCommand {
    constructor(input) {
        this.input = input;
        this.model = ListCommandInvocations_1.ListCommandInvocations;
        this.middlewareStack = new __aws_sdk_middleware_stack.MiddlewareStack();
    }
    resolveMiddleware(clientStack, configuration) {
        const { handler } = configuration;
        const stack = clientStack.concat(this.middlewareStack);
        const handlerExecutionContext = {
            logger: {},
            model: this.model
        };
        return stack.resolve(handler(handlerExecutionContext), handlerExecutionContext);
    }
}
exports.ListCommandInvocationsCommand = ListCommandInvocationsCommand;
//# sourceMappingURL=ListCommandInvocationsCommand.js.map