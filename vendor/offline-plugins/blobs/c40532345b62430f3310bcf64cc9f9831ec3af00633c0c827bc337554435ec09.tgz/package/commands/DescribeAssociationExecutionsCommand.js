"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const __aws_sdk_middleware_stack = require("@aws-sdk/middleware-stack");
const DescribeAssociationExecutions_1 = require("../model/operations/DescribeAssociationExecutions");
class DescribeAssociationExecutionsCommand {
    constructor(input) {
        this.input = input;
        this.model = DescribeAssociationExecutions_1.DescribeAssociationExecutions;
        this.middlewareStack = new __aws_sdk_middleware_stack.MiddlewareStack();
    }
    resolveMiddleware(clientStack, configuration) {
        const { handler } = configuration;
        const stack = clientStack.concat(this.middlewareStack);
        const handlerExecutionContext = {
            logger: {},
            model: this.model
        };
        return stack.resolve(handler(handlerExecutionContext), handlerExecutionContext);
    }
}
exports.DescribeAssociationExecutionsCommand = DescribeAssociationExecutionsCommand;
//# sourceMappingURL=DescribeAssociationExecutionsCommand.js.map