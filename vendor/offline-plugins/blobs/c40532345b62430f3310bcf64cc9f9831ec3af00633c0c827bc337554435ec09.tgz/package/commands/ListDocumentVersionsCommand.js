"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const __aws_sdk_middleware_stack = require("@aws-sdk/middleware-stack");
const ListDocumentVersions_1 = require("../model/operations/ListDocumentVersions");
class ListDocumentVersionsCommand {
    constructor(input) {
        this.input = input;
        this.model = ListDocumentVersions_1.ListDocumentVersions;
        this.middlewareStack = new __aws_sdk_middleware_stack.MiddlewareStack();
    }
    resolveMiddleware(clientStack, configuration) {
        const { handler } = configuration;
        const stack = clientStack.concat(this.middlewareStack);
        const handlerExecutionContext = {
            logger: {},
            model: this.model
        };
        return stack.resolve(handler(handlerExecutionContext), handlerExecutionContext);
    }
}
exports.ListDocumentVersionsCommand = ListDocumentVersionsCommand;
//# sourceMappingURL=ListDocumentVersionsCommand.js.map