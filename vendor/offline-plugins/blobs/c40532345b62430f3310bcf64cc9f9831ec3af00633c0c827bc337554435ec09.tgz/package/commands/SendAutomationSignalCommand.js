"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const __aws_sdk_middleware_stack = require("@aws-sdk/middleware-stack");
const SendAutomationSignal_1 = require("../model/operations/SendAutomationSignal");
class SendAutomationSignalCommand {
    constructor(input) {
        this.input = input;
        this.model = SendAutomationSignal_1.SendAutomationSignal;
        this.middlewareStack = new __aws_sdk_middleware_stack.MiddlewareStack();
    }
    resolveMiddleware(clientStack, configuration) {
        const { handler } = configuration;
        const stack = clientStack.concat(this.middlewareStack);
        const handlerExecutionContext = {
            logger: {},
            model: this.model
        };
        return stack.resolve(handler(handlerExecutionContext), handlerExecutionContext);
    }
}
exports.SendAutomationSignalCommand = SendAutomationSignalCommand;
//# sourceMappingURL=SendAutomationSignalCommand.js.map