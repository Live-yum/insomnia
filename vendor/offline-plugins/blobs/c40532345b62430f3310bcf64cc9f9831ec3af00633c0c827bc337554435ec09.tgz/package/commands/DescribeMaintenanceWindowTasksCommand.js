"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const __aws_sdk_middleware_stack = require("@aws-sdk/middleware-stack");
const DescribeMaintenanceWindowTasks_1 = require("../model/operations/DescribeMaintenanceWindowTasks");
class DescribeMaintenanceWindowTasksCommand {
    constructor(input) {
        this.input = input;
        this.model = DescribeMaintenanceWindowTasks_1.DescribeMaintenanceWindowTasks;
        this.middlewareStack = new __aws_sdk_middleware_stack.MiddlewareStack();
    }
    resolveMiddleware(clientStack, configuration) {
        const { handler } = configuration;
        const stack = clientStack.concat(this.middlewareStack);
        const handlerExecutionContext = {
            logger: {},
            model: this.model
        };
        return stack.resolve(handler(handlerExecutionContext), handlerExecutionContext);
    }
}
exports.DescribeMaintenanceWindowTasksCommand = DescribeMaintenanceWindowTasksCommand;
//# sourceMappingURL=DescribeMaintenanceWindowTasksCommand.js.map