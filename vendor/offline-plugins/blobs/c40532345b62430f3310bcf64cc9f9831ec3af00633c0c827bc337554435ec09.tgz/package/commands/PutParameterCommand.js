"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const __aws_sdk_middleware_stack = require("@aws-sdk/middleware-stack");
const PutParameter_1 = require("../model/operations/PutParameter");
class PutParameterCommand {
    constructor(input) {
        this.input = input;
        this.model = PutParameter_1.PutParameter;
        this.middlewareStack = new __aws_sdk_middleware_stack.MiddlewareStack();
    }
    resolveMiddleware(clientStack, configuration) {
        const { handler } = configuration;
        const stack = clientStack.concat(this.middlewareStack);
        const handlerExecutionContext = {
            logger: {},
            model: this.model
        };
        return stack.resolve(handler(handlerExecutionContext), handlerExecutionContext);
    }
}
exports.PutParameterCommand = PutParameterCommand;
//# sourceMappingURL=PutParameterCommand.js.map