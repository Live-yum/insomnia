"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const __aws_sdk_middleware_stack = require("@aws-sdk/middleware-stack");
const CancelMaintenanceWindowExecution_1 = require("../model/operations/CancelMaintenanceWindowExecution");
class CancelMaintenanceWindowExecutionCommand {
    constructor(input) {
        this.input = input;
        this.model = CancelMaintenanceWindowExecution_1.CancelMaintenanceWindowExecution;
        this.middlewareStack = new __aws_sdk_middleware_stack.MiddlewareStack();
    }
    resolveMiddleware(clientStack, configuration) {
        const { handler } = configuration;
        const stack = clientStack.concat(this.middlewareStack);
        const handlerExecutionContext = {
            logger: {},
            model: this.model
        };
        return stack.resolve(handler(handlerExecutionContext), handlerExecutionContext);
    }
}
exports.CancelMaintenanceWindowExecutionCommand = CancelMaintenanceWindowExecutionCommand;
//# sourceMappingURL=CancelMaintenanceWindowExecutionCommand.js.map