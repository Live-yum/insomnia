"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const __aws_sdk_middleware_stack = require("@aws-sdk/middleware-stack");
const UpdateAssociation_1 = require("../model/operations/UpdateAssociation");
class UpdateAssociationCommand {
    constructor(input) {
        this.input = input;
        this.model = UpdateAssociation_1.UpdateAssociation;
        this.middlewareStack = new __aws_sdk_middleware_stack.MiddlewareStack();
    }
    resolveMiddleware(clientStack, configuration) {
        const { handler } = configuration;
        const stack = clientStack.concat(this.middlewareStack);
        const handlerExecutionContext = {
            logger: {},
            model: this.model
        };
        return stack.resolve(handler(handlerExecutionContext), handlerExecutionContext);
    }
}
exports.UpdateAssociationCommand = UpdateAssociationCommand;
//# sourceMappingURL=UpdateAssociationCommand.js.map