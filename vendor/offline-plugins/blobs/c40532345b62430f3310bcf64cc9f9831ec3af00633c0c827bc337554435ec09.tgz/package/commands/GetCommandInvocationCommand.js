"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const __aws_sdk_middleware_stack = require("@aws-sdk/middleware-stack");
const GetCommandInvocation_1 = require("../model/operations/GetCommandInvocation");
class GetCommandInvocationCommand {
    constructor(input) {
        this.input = input;
        this.model = GetCommandInvocation_1.GetCommandInvocation;
        this.middlewareStack = new __aws_sdk_middleware_stack.MiddlewareStack();
    }
    resolveMiddleware(clientStack, configuration) {
        const { handler } = configuration;
        const stack = clientStack.concat(this.middlewareStack);
        const handlerExecutionContext = {
            logger: {},
            model: this.model
        };
        return stack.resolve(handler(handlerExecutionContext), handlerExecutionContext);
    }
}
exports.GetCommandInvocationCommand = GetCommandInvocationCommand;
//# sourceMappingURL=GetCommandInvocationCommand.js.map