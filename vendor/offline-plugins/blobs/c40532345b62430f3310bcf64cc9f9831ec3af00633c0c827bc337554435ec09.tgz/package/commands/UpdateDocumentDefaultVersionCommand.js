"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const __aws_sdk_middleware_stack = require("@aws-sdk/middleware-stack");
const UpdateDocumentDefaultVersion_1 = require("../model/operations/UpdateDocumentDefaultVersion");
class UpdateDocumentDefaultVersionCommand {
    constructor(input) {
        this.input = input;
        this.model = UpdateDocumentDefaultVersion_1.UpdateDocumentDefaultVersion;
        this.middlewareStack = new __aws_sdk_middleware_stack.MiddlewareStack();
    }
    resolveMiddleware(clientStack, configuration) {
        const { handler } = configuration;
        const stack = clientStack.concat(this.middlewareStack);
        const handlerExecutionContext = {
            logger: {},
            model: this.model
        };
        return stack.resolve(handler(handlerExecutionContext), handlerExecutionContext);
    }
}
exports.UpdateDocumentDefaultVersionCommand = UpdateDocumentDefaultVersionCommand;
//# sourceMappingURL=UpdateDocumentDefaultVersionCommand.js.map