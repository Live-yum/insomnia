"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const __aws_sdk_middleware_stack = require("@aws-sdk/middleware-stack");
const DescribeAutomationStepExecutions_1 = require("../model/operations/DescribeAutomationStepExecutions");
class DescribeAutomationStepExecutionsCommand {
    constructor(input) {
        this.input = input;
        this.model = DescribeAutomationStepExecutions_1.DescribeAutomationStepExecutions;
        this.middlewareStack = new __aws_sdk_middleware_stack.MiddlewareStack();
    }
    resolveMiddleware(clientStack, configuration) {
        const { handler } = configuration;
        const stack = clientStack.concat(this.middlewareStack);
        const handlerExecutionContext = {
            logger: {},
            model: this.model
        };
        return stack.resolve(handler(handlerExecutionContext), handlerExecutionContext);
    }
}
exports.DescribeAutomationStepExecutionsCommand = DescribeAutomationStepExecutionsCommand;
//# sourceMappingURL=DescribeAutomationStepExecutionsCommand.js.map