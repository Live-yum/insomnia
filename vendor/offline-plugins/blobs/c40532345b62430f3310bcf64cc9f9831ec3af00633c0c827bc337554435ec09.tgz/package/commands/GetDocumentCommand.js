"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const __aws_sdk_middleware_stack = require("@aws-sdk/middleware-stack");
const GetDocument_1 = require("../model/operations/GetDocument");
class GetDocumentCommand {
    constructor(input) {
        this.input = input;
        this.model = GetDocument_1.GetDocument;
        this.middlewareStack = new __aws_sdk_middleware_stack.MiddlewareStack();
    }
    resolveMiddleware(clientStack, configuration) {
        const { handler } = configuration;
        const stack = clientStack.concat(this.middlewareStack);
        const handlerExecutionContext = {
            logger: {},
            model: this.model
        };
        return stack.resolve(handler(handlerExecutionContext), handlerExecutionContext);
    }
}
exports.GetDocumentCommand = GetDocumentCommand;
//# sourceMappingURL=GetDocumentCommand.js.map