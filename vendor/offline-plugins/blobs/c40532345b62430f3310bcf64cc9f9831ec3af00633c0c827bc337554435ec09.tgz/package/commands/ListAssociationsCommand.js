"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const __aws_sdk_middleware_stack = require("@aws-sdk/middleware-stack");
const ListAssociations_1 = require("../model/operations/ListAssociations");
class ListAssociationsCommand {
    constructor(input) {
        this.input = input;
        this.model = ListAssociations_1.ListAssociations;
        this.middlewareStack = new __aws_sdk_middleware_stack.MiddlewareStack();
    }
    resolveMiddleware(clientStack, configuration) {
        const { handler } = configuration;
        const stack = clientStack.concat(this.middlewareStack);
        const handlerExecutionContext = {
            logger: {},
            model: this.model
        };
        return stack.resolve(handler(handlerExecutionContext), handlerExecutionContext);
    }
}
exports.ListAssociationsCommand = ListAssociationsCommand;
//# sourceMappingURL=ListAssociationsCommand.js.map