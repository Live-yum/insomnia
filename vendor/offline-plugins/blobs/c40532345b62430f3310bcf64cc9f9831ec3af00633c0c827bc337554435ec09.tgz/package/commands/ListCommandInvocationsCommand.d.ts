/// <reference types="node" />
import * as __aws_sdk_middleware_stack from "@aws-sdk/middleware-stack";
import * as __aws_sdk_types from "@aws-sdk/types";
import * as _stream from "stream";
import { InputTypesUnion } from "../types/InputTypesUnion";
import { OutputTypesUnion } from "../types/OutputTypesUnion";
import { ListCommandInvocationsInput } from "../types/ListCommandInvocationsInput";
import { ListCommandInvocationsOutput } from "../types/ListCommandInvocationsOutput";
import { SSMResolvedConfiguration } from "../SSMConfiguration";
export * from "../types/ListCommandInvocationsInput";
export * from "../types/ListCommandInvocationsOutput";
export * from "../types/ListCommandInvocationsExceptionsUnion";
export declare class ListCommandInvocationsCommand implements __aws_sdk_types.Command<InputTypesUnion, ListCommandInvocationsInput, OutputTypesUnion, ListCommandInvocationsOutput, SSMResolvedConfiguration, _stream.Readable> {
    readonly input: ListCommandInvocationsInput;
    readonly model: __aws_sdk_types.OperationModel;
    readonly middlewareStack: __aws_sdk_middleware_stack.MiddlewareStack<ListCommandInvocationsInput, ListCommandInvocationsOutput, _stream.Readable>;
    constructor(input: ListCommandInvocationsInput);
    resolveMiddleware(clientStack: __aws_sdk_middleware_stack.MiddlewareStack<InputTypesUnion, OutputTypesUnion, _stream.Readable>, configuration: SSMResolvedConfiguration): __aws_sdk_types.Handler<ListCommandInvocationsInput, ListCommandInvocationsOutput>;
}
