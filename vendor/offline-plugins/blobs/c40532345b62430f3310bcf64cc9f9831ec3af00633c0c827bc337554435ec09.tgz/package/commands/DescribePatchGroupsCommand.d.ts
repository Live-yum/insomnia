/// <reference types="node" />
import * as __aws_sdk_middleware_stack from "@aws-sdk/middleware-stack";
import * as __aws_sdk_types from "@aws-sdk/types";
import * as _stream from "stream";
import { InputTypesUnion } from "../types/InputTypesUnion";
import { OutputTypesUnion } from "../types/OutputTypesUnion";
import { DescribePatchGroupsInput } from "../types/DescribePatchGroupsInput";
import { DescribePatchGroupsOutput } from "../types/DescribePatchGroupsOutput";
import { SSMResolvedConfiguration } from "../SSMConfiguration";
export * from "../types/DescribePatchGroupsInput";
export * from "../types/DescribePatchGroupsOutput";
export * from "../types/DescribePatchGroupsExceptionsUnion";
export declare class DescribePatchGroupsCommand implements __aws_sdk_types.Command<InputTypesUnion, DescribePatchGroupsInput, OutputTypesUnion, DescribePatchGroupsOutput, SSMResolvedConfiguration, _stream.Readable> {
    readonly input: DescribePatchGroupsInput;
    readonly model: __aws_sdk_types.OperationModel;
    readonly middlewareStack: __aws_sdk_middleware_stack.MiddlewareStack<DescribePatchGroupsInput, DescribePatchGroupsOutput, _stream.Readable>;
    constructor(input: DescribePatchGroupsInput);
    resolveMiddleware(clientStack: __aws_sdk_middleware_stack.MiddlewareStack<InputTypesUnion, OutputTypesUnion, _stream.Readable>, configuration: SSMResolvedConfiguration): __aws_sdk_types.Handler<DescribePatchGroupsInput, DescribePatchGroupsOutput>;
}
