/// <reference types="node" />
import * as __aws_sdk_middleware_stack from "@aws-sdk/middleware-stack";
import * as __aws_sdk_types from "@aws-sdk/types";
import * as _stream from "stream";
import { InputTypesUnion } from "../types/InputTypesUnion";
import { OutputTypesUnion } from "../types/OutputTypesUnion";
import { GetParameterInput } from "../types/GetParameterInput";
import { GetParameterOutput } from "../types/GetParameterOutput";
import { SSMResolvedConfiguration } from "../SSMConfiguration";
export * from "../types/GetParameterInput";
export * from "../types/GetParameterOutput";
export * from "../types/GetParameterExceptionsUnion";
export declare class GetParameterCommand implements __aws_sdk_types.Command<InputTypesUnion, GetParameterInput, OutputTypesUnion, GetParameterOutput, SSMResolvedConfiguration, _stream.Readable> {
    readonly input: GetParameterInput;
    readonly model: __aws_sdk_types.OperationModel;
    readonly middlewareStack: __aws_sdk_middleware_stack.MiddlewareStack<GetParameterInput, GetParameterOutput, _stream.Readable>;
    constructor(input: GetParameterInput);
    resolveMiddleware(clientStack: __aws_sdk_middleware_stack.MiddlewareStack<InputTypesUnion, OutputTypesUnion, _stream.Readable>, configuration: SSMResolvedConfiguration): __aws_sdk_types.Handler<GetParameterInput, GetParameterOutput>;
}
