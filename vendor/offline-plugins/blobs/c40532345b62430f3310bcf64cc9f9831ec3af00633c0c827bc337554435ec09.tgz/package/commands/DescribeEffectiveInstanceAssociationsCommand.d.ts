/// <reference types="node" />
import * as __aws_sdk_middleware_stack from "@aws-sdk/middleware-stack";
import * as __aws_sdk_types from "@aws-sdk/types";
import * as _stream from "stream";
import { InputTypesUnion } from "../types/InputTypesUnion";
import { OutputTypesUnion } from "../types/OutputTypesUnion";
import { DescribeEffectiveInstanceAssociationsInput } from "../types/DescribeEffectiveInstanceAssociationsInput";
import { DescribeEffectiveInstanceAssociationsOutput } from "../types/DescribeEffectiveInstanceAssociationsOutput";
import { SSMResolvedConfiguration } from "../SSMConfiguration";
export * from "../types/DescribeEffectiveInstanceAssociationsInput";
export * from "../types/DescribeEffectiveInstanceAssociationsOutput";
export * from "../types/DescribeEffectiveInstanceAssociationsExceptionsUnion";
export declare class DescribeEffectiveInstanceAssociationsCommand implements __aws_sdk_types.Command<InputTypesUnion, DescribeEffectiveInstanceAssociationsInput, OutputTypesUnion, DescribeEffectiveInstanceAssociationsOutput, SSMResolvedConfiguration, _stream.Readable> {
    readonly input: DescribeEffectiveInstanceAssociationsInput;
    readonly model: __aws_sdk_types.OperationModel;
    readonly middlewareStack: __aws_sdk_middleware_stack.MiddlewareStack<DescribeEffectiveInstanceAssociationsInput, DescribeEffectiveInstanceAssociationsOutput, _stream.Readable>;
    constructor(input: DescribeEffectiveInstanceAssociationsInput);
    resolveMiddleware(clientStack: __aws_sdk_middleware_stack.MiddlewareStack<InputTypesUnion, OutputTypesUnion, _stream.Readable>, configuration: SSMResolvedConfiguration): __aws_sdk_types.Handler<DescribeEffectiveInstanceAssociationsInput, DescribeEffectiveInstanceAssociationsOutput>;
}
