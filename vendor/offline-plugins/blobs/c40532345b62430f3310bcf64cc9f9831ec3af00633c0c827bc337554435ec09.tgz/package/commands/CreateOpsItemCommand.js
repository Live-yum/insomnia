"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const __aws_sdk_middleware_stack = require("@aws-sdk/middleware-stack");
const CreateOpsItem_1 = require("../model/operations/CreateOpsItem");
class CreateOpsItemCommand {
    constructor(input) {
        this.input = input;
        this.model = CreateOpsItem_1.CreateOpsItem;
        this.middlewareStack = new __aws_sdk_middleware_stack.MiddlewareStack();
    }
    resolveMiddleware(clientStack, configuration) {
        const { handler } = configuration;
        const stack = clientStack.concat(this.middlewareStack);
        const handlerExecutionContext = {
            logger: {},
            model: this.model
        };
        return stack.resolve(handler(handlerExecutionContext), handlerExecutionContext);
    }
}
exports.CreateOpsItemCommand = CreateOpsItemCommand;
//# sourceMappingURL=CreateOpsItemCommand.js.map