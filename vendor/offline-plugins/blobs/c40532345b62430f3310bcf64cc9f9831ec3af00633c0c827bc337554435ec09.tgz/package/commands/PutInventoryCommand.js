"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const __aws_sdk_middleware_stack = require("@aws-sdk/middleware-stack");
const PutInventory_1 = require("../model/operations/PutInventory");
class PutInventoryCommand {
    constructor(input) {
        this.input = input;
        this.model = PutInventory_1.PutInventory;
        this.middlewareStack = new __aws_sdk_middleware_stack.MiddlewareStack();
    }
    resolveMiddleware(clientStack, configuration) {
        const { handler } = configuration;
        const stack = clientStack.concat(this.middlewareStack);
        const handlerExecutionContext = {
            logger: {},
            model: this.model
        };
        return stack.resolve(handler(handlerExecutionContext), handlerExecutionContext);
    }
}
exports.PutInventoryCommand = PutInventoryCommand;
//# sourceMappingURL=PutInventoryCommand.js.map