/// <reference types="node" />
import * as __aws_sdk_middleware_stack from "@aws-sdk/middleware-stack";
import * as __aws_sdk_types from "@aws-sdk/types";
import * as _stream from "stream";
import { InputTypesUnion } from "../types/InputTypesUnion";
import { OutputTypesUnion } from "../types/OutputTypesUnion";
import { DeregisterTaskFromMaintenanceWindowInput } from "../types/DeregisterTaskFromMaintenanceWindowInput";
import { DeregisterTaskFromMaintenanceWindowOutput } from "../types/DeregisterTaskFromMaintenanceWindowOutput";
import { SSMResolvedConfiguration } from "../SSMConfiguration";
export * from "../types/DeregisterTaskFromMaintenanceWindowInput";
export * from "../types/DeregisterTaskFromMaintenanceWindowOutput";
export * from "../types/DeregisterTaskFromMaintenanceWindowExceptionsUnion";
export declare class DeregisterTaskFromMaintenanceWindowCommand implements __aws_sdk_types.Command<InputTypesUnion, DeregisterTaskFromMaintenanceWindowInput, OutputTypesUnion, DeregisterTaskFromMaintenanceWindowOutput, SSMResolvedConfiguration, _stream.Readable> {
    readonly input: DeregisterTaskFromMaintenanceWindowInput;
    readonly model: __aws_sdk_types.OperationModel;
    readonly middlewareStack: __aws_sdk_middleware_stack.MiddlewareStack<DeregisterTaskFromMaintenanceWindowInput, DeregisterTaskFromMaintenanceWindowOutput, _stream.Readable>;
    constructor(input: DeregisterTaskFromMaintenanceWindowInput);
    resolveMiddleware(clientStack: __aws_sdk_middleware_stack.MiddlewareStack<InputTypesUnion, OutputTypesUnion, _stream.Readable>, configuration: SSMResolvedConfiguration): __aws_sdk_types.Handler<DeregisterTaskFromMaintenanceWindowInput, DeregisterTaskFromMaintenanceWindowOutput>;
}
