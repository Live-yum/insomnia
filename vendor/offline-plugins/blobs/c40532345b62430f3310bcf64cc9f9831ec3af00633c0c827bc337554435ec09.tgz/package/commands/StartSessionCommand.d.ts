/// <reference types="node" />
import * as __aws_sdk_middleware_stack from "@aws-sdk/middleware-stack";
import * as __aws_sdk_types from "@aws-sdk/types";
import * as _stream from "stream";
import { InputTypesUnion } from "../types/InputTypesUnion";
import { OutputTypesUnion } from "../types/OutputTypesUnion";
import { StartSessionInput } from "../types/StartSessionInput";
import { StartSessionOutput } from "../types/StartSessionOutput";
import { SSMResolvedConfiguration } from "../SSMConfiguration";
export * from "../types/StartSessionInput";
export * from "../types/StartSessionOutput";
export * from "../types/StartSessionExceptionsUnion";
export declare class StartSessionCommand implements __aws_sdk_types.Command<InputTypesUnion, StartSessionInput, OutputTypesUnion, StartSessionOutput, SSMResolvedConfiguration, _stream.Readable> {
    readonly input: StartSessionInput;
    readonly model: __aws_sdk_types.OperationModel;
    readonly middlewareStack: __aws_sdk_middleware_stack.MiddlewareStack<StartSessionInput, StartSessionOutput, _stream.Readable>;
    constructor(input: StartSessionInput);
    resolveMiddleware(clientStack: __aws_sdk_middleware_stack.MiddlewareStack<InputTypesUnion, OutputTypesUnion, _stream.Readable>, configuration: SSMResolvedConfiguration): __aws_sdk_types.Handler<StartSessionInput, StartSessionOutput>;
}
