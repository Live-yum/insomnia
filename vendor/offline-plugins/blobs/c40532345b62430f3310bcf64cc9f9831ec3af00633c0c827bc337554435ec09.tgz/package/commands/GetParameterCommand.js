"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const __aws_sdk_middleware_stack = require("@aws-sdk/middleware-stack");
const GetParameter_1 = require("../model/operations/GetParameter");
class GetParameterCommand {
    constructor(input) {
        this.input = input;
        this.model = GetParameter_1.GetParameter;
        this.middlewareStack = new __aws_sdk_middleware_stack.MiddlewareStack();
    }
    resolveMiddleware(clientStack, configuration) {
        const { handler } = configuration;
        const stack = clientStack.concat(this.middlewareStack);
        const handlerExecutionContext = {
            logger: {},
            model: this.model
        };
        return stack.resolve(handler(handlerExecutionContext), handlerExecutionContext);
    }
}
exports.GetParameterCommand = GetParameterCommand;
//# sourceMappingURL=GetParameterCommand.js.map