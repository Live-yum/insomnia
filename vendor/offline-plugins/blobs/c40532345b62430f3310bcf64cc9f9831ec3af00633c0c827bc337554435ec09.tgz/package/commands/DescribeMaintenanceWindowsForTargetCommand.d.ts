/// <reference types="node" />
import * as __aws_sdk_middleware_stack from "@aws-sdk/middleware-stack";
import * as __aws_sdk_types from "@aws-sdk/types";
import * as _stream from "stream";
import { InputTypesUnion } from "../types/InputTypesUnion";
import { OutputTypesUnion } from "../types/OutputTypesUnion";
import { DescribeMaintenanceWindowsForTargetInput } from "../types/DescribeMaintenanceWindowsForTargetInput";
import { DescribeMaintenanceWindowsForTargetOutput } from "../types/DescribeMaintenanceWindowsForTargetOutput";
import { SSMResolvedConfiguration } from "../SSMConfiguration";
export * from "../types/DescribeMaintenanceWindowsForTargetInput";
export * from "../types/DescribeMaintenanceWindowsForTargetOutput";
export * from "../types/DescribeMaintenanceWindowsForTargetExceptionsUnion";
export declare class DescribeMaintenanceWindowsForTargetCommand implements __aws_sdk_types.Command<InputTypesUnion, DescribeMaintenanceWindowsForTargetInput, OutputTypesUnion, DescribeMaintenanceWindowsForTargetOutput, SSMResolvedConfiguration, _stream.Readable> {
    readonly input: DescribeMaintenanceWindowsForTargetInput;
    readonly model: __aws_sdk_types.OperationModel;
    readonly middlewareStack: __aws_sdk_middleware_stack.MiddlewareStack<DescribeMaintenanceWindowsForTargetInput, DescribeMaintenanceWindowsForTargetOutput, _stream.Readable>;
    constructor(input: DescribeMaintenanceWindowsForTargetInput);
    resolveMiddleware(clientStack: __aws_sdk_middleware_stack.MiddlewareStack<InputTypesUnion, OutputTypesUnion, _stream.Readable>, configuration: SSMResolvedConfiguration): __aws_sdk_types.Handler<DescribeMaintenanceWindowsForTargetInput, DescribeMaintenanceWindowsForTargetOutput>;
}
