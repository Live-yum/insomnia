"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const __aws_sdk_middleware_stack = require("@aws-sdk/middleware-stack");
const GetMaintenanceWindow_1 = require("../model/operations/GetMaintenanceWindow");
class GetMaintenanceWindowCommand {
    constructor(input) {
        this.input = input;
        this.model = GetMaintenanceWindow_1.GetMaintenanceWindow;
        this.middlewareStack = new __aws_sdk_middleware_stack.MiddlewareStack();
    }
    resolveMiddleware(clientStack, configuration) {
        const { handler } = configuration;
        const stack = clientStack.concat(this.middlewareStack);
        const handlerExecutionContext = {
            logger: {},
            model: this.model
        };
        return stack.resolve(handler(handlerExecutionContext), handlerExecutionContext);
    }
}
exports.GetMaintenanceWindowCommand = GetMaintenanceWindowCommand;
//# sourceMappingURL=GetMaintenanceWindowCommand.js.map