"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const __aws_sdk_middleware_stack = require("@aws-sdk/middleware-stack");
const DescribeMaintenanceWindowExecutionTasks_1 = require("../model/operations/DescribeMaintenanceWindowExecutionTasks");
class DescribeMaintenanceWindowExecutionTasksCommand {
    constructor(input) {
        this.input = input;
        this.model = DescribeMaintenanceWindowExecutionTasks_1.DescribeMaintenanceWindowExecutionTasks;
        this.middlewareStack = new __aws_sdk_middleware_stack.MiddlewareStack();
    }
    resolveMiddleware(clientStack, configuration) {
        const { handler } = configuration;
        const stack = clientStack.concat(this.middlewareStack);
        const handlerExecutionContext = {
            logger: {},
            model: this.model
        };
        return stack.resolve(handler(handlerExecutionContext), handlerExecutionContext);
    }
}
exports.DescribeMaintenanceWindowExecutionTasksCommand = DescribeMaintenanceWindowExecutionTasksCommand;
//# sourceMappingURL=DescribeMaintenanceWindowExecutionTasksCommand.js.map