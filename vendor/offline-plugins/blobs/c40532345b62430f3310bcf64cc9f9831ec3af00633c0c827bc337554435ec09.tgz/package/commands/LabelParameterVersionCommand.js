"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const __aws_sdk_middleware_stack = require("@aws-sdk/middleware-stack");
const LabelParameterVersion_1 = require("../model/operations/LabelParameterVersion");
class LabelParameterVersionCommand {
    constructor(input) {
        this.input = input;
        this.model = LabelParameterVersion_1.LabelParameterVersion;
        this.middlewareStack = new __aws_sdk_middleware_stack.MiddlewareStack();
    }
    resolveMiddleware(clientStack, configuration) {
        const { handler } = configuration;
        const stack = clientStack.concat(this.middlewareStack);
        const handlerExecutionContext = {
            logger: {},
            model: this.model
        };
        return stack.resolve(handler(handlerExecutionContext), handlerExecutionContext);
    }
}
exports.LabelParameterVersionCommand = LabelParameterVersionCommand;
//# sourceMappingURL=LabelParameterVersionCommand.js.map