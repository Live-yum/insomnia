/// <reference types="node" />
import * as __aws_sdk_middleware_stack from "@aws-sdk/middleware-stack";
import * as __aws_sdk_types from "@aws-sdk/types";
import * as _stream from "stream";
import { InputTypesUnion } from "../types/InputTypesUnion";
import { OutputTypesUnion } from "../types/OutputTypesUnion";
import { ListComplianceItemsInput } from "../types/ListComplianceItemsInput";
import { ListComplianceItemsOutput } from "../types/ListComplianceItemsOutput";
import { SSMResolvedConfiguration } from "../SSMConfiguration";
export * from "../types/ListComplianceItemsInput";
export * from "../types/ListComplianceItemsOutput";
export * from "../types/ListComplianceItemsExceptionsUnion";
export declare class ListComplianceItemsCommand implements __aws_sdk_types.Command<InputTypesUnion, ListComplianceItemsInput, OutputTypesUnion, ListComplianceItemsOutput, SSMResolvedConfiguration, _stream.Readable> {
    readonly input: ListComplianceItemsInput;
    readonly model: __aws_sdk_types.OperationModel;
    readonly middlewareStack: __aws_sdk_middleware_stack.MiddlewareStack<ListComplianceItemsInput, ListComplianceItemsOutput, _stream.Readable>;
    constructor(input: ListComplianceItemsInput);
    resolveMiddleware(clientStack: __aws_sdk_middleware_stack.MiddlewareStack<InputTypesUnion, OutputTypesUnion, _stream.Readable>, configuration: SSMResolvedConfiguration): __aws_sdk_types.Handler<ListComplianceItemsInput, ListComplianceItemsOutput>;
}
