/// <reference types="node" />
import * as __aws_sdk_middleware_stack from "@aws-sdk/middleware-stack";
import * as __aws_sdk_types from "@aws-sdk/types";
import * as _stream from "stream";
import { InputTypesUnion } from "../types/InputTypesUnion";
import { OutputTypesUnion } from "../types/OutputTypesUnion";
import { DescribeDocumentPermissionInput } from "../types/DescribeDocumentPermissionInput";
import { DescribeDocumentPermissionOutput } from "../types/DescribeDocumentPermissionOutput";
import { SSMResolvedConfiguration } from "../SSMConfiguration";
export * from "../types/DescribeDocumentPermissionInput";
export * from "../types/DescribeDocumentPermissionOutput";
export * from "../types/DescribeDocumentPermissionExceptionsUnion";
export declare class DescribeDocumentPermissionCommand implements __aws_sdk_types.Command<InputTypesUnion, DescribeDocumentPermissionInput, OutputTypesUnion, DescribeDocumentPermissionOutput, SSMResolvedConfiguration, _stream.Readable> {
    readonly input: DescribeDocumentPermissionInput;
    readonly model: __aws_sdk_types.OperationModel;
    readonly middlewareStack: __aws_sdk_middleware_stack.MiddlewareStack<DescribeDocumentPermissionInput, DescribeDocumentPermissionOutput, _stream.Readable>;
    constructor(input: DescribeDocumentPermissionInput);
    resolveMiddleware(clientStack: __aws_sdk_middleware_stack.MiddlewareStack<InputTypesUnion, OutputTypesUnion, _stream.Readable>, configuration: SSMResolvedConfiguration): __aws_sdk_types.Handler<DescribeDocumentPermissionInput, DescribeDocumentPermissionOutput>;
}
