/// <reference types="node" />
import * as __aws_sdk_middleware_stack from "@aws-sdk/middleware-stack";
import * as __aws_sdk_types from "@aws-sdk/types";
import * as _stream from "stream";
import { InputTypesUnion } from "../types/InputTypesUnion";
import { OutputTypesUnion } from "../types/OutputTypesUnion";
import { CancelMaintenanceWindowExecutionInput } from "../types/CancelMaintenanceWindowExecutionInput";
import { CancelMaintenanceWindowExecutionOutput } from "../types/CancelMaintenanceWindowExecutionOutput";
import { SSMResolvedConfiguration } from "../SSMConfiguration";
export * from "../types/CancelMaintenanceWindowExecutionInput";
export * from "../types/CancelMaintenanceWindowExecutionOutput";
export * from "../types/CancelMaintenanceWindowExecutionExceptionsUnion";
export declare class CancelMaintenanceWindowExecutionCommand implements __aws_sdk_types.Command<InputTypesUnion, CancelMaintenanceWindowExecutionInput, OutputTypesUnion, CancelMaintenanceWindowExecutionOutput, SSMResolvedConfiguration, _stream.Readable> {
    readonly input: CancelMaintenanceWindowExecutionInput;
    readonly model: __aws_sdk_types.OperationModel;
    readonly middlewareStack: __aws_sdk_middleware_stack.MiddlewareStack<CancelMaintenanceWindowExecutionInput, CancelMaintenanceWindowExecutionOutput, _stream.Readable>;
    constructor(input: CancelMaintenanceWindowExecutionInput);
    resolveMiddleware(clientStack: __aws_sdk_middleware_stack.MiddlewareStack<InputTypesUnion, OutputTypesUnion, _stream.Readable>, configuration: SSMResolvedConfiguration): __aws_sdk_types.Handler<CancelMaintenanceWindowExecutionInput, CancelMaintenanceWindowExecutionOutput>;
}
