"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const __aws_sdk_middleware_stack = require("@aws-sdk/middleware-stack");
const DescribeDocumentPermission_1 = require("../model/operations/DescribeDocumentPermission");
class DescribeDocumentPermissionCommand {
    constructor(input) {
        this.input = input;
        this.model = DescribeDocumentPermission_1.DescribeDocumentPermission;
        this.middlewareStack = new __aws_sdk_middleware_stack.MiddlewareStack();
    }
    resolveMiddleware(clientStack, configuration) {
        const { handler } = configuration;
        const stack = clientStack.concat(this.middlewareStack);
        const handlerExecutionContext = {
            logger: {},
            model: this.model
        };
        return stack.resolve(handler(handlerExecutionContext), handlerExecutionContext);
    }
}
exports.DescribeDocumentPermissionCommand = DescribeDocumentPermissionCommand;
//# sourceMappingURL=DescribeDocumentPermissionCommand.js.map