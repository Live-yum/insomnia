"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const __aws_sdk_middleware_stack = require("@aws-sdk/middleware-stack");
const DescribeEffectivePatchesForPatchBaseline_1 = require("../model/operations/DescribeEffectivePatchesForPatchBaseline");
class DescribeEffectivePatchesForPatchBaselineCommand {
    constructor(input) {
        this.input = input;
        this.model = DescribeEffectivePatchesForPatchBaseline_1.DescribeEffectivePatchesForPatchBaseline;
        this.middlewareStack = new __aws_sdk_middleware_stack.MiddlewareStack();
    }
    resolveMiddleware(clientStack, configuration) {
        const { handler } = configuration;
        const stack = clientStack.concat(this.middlewareStack);
        const handlerExecutionContext = {
            logger: {},
            model: this.model
        };
        return stack.resolve(handler(handlerExecutionContext), handlerExecutionContext);
    }
}
exports.DescribeEffectivePatchesForPatchBaselineCommand = DescribeEffectivePatchesForPatchBaselineCommand;
//# sourceMappingURL=DescribeEffectivePatchesForPatchBaselineCommand.js.map