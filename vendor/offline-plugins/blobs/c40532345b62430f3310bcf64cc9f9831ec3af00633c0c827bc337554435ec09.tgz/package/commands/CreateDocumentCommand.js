"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const __aws_sdk_middleware_stack = require("@aws-sdk/middleware-stack");
const CreateDocument_1 = require("../model/operations/CreateDocument");
class CreateDocumentCommand {
    constructor(input) {
        this.input = input;
        this.model = CreateDocument_1.CreateDocument;
        this.middlewareStack = new __aws_sdk_middleware_stack.MiddlewareStack();
    }
    resolveMiddleware(clientStack, configuration) {
        const { handler } = configuration;
        const stack = clientStack.concat(this.middlewareStack);
        const handlerExecutionContext = {
            logger: {},
            model: this.model
        };
        return stack.resolve(handler(handlerExecutionContext), handlerExecutionContext);
    }
}
exports.CreateDocumentCommand = CreateDocumentCommand;
//# sourceMappingURL=CreateDocumentCommand.js.map