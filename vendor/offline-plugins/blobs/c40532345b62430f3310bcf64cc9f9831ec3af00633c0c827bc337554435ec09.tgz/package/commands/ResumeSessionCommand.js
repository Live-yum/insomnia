"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const __aws_sdk_middleware_stack = require("@aws-sdk/middleware-stack");
const ResumeSession_1 = require("../model/operations/ResumeSession");
class ResumeSessionCommand {
    constructor(input) {
        this.input = input;
        this.model = ResumeSession_1.ResumeSession;
        this.middlewareStack = new __aws_sdk_middleware_stack.MiddlewareStack();
    }
    resolveMiddleware(clientStack, configuration) {
        const { handler } = configuration;
        const stack = clientStack.concat(this.middlewareStack);
        const handlerExecutionContext = {
            logger: {},
            model: this.model
        };
        return stack.resolve(handler(handlerExecutionContext), handlerExecutionContext);
    }
}
exports.ResumeSessionCommand = ResumeSessionCommand;
//# sourceMappingURL=ResumeSessionCommand.js.map