/// <reference types="node" />
import * as __aws_sdk_middleware_stack from "@aws-sdk/middleware-stack";
import * as __aws_sdk_types from "@aws-sdk/types";
import * as _stream from "stream";
import { InputTypesUnion } from "../types/InputTypesUnion";
import { OutputTypesUnion } from "../types/OutputTypesUnion";
import { DeleteAssociationInput } from "../types/DeleteAssociationInput";
import { DeleteAssociationOutput } from "../types/DeleteAssociationOutput";
import { SSMResolvedConfiguration } from "../SSMConfiguration";
export * from "../types/DeleteAssociationInput";
export * from "../types/DeleteAssociationOutput";
export * from "../types/DeleteAssociationExceptionsUnion";
export declare class DeleteAssociationCommand implements __aws_sdk_types.Command<InputTypesUnion, DeleteAssociationInput, OutputTypesUnion, DeleteAssociationOutput, SSMResolvedConfiguration, _stream.Readable> {
    readonly input: DeleteAssociationInput;
    readonly model: __aws_sdk_types.OperationModel;
    readonly middlewareStack: __aws_sdk_middleware_stack.MiddlewareStack<DeleteAssociationInput, DeleteAssociationOutput, _stream.Readable>;
    constructor(input: DeleteAssociationInput);
    resolveMiddleware(clientStack: __aws_sdk_middleware_stack.MiddlewareStack<InputTypesUnion, OutputTypesUnion, _stream.Readable>, configuration: SSMResolvedConfiguration): __aws_sdk_types.Handler<DeleteAssociationInput, DeleteAssociationOutput>;
}
