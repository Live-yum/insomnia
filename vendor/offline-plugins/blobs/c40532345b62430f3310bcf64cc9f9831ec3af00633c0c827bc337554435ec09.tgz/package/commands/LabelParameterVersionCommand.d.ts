/// <reference types="node" />
import * as __aws_sdk_middleware_stack from "@aws-sdk/middleware-stack";
import * as __aws_sdk_types from "@aws-sdk/types";
import * as _stream from "stream";
import { InputTypesUnion } from "../types/InputTypesUnion";
import { OutputTypesUnion } from "../types/OutputTypesUnion";
import { LabelParameterVersionInput } from "../types/LabelParameterVersionInput";
import { LabelParameterVersionOutput } from "../types/LabelParameterVersionOutput";
import { SSMResolvedConfiguration } from "../SSMConfiguration";
export * from "../types/LabelParameterVersionInput";
export * from "../types/LabelParameterVersionOutput";
export * from "../types/LabelParameterVersionExceptionsUnion";
export declare class LabelParameterVersionCommand implements __aws_sdk_types.Command<InputTypesUnion, LabelParameterVersionInput, OutputTypesUnion, LabelParameterVersionOutput, SSMResolvedConfiguration, _stream.Readable> {
    readonly input: LabelParameterVersionInput;
    readonly model: __aws_sdk_types.OperationModel;
    readonly middlewareStack: __aws_sdk_middleware_stack.MiddlewareStack<LabelParameterVersionInput, LabelParameterVersionOutput, _stream.Readable>;
    constructor(input: LabelParameterVersionInput);
    resolveMiddleware(clientStack: __aws_sdk_middleware_stack.MiddlewareStack<InputTypesUnion, OutputTypesUnion, _stream.Readable>, configuration: SSMResolvedConfiguration): __aws_sdk_types.Handler<LabelParameterVersionInput, LabelParameterVersionOutput>;
}
