"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const __aws_sdk_middleware_stack = require("@aws-sdk/middleware-stack");
const CreateResourceDataSync_1 = require("../model/operations/CreateResourceDataSync");
class CreateResourceDataSyncCommand {
    constructor(input) {
        this.input = input;
        this.model = CreateResourceDataSync_1.CreateResourceDataSync;
        this.middlewareStack = new __aws_sdk_middleware_stack.MiddlewareStack();
    }
    resolveMiddleware(clientStack, configuration) {
        const { handler } = configuration;
        const stack = clientStack.concat(this.middlewareStack);
        const handlerExecutionContext = {
            logger: {},
            model: this.model
        };
        return stack.resolve(handler(handlerExecutionContext), handlerExecutionContext);
    }
}
exports.CreateResourceDataSyncCommand = CreateResourceDataSyncCommand;
//# sourceMappingURL=CreateResourceDataSyncCommand.js.map