"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const __aws_sdk_middleware_stack = require("@aws-sdk/middleware-stack");
const ResetServiceSetting_1 = require("../model/operations/ResetServiceSetting");
class ResetServiceSettingCommand {
    constructor(input) {
        this.input = input;
        this.model = ResetServiceSetting_1.ResetServiceSetting;
        this.middlewareStack = new __aws_sdk_middleware_stack.MiddlewareStack();
    }
    resolveMiddleware(clientStack, configuration) {
        const { handler } = configuration;
        const stack = clientStack.concat(this.middlewareStack);
        const handlerExecutionContext = {
            logger: {},
            model: this.model
        };
        return stack.resolve(handler(handlerExecutionContext), handlerExecutionContext);
    }
}
exports.ResetServiceSettingCommand = ResetServiceSettingCommand;
//# sourceMappingURL=ResetServiceSettingCommand.js.map