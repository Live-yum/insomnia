"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const __aws_sdk_middleware_stack = require("@aws-sdk/middleware-stack");
const ListResourceDataSync_1 = require("../model/operations/ListResourceDataSync");
class ListResourceDataSyncCommand {
    constructor(input) {
        this.input = input;
        this.model = ListResourceDataSync_1.ListResourceDataSync;
        this.middlewareStack = new __aws_sdk_middleware_stack.MiddlewareStack();
    }
    resolveMiddleware(clientStack, configuration) {
        const { handler } = configuration;
        const stack = clientStack.concat(this.middlewareStack);
        const handlerExecutionContext = {
            logger: {},
            model: this.model
        };
        return stack.resolve(handler(handlerExecutionContext), handlerExecutionContext);
    }
}
exports.ListResourceDataSyncCommand = ListResourceDataSyncCommand;
//# sourceMappingURL=ListResourceDataSyncCommand.js.map