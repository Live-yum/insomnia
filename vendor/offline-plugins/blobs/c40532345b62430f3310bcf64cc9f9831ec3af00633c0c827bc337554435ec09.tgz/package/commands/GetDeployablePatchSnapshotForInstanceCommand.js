"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const __aws_sdk_middleware_stack = require("@aws-sdk/middleware-stack");
const GetDeployablePatchSnapshotForInstance_1 = require("../model/operations/GetDeployablePatchSnapshotForInstance");
class GetDeployablePatchSnapshotForInstanceCommand {
    constructor(input) {
        this.input = input;
        this.model = GetDeployablePatchSnapshotForInstance_1.GetDeployablePatchSnapshotForInstance;
        this.middlewareStack = new __aws_sdk_middleware_stack.MiddlewareStack();
    }
    resolveMiddleware(clientStack, configuration) {
        const { handler } = configuration;
        const stack = clientStack.concat(this.middlewareStack);
        const handlerExecutionContext = {
            logger: {},
            model: this.model
        };
        return stack.resolve(handler(handlerExecutionContext), handlerExecutionContext);
    }
}
exports.GetDeployablePatchSnapshotForInstanceCommand = GetDeployablePatchSnapshotForInstanceCommand;
//# sourceMappingURL=GetDeployablePatchSnapshotForInstanceCommand.js.map