/// <reference types="node" />
import * as __aws_sdk_middleware_stack from "@aws-sdk/middleware-stack";
import * as __aws_sdk_types from "@aws-sdk/types";
import * as _stream from "stream";
import { InputTypesUnion } from "../types/InputTypesUnion";
import { OutputTypesUnion } from "../types/OutputTypesUnion";
import { DeleteMaintenanceWindowInput } from "../types/DeleteMaintenanceWindowInput";
import { DeleteMaintenanceWindowOutput } from "../types/DeleteMaintenanceWindowOutput";
import { SSMResolvedConfiguration } from "../SSMConfiguration";
export * from "../types/DeleteMaintenanceWindowInput";
export * from "../types/DeleteMaintenanceWindowOutput";
export * from "../types/DeleteMaintenanceWindowExceptionsUnion";
export declare class DeleteMaintenanceWindowCommand implements __aws_sdk_types.Command<InputTypesUnion, DeleteMaintenanceWindowInput, OutputTypesUnion, DeleteMaintenanceWindowOutput, SSMResolvedConfiguration, _stream.Readable> {
    readonly input: DeleteMaintenanceWindowInput;
    readonly model: __aws_sdk_types.OperationModel;
    readonly middlewareStack: __aws_sdk_middleware_stack.MiddlewareStack<DeleteMaintenanceWindowInput, DeleteMaintenanceWindowOutput, _stream.Readable>;
    constructor(input: DeleteMaintenanceWindowInput);
    resolveMiddleware(clientStack: __aws_sdk_middleware_stack.MiddlewareStack<InputTypesUnion, OutputTypesUnion, _stream.Readable>, configuration: SSMResolvedConfiguration): __aws_sdk_types.Handler<DeleteMaintenanceWindowInput, DeleteMaintenanceWindowOutput>;
}
