"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const __aws_sdk_middleware_stack = require("@aws-sdk/middleware-stack");
const DescribeInstancePatches_1 = require("../model/operations/DescribeInstancePatches");
class DescribeInstancePatchesCommand {
    constructor(input) {
        this.input = input;
        this.model = DescribeInstancePatches_1.DescribeInstancePatches;
        this.middlewareStack = new __aws_sdk_middleware_stack.MiddlewareStack();
    }
    resolveMiddleware(clientStack, configuration) {
        const { handler } = configuration;
        const stack = clientStack.concat(this.middlewareStack);
        const handlerExecutionContext = {
            logger: {},
            model: this.model
        };
        return stack.resolve(handler(handlerExecutionContext), handlerExecutionContext);
    }
}
exports.DescribeInstancePatchesCommand = DescribeInstancePatchesCommand;
//# sourceMappingURL=DescribeInstancePatchesCommand.js.map