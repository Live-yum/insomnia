"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const __aws_sdk_middleware_stack = require("@aws-sdk/middleware-stack");
const PutComplianceItems_1 = require("../model/operations/PutComplianceItems");
class PutComplianceItemsCommand {
    constructor(input) {
        this.input = input;
        this.model = PutComplianceItems_1.PutComplianceItems;
        this.middlewareStack = new __aws_sdk_middleware_stack.MiddlewareStack();
    }
    resolveMiddleware(clientStack, configuration) {
        const { handler } = configuration;
        const stack = clientStack.concat(this.middlewareStack);
        const handlerExecutionContext = {
            logger: {},
            model: this.model
        };
        return stack.resolve(handler(handlerExecutionContext), handlerExecutionContext);
    }
}
exports.PutComplianceItemsCommand = PutComplianceItemsCommand;
//# sourceMappingURL=PutComplianceItemsCommand.js.map