/// <reference types="node" />
import * as __aws_sdk_middleware_stack from "@aws-sdk/middleware-stack";
import * as __aws_sdk_types from "@aws-sdk/types";
import * as _stream from "stream";
import { InputTypesUnion } from "../types/InputTypesUnion";
import { OutputTypesUnion } from "../types/OutputTypesUnion";
import { CreateOpsItemInput } from "../types/CreateOpsItemInput";
import { CreateOpsItemOutput } from "../types/CreateOpsItemOutput";
import { SSMResolvedConfiguration } from "../SSMConfiguration";
export * from "../types/CreateOpsItemInput";
export * from "../types/CreateOpsItemOutput";
export * from "../types/CreateOpsItemExceptionsUnion";
export declare class CreateOpsItemCommand implements __aws_sdk_types.Command<InputTypesUnion, CreateOpsItemInput, OutputTypesUnion, CreateOpsItemOutput, SSMResolvedConfiguration, _stream.Readable> {
    readonly input: CreateOpsItemInput;
    readonly model: __aws_sdk_types.OperationModel;
    readonly middlewareStack: __aws_sdk_middleware_stack.MiddlewareStack<CreateOpsItemInput, CreateOpsItemOutput, _stream.Readable>;
    constructor(input: CreateOpsItemInput);
    resolveMiddleware(clientStack: __aws_sdk_middleware_stack.MiddlewareStack<InputTypesUnion, OutputTypesUnion, _stream.Readable>, configuration: SSMResolvedConfiguration): __aws_sdk_types.Handler<CreateOpsItemInput, CreateOpsItemOutput>;
}
