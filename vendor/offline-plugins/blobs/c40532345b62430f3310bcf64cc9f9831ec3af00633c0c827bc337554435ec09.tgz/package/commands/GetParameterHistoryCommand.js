"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const __aws_sdk_middleware_stack = require("@aws-sdk/middleware-stack");
const GetParameterHistory_1 = require("../model/operations/GetParameterHistory");
class GetParameterHistoryCommand {
    constructor(input) {
        this.input = input;
        this.model = GetParameterHistory_1.GetParameterHistory;
        this.middlewareStack = new __aws_sdk_middleware_stack.MiddlewareStack();
    }
    resolveMiddleware(clientStack, configuration) {
        const { handler } = configuration;
        const stack = clientStack.concat(this.middlewareStack);
        const handlerExecutionContext = {
            logger: {},
            model: this.model
        };
        return stack.resolve(handler(handlerExecutionContext), handlerExecutionContext);
    }
}
exports.GetParameterHistoryCommand = GetParameterHistoryCommand;
//# sourceMappingURL=GetParameterHistoryCommand.js.map