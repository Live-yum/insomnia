/// <reference types="node" />
import * as __aws_sdk_middleware_stack from "@aws-sdk/middleware-stack";
import * as __aws_sdk_types from "@aws-sdk/types";
import * as _stream from "stream";
import { InputTypesUnion } from "../types/InputTypesUnion";
import { OutputTypesUnion } from "../types/OutputTypesUnion";
import { CreateActivationInput } from "../types/CreateActivationInput";
import { CreateActivationOutput } from "../types/CreateActivationOutput";
import { SSMResolvedConfiguration } from "../SSMConfiguration";
export * from "../types/CreateActivationInput";
export * from "../types/CreateActivationOutput";
export * from "../types/CreateActivationExceptionsUnion";
export declare class CreateActivationCommand implements __aws_sdk_types.Command<InputTypesUnion, CreateActivationInput, OutputTypesUnion, CreateActivationOutput, SSMResolvedConfiguration, _stream.Readable> {
    readonly input: CreateActivationInput;
    readonly model: __aws_sdk_types.OperationModel;
    readonly middlewareStack: __aws_sdk_middleware_stack.MiddlewareStack<CreateActivationInput, CreateActivationOutput, _stream.Readable>;
    constructor(input: CreateActivationInput);
    resolveMiddleware(clientStack: __aws_sdk_middleware_stack.MiddlewareStack<InputTypesUnion, OutputTypesUnion, _stream.Readable>, configuration: SSMResolvedConfiguration): __aws_sdk_types.Handler<CreateActivationInput, CreateActivationOutput>;
}
