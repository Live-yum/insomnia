/// <reference types="node" />
import * as __aws_sdk_middleware_stack from "@aws-sdk/middleware-stack";
import * as __aws_sdk_types from "@aws-sdk/types";
import * as _stream from "stream";
import { InputTypesUnion } from "../types/InputTypesUnion";
import { OutputTypesUnion } from "../types/OutputTypesUnion";
import { GetOpsSummaryInput } from "../types/GetOpsSummaryInput";
import { GetOpsSummaryOutput } from "../types/GetOpsSummaryOutput";
import { SSMResolvedConfiguration } from "../SSMConfiguration";
export * from "../types/GetOpsSummaryInput";
export * from "../types/GetOpsSummaryOutput";
export * from "../types/GetOpsSummaryExceptionsUnion";
export declare class GetOpsSummaryCommand implements __aws_sdk_types.Command<InputTypesUnion, GetOpsSummaryInput, OutputTypesUnion, GetOpsSummaryOutput, SSMResolvedConfiguration, _stream.Readable> {
    readonly input: GetOpsSummaryInput;
    readonly model: __aws_sdk_types.OperationModel;
    readonly middlewareStack: __aws_sdk_middleware_stack.MiddlewareStack<GetOpsSummaryInput, GetOpsSummaryOutput, _stream.Readable>;
    constructor(input: GetOpsSummaryInput);
    resolveMiddleware(clientStack: __aws_sdk_middleware_stack.MiddlewareStack<InputTypesUnion, OutputTypesUnion, _stream.Readable>, configuration: SSMResolvedConfiguration): __aws_sdk_types.Handler<GetOpsSummaryInput, GetOpsSummaryOutput>;
}
