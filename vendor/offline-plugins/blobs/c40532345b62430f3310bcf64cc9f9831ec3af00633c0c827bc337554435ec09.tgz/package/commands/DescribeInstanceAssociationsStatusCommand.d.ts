/// <reference types="node" />
import * as __aws_sdk_middleware_stack from "@aws-sdk/middleware-stack";
import * as __aws_sdk_types from "@aws-sdk/types";
import * as _stream from "stream";
import { InputTypesUnion } from "../types/InputTypesUnion";
import { OutputTypesUnion } from "../types/OutputTypesUnion";
import { DescribeInstanceAssociationsStatusInput } from "../types/DescribeInstanceAssociationsStatusInput";
import { DescribeInstanceAssociationsStatusOutput } from "../types/DescribeInstanceAssociationsStatusOutput";
import { SSMResolvedConfiguration } from "../SSMConfiguration";
export * from "../types/DescribeInstanceAssociationsStatusInput";
export * from "../types/DescribeInstanceAssociationsStatusOutput";
export * from "../types/DescribeInstanceAssociationsStatusExceptionsUnion";
export declare class DescribeInstanceAssociationsStatusCommand implements __aws_sdk_types.Command<InputTypesUnion, DescribeInstanceAssociationsStatusInput, OutputTypesUnion, DescribeInstanceAssociationsStatusOutput, SSMResolvedConfiguration, _stream.Readable> {
    readonly input: DescribeInstanceAssociationsStatusInput;
    readonly model: __aws_sdk_types.OperationModel;
    readonly middlewareStack: __aws_sdk_middleware_stack.MiddlewareStack<DescribeInstanceAssociationsStatusInput, DescribeInstanceAssociationsStatusOutput, _stream.Readable>;
    constructor(input: DescribeInstanceAssociationsStatusInput);
    resolveMiddleware(clientStack: __aws_sdk_middleware_stack.MiddlewareStack<InputTypesUnion, OutputTypesUnion, _stream.Readable>, configuration: SSMResolvedConfiguration): __aws_sdk_types.Handler<DescribeInstanceAssociationsStatusInput, DescribeInstanceAssociationsStatusOutput>;
}
