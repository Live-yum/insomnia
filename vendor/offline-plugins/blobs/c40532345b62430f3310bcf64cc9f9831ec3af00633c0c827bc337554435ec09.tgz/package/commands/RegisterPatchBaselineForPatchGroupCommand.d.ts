/// <reference types="node" />
import * as __aws_sdk_middleware_stack from "@aws-sdk/middleware-stack";
import * as __aws_sdk_types from "@aws-sdk/types";
import * as _stream from "stream";
import { InputTypesUnion } from "../types/InputTypesUnion";
import { OutputTypesUnion } from "../types/OutputTypesUnion";
import { RegisterPatchBaselineForPatchGroupInput } from "../types/RegisterPatchBaselineForPatchGroupInput";
import { RegisterPatchBaselineForPatchGroupOutput } from "../types/RegisterPatchBaselineForPatchGroupOutput";
import { SSMResolvedConfiguration } from "../SSMConfiguration";
export * from "../types/RegisterPatchBaselineForPatchGroupInput";
export * from "../types/RegisterPatchBaselineForPatchGroupOutput";
export * from "../types/RegisterPatchBaselineForPatchGroupExceptionsUnion";
export declare class RegisterPatchBaselineForPatchGroupCommand implements __aws_sdk_types.Command<InputTypesUnion, RegisterPatchBaselineForPatchGroupInput, OutputTypesUnion, RegisterPatchBaselineForPatchGroupOutput, SSMResolvedConfiguration, _stream.Readable> {
    readonly input: RegisterPatchBaselineForPatchGroupInput;
    readonly model: __aws_sdk_types.OperationModel;
    readonly middlewareStack: __aws_sdk_middleware_stack.MiddlewareStack<RegisterPatchBaselineForPatchGroupInput, RegisterPatchBaselineForPatchGroupOutput, _stream.Readable>;
    constructor(input: RegisterPatchBaselineForPatchGroupInput);
    resolveMiddleware(clientStack: __aws_sdk_middleware_stack.MiddlewareStack<InputTypesUnion, OutputTypesUnion, _stream.Readable>, configuration: SSMResolvedConfiguration): __aws_sdk_types.Handler<RegisterPatchBaselineForPatchGroupInput, RegisterPatchBaselineForPatchGroupOutput>;
}
