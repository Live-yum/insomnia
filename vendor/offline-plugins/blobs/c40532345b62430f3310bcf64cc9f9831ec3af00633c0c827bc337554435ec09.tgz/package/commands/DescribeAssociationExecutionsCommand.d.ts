/// <reference types="node" />
import * as __aws_sdk_middleware_stack from "@aws-sdk/middleware-stack";
import * as __aws_sdk_types from "@aws-sdk/types";
import * as _stream from "stream";
import { InputTypesUnion } from "../types/InputTypesUnion";
import { OutputTypesUnion } from "../types/OutputTypesUnion";
import { DescribeAssociationExecutionsInput } from "../types/DescribeAssociationExecutionsInput";
import { DescribeAssociationExecutionsOutput } from "../types/DescribeAssociationExecutionsOutput";
import { SSMResolvedConfiguration } from "../SSMConfiguration";
export * from "../types/DescribeAssociationExecutionsInput";
export * from "../types/DescribeAssociationExecutionsOutput";
export * from "../types/DescribeAssociationExecutionsExceptionsUnion";
export declare class DescribeAssociationExecutionsCommand implements __aws_sdk_types.Command<InputTypesUnion, DescribeAssociationExecutionsInput, OutputTypesUnion, DescribeAssociationExecutionsOutput, SSMResolvedConfiguration, _stream.Readable> {
    readonly input: DescribeAssociationExecutionsInput;
    readonly model: __aws_sdk_types.OperationModel;
    readonly middlewareStack: __aws_sdk_middleware_stack.MiddlewareStack<DescribeAssociationExecutionsInput, DescribeAssociationExecutionsOutput, _stream.Readable>;
    constructor(input: DescribeAssociationExecutionsInput);
    resolveMiddleware(clientStack: __aws_sdk_middleware_stack.MiddlewareStack<InputTypesUnion, OutputTypesUnion, _stream.Readable>, configuration: SSMResolvedConfiguration): __aws_sdk_types.Handler<DescribeAssociationExecutionsInput, DescribeAssociationExecutionsOutput>;
}
