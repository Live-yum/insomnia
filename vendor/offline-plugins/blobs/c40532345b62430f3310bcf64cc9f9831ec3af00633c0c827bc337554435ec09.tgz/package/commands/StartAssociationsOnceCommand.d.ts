/// <reference types="node" />
import * as __aws_sdk_middleware_stack from "@aws-sdk/middleware-stack";
import * as __aws_sdk_types from "@aws-sdk/types";
import * as _stream from "stream";
import { InputTypesUnion } from "../types/InputTypesUnion";
import { OutputTypesUnion } from "../types/OutputTypesUnion";
import { StartAssociationsOnceInput } from "../types/StartAssociationsOnceInput";
import { StartAssociationsOnceOutput } from "../types/StartAssociationsOnceOutput";
import { SSMResolvedConfiguration } from "../SSMConfiguration";
export * from "../types/StartAssociationsOnceInput";
export * from "../types/StartAssociationsOnceOutput";
export * from "../types/StartAssociationsOnceExceptionsUnion";
export declare class StartAssociationsOnceCommand implements __aws_sdk_types.Command<InputTypesUnion, StartAssociationsOnceInput, OutputTypesUnion, StartAssociationsOnceOutput, SSMResolvedConfiguration, _stream.Readable> {
    readonly input: StartAssociationsOnceInput;
    readonly model: __aws_sdk_types.OperationModel;
    readonly middlewareStack: __aws_sdk_middleware_stack.MiddlewareStack<StartAssociationsOnceInput, StartAssociationsOnceOutput, _stream.Readable>;
    constructor(input: StartAssociationsOnceInput);
    resolveMiddleware(clientStack: __aws_sdk_middleware_stack.MiddlewareStack<InputTypesUnion, OutputTypesUnion, _stream.Readable>, configuration: SSMResolvedConfiguration): __aws_sdk_types.Handler<StartAssociationsOnceInput, StartAssociationsOnceOutput>;
}
