/// <reference types="node" />
import * as __aws_sdk_middleware_stack from "@aws-sdk/middleware-stack";
import * as __aws_sdk_types from "@aws-sdk/types";
import * as _stream from "stream";
import { InputTypesUnion } from "../types/InputTypesUnion";
import { OutputTypesUnion } from "../types/OutputTypesUnion";
import { ListComplianceSummariesInput } from "../types/ListComplianceSummariesInput";
import { ListComplianceSummariesOutput } from "../types/ListComplianceSummariesOutput";
import { SSMResolvedConfiguration } from "../SSMConfiguration";
export * from "../types/ListComplianceSummariesInput";
export * from "../types/ListComplianceSummariesOutput";
export * from "../types/ListComplianceSummariesExceptionsUnion";
export declare class ListComplianceSummariesCommand implements __aws_sdk_types.Command<InputTypesUnion, ListComplianceSummariesInput, OutputTypesUnion, ListComplianceSummariesOutput, SSMResolvedConfiguration, _stream.Readable> {
    readonly input: ListComplianceSummariesInput;
    readonly model: __aws_sdk_types.OperationModel;
    readonly middlewareStack: __aws_sdk_middleware_stack.MiddlewareStack<ListComplianceSummariesInput, ListComplianceSummariesOutput, _stream.Readable>;
    constructor(input: ListComplianceSummariesInput);
    resolveMiddleware(clientStack: __aws_sdk_middleware_stack.MiddlewareStack<InputTypesUnion, OutputTypesUnion, _stream.Readable>, configuration: SSMResolvedConfiguration): __aws_sdk_types.Handler<ListComplianceSummariesInput, ListComplianceSummariesOutput>;
}
