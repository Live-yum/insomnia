/// <reference types="node" />
import * as __aws_sdk_middleware_stack from "@aws-sdk/middleware-stack";
import * as __aws_sdk_types from "@aws-sdk/types";
import * as _stream from "stream";
import { InputTypesUnion } from "../types/InputTypesUnion";
import { OutputTypesUnion } from "../types/OutputTypesUnion";
import { DescribeMaintenanceWindowScheduleInput } from "../types/DescribeMaintenanceWindowScheduleInput";
import { DescribeMaintenanceWindowScheduleOutput } from "../types/DescribeMaintenanceWindowScheduleOutput";
import { SSMResolvedConfiguration } from "../SSMConfiguration";
export * from "../types/DescribeMaintenanceWindowScheduleInput";
export * from "../types/DescribeMaintenanceWindowScheduleOutput";
export * from "../types/DescribeMaintenanceWindowScheduleExceptionsUnion";
export declare class DescribeMaintenanceWindowScheduleCommand implements __aws_sdk_types.Command<InputTypesUnion, DescribeMaintenanceWindowScheduleInput, OutputTypesUnion, DescribeMaintenanceWindowScheduleOutput, SSMResolvedConfiguration, _stream.Readable> {
    readonly input: DescribeMaintenanceWindowScheduleInput;
    readonly model: __aws_sdk_types.OperationModel;
    readonly middlewareStack: __aws_sdk_middleware_stack.MiddlewareStack<DescribeMaintenanceWindowScheduleInput, DescribeMaintenanceWindowScheduleOutput, _stream.Readable>;
    constructor(input: DescribeMaintenanceWindowScheduleInput);
    resolveMiddleware(clientStack: __aws_sdk_middleware_stack.MiddlewareStack<InputTypesUnion, OutputTypesUnion, _stream.Readable>, configuration: SSMResolvedConfiguration): __aws_sdk_types.Handler<DescribeMaintenanceWindowScheduleInput, DescribeMaintenanceWindowScheduleOutput>;
}
