"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const __aws_sdk_middleware_stack = require("@aws-sdk/middleware-stack");
const DescribeActivations_1 = require("../model/operations/DescribeActivations");
class DescribeActivationsCommand {
    constructor(input) {
        this.input = input;
        this.model = DescribeActivations_1.DescribeActivations;
        this.middlewareStack = new __aws_sdk_middleware_stack.MiddlewareStack();
    }
    resolveMiddleware(clientStack, configuration) {
        const { handler } = configuration;
        const stack = clientStack.concat(this.middlewareStack);
        const handlerExecutionContext = {
            logger: {},
            model: this.model
        };
        return stack.resolve(handler(handlerExecutionContext), handlerExecutionContext);
    }
}
exports.DescribeActivationsCommand = DescribeActivationsCommand;
//# sourceMappingURL=DescribeActivationsCommand.js.map