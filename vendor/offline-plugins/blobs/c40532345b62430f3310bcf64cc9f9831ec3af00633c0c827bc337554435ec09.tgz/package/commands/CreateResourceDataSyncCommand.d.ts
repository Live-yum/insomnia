/// <reference types="node" />
import * as __aws_sdk_middleware_stack from "@aws-sdk/middleware-stack";
import * as __aws_sdk_types from "@aws-sdk/types";
import * as _stream from "stream";
import { InputTypesUnion } from "../types/InputTypesUnion";
import { OutputTypesUnion } from "../types/OutputTypesUnion";
import { CreateResourceDataSyncInput } from "../types/CreateResourceDataSyncInput";
import { CreateResourceDataSyncOutput } from "../types/CreateResourceDataSyncOutput";
import { SSMResolvedConfiguration } from "../SSMConfiguration";
export * from "../types/CreateResourceDataSyncInput";
export * from "../types/CreateResourceDataSyncOutput";
export * from "../types/CreateResourceDataSyncExceptionsUnion";
export declare class CreateResourceDataSyncCommand implements __aws_sdk_types.Command<InputTypesUnion, CreateResourceDataSyncInput, OutputTypesUnion, CreateResourceDataSyncOutput, SSMResolvedConfiguration, _stream.Readable> {
    readonly input: CreateResourceDataSyncInput;
    readonly model: __aws_sdk_types.OperationModel;
    readonly middlewareStack: __aws_sdk_middleware_stack.MiddlewareStack<CreateResourceDataSyncInput, CreateResourceDataSyncOutput, _stream.Readable>;
    constructor(input: CreateResourceDataSyncInput);
    resolveMiddleware(clientStack: __aws_sdk_middleware_stack.MiddlewareStack<InputTypesUnion, OutputTypesUnion, _stream.Readable>, configuration: SSMResolvedConfiguration): __aws_sdk_types.Handler<CreateResourceDataSyncInput, CreateResourceDataSyncOutput>;
}
