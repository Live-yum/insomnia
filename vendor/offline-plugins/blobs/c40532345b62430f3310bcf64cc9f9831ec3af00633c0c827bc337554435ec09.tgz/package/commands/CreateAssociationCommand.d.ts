/// <reference types="node" />
import * as __aws_sdk_middleware_stack from "@aws-sdk/middleware-stack";
import * as __aws_sdk_types from "@aws-sdk/types";
import * as _stream from "stream";
import { InputTypesUnion } from "../types/InputTypesUnion";
import { OutputTypesUnion } from "../types/OutputTypesUnion";
import { CreateAssociationInput } from "../types/CreateAssociationInput";
import { CreateAssociationOutput } from "../types/CreateAssociationOutput";
import { SSMResolvedConfiguration } from "../SSMConfiguration";
export * from "../types/CreateAssociationInput";
export * from "../types/CreateAssociationOutput";
export * from "../types/CreateAssociationExceptionsUnion";
export declare class CreateAssociationCommand implements __aws_sdk_types.Command<InputTypesUnion, CreateAssociationInput, OutputTypesUnion, CreateAssociationOutput, SSMResolvedConfiguration, _stream.Readable> {
    readonly input: CreateAssociationInput;
    readonly model: __aws_sdk_types.OperationModel;
    readonly middlewareStack: __aws_sdk_middleware_stack.MiddlewareStack<CreateAssociationInput, CreateAssociationOutput, _stream.Readable>;
    constructor(input: CreateAssociationInput);
    resolveMiddleware(clientStack: __aws_sdk_middleware_stack.MiddlewareStack<InputTypesUnion, OutputTypesUnion, _stream.Readable>, configuration: SSMResolvedConfiguration): __aws_sdk_types.Handler<CreateAssociationInput, CreateAssociationOutput>;
}
