/// <reference types="node" />
import * as __aws_sdk_middleware_stack from "@aws-sdk/middleware-stack";
import * as __aws_sdk_types from "@aws-sdk/types";
import * as _stream from "stream";
import { InputTypesUnion } from "../types/InputTypesUnion";
import { OutputTypesUnion } from "../types/OutputTypesUnion";
import { UpdateMaintenanceWindowInput } from "../types/UpdateMaintenanceWindowInput";
import { UpdateMaintenanceWindowOutput } from "../types/UpdateMaintenanceWindowOutput";
import { SSMResolvedConfiguration } from "../SSMConfiguration";
export * from "../types/UpdateMaintenanceWindowInput";
export * from "../types/UpdateMaintenanceWindowOutput";
export * from "../types/UpdateMaintenanceWindowExceptionsUnion";
export declare class UpdateMaintenanceWindowCommand implements __aws_sdk_types.Command<InputTypesUnion, UpdateMaintenanceWindowInput, OutputTypesUnion, UpdateMaintenanceWindowOutput, SSMResolvedConfiguration, _stream.Readable> {
    readonly input: UpdateMaintenanceWindowInput;
    readonly model: __aws_sdk_types.OperationModel;
    readonly middlewareStack: __aws_sdk_middleware_stack.MiddlewareStack<UpdateMaintenanceWindowInput, UpdateMaintenanceWindowOutput, _stream.Readable>;
    constructor(input: UpdateMaintenanceWindowInput);
    resolveMiddleware(clientStack: __aws_sdk_middleware_stack.MiddlewareStack<InputTypesUnion, OutputTypesUnion, _stream.Readable>, configuration: SSMResolvedConfiguration): __aws_sdk_types.Handler<UpdateMaintenanceWindowInput, UpdateMaintenanceWindowOutput>;
}
