"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const __aws_sdk_middleware_stack = require("@aws-sdk/middleware-stack");
const DeleteInventory_1 = require("../model/operations/DeleteInventory");
class DeleteInventoryCommand {
    constructor(input) {
        this.input = input;
        this.model = DeleteInventory_1.DeleteInventory;
        this.middlewareStack = new __aws_sdk_middleware_stack.MiddlewareStack();
    }
    resolveMiddleware(clientStack, configuration) {
        const { handler } = configuration;
        const stack = clientStack.concat(this.middlewareStack);
        const handlerExecutionContext = {
            logger: {},
            model: this.model
        };
        return stack.resolve(handler(handlerExecutionContext), handlerExecutionContext);
    }
}
exports.DeleteInventoryCommand = DeleteInventoryCommand;
//# sourceMappingURL=DeleteInventoryCommand.js.map