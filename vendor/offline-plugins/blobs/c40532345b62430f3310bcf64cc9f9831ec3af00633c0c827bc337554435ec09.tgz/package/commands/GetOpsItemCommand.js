"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const __aws_sdk_middleware_stack = require("@aws-sdk/middleware-stack");
const GetOpsItem_1 = require("../model/operations/GetOpsItem");
class GetOpsItemCommand {
    constructor(input) {
        this.input = input;
        this.model = GetOpsItem_1.GetOpsItem;
        this.middlewareStack = new __aws_sdk_middleware_stack.MiddlewareStack();
    }
    resolveMiddleware(clientStack, configuration) {
        const { handler } = configuration;
        const stack = clientStack.concat(this.middlewareStack);
        const handlerExecutionContext = {
            logger: {},
            model: this.model
        };
        return stack.resolve(handler(handlerExecutionContext), handlerExecutionContext);
    }
}
exports.GetOpsItemCommand = GetOpsItemCommand;
//# sourceMappingURL=GetOpsItemCommand.js.map