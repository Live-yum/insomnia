/// <reference types="node" />
import * as __aws_sdk_middleware_stack from "@aws-sdk/middleware-stack";
import * as __aws_sdk_types from "@aws-sdk/types";
import * as _stream from "stream";
import { InputTypesUnion } from "../types/InputTypesUnion";
import { OutputTypesUnion } from "../types/OutputTypesUnion";
import { ListAssociationVersionsInput } from "../types/ListAssociationVersionsInput";
import { ListAssociationVersionsOutput } from "../types/ListAssociationVersionsOutput";
import { SSMResolvedConfiguration } from "../SSMConfiguration";
export * from "../types/ListAssociationVersionsInput";
export * from "../types/ListAssociationVersionsOutput";
export * from "../types/ListAssociationVersionsExceptionsUnion";
export declare class ListAssociationVersionsCommand implements __aws_sdk_types.Command<InputTypesUnion, ListAssociationVersionsInput, OutputTypesUnion, ListAssociationVersionsOutput, SSMResolvedConfiguration, _stream.Readable> {
    readonly input: ListAssociationVersionsInput;
    readonly model: __aws_sdk_types.OperationModel;
    readonly middlewareStack: __aws_sdk_middleware_stack.MiddlewareStack<ListAssociationVersionsInput, ListAssociationVersionsOutput, _stream.Readable>;
    constructor(input: ListAssociationVersionsInput);
    resolveMiddleware(clientStack: __aws_sdk_middleware_stack.MiddlewareStack<InputTypesUnion, OutputTypesUnion, _stream.Readable>, configuration: SSMResolvedConfiguration): __aws_sdk_types.Handler<ListAssociationVersionsInput, ListAssociationVersionsOutput>;
}
