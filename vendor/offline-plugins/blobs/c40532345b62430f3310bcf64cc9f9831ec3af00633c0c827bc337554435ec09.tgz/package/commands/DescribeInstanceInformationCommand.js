"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const __aws_sdk_middleware_stack = require("@aws-sdk/middleware-stack");
const DescribeInstanceInformation_1 = require("../model/operations/DescribeInstanceInformation");
class DescribeInstanceInformationCommand {
    constructor(input) {
        this.input = input;
        this.model = DescribeInstanceInformation_1.DescribeInstanceInformation;
        this.middlewareStack = new __aws_sdk_middleware_stack.MiddlewareStack();
    }
    resolveMiddleware(clientStack, configuration) {
        const { handler } = configuration;
        const stack = clientStack.concat(this.middlewareStack);
        const handlerExecutionContext = {
            logger: {},
            model: this.model
        };
        return stack.resolve(handler(handlerExecutionContext), handlerExecutionContext);
    }
}
exports.DescribeInstanceInformationCommand = DescribeInstanceInformationCommand;
//# sourceMappingURL=DescribeInstanceInformationCommand.js.map