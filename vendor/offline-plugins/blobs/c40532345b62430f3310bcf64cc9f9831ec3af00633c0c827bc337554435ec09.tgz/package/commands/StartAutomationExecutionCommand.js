"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const __aws_sdk_middleware_stack = require("@aws-sdk/middleware-stack");
const StartAutomationExecution_1 = require("../model/operations/StartAutomationExecution");
class StartAutomationExecutionCommand {
    constructor(input) {
        this.input = input;
        this.model = StartAutomationExecution_1.StartAutomationExecution;
        this.middlewareStack = new __aws_sdk_middleware_stack.MiddlewareStack();
    }
    resolveMiddleware(clientStack, configuration) {
        const { handler } = configuration;
        const stack = clientStack.concat(this.middlewareStack);
        const handlerExecutionContext = {
            logger: {},
            model: this.model
        };
        return stack.resolve(handler(handlerExecutionContext), handlerExecutionContext);
    }
}
exports.StartAutomationExecutionCommand = StartAutomationExecutionCommand;
//# sourceMappingURL=StartAutomationExecutionCommand.js.map