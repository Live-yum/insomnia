/// <reference types="node" />
import * as __aws_sdk_middleware_stack from "@aws-sdk/middleware-stack";
import * as __aws_sdk_types from "@aws-sdk/types";
import * as _stream from "stream";
import { InputTypesUnion } from "../types/InputTypesUnion";
import { OutputTypesUnion } from "../types/OutputTypesUnion";
import { DescribeSessionsInput } from "../types/DescribeSessionsInput";
import { DescribeSessionsOutput } from "../types/DescribeSessionsOutput";
import { SSMResolvedConfiguration } from "../SSMConfiguration";
export * from "../types/DescribeSessionsInput";
export * from "../types/DescribeSessionsOutput";
export * from "../types/DescribeSessionsExceptionsUnion";
export declare class DescribeSessionsCommand implements __aws_sdk_types.Command<InputTypesUnion, DescribeSessionsInput, OutputTypesUnion, DescribeSessionsOutput, SSMResolvedConfiguration, _stream.Readable> {
    readonly input: DescribeSessionsInput;
    readonly model: __aws_sdk_types.OperationModel;
    readonly middlewareStack: __aws_sdk_middleware_stack.MiddlewareStack<DescribeSessionsInput, DescribeSessionsOutput, _stream.Readable>;
    constructor(input: DescribeSessionsInput);
    resolveMiddleware(clientStack: __aws_sdk_middleware_stack.MiddlewareStack<InputTypesUnion, OutputTypesUnion, _stream.Readable>, configuration: SSMResolvedConfiguration): __aws_sdk_types.Handler<DescribeSessionsInput, DescribeSessionsOutput>;
}
