/// <reference types="node" />
import * as __aws_sdk_middleware_stack from "@aws-sdk/middleware-stack";
import * as __aws_sdk_types from "@aws-sdk/types";
import * as _stream from "stream";
import { InputTypesUnion } from "../types/InputTypesUnion";
import { OutputTypesUnion } from "../types/OutputTypesUnion";
import { DeleteDocumentInput } from "../types/DeleteDocumentInput";
import { DeleteDocumentOutput } from "../types/DeleteDocumentOutput";
import { SSMResolvedConfiguration } from "../SSMConfiguration";
export * from "../types/DeleteDocumentInput";
export * from "../types/DeleteDocumentOutput";
export * from "../types/DeleteDocumentExceptionsUnion";
export declare class DeleteDocumentCommand implements __aws_sdk_types.Command<InputTypesUnion, DeleteDocumentInput, OutputTypesUnion, DeleteDocumentOutput, SSMResolvedConfiguration, _stream.Readable> {
    readonly input: DeleteDocumentInput;
    readonly model: __aws_sdk_types.OperationModel;
    readonly middlewareStack: __aws_sdk_middleware_stack.MiddlewareStack<DeleteDocumentInput, DeleteDocumentOutput, _stream.Readable>;
    constructor(input: DeleteDocumentInput);
    resolveMiddleware(clientStack: __aws_sdk_middleware_stack.MiddlewareStack<InputTypesUnion, OutputTypesUnion, _stream.Readable>, configuration: SSMResolvedConfiguration): __aws_sdk_types.Handler<DeleteDocumentInput, DeleteDocumentOutput>;
}
