"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const __aws_sdk_middleware_stack = require("@aws-sdk/middleware-stack");
const UpdatePatchBaseline_1 = require("../model/operations/UpdatePatchBaseline");
class UpdatePatchBaselineCommand {
    constructor(input) {
        this.input = input;
        this.model = UpdatePatchBaseline_1.UpdatePatchBaseline;
        this.middlewareStack = new __aws_sdk_middleware_stack.MiddlewareStack();
    }
    resolveMiddleware(clientStack, configuration) {
        const { handler } = configuration;
        const stack = clientStack.concat(this.middlewareStack);
        const handlerExecutionContext = {
            logger: {},
            model: this.model
        };
        return stack.resolve(handler(handlerExecutionContext), handlerExecutionContext);
    }
}
exports.UpdatePatchBaselineCommand = UpdatePatchBaselineCommand;
//# sourceMappingURL=UpdatePatchBaselineCommand.js.map