"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const __aws_sdk_middleware_stack = require("@aws-sdk/middleware-stack");
const DeletePatchBaseline_1 = require("../model/operations/DeletePatchBaseline");
class DeletePatchBaselineCommand {
    constructor(input) {
        this.input = input;
        this.model = DeletePatchBaseline_1.DeletePatchBaseline;
        this.middlewareStack = new __aws_sdk_middleware_stack.MiddlewareStack();
    }
    resolveMiddleware(clientStack, configuration) {
        const { handler } = configuration;
        const stack = clientStack.concat(this.middlewareStack);
        const handlerExecutionContext = {
            logger: {},
            model: this.model
        };
        return stack.resolve(handler(handlerExecutionContext), handlerExecutionContext);
    }
}
exports.DeletePatchBaselineCommand = DeletePatchBaselineCommand;
//# sourceMappingURL=DeletePatchBaselineCommand.js.map