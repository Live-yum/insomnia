/// <reference types="node" />
import * as __aws_sdk_middleware_stack from "@aws-sdk/middleware-stack";
import * as __aws_sdk_types from "@aws-sdk/types";
import * as _stream from "stream";
import { InputTypesUnion } from "../types/InputTypesUnion";
import { OutputTypesUnion } from "../types/OutputTypesUnion";
import { RegisterTargetWithMaintenanceWindowInput } from "../types/RegisterTargetWithMaintenanceWindowInput";
import { RegisterTargetWithMaintenanceWindowOutput } from "../types/RegisterTargetWithMaintenanceWindowOutput";
import { SSMResolvedConfiguration } from "../SSMConfiguration";
export * from "../types/RegisterTargetWithMaintenanceWindowInput";
export * from "../types/RegisterTargetWithMaintenanceWindowOutput";
export * from "../types/RegisterTargetWithMaintenanceWindowExceptionsUnion";
export declare class RegisterTargetWithMaintenanceWindowCommand implements __aws_sdk_types.Command<InputTypesUnion, RegisterTargetWithMaintenanceWindowInput, OutputTypesUnion, RegisterTargetWithMaintenanceWindowOutput, SSMResolvedConfiguration, _stream.Readable> {
    readonly input: RegisterTargetWithMaintenanceWindowInput;
    readonly model: __aws_sdk_types.OperationModel;
    readonly middlewareStack: __aws_sdk_middleware_stack.MiddlewareStack<RegisterTargetWithMaintenanceWindowInput, RegisterTargetWithMaintenanceWindowOutput, _stream.Readable>;
    constructor(input: RegisterTargetWithMaintenanceWindowInput);
    resolveMiddleware(clientStack: __aws_sdk_middleware_stack.MiddlewareStack<InputTypesUnion, OutputTypesUnion, _stream.Readable>, configuration: SSMResolvedConfiguration): __aws_sdk_types.Handler<RegisterTargetWithMaintenanceWindowInput, RegisterTargetWithMaintenanceWindowOutput>;
}
