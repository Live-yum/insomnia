/// <reference types="node" />
import * as __aws_sdk_middleware_stack from "@aws-sdk/middleware-stack";
import * as __aws_sdk_types from "@aws-sdk/types";
import * as _stream from "stream";
import { InputTypesUnion } from "../types/InputTypesUnion";
import { OutputTypesUnion } from "../types/OutputTypesUnion";
import { ListDocumentsInput } from "../types/ListDocumentsInput";
import { ListDocumentsOutput } from "../types/ListDocumentsOutput";
import { SSMResolvedConfiguration } from "../SSMConfiguration";
export * from "../types/ListDocumentsInput";
export * from "../types/ListDocumentsOutput";
export * from "../types/ListDocumentsExceptionsUnion";
export declare class ListDocumentsCommand implements __aws_sdk_types.Command<InputTypesUnion, ListDocumentsInput, OutputTypesUnion, ListDocumentsOutput, SSMResolvedConfiguration, _stream.Readable> {
    readonly input: ListDocumentsInput;
    readonly model: __aws_sdk_types.OperationModel;
    readonly middlewareStack: __aws_sdk_middleware_stack.MiddlewareStack<ListDocumentsInput, ListDocumentsOutput, _stream.Readable>;
    constructor(input: ListDocumentsInput);
    resolveMiddleware(clientStack: __aws_sdk_middleware_stack.MiddlewareStack<InputTypesUnion, OutputTypesUnion, _stream.Readable>, configuration: SSMResolvedConfiguration): __aws_sdk_types.Handler<ListDocumentsInput, ListDocumentsOutput>;
}
