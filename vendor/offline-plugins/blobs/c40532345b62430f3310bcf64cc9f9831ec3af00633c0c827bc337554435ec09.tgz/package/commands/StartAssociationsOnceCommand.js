"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const __aws_sdk_middleware_stack = require("@aws-sdk/middleware-stack");
const StartAssociationsOnce_1 = require("../model/operations/StartAssociationsOnce");
class StartAssociationsOnceCommand {
    constructor(input) {
        this.input = input;
        this.model = StartAssociationsOnce_1.StartAssociationsOnce;
        this.middlewareStack = new __aws_sdk_middleware_stack.MiddlewareStack();
    }
    resolveMiddleware(clientStack, configuration) {
        const { handler } = configuration;
        const stack = clientStack.concat(this.middlewareStack);
        const handlerExecutionContext = {
            logger: {},
            model: this.model
        };
        return stack.resolve(handler(handlerExecutionContext), handlerExecutionContext);
    }
}
exports.StartAssociationsOnceCommand = StartAssociationsOnceCommand;
//# sourceMappingURL=StartAssociationsOnceCommand.js.map