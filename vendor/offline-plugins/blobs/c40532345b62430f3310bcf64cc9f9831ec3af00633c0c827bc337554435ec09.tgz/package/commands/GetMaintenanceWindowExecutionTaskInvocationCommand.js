"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const __aws_sdk_middleware_stack = require("@aws-sdk/middleware-stack");
const GetMaintenanceWindowExecutionTaskInvocation_1 = require("../model/operations/GetMaintenanceWindowExecutionTaskInvocation");
class GetMaintenanceWindowExecutionTaskInvocationCommand {
    constructor(input) {
        this.input = input;
        this.model = GetMaintenanceWindowExecutionTaskInvocation_1.GetMaintenanceWindowExecutionTaskInvocation;
        this.middlewareStack = new __aws_sdk_middleware_stack.MiddlewareStack();
    }
    resolveMiddleware(clientStack, configuration) {
        const { handler } = configuration;
        const stack = clientStack.concat(this.middlewareStack);
        const handlerExecutionContext = {
            logger: {},
            model: this.model
        };
        return stack.resolve(handler(handlerExecutionContext), handlerExecutionContext);
    }
}
exports.GetMaintenanceWindowExecutionTaskInvocationCommand = GetMaintenanceWindowExecutionTaskInvocationCommand;
//# sourceMappingURL=GetMaintenanceWindowExecutionTaskInvocationCommand.js.map