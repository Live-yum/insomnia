"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const __aws_sdk_middleware_stack = require("@aws-sdk/middleware-stack");
const DescribeMaintenanceWindows_1 = require("../model/operations/DescribeMaintenanceWindows");
class DescribeMaintenanceWindowsCommand {
    constructor(input) {
        this.input = input;
        this.model = DescribeMaintenanceWindows_1.DescribeMaintenanceWindows;
        this.middlewareStack = new __aws_sdk_middleware_stack.MiddlewareStack();
    }
    resolveMiddleware(clientStack, configuration) {
        const { handler } = configuration;
        const stack = clientStack.concat(this.middlewareStack);
        const handlerExecutionContext = {
            logger: {},
            model: this.model
        };
        return stack.resolve(handler(handlerExecutionContext), handlerExecutionContext);
    }
}
exports.DescribeMaintenanceWindowsCommand = DescribeMaintenanceWindowsCommand;
//# sourceMappingURL=DescribeMaintenanceWindowsCommand.js.map