"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const __aws_sdk_middleware_stack = require("@aws-sdk/middleware-stack");
const DeregisterManagedInstance_1 = require("../model/operations/DeregisterManagedInstance");
class DeregisterManagedInstanceCommand {
    constructor(input) {
        this.input = input;
        this.model = DeregisterManagedInstance_1.DeregisterManagedInstance;
        this.middlewareStack = new __aws_sdk_middleware_stack.MiddlewareStack();
    }
    resolveMiddleware(clientStack, configuration) {
        const { handler } = configuration;
        const stack = clientStack.concat(this.middlewareStack);
        const handlerExecutionContext = {
            logger: {},
            model: this.model
        };
        return stack.resolve(handler(handlerExecutionContext), handlerExecutionContext);
    }
}
exports.DeregisterManagedInstanceCommand = DeregisterManagedInstanceCommand;
//# sourceMappingURL=DeregisterManagedInstanceCommand.js.map