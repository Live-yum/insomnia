/// <reference types="node" />
import * as __aws_sdk_middleware_stack from "@aws-sdk/middleware-stack";
import * as __aws_sdk_types from "@aws-sdk/types";
import * as _stream from "stream";
import { InputTypesUnion } from "../types/InputTypesUnion";
import { OutputTypesUnion } from "../types/OutputTypesUnion";
import { GetDeployablePatchSnapshotForInstanceInput } from "../types/GetDeployablePatchSnapshotForInstanceInput";
import { GetDeployablePatchSnapshotForInstanceOutput } from "../types/GetDeployablePatchSnapshotForInstanceOutput";
import { SSMResolvedConfiguration } from "../SSMConfiguration";
export * from "../types/GetDeployablePatchSnapshotForInstanceInput";
export * from "../types/GetDeployablePatchSnapshotForInstanceOutput";
export * from "../types/GetDeployablePatchSnapshotForInstanceExceptionsUnion";
export declare class GetDeployablePatchSnapshotForInstanceCommand implements __aws_sdk_types.Command<InputTypesUnion, GetDeployablePatchSnapshotForInstanceInput, OutputTypesUnion, GetDeployablePatchSnapshotForInstanceOutput, SSMResolvedConfiguration, _stream.Readable> {
    readonly input: GetDeployablePatchSnapshotForInstanceInput;
    readonly model: __aws_sdk_types.OperationModel;
    readonly middlewareStack: __aws_sdk_middleware_stack.MiddlewareStack<GetDeployablePatchSnapshotForInstanceInput, GetDeployablePatchSnapshotForInstanceOutput, _stream.Readable>;
    constructor(input: GetDeployablePatchSnapshotForInstanceInput);
    resolveMiddleware(clientStack: __aws_sdk_middleware_stack.MiddlewareStack<InputTypesUnion, OutputTypesUnion, _stream.Readable>, configuration: SSMResolvedConfiguration): __aws_sdk_types.Handler<GetDeployablePatchSnapshotForInstanceInput, GetDeployablePatchSnapshotForInstanceOutput>;
}
