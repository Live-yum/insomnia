/// <reference types="node" />
import * as __aws_sdk_middleware_stack from "@aws-sdk/middleware-stack";
import * as __aws_sdk_types from "@aws-sdk/types";
import * as _stream from "stream";
import { InputTypesUnion } from "../types/InputTypesUnion";
import { OutputTypesUnion } from "../types/OutputTypesUnion";
import { UpdateOpsItemInput } from "../types/UpdateOpsItemInput";
import { UpdateOpsItemOutput } from "../types/UpdateOpsItemOutput";
import { SSMResolvedConfiguration } from "../SSMConfiguration";
export * from "../types/UpdateOpsItemInput";
export * from "../types/UpdateOpsItemOutput";
export * from "../types/UpdateOpsItemExceptionsUnion";
export declare class UpdateOpsItemCommand implements __aws_sdk_types.Command<InputTypesUnion, UpdateOpsItemInput, OutputTypesUnion, UpdateOpsItemOutput, SSMResolvedConfiguration, _stream.Readable> {
    readonly input: UpdateOpsItemInput;
    readonly model: __aws_sdk_types.OperationModel;
    readonly middlewareStack: __aws_sdk_middleware_stack.MiddlewareStack<UpdateOpsItemInput, UpdateOpsItemOutput, _stream.Readable>;
    constructor(input: UpdateOpsItemInput);
    resolveMiddleware(clientStack: __aws_sdk_middleware_stack.MiddlewareStack<InputTypesUnion, OutputTypesUnion, _stream.Readable>, configuration: SSMResolvedConfiguration): __aws_sdk_types.Handler<UpdateOpsItemInput, UpdateOpsItemOutput>;
}
