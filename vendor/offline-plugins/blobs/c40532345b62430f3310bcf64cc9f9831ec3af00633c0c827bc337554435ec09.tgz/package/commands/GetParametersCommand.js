"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const __aws_sdk_middleware_stack = require("@aws-sdk/middleware-stack");
const GetParameters_1 = require("../model/operations/GetParameters");
class GetParametersCommand {
    constructor(input) {
        this.input = input;
        this.model = GetParameters_1.GetParameters;
        this.middlewareStack = new __aws_sdk_middleware_stack.MiddlewareStack();
    }
    resolveMiddleware(clientStack, configuration) {
        const { handler } = configuration;
        const stack = clientStack.concat(this.middlewareStack);
        const handlerExecutionContext = {
            logger: {},
            model: this.model
        };
        return stack.resolve(handler(handlerExecutionContext), handlerExecutionContext);
    }
}
exports.GetParametersCommand = GetParametersCommand;
//# sourceMappingURL=GetParametersCommand.js.map