"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const __aws_sdk_middleware_stack = require("@aws-sdk/middleware-stack");
const DescribeInstancePatchStatesForPatchGroup_1 = require("../model/operations/DescribeInstancePatchStatesForPatchGroup");
class DescribeInstancePatchStatesForPatchGroupCommand {
    constructor(input) {
        this.input = input;
        this.model = DescribeInstancePatchStatesForPatchGroup_1.DescribeInstancePatchStatesForPatchGroup;
        this.middlewareStack = new __aws_sdk_middleware_stack.MiddlewareStack();
    }
    resolveMiddleware(clientStack, configuration) {
        const { handler } = configuration;
        const stack = clientStack.concat(this.middlewareStack);
        const handlerExecutionContext = {
            logger: {},
            model: this.model
        };
        return stack.resolve(handler(handlerExecutionContext), handlerExecutionContext);
    }
}
exports.DescribeInstancePatchStatesForPatchGroupCommand = DescribeInstancePatchStatesForPatchGroupCommand;
//# sourceMappingURL=DescribeInstancePatchStatesForPatchGroupCommand.js.map