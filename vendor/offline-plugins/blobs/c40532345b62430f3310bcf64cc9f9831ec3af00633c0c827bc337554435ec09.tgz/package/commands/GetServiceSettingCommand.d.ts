/// <reference types="node" />
import * as __aws_sdk_middleware_stack from "@aws-sdk/middleware-stack";
import * as __aws_sdk_types from "@aws-sdk/types";
import * as _stream from "stream";
import { InputTypesUnion } from "../types/InputTypesUnion";
import { OutputTypesUnion } from "../types/OutputTypesUnion";
import { GetServiceSettingInput } from "../types/GetServiceSettingInput";
import { GetServiceSettingOutput } from "../types/GetServiceSettingOutput";
import { SSMResolvedConfiguration } from "../SSMConfiguration";
export * from "../types/GetServiceSettingInput";
export * from "../types/GetServiceSettingOutput";
export * from "../types/GetServiceSettingExceptionsUnion";
export declare class GetServiceSettingCommand implements __aws_sdk_types.Command<InputTypesUnion, GetServiceSettingInput, OutputTypesUnion, GetServiceSettingOutput, SSMResolvedConfiguration, _stream.Readable> {
    readonly input: GetServiceSettingInput;
    readonly model: __aws_sdk_types.OperationModel;
    readonly middlewareStack: __aws_sdk_middleware_stack.MiddlewareStack<GetServiceSettingInput, GetServiceSettingOutput, _stream.Readable>;
    constructor(input: GetServiceSettingInput);
    resolveMiddleware(clientStack: __aws_sdk_middleware_stack.MiddlewareStack<InputTypesUnion, OutputTypesUnion, _stream.Readable>, configuration: SSMResolvedConfiguration): __aws_sdk_types.Handler<GetServiceSettingInput, GetServiceSettingOutput>;
}
