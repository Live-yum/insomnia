/// <reference types="node" />
import * as __aws_sdk_middleware_stack from "@aws-sdk/middleware-stack";
import * as __aws_sdk_types from "@aws-sdk/types";
import * as _stream from "stream";
import { InputTypesUnion } from "../types/InputTypesUnion";
import { OutputTypesUnion } from "../types/OutputTypesUnion";
import { DescribeMaintenanceWindowExecutionsInput } from "../types/DescribeMaintenanceWindowExecutionsInput";
import { DescribeMaintenanceWindowExecutionsOutput } from "../types/DescribeMaintenanceWindowExecutionsOutput";
import { SSMResolvedConfiguration } from "../SSMConfiguration";
export * from "../types/DescribeMaintenanceWindowExecutionsInput";
export * from "../types/DescribeMaintenanceWindowExecutionsOutput";
export * from "../types/DescribeMaintenanceWindowExecutionsExceptionsUnion";
export declare class DescribeMaintenanceWindowExecutionsCommand implements __aws_sdk_types.Command<InputTypesUnion, DescribeMaintenanceWindowExecutionsInput, OutputTypesUnion, DescribeMaintenanceWindowExecutionsOutput, SSMResolvedConfiguration, _stream.Readable> {
    readonly input: DescribeMaintenanceWindowExecutionsInput;
    readonly model: __aws_sdk_types.OperationModel;
    readonly middlewareStack: __aws_sdk_middleware_stack.MiddlewareStack<DescribeMaintenanceWindowExecutionsInput, DescribeMaintenanceWindowExecutionsOutput, _stream.Readable>;
    constructor(input: DescribeMaintenanceWindowExecutionsInput);
    resolveMiddleware(clientStack: __aws_sdk_middleware_stack.MiddlewareStack<InputTypesUnion, OutputTypesUnion, _stream.Readable>, configuration: SSMResolvedConfiguration): __aws_sdk_types.Handler<DescribeMaintenanceWindowExecutionsInput, DescribeMaintenanceWindowExecutionsOutput>;
}
