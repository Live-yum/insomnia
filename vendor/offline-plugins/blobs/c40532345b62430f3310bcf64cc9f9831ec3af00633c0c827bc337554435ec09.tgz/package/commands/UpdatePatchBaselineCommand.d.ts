/// <reference types="node" />
import * as __aws_sdk_middleware_stack from "@aws-sdk/middleware-stack";
import * as __aws_sdk_types from "@aws-sdk/types";
import * as _stream from "stream";
import { InputTypesUnion } from "../types/InputTypesUnion";
import { OutputTypesUnion } from "../types/OutputTypesUnion";
import { UpdatePatchBaselineInput } from "../types/UpdatePatchBaselineInput";
import { UpdatePatchBaselineOutput } from "../types/UpdatePatchBaselineOutput";
import { SSMResolvedConfiguration } from "../SSMConfiguration";
export * from "../types/UpdatePatchBaselineInput";
export * from "../types/UpdatePatchBaselineOutput";
export * from "../types/UpdatePatchBaselineExceptionsUnion";
export declare class UpdatePatchBaselineCommand implements __aws_sdk_types.Command<InputTypesUnion, UpdatePatchBaselineInput, OutputTypesUnion, UpdatePatchBaselineOutput, SSMResolvedConfiguration, _stream.Readable> {
    readonly input: UpdatePatchBaselineInput;
    readonly model: __aws_sdk_types.OperationModel;
    readonly middlewareStack: __aws_sdk_middleware_stack.MiddlewareStack<UpdatePatchBaselineInput, UpdatePatchBaselineOutput, _stream.Readable>;
    constructor(input: UpdatePatchBaselineInput);
    resolveMiddleware(clientStack: __aws_sdk_middleware_stack.MiddlewareStack<InputTypesUnion, OutputTypesUnion, _stream.Readable>, configuration: SSMResolvedConfiguration): __aws_sdk_types.Handler<UpdatePatchBaselineInput, UpdatePatchBaselineOutput>;
}
