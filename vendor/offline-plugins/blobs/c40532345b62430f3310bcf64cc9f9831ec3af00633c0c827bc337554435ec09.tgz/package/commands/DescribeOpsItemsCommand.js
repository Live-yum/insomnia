"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const __aws_sdk_middleware_stack = require("@aws-sdk/middleware-stack");
const DescribeOpsItems_1 = require("../model/operations/DescribeOpsItems");
class DescribeOpsItemsCommand {
    constructor(input) {
        this.input = input;
        this.model = DescribeOpsItems_1.DescribeOpsItems;
        this.middlewareStack = new __aws_sdk_middleware_stack.MiddlewareStack();
    }
    resolveMiddleware(clientStack, configuration) {
        const { handler } = configuration;
        const stack = clientStack.concat(this.middlewareStack);
        const handlerExecutionContext = {
            logger: {},
            model: this.model
        };
        return stack.resolve(handler(handlerExecutionContext), handlerExecutionContext);
    }
}
exports.DescribeOpsItemsCommand = DescribeOpsItemsCommand;
//# sourceMappingURL=DescribeOpsItemsCommand.js.map