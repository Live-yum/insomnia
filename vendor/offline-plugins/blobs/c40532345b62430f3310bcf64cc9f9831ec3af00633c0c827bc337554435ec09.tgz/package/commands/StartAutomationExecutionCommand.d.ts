/// <reference types="node" />
import * as __aws_sdk_middleware_stack from "@aws-sdk/middleware-stack";
import * as __aws_sdk_types from "@aws-sdk/types";
import * as _stream from "stream";
import { InputTypesUnion } from "../types/InputTypesUnion";
import { OutputTypesUnion } from "../types/OutputTypesUnion";
import { StartAutomationExecutionInput } from "../types/StartAutomationExecutionInput";
import { StartAutomationExecutionOutput } from "../types/StartAutomationExecutionOutput";
import { SSMResolvedConfiguration } from "../SSMConfiguration";
export * from "../types/StartAutomationExecutionInput";
export * from "../types/StartAutomationExecutionOutput";
export * from "../types/StartAutomationExecutionExceptionsUnion";
export declare class StartAutomationExecutionCommand implements __aws_sdk_types.Command<InputTypesUnion, StartAutomationExecutionInput, OutputTypesUnion, StartAutomationExecutionOutput, SSMResolvedConfiguration, _stream.Readable> {
    readonly input: StartAutomationExecutionInput;
    readonly model: __aws_sdk_types.OperationModel;
    readonly middlewareStack: __aws_sdk_middleware_stack.MiddlewareStack<StartAutomationExecutionInput, StartAutomationExecutionOutput, _stream.Readable>;
    constructor(input: StartAutomationExecutionInput);
    resolveMiddleware(clientStack: __aws_sdk_middleware_stack.MiddlewareStack<InputTypesUnion, OutputTypesUnion, _stream.Readable>, configuration: SSMResolvedConfiguration): __aws_sdk_types.Handler<StartAutomationExecutionInput, StartAutomationExecutionOutput>;
}
