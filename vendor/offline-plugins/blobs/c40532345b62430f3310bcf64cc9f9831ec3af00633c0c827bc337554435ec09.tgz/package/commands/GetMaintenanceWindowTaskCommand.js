"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const __aws_sdk_middleware_stack = require("@aws-sdk/middleware-stack");
const GetMaintenanceWindowTask_1 = require("../model/operations/GetMaintenanceWindowTask");
class GetMaintenanceWindowTaskCommand {
    constructor(input) {
        this.input = input;
        this.model = GetMaintenanceWindowTask_1.GetMaintenanceWindowTask;
        this.middlewareStack = new __aws_sdk_middleware_stack.MiddlewareStack();
    }
    resolveMiddleware(clientStack, configuration) {
        const { handler } = configuration;
        const stack = clientStack.concat(this.middlewareStack);
        const handlerExecutionContext = {
            logger: {},
            model: this.model
        };
        return stack.resolve(handler(handlerExecutionContext), handlerExecutionContext);
    }
}
exports.GetMaintenanceWindowTaskCommand = GetMaintenanceWindowTaskCommand;
//# sourceMappingURL=GetMaintenanceWindowTaskCommand.js.map