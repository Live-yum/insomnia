/// <reference types="node" />
import * as __aws_sdk_middleware_stack from "@aws-sdk/middleware-stack";
import * as __aws_sdk_types from "@aws-sdk/types";
import * as _stream from "stream";
import { InputTypesUnion } from "../types/InputTypesUnion";
import { OutputTypesUnion } from "../types/OutputTypesUnion";
import { DescribeMaintenanceWindowsInput } from "../types/DescribeMaintenanceWindowsInput";
import { DescribeMaintenanceWindowsOutput } from "../types/DescribeMaintenanceWindowsOutput";
import { SSMResolvedConfiguration } from "../SSMConfiguration";
export * from "../types/DescribeMaintenanceWindowsInput";
export * from "../types/DescribeMaintenanceWindowsOutput";
export * from "../types/DescribeMaintenanceWindowsExceptionsUnion";
export declare class DescribeMaintenanceWindowsCommand implements __aws_sdk_types.Command<InputTypesUnion, DescribeMaintenanceWindowsInput, OutputTypesUnion, DescribeMaintenanceWindowsOutput, SSMResolvedConfiguration, _stream.Readable> {
    readonly input: DescribeMaintenanceWindowsInput;
    readonly model: __aws_sdk_types.OperationModel;
    readonly middlewareStack: __aws_sdk_middleware_stack.MiddlewareStack<DescribeMaintenanceWindowsInput, DescribeMaintenanceWindowsOutput, _stream.Readable>;
    constructor(input: DescribeMaintenanceWindowsInput);
    resolveMiddleware(clientStack: __aws_sdk_middleware_stack.MiddlewareStack<InputTypesUnion, OutputTypesUnion, _stream.Readable>, configuration: SSMResolvedConfiguration): __aws_sdk_types.Handler<DescribeMaintenanceWindowsInput, DescribeMaintenanceWindowsOutput>;
}
