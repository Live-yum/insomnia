/// <reference types="node" />
import * as __aws_sdk_middleware_stack from "@aws-sdk/middleware-stack";
import * as __aws_sdk_types from "@aws-sdk/types";
import * as _stream from "stream";
import { InputTypesUnion } from "../types/InputTypesUnion";
import { OutputTypesUnion } from "../types/OutputTypesUnion";
import { RegisterTaskWithMaintenanceWindowInput } from "../types/RegisterTaskWithMaintenanceWindowInput";
import { RegisterTaskWithMaintenanceWindowOutput } from "../types/RegisterTaskWithMaintenanceWindowOutput";
import { SSMResolvedConfiguration } from "../SSMConfiguration";
export * from "../types/RegisterTaskWithMaintenanceWindowInput";
export * from "../types/RegisterTaskWithMaintenanceWindowOutput";
export * from "../types/RegisterTaskWithMaintenanceWindowExceptionsUnion";
export declare class RegisterTaskWithMaintenanceWindowCommand implements __aws_sdk_types.Command<InputTypesUnion, RegisterTaskWithMaintenanceWindowInput, OutputTypesUnion, RegisterTaskWithMaintenanceWindowOutput, SSMResolvedConfiguration, _stream.Readable> {
    readonly input: RegisterTaskWithMaintenanceWindowInput;
    readonly model: __aws_sdk_types.OperationModel;
    readonly middlewareStack: __aws_sdk_middleware_stack.MiddlewareStack<RegisterTaskWithMaintenanceWindowInput, RegisterTaskWithMaintenanceWindowOutput, _stream.Readable>;
    constructor(input: RegisterTaskWithMaintenanceWindowInput);
    resolveMiddleware(clientStack: __aws_sdk_middleware_stack.MiddlewareStack<InputTypesUnion, OutputTypesUnion, _stream.Readable>, configuration: SSMResolvedConfiguration): __aws_sdk_types.Handler<RegisterTaskWithMaintenanceWindowInput, RegisterTaskWithMaintenanceWindowOutput>;
}
