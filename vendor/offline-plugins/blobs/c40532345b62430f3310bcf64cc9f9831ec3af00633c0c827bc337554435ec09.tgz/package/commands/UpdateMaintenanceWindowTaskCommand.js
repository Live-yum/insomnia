"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const __aws_sdk_middleware_stack = require("@aws-sdk/middleware-stack");
const UpdateMaintenanceWindowTask_1 = require("../model/operations/UpdateMaintenanceWindowTask");
class UpdateMaintenanceWindowTaskCommand {
    constructor(input) {
        this.input = input;
        this.model = UpdateMaintenanceWindowTask_1.UpdateMaintenanceWindowTask;
        this.middlewareStack = new __aws_sdk_middleware_stack.MiddlewareStack();
    }
    resolveMiddleware(clientStack, configuration) {
        const { handler } = configuration;
        const stack = clientStack.concat(this.middlewareStack);
        const handlerExecutionContext = {
            logger: {},
            model: this.model
        };
        return stack.resolve(handler(handlerExecutionContext), handlerExecutionContext);
    }
}
exports.UpdateMaintenanceWindowTaskCommand = UpdateMaintenanceWindowTaskCommand;
//# sourceMappingURL=UpdateMaintenanceWindowTaskCommand.js.map