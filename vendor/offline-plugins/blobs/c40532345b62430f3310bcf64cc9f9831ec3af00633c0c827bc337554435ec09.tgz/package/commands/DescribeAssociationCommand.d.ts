/// <reference types="node" />
import * as __aws_sdk_middleware_stack from "@aws-sdk/middleware-stack";
import * as __aws_sdk_types from "@aws-sdk/types";
import * as _stream from "stream";
import { InputTypesUnion } from "../types/InputTypesUnion";
import { OutputTypesUnion } from "../types/OutputTypesUnion";
import { DescribeAssociationInput } from "../types/DescribeAssociationInput";
import { DescribeAssociationOutput } from "../types/DescribeAssociationOutput";
import { SSMResolvedConfiguration } from "../SSMConfiguration";
export * from "../types/DescribeAssociationInput";
export * from "../types/DescribeAssociationOutput";
export * from "../types/DescribeAssociationExceptionsUnion";
export declare class DescribeAssociationCommand implements __aws_sdk_types.Command<InputTypesUnion, DescribeAssociationInput, OutputTypesUnion, DescribeAssociationOutput, SSMResolvedConfiguration, _stream.Readable> {
    readonly input: DescribeAssociationInput;
    readonly model: __aws_sdk_types.OperationModel;
    readonly middlewareStack: __aws_sdk_middleware_stack.MiddlewareStack<DescribeAssociationInput, DescribeAssociationOutput, _stream.Readable>;
    constructor(input: DescribeAssociationInput);
    resolveMiddleware(clientStack: __aws_sdk_middleware_stack.MiddlewareStack<InputTypesUnion, OutputTypesUnion, _stream.Readable>, configuration: SSMResolvedConfiguration): __aws_sdk_types.Handler<DescribeAssociationInput, DescribeAssociationOutput>;
}
