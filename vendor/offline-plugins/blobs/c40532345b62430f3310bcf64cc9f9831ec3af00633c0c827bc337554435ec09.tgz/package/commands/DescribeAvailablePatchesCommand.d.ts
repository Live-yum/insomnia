/// <reference types="node" />
import * as __aws_sdk_middleware_stack from "@aws-sdk/middleware-stack";
import * as __aws_sdk_types from "@aws-sdk/types";
import * as _stream from "stream";
import { InputTypesUnion } from "../types/InputTypesUnion";
import { OutputTypesUnion } from "../types/OutputTypesUnion";
import { DescribeAvailablePatchesInput } from "../types/DescribeAvailablePatchesInput";
import { DescribeAvailablePatchesOutput } from "../types/DescribeAvailablePatchesOutput";
import { SSMResolvedConfiguration } from "../SSMConfiguration";
export * from "../types/DescribeAvailablePatchesInput";
export * from "../types/DescribeAvailablePatchesOutput";
export * from "../types/DescribeAvailablePatchesExceptionsUnion";
export declare class DescribeAvailablePatchesCommand implements __aws_sdk_types.Command<InputTypesUnion, DescribeAvailablePatchesInput, OutputTypesUnion, DescribeAvailablePatchesOutput, SSMResolvedConfiguration, _stream.Readable> {
    readonly input: DescribeAvailablePatchesInput;
    readonly model: __aws_sdk_types.OperationModel;
    readonly middlewareStack: __aws_sdk_middleware_stack.MiddlewareStack<DescribeAvailablePatchesInput, DescribeAvailablePatchesOutput, _stream.Readable>;
    constructor(input: DescribeAvailablePatchesInput);
    resolveMiddleware(clientStack: __aws_sdk_middleware_stack.MiddlewareStack<InputTypesUnion, OutputTypesUnion, _stream.Readable>, configuration: SSMResolvedConfiguration): __aws_sdk_types.Handler<DescribeAvailablePatchesInput, DescribeAvailablePatchesOutput>;
}
