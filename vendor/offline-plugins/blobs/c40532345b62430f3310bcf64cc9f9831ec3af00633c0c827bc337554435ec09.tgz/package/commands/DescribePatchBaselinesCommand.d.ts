/// <reference types="node" />
import * as __aws_sdk_middleware_stack from "@aws-sdk/middleware-stack";
import * as __aws_sdk_types from "@aws-sdk/types";
import * as _stream from "stream";
import { InputTypesUnion } from "../types/InputTypesUnion";
import { OutputTypesUnion } from "../types/OutputTypesUnion";
import { DescribePatchBaselinesInput } from "../types/DescribePatchBaselinesInput";
import { DescribePatchBaselinesOutput } from "../types/DescribePatchBaselinesOutput";
import { SSMResolvedConfiguration } from "../SSMConfiguration";
export * from "../types/DescribePatchBaselinesInput";
export * from "../types/DescribePatchBaselinesOutput";
export * from "../types/DescribePatchBaselinesExceptionsUnion";
export declare class DescribePatchBaselinesCommand implements __aws_sdk_types.Command<InputTypesUnion, DescribePatchBaselinesInput, OutputTypesUnion, DescribePatchBaselinesOutput, SSMResolvedConfiguration, _stream.Readable> {
    readonly input: DescribePatchBaselinesInput;
    readonly model: __aws_sdk_types.OperationModel;
    readonly middlewareStack: __aws_sdk_middleware_stack.MiddlewareStack<DescribePatchBaselinesInput, DescribePatchBaselinesOutput, _stream.Readable>;
    constructor(input: DescribePatchBaselinesInput);
    resolveMiddleware(clientStack: __aws_sdk_middleware_stack.MiddlewareStack<InputTypesUnion, OutputTypesUnion, _stream.Readable>, configuration: SSMResolvedConfiguration): __aws_sdk_types.Handler<DescribePatchBaselinesInput, DescribePatchBaselinesOutput>;
}
