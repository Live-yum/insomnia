/// <reference types="node" />
import * as __aws_sdk_middleware_stack from "@aws-sdk/middleware-stack";
import * as __aws_sdk_types from "@aws-sdk/types";
import * as _stream from "stream";
import { InputTypesUnion } from "../types/InputTypesUnion";
import { OutputTypesUnion } from "../types/OutputTypesUnion";
import { SendAutomationSignalInput } from "../types/SendAutomationSignalInput";
import { SendAutomationSignalOutput } from "../types/SendAutomationSignalOutput";
import { SSMResolvedConfiguration } from "../SSMConfiguration";
export * from "../types/SendAutomationSignalInput";
export * from "../types/SendAutomationSignalOutput";
export * from "../types/SendAutomationSignalExceptionsUnion";
export declare class SendAutomationSignalCommand implements __aws_sdk_types.Command<InputTypesUnion, SendAutomationSignalInput, OutputTypesUnion, SendAutomationSignalOutput, SSMResolvedConfiguration, _stream.Readable> {
    readonly input: SendAutomationSignalInput;
    readonly model: __aws_sdk_types.OperationModel;
    readonly middlewareStack: __aws_sdk_middleware_stack.MiddlewareStack<SendAutomationSignalInput, SendAutomationSignalOutput, _stream.Readable>;
    constructor(input: SendAutomationSignalInput);
    resolveMiddleware(clientStack: __aws_sdk_middleware_stack.MiddlewareStack<InputTypesUnion, OutputTypesUnion, _stream.Readable>, configuration: SSMResolvedConfiguration): __aws_sdk_types.Handler<SendAutomationSignalInput, SendAutomationSignalOutput>;
}
