"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const __aws_sdk_middleware_stack = require("@aws-sdk/middleware-stack");
const CreateActivation_1 = require("../model/operations/CreateActivation");
class CreateActivationCommand {
    constructor(input) {
        this.input = input;
        this.model = CreateActivation_1.CreateActivation;
        this.middlewareStack = new __aws_sdk_middleware_stack.MiddlewareStack();
    }
    resolveMiddleware(clientStack, configuration) {
        const { handler } = configuration;
        const stack = clientStack.concat(this.middlewareStack);
        const handlerExecutionContext = {
            logger: {},
            model: this.model
        };
        return stack.resolve(handler(handlerExecutionContext), handlerExecutionContext);
    }
}
exports.CreateActivationCommand = CreateActivationCommand;
//# sourceMappingURL=CreateActivationCommand.js.map