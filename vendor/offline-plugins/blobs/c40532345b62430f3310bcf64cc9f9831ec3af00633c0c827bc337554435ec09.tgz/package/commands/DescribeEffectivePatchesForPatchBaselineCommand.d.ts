/// <reference types="node" />
import * as __aws_sdk_middleware_stack from "@aws-sdk/middleware-stack";
import * as __aws_sdk_types from "@aws-sdk/types";
import * as _stream from "stream";
import { InputTypesUnion } from "../types/InputTypesUnion";
import { OutputTypesUnion } from "../types/OutputTypesUnion";
import { DescribeEffectivePatchesForPatchBaselineInput } from "../types/DescribeEffectivePatchesForPatchBaselineInput";
import { DescribeEffectivePatchesForPatchBaselineOutput } from "../types/DescribeEffectivePatchesForPatchBaselineOutput";
import { SSMResolvedConfiguration } from "../SSMConfiguration";
export * from "../types/DescribeEffectivePatchesForPatchBaselineInput";
export * from "../types/DescribeEffectivePatchesForPatchBaselineOutput";
export * from "../types/DescribeEffectivePatchesForPatchBaselineExceptionsUnion";
export declare class DescribeEffectivePatchesForPatchBaselineCommand implements __aws_sdk_types.Command<InputTypesUnion, DescribeEffectivePatchesForPatchBaselineInput, OutputTypesUnion, DescribeEffectivePatchesForPatchBaselineOutput, SSMResolvedConfiguration, _stream.Readable> {
    readonly input: DescribeEffectivePatchesForPatchBaselineInput;
    readonly model: __aws_sdk_types.OperationModel;
    readonly middlewareStack: __aws_sdk_middleware_stack.MiddlewareStack<DescribeEffectivePatchesForPatchBaselineInput, DescribeEffectivePatchesForPatchBaselineOutput, _stream.Readable>;
    constructor(input: DescribeEffectivePatchesForPatchBaselineInput);
    resolveMiddleware(clientStack: __aws_sdk_middleware_stack.MiddlewareStack<InputTypesUnion, OutputTypesUnion, _stream.Readable>, configuration: SSMResolvedConfiguration): __aws_sdk_types.Handler<DescribeEffectivePatchesForPatchBaselineInput, DescribeEffectivePatchesForPatchBaselineOutput>;
}
