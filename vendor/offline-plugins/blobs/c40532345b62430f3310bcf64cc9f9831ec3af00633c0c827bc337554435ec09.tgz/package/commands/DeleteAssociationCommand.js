"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const __aws_sdk_middleware_stack = require("@aws-sdk/middleware-stack");
const DeleteAssociation_1 = require("../model/operations/DeleteAssociation");
class DeleteAssociationCommand {
    constructor(input) {
        this.input = input;
        this.model = DeleteAssociation_1.DeleteAssociation;
        this.middlewareStack = new __aws_sdk_middleware_stack.MiddlewareStack();
    }
    resolveMiddleware(clientStack, configuration) {
        const { handler } = configuration;
        const stack = clientStack.concat(this.middlewareStack);
        const handlerExecutionContext = {
            logger: {},
            model: this.model
        };
        return stack.resolve(handler(handlerExecutionContext), handlerExecutionContext);
    }
}
exports.DeleteAssociationCommand = DeleteAssociationCommand;
//# sourceMappingURL=DeleteAssociationCommand.js.map