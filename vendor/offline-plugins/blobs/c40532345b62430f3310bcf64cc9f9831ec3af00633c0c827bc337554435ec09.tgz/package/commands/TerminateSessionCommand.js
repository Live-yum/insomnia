"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const __aws_sdk_middleware_stack = require("@aws-sdk/middleware-stack");
const TerminateSession_1 = require("../model/operations/TerminateSession");
class TerminateSessionCommand {
    constructor(input) {
        this.input = input;
        this.model = TerminateSession_1.TerminateSession;
        this.middlewareStack = new __aws_sdk_middleware_stack.MiddlewareStack();
    }
    resolveMiddleware(clientStack, configuration) {
        const { handler } = configuration;
        const stack = clientStack.concat(this.middlewareStack);
        const handlerExecutionContext = {
            logger: {},
            model: this.model
        };
        return stack.resolve(handler(handlerExecutionContext), handlerExecutionContext);
    }
}
exports.TerminateSessionCommand = TerminateSessionCommand;
//# sourceMappingURL=TerminateSessionCommand.js.map