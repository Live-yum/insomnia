"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const __aws_sdk_middleware_stack = require("@aws-sdk/middleware-stack");
const ModifyDocumentPermission_1 = require("../model/operations/ModifyDocumentPermission");
class ModifyDocumentPermissionCommand {
    constructor(input) {
        this.input = input;
        this.model = ModifyDocumentPermission_1.ModifyDocumentPermission;
        this.middlewareStack = new __aws_sdk_middleware_stack.MiddlewareStack();
    }
    resolveMiddleware(clientStack, configuration) {
        const { handler } = configuration;
        const stack = clientStack.concat(this.middlewareStack);
        const handlerExecutionContext = {
            logger: {},
            model: this.model
        };
        return stack.resolve(handler(handlerExecutionContext), handlerExecutionContext);
    }
}
exports.ModifyDocumentPermissionCommand = ModifyDocumentPermissionCommand;
//# sourceMappingURL=ModifyDocumentPermissionCommand.js.map