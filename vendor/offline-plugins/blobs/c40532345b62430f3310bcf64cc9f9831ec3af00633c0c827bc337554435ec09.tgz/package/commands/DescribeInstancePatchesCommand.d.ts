/// <reference types="node" />
import * as __aws_sdk_middleware_stack from "@aws-sdk/middleware-stack";
import * as __aws_sdk_types from "@aws-sdk/types";
import * as _stream from "stream";
import { InputTypesUnion } from "../types/InputTypesUnion";
import { OutputTypesUnion } from "../types/OutputTypesUnion";
import { DescribeInstancePatchesInput } from "../types/DescribeInstancePatchesInput";
import { DescribeInstancePatchesOutput } from "../types/DescribeInstancePatchesOutput";
import { SSMResolvedConfiguration } from "../SSMConfiguration";
export * from "../types/DescribeInstancePatchesInput";
export * from "../types/DescribeInstancePatchesOutput";
export * from "../types/DescribeInstancePatchesExceptionsUnion";
export declare class DescribeInstancePatchesCommand implements __aws_sdk_types.Command<InputTypesUnion, DescribeInstancePatchesInput, OutputTypesUnion, DescribeInstancePatchesOutput, SSMResolvedConfiguration, _stream.Readable> {
    readonly input: DescribeInstancePatchesInput;
    readonly model: __aws_sdk_types.OperationModel;
    readonly middlewareStack: __aws_sdk_middleware_stack.MiddlewareStack<DescribeInstancePatchesInput, DescribeInstancePatchesOutput, _stream.Readable>;
    constructor(input: DescribeInstancePatchesInput);
    resolveMiddleware(clientStack: __aws_sdk_middleware_stack.MiddlewareStack<InputTypesUnion, OutputTypesUnion, _stream.Readable>, configuration: SSMResolvedConfiguration): __aws_sdk_types.Handler<DescribeInstancePatchesInput, DescribeInstancePatchesOutput>;
}
