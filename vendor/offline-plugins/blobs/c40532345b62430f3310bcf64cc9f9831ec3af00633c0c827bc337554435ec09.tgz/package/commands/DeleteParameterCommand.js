"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const __aws_sdk_middleware_stack = require("@aws-sdk/middleware-stack");
const DeleteParameter_1 = require("../model/operations/DeleteParameter");
class DeleteParameterCommand {
    constructor(input) {
        this.input = input;
        this.model = DeleteParameter_1.DeleteParameter;
        this.middlewareStack = new __aws_sdk_middleware_stack.MiddlewareStack();
    }
    resolveMiddleware(clientStack, configuration) {
        const { handler } = configuration;
        const stack = clientStack.concat(this.middlewareStack);
        const handlerExecutionContext = {
            logger: {},
            model: this.model
        };
        return stack.resolve(handler(handlerExecutionContext), handlerExecutionContext);
    }
}
exports.DeleteParameterCommand = DeleteParameterCommand;
//# sourceMappingURL=DeleteParameterCommand.js.map