/// <reference types="node" />
import * as __aws_sdk_middleware_stack from "@aws-sdk/middleware-stack";
import * as __aws_sdk_types from "@aws-sdk/types";
import * as _stream from "stream";
import { InputTypesUnion } from "../types/InputTypesUnion";
import { OutputTypesUnion } from "../types/OutputTypesUnion";
import { UpdateDocumentInput } from "../types/UpdateDocumentInput";
import { UpdateDocumentOutput } from "../types/UpdateDocumentOutput";
import { SSMResolvedConfiguration } from "../SSMConfiguration";
export * from "../types/UpdateDocumentInput";
export * from "../types/UpdateDocumentOutput";
export * from "../types/UpdateDocumentExceptionsUnion";
export declare class UpdateDocumentCommand implements __aws_sdk_types.Command<InputTypesUnion, UpdateDocumentInput, OutputTypesUnion, UpdateDocumentOutput, SSMResolvedConfiguration, _stream.Readable> {
    readonly input: UpdateDocumentInput;
    readonly model: __aws_sdk_types.OperationModel;
    readonly middlewareStack: __aws_sdk_middleware_stack.MiddlewareStack<UpdateDocumentInput, UpdateDocumentOutput, _stream.Readable>;
    constructor(input: UpdateDocumentInput);
    resolveMiddleware(clientStack: __aws_sdk_middleware_stack.MiddlewareStack<InputTypesUnion, OutputTypesUnion, _stream.Readable>, configuration: SSMResolvedConfiguration): __aws_sdk_types.Handler<UpdateDocumentInput, UpdateDocumentOutput>;
}
