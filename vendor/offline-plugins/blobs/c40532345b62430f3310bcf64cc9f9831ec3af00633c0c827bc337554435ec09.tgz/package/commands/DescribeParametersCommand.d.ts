/// <reference types="node" />
import * as __aws_sdk_middleware_stack from "@aws-sdk/middleware-stack";
import * as __aws_sdk_types from "@aws-sdk/types";
import * as _stream from "stream";
import { InputTypesUnion } from "../types/InputTypesUnion";
import { OutputTypesUnion } from "../types/OutputTypesUnion";
import { DescribeParametersInput } from "../types/DescribeParametersInput";
import { DescribeParametersOutput } from "../types/DescribeParametersOutput";
import { SSMResolvedConfiguration } from "../SSMConfiguration";
export * from "../types/DescribeParametersInput";
export * from "../types/DescribeParametersOutput";
export * from "../types/DescribeParametersExceptionsUnion";
export declare class DescribeParametersCommand implements __aws_sdk_types.Command<InputTypesUnion, DescribeParametersInput, OutputTypesUnion, DescribeParametersOutput, SSMResolvedConfiguration, _stream.Readable> {
    readonly input: DescribeParametersInput;
    readonly model: __aws_sdk_types.OperationModel;
    readonly middlewareStack: __aws_sdk_middleware_stack.MiddlewareStack<DescribeParametersInput, DescribeParametersOutput, _stream.Readable>;
    constructor(input: DescribeParametersInput);
    resolveMiddleware(clientStack: __aws_sdk_middleware_stack.MiddlewareStack<InputTypesUnion, OutputTypesUnion, _stream.Readable>, configuration: SSMResolvedConfiguration): __aws_sdk_types.Handler<DescribeParametersInput, DescribeParametersOutput>;
}
