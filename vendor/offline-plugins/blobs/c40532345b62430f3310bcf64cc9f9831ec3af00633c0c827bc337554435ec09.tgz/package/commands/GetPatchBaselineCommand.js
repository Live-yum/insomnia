"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const __aws_sdk_middleware_stack = require("@aws-sdk/middleware-stack");
const GetPatchBaseline_1 = require("../model/operations/GetPatchBaseline");
class GetPatchBaselineCommand {
    constructor(input) {
        this.input = input;
        this.model = GetPatchBaseline_1.GetPatchBaseline;
        this.middlewareStack = new __aws_sdk_middleware_stack.MiddlewareStack();
    }
    resolveMiddleware(clientStack, configuration) {
        const { handler } = configuration;
        const stack = clientStack.concat(this.middlewareStack);
        const handlerExecutionContext = {
            logger: {},
            model: this.model
        };
        return stack.resolve(handler(handlerExecutionContext), handlerExecutionContext);
    }
}
exports.GetPatchBaselineCommand = GetPatchBaselineCommand;
//# sourceMappingURL=GetPatchBaselineCommand.js.map