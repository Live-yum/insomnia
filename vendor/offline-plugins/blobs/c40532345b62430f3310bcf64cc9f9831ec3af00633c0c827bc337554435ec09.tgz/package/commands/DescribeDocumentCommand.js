"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const __aws_sdk_middleware_stack = require("@aws-sdk/middleware-stack");
const DescribeDocument_1 = require("../model/operations/DescribeDocument");
class DescribeDocumentCommand {
    constructor(input) {
        this.input = input;
        this.model = DescribeDocument_1.DescribeDocument;
        this.middlewareStack = new __aws_sdk_middleware_stack.MiddlewareStack();
    }
    resolveMiddleware(clientStack, configuration) {
        const { handler } = configuration;
        const stack = clientStack.concat(this.middlewareStack);
        const handlerExecutionContext = {
            logger: {},
            model: this.model
        };
        return stack.resolve(handler(handlerExecutionContext), handlerExecutionContext);
    }
}
exports.DescribeDocumentCommand = DescribeDocumentCommand;
//# sourceMappingURL=DescribeDocumentCommand.js.map