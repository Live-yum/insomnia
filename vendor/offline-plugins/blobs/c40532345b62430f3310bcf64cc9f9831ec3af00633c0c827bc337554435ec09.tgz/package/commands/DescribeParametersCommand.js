"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const __aws_sdk_middleware_stack = require("@aws-sdk/middleware-stack");
const DescribeParameters_1 = require("../model/operations/DescribeParameters");
class DescribeParametersCommand {
    constructor(input) {
        this.input = input;
        this.model = DescribeParameters_1.DescribeParameters;
        this.middlewareStack = new __aws_sdk_middleware_stack.MiddlewareStack();
    }
    resolveMiddleware(clientStack, configuration) {
        const { handler } = configuration;
        const stack = clientStack.concat(this.middlewareStack);
        const handlerExecutionContext = {
            logger: {},
            model: this.model
        };
        return stack.resolve(handler(handlerExecutionContext), handlerExecutionContext);
    }
}
exports.DescribeParametersCommand = DescribeParametersCommand;
//# sourceMappingURL=DescribeParametersCommand.js.map