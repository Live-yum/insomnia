/// <reference types="node" />
import * as __aws_sdk_middleware_stack from "@aws-sdk/middleware-stack";
import * as __aws_sdk_types from "@aws-sdk/types";
import * as _stream from "stream";
import { InputTypesUnion } from "../types/InputTypesUnion";
import { OutputTypesUnion } from "../types/OutputTypesUnion";
import { PutComplianceItemsInput } from "../types/PutComplianceItemsInput";
import { PutComplianceItemsOutput } from "../types/PutComplianceItemsOutput";
import { SSMResolvedConfiguration } from "../SSMConfiguration";
export * from "../types/PutComplianceItemsInput";
export * from "../types/PutComplianceItemsOutput";
export * from "../types/PutComplianceItemsExceptionsUnion";
export declare class PutComplianceItemsCommand implements __aws_sdk_types.Command<InputTypesUnion, PutComplianceItemsInput, OutputTypesUnion, PutComplianceItemsOutput, SSMResolvedConfiguration, _stream.Readable> {
    readonly input: PutComplianceItemsInput;
    readonly model: __aws_sdk_types.OperationModel;
    readonly middlewareStack: __aws_sdk_middleware_stack.MiddlewareStack<PutComplianceItemsInput, PutComplianceItemsOutput, _stream.Readable>;
    constructor(input: PutComplianceItemsInput);
    resolveMiddleware(clientStack: __aws_sdk_middleware_stack.MiddlewareStack<InputTypesUnion, OutputTypesUnion, _stream.Readable>, configuration: SSMResolvedConfiguration): __aws_sdk_types.Handler<PutComplianceItemsInput, PutComplianceItemsOutput>;
}
