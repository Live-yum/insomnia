/// <reference types="node" />
import * as __aws_sdk_middleware_stack from "@aws-sdk/middleware-stack";
import * as __aws_sdk_types from "@aws-sdk/types";
import * as _stream from "stream";
import { InputTypesUnion } from "../types/InputTypesUnion";
import { OutputTypesUnion } from "../types/OutputTypesUnion";
import { GetPatchBaselineForPatchGroupInput } from "../types/GetPatchBaselineForPatchGroupInput";
import { GetPatchBaselineForPatchGroupOutput } from "../types/GetPatchBaselineForPatchGroupOutput";
import { SSMResolvedConfiguration } from "../SSMConfiguration";
export * from "../types/GetPatchBaselineForPatchGroupInput";
export * from "../types/GetPatchBaselineForPatchGroupOutput";
export * from "../types/GetPatchBaselineForPatchGroupExceptionsUnion";
export declare class GetPatchBaselineForPatchGroupCommand implements __aws_sdk_types.Command<InputTypesUnion, GetPatchBaselineForPatchGroupInput, OutputTypesUnion, GetPatchBaselineForPatchGroupOutput, SSMResolvedConfiguration, _stream.Readable> {
    readonly input: GetPatchBaselineForPatchGroupInput;
    readonly model: __aws_sdk_types.OperationModel;
    readonly middlewareStack: __aws_sdk_middleware_stack.MiddlewareStack<GetPatchBaselineForPatchGroupInput, GetPatchBaselineForPatchGroupOutput, _stream.Readable>;
    constructor(input: GetPatchBaselineForPatchGroupInput);
    resolveMiddleware(clientStack: __aws_sdk_middleware_stack.MiddlewareStack<InputTypesUnion, OutputTypesUnion, _stream.Readable>, configuration: SSMResolvedConfiguration): __aws_sdk_types.Handler<GetPatchBaselineForPatchGroupInput, GetPatchBaselineForPatchGroupOutput>;
}
