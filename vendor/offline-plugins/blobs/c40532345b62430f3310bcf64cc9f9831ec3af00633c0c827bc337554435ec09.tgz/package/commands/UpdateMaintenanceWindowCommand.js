"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const __aws_sdk_middleware_stack = require("@aws-sdk/middleware-stack");
const UpdateMaintenanceWindow_1 = require("../model/operations/UpdateMaintenanceWindow");
class UpdateMaintenanceWindowCommand {
    constructor(input) {
        this.input = input;
        this.model = UpdateMaintenanceWindow_1.UpdateMaintenanceWindow;
        this.middlewareStack = new __aws_sdk_middleware_stack.MiddlewareStack();
    }
    resolveMiddleware(clientStack, configuration) {
        const { handler } = configuration;
        const stack = clientStack.concat(this.middlewareStack);
        const handlerExecutionContext = {
            logger: {},
            model: this.model
        };
        return stack.resolve(handler(handlerExecutionContext), handlerExecutionContext);
    }
}
exports.UpdateMaintenanceWindowCommand = UpdateMaintenanceWindowCommand;
//# sourceMappingURL=UpdateMaintenanceWindowCommand.js.map