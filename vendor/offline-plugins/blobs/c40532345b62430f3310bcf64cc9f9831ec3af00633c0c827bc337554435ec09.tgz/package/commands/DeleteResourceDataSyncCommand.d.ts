/// <reference types="node" />
import * as __aws_sdk_middleware_stack from "@aws-sdk/middleware-stack";
import * as __aws_sdk_types from "@aws-sdk/types";
import * as _stream from "stream";
import { InputTypesUnion } from "../types/InputTypesUnion";
import { OutputTypesUnion } from "../types/OutputTypesUnion";
import { DeleteResourceDataSyncInput } from "../types/DeleteResourceDataSyncInput";
import { DeleteResourceDataSyncOutput } from "../types/DeleteResourceDataSyncOutput";
import { SSMResolvedConfiguration } from "../SSMConfiguration";
export * from "../types/DeleteResourceDataSyncInput";
export * from "../types/DeleteResourceDataSyncOutput";
export * from "../types/DeleteResourceDataSyncExceptionsUnion";
export declare class DeleteResourceDataSyncCommand implements __aws_sdk_types.Command<InputTypesUnion, DeleteResourceDataSyncInput, OutputTypesUnion, DeleteResourceDataSyncOutput, SSMResolvedConfiguration, _stream.Readable> {
    readonly input: DeleteResourceDataSyncInput;
    readonly model: __aws_sdk_types.OperationModel;
    readonly middlewareStack: __aws_sdk_middleware_stack.MiddlewareStack<DeleteResourceDataSyncInput, DeleteResourceDataSyncOutput, _stream.Readable>;
    constructor(input: DeleteResourceDataSyncInput);
    resolveMiddleware(clientStack: __aws_sdk_middleware_stack.MiddlewareStack<InputTypesUnion, OutputTypesUnion, _stream.Readable>, configuration: SSMResolvedConfiguration): __aws_sdk_types.Handler<DeleteResourceDataSyncInput, DeleteResourceDataSyncOutput>;
}
