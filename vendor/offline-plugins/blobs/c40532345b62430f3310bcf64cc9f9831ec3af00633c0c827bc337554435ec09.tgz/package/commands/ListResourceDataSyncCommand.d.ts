/// <reference types="node" />
import * as __aws_sdk_middleware_stack from "@aws-sdk/middleware-stack";
import * as __aws_sdk_types from "@aws-sdk/types";
import * as _stream from "stream";
import { InputTypesUnion } from "../types/InputTypesUnion";
import { OutputTypesUnion } from "../types/OutputTypesUnion";
import { ListResourceDataSyncInput } from "../types/ListResourceDataSyncInput";
import { ListResourceDataSyncOutput } from "../types/ListResourceDataSyncOutput";
import { SSMResolvedConfiguration } from "../SSMConfiguration";
export * from "../types/ListResourceDataSyncInput";
export * from "../types/ListResourceDataSyncOutput";
export * from "../types/ListResourceDataSyncExceptionsUnion";
export declare class ListResourceDataSyncCommand implements __aws_sdk_types.Command<InputTypesUnion, ListResourceDataSyncInput, OutputTypesUnion, ListResourceDataSyncOutput, SSMResolvedConfiguration, _stream.Readable> {
    readonly input: ListResourceDataSyncInput;
    readonly model: __aws_sdk_types.OperationModel;
    readonly middlewareStack: __aws_sdk_middleware_stack.MiddlewareStack<ListResourceDataSyncInput, ListResourceDataSyncOutput, _stream.Readable>;
    constructor(input: ListResourceDataSyncInput);
    resolveMiddleware(clientStack: __aws_sdk_middleware_stack.MiddlewareStack<InputTypesUnion, OutputTypesUnion, _stream.Readable>, configuration: SSMResolvedConfiguration): __aws_sdk_types.Handler<ListResourceDataSyncInput, ListResourceDataSyncOutput>;
}
