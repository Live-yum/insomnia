/// <reference types="node" />
import * as __aws_sdk_middleware_stack from "@aws-sdk/middleware-stack";
import * as __aws_sdk_types from "@aws-sdk/types";
import * as _stream from "stream";
import { InputTypesUnion } from "../types/InputTypesUnion";
import { OutputTypesUnion } from "../types/OutputTypesUnion";
import { ListResourceComplianceSummariesInput } from "../types/ListResourceComplianceSummariesInput";
import { ListResourceComplianceSummariesOutput } from "../types/ListResourceComplianceSummariesOutput";
import { SSMResolvedConfiguration } from "../SSMConfiguration";
export * from "../types/ListResourceComplianceSummariesInput";
export * from "../types/ListResourceComplianceSummariesOutput";
export * from "../types/ListResourceComplianceSummariesExceptionsUnion";
export declare class ListResourceComplianceSummariesCommand implements __aws_sdk_types.Command<InputTypesUnion, ListResourceComplianceSummariesInput, OutputTypesUnion, ListResourceComplianceSummariesOutput, SSMResolvedConfiguration, _stream.Readable> {
    readonly input: ListResourceComplianceSummariesInput;
    readonly model: __aws_sdk_types.OperationModel;
    readonly middlewareStack: __aws_sdk_middleware_stack.MiddlewareStack<ListResourceComplianceSummariesInput, ListResourceComplianceSummariesOutput, _stream.Readable>;
    constructor(input: ListResourceComplianceSummariesInput);
    resolveMiddleware(clientStack: __aws_sdk_middleware_stack.MiddlewareStack<InputTypesUnion, OutputTypesUnion, _stream.Readable>, configuration: SSMResolvedConfiguration): __aws_sdk_types.Handler<ListResourceComplianceSummariesInput, ListResourceComplianceSummariesOutput>;
}
