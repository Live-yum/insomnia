"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const __aws_sdk_middleware_stack = require("@aws-sdk/middleware-stack");
const ListCommands_1 = require("../model/operations/ListCommands");
class ListCommandsCommand {
    constructor(input) {
        this.input = input;
        this.model = ListCommands_1.ListCommands;
        this.middlewareStack = new __aws_sdk_middleware_stack.MiddlewareStack();
    }
    resolveMiddleware(clientStack, configuration) {
        const { handler } = configuration;
        const stack = clientStack.concat(this.middlewareStack);
        const handlerExecutionContext = {
            logger: {},
            model: this.model
        };
        return stack.resolve(handler(handlerExecutionContext), handlerExecutionContext);
    }
}
exports.ListCommandsCommand = ListCommandsCommand;
//# sourceMappingURL=ListCommandsCommand.js.map