/// <reference types="node" />
import * as __aws_sdk_middleware_stack from "@aws-sdk/middleware-stack";
import * as __aws_sdk_types from "@aws-sdk/types";
import * as _stream from "stream";
import { InputTypesUnion } from "../types/InputTypesUnion";
import { OutputTypesUnion } from "../types/OutputTypesUnion";
import { UpdateAssociationStatusInput } from "../types/UpdateAssociationStatusInput";
import { UpdateAssociationStatusOutput } from "../types/UpdateAssociationStatusOutput";
import { SSMResolvedConfiguration } from "../SSMConfiguration";
export * from "../types/UpdateAssociationStatusInput";
export * from "../types/UpdateAssociationStatusOutput";
export * from "../types/UpdateAssociationStatusExceptionsUnion";
export declare class UpdateAssociationStatusCommand implements __aws_sdk_types.Command<InputTypesUnion, UpdateAssociationStatusInput, OutputTypesUnion, UpdateAssociationStatusOutput, SSMResolvedConfiguration, _stream.Readable> {
    readonly input: UpdateAssociationStatusInput;
    readonly model: __aws_sdk_types.OperationModel;
    readonly middlewareStack: __aws_sdk_middleware_stack.MiddlewareStack<UpdateAssociationStatusInput, UpdateAssociationStatusOutput, _stream.Readable>;
    constructor(input: UpdateAssociationStatusInput);
    resolveMiddleware(clientStack: __aws_sdk_middleware_stack.MiddlewareStack<InputTypesUnion, OutputTypesUnion, _stream.Readable>, configuration: SSMResolvedConfiguration): __aws_sdk_types.Handler<UpdateAssociationStatusInput, UpdateAssociationStatusOutput>;
}
