/// <reference types="node" />
import * as __aws_sdk_middleware_stack from "@aws-sdk/middleware-stack";
import * as __aws_sdk_types from "@aws-sdk/types";
import * as _stream from "stream";
import { InputTypesUnion } from "../types/InputTypesUnion";
import { OutputTypesUnion } from "../types/OutputTypesUnion";
import { DeleteActivationInput } from "../types/DeleteActivationInput";
import { DeleteActivationOutput } from "../types/DeleteActivationOutput";
import { SSMResolvedConfiguration } from "../SSMConfiguration";
export * from "../types/DeleteActivationInput";
export * from "../types/DeleteActivationOutput";
export * from "../types/DeleteActivationExceptionsUnion";
export declare class DeleteActivationCommand implements __aws_sdk_types.Command<InputTypesUnion, DeleteActivationInput, OutputTypesUnion, DeleteActivationOutput, SSMResolvedConfiguration, _stream.Readable> {
    readonly input: DeleteActivationInput;
    readonly model: __aws_sdk_types.OperationModel;
    readonly middlewareStack: __aws_sdk_middleware_stack.MiddlewareStack<DeleteActivationInput, DeleteActivationOutput, _stream.Readable>;
    constructor(input: DeleteActivationInput);
    resolveMiddleware(clientStack: __aws_sdk_middleware_stack.MiddlewareStack<InputTypesUnion, OutputTypesUnion, _stream.Readable>, configuration: SSMResolvedConfiguration): __aws_sdk_types.Handler<DeleteActivationInput, DeleteActivationOutput>;
}
