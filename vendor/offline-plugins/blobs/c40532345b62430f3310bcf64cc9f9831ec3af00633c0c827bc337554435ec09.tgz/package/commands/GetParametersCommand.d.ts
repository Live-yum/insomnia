/// <reference types="node" />
import * as __aws_sdk_middleware_stack from "@aws-sdk/middleware-stack";
import * as __aws_sdk_types from "@aws-sdk/types";
import * as _stream from "stream";
import { InputTypesUnion } from "../types/InputTypesUnion";
import { OutputTypesUnion } from "../types/OutputTypesUnion";
import { GetParametersInput } from "../types/GetParametersInput";
import { GetParametersOutput } from "../types/GetParametersOutput";
import { SSMResolvedConfiguration } from "../SSMConfiguration";
export * from "../types/GetParametersInput";
export * from "../types/GetParametersOutput";
export * from "../types/GetParametersExceptionsUnion";
export declare class GetParametersCommand implements __aws_sdk_types.Command<InputTypesUnion, GetParametersInput, OutputTypesUnion, GetParametersOutput, SSMResolvedConfiguration, _stream.Readable> {
    readonly input: GetParametersInput;
    readonly model: __aws_sdk_types.OperationModel;
    readonly middlewareStack: __aws_sdk_middleware_stack.MiddlewareStack<GetParametersInput, GetParametersOutput, _stream.Readable>;
    constructor(input: GetParametersInput);
    resolveMiddleware(clientStack: __aws_sdk_middleware_stack.MiddlewareStack<InputTypesUnion, OutputTypesUnion, _stream.Readable>, configuration: SSMResolvedConfiguration): __aws_sdk_types.Handler<GetParametersInput, GetParametersOutput>;
}
