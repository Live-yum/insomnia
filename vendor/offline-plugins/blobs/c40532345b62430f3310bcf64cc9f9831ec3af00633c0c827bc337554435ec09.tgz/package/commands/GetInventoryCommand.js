"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const __aws_sdk_middleware_stack = require("@aws-sdk/middleware-stack");
const GetInventory_1 = require("../model/operations/GetInventory");
class GetInventoryCommand {
    constructor(input) {
        this.input = input;
        this.model = GetInventory_1.GetInventory;
        this.middlewareStack = new __aws_sdk_middleware_stack.MiddlewareStack();
    }
    resolveMiddleware(clientStack, configuration) {
        const { handler } = configuration;
        const stack = clientStack.concat(this.middlewareStack);
        const handlerExecutionContext = {
            logger: {},
            model: this.model
        };
        return stack.resolve(handler(handlerExecutionContext), handlerExecutionContext);
    }
}
exports.GetInventoryCommand = GetInventoryCommand;
//# sourceMappingURL=GetInventoryCommand.js.map