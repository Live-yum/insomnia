"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const __aws_sdk_middleware_stack = require("@aws-sdk/middleware-stack");
const DescribeInventoryDeletions_1 = require("../model/operations/DescribeInventoryDeletions");
class DescribeInventoryDeletionsCommand {
    constructor(input) {
        this.input = input;
        this.model = DescribeInventoryDeletions_1.DescribeInventoryDeletions;
        this.middlewareStack = new __aws_sdk_middleware_stack.MiddlewareStack();
    }
    resolveMiddleware(clientStack, configuration) {
        const { handler } = configuration;
        const stack = clientStack.concat(this.middlewareStack);
        const handlerExecutionContext = {
            logger: {},
            model: this.model
        };
        return stack.resolve(handler(handlerExecutionContext), handlerExecutionContext);
    }
}
exports.DescribeInventoryDeletionsCommand = DescribeInventoryDeletionsCommand;
//# sourceMappingURL=DescribeInventoryDeletionsCommand.js.map