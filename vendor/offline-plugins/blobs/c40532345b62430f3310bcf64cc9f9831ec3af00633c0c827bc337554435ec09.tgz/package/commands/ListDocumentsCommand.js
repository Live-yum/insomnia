"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const __aws_sdk_middleware_stack = require("@aws-sdk/middleware-stack");
const ListDocuments_1 = require("../model/operations/ListDocuments");
class ListDocumentsCommand {
    constructor(input) {
        this.input = input;
        this.model = ListDocuments_1.ListDocuments;
        this.middlewareStack = new __aws_sdk_middleware_stack.MiddlewareStack();
    }
    resolveMiddleware(clientStack, configuration) {
        const { handler } = configuration;
        const stack = clientStack.concat(this.middlewareStack);
        const handlerExecutionContext = {
            logger: {},
            model: this.model
        };
        return stack.resolve(handler(handlerExecutionContext), handlerExecutionContext);
    }
}
exports.ListDocumentsCommand = ListDocumentsCommand;
//# sourceMappingURL=ListDocumentsCommand.js.map