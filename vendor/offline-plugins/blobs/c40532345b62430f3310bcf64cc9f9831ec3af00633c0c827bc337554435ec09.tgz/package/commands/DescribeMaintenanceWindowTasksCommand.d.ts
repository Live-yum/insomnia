/// <reference types="node" />
import * as __aws_sdk_middleware_stack from "@aws-sdk/middleware-stack";
import * as __aws_sdk_types from "@aws-sdk/types";
import * as _stream from "stream";
import { InputTypesUnion } from "../types/InputTypesUnion";
import { OutputTypesUnion } from "../types/OutputTypesUnion";
import { DescribeMaintenanceWindowTasksInput } from "../types/DescribeMaintenanceWindowTasksInput";
import { DescribeMaintenanceWindowTasksOutput } from "../types/DescribeMaintenanceWindowTasksOutput";
import { SSMResolvedConfiguration } from "../SSMConfiguration";
export * from "../types/DescribeMaintenanceWindowTasksInput";
export * from "../types/DescribeMaintenanceWindowTasksOutput";
export * from "../types/DescribeMaintenanceWindowTasksExceptionsUnion";
export declare class DescribeMaintenanceWindowTasksCommand implements __aws_sdk_types.Command<InputTypesUnion, DescribeMaintenanceWindowTasksInput, OutputTypesUnion, DescribeMaintenanceWindowTasksOutput, SSMResolvedConfiguration, _stream.Readable> {
    readonly input: DescribeMaintenanceWindowTasksInput;
    readonly model: __aws_sdk_types.OperationModel;
    readonly middlewareStack: __aws_sdk_middleware_stack.MiddlewareStack<DescribeMaintenanceWindowTasksInput, DescribeMaintenanceWindowTasksOutput, _stream.Readable>;
    constructor(input: DescribeMaintenanceWindowTasksInput);
    resolveMiddleware(clientStack: __aws_sdk_middleware_stack.MiddlewareStack<InputTypesUnion, OutputTypesUnion, _stream.Readable>, configuration: SSMResolvedConfiguration): __aws_sdk_types.Handler<DescribeMaintenanceWindowTasksInput, DescribeMaintenanceWindowTasksOutput>;
}
