"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const __aws_sdk_middleware_stack = require("@aws-sdk/middleware-stack");
const RemoveTagsFromResource_1 = require("../model/operations/RemoveTagsFromResource");
class RemoveTagsFromResourceCommand {
    constructor(input) {
        this.input = input;
        this.model = RemoveTagsFromResource_1.RemoveTagsFromResource;
        this.middlewareStack = new __aws_sdk_middleware_stack.MiddlewareStack();
    }
    resolveMiddleware(clientStack, configuration) {
        const { handler } = configuration;
        const stack = clientStack.concat(this.middlewareStack);
        const handlerExecutionContext = {
            logger: {},
            model: this.model
        };
        return stack.resolve(handler(handlerExecutionContext), handlerExecutionContext);
    }
}
exports.RemoveTagsFromResourceCommand = RemoveTagsFromResourceCommand;
//# sourceMappingURL=RemoveTagsFromResourceCommand.js.map