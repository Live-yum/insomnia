/// <reference types="node" />
import * as __aws_sdk_middleware_stack from "@aws-sdk/middleware-stack";
import * as __aws_sdk_types from "@aws-sdk/types";
import * as _stream from "stream";
import { InputTypesUnion } from "../types/InputTypesUnion";
import { OutputTypesUnion } from "../types/OutputTypesUnion";
import { GetAutomationExecutionInput } from "../types/GetAutomationExecutionInput";
import { GetAutomationExecutionOutput } from "../types/GetAutomationExecutionOutput";
import { SSMResolvedConfiguration } from "../SSMConfiguration";
export * from "../types/GetAutomationExecutionInput";
export * from "../types/GetAutomationExecutionOutput";
export * from "../types/GetAutomationExecutionExceptionsUnion";
export declare class GetAutomationExecutionCommand implements __aws_sdk_types.Command<InputTypesUnion, GetAutomationExecutionInput, OutputTypesUnion, GetAutomationExecutionOutput, SSMResolvedConfiguration, _stream.Readable> {
    readonly input: GetAutomationExecutionInput;
    readonly model: __aws_sdk_types.OperationModel;
    readonly middlewareStack: __aws_sdk_middleware_stack.MiddlewareStack<GetAutomationExecutionInput, GetAutomationExecutionOutput, _stream.Readable>;
    constructor(input: GetAutomationExecutionInput);
    resolveMiddleware(clientStack: __aws_sdk_middleware_stack.MiddlewareStack<InputTypesUnion, OutputTypesUnion, _stream.Readable>, configuration: SSMResolvedConfiguration): __aws_sdk_types.Handler<GetAutomationExecutionInput, GetAutomationExecutionOutput>;
}
