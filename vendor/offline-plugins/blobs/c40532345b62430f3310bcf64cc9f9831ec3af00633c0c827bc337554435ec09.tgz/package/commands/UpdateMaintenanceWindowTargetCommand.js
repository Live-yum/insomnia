"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const __aws_sdk_middleware_stack = require("@aws-sdk/middleware-stack");
const UpdateMaintenanceWindowTarget_1 = require("../model/operations/UpdateMaintenanceWindowTarget");
class UpdateMaintenanceWindowTargetCommand {
    constructor(input) {
        this.input = input;
        this.model = UpdateMaintenanceWindowTarget_1.UpdateMaintenanceWindowTarget;
        this.middlewareStack = new __aws_sdk_middleware_stack.MiddlewareStack();
    }
    resolveMiddleware(clientStack, configuration) {
        const { handler } = configuration;
        const stack = clientStack.concat(this.middlewareStack);
        const handlerExecutionContext = {
            logger: {},
            model: this.model
        };
        return stack.resolve(handler(handlerExecutionContext), handlerExecutionContext);
    }
}
exports.UpdateMaintenanceWindowTargetCommand = UpdateMaintenanceWindowTargetCommand;
//# sourceMappingURL=UpdateMaintenanceWindowTargetCommand.js.map