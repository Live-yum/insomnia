"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const __aws_sdk_middleware_stack = require("@aws-sdk/middleware-stack");
const UpdateAssociationStatus_1 = require("../model/operations/UpdateAssociationStatus");
class UpdateAssociationStatusCommand {
    constructor(input) {
        this.input = input;
        this.model = UpdateAssociationStatus_1.UpdateAssociationStatus;
        this.middlewareStack = new __aws_sdk_middleware_stack.MiddlewareStack();
    }
    resolveMiddleware(clientStack, configuration) {
        const { handler } = configuration;
        const stack = clientStack.concat(this.middlewareStack);
        const handlerExecutionContext = {
            logger: {},
            model: this.model
        };
        return stack.resolve(handler(handlerExecutionContext), handlerExecutionContext);
    }
}
exports.UpdateAssociationStatusCommand = UpdateAssociationStatusCommand;
//# sourceMappingURL=UpdateAssociationStatusCommand.js.map