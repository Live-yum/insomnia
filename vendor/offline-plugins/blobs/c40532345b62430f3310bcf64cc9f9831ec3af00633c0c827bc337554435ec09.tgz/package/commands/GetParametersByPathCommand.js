"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const __aws_sdk_middleware_stack = require("@aws-sdk/middleware-stack");
const GetParametersByPath_1 = require("../model/operations/GetParametersByPath");
class GetParametersByPathCommand {
    constructor(input) {
        this.input = input;
        this.model = GetParametersByPath_1.GetParametersByPath;
        this.middlewareStack = new __aws_sdk_middleware_stack.MiddlewareStack();
    }
    resolveMiddleware(clientStack, configuration) {
        const { handler } = configuration;
        const stack = clientStack.concat(this.middlewareStack);
        const handlerExecutionContext = {
            logger: {},
            model: this.model
        };
        return stack.resolve(handler(handlerExecutionContext), handlerExecutionContext);
    }
}
exports.GetParametersByPathCommand = GetParametersByPathCommand;
//# sourceMappingURL=GetParametersByPathCommand.js.map