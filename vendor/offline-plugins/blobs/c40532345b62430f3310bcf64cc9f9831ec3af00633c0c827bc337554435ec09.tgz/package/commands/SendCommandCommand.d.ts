/// <reference types="node" />
import * as __aws_sdk_middleware_stack from "@aws-sdk/middleware-stack";
import * as __aws_sdk_types from "@aws-sdk/types";
import * as _stream from "stream";
import { InputTypesUnion } from "../types/InputTypesUnion";
import { OutputTypesUnion } from "../types/OutputTypesUnion";
import { SendCommandInput } from "../types/SendCommandInput";
import { SendCommandOutput } from "../types/SendCommandOutput";
import { SSMResolvedConfiguration } from "../SSMConfiguration";
export * from "../types/SendCommandInput";
export * from "../types/SendCommandOutput";
export * from "../types/SendCommandExceptionsUnion";
export declare class SendCommandCommand implements __aws_sdk_types.Command<InputTypesUnion, SendCommandInput, OutputTypesUnion, SendCommandOutput, SSMResolvedConfiguration, _stream.Readable> {
    readonly input: SendCommandInput;
    readonly model: __aws_sdk_types.OperationModel;
    readonly middlewareStack: __aws_sdk_middleware_stack.MiddlewareStack<SendCommandInput, SendCommandOutput, _stream.Readable>;
    constructor(input: SendCommandInput);
    resolveMiddleware(clientStack: __aws_sdk_middleware_stack.MiddlewareStack<InputTypesUnion, OutputTypesUnion, _stream.Readable>, configuration: SSMResolvedConfiguration): __aws_sdk_types.Handler<SendCommandInput, SendCommandOutput>;
}
