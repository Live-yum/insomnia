"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const __aws_sdk_middleware_stack = require("@aws-sdk/middleware-stack");
const DescribePatchGroups_1 = require("../model/operations/DescribePatchGroups");
class DescribePatchGroupsCommand {
    constructor(input) {
        this.input = input;
        this.model = DescribePatchGroups_1.DescribePatchGroups;
        this.middlewareStack = new __aws_sdk_middleware_stack.MiddlewareStack();
    }
    resolveMiddleware(clientStack, configuration) {
        const { handler } = configuration;
        const stack = clientStack.concat(this.middlewareStack);
        const handlerExecutionContext = {
            logger: {},
            model: this.model
        };
        return stack.resolve(handler(handlerExecutionContext), handlerExecutionContext);
    }
}
exports.DescribePatchGroupsCommand = DescribePatchGroupsCommand;
//# sourceMappingURL=DescribePatchGroupsCommand.js.map