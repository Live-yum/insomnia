"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const __aws_sdk_middleware_stack = require("@aws-sdk/middleware-stack");
const DeregisterTaskFromMaintenanceWindow_1 = require("../model/operations/DeregisterTaskFromMaintenanceWindow");
class DeregisterTaskFromMaintenanceWindowCommand {
    constructor(input) {
        this.input = input;
        this.model = DeregisterTaskFromMaintenanceWindow_1.DeregisterTaskFromMaintenanceWindow;
        this.middlewareStack = new __aws_sdk_middleware_stack.MiddlewareStack();
    }
    resolveMiddleware(clientStack, configuration) {
        const { handler } = configuration;
        const stack = clientStack.concat(this.middlewareStack);
        const handlerExecutionContext = {
            logger: {},
            model: this.model
        };
        return stack.resolve(handler(handlerExecutionContext), handlerExecutionContext);
    }
}
exports.DeregisterTaskFromMaintenanceWindowCommand = DeregisterTaskFromMaintenanceWindowCommand;
//# sourceMappingURL=DeregisterTaskFromMaintenanceWindowCommand.js.map