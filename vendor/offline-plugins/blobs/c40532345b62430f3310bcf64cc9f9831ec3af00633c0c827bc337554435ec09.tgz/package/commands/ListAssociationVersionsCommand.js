"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const __aws_sdk_middleware_stack = require("@aws-sdk/middleware-stack");
const ListAssociationVersions_1 = require("../model/operations/ListAssociationVersions");
class ListAssociationVersionsCommand {
    constructor(input) {
        this.input = input;
        this.model = ListAssociationVersions_1.ListAssociationVersions;
        this.middlewareStack = new __aws_sdk_middleware_stack.MiddlewareStack();
    }
    resolveMiddleware(clientStack, configuration) {
        const { handler } = configuration;
        const stack = clientStack.concat(this.middlewareStack);
        const handlerExecutionContext = {
            logger: {},
            model: this.model
        };
        return stack.resolve(handler(handlerExecutionContext), handlerExecutionContext);
    }
}
exports.ListAssociationVersionsCommand = ListAssociationVersionsCommand;
//# sourceMappingURL=ListAssociationVersionsCommand.js.map