/// <reference types="node" />
import * as __aws_sdk_middleware_stack from "@aws-sdk/middleware-stack";
import * as __aws_sdk_types from "@aws-sdk/types";
import * as _stream from "stream";
import { InputTypesUnion } from "../types/InputTypesUnion";
import { OutputTypesUnion } from "../types/OutputTypesUnion";
import { GetCommandInvocationInput } from "../types/GetCommandInvocationInput";
import { GetCommandInvocationOutput } from "../types/GetCommandInvocationOutput";
import { SSMResolvedConfiguration } from "../SSMConfiguration";
export * from "../types/GetCommandInvocationInput";
export * from "../types/GetCommandInvocationOutput";
export * from "../types/GetCommandInvocationExceptionsUnion";
export declare class GetCommandInvocationCommand implements __aws_sdk_types.Command<InputTypesUnion, GetCommandInvocationInput, OutputTypesUnion, GetCommandInvocationOutput, SSMResolvedConfiguration, _stream.Readable> {
    readonly input: GetCommandInvocationInput;
    readonly model: __aws_sdk_types.OperationModel;
    readonly middlewareStack: __aws_sdk_middleware_stack.MiddlewareStack<GetCommandInvocationInput, GetCommandInvocationOutput, _stream.Readable>;
    constructor(input: GetCommandInvocationInput);
    resolveMiddleware(clientStack: __aws_sdk_middleware_stack.MiddlewareStack<InputTypesUnion, OutputTypesUnion, _stream.Readable>, configuration: SSMResolvedConfiguration): __aws_sdk_types.Handler<GetCommandInvocationInput, GetCommandInvocationOutput>;
}
