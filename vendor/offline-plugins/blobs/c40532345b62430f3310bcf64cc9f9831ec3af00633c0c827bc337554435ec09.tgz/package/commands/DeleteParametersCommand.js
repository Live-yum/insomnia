"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const __aws_sdk_middleware_stack = require("@aws-sdk/middleware-stack");
const DeleteParameters_1 = require("../model/operations/DeleteParameters");
class DeleteParametersCommand {
    constructor(input) {
        this.input = input;
        this.model = DeleteParameters_1.DeleteParameters;
        this.middlewareStack = new __aws_sdk_middleware_stack.MiddlewareStack();
    }
    resolveMiddleware(clientStack, configuration) {
        const { handler } = configuration;
        const stack = clientStack.concat(this.middlewareStack);
        const handlerExecutionContext = {
            logger: {},
            model: this.model
        };
        return stack.resolve(handler(handlerExecutionContext), handlerExecutionContext);
    }
}
exports.DeleteParametersCommand = DeleteParametersCommand;
//# sourceMappingURL=DeleteParametersCommand.js.map