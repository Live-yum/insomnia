/// <reference types="node" />
import * as __aws_sdk_middleware_stack from "@aws-sdk/middleware-stack";
import * as __aws_sdk_types from "@aws-sdk/types";
import * as _stream from "stream";
import { InputTypesUnion } from "../types/InputTypesUnion";
import { OutputTypesUnion } from "../types/OutputTypesUnion";
import { TerminateSessionInput } from "../types/TerminateSessionInput";
import { TerminateSessionOutput } from "../types/TerminateSessionOutput";
import { SSMResolvedConfiguration } from "../SSMConfiguration";
export * from "../types/TerminateSessionInput";
export * from "../types/TerminateSessionOutput";
export * from "../types/TerminateSessionExceptionsUnion";
export declare class TerminateSessionCommand implements __aws_sdk_types.Command<InputTypesUnion, TerminateSessionInput, OutputTypesUnion, TerminateSessionOutput, SSMResolvedConfiguration, _stream.Readable> {
    readonly input: TerminateSessionInput;
    readonly model: __aws_sdk_types.OperationModel;
    readonly middlewareStack: __aws_sdk_middleware_stack.MiddlewareStack<TerminateSessionInput, TerminateSessionOutput, _stream.Readable>;
    constructor(input: TerminateSessionInput);
    resolveMiddleware(clientStack: __aws_sdk_middleware_stack.MiddlewareStack<InputTypesUnion, OutputTypesUnion, _stream.Readable>, configuration: SSMResolvedConfiguration): __aws_sdk_types.Handler<TerminateSessionInput, TerminateSessionOutput>;
}
