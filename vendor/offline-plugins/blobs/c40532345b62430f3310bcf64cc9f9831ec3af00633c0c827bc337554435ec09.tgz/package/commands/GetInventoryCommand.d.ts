/// <reference types="node" />
import * as __aws_sdk_middleware_stack from "@aws-sdk/middleware-stack";
import * as __aws_sdk_types from "@aws-sdk/types";
import * as _stream from "stream";
import { InputTypesUnion } from "../types/InputTypesUnion";
import { OutputTypesUnion } from "../types/OutputTypesUnion";
import { GetInventoryInput } from "../types/GetInventoryInput";
import { GetInventoryOutput } from "../types/GetInventoryOutput";
import { SSMResolvedConfiguration } from "../SSMConfiguration";
export * from "../types/GetInventoryInput";
export * from "../types/GetInventoryOutput";
export * from "../types/GetInventoryExceptionsUnion";
export declare class GetInventoryCommand implements __aws_sdk_types.Command<InputTypesUnion, GetInventoryInput, OutputTypesUnion, GetInventoryOutput, SSMResolvedConfiguration, _stream.Readable> {
    readonly input: GetInventoryInput;
    readonly model: __aws_sdk_types.OperationModel;
    readonly middlewareStack: __aws_sdk_middleware_stack.MiddlewareStack<GetInventoryInput, GetInventoryOutput, _stream.Readable>;
    constructor(input: GetInventoryInput);
    resolveMiddleware(clientStack: __aws_sdk_middleware_stack.MiddlewareStack<InputTypesUnion, OutputTypesUnion, _stream.Readable>, configuration: SSMResolvedConfiguration): __aws_sdk_types.Handler<GetInventoryInput, GetInventoryOutput>;
}
