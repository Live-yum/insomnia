"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const __aws_sdk_middleware_stack = require("@aws-sdk/middleware-stack");
const DescribePatchProperties_1 = require("../model/operations/DescribePatchProperties");
class DescribePatchPropertiesCommand {
    constructor(input) {
        this.input = input;
        this.model = DescribePatchProperties_1.DescribePatchProperties;
        this.middlewareStack = new __aws_sdk_middleware_stack.MiddlewareStack();
    }
    resolveMiddleware(clientStack, configuration) {
        const { handler } = configuration;
        const stack = clientStack.concat(this.middlewareStack);
        const handlerExecutionContext = {
            logger: {},
            model: this.model
        };
        return stack.resolve(handler(handlerExecutionContext), handlerExecutionContext);
    }
}
exports.DescribePatchPropertiesCommand = DescribePatchPropertiesCommand;
//# sourceMappingURL=DescribePatchPropertiesCommand.js.map