/// <reference types="node" />
import * as __aws_sdk_middleware_stack from "@aws-sdk/middleware-stack";
import * as __aws_sdk_types from "@aws-sdk/types";
import * as _stream from "stream";
import { InputTypesUnion } from "../types/InputTypesUnion";
import { OutputTypesUnion } from "../types/OutputTypesUnion";
import { CreateDocumentInput } from "../types/CreateDocumentInput";
import { CreateDocumentOutput } from "../types/CreateDocumentOutput";
import { SSMResolvedConfiguration } from "../SSMConfiguration";
export * from "../types/CreateDocumentInput";
export * from "../types/CreateDocumentOutput";
export * from "../types/CreateDocumentExceptionsUnion";
export declare class CreateDocumentCommand implements __aws_sdk_types.Command<InputTypesUnion, CreateDocumentInput, OutputTypesUnion, CreateDocumentOutput, SSMResolvedConfiguration, _stream.Readable> {
    readonly input: CreateDocumentInput;
    readonly model: __aws_sdk_types.OperationModel;
    readonly middlewareStack: __aws_sdk_middleware_stack.MiddlewareStack<CreateDocumentInput, CreateDocumentOutput, _stream.Readable>;
    constructor(input: CreateDocumentInput);
    resolveMiddleware(clientStack: __aws_sdk_middleware_stack.MiddlewareStack<InputTypesUnion, OutputTypesUnion, _stream.Readable>, configuration: SSMResolvedConfiguration): __aws_sdk_types.Handler<CreateDocumentInput, CreateDocumentOutput>;
}
