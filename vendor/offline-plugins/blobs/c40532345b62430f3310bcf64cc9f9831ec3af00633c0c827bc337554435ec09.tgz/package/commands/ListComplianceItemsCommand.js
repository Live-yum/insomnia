"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const __aws_sdk_middleware_stack = require("@aws-sdk/middleware-stack");
const ListComplianceItems_1 = require("../model/operations/ListComplianceItems");
class ListComplianceItemsCommand {
    constructor(input) {
        this.input = input;
        this.model = ListComplianceItems_1.ListComplianceItems;
        this.middlewareStack = new __aws_sdk_middleware_stack.MiddlewareStack();
    }
    resolveMiddleware(clientStack, configuration) {
        const { handler } = configuration;
        const stack = clientStack.concat(this.middlewareStack);
        const handlerExecutionContext = {
            logger: {},
            model: this.model
        };
        return stack.resolve(handler(handlerExecutionContext), handlerExecutionContext);
    }
}
exports.ListComplianceItemsCommand = ListComplianceItemsCommand;
//# sourceMappingURL=ListComplianceItemsCommand.js.map