/// <reference types="node" />
import * as __aws_sdk_middleware_stack from "@aws-sdk/middleware-stack";
import * as __aws_sdk_types from "@aws-sdk/types";
import * as _stream from "stream";
import { InputTypesUnion } from "../types/InputTypesUnion";
import { OutputTypesUnion } from "../types/OutputTypesUnion";
import { DescribeAssociationExecutionTargetsInput } from "../types/DescribeAssociationExecutionTargetsInput";
import { DescribeAssociationExecutionTargetsOutput } from "../types/DescribeAssociationExecutionTargetsOutput";
import { SSMResolvedConfiguration } from "../SSMConfiguration";
export * from "../types/DescribeAssociationExecutionTargetsInput";
export * from "../types/DescribeAssociationExecutionTargetsOutput";
export * from "../types/DescribeAssociationExecutionTargetsExceptionsUnion";
export declare class DescribeAssociationExecutionTargetsCommand implements __aws_sdk_types.Command<InputTypesUnion, DescribeAssociationExecutionTargetsInput, OutputTypesUnion, DescribeAssociationExecutionTargetsOutput, SSMResolvedConfiguration, _stream.Readable> {
    readonly input: DescribeAssociationExecutionTargetsInput;
    readonly model: __aws_sdk_types.OperationModel;
    readonly middlewareStack: __aws_sdk_middleware_stack.MiddlewareStack<DescribeAssociationExecutionTargetsInput, DescribeAssociationExecutionTargetsOutput, _stream.Readable>;
    constructor(input: DescribeAssociationExecutionTargetsInput);
    resolveMiddleware(clientStack: __aws_sdk_middleware_stack.MiddlewareStack<InputTypesUnion, OutputTypesUnion, _stream.Readable>, configuration: SSMResolvedConfiguration): __aws_sdk_types.Handler<DescribeAssociationExecutionTargetsInput, DescribeAssociationExecutionTargetsOutput>;
}
