/// <reference types="node" />
import * as __aws_sdk_middleware_stack from "@aws-sdk/middleware-stack";
import * as __aws_sdk_types from "@aws-sdk/types";
import * as _stream from "stream";
import { InputTypesUnion } from "../types/InputTypesUnion";
import { OutputTypesUnion } from "../types/OutputTypesUnion";
import { RemoveTagsFromResourceInput } from "../types/RemoveTagsFromResourceInput";
import { RemoveTagsFromResourceOutput } from "../types/RemoveTagsFromResourceOutput";
import { SSMResolvedConfiguration } from "../SSMConfiguration";
export * from "../types/RemoveTagsFromResourceInput";
export * from "../types/RemoveTagsFromResourceOutput";
export * from "../types/RemoveTagsFromResourceExceptionsUnion";
export declare class RemoveTagsFromResourceCommand implements __aws_sdk_types.Command<InputTypesUnion, RemoveTagsFromResourceInput, OutputTypesUnion, RemoveTagsFromResourceOutput, SSMResolvedConfiguration, _stream.Readable> {
    readonly input: RemoveTagsFromResourceInput;
    readonly model: __aws_sdk_types.OperationModel;
    readonly middlewareStack: __aws_sdk_middleware_stack.MiddlewareStack<RemoveTagsFromResourceInput, RemoveTagsFromResourceOutput, _stream.Readable>;
    constructor(input: RemoveTagsFromResourceInput);
    resolveMiddleware(clientStack: __aws_sdk_middleware_stack.MiddlewareStack<InputTypesUnion, OutputTypesUnion, _stream.Readable>, configuration: SSMResolvedConfiguration): __aws_sdk_types.Handler<RemoveTagsFromResourceInput, RemoveTagsFromResourceOutput>;
}
