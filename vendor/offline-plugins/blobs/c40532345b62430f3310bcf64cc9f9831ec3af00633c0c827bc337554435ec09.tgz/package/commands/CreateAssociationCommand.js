"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const __aws_sdk_middleware_stack = require("@aws-sdk/middleware-stack");
const CreateAssociation_1 = require("../model/operations/CreateAssociation");
class CreateAssociationCommand {
    constructor(input) {
        this.input = input;
        this.model = CreateAssociation_1.CreateAssociation;
        this.middlewareStack = new __aws_sdk_middleware_stack.MiddlewareStack();
    }
    resolveMiddleware(clientStack, configuration) {
        const { handler } = configuration;
        const stack = clientStack.concat(this.middlewareStack);
        const handlerExecutionContext = {
            logger: {},
            model: this.model
        };
        return stack.resolve(handler(handlerExecutionContext), handlerExecutionContext);
    }
}
exports.CreateAssociationCommand = CreateAssociationCommand;
//# sourceMappingURL=CreateAssociationCommand.js.map