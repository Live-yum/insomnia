"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const __aws_sdk_middleware_stack = require("@aws-sdk/middleware-stack");
const DescribePatchGroupState_1 = require("../model/operations/DescribePatchGroupState");
class DescribePatchGroupStateCommand {
    constructor(input) {
        this.input = input;
        this.model = DescribePatchGroupState_1.DescribePatchGroupState;
        this.middlewareStack = new __aws_sdk_middleware_stack.MiddlewareStack();
    }
    resolveMiddleware(clientStack, configuration) {
        const { handler } = configuration;
        const stack = clientStack.concat(this.middlewareStack);
        const handlerExecutionContext = {
            logger: {},
            model: this.model
        };
        return stack.resolve(handler(handlerExecutionContext), handlerExecutionContext);
    }
}
exports.DescribePatchGroupStateCommand = DescribePatchGroupStateCommand;
//# sourceMappingURL=DescribePatchGroupStateCommand.js.map