/// <reference types="node" />
import * as __aws_sdk_middleware_stack from "@aws-sdk/middleware-stack";
import * as __aws_sdk_types from "@aws-sdk/types";
import * as _stream from "stream";
import { InputTypesUnion } from "../types/InputTypesUnion";
import { OutputTypesUnion } from "../types/OutputTypesUnion";
import { AddTagsToResourceInput } from "../types/AddTagsToResourceInput";
import { AddTagsToResourceOutput } from "../types/AddTagsToResourceOutput";
import { SSMResolvedConfiguration } from "../SSMConfiguration";
export * from "../types/AddTagsToResourceInput";
export * from "../types/AddTagsToResourceOutput";
export * from "../types/AddTagsToResourceExceptionsUnion";
export declare class AddTagsToResourceCommand implements __aws_sdk_types.Command<InputTypesUnion, AddTagsToResourceInput, OutputTypesUnion, AddTagsToResourceOutput, SSMResolvedConfiguration, _stream.Readable> {
    readonly input: AddTagsToResourceInput;
    readonly model: __aws_sdk_types.OperationModel;
    readonly middlewareStack: __aws_sdk_middleware_stack.MiddlewareStack<AddTagsToResourceInput, AddTagsToResourceOutput, _stream.Readable>;
    constructor(input: AddTagsToResourceInput);
    resolveMiddleware(clientStack: __aws_sdk_middleware_stack.MiddlewareStack<InputTypesUnion, OutputTypesUnion, _stream.Readable>, configuration: SSMResolvedConfiguration): __aws_sdk_types.Handler<AddTagsToResourceInput, AddTagsToResourceOutput>;
}
