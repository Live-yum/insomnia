"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const __aws_sdk_middleware_stack = require("@aws-sdk/middleware-stack");
const CancelCommand_1 = require("../model/operations/CancelCommand");
class CancelCommandCommand {
    constructor(input) {
        this.input = input;
        this.model = CancelCommand_1.CancelCommand;
        this.middlewareStack = new __aws_sdk_middleware_stack.MiddlewareStack();
    }
    resolveMiddleware(clientStack, configuration) {
        const { handler } = configuration;
        const stack = clientStack.concat(this.middlewareStack);
        const handlerExecutionContext = {
            logger: {},
            model: this.model
        };
        return stack.resolve(handler(handlerExecutionContext), handlerExecutionContext);
    }
}
exports.CancelCommandCommand = CancelCommandCommand;
//# sourceMappingURL=CancelCommandCommand.js.map