"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const __aws_sdk_middleware_stack = require("@aws-sdk/middleware-stack");
const GetOpsSummary_1 = require("../model/operations/GetOpsSummary");
class GetOpsSummaryCommand {
    constructor(input) {
        this.input = input;
        this.model = GetOpsSummary_1.GetOpsSummary;
        this.middlewareStack = new __aws_sdk_middleware_stack.MiddlewareStack();
    }
    resolveMiddleware(clientStack, configuration) {
        const { handler } = configuration;
        const stack = clientStack.concat(this.middlewareStack);
        const handlerExecutionContext = {
            logger: {},
            model: this.model
        };
        return stack.resolve(handler(handlerExecutionContext), handlerExecutionContext);
    }
}
exports.GetOpsSummaryCommand = GetOpsSummaryCommand;
//# sourceMappingURL=GetOpsSummaryCommand.js.map