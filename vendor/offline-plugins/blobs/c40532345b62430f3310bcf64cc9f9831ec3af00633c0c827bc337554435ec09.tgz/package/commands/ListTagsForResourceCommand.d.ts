/// <reference types="node" />
import * as __aws_sdk_middleware_stack from "@aws-sdk/middleware-stack";
import * as __aws_sdk_types from "@aws-sdk/types";
import * as _stream from "stream";
import { InputTypesUnion } from "../types/InputTypesUnion";
import { OutputTypesUnion } from "../types/OutputTypesUnion";
import { ListTagsForResourceInput } from "../types/ListTagsForResourceInput";
import { ListTagsForResourceOutput } from "../types/ListTagsForResourceOutput";
import { SSMResolvedConfiguration } from "../SSMConfiguration";
export * from "../types/ListTagsForResourceInput";
export * from "../types/ListTagsForResourceOutput";
export * from "../types/ListTagsForResourceExceptionsUnion";
export declare class ListTagsForResourceCommand implements __aws_sdk_types.Command<InputTypesUnion, ListTagsForResourceInput, OutputTypesUnion, ListTagsForResourceOutput, SSMResolvedConfiguration, _stream.Readable> {
    readonly input: ListTagsForResourceInput;
    readonly model: __aws_sdk_types.OperationModel;
    readonly middlewareStack: __aws_sdk_middleware_stack.MiddlewareStack<ListTagsForResourceInput, ListTagsForResourceOutput, _stream.Readable>;
    constructor(input: ListTagsForResourceInput);
    resolveMiddleware(clientStack: __aws_sdk_middleware_stack.MiddlewareStack<InputTypesUnion, OutputTypesUnion, _stream.Readable>, configuration: SSMResolvedConfiguration): __aws_sdk_types.Handler<ListTagsForResourceInput, ListTagsForResourceOutput>;
}
