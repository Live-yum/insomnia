/// <reference types="node" />
import * as __aws_sdk_middleware_stack from "@aws-sdk/middleware-stack";
import * as __aws_sdk_types from "@aws-sdk/types";
import * as _stream from "stream";
import { InputTypesUnion } from "../types/InputTypesUnion";
import { OutputTypesUnion } from "../types/OutputTypesUnion";
import { CreateMaintenanceWindowInput } from "../types/CreateMaintenanceWindowInput";
import { CreateMaintenanceWindowOutput } from "../types/CreateMaintenanceWindowOutput";
import { SSMResolvedConfiguration } from "../SSMConfiguration";
export * from "../types/CreateMaintenanceWindowInput";
export * from "../types/CreateMaintenanceWindowOutput";
export * from "../types/CreateMaintenanceWindowExceptionsUnion";
export declare class CreateMaintenanceWindowCommand implements __aws_sdk_types.Command<InputTypesUnion, CreateMaintenanceWindowInput, OutputTypesUnion, CreateMaintenanceWindowOutput, SSMResolvedConfiguration, _stream.Readable> {
    readonly input: CreateMaintenanceWindowInput;
    readonly model: __aws_sdk_types.OperationModel;
    readonly middlewareStack: __aws_sdk_middleware_stack.MiddlewareStack<CreateMaintenanceWindowInput, CreateMaintenanceWindowOutput, _stream.Readable>;
    constructor(input: CreateMaintenanceWindowInput);
    resolveMiddleware(clientStack: __aws_sdk_middleware_stack.MiddlewareStack<InputTypesUnion, OutputTypesUnion, _stream.Readable>, configuration: SSMResolvedConfiguration): __aws_sdk_types.Handler<CreateMaintenanceWindowInput, CreateMaintenanceWindowOutput>;
}
