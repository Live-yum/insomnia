"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const __aws_sdk_middleware_stack = require("@aws-sdk/middleware-stack");
const StopAutomationExecution_1 = require("../model/operations/StopAutomationExecution");
class StopAutomationExecutionCommand {
    constructor(input) {
        this.input = input;
        this.model = StopAutomationExecution_1.StopAutomationExecution;
        this.middlewareStack = new __aws_sdk_middleware_stack.MiddlewareStack();
    }
    resolveMiddleware(clientStack, configuration) {
        const { handler } = configuration;
        const stack = clientStack.concat(this.middlewareStack);
        const handlerExecutionContext = {
            logger: {},
            model: this.model
        };
        return stack.resolve(handler(handlerExecutionContext), handlerExecutionContext);
    }
}
exports.StopAutomationExecutionCommand = StopAutomationExecutionCommand;
//# sourceMappingURL=StopAutomationExecutionCommand.js.map