"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const __aws_sdk_core_handler = require("@aws-sdk/core-handler");
const __aws_sdk_credential_provider_node = require("@aws-sdk/credential-provider-node");
const __aws_sdk_hash_node = require("@aws-sdk/hash-node");
const __aws_sdk_json_builder = require("@aws-sdk/json-builder");
const __aws_sdk_json_error_unmarshaller = require("@aws-sdk/json-error-unmarshaller");
const __aws_sdk_json_parser = require("@aws-sdk/json-parser");
const __aws_sdk_node_http_handler = require("@aws-sdk/node-http-handler");
const __aws_sdk_protocol_json_rpc = require("@aws-sdk/protocol-json-rpc");
const __aws_sdk_region_provider = require("@aws-sdk/region-provider");
const __aws_sdk_signature_v4 = require("@aws-sdk/signature-v4");
const __aws_sdk_stream_collector_node = require("@aws-sdk/stream-collector-node");
const __aws_sdk_url_parser_node = require("@aws-sdk/url-parser-node");
const __aws_sdk_util_base64_node = require("@aws-sdk/util-base64-node");
const __aws_sdk_util_body_length_node = require("@aws-sdk/util-body-length-node");
const __aws_sdk_util_utf8_node = require("@aws-sdk/util-utf8-node");
exports.configurationProperties = {
    profile: {},
    maxRedirects: {
        defaultValue: 10
    },
    maxRetries: {
        defaultValue: 3
    },
    region: {
        defaultProvider: __aws_sdk_region_provider.defaultProvider,
        normalize: (value) => {
            if (typeof value === "string") {
                const promisified = Promise.resolve(value);
                return () => promisified;
            }
            return value;
        }
    },
    sslEnabled: {
        defaultValue: true
    },
    urlParser: {
        defaultValue: __aws_sdk_url_parser_node.parseUrl
    },
    endpointProvider: {
        defaultValue: (sslEnabled, region) => ({
            protocol: sslEnabled ? "https:" : "http:",
            path: "/",
            hostname: `ssm.${region}.amazonaws.com`
        })
    },
    endpoint: {
        defaultProvider: (configuration) => {
            const promisified = configuration
                .region()
                .then(region => configuration.endpointProvider(configuration.sslEnabled, region));
            return () => promisified;
        },
        normalize: (value, configuration) => {
            if (typeof value === "string") {
                const promisified = Promise.resolve(configuration.urlParser(value));
                return () => promisified;
            }
            else if (typeof value === "object") {
                const promisified = Promise.resolve(value);
                return () => promisified;
            }
            // Users are not required to supply an endpoint, so `value`
            // could be undefined. This function, however, will only be
            // invoked if `value` is defined, so the return will never
            // be undefined.
            return value;
        }
    },
    base64Decoder: {
        defaultValue: __aws_sdk_util_base64_node.fromBase64
    },
    base64Encoder: {
        defaultValue: __aws_sdk_util_base64_node.toBase64
    },
    utf8Decoder: {
        defaultValue: __aws_sdk_util_utf8_node.fromUtf8
    },
    utf8Encoder: {
        defaultValue: __aws_sdk_util_utf8_node.toUtf8
    },
    streamCollector: {
        defaultValue: __aws_sdk_stream_collector_node.streamCollector
    },
    serializer: {
        defaultProvider: (configuration) => {
            const promisified = configuration
                .endpoint()
                .then(endpoint => new __aws_sdk_protocol_json_rpc.JsonRpcSerializer(endpoint, new __aws_sdk_json_builder.JsonBuilder(configuration.base64Encoder, configuration.utf8Decoder)));
            return () => promisified;
        }
    },
    parser: {
        defaultProvider: (configuration) => new __aws_sdk_protocol_json_rpc.JsonRpcParser(new __aws_sdk_json_parser.JsonParser(configuration.base64Decoder), __aws_sdk_json_error_unmarshaller.jsonErrorUnmarshaller, configuration.streamCollector, configuration.utf8Encoder)
    },
    keepAlive: {
        defaultValue: true
    },
    _user_injected_http_handler: {
        defaultProvider: (configuration) => !configuration.httpHandler
    },
    httpHandler: {
        defaultProvider: (configuration) => new __aws_sdk_node_http_handler.NodeHttpHandler(configuration)
    },
    handler: {
        defaultProvider: (configuration) => __aws_sdk_core_handler.coreHandler(configuration.httpHandler, configuration.parser)
    },
    bodyLengthChecker: {
        defaultValue: __aws_sdk_util_body_length_node.calculateBodyLength
    },
    retryDecider: {},
    delayDecider: {},
    credentials: {
        defaultProvider: __aws_sdk_credential_provider_node.defaultProvider,
        normalize: (value) => {
            if (typeof value === "object") {
                const promisified = Promise.resolve(value);
                return () => promisified;
            }
            return value;
        }
    },
    sha256: {
        defaultValue: __aws_sdk_hash_node.Hash.bind(null, "sha256")
    },
    signingName: {
        defaultValue: "ssm"
    },
    signer: {
        defaultProvider: (configuration) => new __aws_sdk_signature_v4.SignatureV4({
            credentials: configuration.credentials,
            region: configuration.region,
            service: configuration.signingName,
            sha256: configuration.sha256,
            uriEscapePath: true
        })
    }
};
//# sourceMappingURL=SSMConfiguration.js.map