import { OperationModel as _Operation_ } from "@aws-sdk/types";
export declare const DescribeActivations: _Operation_;
