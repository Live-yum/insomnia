"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const RegisterTaskWithMaintenanceWindowInput_1 = require("../shapes/RegisterTaskWithMaintenanceWindowInput");
const RegisterTaskWithMaintenanceWindowOutput_1 = require("../shapes/RegisterTaskWithMaintenanceWindowOutput");
const IdempotentParameterMismatch_1 = require("../shapes/IdempotentParameterMismatch");
const DoesNotExistException_1 = require("../shapes/DoesNotExistException");
const ResourceLimitExceededException_1 = require("../shapes/ResourceLimitExceededException");
const FeatureNotAvailableException_1 = require("../shapes/FeatureNotAvailableException");
const InternalServerError_1 = require("../shapes/InternalServerError");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.RegisterTaskWithMaintenanceWindow = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "RegisterTaskWithMaintenanceWindow",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: RegisterTaskWithMaintenanceWindowInput_1.RegisterTaskWithMaintenanceWindowInput
    },
    output: {
        shape: RegisterTaskWithMaintenanceWindowOutput_1.RegisterTaskWithMaintenanceWindowOutput
    },
    errors: [
        {
            shape: IdempotentParameterMismatch_1.IdempotentParameterMismatch
        },
        {
            shape: DoesNotExistException_1.DoesNotExistException
        },
        {
            shape: ResourceLimitExceededException_1.ResourceLimitExceededException
        },
        {
            shape: FeatureNotAvailableException_1.FeatureNotAvailableException
        },
        {
            shape: InternalServerError_1.InternalServerError
        }
    ]
};
//# sourceMappingURL=RegisterTaskWithMaintenanceWindow.js.map