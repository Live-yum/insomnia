"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const DeleteResourceDataSyncInput_1 = require("../shapes/DeleteResourceDataSyncInput");
const DeleteResourceDataSyncOutput_1 = require("../shapes/DeleteResourceDataSyncOutput");
const InternalServerError_1 = require("../shapes/InternalServerError");
const ResourceDataSyncNotFoundException_1 = require("../shapes/ResourceDataSyncNotFoundException");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.DeleteResourceDataSync = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "DeleteResourceDataSync",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: DeleteResourceDataSyncInput_1.DeleteResourceDataSyncInput
    },
    output: {
        shape: DeleteResourceDataSyncOutput_1.DeleteResourceDataSyncOutput
    },
    errors: [
        {
            shape: InternalServerError_1.InternalServerError
        },
        {
            shape: ResourceDataSyncNotFoundException_1.ResourceDataSyncNotFoundException
        }
    ]
};
//# sourceMappingURL=DeleteResourceDataSync.js.map