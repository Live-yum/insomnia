"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const StartSessionInput_1 = require("../shapes/StartSessionInput");
const StartSessionOutput_1 = require("../shapes/StartSessionOutput");
const InvalidDocument_1 = require("../shapes/InvalidDocument");
const TargetNotConnected_1 = require("../shapes/TargetNotConnected");
const InternalServerError_1 = require("../shapes/InternalServerError");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.StartSession = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "StartSession",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: StartSessionInput_1.StartSessionInput
    },
    output: {
        shape: StartSessionOutput_1.StartSessionOutput
    },
    errors: [
        {
            shape: InvalidDocument_1.InvalidDocument
        },
        {
            shape: TargetNotConnected_1.TargetNotConnected
        },
        {
            shape: InternalServerError_1.InternalServerError
        }
    ]
};
//# sourceMappingURL=StartSession.js.map