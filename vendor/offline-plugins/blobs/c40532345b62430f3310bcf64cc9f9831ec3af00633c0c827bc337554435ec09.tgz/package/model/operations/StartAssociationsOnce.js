"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const StartAssociationsOnceInput_1 = require("../shapes/StartAssociationsOnceInput");
const StartAssociationsOnceOutput_1 = require("../shapes/StartAssociationsOnceOutput");
const InvalidAssociation_1 = require("../shapes/InvalidAssociation");
const AssociationDoesNotExist_1 = require("../shapes/AssociationDoesNotExist");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.StartAssociationsOnce = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "StartAssociationsOnce",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: StartAssociationsOnceInput_1.StartAssociationsOnceInput
    },
    output: {
        shape: StartAssociationsOnceOutput_1.StartAssociationsOnceOutput
    },
    errors: [
        {
            shape: InvalidAssociation_1.InvalidAssociation
        },
        {
            shape: AssociationDoesNotExist_1.AssociationDoesNotExist
        }
    ]
};
//# sourceMappingURL=StartAssociationsOnce.js.map