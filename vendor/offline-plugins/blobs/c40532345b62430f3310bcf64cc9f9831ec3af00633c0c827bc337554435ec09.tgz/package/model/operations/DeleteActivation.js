"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const DeleteActivationInput_1 = require("../shapes/DeleteActivationInput");
const DeleteActivationOutput_1 = require("../shapes/DeleteActivationOutput");
const InvalidActivationId_1 = require("../shapes/InvalidActivationId");
const InvalidActivation_1 = require("../shapes/InvalidActivation");
const InternalServerError_1 = require("../shapes/InternalServerError");
const TooManyUpdates_1 = require("../shapes/TooManyUpdates");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.DeleteActivation = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "DeleteActivation",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: DeleteActivationInput_1.DeleteActivationInput
    },
    output: {
        shape: DeleteActivationOutput_1.DeleteActivationOutput
    },
    errors: [
        {
            shape: InvalidActivationId_1.InvalidActivationId
        },
        {
            shape: InvalidActivation_1.InvalidActivation
        },
        {
            shape: InternalServerError_1.InternalServerError
        },
        {
            shape: TooManyUpdates_1.TooManyUpdates
        }
    ]
};
//# sourceMappingURL=DeleteActivation.js.map