"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const DescribeAutomationStepExecutionsInput_1 = require("../shapes/DescribeAutomationStepExecutionsInput");
const DescribeAutomationStepExecutionsOutput_1 = require("../shapes/DescribeAutomationStepExecutionsOutput");
const AutomationExecutionNotFoundException_1 = require("../shapes/AutomationExecutionNotFoundException");
const InvalidNextToken_1 = require("../shapes/InvalidNextToken");
const InvalidFilterKey_1 = require("../shapes/InvalidFilterKey");
const InvalidFilterValue_1 = require("../shapes/InvalidFilterValue");
const InternalServerError_1 = require("../shapes/InternalServerError");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.DescribeAutomationStepExecutions = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "DescribeAutomationStepExecutions",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: DescribeAutomationStepExecutionsInput_1.DescribeAutomationStepExecutionsInput
    },
    output: {
        shape: DescribeAutomationStepExecutionsOutput_1.DescribeAutomationStepExecutionsOutput
    },
    errors: [
        {
            shape: AutomationExecutionNotFoundException_1.AutomationExecutionNotFoundException
        },
        {
            shape: InvalidNextToken_1.InvalidNextToken
        },
        {
            shape: InvalidFilterKey_1.InvalidFilterKey
        },
        {
            shape: InvalidFilterValue_1.InvalidFilterValue
        },
        {
            shape: InternalServerError_1.InternalServerError
        }
    ]
};
//# sourceMappingURL=DescribeAutomationStepExecutions.js.map