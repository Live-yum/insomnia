"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const DescribeInstancePatchesInput_1 = require("../shapes/DescribeInstancePatchesInput");
const DescribeInstancePatchesOutput_1 = require("../shapes/DescribeInstancePatchesOutput");
const InternalServerError_1 = require("../shapes/InternalServerError");
const InvalidInstanceId_1 = require("../shapes/InvalidInstanceId");
const InvalidFilter_1 = require("../shapes/InvalidFilter");
const InvalidNextToken_1 = require("../shapes/InvalidNextToken");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.DescribeInstancePatches = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "DescribeInstancePatches",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: DescribeInstancePatchesInput_1.DescribeInstancePatchesInput
    },
    output: {
        shape: DescribeInstancePatchesOutput_1.DescribeInstancePatchesOutput
    },
    errors: [
        {
            shape: InternalServerError_1.InternalServerError
        },
        {
            shape: InvalidInstanceId_1.InvalidInstanceId
        },
        {
            shape: InvalidFilter_1.InvalidFilter
        },
        {
            shape: InvalidNextToken_1.InvalidNextToken
        }
    ]
};
//# sourceMappingURL=DescribeInstancePatches.js.map