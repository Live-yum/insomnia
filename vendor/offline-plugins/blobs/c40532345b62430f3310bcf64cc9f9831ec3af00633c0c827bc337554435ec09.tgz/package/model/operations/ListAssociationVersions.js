"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const ListAssociationVersionsInput_1 = require("../shapes/ListAssociationVersionsInput");
const ListAssociationVersionsOutput_1 = require("../shapes/ListAssociationVersionsOutput");
const InternalServerError_1 = require("../shapes/InternalServerError");
const InvalidNextToken_1 = require("../shapes/InvalidNextToken");
const AssociationDoesNotExist_1 = require("../shapes/AssociationDoesNotExist");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.ListAssociationVersions = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "ListAssociationVersions",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: ListAssociationVersionsInput_1.ListAssociationVersionsInput
    },
    output: {
        shape: ListAssociationVersionsOutput_1.ListAssociationVersionsOutput
    },
    errors: [
        {
            shape: InternalServerError_1.InternalServerError
        },
        {
            shape: InvalidNextToken_1.InvalidNextToken
        },
        {
            shape: AssociationDoesNotExist_1.AssociationDoesNotExist
        }
    ]
};
//# sourceMappingURL=ListAssociationVersions.js.map