"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const CreateOpsItemInput_1 = require("../shapes/CreateOpsItemInput");
const CreateOpsItemOutput_1 = require("../shapes/CreateOpsItemOutput");
const InternalServerError_1 = require("../shapes/InternalServerError");
const OpsItemAlreadyExistsException_1 = require("../shapes/OpsItemAlreadyExistsException");
const OpsItemLimitExceededException_1 = require("../shapes/OpsItemLimitExceededException");
const OpsItemInvalidParameterException_1 = require("../shapes/OpsItemInvalidParameterException");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.CreateOpsItem = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "CreateOpsItem",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: CreateOpsItemInput_1.CreateOpsItemInput
    },
    output: {
        shape: CreateOpsItemOutput_1.CreateOpsItemOutput
    },
    errors: [
        {
            shape: InternalServerError_1.InternalServerError
        },
        {
            shape: OpsItemAlreadyExistsException_1.OpsItemAlreadyExistsException
        },
        {
            shape: OpsItemLimitExceededException_1.OpsItemLimitExceededException
        },
        {
            shape: OpsItemInvalidParameterException_1.OpsItemInvalidParameterException
        }
    ]
};
//# sourceMappingURL=CreateOpsItem.js.map