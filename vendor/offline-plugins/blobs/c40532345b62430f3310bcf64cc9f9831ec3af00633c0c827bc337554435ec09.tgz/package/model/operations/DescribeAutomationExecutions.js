"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const DescribeAutomationExecutionsInput_1 = require("../shapes/DescribeAutomationExecutionsInput");
const DescribeAutomationExecutionsOutput_1 = require("../shapes/DescribeAutomationExecutionsOutput");
const InvalidFilterKey_1 = require("../shapes/InvalidFilterKey");
const InvalidFilterValue_1 = require("../shapes/InvalidFilterValue");
const InvalidNextToken_1 = require("../shapes/InvalidNextToken");
const InternalServerError_1 = require("../shapes/InternalServerError");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.DescribeAutomationExecutions = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "DescribeAutomationExecutions",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: DescribeAutomationExecutionsInput_1.DescribeAutomationExecutionsInput
    },
    output: {
        shape: DescribeAutomationExecutionsOutput_1.DescribeAutomationExecutionsOutput
    },
    errors: [
        {
            shape: InvalidFilterKey_1.InvalidFilterKey
        },
        {
            shape: InvalidFilterValue_1.InvalidFilterValue
        },
        {
            shape: InvalidNextToken_1.InvalidNextToken
        },
        {
            shape: InternalServerError_1.InternalServerError
        }
    ]
};
//# sourceMappingURL=DescribeAutomationExecutions.js.map