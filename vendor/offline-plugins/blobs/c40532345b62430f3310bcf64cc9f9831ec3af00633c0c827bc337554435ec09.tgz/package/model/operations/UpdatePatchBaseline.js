"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const UpdatePatchBaselineInput_1 = require("../shapes/UpdatePatchBaselineInput");
const UpdatePatchBaselineOutput_1 = require("../shapes/UpdatePatchBaselineOutput");
const DoesNotExistException_1 = require("../shapes/DoesNotExistException");
const InternalServerError_1 = require("../shapes/InternalServerError");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.UpdatePatchBaseline = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "UpdatePatchBaseline",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: UpdatePatchBaselineInput_1.UpdatePatchBaselineInput
    },
    output: {
        shape: UpdatePatchBaselineOutput_1.UpdatePatchBaselineOutput
    },
    errors: [
        {
            shape: DoesNotExistException_1.DoesNotExistException
        },
        {
            shape: InternalServerError_1.InternalServerError
        }
    ]
};
//# sourceMappingURL=UpdatePatchBaseline.js.map