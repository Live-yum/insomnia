"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const DeregisterTargetFromMaintenanceWindowInput_1 = require("../shapes/DeregisterTargetFromMaintenanceWindowInput");
const DeregisterTargetFromMaintenanceWindowOutput_1 = require("../shapes/DeregisterTargetFromMaintenanceWindowOutput");
const DoesNotExistException_1 = require("../shapes/DoesNotExistException");
const InternalServerError_1 = require("../shapes/InternalServerError");
const TargetInUseException_1 = require("../shapes/TargetInUseException");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.DeregisterTargetFromMaintenanceWindow = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "DeregisterTargetFromMaintenanceWindow",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: DeregisterTargetFromMaintenanceWindowInput_1.DeregisterTargetFromMaintenanceWindowInput
    },
    output: {
        shape: DeregisterTargetFromMaintenanceWindowOutput_1.DeregisterTargetFromMaintenanceWindowOutput
    },
    errors: [
        {
            shape: DoesNotExistException_1.DoesNotExistException
        },
        {
            shape: InternalServerError_1.InternalServerError
        },
        {
            shape: TargetInUseException_1.TargetInUseException
        }
    ]
};
//# sourceMappingURL=DeregisterTargetFromMaintenanceWindow.js.map