"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const DescribeOpsItemsInput_1 = require("../shapes/DescribeOpsItemsInput");
const DescribeOpsItemsOutput_1 = require("../shapes/DescribeOpsItemsOutput");
const InternalServerError_1 = require("../shapes/InternalServerError");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.DescribeOpsItems = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "DescribeOpsItems",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: DescribeOpsItemsInput_1.DescribeOpsItemsInput
    },
    output: {
        shape: DescribeOpsItemsOutput_1.DescribeOpsItemsOutput
    },
    errors: [
        {
            shape: InternalServerError_1.InternalServerError
        }
    ]
};
//# sourceMappingURL=DescribeOpsItems.js.map