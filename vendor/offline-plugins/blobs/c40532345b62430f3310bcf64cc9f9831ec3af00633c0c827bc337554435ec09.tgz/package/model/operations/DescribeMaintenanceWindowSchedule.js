"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const DescribeMaintenanceWindowScheduleInput_1 = require("../shapes/DescribeMaintenanceWindowScheduleInput");
const DescribeMaintenanceWindowScheduleOutput_1 = require("../shapes/DescribeMaintenanceWindowScheduleOutput");
const InternalServerError_1 = require("../shapes/InternalServerError");
const DoesNotExistException_1 = require("../shapes/DoesNotExistException");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.DescribeMaintenanceWindowSchedule = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "DescribeMaintenanceWindowSchedule",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: DescribeMaintenanceWindowScheduleInput_1.DescribeMaintenanceWindowScheduleInput
    },
    output: {
        shape: DescribeMaintenanceWindowScheduleOutput_1.DescribeMaintenanceWindowScheduleOutput
    },
    errors: [
        {
            shape: InternalServerError_1.InternalServerError
        },
        {
            shape: DoesNotExistException_1.DoesNotExistException
        }
    ]
};
//# sourceMappingURL=DescribeMaintenanceWindowSchedule.js.map