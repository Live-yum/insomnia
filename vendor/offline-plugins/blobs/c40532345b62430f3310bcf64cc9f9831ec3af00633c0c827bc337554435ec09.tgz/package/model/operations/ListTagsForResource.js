"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const ListTagsForResourceInput_1 = require("../shapes/ListTagsForResourceInput");
const ListTagsForResourceOutput_1 = require("../shapes/ListTagsForResourceOutput");
const InvalidResourceType_1 = require("../shapes/InvalidResourceType");
const InvalidResourceId_1 = require("../shapes/InvalidResourceId");
const InternalServerError_1 = require("../shapes/InternalServerError");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.ListTagsForResource = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "ListTagsForResource",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: ListTagsForResourceInput_1.ListTagsForResourceInput
    },
    output: {
        shape: ListTagsForResourceOutput_1.ListTagsForResourceOutput
    },
    errors: [
        {
            shape: InvalidResourceType_1.InvalidResourceType
        },
        {
            shape: InvalidResourceId_1.InvalidResourceId
        },
        {
            shape: InternalServerError_1.InternalServerError
        }
    ]
};
//# sourceMappingURL=ListTagsForResource.js.map