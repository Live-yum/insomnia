"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const TerminateSessionInput_1 = require("../shapes/TerminateSessionInput");
const TerminateSessionOutput_1 = require("../shapes/TerminateSessionOutput");
const DoesNotExistException_1 = require("../shapes/DoesNotExistException");
const InternalServerError_1 = require("../shapes/InternalServerError");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.TerminateSession = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "TerminateSession",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: TerminateSessionInput_1.TerminateSessionInput
    },
    output: {
        shape: TerminateSessionOutput_1.TerminateSessionOutput
    },
    errors: [
        {
            shape: DoesNotExistException_1.DoesNotExistException
        },
        {
            shape: InternalServerError_1.InternalServerError
        }
    ]
};
//# sourceMappingURL=TerminateSession.js.map