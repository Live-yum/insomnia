"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const DeregisterTaskFromMaintenanceWindowInput_1 = require("../shapes/DeregisterTaskFromMaintenanceWindowInput");
const DeregisterTaskFromMaintenanceWindowOutput_1 = require("../shapes/DeregisterTaskFromMaintenanceWindowOutput");
const DoesNotExistException_1 = require("../shapes/DoesNotExistException");
const InternalServerError_1 = require("../shapes/InternalServerError");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.DeregisterTaskFromMaintenanceWindow = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "DeregisterTaskFromMaintenanceWindow",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: DeregisterTaskFromMaintenanceWindowInput_1.DeregisterTaskFromMaintenanceWindowInput
    },
    output: {
        shape: DeregisterTaskFromMaintenanceWindowOutput_1.DeregisterTaskFromMaintenanceWindowOutput
    },
    errors: [
        {
            shape: DoesNotExistException_1.DoesNotExistException
        },
        {
            shape: InternalServerError_1.InternalServerError
        }
    ]
};
//# sourceMappingURL=DeregisterTaskFromMaintenanceWindow.js.map