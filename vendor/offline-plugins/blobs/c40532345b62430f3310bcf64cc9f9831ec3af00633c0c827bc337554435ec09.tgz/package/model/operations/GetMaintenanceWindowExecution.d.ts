import { OperationModel as _Operation_ } from "@aws-sdk/types";
export declare const GetMaintenanceWindowExecution: _Operation_;
