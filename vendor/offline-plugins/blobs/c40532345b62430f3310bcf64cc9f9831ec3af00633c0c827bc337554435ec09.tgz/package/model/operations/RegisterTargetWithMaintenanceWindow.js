"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const RegisterTargetWithMaintenanceWindowInput_1 = require("../shapes/RegisterTargetWithMaintenanceWindowInput");
const RegisterTargetWithMaintenanceWindowOutput_1 = require("../shapes/RegisterTargetWithMaintenanceWindowOutput");
const IdempotentParameterMismatch_1 = require("../shapes/IdempotentParameterMismatch");
const DoesNotExistException_1 = require("../shapes/DoesNotExistException");
const ResourceLimitExceededException_1 = require("../shapes/ResourceLimitExceededException");
const InternalServerError_1 = require("../shapes/InternalServerError");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.RegisterTargetWithMaintenanceWindow = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "RegisterTargetWithMaintenanceWindow",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: RegisterTargetWithMaintenanceWindowInput_1.RegisterTargetWithMaintenanceWindowInput
    },
    output: {
        shape: RegisterTargetWithMaintenanceWindowOutput_1.RegisterTargetWithMaintenanceWindowOutput
    },
    errors: [
        {
            shape: IdempotentParameterMismatch_1.IdempotentParameterMismatch
        },
        {
            shape: DoesNotExistException_1.DoesNotExistException
        },
        {
            shape: ResourceLimitExceededException_1.ResourceLimitExceededException
        },
        {
            shape: InternalServerError_1.InternalServerError
        }
    ]
};
//# sourceMappingURL=RegisterTargetWithMaintenanceWindow.js.map