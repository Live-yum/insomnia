"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const UpdateServiceSettingInput_1 = require("../shapes/UpdateServiceSettingInput");
const UpdateServiceSettingOutput_1 = require("../shapes/UpdateServiceSettingOutput");
const InternalServerError_1 = require("../shapes/InternalServerError");
const ServiceSettingNotFound_1 = require("../shapes/ServiceSettingNotFound");
const TooManyUpdates_1 = require("../shapes/TooManyUpdates");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.UpdateServiceSetting = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "UpdateServiceSetting",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: UpdateServiceSettingInput_1.UpdateServiceSettingInput
    },
    output: {
        shape: UpdateServiceSettingOutput_1.UpdateServiceSettingOutput
    },
    errors: [
        {
            shape: InternalServerError_1.InternalServerError
        },
        {
            shape: ServiceSettingNotFound_1.ServiceSettingNotFound
        },
        {
            shape: TooManyUpdates_1.TooManyUpdates
        }
    ]
};
//# sourceMappingURL=UpdateServiceSetting.js.map