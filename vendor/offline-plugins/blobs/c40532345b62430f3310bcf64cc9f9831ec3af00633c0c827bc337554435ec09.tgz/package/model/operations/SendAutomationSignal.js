"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const SendAutomationSignalInput_1 = require("../shapes/SendAutomationSignalInput");
const SendAutomationSignalOutput_1 = require("../shapes/SendAutomationSignalOutput");
const AutomationExecutionNotFoundException_1 = require("../shapes/AutomationExecutionNotFoundException");
const AutomationStepNotFoundException_1 = require("../shapes/AutomationStepNotFoundException");
const InvalidAutomationSignalException_1 = require("../shapes/InvalidAutomationSignalException");
const InternalServerError_1 = require("../shapes/InternalServerError");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.SendAutomationSignal = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "SendAutomationSignal",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: SendAutomationSignalInput_1.SendAutomationSignalInput
    },
    output: {
        shape: SendAutomationSignalOutput_1.SendAutomationSignalOutput
    },
    errors: [
        {
            shape: AutomationExecutionNotFoundException_1.AutomationExecutionNotFoundException
        },
        {
            shape: AutomationStepNotFoundException_1.AutomationStepNotFoundException
        },
        {
            shape: InvalidAutomationSignalException_1.InvalidAutomationSignalException
        },
        {
            shape: InternalServerError_1.InternalServerError
        }
    ]
};
//# sourceMappingURL=SendAutomationSignal.js.map