"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const StopAutomationExecutionInput_1 = require("../shapes/StopAutomationExecutionInput");
const StopAutomationExecutionOutput_1 = require("../shapes/StopAutomationExecutionOutput");
const AutomationExecutionNotFoundException_1 = require("../shapes/AutomationExecutionNotFoundException");
const InvalidAutomationStatusUpdateException_1 = require("../shapes/InvalidAutomationStatusUpdateException");
const InternalServerError_1 = require("../shapes/InternalServerError");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.StopAutomationExecution = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "StopAutomationExecution",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: StopAutomationExecutionInput_1.StopAutomationExecutionInput
    },
    output: {
        shape: StopAutomationExecutionOutput_1.StopAutomationExecutionOutput
    },
    errors: [
        {
            shape: AutomationExecutionNotFoundException_1.AutomationExecutionNotFoundException
        },
        {
            shape: InvalidAutomationStatusUpdateException_1.InvalidAutomationStatusUpdateException
        },
        {
            shape: InternalServerError_1.InternalServerError
        }
    ]
};
//# sourceMappingURL=StopAutomationExecution.js.map