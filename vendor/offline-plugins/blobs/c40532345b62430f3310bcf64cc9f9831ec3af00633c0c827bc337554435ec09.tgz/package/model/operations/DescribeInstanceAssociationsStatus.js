"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const DescribeInstanceAssociationsStatusInput_1 = require("../shapes/DescribeInstanceAssociationsStatusInput");
const DescribeInstanceAssociationsStatusOutput_1 = require("../shapes/DescribeInstanceAssociationsStatusOutput");
const InternalServerError_1 = require("../shapes/InternalServerError");
const InvalidInstanceId_1 = require("../shapes/InvalidInstanceId");
const InvalidNextToken_1 = require("../shapes/InvalidNextToken");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.DescribeInstanceAssociationsStatus = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "DescribeInstanceAssociationsStatus",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: DescribeInstanceAssociationsStatusInput_1.DescribeInstanceAssociationsStatusInput
    },
    output: {
        shape: DescribeInstanceAssociationsStatusOutput_1.DescribeInstanceAssociationsStatusOutput
    },
    errors: [
        {
            shape: InternalServerError_1.InternalServerError
        },
        {
            shape: InvalidInstanceId_1.InvalidInstanceId
        },
        {
            shape: InvalidNextToken_1.InvalidNextToken
        }
    ]
};
//# sourceMappingURL=DescribeInstanceAssociationsStatus.js.map