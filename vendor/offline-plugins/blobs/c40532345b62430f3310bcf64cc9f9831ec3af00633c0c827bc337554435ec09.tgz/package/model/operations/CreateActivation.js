"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const CreateActivationInput_1 = require("../shapes/CreateActivationInput");
const CreateActivationOutput_1 = require("../shapes/CreateActivationOutput");
const InternalServerError_1 = require("../shapes/InternalServerError");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.CreateActivation = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "CreateActivation",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: CreateActivationInput_1.CreateActivationInput
    },
    output: {
        shape: CreateActivationOutput_1.CreateActivationOutput
    },
    errors: [
        {
            shape: InternalServerError_1.InternalServerError
        }
    ]
};
//# sourceMappingURL=CreateActivation.js.map