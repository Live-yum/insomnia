import { OperationModel as _Operation_ } from "@aws-sdk/types";
export declare const PutParameter: _Operation_;
