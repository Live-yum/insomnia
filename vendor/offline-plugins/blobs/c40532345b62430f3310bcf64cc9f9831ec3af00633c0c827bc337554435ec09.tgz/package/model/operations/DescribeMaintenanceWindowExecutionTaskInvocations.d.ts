import { OperationModel as _Operation_ } from "@aws-sdk/types";
export declare const DescribeMaintenanceWindowExecutionTaskInvocations: _Operation_;
