import { OperationModel as _Operation_ } from "@aws-sdk/types";
export declare const CreateAssociation: _Operation_;
