"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const GetParametersInput_1 = require("../shapes/GetParametersInput");
const GetParametersOutput_1 = require("../shapes/GetParametersOutput");
const InvalidKeyId_1 = require("../shapes/InvalidKeyId");
const InternalServerError_1 = require("../shapes/InternalServerError");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.GetParameters = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "GetParameters",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: GetParametersInput_1.GetParametersInput
    },
    output: {
        shape: GetParametersOutput_1.GetParametersOutput
    },
    errors: [
        {
            shape: InvalidKeyId_1.InvalidKeyId
        },
        {
            shape: InternalServerError_1.InternalServerError
        }
    ]
};
//# sourceMappingURL=GetParameters.js.map