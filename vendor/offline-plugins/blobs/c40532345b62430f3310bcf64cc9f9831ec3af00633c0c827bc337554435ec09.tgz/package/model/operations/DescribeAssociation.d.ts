import { OperationModel as _Operation_ } from "@aws-sdk/types";
export declare const DescribeAssociation: _Operation_;
