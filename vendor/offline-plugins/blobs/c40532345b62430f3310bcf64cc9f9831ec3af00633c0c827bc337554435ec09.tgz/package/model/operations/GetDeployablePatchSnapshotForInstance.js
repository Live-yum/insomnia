"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const GetDeployablePatchSnapshotForInstanceInput_1 = require("../shapes/GetDeployablePatchSnapshotForInstanceInput");
const GetDeployablePatchSnapshotForInstanceOutput_1 = require("../shapes/GetDeployablePatchSnapshotForInstanceOutput");
const InternalServerError_1 = require("../shapes/InternalServerError");
const UnsupportedOperatingSystem_1 = require("../shapes/UnsupportedOperatingSystem");
const UnsupportedFeatureRequiredException_1 = require("../shapes/UnsupportedFeatureRequiredException");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.GetDeployablePatchSnapshotForInstance = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "GetDeployablePatchSnapshotForInstance",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: GetDeployablePatchSnapshotForInstanceInput_1.GetDeployablePatchSnapshotForInstanceInput
    },
    output: {
        shape: GetDeployablePatchSnapshotForInstanceOutput_1.GetDeployablePatchSnapshotForInstanceOutput
    },
    errors: [
        {
            shape: InternalServerError_1.InternalServerError
        },
        {
            shape: UnsupportedOperatingSystem_1.UnsupportedOperatingSystem
        },
        {
            shape: UnsupportedFeatureRequiredException_1.UnsupportedFeatureRequiredException
        }
    ]
};
//# sourceMappingURL=GetDeployablePatchSnapshotForInstance.js.map