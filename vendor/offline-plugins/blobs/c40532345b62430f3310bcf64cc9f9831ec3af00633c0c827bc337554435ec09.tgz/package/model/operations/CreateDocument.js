"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const CreateDocumentInput_1 = require("../shapes/CreateDocumentInput");
const CreateDocumentOutput_1 = require("../shapes/CreateDocumentOutput");
const DocumentAlreadyExists_1 = require("../shapes/DocumentAlreadyExists");
const MaxDocumentSizeExceeded_1 = require("../shapes/MaxDocumentSizeExceeded");
const InternalServerError_1 = require("../shapes/InternalServerError");
const InvalidDocumentContent_1 = require("../shapes/InvalidDocumentContent");
const DocumentLimitExceeded_1 = require("../shapes/DocumentLimitExceeded");
const InvalidDocumentSchemaVersion_1 = require("../shapes/InvalidDocumentSchemaVersion");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.CreateDocument = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "CreateDocument",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: CreateDocumentInput_1.CreateDocumentInput
    },
    output: {
        shape: CreateDocumentOutput_1.CreateDocumentOutput
    },
    errors: [
        {
            shape: DocumentAlreadyExists_1.DocumentAlreadyExists
        },
        {
            shape: MaxDocumentSizeExceeded_1.MaxDocumentSizeExceeded
        },
        {
            shape: InternalServerError_1.InternalServerError
        },
        {
            shape: InvalidDocumentContent_1.InvalidDocumentContent
        },
        {
            shape: DocumentLimitExceeded_1.DocumentLimitExceeded
        },
        {
            shape: InvalidDocumentSchemaVersion_1.InvalidDocumentSchemaVersion
        }
    ]
};
//# sourceMappingURL=CreateDocument.js.map