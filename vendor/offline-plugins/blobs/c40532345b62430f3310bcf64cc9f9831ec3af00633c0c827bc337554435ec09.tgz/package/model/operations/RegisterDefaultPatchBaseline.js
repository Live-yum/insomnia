"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const RegisterDefaultPatchBaselineInput_1 = require("../shapes/RegisterDefaultPatchBaselineInput");
const RegisterDefaultPatchBaselineOutput_1 = require("../shapes/RegisterDefaultPatchBaselineOutput");
const InvalidResourceId_1 = require("../shapes/InvalidResourceId");
const DoesNotExistException_1 = require("../shapes/DoesNotExistException");
const InternalServerError_1 = require("../shapes/InternalServerError");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.RegisterDefaultPatchBaseline = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "RegisterDefaultPatchBaseline",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: RegisterDefaultPatchBaselineInput_1.RegisterDefaultPatchBaselineInput
    },
    output: {
        shape: RegisterDefaultPatchBaselineOutput_1.RegisterDefaultPatchBaselineOutput
    },
    errors: [
        {
            shape: InvalidResourceId_1.InvalidResourceId
        },
        {
            shape: DoesNotExistException_1.DoesNotExistException
        },
        {
            shape: InternalServerError_1.InternalServerError
        }
    ]
};
//# sourceMappingURL=RegisterDefaultPatchBaseline.js.map