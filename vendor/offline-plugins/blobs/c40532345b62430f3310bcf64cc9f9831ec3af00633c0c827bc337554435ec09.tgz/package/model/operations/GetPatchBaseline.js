"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const GetPatchBaselineInput_1 = require("../shapes/GetPatchBaselineInput");
const GetPatchBaselineOutput_1 = require("../shapes/GetPatchBaselineOutput");
const DoesNotExistException_1 = require("../shapes/DoesNotExistException");
const InvalidResourceId_1 = require("../shapes/InvalidResourceId");
const InternalServerError_1 = require("../shapes/InternalServerError");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.GetPatchBaseline = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "GetPatchBaseline",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: GetPatchBaselineInput_1.GetPatchBaselineInput
    },
    output: {
        shape: GetPatchBaselineOutput_1.GetPatchBaselineOutput
    },
    errors: [
        {
            shape: DoesNotExistException_1.DoesNotExistException
        },
        {
            shape: InvalidResourceId_1.InvalidResourceId
        },
        {
            shape: InternalServerError_1.InternalServerError
        }
    ]
};
//# sourceMappingURL=GetPatchBaseline.js.map