"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const GetInventorySchemaInput_1 = require("../shapes/GetInventorySchemaInput");
const GetInventorySchemaOutput_1 = require("../shapes/GetInventorySchemaOutput");
const InternalServerError_1 = require("../shapes/InternalServerError");
const InvalidTypeNameException_1 = require("../shapes/InvalidTypeNameException");
const InvalidNextToken_1 = require("../shapes/InvalidNextToken");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.GetInventorySchema = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "GetInventorySchema",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: GetInventorySchemaInput_1.GetInventorySchemaInput
    },
    output: {
        shape: GetInventorySchemaOutput_1.GetInventorySchemaOutput
    },
    errors: [
        {
            shape: InternalServerError_1.InternalServerError
        },
        {
            shape: InvalidTypeNameException_1.InvalidTypeNameException
        },
        {
            shape: InvalidNextToken_1.InvalidNextToken
        }
    ]
};
//# sourceMappingURL=GetInventorySchema.js.map