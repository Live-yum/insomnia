"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const DescribePatchBaselinesInput_1 = require("../shapes/DescribePatchBaselinesInput");
const DescribePatchBaselinesOutput_1 = require("../shapes/DescribePatchBaselinesOutput");
const InternalServerError_1 = require("../shapes/InternalServerError");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.DescribePatchBaselines = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "DescribePatchBaselines",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: DescribePatchBaselinesInput_1.DescribePatchBaselinesInput
    },
    output: {
        shape: DescribePatchBaselinesOutput_1.DescribePatchBaselinesOutput
    },
    errors: [
        {
            shape: InternalServerError_1.InternalServerError
        }
    ]
};
//# sourceMappingURL=DescribePatchBaselines.js.map