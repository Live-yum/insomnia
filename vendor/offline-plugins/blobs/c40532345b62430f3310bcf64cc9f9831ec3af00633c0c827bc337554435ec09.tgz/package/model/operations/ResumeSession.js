"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const ResumeSessionInput_1 = require("../shapes/ResumeSessionInput");
const ResumeSessionOutput_1 = require("../shapes/ResumeSessionOutput");
const DoesNotExistException_1 = require("../shapes/DoesNotExistException");
const InternalServerError_1 = require("../shapes/InternalServerError");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.ResumeSession = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "ResumeSession",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: ResumeSessionInput_1.ResumeSessionInput
    },
    output: {
        shape: ResumeSessionOutput_1.ResumeSessionOutput
    },
    errors: [
        {
            shape: DoesNotExistException_1.DoesNotExistException
        },
        {
            shape: InternalServerError_1.InternalServerError
        }
    ]
};
//# sourceMappingURL=ResumeSession.js.map