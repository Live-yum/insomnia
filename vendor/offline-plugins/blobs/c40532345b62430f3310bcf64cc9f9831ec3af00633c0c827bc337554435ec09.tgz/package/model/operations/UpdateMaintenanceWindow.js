"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const UpdateMaintenanceWindowInput_1 = require("../shapes/UpdateMaintenanceWindowInput");
const UpdateMaintenanceWindowOutput_1 = require("../shapes/UpdateMaintenanceWindowOutput");
const DoesNotExistException_1 = require("../shapes/DoesNotExistException");
const InternalServerError_1 = require("../shapes/InternalServerError");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.UpdateMaintenanceWindow = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "UpdateMaintenanceWindow",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: UpdateMaintenanceWindowInput_1.UpdateMaintenanceWindowInput
    },
    output: {
        shape: UpdateMaintenanceWindowOutput_1.UpdateMaintenanceWindowOutput
    },
    errors: [
        {
            shape: DoesNotExistException_1.DoesNotExistException
        },
        {
            shape: InternalServerError_1.InternalServerError
        }
    ]
};
//# sourceMappingURL=UpdateMaintenanceWindow.js.map