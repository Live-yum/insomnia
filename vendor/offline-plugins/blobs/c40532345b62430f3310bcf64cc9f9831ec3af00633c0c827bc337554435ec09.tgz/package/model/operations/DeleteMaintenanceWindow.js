"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const DeleteMaintenanceWindowInput_1 = require("../shapes/DeleteMaintenanceWindowInput");
const DeleteMaintenanceWindowOutput_1 = require("../shapes/DeleteMaintenanceWindowOutput");
const InternalServerError_1 = require("../shapes/InternalServerError");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.DeleteMaintenanceWindow = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "DeleteMaintenanceWindow",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: DeleteMaintenanceWindowInput_1.DeleteMaintenanceWindowInput
    },
    output: {
        shape: DeleteMaintenanceWindowOutput_1.DeleteMaintenanceWindowOutput
    },
    errors: [
        {
            shape: InternalServerError_1.InternalServerError
        }
    ]
};
//# sourceMappingURL=DeleteMaintenanceWindow.js.map