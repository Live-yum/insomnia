"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const CreateMaintenanceWindowInput_1 = require("../shapes/CreateMaintenanceWindowInput");
const CreateMaintenanceWindowOutput_1 = require("../shapes/CreateMaintenanceWindowOutput");
const IdempotentParameterMismatch_1 = require("../shapes/IdempotentParameterMismatch");
const ResourceLimitExceededException_1 = require("../shapes/ResourceLimitExceededException");
const InternalServerError_1 = require("../shapes/InternalServerError");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.CreateMaintenanceWindow = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "CreateMaintenanceWindow",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: CreateMaintenanceWindowInput_1.CreateMaintenanceWindowInput
    },
    output: {
        shape: CreateMaintenanceWindowOutput_1.CreateMaintenanceWindowOutput
    },
    errors: [
        {
            shape: IdempotentParameterMismatch_1.IdempotentParameterMismatch
        },
        {
            shape: ResourceLimitExceededException_1.ResourceLimitExceededException
        },
        {
            shape: InternalServerError_1.InternalServerError
        }
    ]
};
//# sourceMappingURL=CreateMaintenanceWindow.js.map