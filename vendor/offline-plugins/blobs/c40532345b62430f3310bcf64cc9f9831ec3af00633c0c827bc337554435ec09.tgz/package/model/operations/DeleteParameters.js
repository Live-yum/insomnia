"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const DeleteParametersInput_1 = require("../shapes/DeleteParametersInput");
const DeleteParametersOutput_1 = require("../shapes/DeleteParametersOutput");
const InternalServerError_1 = require("../shapes/InternalServerError");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.DeleteParameters = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "DeleteParameters",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: DeleteParametersInput_1.DeleteParametersInput
    },
    output: {
        shape: DeleteParametersOutput_1.DeleteParametersOutput
    },
    errors: [
        {
            shape: InternalServerError_1.InternalServerError
        }
    ]
};
//# sourceMappingURL=DeleteParameters.js.map