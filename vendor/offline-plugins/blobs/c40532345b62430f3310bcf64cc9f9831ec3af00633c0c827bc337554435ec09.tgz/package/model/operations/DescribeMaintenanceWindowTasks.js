"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const DescribeMaintenanceWindowTasksInput_1 = require("../shapes/DescribeMaintenanceWindowTasksInput");
const DescribeMaintenanceWindowTasksOutput_1 = require("../shapes/DescribeMaintenanceWindowTasksOutput");
const DoesNotExistException_1 = require("../shapes/DoesNotExistException");
const InternalServerError_1 = require("../shapes/InternalServerError");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.DescribeMaintenanceWindowTasks = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "DescribeMaintenanceWindowTasks",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: DescribeMaintenanceWindowTasksInput_1.DescribeMaintenanceWindowTasksInput
    },
    output: {
        shape: DescribeMaintenanceWindowTasksOutput_1.DescribeMaintenanceWindowTasksOutput
    },
    errors: [
        {
            shape: DoesNotExistException_1.DoesNotExistException
        },
        {
            shape: InternalServerError_1.InternalServerError
        }
    ]
};
//# sourceMappingURL=DescribeMaintenanceWindowTasks.js.map