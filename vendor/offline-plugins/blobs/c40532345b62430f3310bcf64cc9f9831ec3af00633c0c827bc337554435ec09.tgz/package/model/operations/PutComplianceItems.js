"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const PutComplianceItemsInput_1 = require("../shapes/PutComplianceItemsInput");
const PutComplianceItemsOutput_1 = require("../shapes/PutComplianceItemsOutput");
const InternalServerError_1 = require("../shapes/InternalServerError");
const InvalidItemContentException_1 = require("../shapes/InvalidItemContentException");
const TotalSizeLimitExceededException_1 = require("../shapes/TotalSizeLimitExceededException");
const ItemSizeLimitExceededException_1 = require("../shapes/ItemSizeLimitExceededException");
const ComplianceTypeCountLimitExceededException_1 = require("../shapes/ComplianceTypeCountLimitExceededException");
const InvalidResourceType_1 = require("../shapes/InvalidResourceType");
const InvalidResourceId_1 = require("../shapes/InvalidResourceId");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.PutComplianceItems = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "PutComplianceItems",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: PutComplianceItemsInput_1.PutComplianceItemsInput
    },
    output: {
        shape: PutComplianceItemsOutput_1.PutComplianceItemsOutput
    },
    errors: [
        {
            shape: InternalServerError_1.InternalServerError
        },
        {
            shape: InvalidItemContentException_1.InvalidItemContentException
        },
        {
            shape: TotalSizeLimitExceededException_1.TotalSizeLimitExceededException
        },
        {
            shape: ItemSizeLimitExceededException_1.ItemSizeLimitExceededException
        },
        {
            shape: ComplianceTypeCountLimitExceededException_1.ComplianceTypeCountLimitExceededException
        },
        {
            shape: InvalidResourceType_1.InvalidResourceType
        },
        {
            shape: InvalidResourceId_1.InvalidResourceId
        }
    ]
};
//# sourceMappingURL=PutComplianceItems.js.map