"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const ResetServiceSettingInput_1 = require("../shapes/ResetServiceSettingInput");
const ResetServiceSettingOutput_1 = require("../shapes/ResetServiceSettingOutput");
const InternalServerError_1 = require("../shapes/InternalServerError");
const ServiceSettingNotFound_1 = require("../shapes/ServiceSettingNotFound");
const TooManyUpdates_1 = require("../shapes/TooManyUpdates");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.ResetServiceSetting = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "ResetServiceSetting",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: ResetServiceSettingInput_1.ResetServiceSettingInput
    },
    output: {
        shape: ResetServiceSettingOutput_1.ResetServiceSettingOutput
    },
    errors: [
        {
            shape: InternalServerError_1.InternalServerError
        },
        {
            shape: ServiceSettingNotFound_1.ServiceSettingNotFound
        },
        {
            shape: TooManyUpdates_1.TooManyUpdates
        }
    ]
};
//# sourceMappingURL=ResetServiceSetting.js.map