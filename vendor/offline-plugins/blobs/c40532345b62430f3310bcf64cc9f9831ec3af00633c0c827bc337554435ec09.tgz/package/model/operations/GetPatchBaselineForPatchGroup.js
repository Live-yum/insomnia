"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const GetPatchBaselineForPatchGroupInput_1 = require("../shapes/GetPatchBaselineForPatchGroupInput");
const GetPatchBaselineForPatchGroupOutput_1 = require("../shapes/GetPatchBaselineForPatchGroupOutput");
const InternalServerError_1 = require("../shapes/InternalServerError");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.GetPatchBaselineForPatchGroup = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "GetPatchBaselineForPatchGroup",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: GetPatchBaselineForPatchGroupInput_1.GetPatchBaselineForPatchGroupInput
    },
    output: {
        shape: GetPatchBaselineForPatchGroupOutput_1.GetPatchBaselineForPatchGroupOutput
    },
    errors: [
        {
            shape: InternalServerError_1.InternalServerError
        }
    ]
};
//# sourceMappingURL=GetPatchBaselineForPatchGroup.js.map