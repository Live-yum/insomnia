"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const GetMaintenanceWindowExecutionTaskInvocationInput_1 = require("../shapes/GetMaintenanceWindowExecutionTaskInvocationInput");
const GetMaintenanceWindowExecutionTaskInvocationOutput_1 = require("../shapes/GetMaintenanceWindowExecutionTaskInvocationOutput");
const DoesNotExistException_1 = require("../shapes/DoesNotExistException");
const InternalServerError_1 = require("../shapes/InternalServerError");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.GetMaintenanceWindowExecutionTaskInvocation = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "GetMaintenanceWindowExecutionTaskInvocation",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: GetMaintenanceWindowExecutionTaskInvocationInput_1.GetMaintenanceWindowExecutionTaskInvocationInput
    },
    output: {
        shape: GetMaintenanceWindowExecutionTaskInvocationOutput_1.GetMaintenanceWindowExecutionTaskInvocationOutput
    },
    errors: [
        {
            shape: DoesNotExistException_1.DoesNotExistException
        },
        {
            shape: InternalServerError_1.InternalServerError
        }
    ]
};
//# sourceMappingURL=GetMaintenanceWindowExecutionTaskInvocation.js.map