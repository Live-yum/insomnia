"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const GetParameterHistoryInput_1 = require("../shapes/GetParameterHistoryInput");
const GetParameterHistoryOutput_1 = require("../shapes/GetParameterHistoryOutput");
const InternalServerError_1 = require("../shapes/InternalServerError");
const ParameterNotFound_1 = require("../shapes/ParameterNotFound");
const InvalidNextToken_1 = require("../shapes/InvalidNextToken");
const InvalidKeyId_1 = require("../shapes/InvalidKeyId");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.GetParameterHistory = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "GetParameterHistory",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: GetParameterHistoryInput_1.GetParameterHistoryInput
    },
    output: {
        shape: GetParameterHistoryOutput_1.GetParameterHistoryOutput
    },
    errors: [
        {
            shape: InternalServerError_1.InternalServerError
        },
        {
            shape: ParameterNotFound_1.ParameterNotFound
        },
        {
            shape: InvalidNextToken_1.InvalidNextToken
        },
        {
            shape: InvalidKeyId_1.InvalidKeyId
        }
    ]
};
//# sourceMappingURL=GetParameterHistory.js.map