"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const DescribeActivationsInput_1 = require("../shapes/DescribeActivationsInput");
const DescribeActivationsOutput_1 = require("../shapes/DescribeActivationsOutput");
const InvalidFilter_1 = require("../shapes/InvalidFilter");
const InvalidNextToken_1 = require("../shapes/InvalidNextToken");
const InternalServerError_1 = require("../shapes/InternalServerError");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.DescribeActivations = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "DescribeActivations",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: DescribeActivationsInput_1.DescribeActivationsInput
    },
    output: {
        shape: DescribeActivationsOutput_1.DescribeActivationsOutput
    },
    errors: [
        {
            shape: InvalidFilter_1.InvalidFilter
        },
        {
            shape: InvalidNextToken_1.InvalidNextToken
        },
        {
            shape: InternalServerError_1.InternalServerError
        }
    ]
};
//# sourceMappingURL=DescribeActivations.js.map