"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const GetParameterInput_1 = require("../shapes/GetParameterInput");
const GetParameterOutput_1 = require("../shapes/GetParameterOutput");
const InternalServerError_1 = require("../shapes/InternalServerError");
const InvalidKeyId_1 = require("../shapes/InvalidKeyId");
const ParameterNotFound_1 = require("../shapes/ParameterNotFound");
const ParameterVersionNotFound_1 = require("../shapes/ParameterVersionNotFound");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.GetParameter = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "GetParameter",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: GetParameterInput_1.GetParameterInput
    },
    output: {
        shape: GetParameterOutput_1.GetParameterOutput
    },
    errors: [
        {
            shape: InternalServerError_1.InternalServerError
        },
        {
            shape: InvalidKeyId_1.InvalidKeyId
        },
        {
            shape: ParameterNotFound_1.ParameterNotFound
        },
        {
            shape: ParameterVersionNotFound_1.ParameterVersionNotFound
        }
    ]
};
//# sourceMappingURL=GetParameter.js.map