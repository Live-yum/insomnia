"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const ModifyDocumentPermissionInput_1 = require("../shapes/ModifyDocumentPermissionInput");
const ModifyDocumentPermissionOutput_1 = require("../shapes/ModifyDocumentPermissionOutput");
const InternalServerError_1 = require("../shapes/InternalServerError");
const InvalidDocument_1 = require("../shapes/InvalidDocument");
const InvalidPermissionType_1 = require("../shapes/InvalidPermissionType");
const DocumentPermissionLimit_1 = require("../shapes/DocumentPermissionLimit");
const DocumentLimitExceeded_1 = require("../shapes/DocumentLimitExceeded");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.ModifyDocumentPermission = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "ModifyDocumentPermission",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: ModifyDocumentPermissionInput_1.ModifyDocumentPermissionInput
    },
    output: {
        shape: ModifyDocumentPermissionOutput_1.ModifyDocumentPermissionOutput
    },
    errors: [
        {
            shape: InternalServerError_1.InternalServerError
        },
        {
            shape: InvalidDocument_1.InvalidDocument
        },
        {
            shape: InvalidPermissionType_1.InvalidPermissionType
        },
        {
            shape: DocumentPermissionLimit_1.DocumentPermissionLimit
        },
        {
            shape: DocumentLimitExceeded_1.DocumentLimitExceeded
        }
    ]
};
//# sourceMappingURL=ModifyDocumentPermission.js.map