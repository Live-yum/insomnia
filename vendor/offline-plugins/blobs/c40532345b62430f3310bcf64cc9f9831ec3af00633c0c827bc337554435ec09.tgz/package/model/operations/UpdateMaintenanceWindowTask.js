"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const UpdateMaintenanceWindowTaskInput_1 = require("../shapes/UpdateMaintenanceWindowTaskInput");
const UpdateMaintenanceWindowTaskOutput_1 = require("../shapes/UpdateMaintenanceWindowTaskOutput");
const DoesNotExistException_1 = require("../shapes/DoesNotExistException");
const InternalServerError_1 = require("../shapes/InternalServerError");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.UpdateMaintenanceWindowTask = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "UpdateMaintenanceWindowTask",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: UpdateMaintenanceWindowTaskInput_1.UpdateMaintenanceWindowTaskInput
    },
    output: {
        shape: UpdateMaintenanceWindowTaskOutput_1.UpdateMaintenanceWindowTaskOutput
    },
    errors: [
        {
            shape: DoesNotExistException_1.DoesNotExistException
        },
        {
            shape: InternalServerError_1.InternalServerError
        }
    ]
};
//# sourceMappingURL=UpdateMaintenanceWindowTask.js.map