"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const DescribeMaintenanceWindowExecutionTasksInput_1 = require("../shapes/DescribeMaintenanceWindowExecutionTasksInput");
const DescribeMaintenanceWindowExecutionTasksOutput_1 = require("../shapes/DescribeMaintenanceWindowExecutionTasksOutput");
const DoesNotExistException_1 = require("../shapes/DoesNotExistException");
const InternalServerError_1 = require("../shapes/InternalServerError");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.DescribeMaintenanceWindowExecutionTasks = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "DescribeMaintenanceWindowExecutionTasks",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: DescribeMaintenanceWindowExecutionTasksInput_1.DescribeMaintenanceWindowExecutionTasksInput
    },
    output: {
        shape: DescribeMaintenanceWindowExecutionTasksOutput_1.DescribeMaintenanceWindowExecutionTasksOutput
    },
    errors: [
        {
            shape: DoesNotExistException_1.DoesNotExistException
        },
        {
            shape: InternalServerError_1.InternalServerError
        }
    ]
};
//# sourceMappingURL=DescribeMaintenanceWindowExecutionTasks.js.map