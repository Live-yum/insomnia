"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const ListDocumentsInput_1 = require("../shapes/ListDocumentsInput");
const ListDocumentsOutput_1 = require("../shapes/ListDocumentsOutput");
const InternalServerError_1 = require("../shapes/InternalServerError");
const InvalidNextToken_1 = require("../shapes/InvalidNextToken");
const InvalidFilterKey_1 = require("../shapes/InvalidFilterKey");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.ListDocuments = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "ListDocuments",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: ListDocumentsInput_1.ListDocumentsInput
    },
    output: {
        shape: ListDocumentsOutput_1.ListDocumentsOutput
    },
    errors: [
        {
            shape: InternalServerError_1.InternalServerError
        },
        {
            shape: InvalidNextToken_1.InvalidNextToken
        },
        {
            shape: InvalidFilterKey_1.InvalidFilterKey
        }
    ]
};
//# sourceMappingURL=ListDocuments.js.map