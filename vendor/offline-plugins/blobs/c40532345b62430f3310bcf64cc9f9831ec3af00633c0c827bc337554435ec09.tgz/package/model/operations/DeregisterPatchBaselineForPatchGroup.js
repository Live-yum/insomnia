"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const DeregisterPatchBaselineForPatchGroupInput_1 = require("../shapes/DeregisterPatchBaselineForPatchGroupInput");
const DeregisterPatchBaselineForPatchGroupOutput_1 = require("../shapes/DeregisterPatchBaselineForPatchGroupOutput");
const InvalidResourceId_1 = require("../shapes/InvalidResourceId");
const InternalServerError_1 = require("../shapes/InternalServerError");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.DeregisterPatchBaselineForPatchGroup = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "DeregisterPatchBaselineForPatchGroup",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: DeregisterPatchBaselineForPatchGroupInput_1.DeregisterPatchBaselineForPatchGroupInput
    },
    output: {
        shape: DeregisterPatchBaselineForPatchGroupOutput_1.DeregisterPatchBaselineForPatchGroupOutput
    },
    errors: [
        {
            shape: InvalidResourceId_1.InvalidResourceId
        },
        {
            shape: InternalServerError_1.InternalServerError
        }
    ]
};
//# sourceMappingURL=DeregisterPatchBaselineForPatchGroup.js.map