"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const DescribeEffectiveInstanceAssociationsInput_1 = require("../shapes/DescribeEffectiveInstanceAssociationsInput");
const DescribeEffectiveInstanceAssociationsOutput_1 = require("../shapes/DescribeEffectiveInstanceAssociationsOutput");
const InternalServerError_1 = require("../shapes/InternalServerError");
const InvalidInstanceId_1 = require("../shapes/InvalidInstanceId");
const InvalidNextToken_1 = require("../shapes/InvalidNextToken");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.DescribeEffectiveInstanceAssociations = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "DescribeEffectiveInstanceAssociations",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: DescribeEffectiveInstanceAssociationsInput_1.DescribeEffectiveInstanceAssociationsInput
    },
    output: {
        shape: DescribeEffectiveInstanceAssociationsOutput_1.DescribeEffectiveInstanceAssociationsOutput
    },
    errors: [
        {
            shape: InternalServerError_1.InternalServerError
        },
        {
            shape: InvalidInstanceId_1.InvalidInstanceId
        },
        {
            shape: InvalidNextToken_1.InvalidNextToken
        }
    ]
};
//# sourceMappingURL=DescribeEffectiveInstanceAssociations.js.map