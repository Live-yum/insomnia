"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const DescribePatchGroupsInput_1 = require("../shapes/DescribePatchGroupsInput");
const DescribePatchGroupsOutput_1 = require("../shapes/DescribePatchGroupsOutput");
const InternalServerError_1 = require("../shapes/InternalServerError");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.DescribePatchGroups = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "DescribePatchGroups",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: DescribePatchGroupsInput_1.DescribePatchGroupsInput
    },
    output: {
        shape: DescribePatchGroupsOutput_1.DescribePatchGroupsOutput
    },
    errors: [
        {
            shape: InternalServerError_1.InternalServerError
        }
    ]
};
//# sourceMappingURL=DescribePatchGroups.js.map