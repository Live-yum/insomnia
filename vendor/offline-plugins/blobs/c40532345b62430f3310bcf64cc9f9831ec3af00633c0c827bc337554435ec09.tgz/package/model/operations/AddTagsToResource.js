"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const AddTagsToResourceInput_1 = require("../shapes/AddTagsToResourceInput");
const AddTagsToResourceOutput_1 = require("../shapes/AddTagsToResourceOutput");
const InvalidResourceType_1 = require("../shapes/InvalidResourceType");
const InvalidResourceId_1 = require("../shapes/InvalidResourceId");
const InternalServerError_1 = require("../shapes/InternalServerError");
const TooManyTagsError_1 = require("../shapes/TooManyTagsError");
const TooManyUpdates_1 = require("../shapes/TooManyUpdates");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.AddTagsToResource = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "AddTagsToResource",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: AddTagsToResourceInput_1.AddTagsToResourceInput
    },
    output: {
        shape: AddTagsToResourceOutput_1.AddTagsToResourceOutput
    },
    errors: [
        {
            shape: InvalidResourceType_1.InvalidResourceType
        },
        {
            shape: InvalidResourceId_1.InvalidResourceId
        },
        {
            shape: InternalServerError_1.InternalServerError
        },
        {
            shape: TooManyTagsError_1.TooManyTagsError
        },
        {
            shape: TooManyUpdates_1.TooManyUpdates
        }
    ]
};
//# sourceMappingURL=AddTagsToResource.js.map