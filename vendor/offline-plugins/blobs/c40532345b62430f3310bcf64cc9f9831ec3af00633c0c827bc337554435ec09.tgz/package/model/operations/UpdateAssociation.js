"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const UpdateAssociationInput_1 = require("../shapes/UpdateAssociationInput");
const UpdateAssociationOutput_1 = require("../shapes/UpdateAssociationOutput");
const InternalServerError_1 = require("../shapes/InternalServerError");
const InvalidSchedule_1 = require("../shapes/InvalidSchedule");
const InvalidParameters_1 = require("../shapes/InvalidParameters");
const InvalidOutputLocation_1 = require("../shapes/InvalidOutputLocation");
const InvalidDocumentVersion_1 = require("../shapes/InvalidDocumentVersion");
const AssociationDoesNotExist_1 = require("../shapes/AssociationDoesNotExist");
const InvalidUpdate_1 = require("../shapes/InvalidUpdate");
const TooManyUpdates_1 = require("../shapes/TooManyUpdates");
const InvalidDocument_1 = require("../shapes/InvalidDocument");
const InvalidTarget_1 = require("../shapes/InvalidTarget");
const InvalidAssociationVersion_1 = require("../shapes/InvalidAssociationVersion");
const AssociationVersionLimitExceeded_1 = require("../shapes/AssociationVersionLimitExceeded");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.UpdateAssociation = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "UpdateAssociation",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: UpdateAssociationInput_1.UpdateAssociationInput
    },
    output: {
        shape: UpdateAssociationOutput_1.UpdateAssociationOutput
    },
    errors: [
        {
            shape: InternalServerError_1.InternalServerError
        },
        {
            shape: InvalidSchedule_1.InvalidSchedule
        },
        {
            shape: InvalidParameters_1.InvalidParameters
        },
        {
            shape: InvalidOutputLocation_1.InvalidOutputLocation
        },
        {
            shape: InvalidDocumentVersion_1.InvalidDocumentVersion
        },
        {
            shape: AssociationDoesNotExist_1.AssociationDoesNotExist
        },
        {
            shape: InvalidUpdate_1.InvalidUpdate
        },
        {
            shape: TooManyUpdates_1.TooManyUpdates
        },
        {
            shape: InvalidDocument_1.InvalidDocument
        },
        {
            shape: InvalidTarget_1.InvalidTarget
        },
        {
            shape: InvalidAssociationVersion_1.InvalidAssociationVersion
        },
        {
            shape: AssociationVersionLimitExceeded_1.AssociationVersionLimitExceeded
        }
    ]
};
//# sourceMappingURL=UpdateAssociation.js.map