"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const GetInventoryInput_1 = require("../shapes/GetInventoryInput");
const GetInventoryOutput_1 = require("../shapes/GetInventoryOutput");
const InternalServerError_1 = require("../shapes/InternalServerError");
const InvalidFilter_1 = require("../shapes/InvalidFilter");
const InvalidInventoryGroupException_1 = require("../shapes/InvalidInventoryGroupException");
const InvalidNextToken_1 = require("../shapes/InvalidNextToken");
const InvalidTypeNameException_1 = require("../shapes/InvalidTypeNameException");
const InvalidAggregatorException_1 = require("../shapes/InvalidAggregatorException");
const InvalidResultAttributeException_1 = require("../shapes/InvalidResultAttributeException");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.GetInventory = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "GetInventory",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: GetInventoryInput_1.GetInventoryInput
    },
    output: {
        shape: GetInventoryOutput_1.GetInventoryOutput
    },
    errors: [
        {
            shape: InternalServerError_1.InternalServerError
        },
        {
            shape: InvalidFilter_1.InvalidFilter
        },
        {
            shape: InvalidInventoryGroupException_1.InvalidInventoryGroupException
        },
        {
            shape: InvalidNextToken_1.InvalidNextToken
        },
        {
            shape: InvalidTypeNameException_1.InvalidTypeNameException
        },
        {
            shape: InvalidAggregatorException_1.InvalidAggregatorException
        },
        {
            shape: InvalidResultAttributeException_1.InvalidResultAttributeException
        }
    ]
};
//# sourceMappingURL=GetInventory.js.map