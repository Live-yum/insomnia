"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const ListAssociationsInput_1 = require("../shapes/ListAssociationsInput");
const ListAssociationsOutput_1 = require("../shapes/ListAssociationsOutput");
const InternalServerError_1 = require("../shapes/InternalServerError");
const InvalidNextToken_1 = require("../shapes/InvalidNextToken");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.ListAssociations = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "ListAssociations",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: ListAssociationsInput_1.ListAssociationsInput
    },
    output: {
        shape: ListAssociationsOutput_1.ListAssociationsOutput
    },
    errors: [
        {
            shape: InternalServerError_1.InternalServerError
        },
        {
            shape: InvalidNextToken_1.InvalidNextToken
        }
    ]
};
//# sourceMappingURL=ListAssociations.js.map