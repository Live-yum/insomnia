"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const DescribePatchPropertiesInput_1 = require("../shapes/DescribePatchPropertiesInput");
const DescribePatchPropertiesOutput_1 = require("../shapes/DescribePatchPropertiesOutput");
const InternalServerError_1 = require("../shapes/InternalServerError");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.DescribePatchProperties = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "DescribePatchProperties",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: DescribePatchPropertiesInput_1.DescribePatchPropertiesInput
    },
    output: {
        shape: DescribePatchPropertiesOutput_1.DescribePatchPropertiesOutput
    },
    errors: [
        {
            shape: InternalServerError_1.InternalServerError
        }
    ]
};
//# sourceMappingURL=DescribePatchProperties.js.map