"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const GetParametersByPathInput_1 = require("../shapes/GetParametersByPathInput");
const GetParametersByPathOutput_1 = require("../shapes/GetParametersByPathOutput");
const InternalServerError_1 = require("../shapes/InternalServerError");
const InvalidFilterKey_1 = require("../shapes/InvalidFilterKey");
const InvalidFilterOption_1 = require("../shapes/InvalidFilterOption");
const InvalidFilterValue_1 = require("../shapes/InvalidFilterValue");
const InvalidKeyId_1 = require("../shapes/InvalidKeyId");
const InvalidNextToken_1 = require("../shapes/InvalidNextToken");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.GetParametersByPath = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "GetParametersByPath",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: GetParametersByPathInput_1.GetParametersByPathInput
    },
    output: {
        shape: GetParametersByPathOutput_1.GetParametersByPathOutput
    },
    errors: [
        {
            shape: InternalServerError_1.InternalServerError
        },
        {
            shape: InvalidFilterKey_1.InvalidFilterKey
        },
        {
            shape: InvalidFilterOption_1.InvalidFilterOption
        },
        {
            shape: InvalidFilterValue_1.InvalidFilterValue
        },
        {
            shape: InvalidKeyId_1.InvalidKeyId
        },
        {
            shape: InvalidNextToken_1.InvalidNextToken
        }
    ]
};
//# sourceMappingURL=GetParametersByPath.js.map