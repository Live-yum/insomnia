"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const GetOpsItemInput_1 = require("../shapes/GetOpsItemInput");
const GetOpsItemOutput_1 = require("../shapes/GetOpsItemOutput");
const InternalServerError_1 = require("../shapes/InternalServerError");
const OpsItemNotFoundException_1 = require("../shapes/OpsItemNotFoundException");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.GetOpsItem = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "GetOpsItem",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: GetOpsItemInput_1.GetOpsItemInput
    },
    output: {
        shape: GetOpsItemOutput_1.GetOpsItemOutput
    },
    errors: [
        {
            shape: InternalServerError_1.InternalServerError
        },
        {
            shape: OpsItemNotFoundException_1.OpsItemNotFoundException
        }
    ]
};
//# sourceMappingURL=GetOpsItem.js.map