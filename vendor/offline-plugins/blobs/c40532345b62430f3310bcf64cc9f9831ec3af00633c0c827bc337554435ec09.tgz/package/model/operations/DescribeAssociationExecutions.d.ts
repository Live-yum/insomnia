import { OperationModel as _Operation_ } from "@aws-sdk/types";
export declare const DescribeAssociationExecutions: _Operation_;
