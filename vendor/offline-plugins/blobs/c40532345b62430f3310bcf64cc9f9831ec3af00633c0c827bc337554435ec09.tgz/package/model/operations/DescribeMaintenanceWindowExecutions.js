"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const DescribeMaintenanceWindowExecutionsInput_1 = require("../shapes/DescribeMaintenanceWindowExecutionsInput");
const DescribeMaintenanceWindowExecutionsOutput_1 = require("../shapes/DescribeMaintenanceWindowExecutionsOutput");
const InternalServerError_1 = require("../shapes/InternalServerError");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.DescribeMaintenanceWindowExecutions = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "DescribeMaintenanceWindowExecutions",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: DescribeMaintenanceWindowExecutionsInput_1.DescribeMaintenanceWindowExecutionsInput
    },
    output: {
        shape: DescribeMaintenanceWindowExecutionsOutput_1.DescribeMaintenanceWindowExecutionsOutput
    },
    errors: [
        {
            shape: InternalServerError_1.InternalServerError
        }
    ]
};
//# sourceMappingURL=DescribeMaintenanceWindowExecutions.js.map