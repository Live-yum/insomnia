"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const ListDocumentVersionsInput_1 = require("../shapes/ListDocumentVersionsInput");
const ListDocumentVersionsOutput_1 = require("../shapes/ListDocumentVersionsOutput");
const InternalServerError_1 = require("../shapes/InternalServerError");
const InvalidNextToken_1 = require("../shapes/InvalidNextToken");
const InvalidDocument_1 = require("../shapes/InvalidDocument");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.ListDocumentVersions = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "ListDocumentVersions",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: ListDocumentVersionsInput_1.ListDocumentVersionsInput
    },
    output: {
        shape: ListDocumentVersionsOutput_1.ListDocumentVersionsOutput
    },
    errors: [
        {
            shape: InternalServerError_1.InternalServerError
        },
        {
            shape: InvalidNextToken_1.InvalidNextToken
        },
        {
            shape: InvalidDocument_1.InvalidDocument
        }
    ]
};
//# sourceMappingURL=ListDocumentVersions.js.map