"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const DescribeInstancePatchStatesForPatchGroupInput_1 = require("../shapes/DescribeInstancePatchStatesForPatchGroupInput");
const DescribeInstancePatchStatesForPatchGroupOutput_1 = require("../shapes/DescribeInstancePatchStatesForPatchGroupOutput");
const InternalServerError_1 = require("../shapes/InternalServerError");
const InvalidFilter_1 = require("../shapes/InvalidFilter");
const InvalidNextToken_1 = require("../shapes/InvalidNextToken");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.DescribeInstancePatchStatesForPatchGroup = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "DescribeInstancePatchStatesForPatchGroup",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: DescribeInstancePatchStatesForPatchGroupInput_1.DescribeInstancePatchStatesForPatchGroupInput
    },
    output: {
        shape: DescribeInstancePatchStatesForPatchGroupOutput_1.DescribeInstancePatchStatesForPatchGroupOutput
    },
    errors: [
        {
            shape: InternalServerError_1.InternalServerError
        },
        {
            shape: InvalidFilter_1.InvalidFilter
        },
        {
            shape: InvalidNextToken_1.InvalidNextToken
        }
    ]
};
//# sourceMappingURL=DescribeInstancePatchStatesForPatchGroup.js.map