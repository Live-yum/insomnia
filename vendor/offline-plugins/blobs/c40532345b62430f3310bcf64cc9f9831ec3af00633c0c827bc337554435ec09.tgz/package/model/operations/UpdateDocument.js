"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const UpdateDocumentInput_1 = require("../shapes/UpdateDocumentInput");
const UpdateDocumentOutput_1 = require("../shapes/UpdateDocumentOutput");
const MaxDocumentSizeExceeded_1 = require("../shapes/MaxDocumentSizeExceeded");
const DocumentVersionLimitExceeded_1 = require("../shapes/DocumentVersionLimitExceeded");
const InternalServerError_1 = require("../shapes/InternalServerError");
const DuplicateDocumentContent_1 = require("../shapes/DuplicateDocumentContent");
const DuplicateDocumentVersionName_1 = require("../shapes/DuplicateDocumentVersionName");
const InvalidDocumentContent_1 = require("../shapes/InvalidDocumentContent");
const InvalidDocumentVersion_1 = require("../shapes/InvalidDocumentVersion");
const InvalidDocumentSchemaVersion_1 = require("../shapes/InvalidDocumentSchemaVersion");
const InvalidDocument_1 = require("../shapes/InvalidDocument");
const InvalidDocumentOperation_1 = require("../shapes/InvalidDocumentOperation");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.UpdateDocument = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "UpdateDocument",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: UpdateDocumentInput_1.UpdateDocumentInput
    },
    output: {
        shape: UpdateDocumentOutput_1.UpdateDocumentOutput
    },
    errors: [
        {
            shape: MaxDocumentSizeExceeded_1.MaxDocumentSizeExceeded
        },
        {
            shape: DocumentVersionLimitExceeded_1.DocumentVersionLimitExceeded
        },
        {
            shape: InternalServerError_1.InternalServerError
        },
        {
            shape: DuplicateDocumentContent_1.DuplicateDocumentContent
        },
        {
            shape: DuplicateDocumentVersionName_1.DuplicateDocumentVersionName
        },
        {
            shape: InvalidDocumentContent_1.InvalidDocumentContent
        },
        {
            shape: InvalidDocumentVersion_1.InvalidDocumentVersion
        },
        {
            shape: InvalidDocumentSchemaVersion_1.InvalidDocumentSchemaVersion
        },
        {
            shape: InvalidDocument_1.InvalidDocument
        },
        {
            shape: InvalidDocumentOperation_1.InvalidDocumentOperation
        }
    ]
};
//# sourceMappingURL=UpdateDocument.js.map