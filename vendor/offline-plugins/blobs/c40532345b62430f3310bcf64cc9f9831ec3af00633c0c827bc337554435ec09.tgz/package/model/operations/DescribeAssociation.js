"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const DescribeAssociationInput_1 = require("../shapes/DescribeAssociationInput");
const DescribeAssociationOutput_1 = require("../shapes/DescribeAssociationOutput");
const AssociationDoesNotExist_1 = require("../shapes/AssociationDoesNotExist");
const InvalidAssociationVersion_1 = require("../shapes/InvalidAssociationVersion");
const InternalServerError_1 = require("../shapes/InternalServerError");
const InvalidDocument_1 = require("../shapes/InvalidDocument");
const InvalidInstanceId_1 = require("../shapes/InvalidInstanceId");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.DescribeAssociation = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "DescribeAssociation",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: DescribeAssociationInput_1.DescribeAssociationInput
    },
    output: {
        shape: DescribeAssociationOutput_1.DescribeAssociationOutput
    },
    errors: [
        {
            shape: AssociationDoesNotExist_1.AssociationDoesNotExist
        },
        {
            shape: InvalidAssociationVersion_1.InvalidAssociationVersion
        },
        {
            shape: InternalServerError_1.InternalServerError
        },
        {
            shape: InvalidDocument_1.InvalidDocument
        },
        {
            shape: InvalidInstanceId_1.InvalidInstanceId
        }
    ]
};
//# sourceMappingURL=DescribeAssociation.js.map