"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const GetDefaultPatchBaselineInput_1 = require("../shapes/GetDefaultPatchBaselineInput");
const GetDefaultPatchBaselineOutput_1 = require("../shapes/GetDefaultPatchBaselineOutput");
const InternalServerError_1 = require("../shapes/InternalServerError");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.GetDefaultPatchBaseline = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "GetDefaultPatchBaseline",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: GetDefaultPatchBaselineInput_1.GetDefaultPatchBaselineInput
    },
    output: {
        shape: GetDefaultPatchBaselineOutput_1.GetDefaultPatchBaselineOutput
    },
    errors: [
        {
            shape: InternalServerError_1.InternalServerError
        }
    ]
};
//# sourceMappingURL=GetDefaultPatchBaseline.js.map