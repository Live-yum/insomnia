"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const DeletePatchBaselineInput_1 = require("../shapes/DeletePatchBaselineInput");
const DeletePatchBaselineOutput_1 = require("../shapes/DeletePatchBaselineOutput");
const ResourceInUseException_1 = require("../shapes/ResourceInUseException");
const InternalServerError_1 = require("../shapes/InternalServerError");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.DeletePatchBaseline = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "DeletePatchBaseline",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: DeletePatchBaselineInput_1.DeletePatchBaselineInput
    },
    output: {
        shape: DeletePatchBaselineOutput_1.DeletePatchBaselineOutput
    },
    errors: [
        {
            shape: ResourceInUseException_1.ResourceInUseException
        },
        {
            shape: InternalServerError_1.InternalServerError
        }
    ]
};
//# sourceMappingURL=DeletePatchBaseline.js.map