import { OperationModel as _Operation_ } from "@aws-sdk/types";
export declare const GetOpsItem: _Operation_;
