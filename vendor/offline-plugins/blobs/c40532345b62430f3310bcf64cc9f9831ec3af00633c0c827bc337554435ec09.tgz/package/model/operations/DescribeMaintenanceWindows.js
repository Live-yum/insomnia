"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const DescribeMaintenanceWindowsInput_1 = require("../shapes/DescribeMaintenanceWindowsInput");
const DescribeMaintenanceWindowsOutput_1 = require("../shapes/DescribeMaintenanceWindowsOutput");
const InternalServerError_1 = require("../shapes/InternalServerError");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.DescribeMaintenanceWindows = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "DescribeMaintenanceWindows",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: DescribeMaintenanceWindowsInput_1.DescribeMaintenanceWindowsInput
    },
    output: {
        shape: DescribeMaintenanceWindowsOutput_1.DescribeMaintenanceWindowsOutput
    },
    errors: [
        {
            shape: InternalServerError_1.InternalServerError
        }
    ]
};
//# sourceMappingURL=DescribeMaintenanceWindows.js.map