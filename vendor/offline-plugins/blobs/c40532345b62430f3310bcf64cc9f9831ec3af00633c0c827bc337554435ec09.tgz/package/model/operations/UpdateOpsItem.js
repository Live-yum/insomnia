"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const UpdateOpsItemInput_1 = require("../shapes/UpdateOpsItemInput");
const UpdateOpsItemOutput_1 = require("../shapes/UpdateOpsItemOutput");
const InternalServerError_1 = require("../shapes/InternalServerError");
const OpsItemNotFoundException_1 = require("../shapes/OpsItemNotFoundException");
const OpsItemAlreadyExistsException_1 = require("../shapes/OpsItemAlreadyExistsException");
const OpsItemLimitExceededException_1 = require("../shapes/OpsItemLimitExceededException");
const OpsItemInvalidParameterException_1 = require("../shapes/OpsItemInvalidParameterException");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.UpdateOpsItem = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "UpdateOpsItem",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: UpdateOpsItemInput_1.UpdateOpsItemInput
    },
    output: {
        shape: UpdateOpsItemOutput_1.UpdateOpsItemOutput
    },
    errors: [
        {
            shape: InternalServerError_1.InternalServerError
        },
        {
            shape: OpsItemNotFoundException_1.OpsItemNotFoundException
        },
        {
            shape: OpsItemAlreadyExistsException_1.OpsItemAlreadyExistsException
        },
        {
            shape: OpsItemLimitExceededException_1.OpsItemLimitExceededException
        },
        {
            shape: OpsItemInvalidParameterException_1.OpsItemInvalidParameterException
        }
    ]
};
//# sourceMappingURL=UpdateOpsItem.js.map