"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const ListComplianceSummariesInput_1 = require("../shapes/ListComplianceSummariesInput");
const ListComplianceSummariesOutput_1 = require("../shapes/ListComplianceSummariesOutput");
const InvalidFilter_1 = require("../shapes/InvalidFilter");
const InvalidNextToken_1 = require("../shapes/InvalidNextToken");
const InternalServerError_1 = require("../shapes/InternalServerError");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.ListComplianceSummaries = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "ListComplianceSummaries",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: ListComplianceSummariesInput_1.ListComplianceSummariesInput
    },
    output: {
        shape: ListComplianceSummariesOutput_1.ListComplianceSummariesOutput
    },
    errors: [
        {
            shape: InvalidFilter_1.InvalidFilter
        },
        {
            shape: InvalidNextToken_1.InvalidNextToken
        },
        {
            shape: InternalServerError_1.InternalServerError
        }
    ]
};
//# sourceMappingURL=ListComplianceSummaries.js.map