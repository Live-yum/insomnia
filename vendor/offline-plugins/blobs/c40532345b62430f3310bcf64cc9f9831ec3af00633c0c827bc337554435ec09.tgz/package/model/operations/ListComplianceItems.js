"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const ListComplianceItemsInput_1 = require("../shapes/ListComplianceItemsInput");
const ListComplianceItemsOutput_1 = require("../shapes/ListComplianceItemsOutput");
const InvalidResourceType_1 = require("../shapes/InvalidResourceType");
const InvalidResourceId_1 = require("../shapes/InvalidResourceId");
const InternalServerError_1 = require("../shapes/InternalServerError");
const InvalidFilter_1 = require("../shapes/InvalidFilter");
const InvalidNextToken_1 = require("../shapes/InvalidNextToken");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.ListComplianceItems = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "ListComplianceItems",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: ListComplianceItemsInput_1.ListComplianceItemsInput
    },
    output: {
        shape: ListComplianceItemsOutput_1.ListComplianceItemsOutput
    },
    errors: [
        {
            shape: InvalidResourceType_1.InvalidResourceType
        },
        {
            shape: InvalidResourceId_1.InvalidResourceId
        },
        {
            shape: InternalServerError_1.InternalServerError
        },
        {
            shape: InvalidFilter_1.InvalidFilter
        },
        {
            shape: InvalidNextToken_1.InvalidNextToken
        }
    ]
};
//# sourceMappingURL=ListComplianceItems.js.map