"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const DescribeInventoryDeletionsInput_1 = require("../shapes/DescribeInventoryDeletionsInput");
const DescribeInventoryDeletionsOutput_1 = require("../shapes/DescribeInventoryDeletionsOutput");
const InternalServerError_1 = require("../shapes/InternalServerError");
const InvalidDeletionIdException_1 = require("../shapes/InvalidDeletionIdException");
const InvalidNextToken_1 = require("../shapes/InvalidNextToken");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.DescribeInventoryDeletions = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "DescribeInventoryDeletions",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: DescribeInventoryDeletionsInput_1.DescribeInventoryDeletionsInput
    },
    output: {
        shape: DescribeInventoryDeletionsOutput_1.DescribeInventoryDeletionsOutput
    },
    errors: [
        {
            shape: InternalServerError_1.InternalServerError
        },
        {
            shape: InvalidDeletionIdException_1.InvalidDeletionIdException
        },
        {
            shape: InvalidNextToken_1.InvalidNextToken
        }
    ]
};
//# sourceMappingURL=DescribeInventoryDeletions.js.map