import { OperationModel as _Operation_ } from "@aws-sdk/types";
export declare const DescribePatchGroupState: _Operation_;
