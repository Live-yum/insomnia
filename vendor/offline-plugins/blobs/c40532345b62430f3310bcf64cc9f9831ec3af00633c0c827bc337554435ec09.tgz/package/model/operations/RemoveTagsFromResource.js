"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const RemoveTagsFromResourceInput_1 = require("../shapes/RemoveTagsFromResourceInput");
const RemoveTagsFromResourceOutput_1 = require("../shapes/RemoveTagsFromResourceOutput");
const InvalidResourceType_1 = require("../shapes/InvalidResourceType");
const InvalidResourceId_1 = require("../shapes/InvalidResourceId");
const InternalServerError_1 = require("../shapes/InternalServerError");
const TooManyUpdates_1 = require("../shapes/TooManyUpdates");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.RemoveTagsFromResource = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "RemoveTagsFromResource",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: RemoveTagsFromResourceInput_1.RemoveTagsFromResourceInput
    },
    output: {
        shape: RemoveTagsFromResourceOutput_1.RemoveTagsFromResourceOutput
    },
    errors: [
        {
            shape: InvalidResourceType_1.InvalidResourceType
        },
        {
            shape: InvalidResourceId_1.InvalidResourceId
        },
        {
            shape: InternalServerError_1.InternalServerError
        },
        {
            shape: TooManyUpdates_1.TooManyUpdates
        }
    ]
};
//# sourceMappingURL=RemoveTagsFromResource.js.map