"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const CancelMaintenanceWindowExecutionInput_1 = require("../shapes/CancelMaintenanceWindowExecutionInput");
const CancelMaintenanceWindowExecutionOutput_1 = require("../shapes/CancelMaintenanceWindowExecutionOutput");
const InternalServerError_1 = require("../shapes/InternalServerError");
const DoesNotExistException_1 = require("../shapes/DoesNotExistException");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.CancelMaintenanceWindowExecution = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "CancelMaintenanceWindowExecution",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: CancelMaintenanceWindowExecutionInput_1.CancelMaintenanceWindowExecutionInput
    },
    output: {
        shape: CancelMaintenanceWindowExecutionOutput_1.CancelMaintenanceWindowExecutionOutput
    },
    errors: [
        {
            shape: InternalServerError_1.InternalServerError
        },
        {
            shape: DoesNotExistException_1.DoesNotExistException
        }
    ]
};
//# sourceMappingURL=CancelMaintenanceWindowExecution.js.map