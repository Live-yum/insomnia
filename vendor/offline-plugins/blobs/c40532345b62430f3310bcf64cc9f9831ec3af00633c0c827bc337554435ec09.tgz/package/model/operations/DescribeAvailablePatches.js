"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const DescribeAvailablePatchesInput_1 = require("../shapes/DescribeAvailablePatchesInput");
const DescribeAvailablePatchesOutput_1 = require("../shapes/DescribeAvailablePatchesOutput");
const InternalServerError_1 = require("../shapes/InternalServerError");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.DescribeAvailablePatches = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "DescribeAvailablePatches",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: DescribeAvailablePatchesInput_1.DescribeAvailablePatchesInput
    },
    output: {
        shape: DescribeAvailablePatchesOutput_1.DescribeAvailablePatchesOutput
    },
    errors: [
        {
            shape: InternalServerError_1.InternalServerError
        }
    ]
};
//# sourceMappingURL=DescribeAvailablePatches.js.map