"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const PutInventoryInput_1 = require("../shapes/PutInventoryInput");
const PutInventoryOutput_1 = require("../shapes/PutInventoryOutput");
const InternalServerError_1 = require("../shapes/InternalServerError");
const InvalidInstanceId_1 = require("../shapes/InvalidInstanceId");
const InvalidTypeNameException_1 = require("../shapes/InvalidTypeNameException");
const InvalidItemContentException_1 = require("../shapes/InvalidItemContentException");
const TotalSizeLimitExceededException_1 = require("../shapes/TotalSizeLimitExceededException");
const ItemSizeLimitExceededException_1 = require("../shapes/ItemSizeLimitExceededException");
const ItemContentMismatchException_1 = require("../shapes/ItemContentMismatchException");
const CustomSchemaCountLimitExceededException_1 = require("../shapes/CustomSchemaCountLimitExceededException");
const UnsupportedInventorySchemaVersionException_1 = require("../shapes/UnsupportedInventorySchemaVersionException");
const UnsupportedInventoryItemContextException_1 = require("../shapes/UnsupportedInventoryItemContextException");
const InvalidInventoryItemContextException_1 = require("../shapes/InvalidInventoryItemContextException");
const SubTypeCountLimitExceededException_1 = require("../shapes/SubTypeCountLimitExceededException");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.PutInventory = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "PutInventory",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: PutInventoryInput_1.PutInventoryInput
    },
    output: {
        shape: PutInventoryOutput_1.PutInventoryOutput
    },
    errors: [
        {
            shape: InternalServerError_1.InternalServerError
        },
        {
            shape: InvalidInstanceId_1.InvalidInstanceId
        },
        {
            shape: InvalidTypeNameException_1.InvalidTypeNameException
        },
        {
            shape: InvalidItemContentException_1.InvalidItemContentException
        },
        {
            shape: TotalSizeLimitExceededException_1.TotalSizeLimitExceededException
        },
        {
            shape: ItemSizeLimitExceededException_1.ItemSizeLimitExceededException
        },
        {
            shape: ItemContentMismatchException_1.ItemContentMismatchException
        },
        {
            shape: CustomSchemaCountLimitExceededException_1.CustomSchemaCountLimitExceededException
        },
        {
            shape: UnsupportedInventorySchemaVersionException_1.UnsupportedInventorySchemaVersionException
        },
        {
            shape: UnsupportedInventoryItemContextException_1.UnsupportedInventoryItemContextException
        },
        {
            shape: InvalidInventoryItemContextException_1.InvalidInventoryItemContextException
        },
        {
            shape: SubTypeCountLimitExceededException_1.SubTypeCountLimitExceededException
        }
    ]
};
//# sourceMappingURL=PutInventory.js.map