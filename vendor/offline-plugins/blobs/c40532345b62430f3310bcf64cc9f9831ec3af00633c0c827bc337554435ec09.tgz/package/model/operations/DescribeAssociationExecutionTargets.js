"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const DescribeAssociationExecutionTargetsInput_1 = require("../shapes/DescribeAssociationExecutionTargetsInput");
const DescribeAssociationExecutionTargetsOutput_1 = require("../shapes/DescribeAssociationExecutionTargetsOutput");
const InternalServerError_1 = require("../shapes/InternalServerError");
const AssociationDoesNotExist_1 = require("../shapes/AssociationDoesNotExist");
const InvalidNextToken_1 = require("../shapes/InvalidNextToken");
const AssociationExecutionDoesNotExist_1 = require("../shapes/AssociationExecutionDoesNotExist");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.DescribeAssociationExecutionTargets = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "DescribeAssociationExecutionTargets",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: DescribeAssociationExecutionTargetsInput_1.DescribeAssociationExecutionTargetsInput
    },
    output: {
        shape: DescribeAssociationExecutionTargetsOutput_1.DescribeAssociationExecutionTargetsOutput
    },
    errors: [
        {
            shape: InternalServerError_1.InternalServerError
        },
        {
            shape: AssociationDoesNotExist_1.AssociationDoesNotExist
        },
        {
            shape: InvalidNextToken_1.InvalidNextToken
        },
        {
            shape: AssociationExecutionDoesNotExist_1.AssociationExecutionDoesNotExist
        }
    ]
};
//# sourceMappingURL=DescribeAssociationExecutionTargets.js.map