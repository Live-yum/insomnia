"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const DescribeParametersInput_1 = require("../shapes/DescribeParametersInput");
const DescribeParametersOutput_1 = require("../shapes/DescribeParametersOutput");
const InternalServerError_1 = require("../shapes/InternalServerError");
const InvalidFilterKey_1 = require("../shapes/InvalidFilterKey");
const InvalidFilterOption_1 = require("../shapes/InvalidFilterOption");
const InvalidFilterValue_1 = require("../shapes/InvalidFilterValue");
const InvalidNextToken_1 = require("../shapes/InvalidNextToken");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.DescribeParameters = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "DescribeParameters",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: DescribeParametersInput_1.DescribeParametersInput
    },
    output: {
        shape: DescribeParametersOutput_1.DescribeParametersOutput
    },
    errors: [
        {
            shape: InternalServerError_1.InternalServerError
        },
        {
            shape: InvalidFilterKey_1.InvalidFilterKey
        },
        {
            shape: InvalidFilterOption_1.InvalidFilterOption
        },
        {
            shape: InvalidFilterValue_1.InvalidFilterValue
        },
        {
            shape: InvalidNextToken_1.InvalidNextToken
        }
    ]
};
//# sourceMappingURL=DescribeParameters.js.map