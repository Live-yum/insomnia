"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const PutParameterInput_1 = require("../shapes/PutParameterInput");
const PutParameterOutput_1 = require("../shapes/PutParameterOutput");
const InternalServerError_1 = require("../shapes/InternalServerError");
const InvalidKeyId_1 = require("../shapes/InvalidKeyId");
const ParameterLimitExceeded_1 = require("../shapes/ParameterLimitExceeded");
const TooManyUpdates_1 = require("../shapes/TooManyUpdates");
const ParameterAlreadyExists_1 = require("../shapes/ParameterAlreadyExists");
const HierarchyLevelLimitExceededException_1 = require("../shapes/HierarchyLevelLimitExceededException");
const HierarchyTypeMismatchException_1 = require("../shapes/HierarchyTypeMismatchException");
const InvalidAllowedPatternException_1 = require("../shapes/InvalidAllowedPatternException");
const ParameterMaxVersionLimitExceeded_1 = require("../shapes/ParameterMaxVersionLimitExceeded");
const ParameterPatternMismatchException_1 = require("../shapes/ParameterPatternMismatchException");
const UnsupportedParameterType_1 = require("../shapes/UnsupportedParameterType");
const PoliciesLimitExceededException_1 = require("../shapes/PoliciesLimitExceededException");
const InvalidPolicyTypeException_1 = require("../shapes/InvalidPolicyTypeException");
const InvalidPolicyAttributeException_1 = require("../shapes/InvalidPolicyAttributeException");
const IncompatiblePolicyException_1 = require("../shapes/IncompatiblePolicyException");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.PutParameter = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "PutParameter",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: PutParameterInput_1.PutParameterInput
    },
    output: {
        shape: PutParameterOutput_1.PutParameterOutput
    },
    errors: [
        {
            shape: InternalServerError_1.InternalServerError
        },
        {
            shape: InvalidKeyId_1.InvalidKeyId
        },
        {
            shape: ParameterLimitExceeded_1.ParameterLimitExceeded
        },
        {
            shape: TooManyUpdates_1.TooManyUpdates
        },
        {
            shape: ParameterAlreadyExists_1.ParameterAlreadyExists
        },
        {
            shape: HierarchyLevelLimitExceededException_1.HierarchyLevelLimitExceededException
        },
        {
            shape: HierarchyTypeMismatchException_1.HierarchyTypeMismatchException
        },
        {
            shape: InvalidAllowedPatternException_1.InvalidAllowedPatternException
        },
        {
            shape: ParameterMaxVersionLimitExceeded_1.ParameterMaxVersionLimitExceeded
        },
        {
            shape: ParameterPatternMismatchException_1.ParameterPatternMismatchException
        },
        {
            shape: UnsupportedParameterType_1.UnsupportedParameterType
        },
        {
            shape: PoliciesLimitExceededException_1.PoliciesLimitExceededException
        },
        {
            shape: InvalidPolicyTypeException_1.InvalidPolicyTypeException
        },
        {
            shape: InvalidPolicyAttributeException_1.InvalidPolicyAttributeException
        },
        {
            shape: IncompatiblePolicyException_1.IncompatiblePolicyException
        }
    ]
};
//# sourceMappingURL=PutParameter.js.map