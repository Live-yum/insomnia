"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const ListResourceComplianceSummariesInput_1 = require("../shapes/ListResourceComplianceSummariesInput");
const ListResourceComplianceSummariesOutput_1 = require("../shapes/ListResourceComplianceSummariesOutput");
const InvalidFilter_1 = require("../shapes/InvalidFilter");
const InvalidNextToken_1 = require("../shapes/InvalidNextToken");
const InternalServerError_1 = require("../shapes/InternalServerError");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.ListResourceComplianceSummaries = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "ListResourceComplianceSummaries",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: ListResourceComplianceSummariesInput_1.ListResourceComplianceSummariesInput
    },
    output: {
        shape: ListResourceComplianceSummariesOutput_1.ListResourceComplianceSummariesOutput
    },
    errors: [
        {
            shape: InvalidFilter_1.InvalidFilter
        },
        {
            shape: InvalidNextToken_1.InvalidNextToken
        },
        {
            shape: InternalServerError_1.InternalServerError
        }
    ]
};
//# sourceMappingURL=ListResourceComplianceSummaries.js.map