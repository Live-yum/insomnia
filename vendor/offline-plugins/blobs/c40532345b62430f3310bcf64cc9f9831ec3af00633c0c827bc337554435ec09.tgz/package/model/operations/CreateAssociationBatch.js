"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const CreateAssociationBatchInput_1 = require("../shapes/CreateAssociationBatchInput");
const CreateAssociationBatchOutput_1 = require("../shapes/CreateAssociationBatchOutput");
const InternalServerError_1 = require("../shapes/InternalServerError");
const InvalidDocument_1 = require("../shapes/InvalidDocument");
const InvalidDocumentVersion_1 = require("../shapes/InvalidDocumentVersion");
const InvalidInstanceId_1 = require("../shapes/InvalidInstanceId");
const InvalidParameters_1 = require("../shapes/InvalidParameters");
const DuplicateInstanceId_1 = require("../shapes/DuplicateInstanceId");
const AssociationLimitExceeded_1 = require("../shapes/AssociationLimitExceeded");
const UnsupportedPlatformType_1 = require("../shapes/UnsupportedPlatformType");
const InvalidOutputLocation_1 = require("../shapes/InvalidOutputLocation");
const InvalidTarget_1 = require("../shapes/InvalidTarget");
const InvalidSchedule_1 = require("../shapes/InvalidSchedule");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.CreateAssociationBatch = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "CreateAssociationBatch",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: CreateAssociationBatchInput_1.CreateAssociationBatchInput
    },
    output: {
        shape: CreateAssociationBatchOutput_1.CreateAssociationBatchOutput
    },
    errors: [
        {
            shape: InternalServerError_1.InternalServerError
        },
        {
            shape: InvalidDocument_1.InvalidDocument
        },
        {
            shape: InvalidDocumentVersion_1.InvalidDocumentVersion
        },
        {
            shape: InvalidInstanceId_1.InvalidInstanceId
        },
        {
            shape: InvalidParameters_1.InvalidParameters
        },
        {
            shape: DuplicateInstanceId_1.DuplicateInstanceId
        },
        {
            shape: AssociationLimitExceeded_1.AssociationLimitExceeded
        },
        {
            shape: UnsupportedPlatformType_1.UnsupportedPlatformType
        },
        {
            shape: InvalidOutputLocation_1.InvalidOutputLocation
        },
        {
            shape: InvalidTarget_1.InvalidTarget
        },
        {
            shape: InvalidSchedule_1.InvalidSchedule
        }
    ]
};
//# sourceMappingURL=CreateAssociationBatch.js.map