"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const RegisterPatchBaselineForPatchGroupInput_1 = require("../shapes/RegisterPatchBaselineForPatchGroupInput");
const RegisterPatchBaselineForPatchGroupOutput_1 = require("../shapes/RegisterPatchBaselineForPatchGroupOutput");
const AlreadyExistsException_1 = require("../shapes/AlreadyExistsException");
const DoesNotExistException_1 = require("../shapes/DoesNotExistException");
const InvalidResourceId_1 = require("../shapes/InvalidResourceId");
const ResourceLimitExceededException_1 = require("../shapes/ResourceLimitExceededException");
const InternalServerError_1 = require("../shapes/InternalServerError");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.RegisterPatchBaselineForPatchGroup = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "RegisterPatchBaselineForPatchGroup",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: RegisterPatchBaselineForPatchGroupInput_1.RegisterPatchBaselineForPatchGroupInput
    },
    output: {
        shape: RegisterPatchBaselineForPatchGroupOutput_1.RegisterPatchBaselineForPatchGroupOutput
    },
    errors: [
        {
            shape: AlreadyExistsException_1.AlreadyExistsException
        },
        {
            shape: DoesNotExistException_1.DoesNotExistException
        },
        {
            shape: InvalidResourceId_1.InvalidResourceId
        },
        {
            shape: ResourceLimitExceededException_1.ResourceLimitExceededException
        },
        {
            shape: InternalServerError_1.InternalServerError
        }
    ]
};
//# sourceMappingURL=RegisterPatchBaselineForPatchGroup.js.map