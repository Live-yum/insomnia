"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const ListResourceDataSyncInput_1 = require("../shapes/ListResourceDataSyncInput");
const ListResourceDataSyncOutput_1 = require("../shapes/ListResourceDataSyncOutput");
const InternalServerError_1 = require("../shapes/InternalServerError");
const InvalidNextToken_1 = require("../shapes/InvalidNextToken");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.ListResourceDataSync = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "ListResourceDataSync",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: ListResourceDataSyncInput_1.ListResourceDataSyncInput
    },
    output: {
        shape: ListResourceDataSyncOutput_1.ListResourceDataSyncOutput
    },
    errors: [
        {
            shape: InternalServerError_1.InternalServerError
        },
        {
            shape: InvalidNextToken_1.InvalidNextToken
        }
    ]
};
//# sourceMappingURL=ListResourceDataSync.js.map