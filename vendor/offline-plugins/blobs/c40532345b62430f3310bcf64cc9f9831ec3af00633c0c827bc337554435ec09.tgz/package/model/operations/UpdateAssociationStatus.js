"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const UpdateAssociationStatusInput_1 = require("../shapes/UpdateAssociationStatusInput");
const UpdateAssociationStatusOutput_1 = require("../shapes/UpdateAssociationStatusOutput");
const InternalServerError_1 = require("../shapes/InternalServerError");
const InvalidInstanceId_1 = require("../shapes/InvalidInstanceId");
const InvalidDocument_1 = require("../shapes/InvalidDocument");
const AssociationDoesNotExist_1 = require("../shapes/AssociationDoesNotExist");
const StatusUnchanged_1 = require("../shapes/StatusUnchanged");
const TooManyUpdates_1 = require("../shapes/TooManyUpdates");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.UpdateAssociationStatus = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "UpdateAssociationStatus",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: UpdateAssociationStatusInput_1.UpdateAssociationStatusInput
    },
    output: {
        shape: UpdateAssociationStatusOutput_1.UpdateAssociationStatusOutput
    },
    errors: [
        {
            shape: InternalServerError_1.InternalServerError
        },
        {
            shape: InvalidInstanceId_1.InvalidInstanceId
        },
        {
            shape: InvalidDocument_1.InvalidDocument
        },
        {
            shape: AssociationDoesNotExist_1.AssociationDoesNotExist
        },
        {
            shape: StatusUnchanged_1.StatusUnchanged
        },
        {
            shape: TooManyUpdates_1.TooManyUpdates
        }
    ]
};
//# sourceMappingURL=UpdateAssociationStatus.js.map