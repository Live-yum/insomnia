"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const DescribeDocumentInput_1 = require("../shapes/DescribeDocumentInput");
const DescribeDocumentOutput_1 = require("../shapes/DescribeDocumentOutput");
const InternalServerError_1 = require("../shapes/InternalServerError");
const InvalidDocument_1 = require("../shapes/InvalidDocument");
const InvalidDocumentVersion_1 = require("../shapes/InvalidDocumentVersion");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.DescribeDocument = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "DescribeDocument",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: DescribeDocumentInput_1.DescribeDocumentInput
    },
    output: {
        shape: DescribeDocumentOutput_1.DescribeDocumentOutput
    },
    errors: [
        {
            shape: InternalServerError_1.InternalServerError
        },
        {
            shape: InvalidDocument_1.InvalidDocument
        },
        {
            shape: InvalidDocumentVersion_1.InvalidDocumentVersion
        }
    ]
};
//# sourceMappingURL=DescribeDocument.js.map