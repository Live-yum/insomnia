"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const DescribeAssociationExecutionsInput_1 = require("../shapes/DescribeAssociationExecutionsInput");
const DescribeAssociationExecutionsOutput_1 = require("../shapes/DescribeAssociationExecutionsOutput");
const InternalServerError_1 = require("../shapes/InternalServerError");
const AssociationDoesNotExist_1 = require("../shapes/AssociationDoesNotExist");
const InvalidNextToken_1 = require("../shapes/InvalidNextToken");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.DescribeAssociationExecutions = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "DescribeAssociationExecutions",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: DescribeAssociationExecutionsInput_1.DescribeAssociationExecutionsInput
    },
    output: {
        shape: DescribeAssociationExecutionsOutput_1.DescribeAssociationExecutionsOutput
    },
    errors: [
        {
            shape: InternalServerError_1.InternalServerError
        },
        {
            shape: AssociationDoesNotExist_1.AssociationDoesNotExist
        },
        {
            shape: InvalidNextToken_1.InvalidNextToken
        }
    ]
};
//# sourceMappingURL=DescribeAssociationExecutions.js.map