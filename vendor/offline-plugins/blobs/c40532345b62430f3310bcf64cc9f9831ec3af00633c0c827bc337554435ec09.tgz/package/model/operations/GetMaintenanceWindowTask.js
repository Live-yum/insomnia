"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const GetMaintenanceWindowTaskInput_1 = require("../shapes/GetMaintenanceWindowTaskInput");
const GetMaintenanceWindowTaskOutput_1 = require("../shapes/GetMaintenanceWindowTaskOutput");
const DoesNotExistException_1 = require("../shapes/DoesNotExistException");
const InternalServerError_1 = require("../shapes/InternalServerError");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.GetMaintenanceWindowTask = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "GetMaintenanceWindowTask",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: GetMaintenanceWindowTaskInput_1.GetMaintenanceWindowTaskInput
    },
    output: {
        shape: GetMaintenanceWindowTaskOutput_1.GetMaintenanceWindowTaskOutput
    },
    errors: [
        {
            shape: DoesNotExistException_1.DoesNotExistException
        },
        {
            shape: InternalServerError_1.InternalServerError
        }
    ]
};
//# sourceMappingURL=GetMaintenanceWindowTask.js.map