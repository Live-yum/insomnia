"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const GetAutomationExecutionInput_1 = require("../shapes/GetAutomationExecutionInput");
const GetAutomationExecutionOutput_1 = require("../shapes/GetAutomationExecutionOutput");
const AutomationExecutionNotFoundException_1 = require("../shapes/AutomationExecutionNotFoundException");
const InternalServerError_1 = require("../shapes/InternalServerError");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.GetAutomationExecution = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "GetAutomationExecution",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: GetAutomationExecutionInput_1.GetAutomationExecutionInput
    },
    output: {
        shape: GetAutomationExecutionOutput_1.GetAutomationExecutionOutput
    },
    errors: [
        {
            shape: AutomationExecutionNotFoundException_1.AutomationExecutionNotFoundException
        },
        {
            shape: InternalServerError_1.InternalServerError
        }
    ]
};
//# sourceMappingURL=GetAutomationExecution.js.map