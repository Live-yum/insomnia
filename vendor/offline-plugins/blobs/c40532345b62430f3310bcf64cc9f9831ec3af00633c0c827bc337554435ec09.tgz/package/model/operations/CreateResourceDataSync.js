"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const CreateResourceDataSyncInput_1 = require("../shapes/CreateResourceDataSyncInput");
const CreateResourceDataSyncOutput_1 = require("../shapes/CreateResourceDataSyncOutput");
const InternalServerError_1 = require("../shapes/InternalServerError");
const ResourceDataSyncCountExceededException_1 = require("../shapes/ResourceDataSyncCountExceededException");
const ResourceDataSyncAlreadyExistsException_1 = require("../shapes/ResourceDataSyncAlreadyExistsException");
const ResourceDataSyncInvalidConfigurationException_1 = require("../shapes/ResourceDataSyncInvalidConfigurationException");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.CreateResourceDataSync = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "CreateResourceDataSync",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: CreateResourceDataSyncInput_1.CreateResourceDataSyncInput
    },
    output: {
        shape: CreateResourceDataSyncOutput_1.CreateResourceDataSyncOutput
    },
    errors: [
        {
            shape: InternalServerError_1.InternalServerError
        },
        {
            shape: ResourceDataSyncCountExceededException_1.ResourceDataSyncCountExceededException
        },
        {
            shape: ResourceDataSyncAlreadyExistsException_1.ResourceDataSyncAlreadyExistsException
        },
        {
            shape: ResourceDataSyncInvalidConfigurationException_1.ResourceDataSyncInvalidConfigurationException
        }
    ]
};
//# sourceMappingURL=CreateResourceDataSync.js.map