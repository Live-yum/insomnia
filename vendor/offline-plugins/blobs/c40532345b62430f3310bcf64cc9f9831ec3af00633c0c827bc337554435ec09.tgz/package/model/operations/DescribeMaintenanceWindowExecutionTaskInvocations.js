"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const DescribeMaintenanceWindowExecutionTaskInvocationsInput_1 = require("../shapes/DescribeMaintenanceWindowExecutionTaskInvocationsInput");
const DescribeMaintenanceWindowExecutionTaskInvocationsOutput_1 = require("../shapes/DescribeMaintenanceWindowExecutionTaskInvocationsOutput");
const DoesNotExistException_1 = require("../shapes/DoesNotExistException");
const InternalServerError_1 = require("../shapes/InternalServerError");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.DescribeMaintenanceWindowExecutionTaskInvocations = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "DescribeMaintenanceWindowExecutionTaskInvocations",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: DescribeMaintenanceWindowExecutionTaskInvocationsInput_1.DescribeMaintenanceWindowExecutionTaskInvocationsInput
    },
    output: {
        shape: DescribeMaintenanceWindowExecutionTaskInvocationsOutput_1.DescribeMaintenanceWindowExecutionTaskInvocationsOutput
    },
    errors: [
        {
            shape: DoesNotExistException_1.DoesNotExistException
        },
        {
            shape: InternalServerError_1.InternalServerError
        }
    ]
};
//# sourceMappingURL=DescribeMaintenanceWindowExecutionTaskInvocations.js.map