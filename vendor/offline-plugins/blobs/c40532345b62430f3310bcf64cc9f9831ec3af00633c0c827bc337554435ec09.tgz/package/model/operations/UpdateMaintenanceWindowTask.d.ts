import { OperationModel as _Operation_ } from "@aws-sdk/types";
export declare const UpdateMaintenanceWindowTask: _Operation_;
