"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const GetMaintenanceWindowExecutionInput_1 = require("../shapes/GetMaintenanceWindowExecutionInput");
const GetMaintenanceWindowExecutionOutput_1 = require("../shapes/GetMaintenanceWindowExecutionOutput");
const DoesNotExistException_1 = require("../shapes/DoesNotExistException");
const InternalServerError_1 = require("../shapes/InternalServerError");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.GetMaintenanceWindowExecution = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "GetMaintenanceWindowExecution",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: GetMaintenanceWindowExecutionInput_1.GetMaintenanceWindowExecutionInput
    },
    output: {
        shape: GetMaintenanceWindowExecutionOutput_1.GetMaintenanceWindowExecutionOutput
    },
    errors: [
        {
            shape: DoesNotExistException_1.DoesNotExistException
        },
        {
            shape: InternalServerError_1.InternalServerError
        }
    ]
};
//# sourceMappingURL=GetMaintenanceWindowExecution.js.map