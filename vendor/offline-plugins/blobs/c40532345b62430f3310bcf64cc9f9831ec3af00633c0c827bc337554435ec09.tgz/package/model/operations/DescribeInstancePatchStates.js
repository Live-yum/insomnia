"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const DescribeInstancePatchStatesInput_1 = require("../shapes/DescribeInstancePatchStatesInput");
const DescribeInstancePatchStatesOutput_1 = require("../shapes/DescribeInstancePatchStatesOutput");
const InternalServerError_1 = require("../shapes/InternalServerError");
const InvalidNextToken_1 = require("../shapes/InvalidNextToken");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.DescribeInstancePatchStates = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "DescribeInstancePatchStates",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: DescribeInstancePatchStatesInput_1.DescribeInstancePatchStatesInput
    },
    output: {
        shape: DescribeInstancePatchStatesOutput_1.DescribeInstancePatchStatesOutput
    },
    errors: [
        {
            shape: InternalServerError_1.InternalServerError
        },
        {
            shape: InvalidNextToken_1.InvalidNextToken
        }
    ]
};
//# sourceMappingURL=DescribeInstancePatchStates.js.map