"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const GetConnectionStatusInput_1 = require("../shapes/GetConnectionStatusInput");
const GetConnectionStatusOutput_1 = require("../shapes/GetConnectionStatusOutput");
const InternalServerError_1 = require("../shapes/InternalServerError");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.GetConnectionStatus = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "GetConnectionStatus",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: GetConnectionStatusInput_1.GetConnectionStatusInput
    },
    output: {
        shape: GetConnectionStatusOutput_1.GetConnectionStatusOutput
    },
    errors: [
        {
            shape: InternalServerError_1.InternalServerError
        }
    ]
};
//# sourceMappingURL=GetConnectionStatus.js.map