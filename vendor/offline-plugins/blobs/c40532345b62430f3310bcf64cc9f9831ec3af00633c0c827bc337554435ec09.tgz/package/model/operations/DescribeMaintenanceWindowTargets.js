"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const DescribeMaintenanceWindowTargetsInput_1 = require("../shapes/DescribeMaintenanceWindowTargetsInput");
const DescribeMaintenanceWindowTargetsOutput_1 = require("../shapes/DescribeMaintenanceWindowTargetsOutput");
const DoesNotExistException_1 = require("../shapes/DoesNotExistException");
const InternalServerError_1 = require("../shapes/InternalServerError");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.DescribeMaintenanceWindowTargets = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "DescribeMaintenanceWindowTargets",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: DescribeMaintenanceWindowTargetsInput_1.DescribeMaintenanceWindowTargetsInput
    },
    output: {
        shape: DescribeMaintenanceWindowTargetsOutput_1.DescribeMaintenanceWindowTargetsOutput
    },
    errors: [
        {
            shape: DoesNotExistException_1.DoesNotExistException
        },
        {
            shape: InternalServerError_1.InternalServerError
        }
    ]
};
//# sourceMappingURL=DescribeMaintenanceWindowTargets.js.map