"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const CreatePatchBaselineInput_1 = require("../shapes/CreatePatchBaselineInput");
const CreatePatchBaselineOutput_1 = require("../shapes/CreatePatchBaselineOutput");
const IdempotentParameterMismatch_1 = require("../shapes/IdempotentParameterMismatch");
const ResourceLimitExceededException_1 = require("../shapes/ResourceLimitExceededException");
const InternalServerError_1 = require("../shapes/InternalServerError");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.CreatePatchBaseline = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "CreatePatchBaseline",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: CreatePatchBaselineInput_1.CreatePatchBaselineInput
    },
    output: {
        shape: CreatePatchBaselineOutput_1.CreatePatchBaselineOutput
    },
    errors: [
        {
            shape: IdempotentParameterMismatch_1.IdempotentParameterMismatch
        },
        {
            shape: ResourceLimitExceededException_1.ResourceLimitExceededException
        },
        {
            shape: InternalServerError_1.InternalServerError
        }
    ]
};
//# sourceMappingURL=CreatePatchBaseline.js.map