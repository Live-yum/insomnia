"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const DescribePatchGroupStateInput_1 = require("../shapes/DescribePatchGroupStateInput");
const DescribePatchGroupStateOutput_1 = require("../shapes/DescribePatchGroupStateOutput");
const InternalServerError_1 = require("../shapes/InternalServerError");
const InvalidNextToken_1 = require("../shapes/InvalidNextToken");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.DescribePatchGroupState = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "DescribePatchGroupState",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: DescribePatchGroupStateInput_1.DescribePatchGroupStateInput
    },
    output: {
        shape: DescribePatchGroupStateOutput_1.DescribePatchGroupStateOutput
    },
    errors: [
        {
            shape: InternalServerError_1.InternalServerError
        },
        {
            shape: InvalidNextToken_1.InvalidNextToken
        }
    ]
};
//# sourceMappingURL=DescribePatchGroupState.js.map