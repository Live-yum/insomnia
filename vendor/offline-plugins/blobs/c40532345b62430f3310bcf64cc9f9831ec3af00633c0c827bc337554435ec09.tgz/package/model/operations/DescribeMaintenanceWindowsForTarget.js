"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const DescribeMaintenanceWindowsForTargetInput_1 = require("../shapes/DescribeMaintenanceWindowsForTargetInput");
const DescribeMaintenanceWindowsForTargetOutput_1 = require("../shapes/DescribeMaintenanceWindowsForTargetOutput");
const InternalServerError_1 = require("../shapes/InternalServerError");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.DescribeMaintenanceWindowsForTarget = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "DescribeMaintenanceWindowsForTarget",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: DescribeMaintenanceWindowsForTargetInput_1.DescribeMaintenanceWindowsForTargetInput
    },
    output: {
        shape: DescribeMaintenanceWindowsForTargetOutput_1.DescribeMaintenanceWindowsForTargetOutput
    },
    errors: [
        {
            shape: InternalServerError_1.InternalServerError
        }
    ]
};
//# sourceMappingURL=DescribeMaintenanceWindowsForTarget.js.map