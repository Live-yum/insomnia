"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const ListInventoryEntriesInput_1 = require("../shapes/ListInventoryEntriesInput");
const ListInventoryEntriesOutput_1 = require("../shapes/ListInventoryEntriesOutput");
const InternalServerError_1 = require("../shapes/InternalServerError");
const InvalidInstanceId_1 = require("../shapes/InvalidInstanceId");
const InvalidTypeNameException_1 = require("../shapes/InvalidTypeNameException");
const InvalidFilter_1 = require("../shapes/InvalidFilter");
const InvalidNextToken_1 = require("../shapes/InvalidNextToken");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.ListInventoryEntries = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "ListInventoryEntries",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: ListInventoryEntriesInput_1.ListInventoryEntriesInput
    },
    output: {
        shape: ListInventoryEntriesOutput_1.ListInventoryEntriesOutput
    },
    errors: [
        {
            shape: InternalServerError_1.InternalServerError
        },
        {
            shape: InvalidInstanceId_1.InvalidInstanceId
        },
        {
            shape: InvalidTypeNameException_1.InvalidTypeNameException
        },
        {
            shape: InvalidFilter_1.InvalidFilter
        },
        {
            shape: InvalidNextToken_1.InvalidNextToken
        }
    ]
};
//# sourceMappingURL=ListInventoryEntries.js.map