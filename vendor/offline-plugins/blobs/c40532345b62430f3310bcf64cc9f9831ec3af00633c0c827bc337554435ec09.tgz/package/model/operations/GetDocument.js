"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const GetDocumentInput_1 = require("../shapes/GetDocumentInput");
const GetDocumentOutput_1 = require("../shapes/GetDocumentOutput");
const InternalServerError_1 = require("../shapes/InternalServerError");
const InvalidDocument_1 = require("../shapes/InvalidDocument");
const InvalidDocumentVersion_1 = require("../shapes/InvalidDocumentVersion");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.GetDocument = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "GetDocument",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: GetDocumentInput_1.GetDocumentInput
    },
    output: {
        shape: GetDocumentOutput_1.GetDocumentOutput
    },
    errors: [
        {
            shape: InternalServerError_1.InternalServerError
        },
        {
            shape: InvalidDocument_1.InvalidDocument
        },
        {
            shape: InvalidDocumentVersion_1.InvalidDocumentVersion
        }
    ]
};
//# sourceMappingURL=GetDocument.js.map