"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const GetCommandInvocationInput_1 = require("../shapes/GetCommandInvocationInput");
const GetCommandInvocationOutput_1 = require("../shapes/GetCommandInvocationOutput");
const InternalServerError_1 = require("../shapes/InternalServerError");
const InvalidCommandId_1 = require("../shapes/InvalidCommandId");
const InvalidInstanceId_1 = require("../shapes/InvalidInstanceId");
const InvalidPluginName_1 = require("../shapes/InvalidPluginName");
const InvocationDoesNotExist_1 = require("../shapes/InvocationDoesNotExist");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.GetCommandInvocation = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "GetCommandInvocation",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: GetCommandInvocationInput_1.GetCommandInvocationInput
    },
    output: {
        shape: GetCommandInvocationOutput_1.GetCommandInvocationOutput
    },
    errors: [
        {
            shape: InternalServerError_1.InternalServerError
        },
        {
            shape: InvalidCommandId_1.InvalidCommandId
        },
        {
            shape: InvalidInstanceId_1.InvalidInstanceId
        },
        {
            shape: InvalidPluginName_1.InvalidPluginName
        },
        {
            shape: InvocationDoesNotExist_1.InvocationDoesNotExist
        }
    ]
};
//# sourceMappingURL=GetCommandInvocation.js.map