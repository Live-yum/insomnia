"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const DeregisterManagedInstanceInput_1 = require("../shapes/DeregisterManagedInstanceInput");
const DeregisterManagedInstanceOutput_1 = require("../shapes/DeregisterManagedInstanceOutput");
const InvalidInstanceId_1 = require("../shapes/InvalidInstanceId");
const InternalServerError_1 = require("../shapes/InternalServerError");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.DeregisterManagedInstance = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "DeregisterManagedInstance",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: DeregisterManagedInstanceInput_1.DeregisterManagedInstanceInput
    },
    output: {
        shape: DeregisterManagedInstanceOutput_1.DeregisterManagedInstanceOutput
    },
    errors: [
        {
            shape: InvalidInstanceId_1.InvalidInstanceId
        },
        {
            shape: InternalServerError_1.InternalServerError
        }
    ]
};
//# sourceMappingURL=DeregisterManagedInstance.js.map