"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const DeleteParameterInput_1 = require("../shapes/DeleteParameterInput");
const DeleteParameterOutput_1 = require("../shapes/DeleteParameterOutput");
const InternalServerError_1 = require("../shapes/InternalServerError");
const ParameterNotFound_1 = require("../shapes/ParameterNotFound");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.DeleteParameter = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "DeleteParameter",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: DeleteParameterInput_1.DeleteParameterInput
    },
    output: {
        shape: DeleteParameterOutput_1.DeleteParameterOutput
    },
    errors: [
        {
            shape: InternalServerError_1.InternalServerError
        },
        {
            shape: ParameterNotFound_1.ParameterNotFound
        }
    ]
};
//# sourceMappingURL=DeleteParameter.js.map