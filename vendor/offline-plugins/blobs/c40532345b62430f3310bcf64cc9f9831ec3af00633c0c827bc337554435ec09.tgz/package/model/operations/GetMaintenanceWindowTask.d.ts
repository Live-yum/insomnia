import { OperationModel as _Operation_ } from "@aws-sdk/types";
export declare const GetMaintenanceWindowTask: _Operation_;
