"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const DeleteDocumentInput_1 = require("../shapes/DeleteDocumentInput");
const DeleteDocumentOutput_1 = require("../shapes/DeleteDocumentOutput");
const InternalServerError_1 = require("../shapes/InternalServerError");
const InvalidDocument_1 = require("../shapes/InvalidDocument");
const InvalidDocumentOperation_1 = require("../shapes/InvalidDocumentOperation");
const AssociatedInstances_1 = require("../shapes/AssociatedInstances");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.DeleteDocument = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "DeleteDocument",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: DeleteDocumentInput_1.DeleteDocumentInput
    },
    output: {
        shape: DeleteDocumentOutput_1.DeleteDocumentOutput
    },
    errors: [
        {
            shape: InternalServerError_1.InternalServerError
        },
        {
            shape: InvalidDocument_1.InvalidDocument
        },
        {
            shape: InvalidDocumentOperation_1.InvalidDocumentOperation
        },
        {
            shape: AssociatedInstances_1.AssociatedInstances
        }
    ]
};
//# sourceMappingURL=DeleteDocument.js.map