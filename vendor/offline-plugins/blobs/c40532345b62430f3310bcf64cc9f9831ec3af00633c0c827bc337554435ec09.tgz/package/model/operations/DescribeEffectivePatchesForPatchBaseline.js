"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const DescribeEffectivePatchesForPatchBaselineInput_1 = require("../shapes/DescribeEffectivePatchesForPatchBaselineInput");
const DescribeEffectivePatchesForPatchBaselineOutput_1 = require("../shapes/DescribeEffectivePatchesForPatchBaselineOutput");
const InvalidResourceId_1 = require("../shapes/InvalidResourceId");
const DoesNotExistException_1 = require("../shapes/DoesNotExistException");
const UnsupportedOperatingSystem_1 = require("../shapes/UnsupportedOperatingSystem");
const InternalServerError_1 = require("../shapes/InternalServerError");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.DescribeEffectivePatchesForPatchBaseline = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "DescribeEffectivePatchesForPatchBaseline",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: DescribeEffectivePatchesForPatchBaselineInput_1.DescribeEffectivePatchesForPatchBaselineInput
    },
    output: {
        shape: DescribeEffectivePatchesForPatchBaselineOutput_1.DescribeEffectivePatchesForPatchBaselineOutput
    },
    errors: [
        {
            shape: InvalidResourceId_1.InvalidResourceId
        },
        {
            shape: DoesNotExistException_1.DoesNotExistException
        },
        {
            shape: UnsupportedOperatingSystem_1.UnsupportedOperatingSystem
        },
        {
            shape: InternalServerError_1.InternalServerError
        }
    ]
};
//# sourceMappingURL=DescribeEffectivePatchesForPatchBaseline.js.map