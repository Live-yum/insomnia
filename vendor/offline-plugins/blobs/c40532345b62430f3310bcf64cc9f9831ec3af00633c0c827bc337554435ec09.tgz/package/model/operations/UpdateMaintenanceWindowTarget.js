"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const UpdateMaintenanceWindowTargetInput_1 = require("../shapes/UpdateMaintenanceWindowTargetInput");
const UpdateMaintenanceWindowTargetOutput_1 = require("../shapes/UpdateMaintenanceWindowTargetOutput");
const DoesNotExistException_1 = require("../shapes/DoesNotExistException");
const InternalServerError_1 = require("../shapes/InternalServerError");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.UpdateMaintenanceWindowTarget = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "UpdateMaintenanceWindowTarget",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: UpdateMaintenanceWindowTargetInput_1.UpdateMaintenanceWindowTargetInput
    },
    output: {
        shape: UpdateMaintenanceWindowTargetOutput_1.UpdateMaintenanceWindowTargetOutput
    },
    errors: [
        {
            shape: DoesNotExistException_1.DoesNotExistException
        },
        {
            shape: InternalServerError_1.InternalServerError
        }
    ]
};
//# sourceMappingURL=UpdateMaintenanceWindowTarget.js.map