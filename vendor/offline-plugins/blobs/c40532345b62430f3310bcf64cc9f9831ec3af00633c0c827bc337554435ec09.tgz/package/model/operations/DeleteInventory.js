"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const DeleteInventoryInput_1 = require("../shapes/DeleteInventoryInput");
const DeleteInventoryOutput_1 = require("../shapes/DeleteInventoryOutput");
const InternalServerError_1 = require("../shapes/InternalServerError");
const InvalidTypeNameException_1 = require("../shapes/InvalidTypeNameException");
const InvalidOptionException_1 = require("../shapes/InvalidOptionException");
const InvalidDeleteInventoryParametersException_1 = require("../shapes/InvalidDeleteInventoryParametersException");
const InvalidInventoryRequestException_1 = require("../shapes/InvalidInventoryRequestException");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.DeleteInventory = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "DeleteInventory",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: DeleteInventoryInput_1.DeleteInventoryInput
    },
    output: {
        shape: DeleteInventoryOutput_1.DeleteInventoryOutput
    },
    errors: [
        {
            shape: InternalServerError_1.InternalServerError
        },
        {
            shape: InvalidTypeNameException_1.InvalidTypeNameException
        },
        {
            shape: InvalidOptionException_1.InvalidOptionException
        },
        {
            shape: InvalidDeleteInventoryParametersException_1.InvalidDeleteInventoryParametersException
        },
        {
            shape: InvalidInventoryRequestException_1.InvalidInventoryRequestException
        }
    ]
};
//# sourceMappingURL=DeleteInventory.js.map