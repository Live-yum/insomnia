"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const DescribeInstanceInformationInput_1 = require("../shapes/DescribeInstanceInformationInput");
const DescribeInstanceInformationOutput_1 = require("../shapes/DescribeInstanceInformationOutput");
const InternalServerError_1 = require("../shapes/InternalServerError");
const InvalidInstanceId_1 = require("../shapes/InvalidInstanceId");
const InvalidNextToken_1 = require("../shapes/InvalidNextToken");
const InvalidInstanceInformationFilterValue_1 = require("../shapes/InvalidInstanceInformationFilterValue");
const InvalidFilterKey_1 = require("../shapes/InvalidFilterKey");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.DescribeInstanceInformation = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "DescribeInstanceInformation",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: DescribeInstanceInformationInput_1.DescribeInstanceInformationInput
    },
    output: {
        shape: DescribeInstanceInformationOutput_1.DescribeInstanceInformationOutput
    },
    errors: [
        {
            shape: InternalServerError_1.InternalServerError
        },
        {
            shape: InvalidInstanceId_1.InvalidInstanceId
        },
        {
            shape: InvalidNextToken_1.InvalidNextToken
        },
        {
            shape: InvalidInstanceInformationFilterValue_1.InvalidInstanceInformationFilterValue
        },
        {
            shape: InvalidFilterKey_1.InvalidFilterKey
        }
    ]
};
//# sourceMappingURL=DescribeInstanceInformation.js.map