"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const ListCommandsInput_1 = require("../shapes/ListCommandsInput");
const ListCommandsOutput_1 = require("../shapes/ListCommandsOutput");
const InternalServerError_1 = require("../shapes/InternalServerError");
const InvalidCommandId_1 = require("../shapes/InvalidCommandId");
const InvalidInstanceId_1 = require("../shapes/InvalidInstanceId");
const InvalidFilterKey_1 = require("../shapes/InvalidFilterKey");
const InvalidNextToken_1 = require("../shapes/InvalidNextToken");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.ListCommands = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "ListCommands",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: ListCommandsInput_1.ListCommandsInput
    },
    output: {
        shape: ListCommandsOutput_1.ListCommandsOutput
    },
    errors: [
        {
            shape: InternalServerError_1.InternalServerError
        },
        {
            shape: InvalidCommandId_1.InvalidCommandId
        },
        {
            shape: InvalidInstanceId_1.InvalidInstanceId
        },
        {
            shape: InvalidFilterKey_1.InvalidFilterKey
        },
        {
            shape: InvalidNextToken_1.InvalidNextToken
        }
    ]
};
//# sourceMappingURL=ListCommands.js.map