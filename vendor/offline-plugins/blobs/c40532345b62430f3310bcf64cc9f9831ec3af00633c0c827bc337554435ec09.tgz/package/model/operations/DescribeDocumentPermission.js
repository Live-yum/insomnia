"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const DescribeDocumentPermissionInput_1 = require("../shapes/DescribeDocumentPermissionInput");
const DescribeDocumentPermissionOutput_1 = require("../shapes/DescribeDocumentPermissionOutput");
const InternalServerError_1 = require("../shapes/InternalServerError");
const InvalidDocument_1 = require("../shapes/InvalidDocument");
const InvalidPermissionType_1 = require("../shapes/InvalidPermissionType");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.DescribeDocumentPermission = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "DescribeDocumentPermission",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: DescribeDocumentPermissionInput_1.DescribeDocumentPermissionInput
    },
    output: {
        shape: DescribeDocumentPermissionOutput_1.DescribeDocumentPermissionOutput
    },
    errors: [
        {
            shape: InternalServerError_1.InternalServerError
        },
        {
            shape: InvalidDocument_1.InvalidDocument
        },
        {
            shape: InvalidPermissionType_1.InvalidPermissionType
        }
    ]
};
//# sourceMappingURL=DescribeDocumentPermission.js.map