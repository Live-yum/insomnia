"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const UpdateManagedInstanceRoleInput_1 = require("../shapes/UpdateManagedInstanceRoleInput");
const UpdateManagedInstanceRoleOutput_1 = require("../shapes/UpdateManagedInstanceRoleOutput");
const InvalidInstanceId_1 = require("../shapes/InvalidInstanceId");
const InternalServerError_1 = require("../shapes/InternalServerError");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.UpdateManagedInstanceRole = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "UpdateManagedInstanceRole",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: UpdateManagedInstanceRoleInput_1.UpdateManagedInstanceRoleInput
    },
    output: {
        shape: UpdateManagedInstanceRoleOutput_1.UpdateManagedInstanceRoleOutput
    },
    errors: [
        {
            shape: InvalidInstanceId_1.InvalidInstanceId
        },
        {
            shape: InternalServerError_1.InternalServerError
        }
    ]
};
//# sourceMappingURL=UpdateManagedInstanceRole.js.map