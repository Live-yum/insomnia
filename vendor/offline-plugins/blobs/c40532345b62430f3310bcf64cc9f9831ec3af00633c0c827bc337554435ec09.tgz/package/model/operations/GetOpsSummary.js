"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const GetOpsSummaryInput_1 = require("../shapes/GetOpsSummaryInput");
const GetOpsSummaryOutput_1 = require("../shapes/GetOpsSummaryOutput");
const InternalServerError_1 = require("../shapes/InternalServerError");
const InvalidFilter_1 = require("../shapes/InvalidFilter");
const InvalidNextToken_1 = require("../shapes/InvalidNextToken");
const InvalidTypeNameException_1 = require("../shapes/InvalidTypeNameException");
const InvalidAggregatorException_1 = require("../shapes/InvalidAggregatorException");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.GetOpsSummary = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "GetOpsSummary",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: GetOpsSummaryInput_1.GetOpsSummaryInput
    },
    output: {
        shape: GetOpsSummaryOutput_1.GetOpsSummaryOutput
    },
    errors: [
        {
            shape: InternalServerError_1.InternalServerError
        },
        {
            shape: InvalidFilter_1.InvalidFilter
        },
        {
            shape: InvalidNextToken_1.InvalidNextToken
        },
        {
            shape: InvalidTypeNameException_1.InvalidTypeNameException
        },
        {
            shape: InvalidAggregatorException_1.InvalidAggregatorException
        }
    ]
};
//# sourceMappingURL=GetOpsSummary.js.map