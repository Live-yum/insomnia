"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const LabelParameterVersionInput_1 = require("../shapes/LabelParameterVersionInput");
const LabelParameterVersionOutput_1 = require("../shapes/LabelParameterVersionOutput");
const InternalServerError_1 = require("../shapes/InternalServerError");
const TooManyUpdates_1 = require("../shapes/TooManyUpdates");
const ParameterNotFound_1 = require("../shapes/ParameterNotFound");
const ParameterVersionNotFound_1 = require("../shapes/ParameterVersionNotFound");
const ParameterVersionLabelLimitExceeded_1 = require("../shapes/ParameterVersionLabelLimitExceeded");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.LabelParameterVersion = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "LabelParameterVersion",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: LabelParameterVersionInput_1.LabelParameterVersionInput
    },
    output: {
        shape: LabelParameterVersionOutput_1.LabelParameterVersionOutput
    },
    errors: [
        {
            shape: InternalServerError_1.InternalServerError
        },
        {
            shape: TooManyUpdates_1.TooManyUpdates
        },
        {
            shape: ParameterNotFound_1.ParameterNotFound
        },
        {
            shape: ParameterVersionNotFound_1.ParameterVersionNotFound
        },
        {
            shape: ParameterVersionLabelLimitExceeded_1.ParameterVersionLabelLimitExceeded
        }
    ]
};
//# sourceMappingURL=LabelParameterVersion.js.map