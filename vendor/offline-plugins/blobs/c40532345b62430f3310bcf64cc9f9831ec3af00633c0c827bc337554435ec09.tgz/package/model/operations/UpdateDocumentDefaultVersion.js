"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const UpdateDocumentDefaultVersionInput_1 = require("../shapes/UpdateDocumentDefaultVersionInput");
const UpdateDocumentDefaultVersionOutput_1 = require("../shapes/UpdateDocumentDefaultVersionOutput");
const InternalServerError_1 = require("../shapes/InternalServerError");
const InvalidDocument_1 = require("../shapes/InvalidDocument");
const InvalidDocumentVersion_1 = require("../shapes/InvalidDocumentVersion");
const InvalidDocumentSchemaVersion_1 = require("../shapes/InvalidDocumentSchemaVersion");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.UpdateDocumentDefaultVersion = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "UpdateDocumentDefaultVersion",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: UpdateDocumentDefaultVersionInput_1.UpdateDocumentDefaultVersionInput
    },
    output: {
        shape: UpdateDocumentDefaultVersionOutput_1.UpdateDocumentDefaultVersionOutput
    },
    errors: [
        {
            shape: InternalServerError_1.InternalServerError
        },
        {
            shape: InvalidDocument_1.InvalidDocument
        },
        {
            shape: InvalidDocumentVersion_1.InvalidDocumentVersion
        },
        {
            shape: InvalidDocumentSchemaVersion_1.InvalidDocumentSchemaVersion
        }
    ]
};
//# sourceMappingURL=UpdateDocumentDefaultVersion.js.map