"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const ListCommandInvocationsInput_1 = require("../shapes/ListCommandInvocationsInput");
const ListCommandInvocationsOutput_1 = require("../shapes/ListCommandInvocationsOutput");
const InternalServerError_1 = require("../shapes/InternalServerError");
const InvalidCommandId_1 = require("../shapes/InvalidCommandId");
const InvalidInstanceId_1 = require("../shapes/InvalidInstanceId");
const InvalidFilterKey_1 = require("../shapes/InvalidFilterKey");
const InvalidNextToken_1 = require("../shapes/InvalidNextToken");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.ListCommandInvocations = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "ListCommandInvocations",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: ListCommandInvocationsInput_1.ListCommandInvocationsInput
    },
    output: {
        shape: ListCommandInvocationsOutput_1.ListCommandInvocationsOutput
    },
    errors: [
        {
            shape: InternalServerError_1.InternalServerError
        },
        {
            shape: InvalidCommandId_1.InvalidCommandId
        },
        {
            shape: InvalidInstanceId_1.InvalidInstanceId
        },
        {
            shape: InvalidFilterKey_1.InvalidFilterKey
        },
        {
            shape: InvalidNextToken_1.InvalidNextToken
        }
    ]
};
//# sourceMappingURL=ListCommandInvocations.js.map