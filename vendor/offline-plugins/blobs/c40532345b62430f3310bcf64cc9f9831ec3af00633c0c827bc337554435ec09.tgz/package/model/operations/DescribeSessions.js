"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const DescribeSessionsInput_1 = require("../shapes/DescribeSessionsInput");
const DescribeSessionsOutput_1 = require("../shapes/DescribeSessionsOutput");
const InternalServerError_1 = require("../shapes/InternalServerError");
const InvalidFilterKey_1 = require("../shapes/InvalidFilterKey");
const InvalidNextToken_1 = require("../shapes/InvalidNextToken");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.DescribeSessions = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "DescribeSessions",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: DescribeSessionsInput_1.DescribeSessionsInput
    },
    output: {
        shape: DescribeSessionsOutput_1.DescribeSessionsOutput
    },
    errors: [
        {
            shape: InternalServerError_1.InternalServerError
        },
        {
            shape: InvalidFilterKey_1.InvalidFilterKey
        },
        {
            shape: InvalidNextToken_1.InvalidNextToken
        }
    ]
};
//# sourceMappingURL=DescribeSessions.js.map