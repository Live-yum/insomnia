"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const GetMaintenanceWindowInput_1 = require("../shapes/GetMaintenanceWindowInput");
const GetMaintenanceWindowOutput_1 = require("../shapes/GetMaintenanceWindowOutput");
const DoesNotExistException_1 = require("../shapes/DoesNotExistException");
const InternalServerError_1 = require("../shapes/InternalServerError");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.GetMaintenanceWindow = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "GetMaintenanceWindow",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: GetMaintenanceWindowInput_1.GetMaintenanceWindowInput
    },
    output: {
        shape: GetMaintenanceWindowOutput_1.GetMaintenanceWindowOutput
    },
    errors: [
        {
            shape: DoesNotExistException_1.DoesNotExistException
        },
        {
            shape: InternalServerError_1.InternalServerError
        }
    ]
};
//# sourceMappingURL=GetMaintenanceWindow.js.map