"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const GetServiceSettingInput_1 = require("../shapes/GetServiceSettingInput");
const GetServiceSettingOutput_1 = require("../shapes/GetServiceSettingOutput");
const InternalServerError_1 = require("../shapes/InternalServerError");
const ServiceSettingNotFound_1 = require("../shapes/ServiceSettingNotFound");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.GetServiceSetting = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "GetServiceSetting",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: GetServiceSettingInput_1.GetServiceSettingInput
    },
    output: {
        shape: GetServiceSettingOutput_1.GetServiceSettingOutput
    },
    errors: [
        {
            shape: InternalServerError_1.InternalServerError
        },
        {
            shape: ServiceSettingNotFound_1.ServiceSettingNotFound
        }
    ]
};
//# sourceMappingURL=GetServiceSetting.js.map