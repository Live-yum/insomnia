import { OperationModel as _Operation_ } from "@aws-sdk/types";
export declare const DescribeInstanceAssociationsStatus: _Operation_;
