"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const SendCommandInput_1 = require("../shapes/SendCommandInput");
const SendCommandOutput_1 = require("../shapes/SendCommandOutput");
const DuplicateInstanceId_1 = require("../shapes/DuplicateInstanceId");
const InternalServerError_1 = require("../shapes/InternalServerError");
const InvalidInstanceId_1 = require("../shapes/InvalidInstanceId");
const InvalidDocument_1 = require("../shapes/InvalidDocument");
const InvalidDocumentVersion_1 = require("../shapes/InvalidDocumentVersion");
const InvalidOutputFolder_1 = require("../shapes/InvalidOutputFolder");
const InvalidParameters_1 = require("../shapes/InvalidParameters");
const UnsupportedPlatformType_1 = require("../shapes/UnsupportedPlatformType");
const MaxDocumentSizeExceeded_1 = require("../shapes/MaxDocumentSizeExceeded");
const InvalidRole_1 = require("../shapes/InvalidRole");
const InvalidNotificationConfig_1 = require("../shapes/InvalidNotificationConfig");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.SendCommand = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "SendCommand",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: SendCommandInput_1.SendCommandInput
    },
    output: {
        shape: SendCommandOutput_1.SendCommandOutput
    },
    errors: [
        {
            shape: DuplicateInstanceId_1.DuplicateInstanceId
        },
        {
            shape: InternalServerError_1.InternalServerError
        },
        {
            shape: InvalidInstanceId_1.InvalidInstanceId
        },
        {
            shape: InvalidDocument_1.InvalidDocument
        },
        {
            shape: InvalidDocumentVersion_1.InvalidDocumentVersion
        },
        {
            shape: InvalidOutputFolder_1.InvalidOutputFolder
        },
        {
            shape: InvalidParameters_1.InvalidParameters
        },
        {
            shape: UnsupportedPlatformType_1.UnsupportedPlatformType
        },
        {
            shape: MaxDocumentSizeExceeded_1.MaxDocumentSizeExceeded
        },
        {
            shape: InvalidRole_1.InvalidRole
        },
        {
            shape: InvalidNotificationConfig_1.InvalidNotificationConfig
        }
    ]
};
//# sourceMappingURL=SendCommand.js.map