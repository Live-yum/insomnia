"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const CreateAssociationInput_1 = require("../shapes/CreateAssociationInput");
const CreateAssociationOutput_1 = require("../shapes/CreateAssociationOutput");
const AssociationAlreadyExists_1 = require("../shapes/AssociationAlreadyExists");
const AssociationLimitExceeded_1 = require("../shapes/AssociationLimitExceeded");
const InternalServerError_1 = require("../shapes/InternalServerError");
const InvalidDocument_1 = require("../shapes/InvalidDocument");
const InvalidDocumentVersion_1 = require("../shapes/InvalidDocumentVersion");
const InvalidInstanceId_1 = require("../shapes/InvalidInstanceId");
const UnsupportedPlatformType_1 = require("../shapes/UnsupportedPlatformType");
const InvalidOutputLocation_1 = require("../shapes/InvalidOutputLocation");
const InvalidParameters_1 = require("../shapes/InvalidParameters");
const InvalidTarget_1 = require("../shapes/InvalidTarget");
const InvalidSchedule_1 = require("../shapes/InvalidSchedule");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.CreateAssociation = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "CreateAssociation",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: CreateAssociationInput_1.CreateAssociationInput
    },
    output: {
        shape: CreateAssociationOutput_1.CreateAssociationOutput
    },
    errors: [
        {
            shape: AssociationAlreadyExists_1.AssociationAlreadyExists
        },
        {
            shape: AssociationLimitExceeded_1.AssociationLimitExceeded
        },
        {
            shape: InternalServerError_1.InternalServerError
        },
        {
            shape: InvalidDocument_1.InvalidDocument
        },
        {
            shape: InvalidDocumentVersion_1.InvalidDocumentVersion
        },
        {
            shape: InvalidInstanceId_1.InvalidInstanceId
        },
        {
            shape: UnsupportedPlatformType_1.UnsupportedPlatformType
        },
        {
            shape: InvalidOutputLocation_1.InvalidOutputLocation
        },
        {
            shape: InvalidParameters_1.InvalidParameters
        },
        {
            shape: InvalidTarget_1.InvalidTarget
        },
        {
            shape: InvalidSchedule_1.InvalidSchedule
        }
    ]
};
//# sourceMappingURL=CreateAssociation.js.map