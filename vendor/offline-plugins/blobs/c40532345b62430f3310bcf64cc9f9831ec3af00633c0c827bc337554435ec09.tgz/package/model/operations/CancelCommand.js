"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const CancelCommandInput_1 = require("../shapes/CancelCommandInput");
const CancelCommandOutput_1 = require("../shapes/CancelCommandOutput");
const InternalServerError_1 = require("../shapes/InternalServerError");
const InvalidCommandId_1 = require("../shapes/InvalidCommandId");
const InvalidInstanceId_1 = require("../shapes/InvalidInstanceId");
const DuplicateInstanceId_1 = require("../shapes/DuplicateInstanceId");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.CancelCommand = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "CancelCommand",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: CancelCommandInput_1.CancelCommandInput
    },
    output: {
        shape: CancelCommandOutput_1.CancelCommandOutput
    },
    errors: [
        {
            shape: InternalServerError_1.InternalServerError
        },
        {
            shape: InvalidCommandId_1.InvalidCommandId
        },
        {
            shape: InvalidInstanceId_1.InvalidInstanceId
        },
        {
            shape: DuplicateInstanceId_1.DuplicateInstanceId
        }
    ]
};
//# sourceMappingURL=CancelCommand.js.map