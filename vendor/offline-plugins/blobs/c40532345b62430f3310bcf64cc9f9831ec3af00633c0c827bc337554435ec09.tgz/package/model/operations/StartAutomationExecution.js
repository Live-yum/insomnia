"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const StartAutomationExecutionInput_1 = require("../shapes/StartAutomationExecutionInput");
const StartAutomationExecutionOutput_1 = require("../shapes/StartAutomationExecutionOutput");
const AutomationDefinitionNotFoundException_1 = require("../shapes/AutomationDefinitionNotFoundException");
const InvalidAutomationExecutionParametersException_1 = require("../shapes/InvalidAutomationExecutionParametersException");
const AutomationExecutionLimitExceededException_1 = require("../shapes/AutomationExecutionLimitExceededException");
const AutomationDefinitionVersionNotFoundException_1 = require("../shapes/AutomationDefinitionVersionNotFoundException");
const IdempotentParameterMismatch_1 = require("../shapes/IdempotentParameterMismatch");
const InvalidTarget_1 = require("../shapes/InvalidTarget");
const InternalServerError_1 = require("../shapes/InternalServerError");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.StartAutomationExecution = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "StartAutomationExecution",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: StartAutomationExecutionInput_1.StartAutomationExecutionInput
    },
    output: {
        shape: StartAutomationExecutionOutput_1.StartAutomationExecutionOutput
    },
    errors: [
        {
            shape: AutomationDefinitionNotFoundException_1.AutomationDefinitionNotFoundException
        },
        {
            shape: InvalidAutomationExecutionParametersException_1.InvalidAutomationExecutionParametersException
        },
        {
            shape: AutomationExecutionLimitExceededException_1.AutomationExecutionLimitExceededException
        },
        {
            shape: AutomationDefinitionVersionNotFoundException_1.AutomationDefinitionVersionNotFoundException
        },
        {
            shape: IdempotentParameterMismatch_1.IdempotentParameterMismatch
        },
        {
            shape: InvalidTarget_1.InvalidTarget
        },
        {
            shape: InternalServerError_1.InternalServerError
        }
    ]
};
//# sourceMappingURL=StartAutomationExecution.js.map