"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const GetMaintenanceWindowExecutionTaskInput_1 = require("../shapes/GetMaintenanceWindowExecutionTaskInput");
const GetMaintenanceWindowExecutionTaskOutput_1 = require("../shapes/GetMaintenanceWindowExecutionTaskOutput");
const DoesNotExistException_1 = require("../shapes/DoesNotExistException");
const InternalServerError_1 = require("../shapes/InternalServerError");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.GetMaintenanceWindowExecutionTask = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "GetMaintenanceWindowExecutionTask",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: GetMaintenanceWindowExecutionTaskInput_1.GetMaintenanceWindowExecutionTaskInput
    },
    output: {
        shape: GetMaintenanceWindowExecutionTaskOutput_1.GetMaintenanceWindowExecutionTaskOutput
    },
    errors: [
        {
            shape: DoesNotExistException_1.DoesNotExistException
        },
        {
            shape: InternalServerError_1.InternalServerError
        }
    ]
};
//# sourceMappingURL=GetMaintenanceWindowExecutionTask.js.map