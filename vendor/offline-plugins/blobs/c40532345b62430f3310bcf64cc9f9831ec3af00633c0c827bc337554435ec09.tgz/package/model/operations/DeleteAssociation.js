"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const DeleteAssociationInput_1 = require("../shapes/DeleteAssociationInput");
const DeleteAssociationOutput_1 = require("../shapes/DeleteAssociationOutput");
const AssociationDoesNotExist_1 = require("../shapes/AssociationDoesNotExist");
const InternalServerError_1 = require("../shapes/InternalServerError");
const InvalidDocument_1 = require("../shapes/InvalidDocument");
const InvalidInstanceId_1 = require("../shapes/InvalidInstanceId");
const TooManyUpdates_1 = require("../shapes/TooManyUpdates");
const ServiceMetadata_1 = require("../ServiceMetadata");
exports.DeleteAssociation = {
    metadata: ServiceMetadata_1.ServiceMetadata,
    name: "DeleteAssociation",
    http: {
        method: "POST",
        requestUri: "/"
    },
    input: {
        shape: DeleteAssociationInput_1.DeleteAssociationInput
    },
    output: {
        shape: DeleteAssociationOutput_1.DeleteAssociationOutput
    },
    errors: [
        {
            shape: AssociationDoesNotExist_1.AssociationDoesNotExist
        },
        {
            shape: InternalServerError_1.InternalServerError
        },
        {
            shape: InvalidDocument_1.InvalidDocument
        },
        {
            shape: InvalidInstanceId_1.InvalidInstanceId
        },
        {
            shape: TooManyUpdates_1.TooManyUpdates
        }
    ]
};
//# sourceMappingURL=DeleteAssociation.js.map