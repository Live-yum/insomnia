"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const _Activation_1 = require("./_Activation");
exports._ActivationList = {
    type: "list",
    member: {
        shape: _Activation_1._Activation
    }
};
//# sourceMappingURL=_ActivationList.js.map