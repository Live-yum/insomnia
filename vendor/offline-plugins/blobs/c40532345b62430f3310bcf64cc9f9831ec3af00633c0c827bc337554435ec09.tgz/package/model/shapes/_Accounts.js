"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports._Accounts = {
    type: "list",
    min: 1,
    member: {
        shape: {
            type: "string"
        }
    }
};
//# sourceMappingURL=_Accounts.js.map