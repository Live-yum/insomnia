"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports._AccountIdList = {
    type: "list",
    member: {
        shape: {
            type: "string"
        }
    }
};
//# sourceMappingURL=_AccountIdList.js.map