import { List as _List_ } from "@aws-sdk/types";
export declare const _ActivationList: _List_;
