"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const _TagList_1 = require("./_TagList");
exports._Activation = {
    type: "structure",
    required: [],
    members: {
        ActivationId: {
            shape: {
                type: "string"
            }
        },
        Description: {
            shape: {
                type: "string"
            }
        },
        DefaultInstanceName: {
            shape: {
                type: "string"
            }
        },
        IamRole: {
            shape: {
                type: "string"
            }
        },
        RegistrationLimit: {
            shape: {
                type: "integer",
                min: 1
            }
        },
        RegistrationsCount: {
            shape: {
                type: "integer",
                min: 1
            }
        },
        ExpirationDate: {
            shape: {
                type: "timestamp"
            }
        },
        Expired: {
            shape: {
                type: "boolean"
            }
        },
        CreatedDate: {
            shape: {
                type: "timestamp"
            }
        },
        Tags: {
            shape: _TagList_1._TagList
        }
    }
};
//# sourceMappingURL=_Activation.js.map