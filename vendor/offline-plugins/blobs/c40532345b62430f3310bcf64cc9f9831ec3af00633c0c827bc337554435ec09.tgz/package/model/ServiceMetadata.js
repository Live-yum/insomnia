"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ServiceMetadata = {
    apiVersion: "2014-11-06",
    endpointPrefix: "ssm",
    jsonVersion: "1.1",
    protocol: "json",
    serviceAbbreviation: "Amazon SSM",
    serviceFullName: "Amazon Simple Systems Manager (SSM)",
    serviceId: "SSM",
    signatureVersion: "v4",
    targetPrefix: "AmazonSSM",
    uid: "ssm-2014-11-06"
};
exports.clientVersion = "0.1.0-preview.1";
//# sourceMappingURL=ServiceMetadata.js.map