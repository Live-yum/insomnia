"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class AsyncDisposer {
    constructor(dispose) {
        this.dispose = dispose;
    }
}
exports.AsyncDisposer = AsyncDisposer;
//# sourceMappingURL=AsyncDisposer.js.map