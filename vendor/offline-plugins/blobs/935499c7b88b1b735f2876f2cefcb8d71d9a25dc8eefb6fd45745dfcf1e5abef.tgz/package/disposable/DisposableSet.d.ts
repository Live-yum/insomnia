import { IDisposable } from './types';
export declare class DisposableSet implements IDisposable {
    protected readonly disposables: Set<IDisposable>;
    get disposed(): boolean;
    dispose(): void;
    push(disposable: IDisposable): IDisposable;
    pushAll(disposables: IDisposable[]): IDisposable[];
}
