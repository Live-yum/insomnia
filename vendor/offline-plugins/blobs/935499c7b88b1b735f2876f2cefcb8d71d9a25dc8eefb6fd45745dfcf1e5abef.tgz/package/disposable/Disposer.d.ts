import { IDisposable } from './types';
export declare class Disposer implements IDisposable {
    dispose: () => void;
    constructor(dispose: () => void);
}
