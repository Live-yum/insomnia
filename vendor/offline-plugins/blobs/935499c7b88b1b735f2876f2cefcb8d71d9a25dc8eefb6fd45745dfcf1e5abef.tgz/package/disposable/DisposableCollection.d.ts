import { IDisposable } from './types';
export declare class DisposableCollection implements IDisposable {
    protected readonly disposables: IDisposable[];
    get disposed(): boolean;
    dispose(): void;
    push(disposable: IDisposable): IDisposable;
    pushAll(disposables: IDisposable[]): IDisposable[];
}
