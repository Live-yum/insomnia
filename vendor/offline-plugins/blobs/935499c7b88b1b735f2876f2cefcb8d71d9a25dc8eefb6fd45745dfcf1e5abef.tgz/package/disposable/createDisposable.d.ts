import { IDisposable } from './types';
export declare function createDisposable(func: () => void): IDisposable;
