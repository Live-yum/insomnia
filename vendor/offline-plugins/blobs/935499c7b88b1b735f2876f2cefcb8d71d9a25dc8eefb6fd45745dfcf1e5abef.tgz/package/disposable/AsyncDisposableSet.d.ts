import { IAsyncDisposable } from './types';
export declare class AsyncDisposableSet implements IAsyncDisposable {
    protected readonly disposables: Set<IAsyncDisposable>;
    get disposed(): boolean;
    dispose(): Promise<void>;
    push(disposable: IAsyncDisposable): IAsyncDisposable;
    pushAll(disposables: IAsyncDisposable[]): IAsyncDisposable[];
}
