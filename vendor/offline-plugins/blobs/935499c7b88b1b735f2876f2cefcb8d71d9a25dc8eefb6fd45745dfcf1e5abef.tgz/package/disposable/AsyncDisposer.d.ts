import { IAsyncDisposable } from './types';
export declare class AsyncDisposer implements IAsyncDisposable {
    dispose: () => void | Promise<void>;
    constructor(dispose: () => void | Promise<void>);
}
