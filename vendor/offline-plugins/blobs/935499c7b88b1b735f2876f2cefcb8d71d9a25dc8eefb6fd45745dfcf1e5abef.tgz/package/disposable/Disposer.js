"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class Disposer {
    constructor(dispose) {
        this.dispose = dispose;
    }
}
exports.Disposer = Disposer;
//# sourceMappingURL=Disposer.js.map