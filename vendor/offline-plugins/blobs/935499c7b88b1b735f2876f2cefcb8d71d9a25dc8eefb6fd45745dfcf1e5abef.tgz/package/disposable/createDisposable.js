"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function createDisposable(func) {
    return {
        dispose: func,
    };
}
exports.createDisposable = createDisposable;
//# sourceMappingURL=createDisposable.js.map