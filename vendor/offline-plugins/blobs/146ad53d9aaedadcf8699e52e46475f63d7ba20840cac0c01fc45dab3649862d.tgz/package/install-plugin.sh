#!/bin/bash

# Define variables
PLUGIN_NAME="insomnia-plugin-mfa-totp"
PLUGIN_DIR="$HOME/AppData/Roaming/Insomnia/$PLUGIN_NAME"

# Create the plugin directory if it doesn't exist
rm -rf "$PLUGIN_DIR"
mkdir -p "$PLUGIN_DIR"

# Copy package.json and index.js to the plugin directory
cp package.json "$PLUGIN_DIR"
cp index.js "$PLUGIN_DIR"

# Navigate to the plugin directory
cd "$PLUGIN_DIR"

# Install the plugin dependencies
npm install

echo "Plugin $PLUGIN_NAME has been installed successfully."