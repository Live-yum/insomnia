<h1>Swagerize Response</h1>
<p>This plugin takes the response and convert it into a swagger path schema in YAML.</p>

<h2>Instalation:</h2>
<lu>
<li>Go to insomnia preferences</li>
<li>Click on plugins tab</li>
<li>Type <code>insomnia-plugin-swagerize-response</code> and click install plugin</li>

<h2>Usage</h2>
To be able to get swagger schemas you'll need to add a header to your request called <code>swagerize</code> and for value use the custom tag called <code>Swagger Options</code>

<p>From the custom tag you can change the path summary, response description, and add url parameters. To get the YAML with the correct indentation you'll need to change the preview mode to RAW</p>