// For help writing plugins, visit the documentation to get started:
//   https://support.insomnia.rest/article/26-plugins

// TODO: Add plugin code here...
const SWAGGERIZE = 'swagerize';
module.exports.templateTags = [{
    name: 'random',
    displayName: 'Random Integer',
    description: 'Generate random things',
    args: [
        {
            displayName: 'Minimum',
            description: 'Minimum potential value',
            type: 'number',
            defaultValue: 0
        },
        {
            displayName: 'Maximum',
            description: 'Maximum potential value',
            type: 'number',
            defaultValue: 100
        }
    ],
    async run (context, min, max) {
        return Math.round(min + Math.random() * (max - min));
    }
}];

module.exports.templateTags = [{
    name: 'swaggerOptions',
    displayName: 'SwaggerOptions',
    description: 'Config for the swagerize script',
    args: [
        {
            displayName: 'Default Type',
            description: 'Declare a default type for null values',
            type: 'string',
            defaultValue: 'string'
        },
        {
            displayName: 'Summary',
            description: 'Add summary',
            type: 'string',
            defaultValue: '"[Add_summary_here]"'
        }, 
        {
            displayName: 'Endpoint Tag',
            description: 'Add Endpoint tag',
            type: 'string',
            defaultValue: '"[add_tags_here]"'
        },
        {
            displayName: 'Response Description',
            description: 'Add response description',
            type: 'string',
            defaultValue: '"[Add_response_description_here]"'
        },
        {
            displayName: 'Include response examples',
            description: 'Include examples',
            type: 'boolean',
            defaultValue: true
        },
        {
            displayName: 'In url Parameters separated by ","',
            description: 'Especify inUrl parameters separate',
            type: 'string',
            defaultValue: ''
        }
    ],
    async run (context, dType, dSummary, dTag, dResponsDescription, dExamples, dInUrlParameters) {
        let inUrlParams = dInUrlParameters.replace(/\s/g,'').split(",");
        options = {
            type: dType,
            summary: dSummary,
            tag: dTag,
            responseDescription: dResponsDescription,
            examples: dExamples,
            inUrlParams: inUrlParams
        }
        return JSON.stringify(options);
    }
}];

const YAML = require('json-to-pretty-yaml');
module.exports.responseHooks = [
    context => {
        if (context.request.hasHeader(SWAGGERIZE)) {
            options = JSON.parse(context.request.getHeader(SWAGGERIZE));
            context.response.setBody(setBodyResponse(context, options));
        }

    }
]

function setBodyResponse(context, options) {
    let method = context.request.getMethod().toLowerCase();
    let swaggerResponse = {};
    let requestName = context.request.getName();
    let requestBody = context.request.getBody();
    let paramsType = requestBody.mimeType;
    let inUrlParams = options["inUrlParams"];
    let apiResponse = JSON.parse(context.response.getBody().toString());
    let statusCode = context.response.getStatusCode();


    swaggerResponse[method] = getBasicSchema(options["summary"], options["tag"]);

    //adding in url params
    if (inUrlParams.length > 0) {
        swaggerResponse[method]["parameters"] = []
        inUrlParams.forEach(param => {
            swaggerResponse[method]["parameters"].push({
                name: param,
                in: "path",
                description: "[add_description_here]",
                required: true,
                style: "simpele"
            });
        });
    }

    //adding requestbody TODO handle exceptions
    if (paramsType === 'multipart/form-data') {
        let params = requestBody.params
        if (params.length > 0) {
            swaggerResponse[method]["requestBody"] = {required: true, content: { "application/x-www-form-urlencoded": { schema: getUrlEncodedParamsSchema(params) } } };
        }
    } else if (paramsType === 'application/json') { 
        let params = JSON.parse(requestBody.text);
        if (Object.keys(params).length > 0) {
            swaggerResponse[method]["requestBody"] = {required: true, content:{ "application/json": { schema: parseObjecToSwaggerFormat(params) } } };
        }
    } else {
        console.log('unsuported mimeType');
    }

    // adding response to the schema
    swaggerResponse[method]["responses"] = {};
    swaggerResponse[method]["responses"][statusCode] = generateResponseSchema(apiResponse, options["responseDescription"]);

    return YAML.stringify(swaggerResponse);
}


//Util functions

//TODO add the option to refer to schemas using headers
function generateResponseSchema(response, description) {
    let responseProperties = {}

    response = {
        description: description,
        content: {
            "application/json": {
                schema: parseObjecToSwaggerFormat(response)
            }
        }
    }
    response["content"]["application/json"]["schema"]["allOf"] = [{"$ref": "#components/schemas/SuccessResponse"}];


    return response;
}

function parseObjecToSwaggerFormat(object) {
    let swaggerFormattedObject = {};
    
    if (object === null) {
        return swaggerFormattedObject = { type: 'string', example: null }
    }

    switch (typeof(object)) {
        case 'object':
            swaggerFormattedObject["type"] = 'object';
            swaggerFormattedObject["properties"] = {};
            for (let atribute in object) {   
                swaggerFormattedObject["properties"][atribute] = parseObjecToSwaggerFormat(object[atribute]); 
            }
            break;
        case 'array':
            swaggerFormattedObject["type"] = 'array';
            swaggerFormattedObject["items"] = [];
            object.forEach(element =>{
                swaggerFormattedObject.push(parseObjecToSwaggerFormat(element));
            });
            break;
        default:
            let paramType = 'string';

            if (isNumeric(object)) {
                paramType = isFloat(object.toString()) ? 'float' : 'integer';
            } else if (isBoolean(object)) {
                paramType = 'boolean'
            }
            
            swaggerFormattedObject = { type: paramType, example: object }
            break;
    }

    return swaggerFormattedObject;
}

function getBasicSchema(summary, tag) {
    schema =
    {
        "summary": summary,
        "tags": [tag]
    };

    return schema;
}

function getRequiredUrlParameterFromRequestName(requestName) {
    let parameters = [],
        rgex = /{([^}]+)}/g,
        match;

    while (match = rgex.exec(requestName)) {
        parameters.push(match[1]);
    }

    return parameters;
}

function getUrlEncodedParamsSchema(params) {
    let required = [];
    let properties = {};

    params.forEach(param => {
        //todo add support for arrays, files and extended text
        let paramType = 'string';

        if (isNumeric(param.value)) {
            paramType = isFloat(param.value) ? 'float' : 'integer';
        } else if (isBoolean(param.value)) {
            paramType = 'boolean'
        }

        properties[param.name] = {};
        if (param.description !== '') {
            properties[param.name]["description"] = param.description;
        }
        properties[param.name]["type"] = paramType;
        properties[param.name]["example"] = convertValue(param.value, paramType)
        required.push(param.name)
    });

    return  {required:required, type: 'object', properties: properties};
}


//Check types
function isNumeric(str) {
    return !isNaN(str);
}

function isBoolean(str) {
    return (str === 'true' || str === 'false');
}

function isFloat(str) {
    return (str.indexOf('.') !== -1)
}


function convertValue(value, type) {
    switch(type) {
        case 'boolean':
            return (value === 'true');
            break;
        case 'integer':
            return parseInt(value);
            break;
        case 'float':
            return parseFloat(value);
            break;
        default:
            return value;
    }
}
