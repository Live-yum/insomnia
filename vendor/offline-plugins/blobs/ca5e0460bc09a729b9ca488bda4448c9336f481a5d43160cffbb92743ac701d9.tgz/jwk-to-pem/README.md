# Installation
> `npm install --save @types/jwk-to-pem`

# Summary
This package contains type definitions for jwk-to-pem (https://github.com/Brightspace/node-jwk-to-pem#readme).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/jwk-to-pem.
## [index.d.ts](https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/jwk-to-pem/index.d.ts)
````ts
export = jwkToBuffer;

declare function jwkToBuffer(jwk: jwkToBuffer.JWK, opts?: jwkToBuffer.Options): string;

declare namespace jwkToBuffer {
    interface Options {
        private: boolean;
    }

    interface EC {
        kty: "EC";
        crv: string;
        x: string;
        y: string;
    }

    interface ECPrivate {
        kty: "EC";
        crv: string;
        d: string;
        x?: string | undefined;
        y?: string | undefined;
    }

    interface RSA {
        kty: "RSA";
        e: string;
        n: string;
        d?: string | undefined;
        p?: string | undefined;
        q?: string | undefined;
        dp?: string | undefined;
        dq?: string | undefined;
        qi?: string | undefined;
    }

    type JWK = EC | ECPrivate | RSA;
}

````

### Additional Details
 * Last updated: Tue, 07 Nov 2023 03:09:37 GMT
 * Dependencies: none

# Credits
These definitions were written by [Erik Silkensen](https://github.com/esilkensen).
