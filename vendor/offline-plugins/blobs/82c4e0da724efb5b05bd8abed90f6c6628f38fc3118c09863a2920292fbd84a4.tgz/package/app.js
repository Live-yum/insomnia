module.exports.templateTags = [{
    name: 'TimeAddition',
    displayName: 'now_add',
    description: 'Adds a given amount of time to current time and displays in a specific format',
    args: [
        {
            displayName: 'Amount of time',
            description: 'Amount of time to be added to current time (negative values supported)',
            type: 'number',
            defaultValue: 60
        },
        {
            displayName: 'Time unit',
            description: 'Time unit related to the amount of time',
            type: 'enum',
            defaultValue: 'minutes',
            options: [
                {
                    displayName: 'Milliseconds',
                    value: 'milliseconds',
                },
                {
                    displayName: 'Seconds',
                    value: 'seconds',
                },
                {
                    displayName: 'Minutes',
                    value: 'minutes',
                },
                {
                    displayName: 'Hours',
                    value: 'hours',
                },
            ]
        },
        {
            displayName: 'Output format',
            description: 'Type of output you desire',
            type: 'enum',
            defaultValue: 'unix_milli',
            options: [
                {
                    displayName: 'Unix millisecond',
                    value: 'unix_milli',
                },
                {
                    displayName: 'Unix second',
                    value: 'unix_sec',
                },
                {
                    displayName: 'ISO',
                    value: 'iso',
                }
            ]
        }
    ],
    async run(context, amount, unit, output) {
        let amoutTarget = amount;
        switch(unit) {
            case 'seconds':
                amoutTarget = amount * 1000;
                break;
            case 'minutes':
                amoutTarget = amount * 60 * 1000;
                break;
            case 'hours':
                amoutTarget = amount * 60 * 60 * 1000;
                break;
        }

        let date = new Date(new Date().getTime() + (amoutTarget));

        switch(output) {
            case 'unix_milli':
                return date.getTime()
            case 'unix_sec':
                return Math.floor(date.getTime()/1000)
            default:
                return date.toISOString()
        }

    }
}];