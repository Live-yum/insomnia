# Time Addition Plugin

It allows you to add a scpefic amout of time to the current time.

Supported time units:
- milliseconds
- seconds
- minutes
- hours

Supported output format:
- unix milliseconds
- unix seconds
- ISO 8601