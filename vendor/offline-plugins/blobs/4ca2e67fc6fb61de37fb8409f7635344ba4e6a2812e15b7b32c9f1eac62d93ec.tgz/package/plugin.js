module.exports.requestHooks = [
    context => {
        var e = context.request.getEnvironment();
        var u = context.request.getUrl();
        if (u.includes("localhost")){
          var newu = u.replace(/v1\.0\/invoke\/[a-z]*\/method\//, "");
          context.request.setUrl(newu);
        }
    }
  ];