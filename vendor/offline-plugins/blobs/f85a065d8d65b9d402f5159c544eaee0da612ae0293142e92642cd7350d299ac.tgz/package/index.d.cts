interface RawAxiosHeaders {
  [key: string]: axios.AxiosHeaderValue;
}

type MethodsHeaders = Partial<{
  [Key in axios.Method as Lowercase<Key>]: AxiosHeaders;
} & {common: AxiosHeaders}>;

type AxiosHeaderMatcher = (this: AxiosHeaders, value: string, name: string, headers: RawAxiosHeaders) => boolean;

type AxiosHeaderParser = (this: AxiosHeaders, value: axios.AxiosHeaderValue, header: string) => any;

type CommonRequestHeadersList = 'Accept' | 'Content-Length' | 'User-Agent'| 'Content-Encoding' | 'Authorization';

type ContentType = axios.AxiosHeaderValue | 'text/html' | 'text/plain' | 'multipart/form-data' | 'application/json' | 'application/x-www-form-urlencoded' | 'application/octet-stream';

type CommonResponseHeadersList = 'Server' | 'Content-Type' | 'Content-Length' | 'Cache-Control'| 'Content-Encoding';

declare class AxiosHeaders {
  constructor(
      headers?: RawAxiosHeaders | AxiosHeaders | string
  );

  [key: string]: any;

  set(headerName?: string, value?: axios.AxiosHeaderValue, rewrite?: boolean | AxiosHeaderMatcher): AxiosHeaders;
  set(headers?: RawAxiosHeaders | AxiosHeaders | string, rewrite?: boolean): AxiosHeaders;

  get(headerName: string, parser: RegExp): RegExpExecArray | null;
  get(headerName: string, matcher?: true | AxiosHeaderParser): axios.AxiosHeaderValue;

  has(header: string, matcher?: AxiosHeaderMatcher): boolean;

  delete(header: string | string[], matcher?: AxiosHeaderMatcher): boolean;

  clear(matcher?: AxiosHeaderMatcher): boolean;

  normalize(format: boolean): AxiosHeaders;

  concat(...targets: Array<AxiosHeaders | RawAxiosHeaders | string | undefined | null>): AxiosHeaders;

  toJSON(asStrings?: boolean): RawAxiosHeaders;

  static from(thing?: AxiosHeaders | RawAxiosHeaders | string): AxiosHeaders;

  static accessor(header: string | string[]): AxiosHeaders;

  static concat(...targets: Array<AxiosHeaders | RawAxiosHeaders | string | undefined | null>): AxiosHeaders;

  setContentType(value: ContentType, rewrite?: boolean | AxiosHeaderMatcher): AxiosHeaders;
  getContentType(parser?: RegExp): RegExpExecArray | null;
  getContentType(matcher?: AxiosHeaderMatcher): axios.AxiosHeaderValue;
  hasContentType(matcher?: AxiosHeaderMatcher): boolean;

  setContentLength(value: axios.AxiosHeaderValue, rewrite?: boolean | AxiosHeaderMatcher): AxiosHeaders;
  getContentLength(parser?: RegExp): RegExpExecArray | null;
  getContentLength(matcher?: AxiosHeaderMatcher): axios.AxiosHeaderValue;
  hasContentLength(matcher?: AxiosHeaderMatcher): boolean;

  setAccept(value: axios.AxiosHeaderValue, rewrite?: boolean | AxiosHeaderMatcher): AxiosHeaders;
  getAccept(parser?: RegExp): RegExpExecArray | null;
  getAccept(matcher?: AxiosHeaderMatcher): axios.AxiosHeaderValue;
  hasAccept(matcher?: AxiosHeaderMatcher): boolean;

  setUserAgent(value: axios.AxiosHeaderValue, rewrite?: boolean | AxiosHeaderMatcher): AxiosHeaders;
  getUserAgent(parser?: RegExp): RegExpExecArray | null;
  getUserAgent(matcher?: AxiosHeaderMatcher): axios.AxiosHeaderValue;
  hasUserAgent(matcher?: AxiosHeaderMatcher): boolean;

  setContentEncoding(value: axios.AxiosHeaderValue, rewrite?: boolean | AxiosHeaderMatcher): AxiosHeaders;
  getContentEncoding(parser?: RegExp): RegExpExecArray | null;
  getContentEncoding(matcher?: AxiosHeaderMatcher): axios.AxiosHeaderValue;
  hasContentEncoding(matcher?: AxiosHeaderMatcher): boolean;

  setAuthorization(value: axios.AxiosHeaderValue, rewrite?: boolean | AxiosHeaderMatcher): AxiosHeaders;
  getAuthorization(parser?: RegExp): RegExpExecArray | null;
  getAuthorization(matcher?: AxiosHeaderMatcher): axios.AxiosHeaderValue;
  hasAuthorization(matcher?: AxiosHeaderMatcher): boolean;

  [Symbol.iterator](): IterableIterator<[string, axios.AxiosHeaderValue]>;
}

declare class AxiosError<T = unknown, D = any> extends Error {
  constructor(
      message?: string,
      code?: string,
      config?: axios.InternalAxiosRequestConfig<D>,
      request?: any,
      response?: axios.AxiosResponse<T, D>
  );

  config?: axios.InternalAxiosRequestConfig<D>;
  code?: string;
  request?: any;
  response?: axios.AxiosResponse<T, D>;
  isAxiosError: boolean;
  status?: number;
  toJSON: () => object;
  cause?: Error;
  static readonly ERR_FR_TOO_MANY_REDIRECTS = "ERR_FR_TOO_MANY_REDIRECTS";
  static readonly ERR_BAD_OPTION_VALUE = "ERR_BAD_OPTION_VALUE";
  static readonly ERR_BAD_OPTION = "ERR_BAD_OPTION";
  static readonly ERR_NETWORK = "ERR_NETWORK";
  static readonly ERR_DEPRECATED = "ERR_DEPRECATED";
  static readonly ERR_BAD_RESPONSE = "ERR_BAD_RESPONSE";
  static readonly ERR_BAD_REQUEST = "ERR_BAD_REQUEST";
  static readonly ERR_NOT_SUPPORT = "ERR_NOT_SUPPORT";
  static readonly ERR_INVALID_URL = "ERR_INVALID_URL";
  static readonly ERR_CANCELED = "ERR_CANCELED";
  static readonly ECONNABORTED = "ECONNABORTED";
  static readonly ETIMEDOUT = "ETIMEDOUT";
}

declare class CanceledError<T> extends AxiosError<T> {
}

declare class Axios {
  constructor(config?: axios.AxiosRequestConfig);
  defaults: axios.AxiosDefaults;
  interceptors: {
    request: axios.AxiosInterceptorManager<axios.InternalAxiosRequestConfig>;
    response: axios.AxiosInterceptorManager<axios.AxiosResponse>;
  };
  getUri(config?: axios.AxiosRequestConfig): string;
  request<T = any, R = axios.AxiosResponse<T>, D = any>(config: axios.AxiosRequestConfig<D>): Promise<R>;
  get<T = any, R = axios.AxiosResponse<T>, D = any>(url: string, config?: axios.AxiosRequestConfig<D>): Promise<R>;
  delete<T = any, R = axios.AxiosResponse<T>, D = any>(url: string, config?: axios.AxiosRequestConfig<D>): Promise<R>;
  head<T = any, R = axios.AxiosResponse<T>, D = any>(url: string, config?: axios.AxiosRequestConfig<D>): Promise<R>;
  options<T = any, R = axios.AxiosResponse<T>, D = any>(url: string, config?: axios.AxiosRequestConfig<D>): Promise<R>;
  post<T = any, R = axios.AxiosResponse<T>, D = any>(url: string, data?: D, config?: axios.AxiosRequestConfig<D>): Promise<R>;
  put<T = any, R = axios.AxiosResponse<T>, D = any>(url: string, data?: D, config?: axios.AxiosRequestConfig<D>): Promise<R>;
  patch<T = any, R = axios.AxiosResponse<T>, D = any>(url: string, data?: D, config?: axios.AxiosRequestConfig<D>): Promise<R>;
  postForm<T = any, R = axios.AxiosResponse<T>, D = any>(url: string, data?: D, config?: axios.AxiosRequestConfig<D>): Promise<R>;
  putForm<T = any, R = axios.AxiosResponse<T>, D = any>(url: string, data?: D, config?: axios.AxiosRequestConfig<D>): Promise<R>;
  patchForm<T = any, R = axios.AxiosResponse<T>, D = any>(url: string, data?: D, config?: axios.AxiosRequestConfig<D>): Promise<R>;
}

declare enum HttpStatusCode {
  Continue = 100,
  SwitchingProtocols = 101,
  Processing = 102,
  EarlyHints = 103,
  Ok = 200,
  Created = 201,
  Accepted = 202,
  NonAuthoritativeInformation = 203,
  NoContent = 204,
  ResetContent = 205,
  PartialContent = 206,
  MultiStatus = 207,
  AlreadyReported = 208,
  ImUsed = 226,
  MultipleChoices = 300,
  MovedPermanently = 301,
  Found = 302,
  SeeOther = 303,
  NotModified = 304,
  UseProxy = 305,
  Unused = 306,
  TemporaryRedirect = 307,
  PermanentRedirect = 308,
  BadRequest = 400,
  Unauthorized = 401,
  PaymentRequired = 402,
  Forbidden = 403,
  NotFound = 404,
  MethodNotAllowed = 405,
  NotAcceptable = 406,
  ProxyAuthenticationRequired = 407,
  RequestTimeout = 408,
  Conflict = 409,
  Gone = 410,
  LengthRequired = 411,
  PreconditionFailed = 412,
  PayloadTooLarge = 413,
  UriTooLong = 414,
  UnsupportedMediaType = 415,
  RangeNotSatisfiable = 416,
  ExpectationFailed = 417,
  ImATeapot = 418,
  MisdirectedRequest = 421,
  UnprocessableEntity = 422,
  Locked = 423,
  FailedDependency = 424,
  TooEarly = 425,
  UpgradeRequired = 426,
  PreconditionRequired = 428,
  TooManyRequests = 429,
  RequestHeaderFieldsTooLarge = 431,
  UnavailableForLegalReasons = 451,
  InternalServerError = 500,
  NotImplemented = 501,
  BadGateway = 502,
  ServiceUnavailable = 503,
  GatewayTimeout = 504,
  HttpVersionNotSupported = 505,
  VariantAlsoNegotiates = 506,
  InsufficientStorage = 507,
  LoopDetected = 508,
  NotExtended = 510,
  NetworkAuthenticationRequired = 511,
}

type InternalAxiosError<T = unknown, D = any> = AxiosError<T, D>;

declare namespace axios {
  type AxiosError<T = unknown, D = any> = InternalAxiosError<T, D>;

  type RawAxiosRequestHeaders = Partial<RawAxiosHeaders & {
    [Key in CommonRequestHeadersList]: AxiosHeaderValue;
  } & {
    'Content-Type': ContentType
  }>;

  type AxiosRequestHeaders = RawAxiosRequestHeaders & AxiosHeaders;

  type AxiosHeaderValue = AxiosHeaders | string | string[] | number | boolean | null;

  type RawCommonResponseHeaders = {
    [Key in CommonResponseHeadersList]: AxiosHeaderValue;
  } & {
    "set-cookie": string[];
  };

  type RawAxiosResponseHeaders = Partial<RawAxiosHeaders & RawCommonResponseHeaders>;

  type AxiosResponseHeaders = RawAxiosResponseHeaders & AxiosHeaders;

  interface AxiosRequestTransformer {
    (this: InternalAxiosRequestConfig, data: any, headers: AxiosRequestHeaders): any;
  }

  interface AxiosResponseTransformer {
    (this: InternalAxiosRequestConfig, data: any, headers: AxiosResponseHeaders, status?: number): any;
  }

  interface AxiosAdapter {
    (config: InternalAxiosRequestConfig): AxiosPromise;
  }

  interface AxiosBasicCredentials {
    username: string;
    password: string;
  }

  interface AxiosProxyConfig {
    host: string;
    port: number;
    auth?: AxiosBasicCredentials;
    protocol?: string;
  }

  type Method =
    | 'get' | 'GET'
    | 'delete' | 'DELETE'
    | 'head' | 'HEAD'
    | 'options' | 'OPTIONS'
    | 'post' | 'POST'
    | 'put' | 'PUT'
    | 'patch' | 'PATCH'
    | 'purge' | 'PURGE'
    | 'link' | 'LINK'
    | 'unlink' | 'UNLINK';

  type ResponseType =
    | 'arraybuffer'
    | 'blob'
    | 'document'
    | 'json'
    | 'text'
    | 'stream';

  type responseEncoding =
    | 'ascii' | 'ASCII'
    | 'ansi' | 'ANSI'
    | 'binary' | 'BINARY'
    | 'base64' | 'BASE64'
    | 'base64url' | 'BASE64URL'
    | 'hex' | 'HEX'
    | 'latin1' | 'LATIN1'
    | 'ucs-2' | 'UCS-2'
    | 'ucs2' | 'UCS2'
    | 'utf-8' | 'UTF-8'
    | 'utf8' | 'UTF8'
    | 'utf16le' | 'UTF16LE';

  interface TransitionalOptions {
    silentJSONParsing?: boolean;
    forcedJSONParsing?: boolean;
    clarifyTimeoutError?: boolean;
  }

  interface GenericAbortSignal {
    readonly aborted: boolean;
    onabort?: ((...args: any) => any) | null;
    addEventListener?: (...args: any) => any;
    removeEventListener?: (...args: any) => any;
  }

  interface FormDataVisitorHelpers {
    defaultVisitor: SerializerVisitor;
    convertValue: (value: any) => any;
    isVisitable: (value: any) => boolean;
  }

  interface SerializerVisitor {
    (
        this: GenericFormData,
        value: any,
        key: string | number,
        path: null | Array<string | number>,
        helpers: FormDataVisitorHelpers
    ): boolean;
  }

  interface SerializerOptions {
    visitor?: SerializerVisitor;
    dots?: boolean;
    metaTokens?: boolean;
    indexes?: boolean | null;
  }

  // tslint:disable-next-line
  interface FormSerializerOptions extends SerializerOptions {
  }

  interface ParamEncoder {
    (value: any, defaultEncoder: (value: any) => any): any;
  }

  interface CustomParamsSerializer {
    (params: Record<string, any>, options?: ParamsSerializerOptions): string;
  }

  interface ParamsSerializerOptions extends SerializerOptions {
    encode?: ParamEncoder;
    serialize?: CustomParamsSerializer;
  }

  type MaxUploadRate = number;

  type MaxDownloadRate = number;

  type BrowserProgressEvent = any;

  interface AxiosProgressEvent {
    loaded: number;
    total?: number;
    progress?: number;
    bytes: number;
    rate?: number;
    estimated?: number;
    upload?: boolean;
    download?: boolean;
    event?: BrowserProgressEvent;
  }

  type Milliseconds = number;

  type x-www-form-ublob'
    | 'document'Serialih| 'Con, co' | boolea-ublob'
    | 'documen;

axios.config: Inter|   | 'document'Se-ublob'
   ddpe MFamiequire | 6): AxiosHeadProgressEvent {Lookup ddpe MEn= dispatchaddpe Mnumber;
    aufamieqialsddpe MFamieqeconds = numbeLookup ddpe M// ma    helLookup ddpe MEn= dRequestTransformer {
    (tR>;
}

diosErrorConfig2,
?number;
    auenerat?:' | 'GET|umber;
    au;
    r?number;
    aufaultToConfig2,
?:rmer {
    (this: Interna|rmer {
    (this: Internptors.resfaultToConfig2,
?:ormer {
    (this: Interna|ormer {
    (this: Internptors.readers | Ax(rs & AxiosHeaders;

  typtial<{
  [Key )ring, rewrite?:;r: defaultT axios.AxidefaultToConfig2,
ptions): string;
  }

  in |zer;
  }

  type MaxUploadR axios.Axi; defaultToCo?:' ;

  type x; defaultToCo

  iM   code?: strin;: defaultToConfig2,
t?: BrowserProgr

axios?:ormer documen;

axio|ormer documen;

axiptors.redentials;
    protocol?: string;
 tToConfig2,
ecArroConfig2,
;g: defaultToConfig2,
?:    | 'ascii' | 'A|umber;
    auultToConfig2,
e?: strin;: defultToConfig2,
e?: strin;: deffaultToConfig2,
 Ax(p type Millis:{
    loaded: numbe
  invoid;ess: defaultToConfig2,
 Ax(p type Millis:{
    loaded: numbe
  invoid;ess: faultToConfig2,
d?: boolean;
  eDirectKeys,
 > anysyReport interfinterface SntListener?: (ltToConfig2,
d?: boolean;
  maxdRequestsd?: boolean;
  maxdtimated?: nu | [er;

  type M,umber;

  type Btors.reultToConfig2,
> analizerO>, options?: ParamsSeri   | 'asDetaig: 1{ders) => boptions?: Paras?: Pa>any;
  }Ction,ontinue = 100,}
  invoid;ess: oConfig2,
?       path: ener?: (Config2,
 axios.AxideConfig2,
 axios.AxideConfsig2,
 axios.Axidept: s?:    host: string;
|isAxio;faultToConfig2,
lizeSyntactic suultToConfig2,
t?: BrowserProgrors.boolean)?: {
    silentJSONPar;ess: o abor?:{
    readonly aborean | nusecur);

cPExpExecA BrowserProgrenv?:  cancel
rs
    )?ager$1y;
  }

  int[]?: Error;
  sta        vf extends Seri?:ns extends SerializerO    aufamieqialsddpe MFamieqecon  tookup> anyrt: s: RawAxiosHeaalizerO>,ror;
 , cb:urn Padonly ath: en,haddpe MnuLookup ddpe M/elLookup ddpe Meadefamieqialsddpe MFamieq
  invoid
  invoid
 |rmDataVisnyrt: s: RawAxiosHeaalizerO>,ror;
 
  inre enum [addpe MnuLookup ddpe MEn= dielLookup ddpe MEn= deadefamieqialsddpe MFamieq]ielLookup ddpe M>);defaultToConfig2,
 }

  // tsli(osRequestConfig): AxiosPromise;
  }
interface S): AxiosHeaddisable-next-Aor festHeaders = Partial<RaR>;
}

diosError= >;
  code?: string;
  rquestTransforConfig<D>;
  code?: string;
r {
  constructo>;
  code?: string
    porHeaders): any;
  }

  interaramsSerializerOpti  intertors: {
eConfig(t;

typrs & AxiosHeaders;

  suultToC | 'yprs & AxiosHeaders;

  suultTgetyprs & AxiosHeaders;

  suultTrHeayprs & AxiosHeaders;

  suultTpt: nurs & AxiosHeaders;

  suultTpu nurs & AxiosHeaders;

  suultTp| 'pnurs & AxiosHeaders;

  suultTalizerOptirs & AxiosHeaders;

  suultTpurode?:rs & AxiosHeaders;

  suultT type?:rs & AxiosHeaders;

  suultT
  type?:rs & AxiosHeaders;

  suulProxyConfig {
    hotors: {
;
r {
  constructoOmit<>,
      request?: any | 'opers'>
    porHeaders)  intertors: {
ustomParamsSerializepted    hotors: {
;
r {
  constructoOmit<>,
      request?: any | 'opers'>
    porHeadere?:rs & AxiosHeaders;

  ring, rewrite?: boers & Ra  intertors: {
>xiosResponseTransformer {
    (tAxiosRespo
r {
  cor: SeriaxiosRT;ess: oyReport inter;ess: oyRepoTex number;
    auders) => boolean;iosHeaders;

  i|s, status?: number): ;onfig(this.: Config<D>;
  code?: string;
  reqesponse?: axios.Axi}ublob'
    | 're enum TiosError= re enum = any>(url: stri  rquestTransforeSyntaSDOUT =: Serier$1y    code?: strin)izeSyntaustomParamsSerializeedErro{
,
      cod:| null>): AxiosHeadustomParamsSerializeedErrcord<strin    code?: stringsRequestCodata: any, headers: ponse?: axios):nvoid;essmParamsSerializeedErrig2,
SDOUT =: Serier$1ycancel =a
  edErr:zeedErrco
  invoid
izeSyntactic suultTancel;
 izeSyntactic Sncel;;essmParamsSerializeedErrig2,
=: Seri.spreadlare enum eedErr  reqesponalS?izeSyntausto {
    if (this.reas:nvoid;essmParamsSerializeedErrig2,
Sncel;eturn awg2,
  eSyntactic suultT edErr:zeedErrcoxiosResponseTransformer xios.AxiosRJSONParsing?: berceptors)ecA BrowserProgrfalse) ?: osRequestConfig): AxiosPromise;
  }
interface SxiosResponseTransformer xios.AxiosResponse>V>ing;
    p(g);
      }?y): any;
 V
inteV boee enum Veria error);
?:urn Pro
  }

  interrializerOptirmer xios.AxiosRJSONPar)ted?: number;
 yloadid
  interfacvoid;ess: sHeades:nvoid;essmParamsSerializrmer xid
constnstructo>;
  ing;
  AxiosResponse<= any>(config: axios.AxiosRequestCo>): Promise<R>;
  patchForm<T = any, R  AxiosResponse<= any>(config: axios.AxiosR: axios.AxiosRequestCo>): Promise<R>;
  patchForm<T = any, SerializerVs:oOmit<>,
  D  const f| 'opers'>
&  cancel
rHeaders)  intertors: {

&  cancel
;

  set(headerNa} & {
    "set-ctry {
      prenericAbortSignal {
    rea;

// ExspatchapoEar(s: RawAxiosHeancoder: (valalizerOptiterface CustomParamsSerializ
    rew FormDaEdGatew=: Seriesword: string;
  eneratrd: string;
  submites:nvoid;essmParamsSerializrmer SDOUT =nstructo>;
  xid
constConfig() {
  RequestCoepted    hotors: {
):o>;
  xid
consng;
  CedErr:zeedErrSDOUT ng;
  CedErrTg2,
  eSyntactic SDOUT ng;
  >;
  : 'functincelTokEPRECATED
    : 'functincelTonly ERR_ tends AxiosErr: 'functixpose all/spreaR_ tontinue = 100,: 'functi
 * Create an in: boolean;
  mData =rd: string;
  ION = VE: any;
  }

: @returiszeSyntausto {all<T>: any;s | RawAxT boee enum T>tchForm<T = T[]ny, R  sAxiosxiosR>n functioany;
  }

  T[]?: ErR): (blob'  T[]?: ErRng;
  IOwn, D = any> = Respo
r {
  cr === tr
  }

: thrown by A type RawAxiosRequrn awging);

axancel;Obj>,ror;
 , Headerrs
    )?ag     value: any,lalizerOptis extends SerializerO)ag     value: any     vf exLForm(tf exag     value: any|
    rew FormDaEdGatew):rror;
  sta  ttpStatusC(

axios.:ormer documen;

axio|ormer documen;

axipt): AxiosHeadd:ormer documenokEPRECATEDHHeaders)'functincelTrs;

  suulPros {
  constnstance(deConfig<D>): PSDOUT