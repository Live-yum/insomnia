
module.exports.templateTags = [{
    name: 'payload',
    displayName: 'RequestPayload',
    description: 'Get Request Payload',
    args: [
        
    ],
    async run (context) {
        const { meta } = context;

		if (!meta.requestId) {
			return null;
		}

		const request = await context.util.models.request.getById(meta.requestId);
		if (request) {
			if (request.body) {
				if (request.body.text) {
					return request.body.text;
				}
			}
		}
		return null;
    }
}];
