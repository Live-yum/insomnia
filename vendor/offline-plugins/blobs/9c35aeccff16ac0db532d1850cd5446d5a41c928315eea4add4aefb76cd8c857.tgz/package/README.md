# Insomnia Template Tags For Get Request Payload

use RequestPayload to get request body