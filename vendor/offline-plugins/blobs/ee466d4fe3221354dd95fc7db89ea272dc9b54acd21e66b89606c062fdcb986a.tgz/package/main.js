const crypto = require('crypto');

// ============================================================================
// Utility Functions
// ============================================================================

/**
 * Safely minify JSON string, returning original if parsing fails
 * @param {string} jsonString - JSON string to minify
 * @returns {string} Minified JSON or original string
 */
function minifyJSON(jsonString) {
    try {
        return JSON.stringify(JSON.parse(jsonString));
    } catch {
        return jsonString;
    }
}

/**
 * Get a header value, falling back to environment variable if not present
 * @param {Object} request - Request object
 * @param {string} headerName - Header name to retrieve
 * @param {string} envVarName - Environment variable fallback
 * @returns {string|null} Header or environment value
 */
function getHeaderOrEnv(request, headerName, envVarName) {
    let value = request.getHeader(headerName);
    if (!value) {
        value = request.getEnvironment()[envVarName];
        if (value) {
            request.setHeader(headerName, value);
        }
    }
    return value;
}

/**
 * Generate ISO timestamp with +7 hours offset (UTC+7)
 * @returns {string} ISO timestamp string in UTC+7 format (without Z suffix)
 */
function generateTimestamp() {
    const now = new Date();
    const utcPlus7 = new Date(now.getTime() + 7 * 60 * 60 * 1000);
    const isoString = utcPlus7.toISOString();
    // Replace 'Z' with '+07:00' to properly indicate UTC+7 timezone
    return isoString.replace('Z', '+07:00');
}

/**
 * Ensure timestamp header exists, creating if necessary
 * @param {Object} request - Request object
 * @returns {string} Timestamp value
 */
function ensureTimestamp(request) {
    let timestamp = request.getHeader('X-Timestamp');
    if (!timestamp) {
        timestamp = generateTimestamp();
        request.setHeader('X-Timestamp', timestamp);
    }
    return timestamp;
}

/**
 * Format private key by replacing escaped newlines with actual newlines
 * @param {string} privateKey - Private key string
 * @returns {string} Formatted private key
 */
function formatPrivateKey(privateKey) {
    return privateKey.replace(/\\n/g, '\n');
}

// ============================================================================
// Asymmetric Signing (RSA-SHA256)
// ============================================================================

/**
 * Handle Snap Asymmetric signing
 * @param {Object} context - Insomnia request context
 */
function handleSnapAsymmetric(context) {
    const request = context.request;
    const env = request.getEnvironment();

    request.setHeader('Content-Type', 'application/json');

    // Get or set client key
    const clientKey = getHeaderOrEnv(request, 'X-Client-Key', 'client_key');

    // Get or create timestamp
    const timestamp = ensureTimestamp(request);

    // Sign if we have all required fields
    if (clientKey && timestamp) {
        const data = `${clientKey}|${timestamp}`;
        const privateKey = env.private_key;

        if (privateKey) {
            const formattedPrivateKey = formatPrivateKey(privateKey);
            const signature = crypto
                .createSign('RSA-SHA256')
                .update(data)
                .sign({ key: formattedPrivateKey }, 'base64');

            request.setHeader('X-Signature', signature);
        }
    }
}

// ============================================================================
// Symmetric Signing (HMAC-SHA512)
// ============================================================================

/**
 * Extract access token from Authorization header or environment
 * @param {Object} request - Request object
 * @returns {string|null} Access token
 */
function getAccessToken(request) {
    const authHeader = request.getHeader('Authorization');
    if (authHeader) {
        return authHeader.replace('Bearer ', '');
    }
    return request.getEnvironment().access_token;
}

/**
 * Calculate relative URL by removing base URL
 * @param {Object} request - Request object
 * @returns {string} Relative URL
 */
function getRelativeURL(request) {
    const fullUrl = request.getUrl();
    const baseUrl = request.getEnvironment().base_url || '';
    return fullUrl.replace(baseUrl, '');
}

/**
 * Generate body hash from request body
 * @param {string} requestBody - Request body text
 * @returns {string} SHA256 hex hash
 */
function generateBodyHash(requestBody) {
    const minifiedBody = requestBody ? minifyJSON(requestBody) : '';
    return crypto.createHash('sha256').update(minifiedBody).digest('hex');
}

/**
 * Handle Snap Symmetric signing
 * @param {Object} context - Insomnia request context
 */
function handleSnapSymmetric(context) {
    const request = context.request;
    const env = request.getEnvironment();

    request.setHeader('Content-Type', 'application/json');

    const httpMethod = request.getMethod().toUpperCase();
    const relativeURL = getRelativeURL(request);
    const accessToken = getAccessToken(request);
    const requestBody = request.getBody().text || '';
    const timestamp = ensureTimestamp(request);

    // Sign if we have all required fields
    if (accessToken && timestamp) {
        const bodyHash = generateBodyHash(requestBody);
        const stringToSign = `${httpMethod}:${relativeURL}:${accessToken}:${bodyHash}:${timestamp}`;

        console.log('String to Sign:', stringToSign);

        const clientSecret = env.client_secret;
        if (clientSecret) {
            const signature = crypto
                .createHmac('sha512', clientSecret)
                .update(stringToSign)
                .digest('base64');

            request.setHeader('X-Signature', signature);
        }
    }
}

// ============================================================================
// Main Request Hook
// ============================================================================

/**
 * Main request hook that routes to appropriate signing method
 * @param {Object} context - Insomnia request context
 */
function handleRequest(context) {
    const requestName = context.request.getName();

    if (requestName.includes('Snap Asymmetric')) {
        handleSnapAsymmetric(context);
    } else if (requestName.includes('Snap Symmetric')) {
        handleSnapSymmetric(context);
    }
}

module.exports.requestHooks = [handleRequest];