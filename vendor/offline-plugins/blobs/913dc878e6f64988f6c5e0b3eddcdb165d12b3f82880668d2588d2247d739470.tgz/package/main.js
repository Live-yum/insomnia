var moment = require("moment");
//const fetch = require("fetch-min");
//var axios = require("axios");
var qs = require("querystring");

module.exports.requestGroupActions = [
  {
    label: "Send Requests",
    action: async (context, data) => {
      let UserPswd = [
        ["_id", "5efdbcf1fedd4b056f5dee99"],
        ["userid", "33d22b0e-9474-46b3-9da4-b1fb5d273abc"],
      ];

      var len = UserPswd.length;

      let results = [];
      const url = "https://www.bookmarks.dev/api/public/bookmarks/get";
      for (var i = 0; i < len; i++) {
        let starttime = new Date();
        let responseData = await window
          .fetch(`${url}`, {
            method: "GET",
            headers: {
              "Content-Type": "application/x-www-form-urlencoded",
            },
            body: qs.stringify({
              username: UserPswd[i][0],
              password: UserPswd[i][1],
            }),
          })
          .then((res) => {
            let endtime = new Date();
            var secondsDiff = moment(endtime).diff(starttime, "miliseconds");
            const style =
              "padding:5px; color: var(--color-font-success); background: var(--color-success)";
            results.push(
              `<li style="margin: 5px"> ${UserPswd[i][0]}: <span style="${style}")>${res.status}</span><span>${res.type}</span><span>  Time in ms: ${secondsDiff}</span></li>`
            );
            //onResponseEnd();
          })
          .catch((err) => {
            let endtime = new Date();
            var secondsDiff = moment(endtime).diff(starttime, "miliseconds");
            const style =
              "padding:5px; color: var(--color-font-danger); background: var(--color-danger)";
            console.log("error ", err);
            results.push(
              `<li style="margin: 5px">  ${UserPswd[i][0]}: <span style="${style}")>${err.data}</span><span>  Time in ms: ${secondsDiff}</span></li>`
            );
            //onResponseEnd();
          });
      } //end of for

      const html = `<ul style="column-count: ${
        results.length > 10 ? 2 : 1
      };">${results.join("\n")}</ul>`;

      context.app.showGenericModalDialog("Results", { html });
    },
  },
];
