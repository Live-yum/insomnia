export declare const jsonToZod: (obj: any, name?: string, module?: boolean | undefined) => string;
