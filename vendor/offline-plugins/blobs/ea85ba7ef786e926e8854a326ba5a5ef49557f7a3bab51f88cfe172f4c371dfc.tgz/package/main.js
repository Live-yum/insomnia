'use strict';

const DEFAULT_CONFIG = {
  productionHostPatterns: ['prod', 'production', 'live'],
  developmentNamePatterns: ['dev', 'local', 'test', 'sandbox'],
  allowedHosts: [],
  maxDuplicateReports: 50,
  maxUrlReports: 100,
};

const AUTH_QUERY_KEYS = new Set(['access_token', 'api_key', 'apikey', 'key', 'token', 'auth', 'authorization', 'client_secret', 'secret', 'password', 'signature', 'sig']);
const SECRET_PATTERNS = [
  { name: 'OpenAI-style key', pattern: /\bsk-[A-Za-z0-9_-]{20,}\b/g },
  { name: 'GitHub token', pattern: /\b(?:ghp|gho|ghu|ghs|ghr)_[A-Za-z0-9_]{20,}\b/g },
  { name: 'AWS access key', pattern: /\b(?:AKIA|ASIA)[A-Z0-9]{16}\b/g },
  { name: 'Slack token', pattern: /\bxox[baprs]-[A-Za-z0-9-]{10,}\b/g },
  { name: 'Private key block', pattern: /-----BEGIN [A-Z ]*PRIVATE KEY-----[\s\S]*?-----END [A-Z ]*PRIVATE KEY-----/g },
  { name: 'Generic secret assignment', pattern: /\b(?:api[_-]?key|access[_-]?token|secret|client[_-]?secret)\s*[:=]\s*["']?[A-Za-z0-9_\-.]{24,}["']?/gi },
];

function normalizeConfig(input) {
  const cfg = Object.assign({}, DEFAULT_CONFIG, input || {});
  for (const key of ['productionHostPatterns', 'developmentNamePatterns', 'allowedHosts']) {
    cfg[key] = Array.isArray(cfg[key]) ? cfg[key].map(String) : DEFAULT_CONFIG[key].slice();
  }
  return cfg;
}

function safeString(value) {
  if (value == null) return '';
  if (typeof value === 'string') return value;
  try { return JSON.stringify(value); } catch { return String(value); }
}

function parseExport(raw) {
  const text = safeString(raw);
  try { return JSON.parse(text); } catch { return { _raw: text }; }
}

function walk(value, visit, path = '$') {
  if (value == null) return;
  visit(value, path);
  if (Array.isArray(value)) {
    value.forEach((item, i) => walk(item, visit, `${path}[${i}]`));
  } else if (typeof value === 'object') {
    Object.keys(value).forEach(k => walk(value[k], visit, `${path}.${k}`));
  }
}

function isRequestLike(obj) {
  if (!obj || typeof obj !== 'object') return false;
  if (typeof obj.url === 'string' && (typeof obj.method === 'string' || obj._type === 'request')) return true;
  return false;
}

function extractBodyText(body) {
  if (body == null) return '';
  if (typeof body === 'string') return body;
  if (typeof body === 'object') {
    if (typeof body.text === 'string') return body.text;
    if (typeof body.body === 'string') return body.body;
    if (typeof body.value === 'string') return body.value;
  }
  return safeString(body);
}

function isEnvironmentLike(obj) {
  if (!obj || typeof obj !== 'object') return false;
  const t = String(obj._type || obj.type || '').toLowerCase();
  return t.includes('environment') || (obj.data && typeof obj.data === 'object' && typeof obj.name === 'string');
}

function collectResources(parsed) {
  const requests = [];
  const environments = [];
  const named = [];
  walk(parsed, (obj, path) => {
    if (!obj || typeof obj !== 'object' || Array.isArray(obj)) return;
    if (typeof obj.name === 'string') named.push({ obj, path, name: obj.name });
    if (isRequestLike(obj)) requests.push({ obj, path });
    if (isEnvironmentLike(obj)) environments.push({ obj, path });
  });
  return { requests, environments, named };
}



function exportDiagnostics(rawExport, parsed) {
  const { requests, environments, named } = collectResources(parsed);
  const topKeys = parsed && typeof parsed === 'object' && !Array.isArray(parsed) ? Object.keys(parsed).slice(0, 12) : [];
  return {
    bytes: safeString(rawExport).length,
    topKeys,
    requests: requests.length,
    environments: environments.length,
    named: named.length,
  };
}

function currentRequestFromContext(context) {
  const req = context && context.request;
  if (!req) return null;
  const call = name => {
    try { return typeof req[name] === 'function' ? req[name]() : undefined; } catch { return undefined; }
  };
  const name = call('getName') || 'Current request';
  const method = call('getMethod') || 'GET';
  const url = call('getUrl') || '';
  const body = call('getBody') || {};
  if (!url && !method && !name) return null;
  return { _type: 'request', name, method, url, body };
}

function collectRequestLikesFromModels(models) {
  const found = [];
  walk(models, (obj, path) => {
    if (!obj || typeof obj !== 'object' || Array.isArray(obj)) return;
    const maybe = {
      _type: obj._type || obj.type || 'request',
      name: obj.name || obj.title,
      method: obj.method,
      url: obj.url,
      body: obj.body,
    };
    if (isRequestLike(maybe)) found.push({ obj: maybe, path: `models${path.slice(1)}` });
  });
  return found;
}

function buildActionExport(rawExport, context, models) {
  const parsed = parseExport(rawExport);
  const diagnostics = exportDiagnostics(rawExport, parsed);
  const resources = collectResources(parsed);
  const synthetic = [];
  if (!resources.requests.length) {
    const current = currentRequestFromContext(context);
    if (current) synthetic.push(current);
    for (const item of collectRequestLikesFromModels(models || {})) synthetic.push(item.obj);
  }
  if (!synthetic.length) return { raw: rawExport, diagnostics, usedFallback: false };
  let merged = parsed && typeof parsed === 'object' && !Array.isArray(parsed) ? Object.assign({}, parsed) : { originalExport: parsed };
  const existing = Array.isArray(merged.resources) ? merged.resources : [];
  merged.resources = existing.concat(synthetic);
  return { raw: JSON.stringify(merged), diagnostics, usedFallback: true };
}

function parseUrl(rawUrl) {
  try { return new URL(rawUrl); } catch { return null; }
}

function hostAllowed(host, cfg) {
  const h = String(host || '').toLowerCase();
  return cfg.allowedHosts.some(a => h === a.toLowerCase() || h.endsWith('.' + a.toLowerCase()));
}

function isProductionHost(host, cfg) {
  const h = String(host || '').toLowerCase();
  if (!h || hostAllowed(h, cfg)) return false;
  return cfg.productionHostPatterns.some(p => {
    const x = String(p).toLowerCase();
    return x && new RegExp(`(^|[-.])${escapeRegExp(x)}($|[-.])`).test(h);
  });
}

function looksDevelopmentName(name, cfg) {
  const n = String(name || '').toLowerCase();
  return cfg.developmentNamePatterns.some(p => n.includes(String(p).toLowerCase()));
}

function escapeRegExp(value) {
  return String(value).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

function redact(value) {
  const s = safeString(value);
  if (s.length <= 8) return '***';
  return `${s.slice(0, 4)}…${s.slice(-4)}`;
}

function redactText(text) {
  let out = safeString(text);
  for (const rule of SECRET_PATTERNS) {
    rule.pattern.lastIndex = 0;
    out = out.replace(rule.pattern, match => redact(match));
  }
  out = out.replace(/([?&](?:access_token|api_key|apikey|key|token|auth|authorization|client_secret|secret|password|signature|sig)=)[^&#\s]+/gi, (_, p) => `${p}${redact('redacted-value')}`);
  return out;
}

function remediationFor(type) {
  return {
    secret: 'Move secrets into private environment values or a vault; never store them in request URLs or exported docs.',
    'query-auth': 'Move auth material from query string to Authorization headers or private environment variables.',
    'prod-mutation': 'Add a safer non-production environment, or rename/duplicate this request for explicit production use.',
    'env-name-mismatch': 'Check the selected environment and base URL; dev/test requests should not target production hosts.',
    'duplicate-name': 'Rename duplicates so search and team handoff are unambiguous.',
    'duplicate-route': 'Merge duplicate requests or make their purpose explicit in names/descriptions.',
    'invalid-url': 'Fix malformed URL or replace host/path with a valid environment variable expression.',
    'missing-url': 'Add a URL or archive placeholder requests.',
    'empty-body': 'Add a request body, or document why the mutation intentionally has no body.',
    'unresolved-template': 'Resolve the template tag before sharing or sending the request; verify the referenced environment variable exists and is selected.',
    'empty-name': 'Add a descriptive request, folder, or environment name so reports, search results, and handoffs identify the item clearly.',
    'environment-missing-base-url': 'Add base_url/api_url/host so environment intent is visible.',
    'missing-description': 'Add a description before using risky destructive requests.',
    'many-hosts': 'Group hosts into environments or split unrelated APIs into separate workspaces.',
    'export-scope-empty': 'Insomnia did not expose the full workspace from this menu action. This report used current-request fallback data, so route/name duplicate checks may require a workspace-level export context.',
  }[type] || 'Review and clean this workspace item.';
}

function add(findings, severity, type, location, message, preview) {
  findings.push({ severity, type, location, message, preview: redactText(preview || ''), remediation: remediationFor(type) });
}

function findSecrets(text, location, findings) {
  const input = safeString(text);
  for (const rule of SECRET_PATTERNS) {
    rule.pattern.lastIndex = 0;
    let m;
    while ((m = rule.pattern.exec(input)) !== null) {
      const nextIndex = rule.pattern.lastIndex;
      add(findings, 'high', 'secret', location, `${rule.name} appears in workspace export`, m[0]);
      rule.pattern.lastIndex = nextIndex;
      if (m.index === rule.pattern.lastIndex) rule.pattern.lastIndex += 1;
    }
  }
}

function findUnresolvedTemplates(text, location, findings) {
  const input = safeString(text);
  const re = /{{\s*[^}]+\s*}}/g;
  let m;
  while ((m = re.exec(input)) !== null) {
    add(findings, 'medium', 'unresolved-template', location, 'Unresolved template tag may be sent literally', m[0]);
    if (m.index === re.lastIndex) re.lastIndex += 1;
  }
}

function lintWorkspace(rawExport, config) {
  const cfg = normalizeConfig(config);
  const parsed = parseExport(rawExport);
  const { requests, environments, named } = collectResources(parsed);
  const findings = [];
  if (config && config.diagnostics && config.diagnostics.requests === 0) {
    add(findings, 'low', 'export-scope-empty', 'context.data.export.insomnia', 'Insomnia did not expose request resources from this menu action; current-request fallback was used', `exportBytes=${config.diagnostics.bytes}; parsedKeys=${config.diagnostics.topKeys.join(',') || 'none'}; fallback=current-request`);
  }
  const nameCounts = new Map();
  const methodPathCounts = new Map();
  const baseHosts = new Map();

  findSecrets(rawExport, 'workspace-export', findings);

  for (const item of named) {
    const clean = item.name.trim().toLowerCase();
    if (!clean) add(findings, 'low', 'empty-name', item.path, 'Empty request/folder/environment name', item.name);
    if (clean) nameCounts.set(clean, (nameCounts.get(clean) || 0) + 1);
  }

  for (const { obj, path } of requests) {
    const name = safeString(obj.name || '(unnamed request)');
    const method = safeString(obj.method || 'GET').toUpperCase();
    const rawUrl = safeString(obj.url || '');
    const urlObj = parseUrl(rawUrl);
    if (!rawUrl) add(findings, 'medium', 'missing-url', path, 'Request has no URL', name);
    findUnresolvedTemplates(rawUrl, `${path}.url`, findings);
    if (rawUrl && !urlObj) add(findings, 'medium', 'invalid-url', path, 'Request URL is not parseable', `${name}: ${rawUrl}`);
    if (urlObj) {
      const route = `${method} ${urlObj.hostname}${urlObj.pathname}`.toLowerCase();
      methodPathCounts.set(route, (methodPathCounts.get(route) || 0) + 1);
      baseHosts.set(urlObj.hostname, (baseHosts.get(urlObj.hostname) || 0) + 1);
      for (const [key, value] of urlObj.searchParams.entries()) {
        if (AUTH_QUERY_KEYS.has(key.toLowerCase())) add(findings, 'high', 'query-auth', `${path}.url`, 'Auth-like value in query string', `${key}=${value}`);
      }
      if (isProductionHost(urlObj.hostname, cfg) && ['DELETE', 'PATCH', 'PUT'].includes(method)) {
        add(findings, 'high', 'prod-mutation', path, 'Destructive method targets production-like host', `${method} ${urlObj.hostname}${urlObj.pathname}`);
      }
      if (looksDevelopmentName(name, cfg) && isProductionHost(urlObj.hostname, cfg)) {
        add(findings, 'medium', 'env-name-mismatch', path, 'Development-looking request name points at production-like host', `${name}: ${rawUrl}`);
      }
    }
    const body = extractBodyText(obj.body);
    findUnresolvedTemplates(body, `${path}.body`, findings);
    if (['POST', 'PUT', 'PATCH'].includes(method) && !body.trim()) add(findings, 'low', 'empty-body', path, `${method} request has empty body`, name);
    if (!safeString(obj.description || obj.metaSortKey || '').trim() && /^delete|remove|purge|destroy/i.test(name)) {
      add(findings, 'low', 'missing-description', path, 'Risky-sounding request has no description', name);
    }
  }

  for (const { obj, path } of environments) {
    const name = safeString(obj.name || 'environment');
    const text = safeString(obj.data || obj);
    findSecrets(text, `${path}.environment`, findings);
    findUnresolvedTemplates(text, `${path}.environment`, findings);
    const keys = Object.keys(obj.data || {}).map(k => k.toLowerCase());
    const urlKeys = keys.filter(k => k.includes('url') || k.includes('host') || k.includes('base'));
    if (!urlKeys.length) add(findings, 'low', 'environment-missing-base-url', path, 'Environment has no obvious base URL/host key', name);
  }

  for (const [name, count] of nameCounts) {
    if (count > 1) add(findings, 'low', 'duplicate-name', 'workspace.name', 'Duplicate request/folder/environment name', `${name} (${count})`);
  }
  for (const [route, count] of methodPathCounts) {
    if (count > 1) add(findings, 'medium', 'duplicate-route', 'workspace.requests', 'Duplicate method+host+path route', `${route} (${count})`);
  }
  if (baseHosts.size > 8) add(findings, 'low', 'many-hosts', 'workspace.urls', 'Workspace uses many distinct hosts; consider grouping or environment variables', `${baseHosts.size} hosts`);

  return findings.slice(0, 500);
}

function summarize(findings) {
  return findings.reduce((acc, f) => { acc[f.severity] = (acc[f.severity] || 0) + 1; return acc; }, { high: 0, medium: 0, low: 0 });
}

function qualityScore(findings) {
  const counts = summarize(findings);
  return Math.max(0, 100 - counts.high * 25 - counts.medium * 10 - counts.low * 3);
}

function fixPriority(findings, limit = 7) {
  const severityRank = { high: 0, medium: 1, low: 2 };
  const typeRank = {
    'query-auth': 0,
    secret: 1,
    'prod-mutation': 2,
    'env-name-mismatch': 3,
    'invalid-url': 4,
    'missing-url': 5,
    'unresolved-template': 6,
    'empty-name': 7,
    'duplicate-route': 8,
    'empty-body': 9,
    'missing-description': 9,
    'environment-missing-base-url': 10,
    'many-hosts': 11,
    'duplicate-name': 12,
    'export-scope-empty': 99,
  };
  const seen = new Set();
  return findings
    .filter(f => f && f.type !== 'export-scope-empty')
    .slice()
    .sort((a, b) =>
      (severityRank[a.severity] ?? 9) - (severityRank[b.severity] ?? 9) ||
      (typeRank[a.type] ?? 50) - (typeRank[b.type] ?? 50) ||
      String(a.location || '').localeCompare(String(b.location || ''))
    )
    .filter(f => {
      const key = `${f.severity}:${f.type}:${f.remediation || remediationFor(f.type)}`;
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    })
    .slice(0, limit);
}

function makeFixPriorityMarkdown(findings) {
  const priority = fixPriority(findings);
  if (!priority.length) return 'No priority fixes. Workspace looks clean.';
  return priority.map((f, i) => `${i + 1}. [${f.severity}] ${f.remediation || remediationFor(f.type)}\n   - Finding: ${f.type} at ${f.location}\n   - Preview: ${String(f.preview || '').replace(/\n/g, ' ')}`).join('\n');
}

function markdownCell(value) {
  return String(value == null ? '' : value)
    .replace(/\\/g, '\\\\')
    .replace(/\|/g, '\\|')
    .replace(/\r?\n/g, '<br>')
    .replace(/\r/g, '<br>')
    .trim();
}

function makeMarkdown(findings) {
  const counts = summarize(findings);
  const score = qualityScore(findings);
  const priority = makeFixPriorityMarkdown(findings);
  const rows = findings.map(f => `| ${[
    f.severity,
    f.type,
    f.location,
    f.message,
    f.preview,
    f.remediation || remediationFor(f.type),
  ].map(markdownCell).join(' | ')} |`).join('\n');
  return `# Insomnia Collection Linter Report\n\nGenerated: ${new Date().toISOString()}\n\nLocal-only report. Secrets are redacted.\n\n## Summary\n\n- Quality score: ${score}/100\n- High: ${counts.high}\n- Medium: ${counts.medium}\n- Low: ${counts.low}\n\n## Fix Priority\n\n${priority}\n\n## Findings\n\n| Severity | Type | Location | Message | Preview | Fix |\n|---|---|---|---|---|---|\n${rows || '| low | none | workspace | No collection hygiene issues detected. |  | No action needed. |'}\n`;
}

function saveDialogPath(result) {
  if (!result) return null;
  if (typeof result === 'string') return result;
  if (typeof result === 'object') {
    if (result.canceled) return null;
    if (typeof result.filePath === 'string' && result.filePath) return result.filePath;
  }
  return null;
}

async function getWritableExportPath(context, fileName) {
  const path = require('path');
  const candidates = [];
  if (context.app && typeof context.app.getPath === 'function') {
    for (const key of ['documents', 'desktop', 'downloads', 'userData', 'home']) {
      try {
        const value = await context.app.getPath(key);
        if (value) candidates.push(value);
      } catch {}
    }
  }
  candidates.push(process.env.HOME || process.env.USERPROFILE || process.cwd());
  return path.join(candidates.find(Boolean) || '.', fileName);
}

const action = {
  label: 'Collection Linter: Export Report',
  icon: 'fa-list-check',
  action: async (context, models) => {
    const raw = await context.data.export.insomnia({ includePrivate: false, format: 'json' });
    const built = buildActionExport(raw, context, models);
    const findings = lintWorkspace(built.raw, { diagnostics: built.diagnostics });
    const report = makeMarkdown(findings);
    const fs = require('fs');
    let output = null;
    if (context.app && typeof context.app.showSaveDialog === 'function') {
      output = saveDialogPath(await context.app.showSaveDialog({ defaultPath: 'insomnia-collection-lint.md' }));
    }
    if (!output) output = await getWritableExportPath(context, 'insomnia-collection-lint.md');
    fs.writeFileSync(output, report, 'utf8');
    if (context.app && typeof context.app.alert === 'function') await context.app.alert('Collection Linter report exported', output);
  }
};

module.exports.workspaceActions = [action];
module.exports.requestGroupActions = [action];
module.exports.requestActions = [action];

module.exports.__test = {
  AUTH_QUERY_KEYS,
  DEFAULT_CONFIG,
  SECRET_PATTERNS,
  buildActionExport,
  collectResources,
  collectRequestLikesFromModels,
  currentRequestFromContext,
  exportDiagnostics,
  findUnresolvedTemplates,
  fixPriority,
  getWritableExportPath,
  isProductionHost,
  lintWorkspace,
  makeMarkdown,
  markdownCell,
  qualityScore,
  remediationFor,
  normalizeConfig,
  parseExport,
  redactText,
  saveDialogPath,
  summarize,
};
