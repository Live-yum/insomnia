import { NativeAuthCacheInterface } from "../native.auth.cache.interface";
export declare class NativeAuthServerConfig {
    apiUrl: string;
    acceptedHosts: string[];
    maxExpirySeconds: number;
    cache?: NativeAuthCacheInterface;
}
