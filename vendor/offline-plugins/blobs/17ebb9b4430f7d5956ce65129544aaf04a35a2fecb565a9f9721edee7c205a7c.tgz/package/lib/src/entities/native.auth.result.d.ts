export declare class NativeAuthResult {
    constructor(result?: Partial<NativeAuthResult>);
    issued: number;
    expires: number;
    address: string;
    host: string;
    extraInfo?: any;
}
