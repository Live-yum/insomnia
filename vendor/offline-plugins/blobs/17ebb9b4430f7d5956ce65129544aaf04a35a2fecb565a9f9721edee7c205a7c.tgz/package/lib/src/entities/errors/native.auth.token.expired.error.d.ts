export declare class NativeAuthTokenExpiredError extends Error {
    constructor();
}
