export declare class NativeAuthHostNotAcceptedError extends Error {
    constructor();
}
