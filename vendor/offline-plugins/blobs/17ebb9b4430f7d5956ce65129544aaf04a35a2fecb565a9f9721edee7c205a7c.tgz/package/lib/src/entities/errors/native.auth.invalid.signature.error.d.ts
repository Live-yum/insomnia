export declare class NativeAuthInvalidSignatureError extends Error {
    constructor();
}
