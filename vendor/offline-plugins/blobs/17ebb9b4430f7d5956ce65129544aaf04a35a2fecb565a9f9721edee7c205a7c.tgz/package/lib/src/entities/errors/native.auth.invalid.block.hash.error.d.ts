export declare class NativeAuthInvalidBlockHashError extends Error {
    constructor();
}
