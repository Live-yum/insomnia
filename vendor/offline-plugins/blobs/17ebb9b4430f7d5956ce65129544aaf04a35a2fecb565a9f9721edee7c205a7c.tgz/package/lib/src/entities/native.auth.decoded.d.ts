export declare class NativeAuthDecoded {
    constructor(result?: Partial<NativeAuthDecoded>);
    ttl: number;
    address: string;
    host: string;
    extraInfo?: any;
    signature: string;
    blockHash: string;
    body: string;
}
