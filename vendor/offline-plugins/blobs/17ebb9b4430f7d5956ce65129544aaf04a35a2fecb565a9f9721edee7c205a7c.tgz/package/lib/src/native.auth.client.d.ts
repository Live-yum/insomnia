import { NativeAuthClientConfig } from "./entities/native.auth.client.config";
export declare class NativeAuthClient {
    private readonly config;
    constructor(config?: Partial<NativeAuthClientConfig>);
    getToken(address: string, token: string, signature: string): string;
    initialize(extraInfo?: any): Promise<string>;
    private getCurrentBlockHash;
    private getCurrentBlockHashWithGateway;
    private getCurrentRound;
    private getCurrentBlockHashWithApi;
    private encodeValue;
    private escape;
}
