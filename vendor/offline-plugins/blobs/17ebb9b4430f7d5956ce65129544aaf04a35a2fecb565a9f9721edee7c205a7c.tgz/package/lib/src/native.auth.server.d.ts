import { NativeAuthServerConfig } from "./entities/native.auth.server.config";
import { NativeAuthResult as NativeAuthValidateResult } from "./entities/native.auth.validate.result";
import { NativeAuthDecoded } from "./entities/native.auth.decoded";
export declare class NativeAuthServer {
    config: NativeAuthServerConfig;
    constructor(config?: Partial<NativeAuthServerConfig>);
    decode(accessToken: string): NativeAuthDecoded;
    validate(accessToken: string): Promise<NativeAuthValidateResult>;
    private getCurrentBlockTimestamp;
    private getBlockTimestamp;
    private decodeValue;
}
