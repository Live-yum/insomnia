import { ISignature } from "@elrondnetwork/erdjs/out";
export declare class NativeAuthSignature implements ISignature {
    private readonly signature;
    constructor(signature: string);
    hex(): string;
}
