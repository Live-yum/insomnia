import { ICrypto } from "./ICrypto.js";
import { ITokenBindingKeyManager } from "./ITokenBindingKeyManager.js";
/**
 * RFC 9449 DPoP proof JWT payload claims.
 * Not exported from any public package entry point.
 * @internal
 */
export type DpopProofClaims = {
    jti: string;
    htm: string;
    htu: string;
    iat: number;
    nonce?: string;
    ath?: string;
};
/**
 * Parameters for building a token-endpoint DPoP proof.
 * @internal
 */
export type DpopTokenProofParams = {
    tokenEndpoint: string;
    nonce?: string;
};
/**
 * Parameters for building a resource-endpoint DPoP proof.
 * @internal
 */
export type DpopResourceProofParams = {
    htu: string;
    htm: string;
    ath: string;
    nonce?: string;
};
export type GenerateDpopResourceProofParams = {
    htu?: string;
    htm?: string;
    nonce?: string;
    accessToken: string;
};
/**
 * Builds RFC 9449 DPoP proof JWT payloads for token-endpoint and
 * resource-endpoint proof bindings.
 *
 * Not exported from any public package entry point.
 * This helper is internal-only until DPoP is wired into acquisition flows
 * in a subsequent work item.
 *
 * DPoP proofs do not contain SHR fields (at, ts, m, u, p, q).
 * @internal
 */
export declare class DpopProofGenerator {
    private cryptoUtils;
    private tokenBindingKeyManager;
    constructor(cryptoUtils: ICrypto, tokenBindingKeyManager: ITokenBindingKeyManager);
    /**
     * Provisions a fresh DPoP key and returns the RFC 7638 JWK thumbprint used
     * as `dpop_jkt`.
     */
    generateJkt(correlationId?: string): Promise<string>;
    /**
     * Builds RFC 9449 claims for a token-endpoint DPoP proof.
     * - htm is always "POST" because token endpoint requests use HTTP POST (RFC 9449 §5).
     * - htu is the normalized token endpoint URI (query and fragment stripped).
     * - jti is a fresh CSPRNG-backed unique identifier for every proof.
     */
    buildTokenProofClaims(params: DpopTokenProofParams, correlationId?: string): DpopProofClaims;
    /**
     * Builds and signs a compact DPoP proof JWT for a token-endpoint request.
     */
    generateTokenProof(params: DpopTokenProofParams, keyId: string, correlationId?: string): Promise<string>;
    /**
     * Builds RFC 9449 claims for a resource-endpoint DPoP proof.
     * - htm is uppercased per RFC 9449 §4.2.
     * - htu is the normalized resource URI (query and fragment stripped).
     * - ath is the base64url-encoded SHA-256 hash of the ASCII access token.
     * - jti is a fresh CSPRNG-backed unique identifier for every proof.
     */
    buildResourceProofClaims(params: DpopResourceProofParams, correlationId?: string): DpopProofClaims;
    /**
     * Builds and signs a compact DPoP proof JWT for a resource request.
     */
    generateResourceProof(params: GenerateDpopResourceProofParams, keyId: string, correlationId?: string): Promise<string>;
    private generateProof;
}
//# sourceMappingURL=DpopProofGenerator.d.ts.map