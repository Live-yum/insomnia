import type { BaseAuthRequest } from "../request/BaseAuthRequest.js";
import type { JoseHeader } from "./JoseHeader.js";
/**
 * PKCE code verifier and challenge pair used by authorization code flows.
 */
export type PkceCodes = {
    verifier: string;
    challenge: string;
};
/**
 * Parameters used by crypto implementations to build signed HTTP request
 * proof-of-possession tokens.
 */
export type SignedHttpRequestParameters = Pick<BaseAuthRequest, "resourceRequestMethod" | "resourceRequestUri" | "shrClaims" | "shrNonce" | "shrOptions"> & {
    correlationId: string;
};
/**
 * Shared JOSE algorithm literals used by MSAL package internals.
 * @internal
 */
export declare const JsonWebTokenAlgorithms: {
    readonly ES256: "ES256";
    readonly RS256: "RS256";
};
/**
 * Interface for crypto functions used by library
 */
export interface ICrypto {
    /**
     * Creates a guid randomly.
     */
    createNewGuid(): string;
    /**
     * base64 Encode string
     * @param input
     */
    base64Encode(input: string): string;
    /**
     * base64 decode string
     * @param input
     */
    base64Decode(input: string): string;
    /**
     * base64 URL safe encoded string
     */
    base64UrlEncode(input: string): string;
    /**
     * Stringifies and base64Url encodes input public key
     * @param inputKid
     * @returns Base64Url encoded public key
     */
    encodeKid(inputKid: string): string;
    /**
     * Removes cryptographic keypair from key store matching the keyId passed in
     * @param kid
     * @param correlationId
     */
    removeTokenBindingKey(kid: string, correlationId: string): Promise<void>;
    /**
     * Removes all cryptographic keys from IndexedDB storage
     * @param correlationId
     */
    clearKeystore(correlationId: string): Promise<boolean>;
    /**
     * Signs a compact JWT with the token-binding key identified by kid.
     * @internal
     * @param header
     * @param payload
     * @param kid
     * @param correlationId
     */
    signTokenBindingJwt(header: JoseHeader, payload: object, kid: string, correlationId: string): Promise<string>;
    /**
     * Returns the SHA-256 hash of an input string
     * @param plainText
     */
    hashString(plainText: string): Promise<string>;
}
/**
 * Default crypto implementation used when a platform-specific implementation has
 * not been provided.
 */
export declare const DEFAULT_CRYPTO_IMPLEMENTATION: ICrypto;
//# sourceMappingURL=ICrypto.d.ts.map