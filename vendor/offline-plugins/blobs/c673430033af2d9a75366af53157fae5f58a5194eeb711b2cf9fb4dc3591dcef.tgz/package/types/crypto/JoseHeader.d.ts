import { JsonWebTokenTypes } from "../utils/Constants.js";
import type { PublicJsonWebKey } from "./PublicJsonWebKey.js";
export type JoseHeaderOptions = {
    typ?: JsonWebTokenTypes;
    alg?: string;
    kid?: string;
    jwk?: PublicJsonWebKey;
};
/** @internal */
export declare class JoseHeader {
    typ?: JsonWebTokenTypes;
    alg: string;
    kid?: string;
    jwk?: PublicJsonWebKey;
    constructor(options: JoseHeaderOptions & {
        alg: string;
    }, correlationId: string);
    /**
     * Builds SignedHttpRequest formatted JOSE Header from the
     * JOSE Header options provided or previously set on the object.
     * Throws if keyId or algorithm aren't provided since they are required for Access Token Binding.
     * @param shrHeaderOptions
     * @param correlationId
     * @returns
     */
    static getShrHeader(shrHeaderOptions: JoseHeaderOptions, correlationId: string): JoseHeader;
    /**
     * Builds a DPoP formatted JOSE Header from the JOSE Header options provided.
     * Throws if public JWK or algorithm aren't provided since they are required for DPoP.
     * @param dpopHeaderOptions
     * @param correlationId
     * @returns
     */
    static getDpopHeader(dpopHeaderOptions: JoseHeaderOptions, correlationId: string): JoseHeader;
}
//# sourceMappingURL=JoseHeader.d.ts.map