export declare const missingKidError = "missing_kid_error";
export declare const missingAlgError = "missing_alg_error";
export declare const missingJwkError = "missing_jwk_error";
export declare const invalidJwkError = "invalid_jwk_error";
//# sourceMappingURL=JoseHeaderErrorCodes.d.ts.map