import { ClientAssertionCallback } from "../account/ClientCredentials.js";
export declare function getClientAssertion(clientAssertion: string | ClientAssertionCallback, clientId: string, tokenEndpoint?: string, fmiPath?: string): Promise<string>;
//# sourceMappingURL=ClientAssertionUtils.d.ts.map