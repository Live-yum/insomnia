/**
 * Checks whether a value is a plain JSON-like object.
 * Allows objects with null prototypes, but rejects arrays and object subclasses.
 */
export declare function isPlainObject(value: unknown): value is Record<string, unknown>;
//# sourceMappingURL=ObjectUtils.d.ts.map