export declare const name = "@azure/msal-common";
export declare const version = "16.14.1";
//# sourceMappingURL=packageMetadata.d.ts.map