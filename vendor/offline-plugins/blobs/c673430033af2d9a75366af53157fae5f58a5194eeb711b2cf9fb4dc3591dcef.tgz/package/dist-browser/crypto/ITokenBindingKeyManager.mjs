/*! @azure/msal-common v16.14.1 2026-09-15 */
'use strict';
import { createClientAuthError } from '../error/ClientAuthError.mjs';
import { methodNotImplemented } from '../error/ClientAuthErrorCodes.mjs';

/*
 * Copyright (c) Microsoft Corporation. All rights reserved.
 * Licensed under the MIT License.
 */
/**
 * Default token-binding key manager used when a platform-specific implementation
 * has not been provided.
 * @internal
 */
const DEFAULT_TOKEN_BINDING_KEY_MANAGER = {
    async provisionTokenBindingKey(request) {
        throw createClientAuthError(methodNotImplemented, request.correlationId);
    },
    async removeTokenBindingKey(_kid, correlationId) {
        throw createClientAuthError(methodNotImplemented, correlationId);
    },
    async getTokenBindingPublicKeyJwk(_kid, correlationId) {
        throw createClientAuthError(methodNotImplemented, correlationId);
    },
};

export { DEFAULT_TOKEN_BINDING_KEY_MANAGER };
//# sourceMappingURL=ITokenBindingKeyManager.mjs.map
