/*! @azure/msal-common v16.14.1 2026-09-15 */
'use strict';
import { createClientAuthError } from '../error/ClientAuthError.mjs';
import { methodNotImplemented } from '../error/ClientAuthErrorCodes.mjs';

/*
 * Copyright (c) Microsoft Corporation. All rights reserved.
 * Licensed under the MIT License.
 */
/**
 * Shared JOSE algorithm literals used by MSAL package internals.
 * @internal
 */
const JsonWebTokenAlgorithms = {
    ES256: "ES256",
    RS256: "RS256",
};
/**
 * Default crypto implementation used when a platform-specific implementation has
 * not been provided.
 */
const DEFAULT_CRYPTO_IMPLEMENTATION = {
    createNewGuid: () => {
        throw createClientAuthError(methodNotImplemented, "");
    },
    base64Decode: () => {
        throw createClientAuthError(methodNotImplemented, "");
    },
    base64Encode: () => {
        throw createClientAuthError(methodNotImplemented, "");
    },
    base64UrlEncode: () => {
        throw createClientAuthError(methodNotImplemented, "");
    },
    encodeKid: () => {
        throw createClientAuthError(methodNotImplemented, "");
    },
    async removeTokenBindingKey(kid, correlationId) {
        throw createClientAuthError(methodNotImplemented, correlationId);
    },
    async clearKeystore(correlationId) {
        throw createClientAuthError(methodNotImplemented, correlationId);
    },
    async signTokenBindingJwt(header, payload, kid, correlationId) {
        throw createClientAuthError(methodNotImplemented, correlationId);
    },
    async hashString() {
        throw createClientAuthError(methodNotImplemented, "");
    },
};

export { DEFAULT_CRYPTO_IMPLEMENTATION, JsonWebTokenAlgorithms };
//# sourceMappingURL=ICrypto.mjs.map
