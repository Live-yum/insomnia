/*! @azure/msal-common v16.14.1 2026-09-15 */
'use strict';
import { JsonWebTokenAlgorithms } from './ICrypto.mjs';
import { nowSeconds } from '../utils/TimeUtils.mjs';
import { createClientConfigurationError } from '../error/ClientConfigurationError.mjs';
import { JoseHeader } from './JoseHeader.mjs';
import { dpopMissingResourceContext, invalidDpopNonce, urlParseError, invalidDpopHtu, invalidDpopHtm } from '../error/ClientConfigurationErrorCodes.mjs';

/*
 * Copyright (c) Microsoft Corporation. All rights reserved.
 * Licensed under the MIT License.
 */
const DPOP_HTM_REGEX = /^[!#$%&'*+\-.^_`|~0-9A-Za-z]+$/;
const DPOP_TOKEN_BINDING_KEY_TYPE = "dpop";
const DPOP_JWT_HEADER_ALGORITHM = JsonWebTokenAlgorithms.ES256;
function buildProofHeader(publicJwk, correlationId) {
    return JoseHeader.getDpopHeader({
        alg: DPOP_JWT_HEADER_ALGORITHM,
        jwk: publicJwk,
    }, correlationId);
}
function normalizeHtm(htm, correlationId) {
    if (typeof htm !== "string" || !DPOP_HTM_REGEX.test(htm)) {
        throw createClientConfigurationError(invalidDpopHtm, correlationId);
    }
    return htm.toUpperCase();
}
/**
 * Normalizes a URL for use as the DPoP htu claim.
 * Per RFC 9449 §4.2, htu is the target URI without query and fragment components.
 * WHATWG URL serialization handles RFC 3986 syntax- and scheme-based normalization
 * such as lowercasing scheme/host and eliding default ports.
 */
function normalizeHtu(url, correlationId) {
    let parsedUrl;
    try {
        parsedUrl = new URL(url);
    }
    catch {
        throw createClientConfigurationError(urlParseError, correlationId);
    }
    if (!/^https:\/\//i.test(url) ||
        parsedUrl.protocol !== "https:" ||
        parsedUrl.username ||
        parsedUrl.password) {
        throw createClientConfigurationError(invalidDpopHtu, correlationId);
    }
    parsedUrl.search = "";
    parsedUrl.hash = "";
    return parsedUrl.href;
}
function validateDpopNonce(nonce, correlationId) {
    if (nonce !== undefined && nonce.trim().length === 0) {
        throw createClientConfigurationError(invalidDpopNonce, correlationId);
    }
}
/**
 * Builds RFC 9449 DPoP proof JWT payloads for token-endpoint and
 * resource-endpoint proof bindings.
 *
 * Not exported from any public package entry point.
 * This helper is internal-only until DPoP is wired into acquisition flows
 * in a subsequent work item.
 *
 * DPoP proofs do not contain SHR fields (at, ts, m, u, p, q).
 * @internal
 */
class DpopProofGenerator {
    constructor(cryptoUtils, tokenBindingKeyManager) {
        this.cryptoUtils = cryptoUtils;
        this.tokenBindingKeyManager = tokenBindingKeyManager;
    }
    /**
     * Provisions a fresh DPoP key and returns the RFC 7638 JWK thumbprint used
     * as `dpop_jkt`.
     */
    async generateJkt(correlationId = "") {
        return this.tokenBindingKeyManager.provisionTokenBindingKey({
            tokenBindingKeyType: DPOP_TOKEN_BINDING_KEY_TYPE,
            tokenBindingKeyAlgorithm: DPOP_JWT_HEADER_ALGORITHM,
            correlationId,
        });
    }
    /**
     * Builds RFC 9449 claims for a token-endpoint DPoP proof.
     * - htm is always "POST" because token endpoint requests use HTTP POST (RFC 9449 §5).
     * - htu is the normalized token endpoint URI (query and fragment stripped).
     * - jti is a fresh CSPRNG-backed unique identifier for every proof.
     */
    buildTokenProofClaims(params, correlationId = "") {
        validateDpopNonce(params.nonce, correlationId);
        const claims = {
            jti: this.cryptoUtils.createNewGuid(),
            htm: "POST",
            htu: normalizeHtu(params.tokenEndpoint, correlationId),
            iat: nowSeconds(),
        };
        if (params.nonce !== undefined) {
            claims.nonce = params.nonce;
        }
        return claims;
    }
    /**
     * Builds and signs a compact DPoP proof JWT for a token-endpoint request.
     */
    async generateTokenProof(params, keyId, correlationId = "") {
        return this.generateProof(this.buildTokenProofClaims(params, correlationId), keyId, correlationId);
    }
    /**
     * Builds RFC 9449 claims for a resource-endpoint DPoP proof.
     * - htm is uppercased per RFC 9449 §4.2.
     * - htu is the normalized resource URI (query and fragment stripped).
     * - ath is the base64url-encoded SHA-256 hash of the ASCII access token.
     * - jti is a fresh CSPRNG-backed unique identifier for every proof.
     */
    buildResourceProofClaims(params, correlationId = "") {
        validateDpopNonce(params.nonce, correlationId);
        const claims = {
            jti: this.cryptoUtils.createNewGuid(),
            htm: normalizeHtm(params.htm, correlationId),
            htu: normalizeHtu(params.htu, correlationId),
            ath: params.ath,
            iat: nowSeconds(),
        };
        if (params.nonce !== undefined) {
            claims.nonce = params.nonce;
        }
        return claims;
    }
    /**
     * Builds and signs a compact DPoP proof JWT for a resource request.
     */
    async generateResourceProof(params, keyId, correlationId = "") {
        const { htu, htm, nonce } = params;
        if (!htu || !htm) {
            throw createClientConfigurationError(dpopMissingResourceContext, correlationId);
        }
        const ath = await this.cryptoUtils.hashString(params.accessToken);
        return this.generateProof(this.buildResourceProofClaims({
            htu,
            htm,
            ath,
            nonce,
        }, correlationId), keyId, correlationId);
    }
    async generateProof(claims, keyId, correlationId) {
        const publicJwk = await this.tokenBindingKeyManager.getTokenBindingPublicKeyJwk(keyId, correlationId);
        return this.cryptoUtils.signTokenBindingJwt(buildProofHeader(publicJwk, correlationId), claims, keyId, correlationId);
    }
}

export { DpopProofGenerator };
//# sourceMappingURL=DpopProofGenerator.mjs.map
