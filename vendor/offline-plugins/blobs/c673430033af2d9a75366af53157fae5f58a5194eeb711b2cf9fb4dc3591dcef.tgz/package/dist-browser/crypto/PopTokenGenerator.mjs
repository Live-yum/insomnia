/*! @azure/msal-common v16.14.1 2026-09-15 */
'use strict';
import { JsonWebTokenAlgorithms } from './ICrypto.mjs';
import { nowSeconds } from '../utils/TimeUtils.mjs';
import { UrlString } from '../url/UrlString.mjs';
import { PopTokenGenerateCnf } from '../telemetry/performance/PerformanceEvents.mjs';
import { invokeAsync } from '../utils/FunctionWrappers.mjs';
import { JoseHeader } from './JoseHeader.mjs';

/*
 * Copyright (c) Microsoft Corporation. All rights reserved.
 * Licensed under the MIT License.
 */
const KeyLocation = {
    SW: "sw"};
const SHR_TOKEN_BINDING_KEY_TYPE = "shr";
const SHR_TOKEN_BINDING_KEY_ALGORITHM = JsonWebTokenAlgorithms.RS256;
/** @internal */
class PopTokenGenerator {
    constructor(cryptoUtils, tokenBindingKeyManager, performanceClient) {
        this.cryptoUtils = cryptoUtils;
        this.tokenBindingKeyManager = tokenBindingKeyManager;
        this.performanceClient = performanceClient;
    }
    /**
     * Generates the req_cnf validated at the RP in the POP protocol for SHR parameters
     * and returns an object containing the keyid, the full req_cnf string and the req_cnf string hash
     * @param request
     * @returns
     */
    async generateCnf(request, logger) {
        const reqCnf = await invokeAsync(this.generateKid.bind(this), PopTokenGenerateCnf, logger, this.performanceClient, request.correlationId)(request);
        const reqCnfString = this.cryptoUtils.base64UrlEncode(JSON.stringify(reqCnf));
        return {
            kid: reqCnf.kid,
            reqCnfString,
        };
    }
    /**
     * Generates key_id for a SHR token request
     * @param request
     * @returns
     */
    async generateKid(request) {
        const kidThumbprint = await this.tokenBindingKeyManager.provisionTokenBindingKey({
            correlationId: request.correlationId,
            tokenBindingKeyType: SHR_TOKEN_BINDING_KEY_TYPE,
            tokenBindingKeyAlgorithm: SHR_TOKEN_BINDING_KEY_ALGORITHM,
        });
        return {
            kid: kidThumbprint,
            xms_ksl: KeyLocation.SW,
        };
    }
    /**
     * Signs the POP access_token with the local generated key-pair
     * @param accessToken
     * @param request
     * @returns
     */
    async signPopToken(accessToken, keyId, request) {
        return this.signPayload(accessToken, keyId, request);
    }
    /**
     * Utility function to generate the signed JWT for an access_token
     * @param payload
     * @param kid
     * @param request
     * @param claims
     * @returns
     */
    async signPayload(payload, keyId, request, claims) {
        // Deconstruct request to extract SHR parameters
        const { resourceRequestMethod, resourceRequestUri, shrClaims, shrNonce, shrOptions, } = request;
        const resourceUrlString = resourceRequestUri
            ? new UrlString(resourceRequestUri, request.correlationId)
            : undefined;
        const resourceUrlComponents = resourceUrlString?.getUrlComponents();
        const publicKeyJwk = await this.tokenBindingKeyManager.getTokenBindingPublicKeyJwk(keyId, request.correlationId);
        const encodedKeyIdThumbprint = this.cryptoUtils.base64UrlEncode(JSON.stringify({ kid: keyId }));
        const shrAlgorithm = shrOptions?.header?.alg ||
            publicKeyJwk.alg ||
            SHR_TOKEN_BINDING_KEY_ALGORITHM;
        const shrHeader = JoseHeader.getShrHeader({
            ...shrOptions?.header,
            alg: shrAlgorithm,
            kid: encodedKeyIdThumbprint,
        }, request.correlationId);
        const shrPayload = {
            at: payload,
            ts: nowSeconds(),
            m: resourceRequestMethod?.toUpperCase(),
            u: resourceUrlComponents?.HostNameAndPort,
            nonce: shrNonce || this.cryptoUtils.createNewGuid(),
            p: resourceUrlComponents?.AbsolutePath,
            q: resourceUrlComponents?.QueryString
                ? [[], resourceUrlComponents.QueryString]
                : undefined,
            client_claims: shrClaims || undefined,
            ...claims,
            cnf: {
                jwk: publicKeyJwk,
            },
        };
        return this.cryptoUtils.signTokenBindingJwt(shrHeader, shrPayload, keyId, request.correlationId);
    }
}

export { PopTokenGenerator };
//# sourceMappingURL=PopTokenGenerator.mjs.map
