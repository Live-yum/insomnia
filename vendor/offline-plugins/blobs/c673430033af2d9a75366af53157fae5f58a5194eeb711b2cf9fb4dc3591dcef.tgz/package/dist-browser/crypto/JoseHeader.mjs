/*! @azure/msal-common v16.14.1 2026-09-15 */
'use strict';
import { createJoseHeaderError } from '../error/JoseHeaderError.mjs';
import { isPlainObject } from '../utils/ObjectUtils.mjs';
import { JsonWebTokenTypes } from '../utils/Constants.mjs';
import { missingAlgError, missingKidError, missingJwkError, invalidJwkError } from '../error/JoseHeaderErrorCodes.mjs';

/*
 * Copyright (c) Microsoft Corporation. All rights reserved.
 * Licensed under the MIT License.
 */
/** @internal */
class JoseHeader {
    constructor(options, correlationId) {
        if (typeof options.alg !== "string" || !options.alg) {
            throw createJoseHeaderError(missingAlgError, correlationId);
        }
        this.typ = options.typ;
        this.alg = options.alg;
        this.kid = options.kid;
        this.jwk = options.jwk;
    }
    /**
     * Builds SignedHttpRequest formatted JOSE Header from the
     * JOSE Header options provided or previously set on the object.
     * Throws if keyId or algorithm aren't provided since they are required for Access Token Binding.
     * @param shrHeaderOptions
     * @param correlationId
     * @returns
     */
    static getShrHeader(shrHeaderOptions, correlationId) {
        // KeyID is required on the SHR header
        if (!shrHeaderOptions.kid) {
            throw createJoseHeaderError(missingKidError, correlationId);
        }
        // Alg is required on the SHR header
        if (!shrHeaderOptions.alg) {
            throw createJoseHeaderError(missingAlgError, correlationId);
        }
        return new JoseHeader({
            // Access Token PoP headers must have type pop, but the type header can be overriden for special cases
            typ: shrHeaderOptions.typ || JsonWebTokenTypes.Pop,
            kid: shrHeaderOptions.kid,
            alg: shrHeaderOptions.alg,
        }, correlationId);
    }
    /**
     * Builds a DPoP formatted JOSE Header from the JOSE Header options provided.
     * Throws if public JWK or algorithm aren't provided since they are required for DPoP.
     * @param dpopHeaderOptions
     * @param correlationId
     * @returns
     */
    static getDpopHeader(dpopHeaderOptions, correlationId) {
        if (!isPlainObject(dpopHeaderOptions.jwk)) {
            throw createJoseHeaderError(missingJwkError, correlationId);
        }
        if (!dpopHeaderOptions.alg) {
            throw createJoseHeaderError(missingAlgError, correlationId);
        }
        if (Object.keys(dpopHeaderOptions.jwk).length === 0) {
            throw createJoseHeaderError(invalidJwkError, correlationId);
        }
        return new JoseHeader({
            typ: JsonWebTokenTypes.Dpop,
            alg: dpopHeaderOptions.alg,
            jwk: dpopHeaderOptions.jwk,
        }, correlationId);
    }
}

export { JoseHeader };
//# sourceMappingURL=JoseHeader.mjs.map
