/*! @azure/msal-common v16.14.1 2026-09-15 */
'use strict';
/* eslint-disable header/header */
const name = "@azure/msal-common";
const version = "16.14.1";

export { name, version };
//# sourceMappingURL=packageMetadata.mjs.map
