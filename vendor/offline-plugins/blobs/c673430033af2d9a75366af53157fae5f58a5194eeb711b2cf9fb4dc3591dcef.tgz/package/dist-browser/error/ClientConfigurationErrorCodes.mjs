/*! @azure/msal-common v16.14.1 2026-09-15 */
'use strict';
/*
 * Copyright (c) Microsoft Corporation. All rights reserved.
 * Licensed under the MIT License.
 */
const redirectUriEmpty = "redirect_uri_empty";
const claimsRequestParsingError = "claims_request_parsing_error";
const authorityUriInsecure = "authority_uri_insecure";
const urlParseError = "url_parse_error";
const urlEmptyError = "empty_url_error";
const emptyInputScopesError = "empty_input_scopes_error";
const invalidClaims = "invalid_claims";
const tokenRequestEmpty = "token_request_empty";
const logoutRequestEmpty = "logout_request_empty";
const invalidCodeChallengeMethod = "invalid_code_challenge_method";
const pkceParamsMissing = "pkce_params_missing";
const invalidCloudDiscoveryMetadata = "invalid_cloud_discovery_metadata";
const invalidAuthorityMetadata = "invalid_authority_metadata";
const untrustedAuthority = "untrusted_authority";
const missingSshJwk = "missing_ssh_jwk";
const missingSshKid = "missing_ssh_kid";
const unsupportedAuthenticationScheme = "unsupported_authentication_scheme";
const missingNonceAuthenticationHeader = "missing_nonce_authentication_header";
const invalidAuthenticationHeader = "invalid_authentication_header";
const cannotSetOIDCOptions = "cannot_set_OIDCOptions";
const cannotAllowPlatformBroker = "cannot_allow_platform_broker";
const authorityMismatch = "authority_mismatch";
const invalidRequestMethodForEAR = "invalid_request_method_for_EAR";
const invalidPlatformBrokerConfiguration = "invalid_platform_broker_configuration";
const issuerValidationFailed = "issuer_validation_failed";
const invalidResponseMode = "invalid_response_mode";
const invalidDpopHtm = "invalid_dpop_htm";
const invalidDpopHtu = "invalid_dpop_htu";
const invalidDpopNonce = "invalid_dpop_nonce";
const dpopMissingResourceContext = "dpop_missing_resource_context";

export { authorityMismatch, authorityUriInsecure, cannotAllowPlatformBroker, cannotSetOIDCOptions, claimsRequestParsingError, dpopMissingResourceContext, emptyInputScopesError, invalidAuthenticationHeader, invalidAuthorityMetadata, invalidClaims, invalidCloudDiscoveryMetadata, invalidCodeChallengeMethod, invalidDpopHtm, invalidDpopHtu, invalidDpopNonce, invalidPlatformBrokerConfiguration, invalidRequestMethodForEAR, invalidResponseMode, issuerValidationFailed, logoutRequestEmpty, missingNonceAuthenticationHeader, missingSshJwk, missingSshKid, pkceParamsMissing, redirectUriEmpty, tokenRequestEmpty, unsupportedAuthenticationScheme, untrustedAuthority, urlEmptyError, urlParseError };
//# sourceMappingURL=ClientConfigurationErrorCodes.mjs.map
