/*! @azure/msal-common v16.14.1 2026-09-15 */
'use strict';
/*
 * Copyright (c) Microsoft Corporation. All rights reserved.
 * Licensed under the MIT License.
 */
const missingKidError = "missing_kid_error";
const missingAlgError = "missing_alg_error";
const missingJwkError = "missing_jwk_error";
const invalidJwkError = "invalid_jwk_error";

export { invalidJwkError, missingAlgError, missingJwkError, missingKidError };
//# sourceMappingURL=JoseHeaderErrorCodes.mjs.map
