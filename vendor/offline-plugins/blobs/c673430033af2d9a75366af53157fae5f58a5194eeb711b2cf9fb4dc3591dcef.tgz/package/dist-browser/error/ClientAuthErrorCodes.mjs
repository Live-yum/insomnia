/*! @azure/msal-common v16.14.1 2026-09-15 */
'use strict';
/*
 * Copyright (c) Microsoft Corporation. All rights reserved.
 * Licensed under the MIT License.
 */
const clientInfoDecodingError = "client_info_decoding_error";
const clientInfoEmptyError = "client_info_empty_error";
const tokenParsingError = "token_parsing_error";
const nullOrEmptyToken = "null_or_empty_token";
const endpointResolutionError = "endpoints_resolution_error";
const networkError = "network_error";
const openIdConfigError = "openid_config_error";
const hashNotDeserialized = "hash_not_deserialized";
const invalidState = "invalid_state";
const stateMismatch = "state_mismatch";
const stateNotFound = "state_not_found";
const nonceMismatch = "nonce_mismatch";
const multipleMatchingTokens = "multiple_matching_tokens";
const multipleMatchingAppMetadata = "multiple_matching_appMetadata";
const requestCannotBeMade = "request_cannot_be_made";
const cannotRemoveEmptyScope = "cannot_remove_empty_scope";
const cannotAppendScopeSet = "cannot_append_scopeset";
const emptyInputScopeSet = "empty_input_scopeset";
const noAccountInSilentRequest = "no_account_in_silent_request";
const invalidCacheRecord = "invalid_cache_record";
const invalidCacheEnvironment = "invalid_cache_environment";
const noAccountFound = "no_account_found";
const noCryptoObject = "no_crypto_object";
const unexpectedCredentialType = "unexpected_credential_type";
const dpopTokenTypeMismatch = "dpop_token_type_mismatch";
const tokenRefreshRequired = "token_refresh_required";
const tokenClaimsCnfRequiredForSignedJwt = "token_claims_cnf_required_for_signedjwt";
const authorizationCodeMissingFromServerResponse = "authorization_code_missing_from_server_response";
const bindingKeyNotRemoved = "binding_key_not_removed";
const endSessionEndpointNotSupported = "end_session_endpoint_not_supported";
const keyIdMissing = "key_id_missing";
const noNetworkConnectivity = "no_network_connectivity";
const userCanceled = "user_canceled";
const methodNotImplemented = "method_not_implemented";
const nestedAppAuthBridgeDisabled = "nested_app_auth_bridge_disabled";
const platformBrokerError = "platform_broker_error";
const resourceParameterRequired = "resource_parameter_required";
const misplacedResourceParam = "misplaced_resource_parameter";

export { authorizationCodeMissingFromServerResponse, bindingKeyNotRemoved, cannotAppendScopeSet, cannotRemoveEmptyScope, clientInfoDecodingError, clientInfoEmptyError, dpopTokenTypeMismatch, emptyInputScopeSet, endSessionEndpointNotSupported, endpointResolutionError, hashNotDeserialized, invalidCacheEnvironment, invalidCacheRecord, invalidState, keyIdMissing, methodNotImplemented, misplacedResourceParam, multipleMatchingAppMetadata, multipleMatchingTokens, nestedAppAuthBridgeDisabled, networkError, noAccountFound, noAccountInSilentRequest, noCryptoObject, noNetworkConnectivity, nonceMismatch, nullOrEmptyToken, openIdConfigError, platformBrokerError, requestCannotBeMade, resourceParameterRequired, stateMismatch, stateNotFound, tokenClaimsCnfRequiredForSignedJwt, tokenParsingError, tokenRefreshRequired, unexpectedCredentialType, userCanceled };
//# sourceMappingURL=ClientAuthErrorCodes.mjs.map
