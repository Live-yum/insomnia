/*! @azure/msal-common v16.14.1 2026-09-15 */
'use strict';
import { AuthError } from './AuthError.mjs';

/*
 * Copyright (c) Microsoft Corporation. All rights reserved.
 * Licensed under the MIT License.
 */
/**
 * ClientAuthErrorMessage class containing string constants used by error codes and messages.
 */
/**
 * Error thrown when there is an error in the client code running on the browser.
 */
class ClientAuthError extends AuthError {
    constructor(errorCode, correlationId, additionalMessage) {
        super(errorCode, correlationId, additionalMessage);
        this.name = "ClientAuthError";
        Object.setPrototypeOf(this, ClientAuthError.prototype);
    }
}
function createClientAuthError(errorCode, correlationId, additionalMessage) {
    return new ClientAuthError(errorCode, correlationId, additionalMessage);
}

export { ClientAuthError, createClientAuthError };
//# sourceMappingURL=ClientAuthError.mjs.map
