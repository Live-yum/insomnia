/*! @azure/msal-common v16.14.1 2026-09-15 */
'use strict';
/*
 * Copyright (c) Microsoft Corporation. All rights reserved.
 * Licensed under the MIT License.
 */
function getDefaultErrorMessage(code) {
    return `See https://aka.ms/msal.js.errors#${code} for details`;
}
/**
 * General error class thrown by the MSAL.js library.
 */
class AuthError extends Error {
    constructor(errorCode, correlationId, errorMessage, suberror) {
        const message = errorMessage ||
            (errorCode ? getDefaultErrorMessage(errorCode) : "");
        const errorString = message ? `${errorCode}: ${message}` : errorCode;
        super(errorString);
        Object.setPrototypeOf(this, AuthError.prototype);
        this.errorCode = errorCode || "";
        this.errorMessage = message || "";
        this.subError = suberror || "";
        this.correlationId = correlationId;
        this.name = "AuthError";
    }
}
function createAuthError(code, correlationId, additionalMessage) {
    return new AuthError(code, correlationId, additionalMessage || getDefaultErrorMessage(code));
}

export { AuthError, createAuthError, getDefaultErrorMessage };
//# sourceMappingURL=AuthError.mjs.map
