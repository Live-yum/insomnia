/*! @azure/msal-common v16.14.1 2026-09-15 */
'use strict';
import { AuthError } from './AuthError.mjs';

/*
 * Copyright (c) Microsoft Corporation. All rights reserved.
 * Licensed under the MIT License.
 */
/**
 * Error thrown when there is an error in the client code running on the browser.
 */
class JoseHeaderError extends AuthError {
    constructor(errorCode, correlationId, errorMessage) {
        super(errorCode, correlationId, errorMessage);
        this.name = "JoseHeaderError";
        Object.setPrototypeOf(this, JoseHeaderError.prototype);
    }
}
/** Returns JoseHeaderError object */
function createJoseHeaderError(code, correlationId) {
    return new JoseHeaderError(code, correlationId);
}

export { JoseHeaderError, createJoseHeaderError };
//# sourceMappingURL=JoseHeaderError.mjs.map
