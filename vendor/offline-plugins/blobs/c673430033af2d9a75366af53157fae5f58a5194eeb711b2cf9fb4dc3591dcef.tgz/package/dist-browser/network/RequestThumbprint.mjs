/*! @azure/msal-common v16.14.1 2026-09-15 */
'use strict';
import { serializeAttributeTokens } from '../cache/utils/CacheHelpers.mjs';

/*
 * Copyright (c) Microsoft Corporation. All rights reserved.
 * Licensed under the MIT License.
 */
function getRequestThumbprint(clientId, request, homeAccountId) {
    return {
        clientId: clientId,
        authority: request.authority,
        scopes: request.scopes,
        homeAccountIdentifier: homeAccountId,
        claims: request.claims,
        authenticationScheme: request.authenticationScheme,
        resourceRequestMethod: request.resourceRequestMethod,
        resourceRequestUri: request.resourceRequestUri,
        shrClaims: request.shrClaims,
        sshKid: request.sshKid,
        embeddedClientId: request.embeddedClientId || request.extraParameters?.clientId,
        resource: request.resource,
        attributeTokens: serializeAttributeTokens(request.attributeTokens),
    };
}

export { getRequestThumbprint };
//# sourceMappingURL=RequestThumbprint.mjs.map
