/*
 * Copyright (c) Microsoft Corporation. All rights reserved.
 * Licensed under the MIT License.
 */

import { AuthorityType } from "./AuthorityType.js";
import {
    isOpenIdConfigResponse,
    OpenIdConfigResponse,
} from "./OpenIdConfigResponse.js";
import { UrlString } from "../url/UrlString.js";
import { IUri } from "../url/IUri.js";
import {
    createClientAuthError,
    ClientAuthErrorCodes,
} from "../error/ClientAuthError.js";
import { INetworkModule } from "../network/INetworkModule.js";
import * as Constants from "../utils/Constants.js";
import {
    EndpointMetadata,
    getCloudDiscoveryMetadataFromHardcodedValues,
    getCloudDiscoveryMetadataFromNetworkResponse,
    InstanceDiscoveryMetadataAliases,
} from "./AuthorityMetadata.js";
import {
    createClientConfigurationError,
    ClientConfigurationErrorCodes,
} from "../error/ClientConfigurationError.js";
import { ProtocolMode } from "./ProtocolMode.js";
import { ICacheManager } from "../cache/interface/ICacheManager.js";
import { AuthorityMetadataEntity } from "../cache/entities/AuthorityMetadataEntity.js";
import {
    AuthorityOptions,
    AzureCloudInstance,
    StaticAuthorityOptions,
} from "./AuthorityOptions.js";
import {
    CloudInstanceDiscoveryResponse,
    isCloudInstanceDiscoveryResponse,
} from "./CloudInstanceDiscoveryResponse.js";
import {
    CloudInstanceDiscoveryErrorResponse,
    isCloudInstanceDiscoveryErrorResponse,
} from "./CloudInstanceDiscoveryErrorResponse.js";
import { CloudDiscoveryMetadata } from "./CloudDiscoveryMetadata.js";
import { RegionDiscovery } from "./RegionDiscovery.js";
import { RegionDiscoveryMetadata } from "./RegionDiscoveryMetadata.js";
import { ImdsOptions } from "./ImdsOptions.js";
import type { AzureCloudOptions } from "../config/ClientConfiguration.js";
import { Logger } from "../logger/Logger.js";
import { AuthError } from "../error/AuthError.js";
import { IPerformanceClient } from "../telemetry/performance/IPerformanceClient.js";
import * as PerformanceEvents from "../telemetry/performance/PerformanceEvents.js";
import { invokeAsync } from "../utils/FunctionWrappers.js";
import * as CacheHelpers from "../cache/utils/CacheHelpers.js";

/**
 * The authority class validates the authority URIs used by the user, and retrieves the OpenID Configuration Data from the
 * endpoint. It will store the pertinent config data in this object for use during token calls.
 * @internal
 */
export class Authority {
    // Canonical authority url string
    private _canonicalAuthority: UrlString;
    // Canonicaly authority url components
    private _canonicalAuthorityUrlComponents: IUri | null;
    // Network interface to make requests with.
    protected networkInterface: INetworkModule;
    // Cache Manager to cache network responses
    protected cacheManager: ICacheManager;
    // Protocol mode to construct endpoints
    private authorityOptions: AuthorityOptions;
    // Authority metadata
    private metadata: AuthorityMetadataEntity;
    // Region discovery service
    private regionDiscovery: RegionDiscovery;
    // Region discovery metadata
    public regionDiscoveryMetadata: RegionDiscoveryMetadata;
    // Logger object
    private logger: Logger;
    // Performance client
    protected performanceClient: IPerformanceClient;
    // Correlation Id
    protected correlationId: string;
    // Indicates if the authority is fake, for the purpose of a Managed Identity Application
    private managedIdentity: boolean;
    // Reserved tenant domain names that will not be replaced with tenant id
    private static reservedTenantDomains: Set<string> = new Set([
        "{tenant}",
        "{tenantid}",
        Constants.AADAuthority.COMMON,
        Constants.AADAuthority.CONSUMERS,
        Constants.AADAuthority.ORGANIZATIONS,
    ]);

    constructor(
        authority: string,
        networkInterface: INetworkModule,
        cacheManager: ICacheManager,
        authorityOptions: AuthorityOptions,
        logger: Logger,
        correlationId: string,
        performanceClient: IPerformanceClient,
        managedIdentity?: boolean
    ) {
        this.canonicalAuthority = authority;
        this._canonicalAuthority.validateAsUri();
        this.networkInterface = networkInterface;
        this.cacheManager = cacheManager;
        this.authorityOptions = authorityOptions;
        this.regionDiscoveryMetadata = {
            region_used: undefined,
            region_source: undefined,
            region_outcome: undefined,
        };
        this.logger = logger;
        this.performanceClient = performanceClient;
        this.correlationId = correlationId;
        this.managedIdentity = managedIdentity || false;
        this.regionDiscovery = new RegionDiscovery(
            networkInterface,
            this.logger,
            this.performanceClient,
            this.correlationId
        );
    }

    /**
     * Get {@link AuthorityType:type}
     * @param authorityUri {@link IUri}
     * @private
     */
    private getAuthorityType(authorityUri: IUri): AuthorityType {
        // CIAM auth url pattern is being standardized as: <tenant>.ciamlogin.com
        if (authorityUri.HostNameAndPort.endsWith(Constants.CIAM_AUTH_URL)) {
            return AuthorityType.Ciam;
        }

        const pathSegments = authorityUri.PathSegments;
        if (pathSegments.length) {
            switch (pathSegments[0].toLowerCase()) {
                case Constants.ADFS:
                    return AuthorityType.Adfs;
                default:
                    break;
            }
        }
        return AuthorityType.Default;
    }

    // See above for AuthorityType
    public get authorityType(): AuthorityType {
        return this.getAuthorityType(this.canonicalAuthorityUrlComponents);
    }

    /**
     * ProtocolMode enum representing the way endpoints are constructed.
     */
    public get protocolMode(): ProtocolMode {
        return this.authorityOptions.protocolMode;
    }

    /**
     * Returns authorityOptions which can be used to reinstantiate a new authority instance
     */
    public get options(): AuthorityOptions {
        return this.authorityOptions;
    }

    /**
     * A URL that is the authority set by the developer
     */
    public get canonicalAuthority(): string {
        return this._canonicalAuthority.urlString;
    }

    /**
     * Sets canonical authority.
     */
    public set canonicalAuthority(url: string) {
        this._canonicalAuthority = new UrlString(url, this.correlationId);
        this._canonicalAuthority.validateAsUri();
        this._canonicalAuthorityUrlComponents = null;
    }

    /**
     * Get authority components.
     */
    public get canonicalAuthorityUrlComponents(): IUri {
        if (!this._canonicalAuthorityUrlComponents) {
            this._canonicalAuthorityUrlComponents =
                this._canonicalAuthority.getUrlComponents();
        }

        return this._canonicalAuthorityUrlComponents;
    }

    /**
     * Get hostname and port i.e. login.microsoftonline.com
     */
    public get hostnameAndPort(): string {
        return this.canonicalAuthorityUrlComponents.HostNameAndPort.toLowerCase();
    }

    /**
     * Get tenant for authority.
     */
    public get tenant(): string {
        return this.canonicalAuthorityUrlComponents.PathSegments[0];
    }

    /**
     * OAuth /authorize endpoint for requests
     */
    public get authorizationEndpoint(): string {
        if (this.discoveryComplete()) {
            return this.replacePath(this.metadata.authorization_endpoint);
        } else {
            throw createClientAuthError(
                ClientAuthErrorCodes.endpointResolutionError,
                this.correlationId
            );
        }
    }

    /**
     * OAuth /token endpoint for requests
     */
    public get tokenEndpoint(): string {
        if (this.discoveryComplete()) {
            return this.replacePath(this.metadata.token_endpoint);
        } else {
            throw createClientAuthError(
                ClientAuthErrorCodes.endpointResolutionError,
                this.correlationId
            );
        }
    }

    public get deviceCodeEndpoint(): string {
        if (this.discoveryComplete()) {
            return this.replacePath(
                this.metadata.token_endpoint.replace("/token", "/devicecode")
            );
        } else {
            throw createClientAuthError(
                ClientAuthErrorCodes.endpointResolutionError,
                this.correlationId
            );
        }
    }

    /**
     * OAuth logout endpoint for requests
     */
    public get endSessionEndpoint(): string {
        if (this.discoveryComplete()) {
            // ROPC policies may not have end_session_endpoint set
            if (!this.metadata.end_session_endpoint) {
                throw createClientAuthError(
                    ClientAuthErrorCodes.endSessionEndpointNotSupported,
                    this.correlationId
                );
            }
            return this.replacePath(this.metadata.end_session_endpoint);
        } else {
            throw createClientAuthError(
                ClientAuthErrorCodes.endpointResolutionError,
                this.correlationId
            );
        }
    }

    /**
     * OAuth issuer for requests
     */
    public get selfSignedJwtAudience(): string {
        if (this.discoveryComplete()) {
            return this.replacePath(this.metadata.issuer);
        } else {
            throw createClientAuthError(
                ClientAuthErrorCodes.endpointResolutionError,
                this.correlationId
            );
        }
    }

    /**
     * Jwks_uri for token signing keys
     */
    public get jwksUri(): string {
        if (this.discoveryComplete()) {
            return this.replacePath(this.metadata.jwks_uri);
        } else {
            throw createClientAuthError(
                ClientAuthErrorCodes.endpointResolutionError,
                this.correlationId
            );
        }
    }

    /**
     * Returns a flag indicating that tenant name can be replaced in authority {@link IUri}
     * @param authorityUri {@link IUri}
     * @private
     */
    private canReplaceTenant(authorityUri: IUri): boolean {
        return (
            authorityUri.PathSegments.length === 1 &&
            !Authority.reservedTenantDomains.has(
                authorityUri.PathSegments[0]
            ) &&
            this.getAuthorityType(authorityUri) === AuthorityType.Default &&
            this.protocolMode !== ProtocolMode.OIDC
        );
    }

    /**
     * Replaces tenant in url path with current tenant. Defaults to common.
     * @param urlString
     */
    private replaceTenant(urlString: string): string {
        return urlString.replace(/{tenant}|{tenantid}/g, this.tenant);
    }

    /**
     * Replaces path such as tenant or policy with the current tenant or policy.
     * @param urlString
     */
    private replacePath(urlString: string): string {
        let endpoint = urlString;
        const cachedAuthorityUrl = new UrlString(
            this.metadata.canonical_authority,
            this.correlationId
        );
        const cachedAuthorityUrlComponents =
            cachedAuthorityUrl.getUrlComponents();
        const cachedAuthorityParts = cachedAuthorityUrlComponents.PathSegments;
        const currentAuthorityParts =
            this.canonicalAuthorityUrlComponents.PathSegments;

        currentAuthorityParts.forEach((currentPart, index) => {
            let cachedPart = cachedAuthorityParts[index];
            if (
                index === 0 &&
                this.canReplaceTenant(cachedAuthorityUrlComponents)
            ) {
                const tenantId = new UrlString(
                    this.metadata.authorization_endpoint,
                    this.correlationId
                ).getUrlComponents().PathSegments[0];
                /**
                 * Check if AAD canonical authority contains tenant domain name, for example "testdomain.onmicrosoft.com",
                 * by comparing its first path segment to the corresponding authorization endpoint path segment, which is
                 * always resolved with tenant id by OIDC.
                 */
                if (cachedPart !== tenantId) {
                    this.logger.verbose(
                        `Replacing tenant domain name '${cachedPart}' with id '${tenantId}'`,
                        this.correlationId
                    );
                    cachedPart = tenantId;
                }
            }
            if (currentPart !== cachedPart) {
                endpoint = endpoint.replace(
                    `/${cachedPart}/`,
                    `/${currentPart}/`
                );
            }
        });

        return this.replaceTenant(endpoint);
    }

    /**
     * The default open id configuration endpoint for any canonical authority.
     */
    protected get defaultOpenIdConfigurationEndpoint(): string {
        const canonicalAuthorityHost = this.hostnameAndPort;
        if (
            this.canonicalAuthority.endsWith("v2.0/") ||
            this.authorityType === AuthorityType.Adfs ||
            (this.protocolMode === ProtocolMode.OIDC &&
                !this.isAliasOfKnownMicrosoftAuthority(canonicalAuthorityHost))
        ) {
            return `${this.canonicalAuthority}.well-known/openid-configuration`;
        }
        return `${this.canonicalAuthority}v2.0/.well-known/openid-configuration`;
    }

    /**
     * Boolean that returns whether or not tenant discovery has been completed.
     */
    discoveryComplete(): boolean {
        return !!this.metadata;
    }

    /**
     * Perform endpoint discovery to discover aliases, preferred_cache, preferred_network
     * and the /authorize, /token and logout endpoints.
     */
    public async resolveEndpointsAsync(): Promise<void> {
        const metadataEntity = this.getCurrentMetadataEntity();

        const cloudDiscoverySource = await invokeAsync(
            this.updateCloudDiscoveryMetadata.bind(this),
            PerformanceEvents.AuthorityUpdateCloudDiscoveryMetadata,
            this.logger,
            this.performanceClient,
            this.correlationId
        )(metadataEntity);
        this.canonicalAuthority = this.canonicalAuthority.replace(
            this.hostnameAndPort,
            metadataEntity.preferred_network
        );
        const endpointSource = await invokeAsync(
            this.updateEndpointMetadata.bind(this),
            PerformanceEvents.AuthorityUpdateEndpointMetadata,
            this.logger,
            this.performanceClient,
            this.correlationId
        )(metadataEntity);
        this.updateCachedMetadata(metadataEntity, cloudDiscoverySource, {
            source: endpointSource,
        });
        this.performanceClient?.addFields(
            {
                cloudDiscoverySource: cloudDiscoverySource,
                authorityEndpointSource: endpointSource,
            },
            this.correlationId
        );
    }

    /**
     * Returns metadata entity from cache if it exists, otherwise returns a new metadata entity built
     * from the configured canonical authority
     * @returns
     */
    private getCurrentMetadataEntity(): AuthorityMetadataEntity {
        let metadataEntity: AuthorityMetadataEntity | null =
            this.cacheManager.getAuthorityMetadataByAlias(
                this.hostnameAndPort,
                this.correlationId
            );

        if (!metadataEntity) {
            metadataEntity = {
                aliases: [],
                preferred_cache: this.hostnameAndPort,
                preferred_network: this.hostnameAndPort,
                canonical_authority: this.canonicalAuthority,
                authorization_endpoint: "",
                token_endpoint: "",
                end_session_endpoint: "",
                issuer: "",
                aliasesFromNetwork: false,
                endpointsFromNetwork: false,
                expiresAt: CacheHelpers.generateAuthorityMetadataExpiresAt(),
                jwks_uri: "",
            };
        }
        return metadataEntity;
    }

    /**
     * Updates cached metadata based on metadata source and sets the instance's metadata
     * property to the same value
     * @param metadataEntity
     * @param cloudDiscoverySource
     * @param endpointMetadataResult
     */
    private updateCachedMetadata(
        metadataEntity: AuthorityMetadataEntity,
        cloudDiscoverySource: Constants.AuthorityMetadataSource | null,
        endpointMetadataResult: {
            source: Constants.AuthorityMetadataSource;
            metadata?: OpenIdConfigResponse;
        } | null
    ): void {
        if (
            cloudDiscoverySource !== Constants.AuthorityMetadataSource.CACHE &&
            endpointMetadataResult?.source !==
                Constants.AuthorityMetadataSource.CACHE
        ) {
            // Reset the expiration time unless both values came from a successful cache lookup
            metadataEntity.expiresAt =
                CacheHelpers.generateAuthorityMetadataExpiresAt();
            metadataEntity.canonical_authority = this.canonicalAuthority;
        }

        const cacheKey = this.cacheManager.generateAuthorityMetadataCacheKey(
            metadataEntity.preferred_cache,
            this.correlationId
        );
        this.cacheManager.setAuthorityMetadata(
            cacheKey,
            metadataEntity,
            this.correlationId
        );
        this.metadata = metadataEntity;
    }

    /**
     * Update AuthorityMetadataEntity with new endpoints and return where the information came from
     * @param metadataEntity
     */
    private async updateEndpointMetadata(
        metadataEntity: AuthorityMetadataEntity
    ): Promise<Constants.AuthorityMetadataSource> {
        const localMetadata =
            this.updateEndpointMetadataFromLocalSources(metadataEntity);

        // Further update may be required for hardcoded metadata if regional metadata is preferred
        if (localMetadata) {
            if (
                localMetadata.source ===
                Constants.AuthorityMetadataSource.HARDCODED_VALUES
            ) {
                // If the user prefers to use an azure region replace the global endpoints with regional information.
                if (
                    this.authorityOptions.azureRegionConfiguration?.azureRegion
                ) {
                    if (localMetadata.metadata) {
                        const hardcodedMetadata = await invokeAsync(
                            this.updateMetadataWithRegionalInformation.bind(
                                this
                            ),
                            PerformanceEvents.AuthorityUpdateMetadataWithRegionalInformation,
                            this.logger,
                            this.performanceClient,
                            this.correlationId
                        )(localMetadata.metadata);
                        CacheHelpers.updateAuthorityEndpointMetadata(
                            metadataEntity,
                            hardcodedMetadata,
                            false
                        );
                        metadataEntity.canonical_authority =
                            this.canonicalAuthority;
                    }
                }
            }
            return localMetadata.source;
        }

        // Get metadata from network if local sources aren't available
        let metadata = await invokeAsync(
            this.getEndpointMetadataFromNetwork.bind(this),
            PerformanceEvents.AuthorityGetEndpointMetadataFromNetwork,
            this.logger,
            this.performanceClient,
            this.correlationId
        )();
        if (metadata) {
            // Validate the issuer returned by the OIDC discovery document.
            this.validateIssuer(metadata.issuer);

            // If the user prefers to use an azure region replace the global endpoints with regional information.
            if (this.authorityOptions.azureRegionConfiguration?.azureRegion) {
                metadata = await invokeAsync(
                    this.updateMetadataWithRegionalInformation.bind(this),
                    PerformanceEvents.AuthorityUpdateMetadataWithRegionalInformation,
                    this.logger,
                    this.performanceClient,
                    this.correlationId
                )(metadata);
            }

            CacheHelpers.updateAuthorityEndpointMetadata(
                metadataEntity,
                metadata,
                true
            );
            return Constants.AuthorityMetadataSource.NETWORK;
        } else {
            // Metadata could not be obtained from the config, cache, network or hardcoded values
            throw createClientAuthError(
                ClientAuthErrorCodes.openIdConfigError,
                this.defaultOpenIdConfigurationEndpoint,
                this.correlationId
            );
        }
    }

    /**
     * Updates endpoint metadata from local sources and returns where the information was retrieved from and the metadata config
     * response if the source is hardcoded metadata
     * @param metadataEntity
     * @returns
     */
    private updateEndpointMetadataFromLocalSources(
        metadataEntity: AuthorityMetadataEntity
    ): {
        source: Constants.AuthorityMetadataSource;
        metadata?: OpenIdConfigResponse;
    } | null {
        this.logger.verbose(
            "Attempting to get endpoint metadata from authority configuration",
            this.correlationId
        );
        const configMetadata = this.getEndpointMetadataFromConfig();
        if (configMetadata) {
            this.logger.verbose(
                "Found endpoint metadata in authority configuration",
                this.correlationId
            );
            CacheHelpers.updateAuthorityEndpointMetadata(
                metadataEntity,
                configMetadata,
                false
            );
            return {
                source: Constants.AuthorityMetadataSource.CONFIG,
            };
        }

        this.logger.verbose(
            "Did not find endpoint metadata in the config... Attempting to get endpoint metadata from the hardcoded values.",
            this.correlationId
        );

        const hardcodedMetadata = this.getEndpointMetadataFromHardcodedValues();
        if (hardcodedMetadata) {
            CacheHelpers.updateAuthorityEndpointMetadata(
                metadataEntity,
                hardcodedMetadata,
                false
            );
            return {
                source: Constants.AuthorityMetadataSource.HARDCODED_VALUES,
                metadata: hardcodedMetadata,
            };
        } else {
            this.logger.verbose(
                "Did not find endpoint metadata in hardcoded values... Attempting to get endpoint metadata from the network metadata cache.",
                this.correlationId
            );
        }

        // Check cached metadata entity expiration status
        const metadataEntityExpired =
            CacheHelpers.isAuthorityMetadataExpired(metadataEntity);
        if (
            this.isAuthoritySameType(metadataEntity) &&
            metadataEntity.endpointsFromNetwork &&
            !metadataEntityExpired
        ) {
            // No need to update
            this.logger.verbose("Found endpoint metadata in the cache.", "");
            return { source: Constants.AuthorityMetadataSource.CACHE };
        } else if (metadataEntityExpired) {
            this.logger.verbose("The metadata entity is expired.", "");
        }

        return null;
    }

    /**
     * Compares the number of url components after the domain to determine if the cached
     * authority metadata can be used for the requested authority. Protects against same domain different
     * authority such as login.microsoftonline.com/tenant and login.microsoftonline.com/tfp/tenant/policy
     * @param metadataEntity
     */
    private isAuthoritySameType(
        metadataEntity: AuthorityMetadataEntity
    ): boolean {
        const cachedAuthorityUrl = new UrlString(
            metadataEntity.canonical_authority,
            this.correlationId
        );
        const cachedParts = cachedAuthorityUrl.getUrlComponents().PathSegments;

        return (
            cachedParts.length ===
            this.canonicalAuthorityUrlComponents.PathSegments.length
        );
    }

    /**
     * Parse authorityMetadata config option
     */
    private getEndpointMetadataFromConfig(): OpenIdConfigResponse | null {
        if (this.authorityOptions.authorityMetadata) {
            try {
                return JSON.parse(
                    this.authorityOptions.authorityMetadata
                ) as OpenIdConfigResponse;
            } catch (e) {
                throw createClientConfigurationError(
                    ClientConfigurationErrorCodes.invalidAuthorityMetadata,
                    this.correlationId
                );
            }
        }

        return null;
    }

    /**
     * Gets OAuth endpoints from the given OpenID configuration endpoint.
     *
     * @param hasHardcodedMetadata boolean
     */
    private async getEndpointMetadataFromNetwork(): Promise<OpenIdConfigResponse | null> {
        const options: ImdsOptions = {};

        /*
         * TODO: Add a timeout if the authority exists in our library's
         * hardcoded list of metadata
         */

        const openIdConfigurationEndpoint =
            this.defaultOpenIdConfigurationEndpoint;
        this.logger.verbose(
            `Authority.getEndpointMetadataFromNetwork: attempting to retrieve OAuth endpoints from '${openIdConfigurationEndpoint}'`,
            this.correlationId
        );

        try {
            const response =
                await this.networkInterface.sendGetRequestAsync<OpenIdConfigResponse>(
                    openIdConfigurationEndpoint,
                    options
                );
            const isValidResponse = isOpenIdConfigResponse(response.body);
            if (isValidResponse) {
                return response.body;
            } else {
                this.logger.verbose(
                    `Authority.getEndpointMetadataFromNetwork: could not parse response as OpenID configuration`,
                    this.correlationId
                );
                return null;
            }
        } catch (e) {
            this.logger.verbose(
                `Authority.getEndpointMetadataFromNetwork: '${e}'`,
                this.correlationId
            );
            return null;
        }
    }

    /**
     * Get OAuth endpoints for common authorities.
     */
    private getEndpointMetadataFromHardcodedValues(): OpenIdConfigResponse | null {
        if (this.hostnameAndPort in EndpointMetadata) {
            return EndpointMetadata[this.hostnameAndPort];
        }

        return null;
    }

    /**
     * Update the retrieved metadata with regional information.
     * User selected Azure region will be used if configured.
     */
    private async updateMetadataWithRegionalInformation(
        metadata: OpenIdConfigResponse
    ): Promise<OpenIdConfigResponse> {
        const userConfiguredAzureRegion =
            this.authorityOptions.azureRegionConfiguration?.azureRegion;

        if (userConfiguredAzureRegion) {
            if (
                userConfiguredAzureRegion !==
                Constants.AZURE_REGION_AUTO_DISCOVER_FLAG
            ) {
                this.regionDiscoveryMetadata.region_outcome =
                    Constants.RegionDiscoveryOutcomes.CONFIGURED_NO_AUTO_DETECTION;
                this.regionDiscoveryMetadata.region_used =
                    userConfiguredAzureRegion;
                return Authority.replaceWithRegionalInformation(
                    metadata,
                    userConfiguredAzureRegion,
                    this.correlationId
                );
            }

            const autodetectedRegionName = await invokeAsync(
                this.regionDiscovery.detectRegion.bind(this.regionDiscovery),
                PerformanceEvents.RegionDiscoveryDetectRegion,
                this.logger,
                this.performanceClient,
                this.correlationId
            )(
                this.authorityOptions.azureRegionConfiguration
                    ?.environmentRegion,
                this.regionDiscoveryMetadata
            );

            if (autodetectedRegionName) {
                this.regionDiscoveryMetadata.region_outcome =
                    Constants.RegionDiscoveryOutcomes.AUTO_DETECTION_REQUESTED_SUCCESSFUL;
                this.regionDiscoveryMetadata.region_used =
                    autodetectedRegionName;
                return Authority.replaceWithRegionalInformation(
                    metadata,
                    autodetectedRegionName,
                    this.correlationId
                );
            }

            this.regionDiscoveryMetadata.region_outcome =
                Constants.RegionDiscoveryOutcomes.AUTO_DETECTION_REQUESTED_FAILED;
        }

        return metadata;
    }

    /**
     * Updates the AuthorityMetadataEntity with new aliases, preferred_network and preferred_cache
     * and returns where the information was retrieved from
     * @param metadataEntity
     * @returns AuthorityMetadataSource
     */
    private async updateCloudDiscoveryMetadata(
        metadataEntity: AuthorityMetadataEntity
    ): Promise<Constants.AuthorityMetadataSource> {
        const localMetadataSource =
            this.updateCloudDiscoveryMetadataFromLocalSources(metadataEntity);
        if (localMetadataSource) {
            return localMetadataSource;
        }

        // Fallback to network as metadata source
        const metadata = await invokeAsync(
            this.getCloudDiscoveryMetadataFromNetwork.bind(this),
            PerformanceEvents.AuthorityGetCloudDiscoveryMetadataFromNetwork,
            this.logger,
            this.performanceClient,
            this.correlationId
        )();

        if (metadata) {
            CacheHelpers.updateCloudDiscoveryMetadata(
                metadataEntity,
                metadata,
                true
            );
            return Constants.AuthorityMetadataSource.NETWORK;
        }

        // Metadata could not be obtained from the config, cache, network or hardcoded values
        throw createClientConfigurationError(
            ClientConfigurationErrorCodes.untrustedAuthority,
            this.correlationId
        );
    }

    private updateCloudDiscoveryMetadataFromLocalSources(
        metadataEntity: AuthorityMetadataEntity
    ): Constants.AuthorityMetadataSource | null {
        this.logger.verbose(
            "Attempting to get cloud discovery metadata from authority configuration",
            this.correlationId
        );
        this.logger.verbosePii(
            `Known Authorities: '${
                this.authorityOptions.knownAuthorities ||
                Constants.NOT_APPLICABLE
            }'`,
            this.correlationId
        );
        this.logger.verbosePii(
            `Authority Metadata: '${
                this.authorityOptions.authorityMetadata ||
                Constants.NOT_APPLICABLE
            }'`,
            this.correlationId
        );
        this.logger.verbosePii(
            `Canonical Authority: '${
                metadataEntity.canonical_authority || Constants.NOT_APPLICABLE
            }'`,
            this.correlationId
        );
        const metadata = this.getCloudDiscoveryMetadataFromConfig();
        if (metadata) {
            this.logger.verbose(
                "Found cloud discovery metadata in authority configuration",
                this.correlationId
            );
            CacheHelpers.updateCloudDiscoveryMetadata(
                metadataEntity,
                metadata,
                false
            );
            return Constants.AuthorityMetadataSource.CONFIG;
        }

        // If the cached metadata came from config but that config was not passed to this instance, we must go to hardcoded values
        this.logger.verbose(
            "Did not find cloud discovery metadata in the config... Attempting to get cloud discovery metadata from the hardcoded values.",
            this.correlationId
        );

        const hardcodedMetadata = getCloudDiscoveryMetadataFromHardcodedValues(
            this.hostnameAndPort
        );
        if (hardcodedMetadata) {
            this.logger.verbose(
                "Found cloud discovery metadata from hardcoded values.",
                this.correlationId
            );
            CacheHelpers.updateCloudDiscoveryMetadata(
                metadataEntity,
                hardcodedMetadata,
                false
            );
            return Constants.AuthorityMetadataSource.HARDCODED_VALUES;
        }

        this.logger.verbose(
            "Did not find cloud discovery metadata in hardcoded values... Attempting to get cloud discovery metadata from the network metadata cache.",
            this.correlationId
        );

        const metadataEntityExpired =
            CacheHelpers.isAuthorityMetadataExpired(metadataEntity);
        if (
            this.isAuthoritySameType(metadataEntity) &&
            metadataEntity.aliasesFromNetwork &&
            !metadataEntityExpired
        ) {
            this.logger.verbose(
                "Found cloud discovery metadata in the cache.",
                ""
            );
            // No need to update
            return Constants.AuthorityMetadataSource.CACHE;
        } else if (metadataEntityExpired) {
            this.logger.verbose("The metadata entity is expired.", "");
        }

        return null;
    }

    /**
     * Parse cloudDiscoveryMetadata config or check knownAuthorities
     */
    private getCloudDiscoveryMetadataFromConfig(): CloudDiscoveryMetadata | null {
        // CIAM does not support cloud discovery metadata
        if (this.authorityType === AuthorityType.Ciam) {
            this.logger.verbose(
                "CIAM authorities do not support cloud discovery metadata, generate the aliases from authority host.",
                this.correlationId
            );
            return Authority.createCloudDiscoveryMetadataFromHost(
                this.hostnameAndPort
            );
        }

        // Check if network response was provided in config
        if (this.authorityOptions.cloudDiscoveryMetadata) {
            this.logger.verbose(
                "The cloud discovery metadata has been provided as a network response, in the config.",
                this.correlationId
            );
            try {
                this.logger.verbose(
                    "Attempting to parse the cloud discovery metadata.",
                    this.correlationId
                );
                const parsedResponse = JSON.parse(
                    this.authorityOptions.cloudDiscoveryMetadata
                ) as CloudInstanceDiscoveryResponse;
                const metadata = getCloudDiscoveryMetadataFromNetworkResponse(
                    parsedResponse.metadata,
                    this.hostnameAndPort
                );
                this.logger.verbose("Parsed the cloud discovery metadata.", "");
                if (metadata) {
                    this.logger.verbose(
                        "There is returnable metadata attached to the parsed cloud discovery metadata.",
                        this.correlationId
                    );
                    return metadata;
                } else {
                    this.logger.verbose(
                        "There is no metadata attached to the parsed cloud discovery metadata.",
                        this.correlationId
                    );
                }
            } catch (e) {
                this.logger.verbose(
                    "Unable to parse the cloud discovery metadata. Throwing Invalid Cloud Discovery Metadata Error.",
                    this.correlationId
                );
                throw createClientConfigurationError(
                    ClientConfigurationErrorCodes.invalidCloudDiscoveryMetadata,
                    this.correlationId
                );
            }
        }

        // If cloudDiscoveryMetadata is empty or does not contain the host, check knownAuthorities
        if (this.isInKnownAuthorities(this.hostnameAndPort)) {
            this.logger.verbose(
                "The host is included in knownAuthorities. Creating new cloud discovery metadata from the host.",
                this.correlationId
            );
            return Authority.createCloudDiscoveryMetadataFromHost(
                this.hostnameAndPort
            );
        }

        return null;
    }

    /**
     * Called to get metadata from network if CloudDiscoveryMetadata was not populated by config
     *
     * @param hasHardcodedMetadata boolean
     */
    private async getCloudDiscoveryMetadataFromNetwork(): Promise<CloudDiscoveryMetadata | null> {
        const instanceDiscoveryEndpoint = `${Constants.AAD_INSTANCE_DISCOVERY_ENDPT}${this.canonicalAuthority}oauth2/v2.0/authorize`;
        const options: ImdsOptions = {};

        /*
         * TODO: Add a timeout if the authority exists in our library's
         * hardcoded list of metadata
         */

        let match = null;
        try {
            const response = await this.networkInterface.sendGetRequestAsync<
                | CloudInstanceDiscoveryResponse
                | CloudInstanceDiscoveryErrorResponse
            >(instanceDiscoveryEndpoint, options);
            let typedResponseBody:
                | CloudInstanceDiscoveryResponse
                | CloudInstanceDiscoveryErrorResponse;
            let metadata: Array<CloudDiscoveryMetadata>;
            if (isCloudInstanceDiscoveryResponse(response.body)) {
                typedResponseBody =
                    response.body as CloudInstanceDiscoveryResponse;
                metadata = typedResponseBody.metadata;

                this.logger.verbosePii(
                    `tenant_discovery_endpoint is: '${typedResponseBody.tenant_discovery_endpoint}'`,
                    this.correlationId
                );
            } else if (isCloudInstanceDiscoveryErrorResponse(response.body)) {
                this.logger.warning(
                    `A CloudInstanceDiscoveryErrorResponse was returned. The cloud instance discovery network request's status code is: '${response.status}'`,
                    this.correlationId
                );

                typedResponseBody =
                    response.body as CloudInstanceDiscoveryErrorResponse;
                if (typedResponseBody.error === Constants.INVALID_INSTANCE) {
                    this.logger.error(
                        "The CloudInstanceDiscoveryErrorResponse error is invalid_instance.",
                        this.correlationId
                    );
                    return null;
                }

                this.logger.warning(
                    `The CloudInstanceDiscoveryErrorResponse error is '${typedResponseBody.error}'`,
                    this.correlationId
                );
                this.logger.warning(
                    `The CloudInstanceDiscoveryErrorResponse error description is '${typedResponseBody.error_description}'`,
                    this.correlationId
                );

                this.logger.warning(
                    "Setting the value of the CloudInstanceDiscoveryMetadata (returned from the network, correlationId) to []",
                    this.correlationId
                );
                metadata = [];
            } else {
                this.logger.error(
                    "AAD did not return a CloudInstanceDiscoveryResponse or CloudInstanceDiscoveryErrorResponse",
                    this.correlationId
                );
                return null;
            }

            this.logger.verbose(
                "Attempting to find a match between the developer's authority and the CloudInstanceDiscoveryMetadata returned from the network request.",
                this.correlationId
            );
            match = getCloudDiscoveryMetadataFromNetworkResponse(
                metadata,
                this.hostnameAndPort
            );
        } catch (error) {
            if (error instanceof AuthError) {
                this.logger.error(
                    `There was a network error while attempting to get the cloud discovery instance metadata.\nError: '${error.errorCode}'\nError Description: '${error.errorMessage}'`,
                    this.correlationId
                );
            } else {
                const typedError = error as Error;
                this.logger.error(
                    `A non-MSALJS error was thrown while attempting to get the cloud instance discovery metadata.\nError: '${typedError.name}'\nError Description: '${typedError.message}'`,
                    this.correlationId
                );
            }

            return null;
        }

        // Custom Domain scenario, host is trusted because Instance Discovery call succeeded
        if (!match) {
            this.logger.warning(
                "The developer's authority was not found within the CloudInstanceDiscoveryMetadata returned from the network request.",
                this.correlationId
            );
            this.logger.verbose(
                "Creating custom Authority for custom domain scenario.",
                this.correlationId
            );

            match = Authority.createCloudDiscoveryMetadataFromHost(
                this.hostnameAndPort
            );
        }
        return match;
    }

    /**
     * Helper function to determine if a host is included in the knownAuthorities config option.
     */
    private isInKnownAuthorities(host: string): boolean {
        const normalizedHost = host.toLowerCase();
        const matches = this.authorityOptions.knownAuthorities.filter(
            (authority) => {
                return (
                    authority &&
                    UrlString.getDomainFromUrl(
                        authority,
                        this.correlationId
                    ).toLowerCase() === normalizedHost
                );
            }
        );
        return matches.length > 0;
    }

    /**
     * helper function to populate the authority based on azureCloudOptions
     * @param authorityString
     * @param azureCloudOptions
     */
    static generateAuthority(
        authorityString: string,
        azureCloudOptions?: AzureCloudOptions
    ): string {
        let authorityAzureCloudInstance;

        if (
            azureCloudOptions &&
            azureCloudOptions.azureCloudInstance !== AzureCloudInstance.None
        ) {
            const tenant = azureCloudOptions.tenant
                ? azureCloudOptions.tenant
                : Constants.DEFAULT_COMMON_TENANT;
            authorityAzureCloudInstance = `${azureCloudOptions.azureCloudInstance}/${tenant}/`;
        }

        return authorityAzureCloudInstance
            ? authorityAzureCloudInstance
            : authorityString;
    }

    /**
     * Creates cloud discovery metadata object from a given host
     * @param host
     */
    static createCloudDiscoveryMetadataFromHost(
        host: string
    ): CloudDiscoveryMetadata {
        return {
            preferred_network: host,
            preferred_cache: host,
            aliases: [host],
        };
    }

    /**
     * helper function to generate environment from authority object
     */
    getPreferredCache(): string {
        if (this.managedIdentity) {
            return Constants.DEFAULT_AUTHORITY_HOST;
        } else if (this.discoveryComplete()) {
            return this.metadata.preferred_cache;
        } else {
            throw createClientAuthError(
                ClientAuthErrorCodes.endpointResolutionError,
                this.correlationId
            );
        }
    }

    /**
     * Returns whether or not the provided host is an alias of this authority instance
     * @param host
     */
    isAlias(host: string): boolean {
        return this.metadata.aliases.indexOf(host) > -1;
    }

    /**
     * Returns whether or not the provided host is an alias of a known Microsoft authority for purposes of endpoint discovery
     * @param host
     */
    isAliasOfKnownMicrosoftAuthority(host: string): boolean {
        return InstanceDiscoveryMetadataAliases.has(host);
    }

    /**
     * Validates the `issuer` returned by an OIDC discovery document against
     * this authority, per
     * https://openid.net/specs/openid-connect-discovery-1_0.html#ProviderConfigurationValidation
     *
     * The issuer is accepted when ANY of the following holds:
     *  1. The issuer scheme + host + port match the authority's (path may
     *     differ). Applies to all authorities.
     *  2. The authority is a Microsoft cloud authority (public, sovereign,
     *     or CIAM), the issuer is HTTPS, and the issuer host is in the known
     *     Microsoft authority host set.
     *  3. Same as (2), but the issuer host is a single-label regional variant
     *     of a known Microsoft host (e.g. `westus.login.microsoftonline.com`).
     *  4. Same as (2), but the issuer host matches the CIAM tenant pattern
     *     `{tenant}.ciamlogin.com` with an optional `/{tenant}[.onmicrosoft.com][/v2.0]`
     *     path.
     *  5. The issuer host is HTTPS and is explicitly listed in the
     *     developer-configured `knownAuthorities`. This covers scenarios where
     *     the OIDC discovery document returns an issuer host that differs from
     *     the authority (e.g., a GUID-based issuer for a name-based CIAM authority).
     *
     * @param issuer The `issuer` value returned in the OIDC discovery document.
     * @throws ClientConfigurationError("issuer_validation_failed") on failure.
     */
    private validateIssuer(issuer: string): void {
        if (!issuer) {
            throw createClientConfigurationError(
                ClientConfigurationErrorCodes.issuerValidationFailed,
                this.correlationId
            );
        }

        // Parse with the WHATWG URL API. URL normalizes scheme + host to lowercase per RFC 3986.
        let issuerUrl: URL;
        try {
            issuerUrl = new URL(issuer);
        } catch {
            throw createClientConfigurationError(
                ClientConfigurationErrorCodes.issuerValidationFailed,
                this.correlationId
            );
        }
        const issuerScheme = issuerUrl.protocol;
        const issuerHost = issuerUrl.host;
        const authorityScheme = (
            this.canonicalAuthorityUrlComponents.Protocol || ""
        ).toLowerCase();
        const authorityHost = (
            this.canonicalAuthorityUrlComponents.HostNameAndPort || ""
        ).toLowerCase();

        // Rule 1: Same scheme and host
        const matchesAuthorityOrigin = this.matchesAuthorityOrigin(
            issuerScheme,
            issuerHost,
            authorityScheme,
            authorityHost
        );

        // Rule 2: The issuer host is a well-known Microsoft authority host (HTTPS only)
        const matchesKnownMicrosoftHost =
            issuerScheme === "https:" &&
            this.isAliasOfKnownMicrosoftAuthority(issuerHost);

        /*
         * Rule 3: The issuer host is a regional variant ({region}.{host}) of a well-known host
         * (HTTPS only). E.g. westus2.login.microsoft.com
         */
        const matchesRegionalMicrosoftHost =
            issuerScheme === "https:" &&
            this.matchesRegionalMicrosoftHost(issuerHost);

        /*
         * Rule 4: CIAM-specific validation. In a CIAM scenario the issuer is expected to
         * have "{tenant}.ciamlogin.com" as the host, even when using a custom domain.
         */
        const matchesCiamTenantPattern = this.matchesCiamTenantPattern(
            issuerUrl,
            authorityHost,
            this.canonicalAuthorityUrlComponents.PathSegments
        );

        /*
         * Rule 5: The issuer host is explicitly listed in the developer-configured
         * knownAuthorities. This covers scenarios where the OIDC discovery document
         * returns an issuer with a different host than the authority
         * (e.g., a GUID-based issuer for a name-based authority).
         */
        const matchesKnownAuthority =
            issuerScheme === "https:" && this.isInKnownAuthorities(issuerHost);

        // Each rule is an independent boolean; the issuer is valid if ANY rule matches.
        if (
            matchesAuthorityOrigin ||
            matchesKnownMicrosoftHost ||
            matchesRegionalMicrosoftHost ||
            matchesCiamTenantPattern ||
            matchesKnownAuthority
        ) {
            return;
        }

        // issuer validation fails if none of the above rules are satisfied
        throw createClientConfigurationError(
            ClientConfigurationErrorCodes.issuerValidationFailed,
            this.correlationId
        );
    }

    /**
     * Rule 1: The issuer scheme + host (and port) match the authority's. Path
     * may differ. Applies to all authorities.
     */
    private matchesAuthorityOrigin(
        issuerScheme: string,
        issuerHost: string,
        authorityScheme: string,
        authorityHost: string
    ): boolean {
        return issuerScheme === authorityScheme && issuerHost === authorityHost;
    }

    /**
     * Rule 3: The issuer host is a regional variant
     * (`{region}.{host}`) of a known Microsoft authority host.
     * E.g. `westus2.login.microsoft.com`.
     */
    private matchesRegionalMicrosoftHost(issuerHost: string): boolean {
        const firstDot = issuerHost.indexOf(".");
        if (firstDot > 0 && firstDot < issuerHost.length - 1) {
            const hostWithoutRegion = issuerHost.substring(firstDot + 1);
            return this.isAliasOfKnownMicrosoftAuthority(hostWithoutRegion);
        }
        return false;
    }

    /**
     * Rule 4: The issuer matches one of the well-known CIAM tenant patterns
     * (`https://{tenant}.ciamlogin.com[/{tenant}[.onmicrosoft.com][/v2.0]]`).
     *
     * The bare tenant name is extracted from the authority's first path segment
     * when available (stripping the `.onmicrosoft.com` suffix that
     * `transformCIAMAuthority` adds), or otherwise from the leftmost label of
     * the authority host (to support CIAM custom domain scenarios).
     *
     * Both `/{tenant}` and `/{tenant}.onmicrosoft.com` path forms are accepted
     * because the OIDC issuer may use either form depending on the authority URL
     * that was used to trigger discovery.
     */
    private matchesCiamTenantPattern(
        issuerUrl: URL,
        authorityHost: string,
        authorityPathSegments: string[]
    ): boolean {
        /*
         * authorityPathSegments[0] is the first path segment of the *authority
         * URL* after transformCIAMAuthority runs (e.g. "contoso.onmicrosoft.com").
         * Additional CIAM issuer path segments such as "/v2.0" are part of the
         * issuer string, not the authority URL's PathSegments.
         */
        const pathSegment = authorityPathSegments[0];

        /*
         * Extract the bare tenant name: strip the .onmicrosoft.com suffix when
         * present (introduced by transformCIAMAuthority), or fall back to the
         * first label of the authority hostname for non-transformed/custom-domain
         * CIAM authorities.
         */
        const tenantName = pathSegment
            ? pathSegment.endsWith(Constants.AAD_TENANT_DOMAIN_SUFFIX)
                ? pathSegment.slice(
                      0,
                      -Constants.AAD_TENANT_DOMAIN_SUFFIX.length
                  )
                : pathSegment
            : authorityHost.split(".")[0];

        if (!tenantName) {
            return false;
        }

        const ciamBaseURL = `https://${tenantName}${Constants.CIAM_AUTH_URL}`;
        const validCiamPatterns: string[] = [
            ciamBaseURL, // https://{tenant}.ciamlogin.com
            `${ciamBaseURL}/${tenantName}`, // https://{tenant}.ciamlogin.com/{tenant}
            `${ciamBaseURL}/${tenantName}/v2.0`, // https://{tenant}.ciamlogin.com/{tenant}/v2.0
            `${ciamBaseURL}/${tenantName}${Constants.AAD_TENANT_DOMAIN_SUFFIX}`, // https://{tenant}.ciamlogin.com/{tenant}.onmicrosoft.com
            `${ciamBaseURL}/${tenantName}${Constants.AAD_TENANT_DOMAIN_SUFFIX}/v2.0`, // https://{tenant}.ciamlogin.com/{tenant}.onmicrosoft.com/v2.0
        ];

        /*
         * Compose the canonical issuer string from URL components and strip any
         * trailing slashes from the path so it can be compared to the pattern set.
         */
        const issuerPath = issuerUrl.pathname.replace(/\/+$/, "");
        const normalizedIssuer = `${issuerUrl.protocol}//${issuerUrl.host}${issuerPath}`;
        return validCiamPatterns.some(
            (pattern) => pattern === normalizedIssuer
        );
    }

    /**
     * Checks whether the provided host is that of a public cloud authority
     *
     * @param authority string
     * @returns bool
     */
    static isPublicCloudAuthority(host: string): boolean {
        return Constants.KNOWN_PUBLIC_CLOUDS.indexOf(host) >= 0;
    }

    /**
     * Rebuild the authority string with the region
     *
     * @param host string
     * @param region string
     */
    static buildRegionalAuthorityString(
        host: string,
        region: string,
        correlationId: string,
        queryString?: string
    ): string {
        // Create and validate a Url string object with the initial authority string
        const authorityUrlInstance = new UrlString(host, correlationId);
        authorityUrlInstance.validateAsUri();

        const authorityUrlParts = authorityUrlInstance.getUrlComponents();

        let hostNameAndPort = `${region}.${authorityUrlParts.HostNameAndPort}`;

        if (this.isPublicCloudAuthority(authorityUrlParts.HostNameAndPort)) {
            hostNameAndPort = `${region}.${Constants.REGIONAL_AUTH_PUBLIC_CLOUD_SUFFIX}`;
        }

        // Include the query string portion of the url
        const url = UrlString.constructAuthorityUriFromObject(
            {
                ...authorityUrlInstance.getUrlComponents(),
                HostNameAndPort: hostNameAndPort,
            },
            correlationId
        ).urlString;

        // Add the query string if a query string was provided
        if (queryString) return `${url}?${queryString}`;

        return url;
    }

    /**
     * Replace the endpoints in the metadata object with their regional equivalents.
     *
     * @param metadata OpenIdConfigResponse
     * @param azureRegion string
     */
    static replaceWithRegionalInformation(
        metadata: OpenIdConfigResponse,
        azureRegion: string,
        correlationId: string
    ): OpenIdConfigResponse {
        const regionalMetadata = { ...metadata };
        regionalMetadata.authorization_endpoint =
            Authority.buildRegionalAuthorityString(
                regionalMetadata.authorization_endpoint,
                azureRegion,
                correlationId
            );

        regionalMetadata.token_endpoint =
            Authority.buildRegionalAuthorityString(
                regionalMetadata.token_endpoint,
                azureRegion,
                correlationId
            );

        if (regionalMetadata.end_session_endpoint) {
            regionalMetadata.end_session_endpoint =
                Authority.buildRegionalAuthorityString(
                    regionalMetadata.end_session_endpoint,
                    azureRegion,
                    correlationId
                );
        }

        return regionalMetadata;
    }

    /**
     * Transform CIAM_AUTHORIY as per the below rules:
     * If no path segments found and it is a CIAM authority (hostname ends with .ciamlogin.com), then transform it
     *
     * NOTE: The transformation path should go away once STS supports CIAM with the format: `tenantIdorDomain.ciamlogin.com`
     * `ciamlogin.com` can also change in the future and we should accommodate the same
     *
     * @param authority
     */
    static transformCIAMAuthority(
        authority: string,
        correlationId: string
    ): string {
        let ciamAuthority = authority;
        const authorityUrl = new UrlString(authority, correlationId);
        const authorityUrlComponents = authorityUrl.getUrlComponents();

        // check if transformation is needed
        if (
            authorityUrlComponents.PathSegments.length === 0 &&
            authorityUrlComponents.HostNameAndPort.endsWith(
                Constants.CIAM_AUTH_URL
            )
        ) {
            const tenantIdOrDomain =
                authorityUrlComponents.HostNameAndPort.split(".")[0];
            ciamAuthority = `${ciamAuthority}${tenantIdOrDomain}${Constants.AAD_TENANT_DOMAIN_SUFFIX}`;
        }

        return ciamAuthority;
    }
}

/**
 * Extract tenantId from authority
 */
export function getTenantFromAuthorityString(
    authority: string,
    correlationId: string
): string | undefined {
    const authorityUrl = new UrlString(authority, correlationId);
    const authorityUrlComponents = authorityUrl.getUrlComponents();
    /**
     * For credential matching purposes, tenantId is the last path segment of the authority URL:
     *  AAD Authority - domain/tenantId -> Credentials are cached with realm = tenantId
     *  B2C Authority - domain/{tenantId}?/.../policy -> Credentials are cached with realm = policy
     *  tenantId is downcased because B2C policies can have mixed case but tfp claim is downcased
     *
     * Note that we may not have any path segments in certain OIDC scenarios.
     */
    const tenantId =
        authorityUrlComponents.PathSegments.slice(-1)[0]?.toLowerCase();

    switch (tenantId) {
        case Constants.AADAuthority.COMMON:
        case Constants.AADAuthority.ORGANIZATIONS:
        case Constants.AADAuthority.CONSUMERS:
            return undefined;
        default:
            return tenantId;
    }
}

export function formatAuthorityUri(authorityUri: string): string {
    return authorityUri.endsWith(Constants.FORWARD_SLASH)
        ? authorityUri
        : `${authorityUri}${Constants.FORWARD_SLASH}`;
}

export function buildStaticAuthorityOptions(
    authOptions: Partial<AuthorityOptions>
): StaticAuthorityOptions {
    const rawCloudDiscoveryMetadata = authOptions.cloudDiscoveryMetadata;
    let cloudDiscoveryMetadata: CloudInstanceDiscoveryResponse | undefined =
        undefined;
    if (rawCloudDiscoveryMetadata) {
        try {
            cloudDiscoveryMetadata = JSON.parse(rawCloudDiscoveryMetadata);
        } catch (e) {
            throw createClientConfigurationError(
                ClientConfigurationErrorCodes.invalidCloudDiscoveryMetadata,
                ""
            );
        }
    }
    return {
        canonicalAuthority: authOptions.authority
            ? formatAuthorityUri(authOptions.authority)
            : undefined,
        knownAuthorities: authOptions.knownAuthorities,
        cloudDiscoveryMetadata: cloudDiscoveryMetadata,
    };
}
