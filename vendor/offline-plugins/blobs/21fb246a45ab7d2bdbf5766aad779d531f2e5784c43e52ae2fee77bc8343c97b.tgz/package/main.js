// Request hook to set header on every request
module.exports.requestHooks = [
  (context) => {
    let UserPswd = [];
    UserPswd.push('{"Username": "User1", "Password": "Password1"}');
    UserPswd.push('{"Username": "User2", "Password": "Password2"}');

    var len = UserPswd.length;

    for (var i = 0; i < len; i++) {
      // request.setUrl("https://httpbin.org/POST");
      //  request.setBody(
      //  '{mimeType:"application/json", text:"',
      //  UserPswd[i],
      //  '"}'
      //);
      const response = context.network.sendRequest(context.request);
      const style =
        response.statusCode !== 200
          ? "padding:5px; color: var(--color-font-danger); background: var(--color-danger)"
          : "padding:5px; color: var(--color-font-success); background: var(--color-success)";
      results.push(
        `<li style="margin: 5px">${request.name}: <span style="${style}")>${response.statusCode}</span><span>${context.response.getTime}</span></li>`
      );
    }
    const html = `<ul style="column-count: ${
      results.length > 10 ? 2 : 1
    };">${results.join("\n")}</ul>`;

    context.app.showGenericModalDialog("Results", { html });
  },
];
