export { fromCognitoIdentity } from "./fromCognitoIdentity";
export { fromCognitoIdentityPool } from "./fromCognitoIdentityPool";
