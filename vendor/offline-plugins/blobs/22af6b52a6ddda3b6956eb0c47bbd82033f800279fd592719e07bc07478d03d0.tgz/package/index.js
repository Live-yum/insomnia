'use strict'

const { generateSignature } = require('@fulll/signature')
const CryptoJS = require('crypto-js')

function updateURLParams(request, urlString) {
  const [noSearchParamsURL] = urlString.replace(/^http:/, 'https:').split('?')
  const url = new URL(noSearchParamsURL)

  const params = request.parameters.sort(
    (a, b) => b.name.length - a.name.length,
  )
  for (const { name, value } of params) {
    if (!name) continue

    const toReplace = `:${name}`
    let path = url.pathname

    if (!path.includes(toReplace)) {
      // Not found in URL, treat as regular parameter
      continue
    }

    while (path.includes(toReplace)) {
      path = path.replace(toReplace, encodeURIComponent(value))
    }
    url.pathname = path
  }

  return url
}

async function buildURL(context, request) {
  const renderedURL = await context.util.render(request.url)
  return updateURLParams(request, renderedURL)
}

module.exports.templateTags = [
  {
    name: 'signature',
    displayName: 'HMAC-FULLL',
    description: 'Apply HMAC to a value with @fulll/signature',
    args: [
      {
        displayName: 'Key',
        type: 'string',
        placeholder: 'HMAC Secret Key',
      },
      {
        displayName: 'ttl in seconds',
        type: 'number',
        placeholder: 'Optional TTL value in second',
      },
      {
        displayName: 'query string',
        type: 'boolean',
        placeholder: 'whether the signature is used as query string or not',
      },
      {
        displayName: 'variables only',
        type: 'boolean',
        placeholder: 'whether only variables are used in hmac generation',
      },
      {
        displayName: 'force minify',
        type: 'boolean',
        placeholder: 'whether minify should be forced at signature creation',
      },
    ],
    async run(
      context,
      key = '',
      ttl = undefined,
      queryString = false,
      variablesOnly = false,
      forceMinify = false,
    ) {
      const { meta } = context

      const request = await context.util.models.request.getById(meta.requestId)
      const httpMethod = request.method

      try {
        const url = await buildURL(context, request)

        let body = request.body.text
        if (forceMinify) {
          try {
            body = JSON.stringify(JSON.parse(request.body.text))
          } catch {
            body = request.body.text
          }
        }

        if (variablesOnly) {
          const { variables = {} } = JSON.parse(body)
          console.log(JSON.stringify(variables))
          const encrypted = CryptoJS.HmacSHA1(JSON.stringify(variables), key)

          console.log(CryptoJS.enc.Base64.stringify(encrypted))
          return CryptoJS.enc.Base64.stringify(encrypted)
        }

        const restQuery = {
          body,
          method: httpMethod,
          url,
        }

        const signature = generateSignature(restQuery, key, ttl)

        console.log('generate signature from ', {
          restQuery,
          key,
          ttl,
          signature,
        })

        if (queryString) {
          const [part1, part2] = signature.split(':')
          return `_signature=${part2 || part1}${
            part2 && part1 ? `&_signature_ttl=${part1}` : ''
          }`
        }

        return `${signature}`
      } catch (err) {
        console.error('err', err)
        throw err
      }
    },
  },
]
