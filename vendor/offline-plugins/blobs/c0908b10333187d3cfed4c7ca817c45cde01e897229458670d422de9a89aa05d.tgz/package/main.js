const fetch = require("fetch-min");

module.exports = async function (context) {
  let UserPswd = [];
  UserPswd.push("{Username: 'Ronaldo', Password:  'Steffi'}");
  UserPswd.push("{Username: 'Sachin', Password:  'Ganguly'}");
  var len = UserPswd.length;

  for (var i = 0; i < len; i++) {
    const response = await authDataProvider(context);
    const style =
      response.statusCode !== 200
        ? "padding:5px; color: var(--color-font-danger); background: var(--color-danger)"
        : "padding:5px; color: var(--color-font-success); background: var(--color-success)";
    results.push(
      `<li style="margin: 5px">${UserPswd[i]}: <span style="${style}")>${response.statusCode}</span></li>`
    );
  }

  const html = `<ul style="column-count: ${
    results.length > 10 ? 2 : 1
  };">${results.join("\n")}</ul>`;

  context.app.showGenericModalDialog("Results", { html });
};

async function authDataProvider(context) {
  const url = "httpbin.org/post";

  let responseData = await window
    .fetch(`https://${url}`, {
      method: "post",
      headers: {
        "Content-type": "application/json",
      },
      body: JSON.stringify(UserPswd[0]),
    })
    .then((response) => {
      return response;
    })
    .catch((error) => {
      console.error(error);
    });
  let response = await responseData.json();
  console.log(response);
  return response;
}
