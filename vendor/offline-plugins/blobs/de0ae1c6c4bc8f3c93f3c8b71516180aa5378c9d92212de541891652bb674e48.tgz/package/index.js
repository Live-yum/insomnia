"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// src/insomnia/state.ts
var router = null;
var getRouter = () => {
  if (!router) {
    const root = document.querySelector("#root");
    if (!root) {
      return;
    }
    const parameter = Object.getOwnPropertyNames(root).findLast((x) => x.startsWith("__reactContainer"));
    router = root[parameter]?.memoizedState?.element?.props?.router;
  }
  return router;
};
var getState = () => {
  const router2 = getRouter();
  return router2?.state;
};
var getActiveWorkspaceId = () => {
  const state = getState();
  return state?.loaderData[":workspaceId"].activeWorkspace._id;
};
var getActiveEnvironmentId = () => {
  const state = getState();
  return state?.loaderData[":workspaceId"].activeEnvironment._id;
};

// src/insomnia/events.ts
var storageKey = "plugin-oa2-mate-event-handler-id";
var eventHandlerId = Math.random().toString(36).substring(2);
localStorage.setItem(storageKey, eventHandlerId);
var listeners = [];
var unsubscribe = window.main.on("db.changes", (_, changes) => {
  const currentEventHandlerId = localStorage.getItem(storageKey);
  if (currentEventHandlerId !== eventHandlerId) {
    unsubscribe();
    console.warn("[oa2-mate]", "Unsubscribed old event handler");
    return;
  }
  return changes.forEach(([method, doc]) => {
    if (!method || !doc) {
      console.log("[oa2-mate]", "unkonwn method or doc", method, doc);
      return;
    }
    listeners.forEach((listener) => {
      try {
        listener(method, doc);
      } catch (e) {
      }
    });
  });
});
var subscribe = (listener) => {
  listeners.push(listener);
  return () => listeners.splice(listeners.indexOf(listener), 1);
};

// src/services/db.ts
var path = __toESM(require("path"));
var NeDb = window.require("nedb");
var dbName = "Plugin.oa2";
var dbPath = path.join(window.app.getPath("userData"), `insomnia.${dbName}.db`);
var databaseInternal = new NeDb({ filename: dbPath, autoload: true, corruptAlertThreshold: 0.9, inMemoryOnly: false });
var database = databaseInternal;

// src/services/main.ts
var delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
var onTokenUpdate = (token) => {
  const activeWorkspaceId = getActiveWorkspaceId();
  const activeEnvironmentId = getActiveEnvironmentId();
  const tokenToStore = {
    accessToken: token.accessToken,
    environmentId: activeEnvironmentId ?? null,
    workspaceId: activeWorkspaceId,
    createdAt: Date.now()
  };
  database.update(
    { workspaceId: tokenToStore.workspaceId, environmentId: tokenToStore.environmentId },
    tokenToStore,
    { upsert: true },
    (err, affectedNum) => {
      if (err)
        console.error("[oa2-mate] Failed to store token", err);
      else if (affectedNum !== 1)
        console.warn("[oa2-mate] Unexpected amount of affected rows", affectedNum);
    }
  );
};
var getTokenAsync = (workspaceId, environmentId) => new Promise((resolve, reject) => {
  database.findOne({ workspaceId, environmentId }, (err, doc) => {
    if (err)
      reject(err);
    else
      resolve(doc);
  });
});
var getTokensAsync = (workspaceId) => new Promise((resolve, reject) => {
  database.find({ workspaceId }, {}, (err, docs) => {
    if (err)
      reject(err);
    else
      resolve(docs ?? []);
  });
});
var init = async () => {
  let maxRetries = 20;
  do {
    if (module.parent) {
      subscribe((method, doc) => {
        if (method !== "update" && method !== "insert")
          return;
        if (doc.type !== "OAuth2Token")
          return;
        onTokenUpdate(doc);
      });
      console.log("[oa2-mate] Initialized");
      break;
    }
    delay(500);
  } while (maxRetries-- > 0);
  if (maxRetries <= 0)
    console.error("[oa2-mate] Failed to initialize");
};
var getCurrentTokenAsync = async () => {
  const activeWorkspaceId = getActiveWorkspaceId();
  const activeEnvironmentId = getActiveEnvironmentId();
  return await getTokenAsync(activeWorkspaceId, activeEnvironmentId ?? null);
};
var getLatestTokenAsync = async () => {
  const activeWorkspaceId = getActiveWorkspaceId();
  const tokens = await getTokensAsync(activeWorkspaceId);
  if (tokens.length === 0)
    return null;
  return tokens.reduce((prev, curr) => prev.createdAt > curr.createdAt ? prev : curr, tokens[0] ?? null);
};

// src/template-tags/token-tag.ts
var tokenTag = {
  name: "oa2_mate",
  displayName: "oa2_mate",
  description: "Latest known OAuth2 token for workspace or environment",
  args: [
    {
      displayName: "Use environment-specific access tokens only.",
      help: "If checked, the access token will strictly correspond to the currently selected environment. Otherwise will be used the most recent access token regardless of the currently selected environment.",
      type: "boolean",
      defaultValue: false
    }
  ],
  async run(ctx, environmentSpecific) {
    const storedToken = environmentSpecific === true ? await getCurrentTokenAsync() : await getLatestTokenAsync();
    return storedToken?.accessToken ?? (!ctx.renderPurpose ? `(no ${environmentSpecific === true ? "environment" : "workspace"} tokens found)` : null);
  }
};

// src/index.ts
init();
module.exports = {
  templateTags: [tokenTag]
};
