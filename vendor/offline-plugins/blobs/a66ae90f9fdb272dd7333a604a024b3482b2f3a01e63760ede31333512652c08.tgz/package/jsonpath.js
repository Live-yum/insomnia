/*! jsonpath 1.3.0 */

(function(f){if(typeof exports==="object"&&typeof module!=="undefined"){module.exports=f()}else if(typeof define==="function"&&define.amd){define([],f)}else{var g;if(typeof window!=="undefined"){g=window}else if(typeof global!=="undefined"){g=global}else if(typeof self!=="undefined"){g=self}else{g=this}g.jsonpath = f()}})(function(){var define,module,exports;return (function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({"./aesprim":[function(require,module,exports){
/*
  Copyright (C) 2013 Ariya Hidayat <ariya.hidayat@gmail.com>
  Copyright (C) 2013 Thaddee Tyl <thaddee.tyl@gmail.com>
  Copyright (C) 2013 Mathias Bynens <mathias@qiwi.be>
  Copyright (C) 2012 Ariya Hidayat <ariya.hidayat@gmail.com>
  Copyright (C) 2012 Mathias Bynens <mathias@qiwi.be>
  Copyright (C) 2012 Joost-Wim Boekesteijn <joost-wim@boekesteijn.nl>
  Copyright (C) 2012 Kris Kowal <kris.kowal@cixar.com>
  Copyright (C) 2012 Yusuke Suzuki <utatane.tea@gmail.com>
  Copyright (C) 2012 Arpad Borsos <arpad.borsos@googlemail.com>
  Copyright (C) 2011 Ariya Hidayat <ariya.hidayat@gmail.com>

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in the
      documentation and/or other materials provided with the distribution.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED. IN NO EVENT SHALL <COPYRIGHT HOLDER> BE LIABLE FOR ANY
  DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
  (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
  LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
  THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

/*jslint bitwise:true plusplus:true */
/*global esprima:true, define:true, exports:true, window: true,
throwErrorTolerant: true,
throwError: true, generateStatement: true, peek: true,
parseAssignmentExpression: true, parseBlock: true, parseExpression: true,
parseFunctionDeclaration: true, parseFunctionExpression: true,
parseFunctionSourceElements: true, parseVariableIdentifier: true,
parseLeftHandSideExpression: true,
parseUnaryExpression: true,
parseStatement: true, parseSourceElement: true */

(function (root, factory) {
    'use strict';

    // Universal Module Definition (UMD) to support AMD, CommonJS/Node.js,
    // Rhino, and plain browser loading.

    /* istanbul ignore next */
    if (typeof define === 'function' && define.amd) {
        define(['exports'], factory);
    } else if (typeof exports !== 'undefined') {
        factory(exports);
    } else {
        factory((root.esprima = {}));
    }
}(this, function (exports) {
    'use strict';

    var Token,
        TokenName,
        FnExprTokens,
        Syntax,
        PropertyKind,
        Messages,
        Regex,
        SyntaxTreeDelegate,
        source,
        strict,
        index,
        lineNumber,
        lineStart,
        length,
        delegate,
        lookahead,
        state,
        extra;

    Token = {
        BooleanLiteral: 1,
        EOF: 2,
        Identifier: 3,
        Keyword: 4,
        NullLiteral: 5,
        NumericLiteral: 6,
        Punctuator: 7,
        StringLiteral: 8,
        RegularExpression: 9
    };

    TokenName = {};
    TokenName[Token.BooleanLiteral] = 'Boolean';
    TokenName[Token.EOF] = '<end>';
    TokenName[Token.Identifier] = 'Identifier';
    TokenName[Token.Keyword] = 'Keyword';
    TokenName[Token.NullLiteral] = 'Null';
    TokenName[Token.NumericLiteral] = 'Numeric';
    TokenName[Token.Punctuator] = 'Punctuator';
    TokenName[Token.StringLiteral] = 'String';
    TokenName[Token.RegularExpression] = 'RegularExpression';

    // A function following one of those tokens is an expression.
    FnExprTokens = ['(', '{', '[', 'in', 'typeof', 'instanceof', 'new',
                    'return', 'case', 'delete', 'throw', 'void',
                    // assignment operators
                    '=', '+=', '-=', '*=', '/=', '%=', '<<=', '>>=', '>>>=',
                    '&=', '|=', '^=', ',',
                    // binary/unary operators
                    '+', '-', '*', '/', '%', '++', '--', '<<', '>>', '>>>', '&',
                    '|', '^', '!', '~', '&&', '||', '?', ':', '===', '==', '>=',
                    '<=', '<', '>', '!=', '!=='];

    Syntax = {
        AssignmentExpression: 'AssignmentExpression',
        ArrayExpression: 'ArrayExpression',
        BlockStatement: 'BlockStatement',
        BinaryExpression: 'BinaryExpression',
        BreakStatement: 'BreakStatement',
        CallExpression: 'CallExpression',
        CatchClause: 'CatchClause',
        ConditionalExpression: 'ConditionalExpression',
        ContinueStatement: 'ContinueStatement',
        DoWhileStatement: 'DoWhileStatement',
        DebuggerStatement: 'DebuggerStatement',
        EmptyStatement: 'EmptyStatement',
        ExpressionStatement: 'ExpressionStatement',
        ForStatement: 'ForStatement',
        ForInStatement: 'ForInStatement',
        FunctionDeclaration: 'FunctionDeclaration',
        FunctionExpression: 'FunctionExpression',
        Identifier: 'Identifier',
        IfStatement: 'IfStatement',
        Literal: 'Literal',
        LabeledStatement: 'LabeledStatement',
        LogicalExpression: 'LogicalExpression',
        MemberExpression: 'MemberExpression',
        NewExpression: 'NewExpression',
        ObjectExpression: 'ObjectExpression',
        Program: 'Program',
        Property: 'Property',
        ReturnStatement: 'ReturnStatement',
        SequenceExpression: 'SequenceExpression',
        SwitchStatement: 'SwitchStatement',
        SwitchCase: 'SwitchCase',
        ThisExpression: 'ThisExpression',
        ThrowStatement: 'ThrowStatement',
        TryStatement: 'TryStatement',
        UnaryExpression: 'UnaryExpression',
        UpdateExpression: 'UpdateExpression',
        VariableDeclaration: 'VariableDeclaration',
        VariableDeclarator: 'VariableDeclarator',
        WhileStatement: 'WhileStatement',
        WithStatement: 'WithStatement'
    };

    PropertyKind = {
        Data: 1,
        Get: 2,
        Set: 4
    };

    // Error messages should be identical to V8.
    Messages = {
        UnexpectedToken:  'Unexpected token %0',
        UnexpectedNumber:  'Unexpected number',
        UnexpectedString:  'Unexpected string',
        UnexpectedIdentifier:  'Unexpected identifier',
        UnexpectedReserved:  'Unexpected reserved word',
        UnexpectedEOS:  'Unexpected end of input',
        NewlineAfterThrow:  'Illegal newline after throw',
        InvalidRegExp: 'Invalid regular expression',
        UnterminatedRegExp:  'Invalid regular expression: missing /',
        InvalidLHSInAssignment:  'Invalid left-hand side in assignment',
        InvalidLHSInForIn:  'Invalid left-hand side in for-in',
        MultipleDefaultsInSwitch: 'More than one default clause in switch statement',
        NoCatchOrFinally:  'Missing catch or finally after try',
        UnknownLabel: 'Undefined label \'%0\'',
        Redeclaration: '%0 \'%1\' has already been declared',
        IllegalContinue: 'Illegal continue statement',
        IllegalBreak: 'Illegal break statement',
        IllegalReturn: 'Illegal return statement',
        StrictModeWith:  'Strict mode code may not include a with statement',
        StrictCatchVariable:  'Catch variable may not be eval or arguments in strict mode',
        StrictVarName:  'Variable name may not be eval or arguments in strict mode',
        StrictParamName:  'Parameter name eval or arguments is not allowed in strict mode',
        StrictParamDupe: 'Strict mode function may not have duplicate parameter names',
        StrictFunctionName:  'Function name may not be eval or arguments in strict mode',
        StrictOctalLiteral:  'Octal literals are not allowed in strict mode.',
        StrictDelete:  'Delete of an unqualified identifier in strict mode.',
        StrictDuplicateProperty:  'Duplicate data property in object literal not allowed in strict mode',
        AccessorDataProperty:  'Object literal may not have data and accessor property with the same name',
        AccessorGetSet:  'Object literal may not have multiple get/set accessors with the same name',
        StrictLHSAssignment:  'Assignment to eval or arguments is not allowed in strict mode',
        StrictLHSPostfix:  'Postfix increment/decrement may not have eval or arguments operand in strict mode',
        StrictLHSPrefix:  'Prefix increment/decrement may not have eval or arguments operand in strict mode',
        StrictReservedWord:  'Use of future reserved word in strict mode'
    };

    // See also tools/generate-unicode-regex.py.
    Regex = {
        NonAsciiIdentifierStart: new RegExp('[\xAA\xB5\xBA\xC0-\xD6\xD8-\xF6\xF8-\u02C1\u02C6-\u02D1\u02E0-\u02E4\u02EC\u02EE\u0370-\u0374\u0376\u0377\u037A-\u037D\u0386\u0388-\u038A\u038C\u038E-\u03A1\u03A3-\u03F5\u03F7-\u0481\u048A-\u0527\u0531-\u0556\u0559\u0561-\u0587\u05D0-\u05EA\u05F0-\u05F2\u0620-\u064A\u066E\u066F\u0671-\u06D3\u06D5\u06E5\u06E6\u06EE\u06EF\u06FA-\u06FC\u06FF\u0710\u0712-\u072F\u074D-\u07A5\u07B1\u07CA-\u07EA\u07F4\u07F5\u07FA\u0800-\u0815\u081A\u0824\u0828\u0840-\u0858\u08A0\u08A2-\u08AC\u0904-\u0939\u093D\u0950\u0958-\u0961\u0971-\u0977\u0979-\u097F\u0985-\u098C\u098F\u0990\u0993-\u09A8\u09AA-\u09B0\u09B2\u09B6-\u09B9\u09BD\u09CE\u09DC\u09DD\u09DF-\u09E1\u09F0\u09F1\u0A05-\u0A0A\u0A0F\u0A10\u0A13-\u0A28\u0A2A-\u0A30\u0A32\u0A33\u0A35\u0A36\u0A38\u0A39\u0A59-\u0A5C\u0A5E\u0A72-\u0A74\u0A85-\u0A8D\u0A8F-\u0A91\u0A93-\u0AA8\u0AAA-\u0AB0\u0AB2\u0AB3\u0AB5-\u0AB9\u0ABD\u0AD0\u0AE0\u0AE1\u0B05-\u0B0C\u0B0F\u0B10\u0B13-\u0B28\u0B2A-\u0B30\u0B32\u0B33\u0B35-\u0B39\u0B3D\u0B5C\u0B5D\u0B5F-\u0B61\u0B71\u0B83\u0B85-\u0B8A\u0B8E-\u0B90\u0B92-\u0B95\u0B99\u0B9A\u0B9C\u0B9E\u0B9F\u0BA3\u0BA4\u0BA8-\u0BAA\u0BAE-\u0BB9\u0BD0\u0C05-\u0C0C\u0C0E-\u0C10\u0C12-\u0C28\u0C2A-\u0C33\u0C35-\u0C39\u0C3D\u0C58\u0C59\u0C60\u0C61\u0C85-\u0C8C\u0C8E-\u0C90\u0C92-\u0CA8\u0CAA-\u0CB3\u0CB5-\u0CB9\u0CBD\u0CDE\u0CE0\u0CE1\u0CF1\u0CF2\u0D05-\u0D0C\u0D0E-\u0D10\u0D12-\u0D3A\u0D3D\u0D4E\u0D60\u0D61\u0D7A-\u0D7F\u0D85-\u0D96\u0D9A-\u0DB1\u0DB3-\u0DBB\u0DBD\u0DC0-\u0DC6\u0E01-\u0E30\u0E32\u0E33\u0E40-\u0E46\u0E81\u0E82\u0E84\u0E87\u0E88\u0E8A\u0E8D\u0E94-\u0E97\u0E99-\u0E9F\u0EA1-\u0EA3\u0EA5\u0EA7\u0EAA\u0EAB\u0EAD-\u0EB0\u0EB2\u0EB3\u0EBD\u0EC0-\u0EC4\u0EC6\u0EDC-\u0EDF\u0F00\u0F40-\u0F47\u0F49-\u0F6C\u0F88-\u0F8C\u1000-\u102A\u103F\u1050-\u1055\u105A-\u105D\u1061\u1065\u1066\u106E-\u1070\u1075-\u1081\u108E\u10A0-\u10C5\u10C7\u10CD\u10D0-\u10FA\u10FC-\u1248\u124A-\u124D\u1250-\u1256\u1258\u125A-\u125D\u1260-\u1288\u128A-\u128D\u1290-\u12B0\u12B2-\u12B5\u12B8-\u12BE\u12C0\u12C2-\u12C5\u12C8-\u12D6\u12D8-\u1310\u1312-\u1315\u1318-\u135A\u1380-\u138F\u13A0-\u13F4\u1401-\u166C\u166F-\u167F\u1681-\u169A\u16A0-\u16EA\u16EE-\u16F0\u1700-\u170C\u170E-\u1711\u1720-\u1731\u1740-\u1751\u1760-\u176C\u176E-\u1770\u1780-\u17B3\u17D7\u17DC\u1820-\u1877\u1880-\u18A8\u18AA\u18B0-\u18F5\u1900-\u191C\u1950-\u196D\u1970-\u1974\u1980-\u19AB\u19C1-\u19C7\u1A00-\u1A16\u1A20-\u1A54\u1AA7\u1B05-\u1B33\u1B45-\u1B4B\u1B83-\u1BA0\u1BAE\u1BAF\u1BBA-\u1BE5\u1C00-\u1C23\u1C4D-\u1C4F\u1C5A-\u1C7D\u1CE9-\u1CEC\u1CEE-\u1CF1\u1CF5\u1CF6\u1D00-\u1DBF\u1E00-\u1F15\u1F18-\u1F1D\u1F20-\u1F45\u1F48-\u1F4D\u1F50-\u1F57\u1F59\u1F5B\u1F5D\u1F5F-\u1F7D\u1F80-\u1FB4\u1FB6-\u1FBC\u1FBE\u1FC2-\u1FC4\u1FC6-\u1FCC\u1FD0-\u1FD3\u1FD6-\u1FDB\u1FE0-\u1FEC\u1FF2-\u1FF4\u1FF6-\u1FFC\u2071\u207F\u2090-\u209C\u2102\u2107\u210A-\u2113\u2115\u2119-\u211D\u2124\u2126\u2128\u212A-\u212D\u212F-\u2139\u213C-\u213F\u2145-\u2149\u214E\u2160-\u2188\u2C00-\u2C2E\u2C30-\u2C5E\u2C60-\u2CE4\u2CEB-\u2CEE\u2CF2\u2CF3\u2D00-\u2D25\u2D27\u2D2D\u2D30-\u2D67\u2D6F\u2D80-\u2D96\u2DA0-\u2DA6\u2DA8-\u2DAE\u2DB0-\u2DB6\u2DB8-\u2DBE\u2DC0-\u2DC6\u2DC8-\u2DCE\u2DD0-\u2DD6\u2DD8-\u2DDE\u2E2F\u3005-\u3007\u3021-\u3029\u3031-\u3035\u3038-\u303C\u3041-\u3096\u309D-\u309F\u30A1-\u30FA\u30FC-\u30FF\u3105-\u312D\u3131-\u318E\u31A0-\u31BA\u31F0-\u31FF\u3400-\u4DB5\u4E00-\u9FCC\uA000-\uA48C\uA4D0-\uA4FD\uA500-\uA60C\uA610-\uA61F\uA62A\uA62B\uA640-\uA66E\uA67F-\uA697\uA6A0-\uA6EF\uA717-\uA71F\uA722-\uA788\uA78B-\uA78E\uA790-\uA793\uA7A0-\uA7AA\uA7F8-\uA801\uA803-\uA805\uA807-\uA80A\uA80C-\uA822\uA840-\uA873\uA882-\uA8B3\uA8F2-\uA8F7\uA8FB\uA90A-\uA925\uA930-\uA946\uA960-\uA97C\uA984-\uA9B2\uA9CF\uAA00-\uAA28\uAA40-\uAA42\uAA44-\uAA4B\uAA60-\uAA76\uAA7A\uAA80-\uAAAF\uAAB1\uAAB5\uAAB6\uAAB9-\uAABD\uAAC0\uAAC2\uAADB-\uAADD\uAAE0-\uAAEA\uAAF2-\uAAF4\uAB01-\uAB06\uAB09-\uAB0E\uAB11-\uAB16\uAB20-\uAB26\uAB28-\uAB2E\uABC0-\uABE2\uAC00-\uD7A3\uD7B0-\uD7C6\uD7CB-\uD7FB\uF900-\uFA6D\uFA70-\uFAD9\uFB00-\uFB06\uFB13-\uFB17\uFB1D\uFB1F-\uFB28\uFB2A-\uFB36\uFB38-\uFB3C\uFB3E\uFB40\uFB41\uFB43\uFB44\uFB46-\uFBB1\uFBD3-\uFD3D\uFD50-\uFD8F\uFD92-\uFDC7\uFDF0-\uFDFB\uFE70-\uFE74\uFE76-\uFEFC\uFF21-\uFF3A\uFF41-\uFF5A\uFF66-\uFFBE\uFFC2-\uFFC7\uFFCA-\uFFCF\uFFD2-\uFFD7\uFFDA-\uFFDC]'),
        NonAsciiIdentifierPart: new RegExp('[\xAA\xB5\xBA\xC0-\xD6\xD8-\xF6\xF8-\u02C1\u02C6-\u02D1\u02E0-\u02E4\u02EC\u02EE\u0300-\u0374\u0376\u0377\u037A-\u037D\u0386\u0388-\u038A\u038C\u038E-\u03A1\u03A3-\u03F5\u03F7-\u0481\u0483-\u0487\u048A-\u0527\u0531-\u0556\u0559\u0561-\u0587\u0591-\u05BD\u05BF\u05C1\u05C2\u05C4\u05C5\u05C7\u05D0-\u05EA\u05F0-\u05F2\u0610-\u061A\u0620-\u0669\u066E-\u06D3\u06D5-\u06DC\u06DF-\u06E8\u06EA-\u06FC\u06FF\u0710-\u074A\u074D-\u07B1\u07C0-\u07F5\u07FA\u0800-\u082D\u0840-\u085B\u08A0\u08A2-\u08AC\u08E4-\u08FE\u0900-\u0963\u0966-\u096F\u0971-\u0977\u0979-\u097F\u0981-\u0983\u0985-\u098C\u098F\u0990\u0993-\u09A8\u09AA-\u09B0\u09B2\u09B6-\u09B9\u09BC-\u09C4\u09C7\u09C8\u09CB-\u09CE\u09D7\u09DC\u09DD\u09DF-\u09E3\u09E6-\u09F1\u0A01-\u0A03\u0A05-\u0A0A\u0A0F\u0A10\u0A13-\u0A28\u0A2A-\u0A30\u0A32\u0A33\u0A35\u0A36\u0A38\u0A39\u0A3C\u0A3E-\u0A42\u0A47\u0A48\u0A4B-\u0A4D\u0A51\u0A59-\u0A5C\u0A5E\u0A66-\u0A75\u0A81-\u0A83\u0A85-\u0A8D\u0A8F-\u0A91\u0A93-\u0AA8\u0AAA-\u0AB0\u0AB2\u0AB3\u0AB5-\u0AB9\u0ABC-\u0AC5\u0AC7-\u0AC9\u0ACB-\u0ACD\u0AD0\u0AE0-\u0AE3\u0AE6-\u0AEF\u0B01-\u0B03\u0B05-\u0B0C\u0B0F\u0B10\u0B13-\u0B28\u0B2A-\u0B30\u0B32\u0B33\u0B35-\u0B39\u0B3C-\u0B44\u0B47\u0B48\u0B4B-\u0B4D\u0B56\u0B57\u0B5C\u0B5D\u0B5F-\u0B63\u0B66-\u0B6F\u0B71\u0B82\u0B83\u0B85-\u0B8A\u0B8E-\u0B90\u0B92-\u0B95\u0B99\u0B9A\u0B9C\u0B9E\u0B9F\u0BA3\u0BA4\u0BA8-\u0BAA\u0BAE-\u0BB9\u0BBE-\u0BC2\u0BC6-\u0BC8\u0BCA-\u0BCD\u0BD0\u0BD7\u0BE6-\u0BEF\u0C01-\u0C03\u0C05-\u0C0C\u0C0E-\u0C10\u0C12-\u0C28\u0C2A-\u0C33\u0C35-\u0C39\u0C3D-\u0C44\u0C46-\u0C48\u0C4A-\u0C4D\u0C55\u0C56\u0C58\u0C59\u0C60-\u0C63\u0C66-\u0C6F\u0C82\u0C83\u0C85-\u0C8C\u0C8E-\u0C90\u0C92-\u0CA8\u0CAA-\u0CB3\u0CB5-\u0CB9\u0CBC-\u0CC4\u0CC6-\u0CC8\u0CCA-\u0CCD\u0CD5\u0CD6\u0CDE\u0CE0-\u0CE3\u0CE6-\u0CEF\u0CF1\u0CF2\u0D02\u0D03\u0D05-\u0D0C\u0D0E-\u0D10\u0D12-\u0D3A\u0D3D-\u0D44\u0D46-\u0D48\u0D4A-\u0D4E\u0D57\u0D60-\u0D63\u0D66-\u0D6F\u0D7A-\u0D7F\u0D82\u0D83\u0D85-\u0D96\u0D9A-\u0DB1\u0DB3-\u0DBB\u0DBD\u0DC0-\u0DC6\u0DCA\u0DCF-\u0DD4\u0DD6\u0DD8-\u0DDF\u0DF2\u0DF3\u0E01-\u0E3A\u0E40-\u0E4E\u0E50-\u0E59\u0E81\u0E82\u0E84\u0E87\u0E88\u0E8A\u0E8D\u0E94-\u0E97\u0E99-\u0E9F\u0EA1-\u0EA3\u0EA5\u0EA7\u0EAA\u0EAB\u0EAD-\u0EB9\u0EBB-\u0EBD\u0EC0-\u0EC4\u0EC6\u0EC8-\u0ECD\u0ED0-\u0ED9\u0EDC-\u0EDF\u0F00\u0F18\u0F19\u0F20-\u0F29\u0F35\u0F37\u0F39\u0F3E-\u0F47\u0F49-\u0F6C\u0F71-\u0F84\u0F86-\u0F97\u0F99-\u0FBC\u0FC6\u1000-\u1049\u1050-\u109D\u10A0-\u10C5\u10C7\u10CD\u10D0-\u10FA\u10FC-\u1248\u124A-\u124D\u1250-\u1256\u1258\u125A-\u125D\u1260-\u1288\u128A-\u128D\u1290-\u12B0\u12B2-\u12B5\u12B8-\u12BE\u12C0\u12C2-\u12C5\u12C8-\u12D6\u12D8-\u1310\u1312-\u1315\u1318-\u135A\u135D-\u135F\u1380-\u138F\u13A0-\u13F4\u1401-\u166C\u166F-\u167F\u1681-\u169A\u16A0-\u16EA\u16EE-\u16F0\u1700-\u170C\u170E-\u1714\u1720-\u1734\u1740-\u1753\u1760-\u176C\u176E-\u1770\u1772\u1773\u1780-\u17D3\u17D7\u17DC\u17DD\u17E0-\u17E9\u180B-\u180D\u1810-\u1819\u1820-\u1877\u1880-\u18AA\u18B0-\u18F5\u1900-\u191C\u1920-\u192B\u1930-\u193B\u1946-\u196D\u1970-\u1974\u1980-\u19AB\u19B0-\u19C9\u19D0-\u19D9\u1A00-\u1A1B\u1A20-\u1A5E\u1A60-\u1A7C\u1A7F-\u1A89\u1A90-\u1A99\u1AA7\u1B00-\u1B4B\u1B50-\u1B59\u1B6B-\u1B73\u1B80-\u1BF3\u1C00-\u1C37\u1C40-\u1C49\u1C4D-\u1C7D\u1CD0-\u1CD2\u1CD4-\u1CF6\u1D00-\u1DE6\u1DFC-\u1F15\u1F18-\u1F1D\u1F20-\u1F45\u1F48-\u1F4D\u1F50-\u1F57\u1F59\u1F5B\u1F5D\u1F5F-\u1F7D\u1F80-\u1FB4\u1FB6-\u1FBC\u1FBE\u1FC2-\u1FC4\u1FC6-\u1FCC\u1FD0-\u1FD3\u1FD6-\u1FDB\u1FE0-\u1FEC\u1FF2-\u1FF4\u1FF6-\u1FFC\u200C\u200D\u203F\u2040\u2054\u2071\u207F\u2090-\u209C\u20D0-\u20DC\u20E1\u20E5-\u20F0\u2102\u2107\u210A-\u2113\u2115\u2119-\u211D\u2124\u2126\u2128\u212A-\u212D\u212F-\u2139\u213C-\u213F\u2145-\u2149\u214E\u2160-\u2188\u2C00-\u2C2E\u2C30-\u2C5E\u2C60-\u2CE4\u2CEB-\u2CF3\u2D00-\u2D25\u2D27\u2D2D\u2D30-\u2D67\u2D6F\u2D7F-\u2D96\u2DA0-\u2DA6\u2DA8-\u2DAE\u2DB0-\u2DB6\u2DB8-\u2DBE\u2DC0-\u2DC6\u2DC8-\u2DCE\u2DD0-\u2DD6\u2DD8-\u2DDE\u2DE0-\u2DFF\u2E2F\u3005-\u3007\u3021-\u302F\u3031-\u3035\u3038-\u303C\u3041-\u3096\u3099\u309A\u309D-\u309F\u30A1-\u30FA\u30FC-\u30FF\u3105-\u312D\u3131-\u318E\u31A0-\u31BA\u31F0-\u31FF\u3400-\u4DB5\u4E00-\u9FCC\uA000-\uA48C\uA4D0-\uA4FD\uA500-\uA60C\uA610-\uA62B\uA640-\uA66F\uA674-\uA67D\uA67F-\uA697\uA69F-\uA6F1\uA717-\uA71F\uA722-\uA788\uA78B-\uA78E\uA790-\uA793\uA7A0-\uA7AA\uA7F8-\uA827\uA840-\uA873\uA880-\uA8C4\uA8D0-\uA8D9\uA8E0-\uA8F7\uA8FB\uA900-\uA92D\uA930-\uA953\uA960-\uA97C\uA980-\uA9C0\uA9CF-\uA9D9\uAA00-\uAA36\uAA40-\uAA4D\uAA50-\uAA59\uAA60-\uAA76\uAA7A\uAA7B\uAA80-\uAAC2\uAADB-\uAADD\uAAE0-\uAAEF\uAAF2-\uAAF6\uAB01-\uAB06\uAB09-\uAB0E\uAB11-\uAB16\uAB20-\uAB26\uAB28-\uAB2E\uABC0-\uABEA\uABEC\uABED\uABF0-\uABF9\uAC00-\uD7A3\uD7B0-\uD7C6\uD7CB-\uD7FB\uF900-\uFA6D\uFA70-\uFAD9\uFB00-\uFB06\uFB13-\uFB17\uFB1D-\uFB28\uFB2A-\uFB36\uFB38-\uFB3C\uFB3E\uFB40\uFB41\uFB43\uFB44\uFB46-\uFBB1\uFBD3-\uFD3D\uFD50-\uFD8F\uFD92-\uFDC7\uFDF0-\uFDFB\uFE00-\uFE0F\uFE20-\uFE26\uFE33\uFE34\uFE4D-\uFE4F\uFE70-\uFE74\uFE76-\uFEFC\uFF10-\uFF19\uFF21-\uFF3A\uFF3F\uFF41-\uFF5A\uFF66-\uFFBE\uFFC2-\uFFC7\uFFCA-\uFFCF\uFFD2-\uFFD7\uFFDA-\uFFDC]')
    };

    // Ensure the condition is true, otherwise throw an error.
    // This is only to have a better contract semantic, i.e. another safety net
    // to catch a logic error. The condition shall be fulfilled in normal case.
    // Do NOT use this to enforce a certain condition on any user input.

    function assert(condition, message) {
        /* istanbul ignore if */
        if (!condition) {
            throw new Error('ASSERT: ' + message);
        }
    }

    function isDecimalDigit(ch) {
        return (ch >= 48 && ch <= 57);   // 0..9
    }

    function isHexDigit(ch) {
        return '0123456789abcdefABCDEF'.indexOf(ch) >= 0;
    }

    function isOctalDigit(ch) {
        return '01234567'.indexOf(ch) >= 0;
    }


    // 7.2 White Space

    function isWhiteSpace(ch) {
        return (ch === 0x20) || (ch === 0x09) || (ch === 0x0B) || (ch === 0x0C) || (ch === 0xA0) ||
            (ch >= 0x1680 && [0x1680, 0x180E, 0x2000, 0x2001, 0x2002, 0x2003, 0x2004, 0x2005, 0x2006, 0x2007, 0x2008, 0x2009, 0x200A, 0x202F, 0x205F, 0x3000, 0xFEFF].indexOf(ch) >= 0);
    }

    // 7.3 Line Terminators

    function isLineTerminator(ch) {
        return (ch === 0x0A) || (ch === 0x0D) || (ch === 0x2028) || (ch === 0x2029);
    }

    // 7.6 Identifier Names and Identifiers

    function isIdentifierStart(ch) {
        return (ch == 0x40) ||  (ch === 0x24) || (ch === 0x5F) ||  // $ (dollar) and _ (underscore)
            (ch >= 0x41 && ch <= 0x5A) ||         // A..Z
            (ch >= 0x61 && ch <= 0x7A) ||         // a..z
            (ch === 0x5C) ||                      // \ (backslash)
            ((ch >= 0x80) && Regex.NonAsciiIdentifierStart.test(String.fromCharCode(ch)));
    }

    function isIdentifierPart(ch) {
        return (ch === 0x24) || (ch === 0x5F) ||  // $ (dollar) and _ (underscore)
            (ch >= 0x41 && ch <= 0x5A) ||         // A..Z
            (ch >= 0x61 && ch <= 0x7A) ||         // a..z
            (ch >= 0x30 && ch <= 0x39) ||         // 0..9
            (ch === 0x5C) ||                      // \ (backslash)
            ((ch >= 0x80) && Regex.NonAsciiIdentifierPart.test(String.fromCharCode(ch)));
    }

    // 7.6.1.2 Future Reserved Words

    function isFutureReservedWord(id) {
        switch (id) {
        case 'class':
        case 'enum':
        case 'export':
        case 'extends':
        case 'import':
        case 'super':
            return true;
        default:
            return false;
        }
    }

    function isStrictModeReservedWord(id) {
        switch (id) {
        case 'implements':
        case 'interface':
        case 'package':
        case 'private':
        case 'protected':
        case 'public':
        case 'static':
        case 'yield':
        case 'let':
            return true;
        default:
            return false;
        }
    }

    function isRestrictedWord(id) {
        return id === 'eval' || id === 'arguments';
    }

    // 7.6.1.1 Keywords

    function isKeyword(id) {
        if (strict && isStrictModeReservedWord(id)) {
            return true;
        }

        // 'const' is specialized as Keyword in V8.
        // 'yield' and 'let' are for compatiblity with SpiderMonkey and ES.next.
        // Some others are from future reserved words.

        switch (id.length) {
        case 2:
            return (id === 'if') || (id === 'in') || (id === 'do');
        case 3:
            return (id === 'var') || (id === 'for') || (id === 'new') ||
                (id === 'try') || (id === 'let');
        case 4:
            return (id === 'this') || (id === 'else') || (id === 'case') ||
                (id === 'void') || (id === 'with') || (id === 'enum');
        case 5:
            return (id === 'while') || (id === 'break') || (id === 'catch') ||
                (id === 'throw') || (id === 'const') || (id === 'yield') ||
                (id === 'class') || (id === 'super');
        case 6:
            return (id === 'return') || (id === 'typeof') || (id === 'delete') ||
                (id === 'switch') || (id === 'export') || (id === 'import');
        case 7:
            return (id === 'default') || (id === 'finally') || (id === 'extends');
        case 8:
            return (id === 'function') || (id === 'continue') || (id === 'debugger');
        case 10:
            return (id === 'instanceof');
        default:
            return false;
        }
    }

    // 7.4 Comments

    function addComment(type, value, start, end, loc) {
        var comment, attacher;

        assert(typeof start === 'number', 'Comment must have valid position');

        // Because the way the actual token is scanned, often the comments
        // (if any) are skipped twice during the lexical analysis.
        // Thus, we need to skip adding a comment if the comment array already
        // handled it.
        if (state.lastCommentStart >= start) {
            return;
        }
        state.lastCommentStart = start;

        comment = {
            type: type,
            value: value
        };
        if (extra.range) {
            comment.range = [start, end];
        }
        if (extra.loc) {
            comment.loc = loc;
        }
        extra.comments.push(comment);
        if (extra.attachComment) {
            extra.leadingComments.push(comment);
            extra.trailingComments.push(comment);
        }
    }

    function skipSingleLineComment(offset) {
        var start, loc, ch, comment;

        start = index - offset;
        loc = {
            start: {
                line: lineNumber,
                column: index - lineStart - offset
            }
        };

        while (index < length) {
            ch = source.charCodeAt(index);
            ++index;
            if (isLineTerminator(ch)) {
                if (extra.comments) {
                    comment = source.slice(start + offset, index - 1);
                    loc.end = {
                        line: lineNumber,
                        column: index - lineStart - 1
                    };
                    addComment('Line', comment, start, index - 1, loc);
                }
                if (ch === 13 && source.charCodeAt(index) === 10) {
                    ++index;
                }
                ++lineNumber;
                lineStart = index;
                return;
            }
        }

        if (extra.comments) {
            comment = source.slice(start + offset, index);
            loc.end = {
                line: lineNumber,
                column: index - lineStart
            };
            addComment('Line', comment, start, index, loc);
        }
    }

    function skipMultiLineComment() {
        var start, loc, ch, comment;

        if (extra.comments) {
            start = index - 2;
            loc = {
                start: {
                    line: lineNumber,
                    column: index - lineStart - 2
                }
            };
        }

        while (index < length) {
            ch = source.charCodeAt(index);
            if (isLineTerminator(ch)) {
                if (ch === 0x0D && source.charCodeAt(index + 1) === 0x0A) {
                    ++index;
                }
                ++lineNumber;
                ++index;
                lineStart = index;
                if (index >= length) {
                    throwError({}, Messages.UnexpectedToken, 'ILLEGAL');
                }
            } else if (ch === 0x2A) {
                // Block comment ends with '*/'.
                if (source.charCodeAt(index + 1) === 0x2F) {
                    ++index;
                    ++index;
                    if (extra.comments) {
                        comment = source.slice(start + 2, index - 2);
                        loc.end = {
                            line: lineNumber,
                            column: index - lineStart
                        };
                        addComment('Block', comment, start, index, loc);
                    }
                    return;
                }
                ++index;
            } else {
                ++index;
            }
        }

        throwError({}, Messages.UnexpectedToken, 'ILLEGAL');
    }

    function skipComment() {
        var ch, start;

        start = (index === 0);
        while (index < length) {
            ch = source.charCodeAt(index);

            if (isWhiteSpace(ch)) {
                ++index;
            } else if (isLineTerminator(ch)) {
                ++index;
                if (ch === 0x0D && source.charCodeAt(index) === 0x0A) {
                    ++index;
                }
                ++lineNumber;
                lineStart = index;
                start = true;
            } else if (ch === 0x2F) { // U+002F is '/'
                ch = source.charCodeAt(index + 1);
                if (ch === 0x2F) {
                    ++index;
                    ++index;
                    skipSingleLineComment(2);
                    start = true;
                } else if (ch === 0x2A) {  // U+002A is '*'
                    ++index;
                    ++index;
                    skipMultiLineComment();
                } else {
                    break;
                }
            } else if (start && ch === 0x2D) { // U+002D is '-'
                // U+003E is '>'
                if ((source.charCodeAt(index + 1) === 0x2D) && (source.charCodeAt(index + 2) === 0x3E)) {
                    // '-->' is a single-line comment
                    index += 3;
                    skipSingleLineComment(3);
                } else {
                    break;
                }
            } else if (ch === 0x3C) { // U+003C is '<'
                if (source.slice(index + 1, index + 4) === '!--') {
                    ++index; // `<`
                    ++index; // `!`
                    ++index; // `-`
                    ++index; // `-`
                    skipSingleLineComment(4);
                } else {
                    break;
                }
            } else {
                break;
            }
        }
    }

    function scanHexEscape(prefix) {
        var i, len, ch, code = 0;

        len = (prefix === 'u') ? 4 : 2;
        for (i = 0; i < len; ++i) {
            if (index < length && isHexDigit(source[index])) {
                ch = source[index++];
                code = code * 16 + '0123456789abcdef'.indexOf(ch.toLowerCase());
            } else {
                return '';
            }
        }
        return String.fromCharCode(code);
    }

    function getEscapedIdentifier() {
        var ch, id;

        ch = source.charCodeAt(index++);
        id = String.fromCharCode(ch);

        // '\u' (U+005C, U+0075) denotes an escaped character.
        if (ch === 0x5C) {
            if (source.charCodeAt(index) !== 0x75) {
                throwError({}, Messages.UnexpectedToken, 'ILLEGAL');
            }
            ++index;
            ch = scanHexEscape('u');
            if (!ch || ch === '\\' || !isIdentifierStart(ch.charCodeAt(0))) {
                throwError({}, Messages.UnexpectedToken, 'ILLEGAL');
            }
            id = ch;
        }

        while (index < length) {
            ch = source.charCodeAt(index);
            if (!isIdentifierPart(ch)) {
                break;
            }
            ++index;
            id += String.fromCharCode(ch);

            // '\u' (U+005C, U+0075) denotes an escaped character.
            if (ch === 0x5C) {
                id = id.substr(0, id.length - 1);
                if (source.charCodeAt(index) !== 0x75) {
                    throwError({}, Messages.UnexpectedToken, 'ILLEGAL');
                }
                ++index;
                ch = scanHexEscape('u');
                if (!ch || ch === '\\' || !isIdentifierPart(ch.charCodeAt(0))) {
                    throwError({}, Messages.UnexpectedToken, 'ILLEGAL');
                }
                id += ch;
            }
        }

        return id;
    }

    function getIdentifier() {
        var start, ch;

        start = index++;
        while (index < length) {
            ch = source.charCodeAt(index);
            if (ch === 0x5C) {
                // Blackslash (U+005C) marks Unicode escape sequence.
                index = start;
                return getEscapedIdentifier();
            }
            if (isIdentifierPart(ch)) {
                ++index;
            } else {
                break;
            }
        }

        return source.slice(start, index);
    }

    function scanIdentifier() {
        var start, id, type;

        start = index;

        // Backslash (U+005C) starts an escaped character.
        id = (source.charCodeAt(index) === 0x5C) ? getEscapedIdentifier() : getIdentifier();

        // There is no keyword or literal with only one character.
        // Thus, it must be an identifier.
        if (id.length === 1) {
            type = Token.Identifier;
        } else if (isKeyword(id)) {
            type = Token.Keyword;
        } else if (id === 'null') {
            type = Token.NullLiteral;
        } else if (id === 'true' || id === 'false') {
            type = Token.BooleanLiteral;
        } else {
            type = Token.Identifier;
        }

        return {
            type: type,
            value: id,
            lineNumber: lineNumber,
            lineStart: lineStart,
            start: start,
            end: index
        };
    }


    // 7.7 Punctuators

    function scanPunctuator() {
        var start = index,
            code = source.charCodeAt(index),
            code2,
            ch1 = source[index],
            ch2,
            ch3,
            ch4;

        switch (code) {

        // Check for most common single-character punctuators.
        case 0x2E:  // . dot
        case 0x28:  // ( open bracket
        case 0x29:  // ) close bracket
        case 0x3B:  // ; semicolon
        case 0x2C:  // , comma
        case 0x7B:  // { open curly brace
        case 0x7D:  // } close curly brace
        case 0x5B:  // [
        case 0x5D:  // ]
        case 0x3A:  // :
        case 0x3F:  // ?
        case 0x7E:  // ~
            ++index;
            if (extra.tokenize) {
                if (code === 0x28) {
                    extra.openParenToken = extra.tokens.length;
                } else if (code === 0x7B) {
                    extra.openCurlyToken = extra.tokens.length;
                }
            }
            return {
                type: Token.Punctuator,
                value: String.fromCharCode(code),
                lineNumber: lineNumber,
                lineStart: lineStart,
                start: start,
                end: index
            };

        default:
            code2 = source.charCodeAt(index + 1);

            // '=' (U+003D) marks an assignment or comparison operator.
            if (code2 === 0x3D) {
                switch (code) {
                case 0x2B:  // +
                case 0x2D:  // -
                case 0x2F:  // /
                case 0x3C:  // <
                case 0x3E:  // >
                case 0x5E:  // ^
                case 0x7C:  // |
                case 0x25:  // %
                case 0x26:  // &
                case 0x2A:  // *
                    index += 2;
                    return {
                        type: Token.Punctuator,
                        value: String.fromCharCode(code) + String.fromCharCode(code2),
                        lineNumber: lineNumber,
                        lineStart: lineStart,
                        start: start,
                        end: index
                    };

                case 0x21: // !
                case 0x3D: // =
                    index += 2;

                    // !== and ===
                    if (source.charCodeAt(index) === 0x3D) {
                        ++index;
                    }
                    return {
                        type: Token.Punctuator,
                        value: source.slice(start, index),
                        lineNumber: lineNumber,
                        lineStart: lineStart,
                        start: start,
                        end: index
                    };
                }
            }
        }

        // 4-character punctuator: >>>=

        ch4 = source.substr(index, 4);

        if (ch4 === '>>>=') {
            index += 4;
            return {
                type: Token.Punctuator,
                value: ch4,
                lineNumber: lineNumber,
                lineStart: lineStart,
                start: start,
                end: index
            };
        }

        // 3-character punctuators: === !== >>> <<= >>=

        ch3 = ch4.substr(0, 3);

        if (ch3 === '>>>' || ch3 === '<<=' || ch3 === '>>=') {
            index += 3;
            return {
                type: Token.Punctuator,
                value: ch3,
                lineNumber: lineNumber,
                lineStart: lineStart,
                start: start,
                end: index
            };
        }

        // Other 2-character punctuators: ++ -- << >> && ||
        ch2 = ch3.substr(0, 2);

        if ((ch1 === ch2[1] && ('+-<>&|'.indexOf(ch1) >= 0)) || ch2 === '=>') {
            index += 2;
            return {
                type: Token.Punctuator,
                value: ch2,
                lineNumber: lineNumber,
                lineStart: lineStart,
                start: start,
                end: index
            };
        }

        // 1-character punctuators: < > = ! + - * % & | ^ /
        if ('<>=!+-*%&|^/'.indexOf(ch1) >= 0) {
            ++index;
            return {
                type: Token.Punctuator,
                value: ch1,
                lineNumber: lineNumber,
                lineStart: lineStart,
                start: start,
                end: index
            };
        }

        throwError({}, Messages.UnexpectedToken, 'ILLEGAL');
    }

    // 7.8.3 Numeric Literals

    function scanHexLiteral(start) {
        var number = '';

        while (index < length) {
            if (!isHexDigit(source[index])) {
                break;
            }
            number += source[index++];
        }

        if (number.length === 0) {
            throwError({}, Messages.UnexpectedToken, 'ILLEGAL');
        }

        if (isIdentifierStart(source.charCodeAt(index))) {
            throwError({}, Messages.UnexpectedToken, 'ILLEGAL');
        }

        return {
            type: Token.NumericLiteral,
            value: parseInt('0x' + number, 16),
            lineNumber: lineNumber,
            lineStart: lineStart,
            start: start,
            end: index
        };
    }

    function scanOctalLiteral(start) {
        var number = '0' + source[index++];
        while (index < length) {
            if (!isOctalDigit(source[index])) {
                break;
            }
            number += source[index++];
        }

        if (isIdentifierStart(source.charCodeAt(index)) || isDecimalDigit(source.charCodeAt(index))) {
            throwError({}, Messages.UnexpectedToken, 'ILLEGAL');
        }

        return {
            type: Token.NumericLiteral,
            value: parseInt(number, 8),
            octal: true,
            lineNumber: lineNumber,
            lineStart: lineStart,
            start: start,
            end: index
        };
    }

    function isImplicitOctalLiteral() {
        var i, ch;

        // Implicit octal, unless there is a non-octal digit.
        // (Annex B.1.1 on Numeric Literals)
        for (i = index + 1; i < length; ++i) {
            ch = source[i];
            if (ch === '8' || ch === '9') {
                return false;
            }
            if (!isOctalDigit(ch)) {
                return true;
            }
        }

        return true;
    }

    function scanNumericLiteral() {
        var number, start, ch;

        ch = source[index];
        assert(isDecimalDigit(ch.charCodeAt(0)) || (ch === '.'),
            'Numeric literal must start with a decimal digit or a decimal point');

        start = index;
        number = '';
        if (ch !== '.') {
            number = source[index++];
            ch = source[index];

            // Hex number starts with '0x'.
            // Octal number starts with '0'.
            if (number === '0') {
                if (ch === 'x' || ch === 'X') {
                    ++index;
                    return scanHexLiteral(start);
                }
                if (isOctalDigit(ch)) {
                    if (isImplicitOctalLiteral()) {
                        return scanOctalLiteral(start);
                    }
                }
            }

            while (isDecimalDigit(source.charCodeAt(index))) {
                number += source[index++];
            }
            ch = source[index];
        }

        if (ch === '.') {
            number += source[index++];
            while (isDecimalDigit(source.charCodeAt(index))) {
                number += source[index++];
            }
            ch = source[index];
        }

        if (ch === 'e' || ch === 'E') {
            number += source[index++];

            ch = source[index];
            if (ch === '+' || ch === '-') {
                number += source[index++];
            }
            if (isDecimalDigit(source.charCodeAt(index))) {
                while (isDecimalDigit(source.charCodeAt(index))) {
                    number += source[index++];
                }
            } else {
                throwError({}, Messages.UnexpectedToken, 'ILLEGAL');
            }
        }

        if (isIdentifierStart(source.charCodeAt(index))) {
            throwError({}, Messages.UnexpectedToken, 'ILLEGAL');
        }

        return {
            type: Token.NumericLiteral,
            value: parseFloat(number),
            lineNumber: lineNumber,
            lineStart: lineStart,
            start: start,
            end: index
        };
    }

    // 7.8.4 String Literals

    function scanStringLiteral() {
        var str = '', quote, start, ch, code, unescaped, restore, octal = false, startLineNumber, startLineStart;
        startLineNumber = lineNumber;
        startLineStart = lineStart;

        quote = source[index];
        assert((quote === '\'' || quote === '"'),
            'String literal must starts with a quote');

        start = index;
        ++index;

        while (index < length) {
            ch = source[index++];

            if (ch === quote) {
                quote = '';
                break;
            } else if (ch === '\\') {
                ch = source[index++];
                if (!ch || !isLineTerminator(ch.charCodeAt(0))) {
                    switch (ch) {
                    case 'u':
                    case 'x':
                        restore = index;
                        unescaped = scanHexEscape(ch);
                        if (unescaped) {
                            str += unescaped;
                        } else {
                            index = restore;
                            str += ch;
                        }
                        break;
                    case 'n':
                        str += '\n';
                        break;
                    case 'r':
                        str += '\r';
                        break;
                    case 't':
                        str += '\t';
                        break;
                    case 'b':
                        str += '\b';
                        break;
                    case 'f':
                        str += '\f';
                        break;
                    case 'v':
                        str += '\x0B';
                        break;

                    default:
                        if (isOctalDigit(ch)) {
                            code = '01234567'.indexOf(ch);

                            // \0 is not octal escape sequence
                            if (code !== 0) {
                                octal = true;
                            }

                            if (index < length && isOctalDigit(source[index])) {
                                octal = true;
                                code = code * 8 + '01234567'.indexOf(source[index++]);

                                // 3 digits are only allowed when string starts
                                // with 0, 1, 2, 3
                                if ('0123'.indexOf(ch) >= 0 &&
                                        index < length &&
                                        isOctalDigit(source[index])) {
                                    code = code * 8 + '01234567'.indexOf(source[index++]);
                                }
                            }
                            str += String.fromCharCode(code);
                        } else {
                            str += ch;
                        }
                        break;
                    }
                } else {
                    ++lineNumber;
                    if (ch ===  '\r' && source[index] === '\n') {
                        ++index;
                    }
                    lineStart = index;
                }
            } else if (isLineTerminator(ch.charCodeAt(0))) {
                break;
            } else {
                str += ch;
            }
        }

        if (quote !== '') {
            throwError({}, Messages.UnexpectedToken, 'ILLEGAL');
        }

        return {
            type: Token.StringLiteral,
            value: str,
            octal: octal,
            startLineNumber: startLineNumber,
            startLineStart: startLineStart,
            lineNumber: lineNumber,
            lineStart: lineStart,
            start: start,
            end: index
        };
    }

    function testRegExp(pattern, flags) {
        var value;
        try {
            value = new RegExp(pattern, flags);
        } catch (e) {
            throwError({}, Messages.InvalidRegExp);
        }
        return value;
    }

    function scanRegExpBody() {
        var ch, str, classMarker, terminated, body;

        ch = source[index];
        assert(ch === '/', 'Regular expression literal must start with a slash');
        str = source[index++];

        classMarker = false;
        terminated = false;
        while (index < length) {
            ch = source[index++];
            str += ch;
            if (ch === '\\') {
                ch = source[index++];
                // ECMA-262 7.8.5
                if (isLineTerminator(ch.charCodeAt(0))) {
                    throwError({}, Messages.UnterminatedRegExp);
                }
                str += ch;
            } else if (isLineTerminator(ch.charCodeAt(0))) {
                throwError({}, Messages.UnterminatedRegExp);
            } else if (classMarker) {
                if (ch === ']') {
                    classMarker = false;
                }
            } else {
                if (ch === '/') {
                    terminated = true;
                    break;
                } else if (ch === '[') {
                    classMarker = true;
                }
            }
        }

        if (!terminated) {
            throwError({}, Messages.UnterminatedRegExp);
        }

        // Exclud    'xclud 8 ltraith a s '0'.
    ed, ndex r ch3.sub1r ch,, id.lengtent(2);
        return {
            valed, mber,
          n litalue:ndex
        };
    }

    function atedReFn, fBody() {
        var ch, srn, f,ex = restoh');
        ste = '';
    rn, f ste = '';
        while (index < length) {
            ch = source[i]dex);
            if (!isIdentifierParr(ch.charCodeAt(0))) {
                break;
         
// ~
            ++index;
             || ch === 'gth e (index < length) {
                ch = source[i]dex);
                 || ch =u= 'X') {
                    ++index;
                    restore = index;
                    ch = scanHexEscape('u');
                     |'\n') {
                    rn, f str += ch;
                        f    str +\u';     rest<re = in ++    resaped) {
                            strh = sou    res]= ch;
                        }
                    } else {
                        index = restore;
                    rn, f str'u\x0B';
                        str +\u';dex;
                    }
                    throwETolerantrror({}, Messages.UnexpectedToken, 'ILLEGAL');
                } else {
                    str +\';dex;
                    throwETolerantrror({}, Messages.UnexpectedToken, 'ILLEGAL');
                }
            } else {
            rn, f str += ch;
                str += ch;
            }
        }

        return {
            valrn, f,ber,
          n litalue:ndex
        };
    }

    function atedRefier() {
        var staed, msrn, f,eExp(patteurn valset;
      okaheanate== 'sh');
     on skipComme;pe;

        start = index;

    ed, ndexon scanRegExpBo= '';
    rn, f stion atedReFn, fBo;
            valuion testReged, .pe, valrn, f.pe, v)ment;

        if (extra.tokenize) {
            return {
                type: To', 'RegEar expresator,
                valpe, vach1,
                lineNumber: lineNumber,
                lineStart: lineStart,
                start: start,
                end: index
            };
        }

        return {
          n litaled, .ion lite+lrn, f.lingLiteral,
            valpe, vach1,
            start: start,
            end: index
        };
    }

    functcollect && Rfier() {
        postart, lr&& R,tual ttoh');
     on skipComme;ph');
    postore = index;
        loc = {
            start: {
                line: lineNumber,
                column: index - lineSfset
            }
        };

    r&& R stion atedReBo;
            loc.end = {
            line: lineNumber,
            column: index - lineSfset
        };

        /* istanbul ign ES.e if */
        iif (extra.tokenize) {
        // Popt if previoustual t,    ch/ \0likely ===igit'/='dex;
            if (extra.tokens.le > !== 0) {
            trlyToken = extra.to[if (extra.tokens.le - 1]dex);
                tra.tment.r[0ndex] post&& trlyT.    tych =ken.Punctu'(ch)) {
                    trlyT.    valch ===(!chtrlyT.    valch === '\n') {
                    if (extra.tokpop(tart);
                    }
                }
            }

        if (extra.tokpts.purn {
                ty'', 'RegEar expres'ator,
                valr&& R.lingLiteral,
            rnt.r: [postarce[index],
               :       }
         GAL');
        }

        retr&& Rh)));
    }

    function isIdentiier  trlyTd(id) {
        rettrlyT.    tych e = Token.Identite') ||
        trlyT.    tych e = To as Keywe') ||
        trlyT.    tych e = Token.BooleanLitwe') ||
        trlyT.    tych e = Token.NullLiteral;
}ents

    functiovinstS a sfier() {
        prevctedToh) {
          eckTal tto        // Us during foly a  'xclgorithm:eady
        ttps://githubxtra/mozilla/sweet.js/wiki/den ash');
    prevctedToken = extra.to[if (extra.tokens.le - 1]dex);
        iprevctedTnize) {
        // Noth  'xbefoEnsurat:hus,is so must  divipres.e) {
            retcollect && Rfiend];
        }
        prevctedT.    tych =ken.Punctu'(ch)) {
            prevctedT.    valch =]= '9') {
                retion scanPunctuatx++];
            }
            prevctedT.    valch =) '\\') {
              eckTal token = extra.to[if (extra.openParenTo- 1]dex);
                  eckTal togth &&
                      eckTal t.    tych = as Key'ogth &&
                       eckTal t.    valch =if'te') ||
                       eckTal t.    valch === 'whte') ||
                       eckTal t.    valch === 'te') ||
                       eckTal t.    valch === 'wi'\n') {
                    retcollect && Rfiend];
                }
                retion scanPunctuatx++];
            }
            prevctedT.    valch =}'0x5C) {
               Divip addin    functbonkeyth  'xmake\0littlscapnsvach1,
            // buthus,ust h // // Check urat.)) {
                if (extra.to[if (extra.openCurlyTo- 3]ogth &&
                    if (extra.to[if (extra.openCurlyTo- 3].    tych = as Key'x3E)) {
                   Anonymoust    func.
                      eckTal token = extra.to[if (extra.openCurlyTo- 4]'u');
                    !  eckTal tal()) {
                        return scanPunctuatx++];
                    }
                } e    if (extra.to[if (extra.openCurlyTo- 4]ogth &&
                    if (extra.to[if (extra.openCurlyTo- 4].    tych = as Key'x3E)) {
                   ier dt    func.
                      eckTal token = extra.to[if (extra.openCurlyTo- 5]'u');
                    !  eckTal tal()) {
                        retcollect && Rfiend];
                    }
                } else {
                    return scanPunctuatx++];
            }ch1,
            //   eckTal todes.Unteesowed// Oting f   functioch1,
            //  or alarafunctgit nular expres.)) {
                FnEar Tra.tok23'.indexOeckTal t.    v(ch1) >= 0) {
                // Ithere nular expres.)) {
                    return scanPunctuatx++];
            }ch1,
            // Ithere or alarafunc.
                    retcollect && Rfiend];
        }e) {
            retcollect && Rfiend];
        }
        prevctedT.    tych = as Key'ogt prevctedT.    va!id === 'thi{e) {
            retcollect && Rfiend];
        }
        return scanPunctuatx++];
}ents

    functiovinstBody() {
        vatoh');
     on skipComme;ph');
        if (index >= length) {
            return {
                type: ToEOFach1,
                lineNumber: lineNumber,
                lineStart: lineStart,
                stat = index,
                end: index
            };
        }

        ch = source.charCodeAt(index);

        if (isIdentifierStgit(ch)) {
            return apedIdentifier();
        }

       Verymost co: (xcludllar) ;ter.
        if (ch ==28 '+' || ch ase  '+' || ch as3B(ch)) {
            return scanPunctuatx++];
        }

          'String liteust starts wmon si     qu'=' (27)tgitdoubsi     qu'=' (22)cter.
        if (ch ==27 '+' || ch ase2(ch)) {
            return scanStringLiterx++];
         }

       Dot (.){ // UE,is  also     sta frseFing-mal p var numbhsequting  we   }

        // // Ching  wxtaped character.
        if (ch ==2E ++i) {
            ie (isDecimalDigit(source.charCodeAt(index ) '9') {
                retion scanNumericLiterend];
        }e) {
            return scanPunctuatx++];
        }

        ie (isDecimalDigit(ch)) {
            return scanNumericLiterend];
        }

        acksla/){ // U+0is  also     sta r&& R.nt;

        if (extra.toketart && ch ===F(ch)) {
            retiovinstS a sfiAL');
        }

        return scanPunctuatx++];
}ents

    functcollectpe: TBody() {
        rt, lual t, rnt.rteurn valset;
     on skipComme;pe;

        loc = {
            start: {
                line: lineNumber,
                column: index - lineSfset
            }
        };

    trlyTokeiovinstBo;
            loc.end = {
            line: lineNumber,
            column: index - lineSfset
        };

        trlyT.    t!ch e = ToEOF(ch)) {
            valuue: source.sltrlyT.var statrlyT.endment);
            extra.tokpts.purn {
                tye = Tier [trlyT.    ]ator,
                valpe, vach1,
            rnt.r: [trlyT.var statrlyT.endndex],
               :       }
         GAL');
        }

        rettal tto    }ents

    functl Rfier() {
        ual ttoh');
    trlyToke  okahean;ter.
        indetrlyT.end;
         artLineNumbetrlyT.  ++lineNumber;
        lineStartrlyT.  ++lineStart;

      okaheanatesert(typ    extra.toa!id =undefined= 'u'collectpe: TBod:eiovinstBo;
ter.
        indetrlyT.end;
         artLineNumbetrlyT.  ++lineNumber;
        lineStartrlyT.  ++lineStart;

        rettal tto    }ents

    functpeekfier() {
        postariner ch, start;

    postore = index;
     le-lber = lineNumber;
        start = lineStat;

      okaheanatesert(typ    extra.toa!id =undefined= 'u'collectpe: TBod:eiovinstBo;
er.
        indepos;
         artLineNumbe artmber;
        lineStarx = start;
}ents

    functPid posi(riner     coier() {
    == '. le-lber = ;() {
    == '.    cocode   cotart;
}ents

    functSe: soLocafunc(rt: startr ch, sC   cotariner     coier() {
    == '.    stare = Pid posi(rt: startr ch, sC   co);() {
    == '.loc.ene = Pid posi(riner     coitart;
}ents

SyntaxTreeDelega quotde) {

    nam ty'SyntaxTree',art;

    processskipCom:
    funct(nh (code) {
            rte.lhilt, ira.trailingCommx++];

            nh (.    tych Syntax.Programrker) {
                nh (.ed, .ins.le > !== 0) {
                    return;
                }
        }
dex;
            if (extra.trailingCommeins.le > !== 0) {
                if (extra.trailingComm[0]ment.r[0nd>= nh (.ent.r[1] '/') {
                 ra.trailingCommoken = extra.trailingCommx+                    if (extra.trailingCommoke[]AL');
                } else {
                if (extra.trailingCommeins.le ode =se;
                }
            } else {
                if (exbottomRighmmenckeins.le > !ogth &&
                    if (exbottomRighmmenck[if (exbottomRighmmenckeins.le - 1]xtra.trailingCommogth &&
                    if (exbottomRighmmenck[if (exbottomRighmmenckeins.le - 1]xtra.trailingComm[0]ment.r[0nd>= nh (.ent.r[1] '/') {
                 ra.trailingCommoken = exbottomRighmmenck[if (exbottomRighmmenckeins.le - 1]xtra.trailingComm;ak;

                  leteen = exbottomRighmmenck[if (exbottomRighmmenckeins.le - 1]xtra.trailingComm;ak;

                }
        }
dex;
            eFinghing sencke++];
            whiif (exbottomRighmmenckeins.le > !ogten = exbottomRighmmenck[if (exbottomRighmmenckeins.le - 1]xent.r[0nd>= nh (.ent.r[0] '/') {
            rte.lhiltoken = exbottomRighmmenckkpop(tart);
        }
dex;
            rte.lhilt== 0) {
                rte.lhilt.ud    'lingCommogt rte.lhilt.ud    'lingComm[rte.lhilt.ud    'lingCommeins.le - 1]xent.r[1] <= nh (.ent.r[0] '/') {
                nh (.ud    'lingCommo= rte.lhilt.ud    'lingComm;ak;

                  leteerte.lhilt.ud    'lingComm;ak;

                }
            } else n = exud    'lingCommeins.le > !ogten = exud    'lingComm[n = exud    'lingCommeins.le - 1]xent.r[1] <= nh (.ent.r[0] '/') {
            nh (.ud    'lingCommo= n = exud    'lingComm;ak;

            n = exud    'lingCommoke[]AL');
             }

            tra.trailingComm '/') {
            nh (. ra.trailingCommoketra.trailingComm;ak;

            }

        if (exbottomRighmmenckkpts.pnde(code);
    },art;

    3D) E   e    funct(nh (r ch, sTal tal()) {
        lse n = exent.r '/') {
            nh (.ent.roke[ch, sTal t.ice(start, iex++];
            }
            n = exuoc '/') {
            nh (.u   loe = Se: soLocafunc((2);
                    sTal t.ice(startLineNumb=tr +defined ?      sTal t. artLineNum:     sTal t.ice(startLineNu,(2);
                    sTal t.ice(s -e if (sTal t.ice(startlineSta=tr +defined ?      sTal t. artlineSt:     sTal t.ice(startlineSndex),
                er: lineNumber,
                mn: index - lineStart
            tx++];
            == '.postProcesspnde(code);
        }
dex;
            if (exattachlingCom(0))) {
               '.processskipCompnde(code);
        }
) {
            retnde(ode);
    },art;

    postProcess:
    funct(nh (code) {
            if (exue: so '/') {
            nh (.u  xue: soo= n = exue: soode);
        }
) {
            retnde(ode);
    },art;

    createArrayEar expres:
    funct(elegComm '/') {
            return {
                tySyntax.ArrayEar expresndex,
             legComm:  legCommndex
            };
     ,art;

    createAan assignEar expres:
    funct(son operar ift, righm '/') {
            return {
                tySyntax.Aan assignEar expresndex,
            son oper: son operdex],
             efStarift,ch1,
            righm: righmndex
            };
     ,art;

    createBinaryEar expres:
    funct(son operar ift, righm '/') {
            u   typ(son opertych =||=(!chson opertych =&&= 'u'Syntax.LogicalEar expres ault:
                    Syntax.BinaryEar expresndex;
            return {
                type: type,
            son oper: son operdex],
             efStarift,ch1,
            righm: righmndex
            };
     ,art;

    createBlockStatepCom:
    funct(ed,  '/') {
            return {
                tySyntax.BlockStatepCom,ch1,
            ed, aled, ndex
            };
     ,art;

    createB   bStatepCom:
    funct(label '/') {
            return {
                tySyntax.B   bStatepComdex],
             abel:  abelndex
            };
     ,art;

    createCallEar expres:
    funct(callee, argm '/') {
            return {
                tySyntax.CallEar expresmber,
             allee:  alleember,
            'argugComm': argmndex
            };
     ,art;

    createCatchClause:
    funct(paramtaed,  '/') {
            return {
                tySyntax.CatchClausember,
            param: param,ch1,
            ed, aled, ndex
            };
     ,art;

    createCond posialEar expres:
    funct(ion r   nape set, al(patate '/') {
            return {
                tySyntax.Cond posialEar expres,ch1,
            ion : ion mber,
              nape set:   nape set,ber,
            al(patate: al(patatendex
            };
     ,art;

    createContinueStatepCom:
    funct(label '/') {
            return {
                tySyntax.ContinueStatepComdex],
             abel:  abelndex
            };
     ,art;

    createDebuggtifietepCom:
    funct( '/') {
            return {
                tySyntax.DebuggtifietepComndex
            };
     ,art;

    createDoW   wStatepCom:
    funct(ed, , ion  '/') {
            return {
                tySyntax.DoW   wStatepCom,ch1,
            ed, aled, ,ch1,
            ion : ion ndex
            };
     ,art;

    createEmptyfietepCom:
    funct( '/') {
            return {
                tySyntax.EmptyfietepComndex
            };
     ,art;

    createEar expresfietepCom:
    funct(lar expres '/') {
            return {
                tySyntax.Ear expresfietepComndex,
             ar expres:
 ar expresndex
            };
     ,art;

    createFoifietepCom:
    funct(init, ion , upda quoed,  '/') {
            return {
                tySyntax.FoifietepCom,nce.
              istat it,ch1,
            ion : ion mber,
            upda q: upda quch1,
            ed, aled, ndex
            };
     ,art;

    createForIsfietepCom:
    funct( ift, righmuoed,  '/') {
            return {
                tySyntax.FoiIsfietepComndex,
             efStarift,ch1,
            righm: righm,ch1,
            ed, aled, ,ch1,
            each:er = fndex
            };
     ,art;

    createF   funcD alarafunc:
    funct(id, params,     defsuoed,  '/') {
            return {
                tySyntax.F   funcD alarafunc,nce.
             dalue: id,
            params: params,
                    defs:     defsuch1,
            ed, aled, ,ch1,
            ron : == ',ch1,
            genn oper: l = fadex,
             ar expres:
r = fndex
            };
     ,art;

    createF   funcEar expres:
    funct(id, params,     defsuoed,  '/') {
            return {
                tySyntax.F   funcEar expres,ch1,
             dalue: id,
            params: params,
                    defs:     defsuch1,
            ed, aled, ,ch1,
            ron : == ',ch1,
            genn oper: l = fadex,
             ar expres:
r = fndex
            };
     ,art;

    createapedIdenti:
    funct(name '/') {
            return {
                tySyntax.apedIdentiadex,
            nam tynam ndex
            };
     ,art;

    createaffietepCom:
    funct(ion r   nape set, al(patate '/') {
            return {
                tySyntax.affietepCom,ch1,
            ion : ion mber,
              nape set:   nape set,ber,
            al(patate: al(patatendex
            };
     ,art;

    createLabeledStatepCom:
    funct(labeluoed,  '/') {
            return {
                tySyntax.LabeledStatepComdex],
             abel:  abeluch1,
            ed, aled, ndex
            };
     ,art;

    createL n lital    funct(ial tal()) {
            return {
                tySyntax.LingLiteral,
                valtrlyT.    vach1,
            rnw:uue: source.sltrlyT.var statrlyT.endmndex
            };
     ,art;

    createMeneNuEar expres:
    funct(accesserarobject, propert  '/') {
            return {
                tySyntax.MeneNuEar expresmber,
              mputed: accesser (ch ===type,
            sbject:robject, id,
            propert : propert ndex
            };
     ,art;

    createNewEar expres:
    funct(callee, argm '/') {
            return {
                tySyntax.NewEar expresmber,
             allee:  alleember,
            'argugComm': argmndex
            };
     ,art;

    createObjectEar expres:
    funct(propertiem '/') {
            return {
                tySyntax.ObjectEar expres, id,
            properties: propertiesndex
            };
     ,art;

    createPostfixEar expres:
    funct(son operarargugCom '/') {
            return {
                tySyntax.Upda qEar expresndex,
            son oper: son operdex],
            argugCom: argugCom, id,
            prefix:
r = fndex
            };
     ,art;

    createProgram:
    funct(ed,  '/') {
            return {
                tySyntax.Programuch1,
            ed, aled, ndex
            };
     ,art;

    createPropert :     funct(kind, keyteurn v '/') {
            return {
                tySyntax.Propert uch1,
            key: keyttor,
                valpe, vach1,
            kind: kindndex
            };
     ,art;

    createR   reStatepCom:
    funct(argugCom '/') {
            return {
                tySyntax.R   reStatepComdex],
            argugCom: argugComndex
            };
     ,art;

    createSpe sequEar expres:
    funct(ear expresm '/') {
            return {
                tySyntax.Spe sequEar expresadex,
             ar express:
 ar expressndex
            };
     ,art;

    createS   swCase:
    funct(ion r   nape set '/') {
            return {
                tySyntax.S   swCase,ch1,
            ion : ion mber,
              nape set:   nape setndex
            };
     ,art;

    createS   swStatepCom:
    funct(discrinteret,     s '/') {
            return {
                tySyntax.S   swStatepComdex],
            discrinteret: discrinteret,// !
                s:     sndex
            };
     ,art;

    createThisEar expres:
    funct( '/') {
            return {
                tySyntax.ThisEar expresndex
            };
     ,art;

    createThrowStatepCom:
    funct(argugCom '/') {
            return {
                tySyntax.ThrowStatepComdex],
            argugCom: argugComndex
            };
     ,art;

    createTryfietepCom:
    funct(block, guardedHandlers, handlers, finalizMarker) {
            return {
                tySyntax.TryfietepComuch1,
            elock: elock,ch1,
            guardedHandlers: guardedHandlers,ch1,
            handlers: handlers,ch1,
            finalizMa: finalizMandex
            };
     ,art;

    createUnaryEar expres:
    funct(son operarargugCom '/') {
            son opertych =++=(!chson opertych =--= '9') {
                ret/') {
                    tySyntax.Upda qEar expresndex,
                son oper: son operdex],
                argugCom: argugCom, id,
                prefix:
r = ak;

             ode);
        }
) {
            return {
                tySyntax.UnaryEar expresndex,
            son oper: son operdex],
            argugCom: argugCom, id,
            prefix:
r = ak;

            };
     ,art;

    createVariableD alarafunc:
    funct(r alarafuncs, kindrker) {
            return {
                tySyntax.VariableD alarafunc,
                  alarafuncs:   alarafuncsach1,
            kind: kindndex
            };
     ,art;

    createVariableD alarafor:
    funct(id, t itrker) {
            return {
                tySyntax.VariableD alaraferdex],
             dalue: id,
              istat itndex
            };
     ,art;

    createW   wStatepCom:
    funct(ion r ed,  '/') {
            return {
                tySyntax.W   wStatepCom,ch1,
            ion : ion mber,
            ed, aled, ndex
            };
     ,art;

    createWitwStatepCom:
    funct(object, ed,  '/') {
            return {
                tySyntax.WitwStatepComtype,
            sbject:robject, id,
            ed, aled, ndex
            };
     
        };

// R   return     ess there i le-ltineTerminxbefoEnsurg  wxtatrlyT.ents

    functpeek (isLineTerminaier() {
        postariner ch, s, found;
rt;

    postore = index;
     le-lber = lineNumber;
        start = lineStat;

     on skipComme;pe;

    foundlber = lineNua!id r = ;() {
        indepos;
         artLineNumbe artmber;
        lineStarx = start;

        retfound;
 };
    }

   Throwe nulacepfunc   }

    functi   throwErual t, m}, MesFormastart) {
        erowE, id,
        argm = Array.proto    urce.s. all(argugComstr(0, id,
        msg = m}, MesFormas.replace((2);
            /%(\d)/g,ch1,
            f   funct(wholetart, i '/') {
                    assee (indeargmeins.le, '{}, Mes refersequtral mbe in rnt.re('u');
                    retirgsurce[i]dex);
            }
) {
        ndex);

        ert(typtrlyT.  ++lineNutych =var nu= '9') {
        erowE loe = hrowEr' (is = '0trlyT.  ++lineNut+ ': = '0msgment);
         rowE.    indetrlyT.sineStat;

         rowE. artLineNumbetrlyT.  ++lineNumber;
         rowE.    cocodtal t.ice(s -e    lineStdex 
            } else {
        erowE loe = hrowEr' (is = '0  ++lineNut+ ': = '0msgment);
         rowE.    indee = index;
         rowE. artLineNumbe  ++lineNumber;
         rowE.    cocodmn: index - lineStdex 
         ex);

     rowE.descripfunc = msg;  }

        t  rowE   };
    }

    functi   throwETolerantrier() {
    =   try {
        i   throwE.apply(== ', argugComflags);
        } catch (e) {
            if (ex rowEm '/') {
            if (ex rowEmkpts.pe);   }
            } else {
                t  true;
            }
               }

   Throwe nulacepfunc because o  essatrlyT.ents

    funct    tges.Unexpe(ial tal()) {
        trlyT.    t=ch e = ToEOF(ch)) {
        i   throwErual t, {}, Messages.UnexpeEOStx++];
        }

        trlyT.    tych e = TokeanNumericLit(ch)) {
        i   throwErual t, {}, Messages.UnexpelineNutx++];
        }

        trlyT.    tych e = ToscanStringLit(ch)) {
        i   throwErual t, {}, Messages.UnexpescanSttx++];
        }

        trlyT.    tych e = ToapedIdenti(ch)) {
        i   throwErual t, {}, Messages.UnexpeapedIdenti(x++];
        }

        trlyT.    tych e = To as Key ++i) {
            ieFutureReservedWord trlyT.    vt(0))) {
                throwErual t, {}, Messages.UnexpeReservedgExp);
            } else hen ctngth &Sen ctModeReservedWord trlyT.    vt(0))) {
                throwETolerantrual t, {}, MessaSen ctReservedWord('u');
                return;
        })) {
        i   throwErual t, {}, Messages.UnexpectedToktrlyT.    vtend];
        }

       ken.BooleanLit, ken.NullLit,tgitscanPunctu.
        i   throwErual t, {}, Messages.UnexpectedToktrlyT.    vtend];
    }

   E.Unexsurg  wxtatrlyT  //m } caing specdentd pcanPunctu.
    // If0 is,e nulacepfunc willmbe i   tT.ents

    functs.Unex(urn v '/') {
        ual tmbe  Rfiend];
        trlyT.    t!ch e = ToscanPunctu(!chtrlyT.    va!ch urn v '/') {
            tges.Unexpe(ial ta;   }
              }

   E.Unexsurg  wxtatrlyT  //m } caing specdentd kas Key.
    // If0 is,e nulacepfunc willmbe i   tT.ents

    functs.Unex as Key(kas Key ++i) {
        ual tmbe  Rfiend];
        trlyT.    t!ch e = To as Keywe'htrlyT.    va!ch kas Key ++i) {
            tges.Unexpe(ial ta;   }
              }

   R   return     ess  wxtatrlyT m } cesaing specdentd pcanPunctu.
nts

    functm } c(urn v '/') {
        ret  okahean.    tych e = ToscanPunctu(gt r okahean.    valch urn value;
    }

   R   return     ess  wxtatrlyT m } cesaing specdentd kas Key
nts

    functm } c as Key(kas Key ++i) {
        ret  okahean.    tych e = To as Keywgt r okahean.    valch kas Keyalue;
    }

   R   return     ess  wxtatrlyT ere nuaan assign son oper
nts

    functm } cAan asaier() {
        opdex);

          okahean.    t!ch e = ToscanPunctu '/') {
            retr = false;
    })) {
    opoke  okahean.var value;
        retopokch =='te') ||
        opokch =*='te') ||
        opokch =/='te') ||
        opokch =%='te') ||
        opokch =+='te') ||
        opokch =-='te') ||
        opokch =<<='te') ||
        opokch =>>='te') ||
        opokch =>>>='te') ||
        opokch =&='te') ||
        opokch =^='te') ||
        opokch =|='x++];
}ents

    functconsumeSemicoloTBody() {
        riner oldI   indee = ir oldtartLineNumber = lineNu str,
         ldtartLineStart = lineSr oldt okaheanate  okahean;t  }

       C } caing verymost co     cfirn : immediately a semicoloTu'=' (3B)cter.
        h = source.charCodeAt(in| ch as3Bwe'hm } c(';wi'\n') {
        l Rfiend];
            return;
        }

     le-lber = lineNumber;
     on skipComme;pe;

          = lineNua!id r =  ++i) {
            indeoldI   i;art,
            lineNundeoldL ++lineNumber;
            lineStar ldtartLineSmber;
          okaheanateoldt okaheanend];
            return;
        }

          okahean.    t!ch e = ToEOFwgt !m } c('}') ++i) {
            tges.Unexpe(  okaheana;   }
              }

   R   return     providedular expressis LeftHandSidqEar expres   }

    functioLeftHandSidq(ear  ++i) {
        retear .    tych Syntax.ken.Identite'tear .    tych Syntax.MeneNuEar expresalue;
    }

   11.1.4 Array Initialiser
nts

    functue: pArrayInitialiserBody() {
         legCommoke[]r ch, sTal tte');

        sTrlyToke  okahean;ter.
    s.Unex(=== ndex;

        whi!m } c(']') ++i) {
            m } c(',wi'\n') {
            l Rfiend];
             legCommkpts.pnull);   }
            } else {
             legCommkpts.pue: pAan assignEar expres()x++]);

                !m } c(']') ++i) {
        er.
    s.Unex(=,EGAL');
                }
         urn;
        }

      Rfieni) {
        retdelega q.3D) E  (delega q.createArrayEar expres(elegComm r ch, sTal taalue;
    }

   11.1.5 Object Initialiser
nts

    functue: pPropert F   func(paramtafirn ier() {
        previousSen cttaed, msch, sTal tte');

    previousSen ctndex ricStart;
        sTrlyToke  okahean;ter.
    ed, ndeue: pF   funcSe: soElegCommme;pe;

        firn '\r' en ctngth &Re en ctedWord param[0]mname (ch)) {
        i   throwETolerantrfirn , {}, MessaSen ctParamier iend];
        }
    sen ctndepreviousSen ct;i) {
        retdelega q.3D) E  (delega q.createF   funcEar expres(== ', paramta[]r ed,  r ch, sTal taalue;
    }

    functue: pObjectPropert Keyfier() {
        ual tr ch, sTal tte');

        sTrlyToke  okahean;ter.
    ual tmbe  Rfien  }

       Note: This
    functio  alled are oing.tue: pObjectPropert (),   ere  }

        OFlar) scanPunctu(tra.toaits already fil(paed aut.   }

        trlyT.    tych e = ToscanStringLitwe'htrlyT.    tych e = TokeanNumericLit(ch)) {
        lse hen ctngthtrlyT.al: o(0))) {
                throwETolerantrual t, {}, MessaSen ct  isOericLit(ode);
        }
) {
            retdelega q.3D) E  (delega q.createericLiteial tar ch, sTal taalue;
        }

        retdelega q.3D) E  (delega q.createapedIdentiftrlyT.    vtr ch, sTal taalue;
    }

    functue: pObjectPropert fier() {
        ual tr keyteid, pe, valparamtach, sTal tte');

    trlyToke  okahean;ter.
        sTrlyToke  okahean;t  }

        trlyT.    tych e = ToapedIdenti(ch))) {
        ldndeue: pObjectPropert Keyfi;
dex;
           Propert  Aan assign: Gep(palar) Sep(pa.   }

            ttedT.    valch =get'wgt !m } c(':') ++i) {
        er.
keyndeue: pObjectPropert Keyfi;
        er.
    s.Unex(=('i;
        er.
    s.Unex(=)'i;
        er.
        valuue: pPropert F   func([]('u');
                retdelega q.3D) E  (delega q.createPropert f=get', keyteurn v r ch, sTal taalue;
            }
            ttedT.    valch =set'wgt !m } c(':') ++i) {
        er.
keyndeue: pObjectPropert Keyfi;
        er.
    s.Unex(=('i;
        er.
    trlyToke  okahean;ter.
    d];
        trlyT.    t!ch e = ToapedIdenti(ch)) {
        er.
    s.Unex(=)'i;
        er.
            throwETolerantrual t, {}, Messages.UnexpectedToktrlyT.    vtend];
        er.
        valuue: pPropert F   func([]('u');
                } else {
                paramoke[uue: pVariableapedIdentifi ];)) {
        er.
    s.Unex(=)'i;
        er.
            valuue: pPropert F   func(paramtatal taalue;
                }
                retdelega q.3D) E  (delega q.createPropert f=set', keyteurn v r ch, sTal taalue;
            }
        s.Unex(=:'i;
        er.
    valuue: pAan assignEar expres();
                retdelega q.3D) E  (delega q.createPropert f=t it'teid, pe, var ch, sTal taalue;
      ) {
        trlyT.    t=ch e = ToEOFwe'htrlyT.    tych e = ToscanPunctu '/') {
            tges.Unexpe(ial ta;   }
        } else {
        keyndeue: pObjectPropert Keyfi;
        er.
s.Unex(=:'i;
        er.
    valuue: pAan assignEar expres();
                retdelega q.3D) E  (delega q.createPropert f=t it'tekeyteurn v r ch, sTal taalue;
    }lue;
    }

    functue: pObjectInitialiserBody() {
        propertiesoke[]r propert ,ynam tekeytekind, mapokeror(to   'Str=    'Str ch, sTal tte');

        sTrlyToke  okahean;tter.
    s.Unex(={= ndex;

        whi!m } c('}') ++i) {
        propert ndeue: pObjectPropert fi;
dex;
            propert .key.    tych Syntax.ken.Identi '/') {
            namvaluuropert .key.namv;   }
            } else {
            namvaluto   'St propert .key.    vtend];
            }
        kindtyp(propert .kindtych =i it' 'u'Propert Kind.Data :p(propert .kindtych =get' 'u'Propert Kind.GeSt: Propert Kind.Set;
dex;
        keynde'$= '0namv;   }
            Object.proto    uhasOwnPropert . all(maptekey)== 0) {
                map[keyndex] Propert Kind.Data(ch)) {
                    hen ctngthkindtych Propert Kind.Data(ch)) {
                        throwETolerantrror({}, MessaSen ctDuplicatePropert iend];
                    } else kindt!ch Propert Kind.Data(ch)) {
                        throwETolerantrror({}, MessaAccesserDataPropert iend];
                 u');
                } else {
                lse kindt=ch Propert Kind.Data(ch)) {
                        throwETolerantrror({}, MessaAccesserDataPropert iend];
                    } else map[keynd& kindrker) {
                        throwETolerantrror({}, MessaAccesserGetSettart);
                    }
                }
            map[keynd|= kind;   }
            } else {
            map[keynde kind;   }
         

            propertieskpts.puropert ien
                !m } c('}') ++i) {
        er.
s.Unex(=,EGAL');
         urn;
        }

    s.Unex(=}'ieni) {
        retdelega q.3D) E  (delega q.createObjectEar expres(propertiem r ch, sTal taalue;
    }

   11.1.6 The Group'StrOon oper
nts

    functue: pGroupEar expres()dy() {
         xpr;tter.
    s.Unex(=('ieni) {
     xprndeue: pEar expres();

er.
    s.Unex(=)'i;
i) {
        retear ;          }

   11.1 Primary Ear expressnnts

    functue: pPrimaryEar expres()dy() {
        pe: t ual tr ear r ch, sTal tte');

        m } c('('t(ch)) {
            retue: pGroupEar expres()turn;
        }

        m } c('['t(ch)) {
            retue: pArrayInitialiserBoturn;
        }

        m } c('{'t(ch)) {
            retue: pObjectInitialiserBoturn;
        }

    u   typ  okahean.    ;ter.
        sTrlyToke  okahean;t  }

        t   tych e = ToapedIdenti(ch)) {
         xprnde delega q.createapedIdentif  Rfi.    vtend];
        } else     tych e = ToscanStringLitwe'ht   tych e = TokeanNumericLit(ch)) {
        lse hen ctngth  okahean.al: o(0))) {
                throwETolerantr  okahean, {}, MessaSen ct  isOericLit(ode);
        }
) {
         xprndedelega q.createericLite  Rfitend];
        } else     tych e = To as Key ++i) {
            m } c as Key('    func') '9') {
                retue: pF   funcEar expres();
            }i) {
            m } c as Key('== 'th'\n') {
            l Rfiend];
             xprndedelega q.createThisEar expres();   }
            } else {
                tges.Unexpe(  Rfitend];
         urn;
        } else     tych e = Token.BooleanLit '/') {
         al tmbe  Rfiend];
         al t.    val  ttedT.    valch =urn 'i;
        er.
s.Urndedelega q.createericLiteial ta;   }
        } else     tych e = Token.NullLit '/') {
         al tmbe  Rfiend];
         al t.    val == 'sh');
    er.
s.Urndedelega q.createericLiteial ta;   }
        } else m } c('/')we'hm } c('== ' ++i) {
            ert(typ    extra.toa!id =undefined= '{nd];
             xprndedelega q.createericLitecollect && Rfi);   }
            } else {
             xprndedelega q.createericLiteion atedReBo);
            }i) {
        peekfi;   }
        } else {
            tges.Unexpe(  Rfitend];
        }

        retdelega q.3D) E  (ear r ch, sTal taalue;
    }

   11.2 Left-Hand-Sidq Ear expressnnts

    functue: pArgugComf()dy() {
        argm = []ALter.
    s.Unex(=('ieni) {
        !m } c(') ' ++i) {
            whiee (inde >= length) {
            argmkpts.pue: pAan assignEar expres()x++) {
                ma} c(') ' ++i) {
        er.
    e   balue;
                }
            s.Unex(=,EGAL');
         urn;
        }

    s.Unex(=)'i;
i) {
        retargmalue;
    }

    functue: pNonC mputedPropert fier() {
        ual tr ch, sTal tte');

        sTrlyToke  okahean;ter.
    ual tmbe  Rfien  }

        !ion isIdentiier  trlyTd ++i) {
            tges.Unexpe(ial ta;   }
        }

        retdelega q.3D) E  (delega q.createapedIdentiftrlyT.    vtr ch, sTal taalue;
    }

    functue: pNonC mputedMeneNufier() {
    s.Unex(=.'i;
i) {
        retue: pNonC mputedPropert fialue;
    }

    functue: pC mputedMeneNufier() {
         xpr;tter.
    s.Unex(=['ieni) {
     xprndeue: pEar expres();

er.
    s.Unex(=]'i;
i) {
        retear ;         }

    functue: pNewEar expresBody() {
        vallee, argmr ch, sTal tte');

        sTrlyToke  okahean;ter.
    s.Unex as Key('newEGAL');
    valleendeue: pLeftHandSidqEar expresfi;   }
    argm = m } c('('t ?tue: pArgugComf()d: []ALter.
        retdelega q.3D) E  (delega q.createNewEar expresBcallee, argm r ch, sTal taalue;
    }

    functue: pLeftHandSidqEar expresAly aCallfier() {
         xpr, argmr propert ,ych, sTal t,epreviousAly aIntarx =te.aly aInte');

        sTrlyToke  okahean;ter.
    x =te.aly aInoketr value;
     xprndem } c as Key('newEG ?tue: pNewEar expresBod:tue: pPrimaryEar expres()te');

    eck (;; ++i) {
            m } c('. ' ++i) {
        er.
propert ndeue: pNonC mputedMeneNufiend];
             xprndedelega q.createMeneNuEar expres('. r ear r propert iend];
            } else m } c('( ' ++i) {
        er.
argm = ue: pArgugComf()end];
             xprndedelega q.createCallEar expres( xpr, argmiend];
            } else m } c('[ ' ++i) {
        er.
propert ndeue: pC mputedMeneNufiend];
             xprndedelega q.createMeneNuEar expres('[ r ear r propert iend];
            } e+i) {
        er.
e   balue;
            }
        delega q.3D) E  (ear r ch, sTal taalue;
        }
    se=te.aly aInokepreviousAly aIn;
i) {
        retear ;         }

    functue: pLeftHandSidqEar expresfier() {
         xpr, propert ,ych, sTal t;   }
    a   assse=te.aly aIn, 'valleenofoe = lar expressalways aly a in kas Key.'i;
i) {
        sTrlyToke  okahean;tter.
    s.Urndem } c as Key('newEG ?tue: pNewEar expresBod:tue: pPrimaryEar expres()te');

        whim } c('. 'we'hm } c('[') ++i) {
            m } c('[ ' ++i) {
        er.
propert ndeue: pC mputedMeneNufiend];
             xprndedelega q.createMeneNuEar expres('[ r ear r propert iend];
            } e+i) {
        er.
propert ndeue: pNonC mputedMeneNufiend];
             xprndedelega q.createMeneNuEar expres('. r ear r propert iend];
            }
        delega q.3D) E  (ear r ch, sTal taalue;
        }
        retear ;         }

   11.3 Postfix Ear expressnnts

    functue: pPostfixEar expresfier() {
         xpr, ual tr ch, sTal toke  okahean;tter.
    s.Urndeue: pLeftHandSidqEar expresAly aCallfidex);

          okahean.    tych e = ToscanPunctu '/') {
             m } c('++ 'we'hm } c('--= )wgt !peek (isLineTerminai ++i) {
        er.
   11.3.1, 11.3.2
                    hen ctngthear .    tych Syntax.ken.Identitgth &Re en ctedWord ear .name (ch)) {
                    throwETolerantrror({}, MessaSen ctLHSPostfixaalue;
              ]);

                !ioLeftHandSidq(ear  (ch)) {
                    throwETolerantrror({}, MessaInvalidLHSInAan assignaalue;
              ]);

             al tmbe  Rfiend];
             xprndedelega q.3D) E  (delega q.createPostfixEar expresftrlyT.    va  xpr r ch, sTal taalue;
            }
    }
   }
        retear ;         }

   11.4 UnaryrOon opersnnts

    functue: pUnaryEar expresfier() {
        ual tr ear r ch, sTal tte');

          okahean.    t!ch e = ToscanPunctungth  okahean.    t!ch e = To as Key(ch)) {
         xprndeue: pPostfixEar expresfi;   }
        } else m } c('++ 'we'hm } c('--= )wc = {
            sTrlyToke  okahean;ter.
    d];
 al tmbe  Rfiend];
         xprndeue: pUnaryEar expresfi;
        er.
   11.4.4, 11.4.5
                hen ctngthear .    tych Syntax.ken.Identitgth &Re en ctedWord ear .name (ch)) {
                throwETolerantrror({}, MessaSen ctLHSPrefixcode);
        }
dex;
            !ioLeftHandSidq(ear  (ch)) {
                throwETolerantrror({}, MessaInvalidLHSInAan assignaalue;
            }

        ifprndedelega q.createUnaryEar expresftrlyT.    va  xpr sh');
    er.
s.Urndedelega q.3D) E  (ear r ch, sTal taalue;
        } else m } c('+ 'we'hm } c('- 'we'hm } c('~ 'we'hm } c('!= )wc = {
            sTrlyToke  okahean;ter.
    d];
 al tmbe  Rfiend];
         xprndeue: pUnaryEar expresfi;
        er.
ifprndedelega q.createUnaryEar expresftrlyT.    va  xpr sh');
    er.
s.Urndedelega q.3D) E  (ear r ch, sTal taalue;
        } else m } c as Key('  lete 'we'hm } c as Key('void 'we'hm } c as Key('ert(ty= )wc = {
            sTrlyToke  okahean;ter.
    d];
 al tmbe  Rfiend];
         xprndeue: pUnaryEar expresfi;
        er.
ifprndedelega q.createUnaryEar expresftrlyT.    va  xpr sh');
    er.
s.Urndedelega q.3D) E  (ear r ch, sTal taalue;
            hen ctngthear .son opertych =  lete ngthear .argugCom.    tych Syntax.ken.Identi '/') {
                throwETolerantrror({}, MessaSen ctD letetend];
         urn;
        } eh)) {
         xprndeue: pPostfixEar expresfi;   }
     
i) {
        retear ;         }

    functbinaryPrecedsequrual t, aly aInier() {
        prec ode =nd];
        trlyT.    t!ch e = ToscanPunctu(gthtrlyT.    t!ch e = To as Key(ch)) {
            ret0;   }
     
i) {
    s   sw  ttedT.    v(ch)) {
        c=||=:
            prec od1end];
        e   bal)) {
        c=&&=:
            prec od2end];
        e   bal)) {
        c=|=:
            prec od3end];
        e   bal)) {
        c=^=:
            prec od4end];
        e   bal)) {
        c=&=:
            prec od5end];
        e   bal)) {
        c====:
            c=!==:
            c=====:
            c=!===:
            prec od6end];
        e   bal)) {
        c=<=:
            c=>=:
            c=<==:
            c=>==:
            c=instinstof=:
            prec od7end];
        e   bal)) {
        c=in=:
            prec odaly aIno? 7 :de =se;
        e   bal)) {
        c=<<=:
            c=>>=:
            c=>>>=:
            prec od8 =se;
        e   bal)) {
        c=+=:
            c=-=:
            prec od9 =se;
        e   bal)) {
        c=*=:
            c=/=:
            c=%=:
            prec od11end];
        e   bal)) {
        def:
        er.
e   balue;
     
i) {
        retprec;         }

   11.5 MultiplicativerOon opersn }

   11.6 Add poverOon opersn }

   11.7 Bitwise ShiftrOon opersn }

   11.8 RelaposialrOon opersn }

   11.9 EqualityrOon opersn }

   11.10 Binary Bitwise Oon opersn }

   11.11 Binary LogicalrOon opersnnts

    functue: pBinaryEar expresfier() {
        3D) er, 3D) ers,  xpr, ual tr prec, senck, righmuoson operar ift, i;art;

    3D) Number okahean;ter.
     iftndeue: pUnaryEar expresfi;
');

    trlyToke  okahean;ter.
    prec odbinaryPrecedsequrual t, se=te.aly aIne;pe;

        prec och a(ch)) {
            ret iftalue;
        }
    ttedT.prec odprec;           Rfieni) {
    3D) ers = [3D) er,   okahean];)) {
    righmndeue: pUnaryEar expresfi;
');

    senck = [ ift, ual t, righm]te');

        whi(prec odbinaryPrecedsequr  okahean, se=te.aly aIne) > !== 0
        er.
   Reduce: make adbinary lar expressing.tessathresatrpmost entrieski) {
            whi(senckeins.le > 2)wgt (prec <= senck[senckeins.le - 2].prec) '9') {
             ighmndesenckkpop(tart);
            son operndesenckkpop(t.var value;
    er.
     iftndesenckkpop(tart);
            ifprndedelega q.createBinaryEar expresfson operar ift, righm ;se {
            ma) erskpop(tart);
            3D) Numbema) ers[ma) erskins.le - 1];
                  lega q.3D) E  (ear r ma) ertart);
            senckkpts.p xpr sh');
    er.
}
dex;
           Shift.') {
         al tmbe  Rfiend];
         al t.prec odprec;             senckkpts.ptal taalue;
        ma) erskpts.p  okaheana;   }
         xprndeue: pUnaryEar expresfi;
        er.
senckkpts.p xpr sh');
        }

       Final reduce  //c.Boo-uphing sencke++];
    indesenckkins.le - 1alue;
     xprndesenck[i];
        ma) erskpop(tart);
        whie > 1(ch)) {
         xprndedelega q.createBinaryEar expresfsenck[i - 1]x    va senck[i - 2]a  xpr sh');
    er.
i -od2end];
        3D) Numbema) erskpop(tart);
          lega q.3D) E  (ear r ma) ertart);
    }
i) {
        retear ;          }

   11.12 Cond posialrOon oper
nts

    functue: pCond posialEar expresfier() {
         xpr, previousAly aInr   nape set, al(patater ch, sTal tte');

        sTrlyToke  okahean;tter.
    s.Urndeue: pBinaryEar expresfite');

        m } c('?wi'\n') {
        l Rfiend];
        previousAly aIntarx =te.aly aInte        er.
sente.aly aInoketr value;
          nape setaluue: pAan assignEar expres();
            se=te.aly aInokepreviousAly aIn;
        er.
s.Unex(=:'i;
        er.
al(patatealuue: pAan assignEar expres();
)) {
         xprndedelega q.createCond posialEar expresf xpr,   nape set, al(patate ;   }
        delega q.3D) E  (ear r ch, sTal taalue;
         }
        retear ;         }

   11.13 Aan assignrOon opersnnts

    functue: pAan assignEar expres()er() {
        ual tr  ift, righmuonh (r ch, sTal tte');

    trlyToke  okahean;ter.
        sTrlyToke  okahean;t  }

    nh (mbe  ftndeue: pCond posialEar expresfite');

        m } cAan asai'\n') {
        // LeftHandSidqEar expres ex;
            !ioLeftHandSidq(  ft (ch)) {
                throwETolerantrror({}, MessaInvalidLHSInAan assignaalue;
            }

           11.13.1)) {
        lse hen ctngth eft.    tych Syntax.ken.Identitgth &Re en ctedWord  eft.name (ch)) {
                throwETolerantrual t, {}, MessaSen ctLHSAan assignaalue;
            }

         al tmbe  Rfiend];
        righmndeue: pAan assignEar expres();
            nh (mbedelega q.3D) E  (delega q.createAan assignEar expres(trlyT.    va  ift, righm r ch, sTal taalue;
         }
        retnde(ode);
    }

   11.14 skiparOon oper
nts

    functue: pEar expresfier() {
         xpr,     sTrlyToke  okahean;tter.
    s.Urndeue: pAan assignEar expres();
)) {
        m } c(',wi'\n') {
         xprndedelega q.createSpe sequEar expres([  xprn]);
)) {
            whiee (inde >= length) {
                !m } c(', ' ++i) {
        er.
    e   balue;
                }
              Rfiend];
             xpr. ar expresskpts.pue: pAan assignEar expres()x++) {
            }

        delega q.3D) E  (ear r ch, sTal taalue;
         }
        retear ;         }

   12.1 Block
nts

    functue: pStatepComListBody() {
        ristoke[]r
            se=tepComte');

        whiee (inde >= length) {
            m } c('}') ++i) {
        er.
e   balue;
            }
        se=tepComndeue: pSe: soElegCom(aalue;
            ert(typse=tepComndid =undefined= '{nd];
            e   balue;
            }
        ristkpts.pse=tepComaalue;
         }
        retrist;         }

    functue: pBlockBody() {
        block, ch, sTal tte');

        sTrlyToke  okahean;ter.
    s.Unex(={= ndex;

    blockndeue: pStatepComListBo;   }

    s.Unex(=}'ieni) {
        retdelega q.3D) E  (delega q.createBlockStatepCom(block r ch, sTal taalue;
    }

   12.2 Variable fietepComn  }

    functue: pVariableapedIdentifi r() {
        ual tr ch, sTal tte');

        sTrlyToke  okahean;ter.
    ual tmbe  Rfien  }

        trlyT.    t!ch e = ToapedIdenti(ch)) {
            tges.Unexpe(ial ta;   }
        }

        retdelega q.3D) E  (delega q.createapedIdentiftrlyT.    vtr ch, sTal taalue;
    }

    functue: pVariableD alarafunc(kindrker) {
        i ital == 'teid, ch, sTal tte');

        sTrlyToke  okahean;ter.
    ldndeue: pVariableapedIdentifien  }

       12.2.1)) {
    lse hen ctngth &Re en ctedWord idmname (ch)) {
        i   throwETolerantrror({}, MessaSen ctVarier iend];
      
        lse kindt=ch '  nat''\n') {
         xpnex(=='i;
        er.
i ital ue: pAan assignEar expres();
            } else m } c('=wi'\n') {
        l Rfiend];
        i ital ue: pAan assignEar expres();
            }

        retdelega q.3D) E  (delega q.createVariableD alarafer(id, t itrr ch, sTal taalue;
    }

    functue: pVariableD alarafuncListBkindrker) {
        ristoke[]al)) {
     o\n') {
        listkpts.pue: pVariableD alarafunc(kindraalue;
            !m } c(', ' ++i) {
        er.
e   balue;
            }
        r Rfiend];
    }     whiee (inde >= len;    }
        retrist;         }

    functue: pVariableStatepCom(rker) {
          alarafuncs;   }

    s.Unex as Key('var'ieni) {
      alarafuncsndeue: pVariableD alarafuncListBieni) {
    consumeSemicoloTBoeni) {
        retdelega q.createVariableD alarafunc(r alarafuncs, 'var'ienue;
    }

   kindtmaymbe `  nat`tgit`let`  }

   Bothaits s.UnripComallar) not in ing specdencafunc yet.
    // see http://wiki.ecmascripf.org/doku.php?id=harmony:  nat
    // ar) http://wiki.ecmascripf.org/doku.php?id=harmony:letnts

    functue: pConstLetD alarafunc(kindrker) {
        r alarafuncs, ch, sTal tte');

        sTrlyToke  okahean;tter.
    s.Unex as Key(kindreni) {
      alarafuncsndeue: pVariableD alarafuncListBkindreni) {
    consumeSemicoloTBoeni) {
        retdelega q.3D) E  (delega q.createVariableD alarafunc(r alarafuncs, kindrr ch, sTal taalue;
    }

   12.3 Empty fietepComn  }

    functue: pEmptyStatepCom(rker) {
     xpnex(=;'i;
            retdelega q.createEmptyStatepCom(ralue;
    }

   12.4 Ear expres fietepComn  }

    functue: pEar expresStatepCom(rker) {
         xprndeue: pEar expres();
) {
    consumeSemicoloTBoen            retdelega q.createEar expresStatepCom( xpr sh');
    }

   12.5 If0sietepComn  }

    functue: paffietepComfi r() {
        uon r   nape set, al(patate;   }

    s.Unex as Key('if')ALter.
    s.Unex(=('ieni) {
    uon ndeue: pEar expres();

er.
    s.Unex(=)'i;
i) {
      nape setaluue: pStatepCom(ral
            m } c as Key('  } wi'\n') {
        l Rfiend];
        al(patatealuue: pStatepCom(ralue;
        } eh)) {
        al(patatealu== 'sh');
    }ni) {
        retdelega q.createaffietepComfion r   nape set, al(patate sh');
    }

   12.6 IicLitres fietepComsnnts

    functue: pDoW   wStatepComBody() {
        bd, msion r oldI IicLitres;   }

    s.Unex as Key('do'i;
i) {
    oldI IicLitrestarx =te.i IicLitres;         se=te.i IicLitrestartr valter.
    ed, ndeue: pStatepCom(ral
        se=te.i IicLitrestaroldI IicLitres;   }

    s.Unex as Key('    w')ALter.
    s.Unex(=('ieni) {
    uon ndeue: pEar expres();

er.
    s.Unex(=)'i;
i) {
    lse m } c(';wi'\n') {
        l Rfiend];
    }ni) {
        retdelega q.createDoW   wStatepComBbd, msion aalue;
    }

    functue: pW   wStatepComBody() {
        ion r ed, ,roldI IicLitres;   }

    s.Unex as Key('    w')ALter.
    s.Unex(=('ieni) {
    uon ndeue: pEar expres();

er.
    s.Unex(=)'i;
i) {
    oldI IicLitrestarx =te.i IicLitres;         se=te.i IicLitrestartr valter.
    ed, ndeue: pStatepCom(ral
        se=te.i IicLitrestaroldI IicLitres;   }

        retdelega q.createW   wStatepComBion r ed,  alue;
    }

    functue: pForVariableD alarafunc(i r() {
        ual tr r alarafuncs, ch, sTal tte');

        sTrlyToke  okahean;t         al tmbe  Rfiend];
      alarafuncsndeue: pVariableD alarafuncListBieni) {
        retdelega q.3D) E  (delega q.createVariableD alarafunc(r alarafuncs, trlyT.    vtr ch, sTal taalue;
    }

    functue: pForStatepComBody() {
        t itmsion r upda qr  ift, righmuoed, ,roldI IicLitres,epreviousAly aIntarx =te.aly aInte');

    i ital uon ndeupda qalu== 'sh  }

    s.Unex as Key('for')ALter.
    s.Unex(=('ieni) {
    lse m } c(';wi'\n') {
        l Rfiend];
    }   } eh)) {
            m } c as Key('var'iwe'hm } c as Key('let'  ++i) {
        er.
se=te.aly aInoker = false;
            i ital ue: pForVariableD alarafunc(i;i) {
        er.
se=te.aly aInokepreviousAly aIn;
i) {
                i it.r alarafuncskins.le =ch 1ngthm } c as Key('in ' ++i) {
        er.
      Rfiend];
                 iftndei it'u');
                 ighmndeue: pEar expres();
                    i ital == 'sh');
    er.
        }
            } e+i) {
        er.
se=te.aly aInoker = false;
            i ital ue: pEar expres();
                se=te.aly aInokepreviousAly aIn;
i) {
                m } c as Key('in ' ++i) {
        er.
    // LeftHandSidqEar expres ex;
                    !ioLeftHandSidq(t itrrker) {
                        throwETolerantrror({}, MessaInvalidLHSInForIntart);
                  i) {
        er.
      Rfiend];
                 iftndei it'u');
                 ighmndeue: pEar expres();
                    i ital == 'sh');
    er.
        }
         
lue;
            ert(typ iftndid =undefined= '{nd];
             xpnex(=;'i;
                }
    }
   }
        ert(typ iftndid =undefined= '{nlue;
            !m } c('; ' ++i) {
        er.
uon ndeue: pEar expres();
e);
        }
) {
         xpnex(=;'i;
lue;
            !m } c(') ' ++i) {
        er.
upda qaluue: pEar expres();
e);
        }
) {
    }

er.
    s.Unex(=)'i;
i) {
    oldI IicLitrestarx =te.i IicLitres;         se=te.i IicLitrestartr valter.
    ed, ndeue: pStatepCom(ral
        se=te.i IicLitrestaroldI IicLitres;   }

        ret ert(typ iftndid =undefined= '?
                  lega q.createForStatepComBt itmsion r upda qr ed,  ':
                  lega q.createForIsStatepCom( ift, righmuoed,  sh');
    }

   12.7 The continue0sietepComn  }

    functue: pContinueStatepComBody() {
        labelal == 'tekeysh  }

    s.Unex as Key('continue'ien  }

       Optimiznsurg most ost co form: 'continue;'cter.
        h = source.charCodeAt(in| ch as3B'\n') {
        l Rfienlue;
            !se=te.i IicLitres(0))) {
                throwError({}, MessaIllegalContinuex++) {
            }

            retdelega q.createContinueStatepComBnull);   }
    }
   }
        peek (isLineTerminai ++i) {
            !se=te.i IicLitres(0))) {
                throwError({}, MessaIllegalContinuex++) {
            }

            retdelega q.createContinueStatepComBnull);   }
    }
   }
          okahean.    tych e = ToapedIdenti(ch)) {
        labelal ue: pVariableapedIdentifien  }

        keynde'$= '0label.namv;   }
            !Object.proto    uhasOwnPropert . all(se=te.labelSettekey)== 0) {
                throwError({}, MessaUnknownLabel,0label.namv);
e);
        }
) {
    }

er.
    consumeSemicoloTBoeni) {
         abelal=l == 'wgt !se=te.i IicLitres(0))) {
            throwError({}, MessaIllegalContinuex++) {
    }ni) {
        retdelega q.createContinueStatepComB abel sh');
    }

   12.8 The e   b0sietepComn  }

    functue: pB   bStatepComBody() {
        labelal == 'tekeysh  }

    s.Unex as Key('e   b'ien  }

       C } caing verymost co     cfirn : immediately a semicoloTu'=' (3B)cter.
        h = source.charCodeAt(in| ch as3B'\n') {
        l Rfienlue;
            !(se=te.i IicLitrest|| se=te.i S   sw)(0))) {
                throwError({}, MessaIllegalB   bx++) {
            }

            retdelega q.createB   bStatepComBnull);   }
    }
   }
        peek (isLineTerminai ++i) {
            !(se=te.i IicLitrest|| se=te.i S   sw)(0))) {
                throwError({}, MessaIllegalB   bx++) {
            }

            retdelega q.createB   bStatepComBnull);   }
    }
   }
          okahean.    tych e = ToapedIdenti(ch)) {
        labelal ue: pVariableapedIdentifien  }

        keynde'$= '0label.namv;   }
            !Object.proto    uhasOwnPropert . all(se=te.labelSettekey)== 0) {
                throwError({}, MessaUnknownLabel,0label.namv);
e);
        }
) {
    }

er.
    consumeSemicoloTBoeni) {
         abelal=l == 'wgt !(se=te.i IicLitrest|| se=te.i S   sw)(0))) {
            throwError({}, MessaIllegalB   bx++) {
    }ni) {
        retdelega q.createB   bStatepComB abel sh');
    }

   12.9 The     retsietepComn  }

    functue: pR   reStatepComBody() {
        argugComalu== 'sh  }

    s.Unex as Key('    re'ieni) {
        !se=te.i F   funcBd,  'h)) {
        i   throwETolerantrror({}, MessaIllegalR   re sh');
        }

       '    re' foly aed by a space ar) an ien.Identitis verymost cocter.
        h = source.charCodeAt(in| ch as20 ++i) {
            ieapedIdentiLineS h = source.charCodeAt(itdex)' ++i) {
        er.
argupComndeue: pEar expres();
                consumeSemicoloTBoen        ) {
        retdelega q.createR   reStatepComBargupComi;
                }
    }
   }
        peek (isLineTerminai ++i) {
            retdelega q.createR   reStatepComBnull);   }
    }
   }
        !m } c('; ' ++i) {
            !m } c('}')ngth  okahean.    t!ch e = ToEOF(ch)) {
        er.
argupComndeue: pEar expres();
            }
) {
    }

er.
    consumeSemicoloTBoeni) {
        retdelega q.createR   reStatepComBargupComi;
        }

   12.10 The withtsietepComn  }

    functue: pWithStatepComBody() {
        objectuoed, eni) {
         en ct'\n') {
        // TODO(ikarieermin): Should we
upda qaessaton n    s instead?
             on skipComme;pe;

        i   throwETolerantrror({}, MessaSen ctModeWith);   }
    }
   }
    s.Unex as Key(' ith')ALter.
    s.Unex(=('ieni) {
    objectndeue: pEar expres();

er.
    s.Unex(=)'i;
i) {
    ed, ndeue: pStatepCom(ral
            retdelega q.createWithStatepComBobjectuoed, i;
        }

   12.10 The swithtsietepComn  }

    functue: pS   swCasefi r() {
        uon r   nape setoke[]r ch,tepCom, ch, sTal tte');

        sTrlyToke  okahean;ter.
    lse m } c as Key('    defwi'\n') {
        l Rfiend];
        uon nde== 'sh');
    }   } eh)) {
         xpnex as Key('cas 'i;
        er.
uon ndeue: pEar expres();
e);
    }
    er.
s.Unex(=:'i;
');

        whiee (inde >= length) {
            m } c('}')we'hm } c as Key('    defwiwe'hm } c as Key('cas 'i ++i) {
        er.
e   balue;
            }
        se=tepComndeue: pStatepCom(ralue;
          nape setkpts.pse=tepComaalue;
         }
        retdelega q.3D) E  (delega q.createS   swCasefuon r   nape settr ch, sTal taalue;
    }

    functue: pS   swStatepCom(rker) {
         iscrieTerom,     s, clauser oldI S   sw,     defFounn;tter.
    s.Unex as Key('s   sw')ALter.
    s.Unex(=('ieni) {
     iscrieTeromndeue: pEar expres();

er.
    s.Unex(=)'i;
i) {
    s.Unex(={= ndex;

        s ke[]al)) {
        m } c('}') ++i) {
        l Rfiend];
            re delega q.createS   swStatepCom( iscrieTerom,     saalue;
         }
    oldI S   swtarx =te.i S   sw;         se=te.i S   swtartr value;
        defFounnoker = fal');

        whiee (inde >= length) {
            m } c('}') ++i) {
        er.
e   balue;
            }
        clausendeue: pS   swCasefi;   }
            clause.uon nd=l == 'ngth) {
                    defFounn(ch)) {
                    throwError({}, MessaMultipleD   defsI S   swaalue;
                }
                defFounnoketr value;
            }
        c   skpts.pclauseaalue;
         }
    se=te.i S   swtaroldI S   sw;   }

    s.Unex(=}'ieni) {
        retdelega q.createS   swStatepCom( iscrieTerom,     saalue;
    }

   12.13 The     ttsietepComn  }

    functue: pT   tStatepComBody() {
        argugCom;tter.
    s.Unex as Key('    t'ieni) {
        peek (isLineTerminai ++i) {
            throwError({}, MessaNew    AfterT   taalue;
         }
    argupComndeue: pEar expres();

er.
    consumeSemicoloTBoeni) {
        retdelega q.createT   tStatepComBargupComi;
        }

   12.14 The  ry0sietepComn  }

    functue: pC } cClauseBody() {
        paramtaed, msch, sTal tte');

        sTrlyToke  okahean;ter.
    s.Unex as Key('ca sw')ALter.
    s.Unex(=('ien            m } c(')') ++i) {
            tges.Unexpe(  okaheana;   }
      ter.
    paramokeue: pVariableapedIdentifien }

       12.14.1)) {
    lse hen ctngth &Re en ctedWord parammname (ch)) {
        i   throwETolerantrror({}, MessaSen ctC } cVariable);   }
    }
   }
    s.Unex(=)'i;
        ed, ndeue: pBlockBo;i) {
        retdelega q.3D) E  (delega q.createC } cClauseBparamtaed, tr ch, sTal taalue;
    }

    functue: pTryStatepComBody() {
        block, handlers = []tafinalizNumbe== 'sh  }

    s.Unex as Key('try= ndex;

    blockndeue: pBlockBo;iter.
    lse m } c as Key('ca sw')(ch)) {
        handlerskpts.pue: pC } cClauseBooturn;
        }

        m } c as Key('finally') ++i) {
        l Rfiend];
        finalizNumbeue: pBlockBo;i) {
        }

        handlerskins.le =ch 0wgt !finalizNu ++i) {
            throwError({}, MessaNoC } cOrFinallyx++) {
    }ni) {
        retdelega q.createTryStatepComBblock, []tahandlerstafinalizNui;
        }

   12.15 The debugger0sietepComn  }

    functue: pDebuggerStatepCom(rker) {
     xpnex as Key('  bugger');

er.
    consumeSemicoloTBoeni) {
        retdelega q.createDebuggerStatepCom(r;
        }

   12 fietepComsnnts

    functue: pStatepComBody() {
        i   typ  okahean.    ,') {
         xpr,)) {
        labeledBd, ,  }

        key, = {
            sTrlyT;t  }

        t   tych e = ToEOF(ch)) {
            tges.Unexpe(  okaheana;   }
      ter.
        t   tych e = ToscanPunctungth  okahean.    valch ={'(ch)) {
            retue: pBlockBo;i) {
        }

        sTrlyToke  okahean;t  }

        t   tych e = ToscanPunctu '/') {
        s   sw    okahean.    v '/') {
            c=;':   }
                retdelega q.3D) E  (ue: pEmptyStatepCom(rr ch, sTal taalue;
            c=(':   }
                retdelega q.3D) E  (ue: pEar expresStatepCom(rr ch, sTal taalue;
            def:
        er.
er.
e   balue;
            }
      ter.
        t   tych e = To as Key(ch)) {
        s   sw    okahean.    v '/') {
            c=e   b':   }
                retdelega q.3D) E  (ue: pB   bStatepComBor ch, sTal taalue;
            c=continue':   }
                retdelega q.3D) E  (ue: pContinueStatepComBor ch, sTal taalue;
            c=  bugger':   }
                retdelega q.3D) E  (ue: pDebuggerStatepCom(rr ch, sTal taalue;
            c= o':   }
                retdelega q.3D) E  (ue: pDoW   wStatepComBor ch, sTal taalue;
            c=for':   }
                retdelega q.3D) E  (ue: pForStatepComBor ch, sTal taalue;
            c=f   func':   }
                retdelega q.3D) E  (ue: pF   funcD alarafunc(ir ch, sTal taalue;
            c=if':   }
                retdelega q.3D) E  (ue: paffietepComfir ch, sTal taalue;
            c=    re':   }
                retdelega q.3D) E  (ue: pR   reStatepComBor ch, sTal taalue;
            c=s   sw':   }
                retdelega q.3D) E  (ue: pS   swStatepCom(rr ch, sTal taalue;
            c=    t':   }
                retdelega q.3D) E  (ue: pT   tStatepComBor ch, sTal taalue;
            c= ry':   }
                retdelega q.3D) E  (ue: pTryStatepCom(rr ch, sTal taalue;
            c=var':   }
                retdelega q.3D) E  (ue: pVariableStatepCom(rr ch, sTal taalue;
            c=    w':   }
                retdelega q.3D) E  (ue: pW   wStatepComBor ch, sTal taalue;
            c= ith':   }
                retdelega q.3D) E  (ue: pWithStatepComBor ch, sTal taalue;
            def:
        er.
er.
e   balue;
            }
      ter.
     xprndeue: pEar expres();

er.
       12.12 Labelled fietepComsner.
        (ear .    tych Syntax.ken.Identi)ngthm } c(=:'i'\n') {
        l Rfienlue;
        keynde'$= '0ear .name;   }
            Object.proto    uhasOwnPropert . all(se=te.labelSettekey)== 0) {
                throwError({}, MessaRer alarafunc, 'Label r ear .namv);
e);
        }

            se=te.labelSet[keynde tr value;
        labeledBd, ndeue: pStatepCom(ralue;
          lete se=te.labelSet[keyn;
                retdelega q.3D) E  (delega q.createLabeledStatepCom( xpr, labeledBd,  r ch, sTal taalue;
         }
    consumeSemicoloTBoeni) {
        retdelega q.3D) E  (delega q.createEar expresStatepCom( xpr r ch, sTal taalue;
    }

   13 F   func Defin posi   }

    functue: pF   funcSe: soElegComf()dy() {
        se: soElegCom, se: soElegComs = []taual tr rirecpove,cfirn Re en cted, = {
        oldLabelSetteoldI IicLitres,eoldI S   sw, oldI F   funcBd, , ch, sTal tte');

        sTrlyToke  okahean;ter.
    s.Unex(={= ndex;

        whiee (inde >= length) {
              okahean.    t!ch e = ToscanStringLit ++i) {
        er.
e   balue;
            }
        trlyToke  okahean;t  }

         e: soElegComndeue: pSe: soElegCom(aalue;
        se: soElegComskpts.pse: soElegComaalue;
            he: soElegCom. ar expres.    t!ch Syntax.ringLit ++i) {
        er.
// == 'tis not rirecpovei) {
        er.
e   balue;
            }
        direcpovetarx = sousliqurual t.    stdex, trlyT.end - 1aalue;
            direcpovetaid =use sen ct' ++i) {
        er.
sen ctne tr value;
                firn Re en cted(ch)) {
                    throwETolerantrfirn Re en cted, {}, MessaSen ct  isOericLit(ode);
                }
            } e+i) {
        er.
    !firn Re en cted(gthtrlyT.al: o(0))) {
                firn Re en cted(=htrlyTsh');
    er.
        }
         
ue;
         }
    oldLabelSettarx =te.labelSet;i) {
    oldI IicLitrestarx =te.i IicLitres;         oldI S   swtarx =te.i S   sw;         oldI F   funcBd, tarx =te.i F   funcBd, al
        se=te.labelSettar{};         se=te.i IicLitrestarr = false;
    se=te.i S   swtarr = false;
    se=te.i F   funcBd, tartr valter.
        whiee (inde >= length) {
            m } c('}') ++i) {
        er.
e   balue;
            }
        se: soElegComndeue: pSe: soElegCom(aalue;
            ert(typse: soElegComndid =undefined= '{nd];
            e   balue;
            }
        se: soElegComskpts.pse: soElegComaalue;
        }

    s.Unex(=}'ieni) {
    se=te.labelSettaroldLabelSet;
        se=te.i IicLitrestaroldI IicLitres;   }
    se=te.i S   swtaroldI S   sw; se;
    se=te.i F   funcBd, taroldI F   funcBd, eni) {
        retdelega q.3D) E  (delega q.createBlockStatepCom(se: soElegComstr ch, sTal taalue;
    }

    functue: pParams firn Re en cted(ch)) {
        paramtaparams = []taual tr  en cted, paramSettekey, m}, Mes;ter.
    s.Unex(=('ieni) {
        !m } c(') ' ++i) {
        paramSettar{};                 whiee (inde >= length) {
            trlyToke  okahean;ter.
    d];
    paramokeue: pVariableapedIdentifien }

            keynde'$= '0trlyT.    v;
                    hen ct(0))) {
                    ieRe en ctedWord trlyT.    vtrker) {
                     en cted(=htrlyTsh');
    er.
            m}, Mes = {}, MessaSen ctParamName;   }
                    }
                    Object.proto    uhasOwnPropert . all(paramSettekeytrker) {
                     en cted(=htrlyTsh');
    er.
            m}, Mes = {}, MessaSen ctParamDupe;   }
                    }
                } else !firn Re en cted(ch)) {
                    ieRe en ctedWord trlyT.    vtrker) {
                    firn Re en cted(=htrlyTsh');
    er.
            m}, Mes = {}, MessaSen ctParamName;   }
                    } else isSen ctModeReservedWord trlyT.    vtrker) {
                    firn Re en cted(=htrlyTsh');
    er.
            m}, Mes = {}, MessaSen ctReservedWord;   }
                    } else Object.proto    uhasOwnPropert . all(paramSettekeytrker) {
                    firn Re en cted(=htrlyTsh');
    er.
            m}, Mes = {}, MessaSen ctParamDupe;   }
                    }
             ter.
    d];
    paramskpts.pue:am);ter.
    d];
    paramSet[keynde tr value;
                ma} c(') ' ++i) {
        er.
    e   balue;
                }
            s.Unex(=,EGAL');
         urn;
        }

    s.Unex(=)'i;
i) {
        ret+i) {
        params: params, = {
          n cted:  en cted, = {
        firn Re en cted:cfirn Re en cted, = {
        m}, Mes: m}, Mesurn;
     alue;
    }

    functue: pF   funcD alarafunc(idy() {
        tdtaparams = []tabd, msial tr  en cted, tmp,cfirn Re en cted, m}, Mes,epreviousSen ct, ch, sTal tte');

        sTrlyToke  okahean;tter.
    s.Unex as Key(=f   func');');

    trlyToke  okahean;ter.
    ldndeue: pVariableapedIdentifien            hen ct(0))) {
            ieRe en ctedWord trlyT.    vtrker) {
                throwETolerantrual t, {}, MessaSen ctF   funcNamv);
e);
        }
) {
    }   } eh)) {
            ieRe en ctedWord trlyT.    vtrker) {
            firn Re en cted(=htrlyTsh');
    er.
    m}, Mes = {}, MessaSen ctF   funcNamvend];
            } else isSen ctModeReservedWord trlyT.    vtrker) {
            firn Re en cted(=htrlyTsh');
    er.
    m}, Mes = {}, MessaSen ctReservedWord;   }
         urn;
        }

    tmpndeue: pParams firn Re en cted(;ter.
    params = tmp.params; se;
    sen cted(=htmp.sen cted; se;
    firn Re en cted(=htmp.firn Re en cteden            tmp.m}, Mesrker) {
        m}, Mes = tmp.m}, Mes;   }
      ter.
    previousSen cttarx n ct;
        ed, ndeue: pF   funcSe: soElegComf();)) {
    lse hen ctngthfirn Re en cted(ch)) {
            throwErfirn Re en cted, m}, Mes);
e);
    }
    er.
lse hen ctngth en cted(ch)) {
            throwETolerantr en cted, m}, Mes);
e);
    }
    er.
sen ctne previousSen cteni) {
        retdelega q.3D) E  (delega q.createF   funcD alarafunc(tdtaparams, []tabd, tr ch, sTal taalue;
    }

    functue: pF   funcEar expres()er() {
        ual tr ldnde== 'te en cted, firn Re en cted, m}, Mes,etmp,cparams = []tabd, mspreviousSen ct, ch, sTal tte');

        sTrlyToke  okahean;ter.
    s.Unex as Key(=f   func');'i) {
        !m } c('( ' ++i) {
        trlyToke  okahean;ter.
    d];
ldndeue: pVariableapedIdentifien                hen ct(0))) {
                ieRe en ctedWord trlyT.    vtrker) {
                    throwETolerantrual t, {}, MessaSen ctF   funcNamv);
e);
                }
            } e+i) {
        er.
    ieRe en ctedWord trlyT.    vtrker) {
                firn Re en cted(=htrlyTsh');
    er.
        m}, Mes = {}, MessaSen ctF   funcNamvend];
                } else isSen ctModeReservedWord trlyT.    vtrker) {
                firn Re en cted(=htrlyTsh');
    er.
        m}, Mes = {}, MessaSen ctReservedWord;   }
            }   }
         urn;
        }

    tmpndeue: pParams firn Re en cted(;ter.
    params = tmp.params; se;
    sen cted(=htmp.sen cted; se;
    firn Re en cted(=htmp.firn Re en cteden            tmp.m}, Mesrker) {
        m}, Mes = tmp.m}, Mes;   }
      ter.
    previousSen cttarx n ct;
        ed, ndeue: pF   funcSe: soElegComf();)) {
    lse hen ctngthfirn Re en cted(ch)) {
            throwErfirn Re en cted, m}, Mes);
e);
    }
    er.
lse hen ctngth en cted(ch)) {
            throwETolerantr en cted, m}, Mes);
e);
    }
    er.
sen ctne previousSen cteni) {
        retdelega q.3D) E  (delega q.createF   funcEar expres(tdtaparams, []tabd, tr ch, sTal taalue;
    }

   14 Programnnts

    functue: pSe: soElegCom(ach)) {
          okahean.    tych e = To as Key(ch)) {
        s   sw    okahean.    v '/') {
            c=  nat':') {
            c=let':   }
                retue: pConstLetD alarafunc(  okahean.    v alue;
            c=f   func':   }
                retue: pF   funcD alarafunc(ialue;
            def:
        er.
er.
    retue: pStatepCom(ralue;
        }   }
    }
   }
          okahean.    t!ch e = ToEOF(ch)) {
            retue: pStatepCom(ralue;
    }lue;
    }

    functue: pSe: soElegComf()dy() {
        se: soElegCom, se: soElegComs = []taual tr rirecpove,cfirn Re en ctedalter.
        whiee (inde >= length) {
        trlyToke  okahean;ter.
    d];
l   trlyT.    t!ch e = ToscanStringLit ++i) {
        er.
e   balue;
            }

         e: soElegComndeue: pSe: soElegCom(aalue;
        se: soElegComskpts.pse: soElegComaalue;
            he: soElegCom. ar expres.    t!ch Syntax.ringLit ++i) {
        er.
// == 'tis not rirecpovei) {
        er.
e   balue;
            }
        direcpovetarx = sousliqurual t.    stdex, trlyT.end - 1aalue;
            direcpovetaid =use sen ct' ++i) {
        er.
sen ctne tr value;
                firn Re en cted(ch)) {
                    throwETolerantrfirn Re en cted, {}, MessaSen ct  isOericLit(ode);
                }
            } e+i) {
        er.
    !firn Re en cted(gthtrlyT.al: o(0))) {
                firn Re en cted(=htrlyTsh');
    er.
        }
         
ue;
         }
        whiee (inde >= length) {
         e: soElegComndeue: pSe: soElegCom(aalue;
        /* istinbul ignor else*/lue;
            ert(typse: soElegComndid =undefined= '{nd];
            e   balue;
            }
        se: soElegComskpts.pse: soElegComaalue;
                  retse: soElegComsalue;
    }

    functue: pProgramBody() {
        bd, msch, sTal tte');

     on skipComme;pe;

    peekme;pe;

        sTrlyToke  okahean;ter.
    sen ctne r = fal');

    ed, ndeue: pSe: soElegComf();)) {
        retdelega q.3D) E  (delega q.createProgramBbd, tr ch, sTal taalue;
    }

    functfil(paTal tLocafunc(idy() {
        t, entr msial tr ial ts ke[]al)) {
    forhie ode  i < extra.ial tskins.le; ++i'\n') {
         ntr  = extra.ial ts[i];
            trlyTokeer) {
             ype:  ntr .    ,') {
              lue:  ntr .  luelue;
         alue;
            extra.ranesrker) {
            trlyT.ranes = entr .ranesalue;
            }
            extra.locrker) {
            trlyT.loc = entr .localue;
            }
        trlyTskpts.ptal taalue;
        }

    s.tra.ial ts(=htrlyTsalue;
    }

    functtrlyTize(ch (r opfuncs)er() {
        uascanSt,   }
        trlyT,   }
        trlyTste');

    trscanSt = scanSt;   }
        ert(typch (t!ch 'scanSt'wgt !(ch (tinstinstof scanSttrker) {
        ch (mbetrscanSt(ch (aalue;
        }

    delega q h SyntaxTreeDelega q;ter.
    se: so = ch (;   }
     e (in=de =se;
        NumbNumbe h = souins.le > 0) ? 1 :de =se;
        LineSn=de =se;
     ns.le = h = souins.le =se;
      okaheannde== 'sh');
    se=teokeer) {
        aly aIn: tr v,)) {
        labelSet: {},nd];
        i F   funcBd, : r = f,nd];
        i IicLitres: r = f,nd];
        i S   sw: r = f,nd];
        lastskipComLineS: -1urn;
     al  }

    s.tratar{};   }

       Optincsnm } cingcter.
    opfuncstaropfuncst||r{};   }

       Oypchurse we
collectnial ts(herecter.
    opfuncs.ial ts(=htr value;
    s.tra.ial ts(=h[]alue;
    s.tra.ial tizns=htr value;
    // The foly anSt two fieldsaits nec}, Mry  //compu qaessaRegex trlyTsklue;
    s.tra.openParenTrlyToke-1;lue;
    s.tra.openCurlyTrlyToke-1;llue;
    s.tra.ranes =  ert(typopfuncs.ranes =ch 'boo.Boo')ngthopfuncs.ranes;lue;
    s.tra.loc =  ert(typopfuncs.loc =ch 'boo.Boo')ngthopfuncs.local   }
        ert(typopfuncs.ckipCom =ch 'boo.Boo'ngthopfuncs.ckipCom'\n') {
         xtra.ckipComs(=h[]alue;
    }   }
        ert(typopfuncs.tolerant =ch 'boo.Boo'ngthopfuncs.tolerant'\n') {
         xtra.erowEs(=h[]alue;
    } ');

    tryt+i) {
        peekme;pe;

              okahean.    tych e = ToEOF(ch)) {
        er.
    reteatra.ial tsalue;
            }

         al tmbe  Rfiend];
            whi  okahean.    t!ch e = ToEOF(ch)) {
        er.
tryt+i) {
                 al tmbe  Rfiend];
              ca sw (lexhrowE)t+i) {
                 al tmbe  okahean;ter.
    d];
            extra.erowEsrker) {
                    extra.erowEskpts.p exhrowE)sh');
    er.
            // We have  //e   b0on ing firn  erowEh');
    er.
            // to avoid infin pee  opski) {
            er.
    e   balue;
                    } e+i) {
        er.
            t  exhrowE;   }
                    }
             ter.
    d];
    }

        fil(paTal tLocafunc(i;
            trlyTs = extra.ial tsalue;
            ert(typ xtra.ckipComs(!id =undefined= '{nd];
            trlyTskckipComs(=h xtra.ckipComsalue;
            }
            ert(typ xtra.erowEs(!id =undefined= '{nd];
            trlyTskerowEs(=h xtra.erowEs;
e);
        }
) {
    } ca sw (e(ch)) {
            t s;   }
      finally\n') {
         xtratar{};                       rettrlyTsalue;
    }

    functue: p(ch (r opfuncs)er() {
        program,etrscanStte');

    trscanSt = scanSt;   }
        ert(typch (t!ch 'scanSt'wgt !(ch (tinstinstof scanSttrker) {
        ch (mbetrscanSt(ch (aalue;
        }

    delega q h SyntaxTreeDelega q;ter.
    se: so = ch (;   }
     e (in=de =se;
        NumbNumbe h = souins.le > 0) ? 1 :de =se;
        LineSn=de =se;
     ns.le = h = souins.le =se;
      okaheannde== 'sh');
    se=teokeer) {
        aly aIn: tr v,)) {
        labelSet: {},nd];
        i F   funcBd, : r = f,nd];
        i IicLitres: r = f,nd];
        i S   sw: r = f,nd];
        lastskipComLineS: -1urn;
     al  }

    s.tratar{};   }
        ert(typopfuncs(!id =undefined= '{nd];
        s.tra.ranes =  ert(typopfuncs.ranes =ch 'boo.Boo')ngthopfuncs.ranes;lue;
        s.tra.loc =  ert(typopfuncs.loc =ch 'boo.Boo')ngthopfuncs.localue;
        s.tra.attachCkipCom =  ert(typopfuncs.attachCkipCom =ch 'boo.Boo')ngthopfuncs.attachCkipComenlue;
            s.tra.loc gthopfuncs.se: so !=l == 'wgt opfuncs.se: so !=l undefined '{nd];
             xtra.se: so = trscanSt(opfuncs.se: so);
e);
        }

                ert(typopfuncs.tolyTs =ch 'boo.Boo'ngthopfuncs.tolyTs '{nd];
             xtra.ial ts(=h[]alue;
            }
            ert(typopfuncs.ckipCom =ch 'boo.Boo'ngthopfuncs.ckipCom'\n') {
             xtra.ckipComs(=h[]alue;
            }
            ert(typopfuncs.tolerant =ch 'boo.Boo'ngthopfuncs.tolerant'\n') {
             xtra.erowEs(=h[]alue;
            }
            extra.attachCkipCom'\n') {
             xtra.ranes = tr value;
             xtra.ckipComs(=h[]alue;
             xtra.bottomRighmStacknde[]alue;
             xtra.trailingCkipComs(=h[]alue;
             xtra.leadingCkipComs(=h[]alue;
        }lue;
    } ');

    tryt+i) {
        programndeue: pProgramBoalue;
            ert(typ xtra.ckipComs(!id =undefined= '{nd];
            programkckipComs(=h xtra.ckipComsalue;
            }
            ert(typ xtra.ial ts(!id =undefined= '{nd];
            fil(paTal tLocafunc(i;
                programktrlyTs = extra.ial tsalue;
            }
            ert(typ xtra.erowEs(!id =undefined= '{nd];
            programkerowEs(=h xtra.erowEs;
e);
        }
) {
    } ca sw (e(ch)) {
            t s;   }
      finally\n') {
         xtratar{};                        retprogramalue;
    }

   Sync witht*.json manifestski) {
exports.versrestar'1.2.5'enlue;
exports.ial tizns=htal tiznenlue;
exports.ue: pndeue: p;   }

   Deep copyki) {/* istinbul ignor enexte*/lue;
exports.Syntax =      funct(idy() {
        namv,  ypestar{};   }

        ert(typObject.create =ch 'f   func')ch)) {
         ypestarObject.createBnull);   }
    }
   }
    forhinamv in Syntax(0))) {
            Syntax.hasOwnPropert (name (ch)) {
             ypes[name] h Syntax[name];
                }
    }
   }
        ert(typObject.freeze =ch 'f   func')ch)) {
        Object.freeze ert(sx++) {
    }ni) {
        retert(salue;
 Bootu
}ootu/* vim: set sw=4 ts=4 et tw=80 :e*/l
},{}],1:[f   func(require,module,exports){
     funct(proc}, ){u/* ue: pr gencLited by jison 0.4.13 */
/*
  R   res a Pe: pr objectnof ing foly anSt structure:ni) Pe: pr:ch)) {
yy: {}
  }ni) Pe: pr.proto    :ch)) {
yy: {},nd];
trace:
    func(),nd];
symbols_: {associapovetrist: namv ==> numbNu},nd];
tineTerls_: {associapovetrist: numbNumb=> name},nd];
produ funcs_: [...],nd];
performActres: r   functanonymous(yytext, yyins., yyiineno, yy, yyse=te, $$, _$),nd];
table: [...],nd];
    defActress: {...},nd];
pe: pErowE:
    func(strtahash),nd];
pe: p:
    func(input),ni) {
lexpr:ch)) {




EOF: 1,ter.
    par pErowE:
    func(strtahash),nd];
d];
setInput:
    func(input),n        i put:
    func(),n        u put:
    func(str),n        more:
    func(),n        less:
    func(n),ter.
    pastInput:
    func(),n        upcomingInput:
    func(),n        showPositres: r   func(),n        uon _m } c: r   func(regex_m } c_array, rule_eAt(in,n        next:
    func(),n        lex:
    func(),n        begis: r   func(conditres),ter.
    popState:
    func(),n        _currentRules: r   func(),n        uopState:
    func(),n        pts.State:
    func(conditres),tter.
    opfuncs:ch)) {
         aness: boo.Boo {
        (opfuncal: tr vmb=>  al tmlocafunc info will include a .ranes[] membNu)  }

        flex:
boo.Boo {
          (opfuncal: tr vmb=> flex-like lexnSt behaviour where ing rulesaits uon ed exhauspovely  //findting lonesstnm } c)  }

        backtrack_lexpr:cboo.Boo {(opfuncal: tr vmb=> lexpr regexesaits uon ed in order ar) forheachnm } cing regexting a functch (tis invoked;ting lexpr tineTertes ing scan when a  al tmis     reed by ing a functch ()  }

    },tter.
    performActres: r   func(yy, yy_, $avoiding_name_collisuncs, YY_START),n        rules: [...],nd];
    conditress: {associapovetrist: namv ==> set},nd];
}
  }ni
   al tmlocafunc info (@$, _$, etc.):ch)) {
firn _iine: T,   }
last_iine: T,   }
firn _column: T,   }
last_column: T,   }
ranes: [ch, s_numbNu, end_numbNu]       (where ing numbNusaits eAt(i s into ing i put scanSt, regular zero-based)
  }ni
   he par pErowE r   functreceivesai 'hash' objectnwithtthese membNus forhlexpr ar) ue: pr erowEs:ch)) {
text:
       (m } ced
text)  }

 al t:
      ( he produ ed
teneTerl ual tr lf any)  }

iine: 
      (yyiineno)
  }n      whue: pr (grammar) erowEs will also providetthese membNus, i.e. ue: pr erowEs delivpr a superset of attributes:ch)) {
loc:  
      (yyilocr
    s.Unexed:c   (scanSt describnSt tng set of s.UnexedttrlyTsr
    recoverable: (boo.Boo: TRUE when  he par prahas a erowE recovery rule available forh== 'tparticular erowE)
  }n*/
    parsNumbe     func(){
    parsNumbe{trace:
    func
trace(idy },tyy: {},nsymbols_: {"erowE":2,"JSON_PATH":3,"DOLLAR":4,"PATH_COMPONENTS":5,"LEADING_CHILD_MEMBER_EXPRESSION":6,"PATH_COMPONENT":7,"MEMBER_COMPONENT":8,"SUBSCRIPT_COMPONENT":9,"CHILD_MEMBER_COMPONENT":10,"DESCENDANT_MEMBER_COMPONENT":11,"DOT":12,"MEMBER_EXPRESSION":13,"DOT_DOT":14,"STAR":15,"IDENTIFIER":16,"SCRIPT_EXPRESSION":17,"INTEGER":18,"END":19,"CHILD_SUBSCRIPT_COMPONENT":20,"DESCENDANT_SUBSCRIPT_COMPONENT":21,"[":22,"SUBSCRIPT":23,"]":24,"SUBSCRIPT_EXPRESSION":25,"SUBSCRIPT_EXPRESSION_LIST":26,"SUBSCRIPT_EXPRESSION_LISTABLE":27,",":28,"STRING_LITERAL":29,"ARRAY_SLICE":30,"FILTER_EXPRESSION":31,"QQ_STRING":32,"Q_STRING":33,"$accept":0,"$end":1},
tineTerls_: {2:"erowE",4:"DOLLAR",12:"DOT",14:"DOT_DOT",15:"STAR",16:"IDENTIFIER",17:"SCRIPT_EXPRESSION",18:"INTEGER",19:"END",22:"[",24:"]",28:",",30:"ARRAY_SLICE",31:"FILTER_EXPRESSION",32:"QQ_STRING",33:"Q_STRING"},
produ funcs_: [0,[3,1],[3,2],[3,1],[3,2],[5,1],[5,2],[7,1],[7,1],[8,1],[8,1],[10,2],[6,1],[11,2],[13,1],[13,1],[13,1],[13,1],[13,1],[9,1],[9,1],[20,3],[21,4],[23,1],[23,1],[26,1],[26,3],[27,1],[27,1],[27,1],[25,1],[25,1],[25,1],[29,1],[29,1]],
performActres: r   functanonymous(yytext, yyins., yyiineno, yy, yyse=te{/* a func[1] */, $${/* vstackn*/, _${/* lstackn*/
/**/)ch)/*h== 't== yyvaln*/
    !yy.asm'\n') {
yy.asm = _ast;
    _ast.in poalizN(i;
}

    $0 = $$uins.le - 1;
s   sw  yyse=te'\n'    c1:yy.asm.set({  ar expres: {  ype: "root",   lue: $$[$0] } });
yy.asm.unshifmme;     retyy.asm.yield()
e   bal    c2:yy.asm.set({  ar expres: {  ype: "root",   lue: $$[$0-1] } });
yy.asm.unshifmme;     retyy.asm.yield()
e   bal    c3:yy.asm.unshifmme;     retyy.asm.yield()
e   bal    c4:yy.asm.set({ operitres: "membNu", scope: "child",  ar expres: {  ype: "ien.Identi",   lue: $$[$0-1] }});
yy.asm.unshifmme;     retyy.asm.yield()
e   bal    c5:
e   bal    c6:
e   bal    c7:yy.asm.set({ operitres: "membNu" });
yy.asm.pts.p)
e   bal    c8:yy.asm.set({ operitres: "subscript" });
yy.asm.pts.p) 
e   bal    c9:yy.asm.set({ scope: "child" })
e   bal    c10:yy.asm.set({ scope: "descendant" })
e   bal    c11:
e   bal    c12:yy.asm.set({ scope: "child", operitres: "membNu" })
e   bal    c13:
e   bal    c14:yy.asm.set({  ar expres: {  ype: "wildcard",   lue: $$[$0] } })
e   bal    c15:yy.asm.set({  ar expres: {  ype: "ien.Identi",   lue: $$[$0] } })
e   bal    c16:yy.asm.set({  ar expres: {  ype: "script_ ar expres",   lue: $$[$0] } })
e   bal    c17:yy.asm.set({  ar expres: {  ype: "numeric_lricLit",   lue: ue: pant($$[$0]) } })
e   bal    c18:
e   bal    c19:yy.asm.set({ scope: "child" })
e   bal    c20:yy.asm.set({ scope: "descendant" })
e   bal    c21:
e   bal    c22:
e   bal    c23:
e   bal    c24:$$[$0]uins.le > 1? yy.asm.set({  ar expres: {  ype: "unres",   lue: $$[$0] } }) :h== '.$ = $$[$0]
e   bal    c25:== '.$ = [$$[$0]]
e   bal    c26:== '.$ = $$[$0-2].concat($$[$0])
e   bal    c27:== '.$ = {  ar expres: {  ype: "numeric_lricLit",   lue: ue: pant($$[$0]) } }; yy.asm.set(== '.$)
e   bal    c28:== '.$ = {  ar expres: {  ype: "scanSt_lricLit",   lue: $$[$0] } }; yy.asm.set(== '.$)
e   bal    c29:== '.$ = {  ar expres: {  ype: "sliqu",   lue: $$[$0] } }; yy.asm.set(== '.$)
e   bal    c30:== '.$ = {  ar expres: {  ype: "wildcard",   lue: $$[$0] } }; yy.asm.set(== '.$)
e   bal    c31:== '.$ = {  ar expres: {  ype: "script_ ar expres",   lue: $$[$0] } }; yy.asm.set(== '.$)
e   bal    c32:== '.$ = {  ar expres: {  ype: "fil(pa_ ar expres",   lue: $$[$0] } }; yy.asm.set(== '.$)
e   bal    c33:== '.$ = $$[$0]
e   bal    c34:== '.$ = $$[$0]
e   bal}
},
table: [{3:1,4:[1,2],6:3,13:4,15:[1,5],16:[1,6],17:[1,7],18:[1,8],19:[1,9]},{1:[3]},{1:[2,1],5:10,7:11,8:12,9:13,10:14,11:15,12:[1,18],14:[1,19],20:16,21:17,22:[1,20]},{1:[2,3],5:21,7:11,8:12,9:13,10:14,11:15,12:[1,18],14:[1,19],20:16,21:17,22:[1,20]},{1:[2,12],12:[2,12],14:[2,12],22:[2,12]},{1:[2,14],12:[2,14],14:[2,14],22:[2,14]},{1:[2,15],12:[2,15],14:[2,15],22:[2,15]},{1:[2,16],12:[2,16],14:[2,16],22:[2,16]},{1:[2,17],12:[2,17],14:[2,17],22:[2,17]},{1:[2,18],12:[2,18],14:[2,18],22:[2,18]},{1:[2,2],7:22,8:12,9:13,10:14,11:15,12:[1,18],14:[1,19],20:16,21:17,22:[1,20]},{1:[2,5],12:[2,5],14:[2,5],22:[2,5]},{1:[2,7],12:[2,7],14:[2,7],22:[2,7]},{1:[2,8],12:[2,8],14:[2,8],22:[2,8]},{1:[2,9],12:[2,9],14:[2,9],22:[2,9]},{1:[2,10],12:[2,10],14:[2,10],22:[2,10]},{1:[2,19],12:[2,19],14:[2,19],22:[2,19]},{1:[2,20],12:[2,20],14:[2,20],22:[2,20]},{13:23,15:[1,5],16:[1,6],17:[1,7],18:[1,8],19:[1,9]},{13:24,15:[1,5],16:[1,6],17:[1,7],18:[1,8],19:[1,9],22:[1,25]},{15:[1,29],17:[1,30],18:[1,33],23:26,25:27,26:28,27:32,29:34,30:[1,35],31:[1,31],32:[1,36],33:[1,37]},{1:[2,4],7:22,8:12,9:13,10:14,11:15,12:[1,18],14:[1,19],20:16,21:17,22:[1,20]},{1:[2,6],12:[2,6],14:[2,6],22:[2,6]},{1:[2,11],12:[2,11],14:[2,11],22:[2,11]},{1:[2,13],12:[2,13],14:[2,13],22:[2,13]},{15:[1,29],17:[1,30],18:[1,33],23:38,25:27,26:28,27:32,29:34,30:[1,35],31:[1,31],32:[1,36],33:[1,37]},{24:[1,39]},{24:[2,23]},{24:[2,24],28:[1,40]},{24:[2,30]},{24:[2,31]},{24:[2,32]},{24:[2,25],28:[2,25]},{24:[2,27],28:[2,27]},{24:[2,28],28:[2,28]},{24:[2,29],28:[2,29]},{24:[2,33],28:[2,33]},{24:[2,34],28:[2,34]},{24:[1,41]},{1:[2,21],12:[2,21],14:[2,21],22:[2,21]},{18:[1,33],27:42,29:34,30:[1,35],32:[1,36],33:[1,37]},{1:[2,22],12:[2,22],14:[2,22],22:[2,22]},{24:[2,26],28:[2,26]}],
    defActress: {27:[2,23],29:[2,30],30:[2,31],31:[2,32]},
par pErowE:
    func par pErowE(strtahash)\n') {
    hash.recoverable)ch)) {
    == '.trace(str)alue;
    } e+i) {
        t new ErowE(straalue;
  },
par p:
    func par p(input)e+i) {
    selfs=hthisr ch,cknde[0], vstackn= [null], lstackn= []tauable = == '.table, yytexttar'', yyiinenon=de, yyins.n=de, recoveris.n=de, TERROR = 2,
EOF = 1;lue;
    argstarlstackusliqu. all(argupComs, 1aalue;
== '.lexpr.setInput(input)alue;
== '.lexpr.yy = == '.yyalue;
== '.yy.lexpr = == '.lexpralue;
== '.yy.parsNumbe== ';
        ert(typ== '.lexpr.yylloc =c =undefined= '{nd];
    == '.lexpr.yylloc =r{};     }lue;
    yyloc =r== '.lexpr.yylloc;     lstackupts.pyyloc);lue;
     aness =r== '.lexpr.opfuncs(gtht= '.lexpr.opfuncs.ranes';
        ert(typ== '.yy.parsNErowE =ch 'f   func')ch)) {
    == '.parsNErowE =p== '.yy.parsNErowEalue;
    } e+i) {
       '.parsNErowE =pObject.getProto    Of(== ').parsNErowEalue;
   }

    functuopStack(n)ch)) {
    stacku ns.le = htacku ns.le - 2 * Tsh');
    vstacku ns.le = vhtacku ns.le - Tsh');
    lstacku ns.le = lhtacku ns.le - Tsh');
   }

    funct  Rfier() {
        ual t;');

    trlyTokeself.lexpr.  Rfie||
EOF;   }
        ert(typtrlyTo!id =numbNu'ngth) {
        trlyTokeself.symbols_[trlyT]e||
ual t;');

                  rettrlyT;     }lue;
    symbol) {
 '    programkeroyf.symbols_[tr*/, $$, a, r,    !yy}lue, p,h = ,(strSls_[trrlyTsr
 ;
    kahean.expr  stacku ns.le 
    le - [le - Tsh');
   1]    ert(typtrlyrowEress: {27:[2,2[le 
 ]      trlyTokese()  }

parsNErress: {27:[2,2[le 
 ];   } eh)) {
            ieRe en ct '    gth) {
  ');

soElegC'    gthd= '{nd];
            programkerC'    gt;
              ca s}   trlyTokese()  }

parxtta[le 
 ]expr.xtta[le 
 ][C'     }   }
        ert(ty      ert(typ xtra.erow()  }

pthd= '{nd];
  ');
!()  }
Tsh');
 );
!()  }
[0]          programkerv  }n*/Strineno;       s.Unex(=,EGAL');sh');           xtra.leadin Sypar) .xtta[le 
 ]                  ieRe en ct, yyte {2:"erow[p]exprp >2,
EOF                   extra.erowEsL');shc);lue'\'    v yyte {2:"erow[p]e+ '\' )                }
             ter.
    d];
    paramskptsn ct, yytnput(ins: r   func                  extra.n*/Strinento   overy r() {ine     
  }n    T.en)e+ ':\n    v yytnput(ins: r   func()e+ '\s(td =usng ame;   ');shcjoin(', ')e+ ', got \'    t, yyte {2:"erow[C'      );
C'    )e+ '\'             } else isSen                 extra.n*/Strinento   overy r() {ine     
  }n    T.en)e+ ': (  okahean     
C'    gthde;
 ? 'ue;
ofnSt, r' : '\'    t, yyte {2:"erow[C'      );
C'    )e+ '\'              }
                defFouErowE =pObject.(n*/Str,              al tmbe  o  (m v yytnput(ixt)  ,            al tmbe  okahe: , yyte {2:"erow[C'      );
C'    ,            al tmbe     (yy.yylloc;     l yyse=            al tmbe     (y;
   =            al tmbe     (scanSt   (scan           }
                ca s}   trlyTon ct()  }
[0]f scanSttrkeA_eAtexpr()  }
Tsh');
 >en)e        t s;   }
   straalue;
nto   o func pm defsI r()  }
s possi.tabat.le 
 :     le 
  + ', okahe:     l'    )}
    er.
sen ctne pre=te'\n()  }
[0]          prasm.set   se=te.labelSeloc);luel'    )}
    er.
u ns.le = vaalue;yylloc;      al t    labeledBd, le = vaalue;yylloc;     l     aness=te.labelSeloc);lue*/, $${/*  aness=te.label'    gt;    se=teokeerirn Re enogramkeroyf.sy                  ex, recover;yylloc;     le      ert(ty      ex,  yyiine;yylloc;      al     ert(ty      ex, , yyins.n.yylloc;     l yyse    ert(ty      ex, ,lexpr.yylloc;     lstackupts=teokeerirn Re en=de, TERROde =s             al tmbe  n=de, TERR--            }
            } e+i) {
        er.
    !firn l'    gt;ogramkeroyf.sy        programktrlyramkeroyf.sygt;    se=teokeerirn         } e+i)
              asm.set   l Rfienlue;


parsNErs_: [0,[3,1][*/, $${/*][1          xtra.   !y]
e  .le = [.le - Tsh');
   len          xtra.   !y]_$            ype:  ntr: T,   }
las le = [.le - Tsh');
   (;


|| 1)].: T,   }
l=            al tm T,   }
fir le = [.le - Tsh');
   1]. T,   }
f,        ype:  ntr: T,     }
ran le = [.le - Tsh');
   (;


|| 1)].: T,     }
r=            al tm T,     }
ran le = [.le - Tsh');
   1]. T,     }
r    alue;
            extra.rane                        ex,  !y]_$r value;
[            al tmbe   le = [.le - Tsh');
   (;


|| 1)].mbNu) 0],            al tmbe   le = [.le - Tsh');
   1].mbNu) 1]            al tm         }
            extra.y.parsNErres: r   func.apply(,  !y,
[            al tmins., y               ex, reco,   ert(ty      ex, , yyin,           defFouErowEyy,           defFou*/, $${/*          lue:  ntrle - =            al tm le -             a$[$0])
e acku)         ert(typ xtra.ckiprfined= '{nd];
            programkeryT;    r        }
            ert(typ xtlen      er.
sen ctne tr uable u. all(argu(0, -1 *e;


* 2             }
    null], lsvu. all(argu(0, -1 *e;

             }
    ]tauable lu. all(argu(0, -1 *e;

             }
}aness=te.labelSeloc);luersNErs_: [0,[3,1][*/, $${/*][0])}
    er.
u ns.le = vaalue   !y]
t    labeledBd, le = vaalue,  !y]_$t    labeledBd,strSls_[
parxtta[le - [le - Tsh');
   2]][le - [le - Tsh');
   1]] aness=te.labelSeloc);luestrSls_[t    labeledBd,
              asm.s3:       retue: pState             x}
    symbol pState      }};$$uin_;
    {r pE(i;
}

   (),n        t:
     sNEr_node;
        }l sNEr_node }lue;
     sNEr_stash
          perfsec(),n       prop         in Sy$uinkar) prop    sNEr_node[k]gt;ogops[k     }l pState sNEr_node      perfnode(),n       obj  hash.recov 1aalue;
.) {
     sNEr_node }lobj    }l pState sNEr_node      perf);lu(),n        t:
     sNEr_node;c);luersNEr_node)    }l sNEr_node }lue;
    perf     re(),n        t:
     sNEr_node;c     retrsNEr_node)    }l sNEr_node }lue;
    perf  bal(),n        t:
    $uin_node;
   sNEr_node;    }l sNEr(i;
}

    $0   }l pState_node;    }
}set sby jison 0.4.13 */-lex 0.2.1 sNumbe  '.lexpr){
    parsNumbe{ '.lexpr{

.
  1,
E:
    func ar pErowE(strtahash)\n') {
    hash.rkptsn ct, yytbe== ';
 )e        t s;   }yytbe== ';
 .(strtahash)\n') {
   ;   } eh)) {
            ieRe eErowE(straalue;
  },
par p   x}
    s,

// resets tineTerte, sets straSt, r
    func(proc}, ){u {
    selfs=  }l sNEr_St, re=aSt, r;elfs=  }l sNEr_func
   sNEr_lexpr:cbo
parsNErronese;
    se=te.i F  }yytbe, yyins.n.yyll, recoverise=te.i F  }yytbe yyiine;yyllxt)  }

ne;yyllxt)  ineno;       s.;yyll: {associalue;
   'INITIAL']se=te.i F  }yytbe,    }lu
   ype:  ntr: T,   }
las1    firn Re en cted    }
ran0    lastskipComLin  }
las1    firn Re en T,     }
ran0
lue;
            exn ct, yytnes';
        )e        t s;   }yytbe,   r value;
[0,0 }   }
        ert(ty, yytnffse
     ns.le = h pState sNE;
    s,

// icoloTBsr erore: pr ooneschar from scanSt, r
ifunc(proc}, ){u      ual t;');
  ine sNEr_St, r[0]se=te.i F  }yytbe yyii+=   se=te.i F .yyll, reco++;   ert(ty, yytnffse
++;   ert(ty, yytxt)  i+=   se=te.i F .yyllxt)  }

+=   se=te.i F mbe{ ine;
  chlxt)  (/(?:\r\n?|\n).*/g lse hen ctngth ine;)e        t s;   }yytbe, yyin++;   ert(tys;   }yytbe,   rmLin  }
l++;   ert(ty {
            ieRe eEryytbe,   rmLin    }
r++;   ert(ty        exn ct, yytnes';
        )e        t s;   }yytbe,   r valu[1]++;   ert(ty  elfs=  }l sNEr_St, re=a sNEr_St, rl(argu(1     retdelega q.3  se=te.s,

//      re ooneschar (oet of) {
  i put scanSt, r
ufunc(proc}, ){uch      ual t;');
;


pache;
      okaheannmbe{ ine;
  chlsplit(/(?:\r\n?|\n)/g lselfs=  }l sNEr_St, re=a  i+l sNEr_St, rse=te.i F  }yytbe yyiine;yyllbe yyi. });tr(0, ;yyllbe yyi.sh');
   len
            di//.yyll, recov-t;
 n;   ert(ty, yytnffse
v-t;
 n;   ert(tymbe{t;
 ine;
  .yyllxt)  lsplit(/(?:\r\n?|\n)/g ls  ert(ty, yytxt)  i  .yyllxt)  ls});tr(0, ;yyllxt)  lsh');
   1)se=te.i F .yyllxt)  }

ne;yyllxt)  }
ls});tr(0, ;yyllxt)  edlsh');
   1)sese hen ctngth ine;lsh');
   1)e        t s;   }yytbe, yyinv-t;
ine;lsh');
   1;   ert(ty        ex =r==s.n.yyll, r   r valulselfs=  }l sNErbe,    }lu
   ype:  ntr: T,   }
las.yyll, r   r: T,   }
l=            amLin  }
las }yytbe, yyinv+s1    firn Re en cted    }
ran.yyll, r   r: T,     }
r=            a T,     }
ran ine;
?           }
    h ine;lsh');
 pthdt;
 ine;lsh');
 ?n.yyll, r   r: T,     }
r    )            al tmb+dt;
 ine;[t;
 ine;lsh');
 -;
ine;lsh');
]lsh');
 -;
ine;[> 1? yy.aser.
er.
    retu.yyll, r   r: T,     }
r   lenal  }

    s.tratar{}n ct, yytnes';
        )e        t s;   }yytbe,   r value;
[rkn= [rkn=i+l sNEr, recov- len          x}e=te.i F .yyll, recoine;yyllbe yyi.;
      okaheann pState sNE;
    s,

// Wr prComsed from */, $$, cachecter.
 }

 al r eroappends itr() ;
exp*/, $$
func(proc}, ){u      ual t; sNEr_func
               x pState sNE;
    s,

// Wr prComsed from */, $$, sig"ero tineTertes hatyvaln*able fairo toter.
  scanSt, regCousaits
expegexting able  c_arr)res:uld bn order ar)stch e
reoto (proc}, ){u      ual t;n ct, yytnes';
  lexpr:cboo.Boo )e        t s;   }yyt_lexpr:cbo
par            x}{
            ieRe e pState sNEr(strtahash)'Lexicalovery r() {ine     
 }yytbe, yyinv+s1)e+ '. You   alonlying lex reoto ()ar) .ineTertesar prahasTertesisly anSt lexpr:cboing attrua2.5'e(nes';
  lexpr:cboo.Boo 
par   ).\n    v yytns: r   func(),              al tmo  (m "",
       al tmbe  okahe: cted,
       al tmbe     (yy.yyllbe, yyin
      }
                     rettrlyT;     sNE;
    s,

// retainwEh');
nscharactxpr y anSt egext
func(proc}, ){un      ual t; sNErufunc(.yyllxt)  lsargu(n)       s,

// displays alreadyter.
 }

St, regr ero } ciery re);
   s

    func(proc}, ){u      ual t;');
p;
    ;yyllxt)  }
ls});tr(0, ;yyllxt)  edlsh');
   ;yyllxt)  lsh');
     retdelega q.3(p;
 Tsh');
 >e20 ? '...':'')e+ p;
 Ts});tr(-20).replue;
/\n/g, ""       s,

// displays put:
   
St, regr ero } ciery re);
   s
put:
    func(idy() {
        namv,  ypesyyiine;yyllxt)  lse hen ctngthnyyi.sh');
 < 2 =s             anyyii+=  sNEr_St, rl(});tr(0, 20-nyyi.sh');
               retse: soEleghnyyi.(});tr(0,2 =s+thnyyi.sh');
 >e20 ? '...' : '')).replue;
/\n/g, ""       s,

// displays nSt charactxp pos func rulesaits aviour very r(ces: rdegr ero } ciery re);
   s
es: r   func(proc}, ){u      ual t;');
pnc
   sNEr
    func            ');
 gt; eweA_eAt(pr 0) ? 1 :+s1)cjoin("-"     retdelega q.3pnc
  v yytput:
    func()e+ "\n" + ce+ "^"      s,

// orderahasTertd okahe: ega q.3FALS par proveiater.
 , otherwiselyT;     }lue
: r   func(proc}, ){uer.
 , to ingd_able      ual tr ldnde== '
   al tmbe     (       n cted: lexpup s.tratar{}n ct, yytnes';
  lexpr:cboo.Boo )e        t s;  // s b0ocono  (     n cted: lexpup            ype:  ntrbe, yyinyy.yyllbe, yyin,   ert(ty      ex, ,   (y            firn Re en cted  }
las.yyll, r   r: T,   }
l=            a       amLin  }
las }yyt T,   }
f,        ype:  ntre en cted    }
ran.yyll, r   r: T,     }
r=            a       a T,     }
ranEryytbe,   rmLin    }
r           }
     ,            al tmins., :e;yyllbe yyi,            al tm func(r;yyllxt)  ,            al tm funcloc:;yyllxt)  es,            al tm funcldc:;yyllxt)  edy               ex, reco: .yyll, recoy               exnffse
:y, yytnffse
y               ex_func() sNEr_funcy               ex_ func() sNEr_St, ry               ex, :uErowEyy,           defFou: {associalue;:.;yyll: {associalue;l(argu(0),           defFourone:arsNErrone    alue;
            extra.rane, yytnes';
        )e        t s;  ed: lexpuptbe,   r value;
 }yytbe,   r valul(argu(0)        }
    }
   }
        ert(ty ine;
  xt)  [> 1xt)  (/(?:\r\n?|\n).*/g lse hen ctngth ine;)e        t s;   }yytbe, yyini+= 
ine;lsh');
         x}e=te.i F .yyll, r    }lu
   ype:  ntr: T,   }
las.yyll, r   r T,   }
f,        ype: mLin  }
las }yytbe, yyinv+s1    firn Re en cted    }
ran.yyll, r   rmLin    }
r=            a T,     }
ran ine;
?           }
    al tmbe     ( [
ine;lsh');
   1]lsh');
 -;
ine;[
ine;lsh');
   1]lxt)  (/\r?\n?/)[> 1? yy.aser.
er.
    retu     ieRe eEryytbe,   rmLin    }
r + xt)  [> 1? yy.a
lue;
            ex }yytbe yyii+= xt)  [> ;   ert(ty, yytxt)  i+= xt)  [> ;   ert(ty, yytxt)  e;
  xt)  ;e=te.i F .yyll, recoine;yyllbe yyi.;
      okaheannn ct, yytnes';
        )e        t s;   }yytbe,   r value;
[, yytnffse
yy, yytnffse
v+.n.yyll, reco          x}e=te.i F .yyll_func
  
    se=te.i F  }yyt_lexpr:cbo
pa
    se=te.i F  }yyt_St, re=a sNEr_St, rl(argu(xt)  [> 1? yy.a)se=te.i F .yyllxt)  }

+= xt)  [> ;   ert(ty,f.symborsNErres: r   func.Coms,knde[0ErowEyy,cknde[0to ingd_able,.;yyll: {associalue;[;yyll: {associalue;lsh');
   1])    ert(typtrlyrowEronesxpr.opfu_ {
    selfs=  }li F .yyllronese;
    se=te.i F         exn ct,
             ieRe e pState                isSen ctMo }yyt_lexpr:cbo)e        t s;  // n=de, Tocono  (     n cted: in Sy$uinkar) lexpup              throwETois[k]gt;lexpup[k     }l  }
            extra.ypState
    s // nulh ()  }

 omsed reoto ()armplyt of s.Unyyiinulh es:uld bn order ar)stch e
            retse: soEleg
    se=te.s,

// retElegs
expegextar) St, r
func(proc}, ){u      ual t;n ct, yytrone)         ieRe e pState sNEr       ert(ty        exn ct!.opfu_ {
    selfs=  }li F .yyllronese;             x}
   ual tr ldnde== '
   al tmbe  xt)  ,            atempMt)  ,            ato in;       exn ct!.opfu_func)e        t s;   }yytbe yyiineno;   ert(tys;   }yytxt)  ineno;       s.        ex =r==on ed=a sNEr_es: r   func            in Sy$uin extra.ial =on e+i'\n') {i++)e        t s;   empMt)  e=a sNEr_St, rlxt)  ( sNEr=on e[=on e[i]]         ert(typ xtrempMt)  e&&( ' ++i)');

empMt)  [> 1? yy.asm.xt)  [> 1? yy.a)              throwExt)  i  .empMt)  ckupts=teokeerirn Rse;
   i;];
    paramskptsn ct, yytnes';
  lexpr:cboo.Boo )e        t s;    ert(ty,f.symborsNEr: r   functrempMt)  (in,n e[i])d];
            extra.erow=numbNu'ng
                      extra.erow pState                     } e+i) {
    ctMo }yyt_lexpr:cbo)e        t s;        throwExt)  i  
    se=te.i F           defFou: {tinu s // nulh ()  }

 omsed reoto ()armplyt ofa nulh MISxt)  l               } e+i) {
        er.
            t  exh//{
   :ot rirecpaexesaitsulh which icoloTBsrSt, re memoutteneTert ofa =numbN(e.g. whitespace)               extra.erow pState
    se=te.i F           de}           } else isSen ctMo!, yytnes';
  lexn)e        t s;        th
                    }      
ue;
         }
       extra.erow
          trlyTokeself.symborsNEr: r   functmt)  (in,n e[ise;
]         ert(typ xtrnumbNu'ng
                      ex pState                   }
      t  exh//{
   :ot rirecpaexesaitsulh which icoloTBsrSt, re memoutteneTert ofa =numbN(e.g. whitespace)              pState
    se=te.i F         exn ct, yyt_St, re=== ""          ieRe e pState sNEr       ert(ty {
            ieRe e pState sNEr(strtahash)'Lexicalovery r() {ine     
 }yytbe, yyinv+s1)e+ '. Unn=deg
exp

 al .\n    v yytns: r   func(),              al tmo  (m "",
       al tmbe  okahe: cted,
       al tmbe     (yy.yyllbe, yyin
      }
        ar p   x}
    s,

// retElegs
expegexta hatyE reco }lue
oo { Rfier() {
        ual t;');
=s.n.yylls
ex  lse hen ctngthr          ieRe e pStater    ert(ty {
            ieRe e pState sNEr
              }
    s,

// ()  vcan wa; ewexesait: {associ le 
  ();lun when  ewexesait: {associ le 
  oput scan: {associ le ck)
 func( Rfier()  func),tter.
        ual t; sNEr: {associalue;l);lue,tter.
   se=te.s,

// poprahas  cteni)ly ()  veexesait: {associ le 
  off scan: {associ le ck
    func(opStack(n)ch)) te       namv,  ypess.n.yyll: {associalue;lsh');
   1lse hen ctngthnOde =s             a pState sNEr: {associalue;l)op()    ert(ty {
            ieRe e pState sNEr: {associalue;[0 }   }
        ers,

// pneTerlrahasTertesnulh eet which ecpa)  veearticue es: r  ly ()  veexesait: {associ le 
 
les: r   func(opStack(n_es: r   func       ual t;n ct, yyt: {associalue;lsh');
 xpr.opfu: {associalue;[;yyll: {associalue;lsh');
   1])         ieRe e pState sNEr: {associs[.opfu: {associalue;[;yyll: {associalue;lsh');
   1]]r=on e    ert(ty {
            ieRe e pState sNEr: {associs["INITIAL"]r=on e    ert(ty 
    s,

// retElegcue es: r  ly ()  veexesait: {associ le 
 ;l tmis n Rse;
  1aalue; ecpese memd itrpneTerl when N-ths  cteni)t: {associ le 
  }

iiorh== 't
t   func(opStack(nt   funcun      ual t;ss.n.yyll: {associalue;lsh');
   1 - Math.abs(

|| 0)lse hen ctngthnOd=e =s             a pState sNEr: {associalue;[n]    ert(ty {
            ieRe e pState"INITIAL"          }
    s,

// (liar ar)  func),tter.
   

    func(opStack(n)    func),tter.
        ual t; sNEr func),tter.
   ;
    s,

// retElegcue  name},legCtcan wes: r  ly n  erowle ck
Ctcanalue;S   (opStack(nCtcanalue;S          ual t; pState sNEr: {associalue;l;
      okah},
)) {
     }ctres: r   functanonymous(yytext, yyin,dingname_collisuncs, YY_START)n       *h== 't==umbe{YYSTATE=n       yyse=te'(name_collisuncs, YY_START:yy.asm.s0: pState4  c19:yy.asm.s: pState14  c2:yy.asm.set pState12  c3:yy.asm.uns pState15  c4:yy.asm.set pState16  c5:
e   bal   pState22  c6:
e   bal   pState24  c7:yy.asm.set pState28  c8:yy.asm.set pState30  c9:yy.asm.set pState18  c10:yy.asm.set({_tbe yyiine({_tbe yyi.(});tr(1,({_tbe;
  -2yy.asm.yie32;  c11:
e   bal  ({_tbe yyiine({_tbe yyi.(});tr(1,({_tbe;
  -2yy.asm.yie33;  c12:yy.asm.set pState17  c13:
e   bal  asm.yie31},
table: [{3.],nd];
/^(?:\$)/,/^(?:\.\.)/,/^(?:\.)/,/^(?:\*)/,/^(?:[a-zA-Z_]+[a-zA-Z0-9_]*)/,/^(?:\[)/,/^(?:\])/,/^(?:,)/,/^(?:((-?(?:0|[1-9][0-9]*)))?\:((-?(?:0|[1-9][0-9]*)))?(\:((-?(?:0|[1-9][0-9]*)))?)?)/,/^(?:(-?(?:0|[1-9][0-9]*)))/,/^(?:"(?:\\["bfnrt/\\]|\\u[a-fA-F0-9]{4}|[^"\\])*")/,/^(?:'(?:\\['bfnrt/\\]|\\u[a-fA-F0-9]{4}|[^'\\])*')/,/^(?:\(.+?\)(?=\]))/,/^(?:\?\(.+?\)(?=\]))/],
: {associapov"INITIAL":{".],nd":[0,1,2,3,4,5,6,7,8,9,10,11,12,13]}".ranesive":    }}
}seasm.yie
== '.y})()  = ';
 ..Boo 
pa
== '.ynonymous(ectnof        .yyllbe }lue;
}
to    :ch)) {
yy  }

   r;= ';
 .P ';
    P ';
 seasm.yie eweP ';
 se})()  

p xtra.ckiprule,exfined= '{nd];
   xpr.a.erowEs   fufined= '{nd];
      : pndeue: p; r  }

   r; : pndeueP p; r  }

   r.P
   r; : pndeue: p;   }proc}, ){u   lega q.3p ';
 .(strt.apply(p ';
 ,  1aalue;s);    : pndeuemainw }proc}, ){ue;
onjsMain acku) hash.recov!acku[1])         ieicolole.log('U
   : '+acku[0]+' FILE            /* ue: .exit(1     resymbol) {
 scanSt(orule,ex('fs').readFile*.js(rule,ex('path').norm

    acku[1]), "utf8"$0   }l pState: pndeue: p; re: p; ();
      };
p xtra.ckiports){fined= '{nd];
   xprrule,exemainw ==ports){)     : pndeuemainu/* ue: .argvl(argu(1 $0 = }vim:.Coms,knde[rule,ex('_/* ue: '))f   "_/* ue: ":15,"fsER_EXPpathDOT"}],2(require,module,exports){
     functorts){.Es   fuf}lu
  ",   lue: : "[a-zA-Z_]+[a-zA-Z0-9_]*",
  integ: : "-?(?:0|[1-9][0-9]*)",
  qq_f) {
 : "\"(?:\\\\[\"bfnrt/\\\\]|\\\\u[a-fA-F0-9]{4}|[^\"\\\\])*\"",
  q_f) {
 : "'(?:\\\\[\'bfnrt/\\\\]|\\\\u[a-fA-F0-9]{4}|[^\'\\\\])*'" };
f   fun3(require,module,exports){
     funct) {
dictt(orule,ex('./dict    ) {
fst(orule,ex('fs')  ) {
rowEs w   {r pE func(){
   ual trmacro        aness: boesc: "\\\\",            atot:
dict.integ: ,tter.
    performAct.],nd];
            a["\\$", " pState':"DOT"'"*          lue:["\\.\\.", " pState':""STAR'"*          lue:["\\.", " pState':""'"*          lue:["\\*", " pState'    '"*          lue:[dict.i,   lue: , " pState'",17:"SCRI'"*          lue:["\\[", " pState'['"*          lue:["\\]", " pState']'"*          lue:[",", " pState','"*          lue:["({int})?\\:({int})?(\\:({int})?)?", " pState'E",31:"FILT'"*          lue:["{int}", " pState'9:"END"'"*          lue:[dict.qq_f) {
 , "be yyiine({ yyi.(});tr(1,({;
  -2yy.asm.yie',33:"Q_ST';"*          lue:[dict.q_f) {
 , "be yyiine({ yyi.(});tr(1,({;
  -2yy.asm.yie',3:"Q_ST';"*          lue:["\\(.+?\\)(?=\\])", " pState' ESSION",18:"INTE'"*          lue:["\\?\\(.+?\\)(?=\\])", " pState'RESSION",32:"QQ_S'"]         ]
.
    perforsn;
   ":3,"DOLLAR perforbnf(){
   ual tr:3,"DOLLA:
[            al tm[e':"DOT"',   t s;        th'({  ar expres: {  ype: "root",   lue: $$[$0-1] } 1asm.unshifmme;     retyy.asm.yield()
e   bal  ' *          lue:  nt[e':"DOT" NENTS":5,"LEADI', '({  ar expres: {  ype: "root",   lue: $$[$0-1] } 1asm.unshifmme;     retyy.asm.yield()
e   bal  ' *          lue:  nt[e'ILD_MEMBER_EXPRESSION":6,"PATH_',   t s;        th'({  ar      retyy.asm.yield()
e   bal  ' *          lue:  nt[e'ILD_MEMBER_EXPRESSION":6,"PATH_ NENTS":5,"LEADI', '({  ar expres "membNu", scope: "child",  ar expres: {  ype: "ien.Identi",   lue: $$[$0-1] }}1sm.unshifmme;     retyy.asm.yield()
e   bal  ' ] *           NENTS":5,"LEADI:
[            al tm[e'NENTS":5,"LEAD',   t s;        th'' *          lue:  nt[e'NENTS":5,"LEADI NENTS":5,"LEAD', '' ] *           NENTS":5,"LEAD:
[            al tm[e'PONENT":11,"DOT"',   t'({ operitres: "membNu" });
yy.asm.pts.p)
e   bal  ' *          lue:  nt[e'COMPONENT":21,"[":2', '({  ar expres "membNu", s });
yy.asm.pts.p) 
e   bal  ' ] *           PONENT":11,"DOT":
[            al tm[e'ER_COMPONENT":10,"DESC',   t s'({ scope: "child" })
e   bal  ' *          lue:  nt[e':MEMBER_COMPONENT":11,"DOT"', '({  ar expresscendant" })
e   bal  ' ] *           ER_COMPONENT":10,"DESC:
[            al tm[e':"T RESSION":6,"PATH_', '' ] *           ILD_MEMBER_EXPRESSION":6,"PATH_:
[            al tm[e'PONENT"":6,"PATH_', '({ scope: "child", operitres: "membNu" })
e   bal  ' ] *           :MEMBER_COMPONENT":11,"DOT":
[            al tm[e':"T_:"T RESSION":6,"PATH_', '' ] *           RESSION":6,"PATH_:
[            al tm[e'    ',t s;        th'({  ar expres: {  ype: "root",   l   lue: $$[$0] } };1asm.u' *          lue:  nt[e'",17:"SCRI',      th'({  ar expres: {  ype: "root",   l",   lue: $$[$0-1] }}1smm.u' *          lue:  nt[e' ESSION",18:"INTE', '({  ar expres: {  ype: "root",   l expres",   lue: $$[$0] } };1asm.u' *          lue:  nt[e'":"END"',;        th'({  ar expres: {  ype: "root",   licLit",   lue: ue: pant($$[$0]) } }1)asm.u' *          lue:  nt[e'END',   t s;        '' ] *           COMPONENT":21,"[":2:
[            al tm[e'ER_COMCOMPONENT":21,"[":2',   t s'({ scope: "child" })
e   bal  ' *          lue:  nt[e':MEMBER_COMCOMPONENT":21,"[":2', '({  ar expresscendant" })
e   bal  ' ] *           ER_COMCOMPONENT":21,"[":2:
[            al tm[e'[ COMPONENT ]', '' ] *           :MEMBER_COMCOMPONENT":21,"[":2:
[            al tm[e':"T_:"T [ COMPONENT ]', '' ] *           COMPONENT:
[            al tm[e' XPRESSION_LISTABLE"', '' ],            al tm[e' XPRESSION_LISTABLE":27,"', '$11? yy.asm.set({  ar expres: {  ype: "unres",   lue: $$[$0] } })1 '.$ = $$
e   1' ] *           COMPONENT"_LISTABLE":27,":
[            al tm[e' XPRESSION_LISTABLE":27,",":2', '$]]
e  1]'],            al tm[e' XPRESSION_LISTABLE":27," ,  XPRESSION_LISTABLE":27,",":2', '$]]
e$1[$0])
e  3)' ] *           COMPONENT"_LISTABLE":27,",":2:
[            al tm[e'":"END"',;        th'$expres: {  ype: "numeric_lricLit",   lue: ue: pant($$[$0]) } }1asm.set(== '.$)
e $$u' *          lue:  nt[e' RAL":29,"ARRA',   t'$expres: {  ype: "scanSt_lricLit",   lue: $$[$0] } };1sm.set(== '.$)
e $$u' *          lue:  nt[e'E",31:"FILT',     th'$expres: {  ype: "numeric_lrlue: $$[$0] } };1sm.set(== '.$)
e $$u' * *           COMPONENT"_LISTABLE":
[            al tm[e'    ',t s;        th'$expres: {  ype: "wildcard",   lue: $$[$0] } };1sm.set(== '.$)
e $$u' *          lue:  nt[e'RESSION_LISTABLE"', '$expres: {  ype: "script_ ar expres",   lue: $$[$0] } };1sm.set(== '.$)
e $$u' *          lue:  nt[e'RESSION",32:"QQ_S', '$expres: {  ype: "script_ ar expres",   lue: $$[$0] } };1sm.set(== '.$)
e $$u' * *           CRAL":29,"ARRA:
[            al tm[e',33:"Q_ST', "$]]
e$1" *          lue:  nt[e'33:"Q_ST',  "$]]
e$1" * ]
.
    };
p xtfs.readFile*.js)     rowEs w.orts){Iranes[]= fs.readFile*.jsodule,ex.resolve("../.ranes[/orts){.js")     rowEs w.()  }
Iranes[]= fs.readFile*.jsodule,ex.resolve("../.ranes[/()  }
Tjs")   }
torts){.Es   fuf}lrowEs w;
f   "./dictPATH"fsER_E}]:3,1equire,module,exports){
     funct) {
aesprimt(orule,ex('./aesprim')  ) {
lue: t(orule,ex('./lue: ')  ) {
_e$0] s_[
parule,ex('Ctcaic-e$0]')  ) {
_uniq
parule,ex(' '{nrscore').uniq;

// ame (ch)set},sa hatymu);
ne, Tobh ()ue: i.tabins: {  ype: s.
// Mitigcan wch)) {
yy pollumous(yydeicoli) Pe} ciscapabatlue;s. ) {
UNSAFE_PROPERTY_NAMESgetProto  creuncunul )}
et sjshint -W069 lexpr */
UNSAFE_PROPERTY_NAMES['icoli) Pe} ']se;      UNSAFE_PROPERTY_NAMES['__ch)) __']se;      UNSAFE_PROPERTY_NAMES['ch)) {
yy']se;      t sjshint -W069 l
    ,1:[fproc}, ){isUnsafeame (ch)Name(et},)      pState a.ckipet},nd]= 'cLit",  xprUNSAFE_PROPERTY_NAMES[et},]nd]=       }[fproc}, ){isSafeAst(
yy.asm =ecov!ast');

soElegast'ined=htthes')  pState
    se
t  Rfier() walk(node) hash.recov!node );

soElegnode ined=htthes' );
!node.
soE)          soEleg
    se=te.sperforse=te'\nnode.
soE)   
t  exh//{===== SAFE2,
EMINALS{===== 
t  exh   ba'L lue: ':
  retue: pState      
t  exh   ba'I,   lue: ':
  retue:// Onlyiallow erowlpecialsscend ",   lue: 
  retue: pStatenode.et},nd]= '@';
 
t  exh//{===== PROPERTY ACCESS{===== 
t  exh   ba'Me   bE {  ype: ':     ual t;n ct!walk(node.htthes)               pState
    se=te.i F   
  retue:// Non-compucanStobj:ch) (ch)   ual t;n ct!node.compucan xprnode.ch) (ch).{
yy  ]= 'I,   lue: '              n ctisUnsafeame (ch)Name(eode.ch) (ch).et},)=s             a pState
    se=te.i F   }
    retue: pState             x}

  retue:// CompucanStobj["ch) (ch)"]         ngthnode.compucan              n ct!walk(node.ch) (ch))=s             a pState
    se=te.i F   }
           n ct            anode.ch) (ch).{
yy  ]= 'L lue: ' &&            atsUnsafeame (ch)Name(SLit",(eode.ch) (ch).$0] }))           =s             a pState
    se=te.i F   }
            pState             x}

  retue: pState
    se=te.i }
 
t  exh//{===== ",32:"QQ_SS{===== 
t  exh   ba'UnaryE {  ype: ':
  retue: pStatewalk(node. 1aalue;)  
t  exh   ba'BinaryE {  ype: ':
  retu   ba'LogicalE {  ype: ':
  retue: pStatewalk(node.left) xprwalk(node.righ;)  
t  exh   ba'C {associalE {  ype: ':
  retue: pStatet           walk(node.: r ) &&           walk(node.icolequue;) &&           walk(node.axprescan)         )  
t  exh   ba'A_eAtE {  ype: ':
  retue:in Sy$uin extra.ial node.elelue;
.) {
   {i++)e        t s;n ct!walk(node.elelue;
[i])=s             a pState
    se=te.i F   }
    retu}
  retue: pState      
t  exh   ba'Proto E {  ype: ':
  retue:in Sy$uinjextra.jal node.ch) (chi e+i'\n') {j++)e        t s;');
pnop   node.ch) (chi e[j];
           // Reoto     afe keys           n ct            ach) .key &&            a(         lue:  (ch) .key.{
yy  ]= 'I,   lue: ' &&            a  atsUnsafeame (ch)Name(ch) .key.et},)=s||         lue:  (ch) .key.{
yy  ]= 'L lue: ' &&            a  atsUnsafeame (ch)Name(SLit",(ch) .key.$0] })))             )           =s             a pState
    se=te.i F   }
           n ct!walk(ch) .$0] }))s             a pState
    se=te.i F   }
    retu}
  retue: pState      

t  exh//{===== ",3LICITLY REJECT DANGEROUS TYPES{===== t  exh//{Security: doroveirely n  ress: { deny; list each icde-execumous(/ciscapabvePe} . 
t  exh   ba'CallE {  ype: ':
  retu   ba'NewE {  ype: ':
  retu   ba'FRfier()E {  ype: ':
  retu   ba'ArrowFRfier()E {  ype: ':
  retu   ba'ThisE {  ype: ':
  retu   ba'Assig"lue;E {  ype: ':
  retu   ba'UpdateE {  ype: ':
  retu   ba'SequueceE {  ype: ':
  retu   ba'TemplateL lue: ':
  retu   ba'TemplateElelue;':
  retu   ba'TaggedTemplateE {  ype: ':
  retu   ba'RpStat funclue;':
  retu   ba'E {  ype:  funclue;':
  retu a pState
    se

t  exh//{===== DEFAULT DENY{===== 
t  exhress: {:   retse: soEleg
    se=te.s
  }
    pStatewalk(
yy.0 = $$uinHandlxpr =),n        t:
   pState sNEr(i;
}

   .apply(knde[0 1aalue;s); = $Handlxpr:ch)) {
yyr(i;
}

    =),n        t:
  (str)aluvep;   }aluvep; r.expr ;
  (str)" })
e   }aluvep; r.); = $Handlxpr:ch)) {
yyrkeysgetProto  keys; $Handlxpr:ch)) {
yyrresolve =),n       componue;)   
t $uinkee }l[ componue;. "membNu", componue;.scend, componue;.: {  ype: .{
yy ]cjoin('-      $uinmetho

ne;yyll_fns[key];
   n ct!metho
)eErowE(straalue;
"c:uldn'eiresolve key: " + key      pStatemetho
.bindsNErow  };
$Handlxpr:ch)) {
yyrregist r  },n       key) {
ndlxp)   
t n ct!{
ndlxpf scanSttrkeFRfier() t:
     sowE(straalue;
"{
ndlxpfmu);
bh (},n      "$0   }
   ;yyll_fns[key] = {
ndlxp  };
$Handlxpr:ch)) {
yyr_fns   {r pE'
e   b-e   b-i,   lue: ':),n       componue;,$$[$
}

 t:
    $uinkee }lcomponue;.: {  ype: .$0] } aness =r=$0] }  }

 
}

.$0] } anessn ct$0] }  scanSttrkeProto  xprkee in=$0] })          soEleg[ {[$0] } }$0] }[key],$$[th:}

 
}

.$[th[$0])
e key  } ]
.
        perf'
e   b-" })
e   b-i,   lue: ':
.
  _aluvep; (,n       key) $0] }s.n=f   lega q.3kee }paruf }) perf' });
yy.a-e   b-icLit",   lue: ':
.
  _" })
e (,n       key) $0] }s.n=f   lega q.3kee }pparuf }) perf'
e   b-e   b-icLit",   lue: ':
.
  _" })
e (,n       key) $0] }s.n=f   lega q.3SLit",(key  === SLit",(n=f  }) perf' });
yy.a-" })
e   b-icLit",   lue: ':
.
  _aluvep; (,n       key) $0] }s.n=f   lega q.3kee }pparuf }) perf'
e   b-e   b-   lue: ':
.
  _" })
e (,n          lega q.3expr }) perf'
e   b-" })
e   b-   lue: ':
.
  _aluvep; (,n          lega q.3expr }) perf' });
yy.a-" })
e   b-   lue: ':
.
  _aluvep; (,n          lega q.3expr }) perf' });
yy.a-e   b-   lue: ':
.
  _" })
e (,n          lega q.3expr }) perf' });
yy.a-e   b-lue: ':),n       componue;,$$[$
}

 t:
    n ctis_a_eAt(p
 
}

.$0] }))s        rlstackuslicomponue;.: {  ype: .$0] }lsplit(':').map(_$[$0]_nul = 't_in t    labe =r=$0] }s  }

 
}

.$0] }.map(,n       v, i   lega q.3{[$0] } }$,$$[th:}

 
}

.$[th[$0])
e i)asm.u;        soEleg(argupapply(cted, [$0] }s$[$0])
e acku)             perf' });
yy.a-e   b-lue: ':),n       componue;,$$[$
}

 t:
    $uinresult;
        }lcomponue;.: {  ype: .$0] }lforEach(,n       componue;)     labe =r=_componue;xpres "membNu" }' });
yy.a'child",  'e   b'es: {  ype: "icomponue;.: {  ype:            =r={
ndlxpfne;yyllresolve(_componue;t    labe =r=_result;
  {
ndlxp(_componue;,$$[$
}

     laben ct_result;      ual t; psult;
   psult;[$0])
e _result; se=te.i }
.
     NErow     }l pStateunique(result; se=t} perf' });
yy.a-" })
e   b-lue: ':),n       componue;,$$[$
}

, coue;)   
t be =r=jpt(orule,ex('..'  aness =r=sr ch,cknde;

    $uinresult;
        }l ypesode;
  jp.sode;($[$
}

, '$..*')l(argu(1   
   anodeslforEach(,n       node) hash.rn Re en=sult;[? yy.asm= coue;)  pStatse=te.i componue;.: {  ype: .$0] }lforEach(,n       componue;)     labebe =r=_componue;xpres "membNu" }' });
yy.a'child",  'e   b'es: {  ype: "icomponue;.: {  ype:              =r={
ndlxpfnels_[tresolve(_componue;t    labebe =r=_result;
  {
ndlxp(_componue;,$node)    }ll t; psult;
   psult;[$0])
e _result; se=te.i }        w     }l pStateunique(result; se=t} perf' });
yy.a-e   b- expres",   lue: ':),n       componue;,$$[$
}

, coue;)   
t be// sue: toutterow: {  ype:  from ?(: {  ype: )aness =r=srcslicomponue;.: {  ype: .$0] }lsargu(2, -1  aness =r=;
    aesprime: p; ()rc).body[> 1: {  ype: ;

    $uinpass'.table,n       key) $0] })          soElege$0] s_[(
yy, { '@' }$0] } }        
   }l pState sNEr" })
e ($[$
}

, cted, pass'.ta, coue;);

  } perf' });
yy.a-" })
e   b- expres",   lue: ':),n       componue;,$$[$
}

, coue;)   
t be// sue: toutterow: {  ype:  from ?(: {  ype: )aness =r=srcslicomponue;.: {  ype: .$0] }lsargu(2, -1  aness =r=;
    aesprime: p; ()rc).body[> 1: {  ype: ;

    $uinpass'.table,n       key) $0] })          soElege$0] s_[(
yy, { '@' }$0] } }        
   }l pState sNEraluvep; ($[$
}

, cted, pass'.ta, coue;);
=t} perf' });
yy.a-e   b- expres",   lue: ':),n       componue;,$$[$
}

 t:
    $uinexpslicomponue;.: {  ype: .$0] }lsargu(1, -1  aness soElege$0]_recur; ($[$
}

, exp, '$[{{$0] }}}]');
=t} perf'
e   b-e   b- expres",   lue: ':),n       componue;,$$[$
}

 t:
    $uinexpslicomponue;.: {  ype: .$0] }lsargu(1, -1  aness soElege$0]_recur; ($[$
}

, exp, '$.{{$0] }}}');
=t} perf'
e   b-" })
e   b- expres",   lue: ':),n       componue;,$$[$
}

 t:
    $uinexpslicomponue;.: {  ype: .$0] }lsargu(1, -1  aness soElege$0]_recur; ($[$
}

, exp, '$..$0] }');
=t} };
$Handlxpr:ch)) {
yyr_fns[' });
yy.a-e   b- Lit",   lue: ']se
	Handlxpr:ch)) {
yyr_fns['
e   b-e   b-i,   lue: '];
$Handlxpr:ch)) {
yyr_fns['
e   b-" })
e   b-icLit",   lue: ']se
nessHandlxpr:ch)) {
yyr_fns[' });
yy.a-" })
e   b- Lit",   lue: ']se
nessHandlxpr:ch)) {
yyr_fns['
e   b-" })
e   b-i,   lue: '];
$ Rfier() e$0]_recur; ($[$
}

, src, .emplate)   
t $uinjpt(orule,ex('./Rse;
      $uin;
    aesprime: p; ()rc).body[> 1: {  ype: ;
ss =r=$0] }  }e$0] s_[(
yy, { '@' }

 
}

.$0] } }     $uinpat i  .emplate.replue;
/\{\{\s*$0] }\s*\}\}/g, $0] }); 
t $uin psult;
  jp.sode;($[$
}

.$0] }s.pat       psult;[forEach(,n       r        r.pat i  

 
}

.$[th[$0])
e r.pat l(argu(1 $0    w      pStaterpsult;  }[fproc}, ){is_a_eAt(v

 t:
   pStateA_eAt.isA_eAt(v

   }[fproc}, ){is_htthes(v

 t:
  // ecpt rira non-a_eAt, non-{
  'htthes?
   pState !yy&& !(v

f scanSttrkeA_eAt) xprv

f scanSttrkeProto   }[fproc}, ){aluvep; r.recur; )   
t  soEleg
n       p[$
}

, ref, pass'.ta, coue;)   
t be =r=$0] }  }

 
}

.$0] } aness$uinpat i  

 
}

.$[th;

    $uinresult;
      
    $uin" })
e   },n       v0] }s.pat     
t  exhn ctis_a_eAt($0] }))s          $0] }lforEach(,n       elelue;[0to in)e        t s;n ctn=sult;[? yy.asm= coue;)  lega q.3}       t s;n ctpass'.ta(to in, elelue;[0n=f )s             a psult;[  bal{$$[th:}

th[$0])
e io in)$[$0] } }elelue;             ca}
    retu}t    labebe =] }lforEach(,n       elelue;[0to in)e        t s;n ctn=sult;[? yy.asm= coue;)  lega q.3}       t s;n ctrecur; )         defFour })
e (elelue;[0

th[$0])
e io in)           ca}
    retu}t    labe isSen ctMois_htthes(v

 }))s           sNErkeys(v

 })lforEach(,n       k)e        t s;n ctn=sult;[? yy.asm= coue;)  lega q.3}       t s;n ctpass'.ta(k,}$0] }[k][0n=f )s             a psult;[  bal{$$[th:}

th[$0])
e k)$[$0] } }$0] }[k]             ca}
    retu}t          sNErkeys(v

 })lforEach(,n       k)e        t s;n ctn=sult;[? yy.asm= coue;)  lega q.3}       t s;n ctrecur; )         defFour })
e ($0] }[k][0

th[$0])
e k)           ca}
    retu}t    labe       .bindsNErow  fFour })
e ($0] }s.pat         pStaterpsult;  =t} }[fproc}, ){_" })
e ($[ss'.ta t:
   pState,n       componue;,$$[$
}

, coue;)     }l pState sNEr" })
e ($[$
}

, componue;.: {  ype: .$0] }, pass'.ta, coue;);
=t} }[fproc}, ){_aluvep; ($[ss'.ta t:
   pState,n       componue;,$$[$
}

, coue;)     }l pState sNEraluvep; ($[$
}

, componue;.: {  ype: .$0] }, pass'.ta, coue;);
=t} }[fproc}, ){e$0] s_[(
yy, ild",.asm =ecov!isSafeAst(
yy. t:
     sowE(straalue;
'Unsafes: {  ype: "i;
yy.a(yyde expres: {  ype: s maylonlyi()ue: gcue es: r  gnode (@)e mem safespme (ch)set},s');
=t}   try  lega q.3_e$0] s_[(
yy, ild",.a}   cgexta(,.ast} }[fproc}, ){unique(result; t:
   psult;
   psult;[ expre(,n       d)  lega q.3du}t   ega q.3_uniq(
   a psult;      ,n       r     pStater.pat lmap(,n       c   lega q.3SLit",(c).replue;
'-', '--'  })cjoin('-  a}      }[fproc}, ){_$[$0]_nul = 't_in (v

 t:
   =r=sv

f= SLit",(v

      soEleg( !y]xt)  (/^-?[0-9]+$/) ?$$[$0]) } sv

 t:;    se}
torts){.Es   fuf}lHandlxpr;
f   "..":"jsonpathD,"./aesprim":"./aesprim","./io in":5,"./lue: $:7,"Ctcaic-e$0]":15," '{nrscoreER_E}]:5,1equire,module,exports){
     funct) {
assertt(orule,ex('assert')  ) {
dictt(orule,ex('./dict    ) {
P p; r  }rule,ex('./: p; r    ) {
Handlxpr =)rule,ex('./{
ndlxps');
 ) {
:3,"Pat i  ,n        t:
  (str)(i;
}

   .apply(knde[0 1aalue;s); =;

:3,"Pat :ch)) {
yyr(i;
}

    =),n        t:
  (str): p; r  } eweP ';
 ( ;
  (str)handlxpr =) eweHandlxpr(); =;

:3,"Pat :ch)) {
yyr: p;   }proc}, )(f) {
  i:
  assert.ok(_is_f) {
 (f) {
  , "wn  eed a.pat "      soEleg(str): p; re: p; ()) {
  ; =;

:3,"Pat :ch)) {
yyr: pue;xpr,n       obj, f) {
  i:

  assert.ok(objf scanSttrkeProto , "objf eedo totbh (n'htthes"     assert.ok(f) {
 , "wn  eed a.pat "   
}l ypesodes.n.yyllsode;(obj, f) {
  [0 }   ngthnode   sNEr_assert_safe_pat _keys(node.cat      $uinkee }lnode.cat l)op()  t sjshint unused:
    ,1:[   soEleg(str)$0] }(obj, node.cat    }

:3,"Pat :ch)) {
yyrapplyxpr,n       obj, f) {
 , fn i:

  assert.ok(objf scanSttrkeProto , "objf eedo totbh (n'htthes"     assert.ok(f) {
 , "wn  eed a.pat "     assert.equaltra.ckipfn, ",n      ", ",nf eedo totbh ,n      "$ 
}l ypesodess.n.yyllsode;(obj, f) {
  .sort(,n       a, b t:
    // sortesodessso we applyxfrom scanbottom up   }l pStateb.cat lsh');
   a.cat lsh');
0    w     nodeslforEach(,n       node) hash.r sNEr_assert_safe_pat _keys(node.cat        $uinkee }lnode.cat l)op() aness$uinpapue;xpr(str)$0] }(obj, v yytn) {
 ify(node.cat  ) aness =r=$0] }lnode.$0] }  }fc.Coms,obj, papue;[key]) anesspapue;[key] lsval;
=t}  NErow      pStatenodes  }

:3,"Pat :ch)) {
yyr$0] }  }fn       obj, cat ) $0] })   
  assert.ok(objf scanSttrkeProto , "objf eedo totbh (n'htthes"     assert.ok(cat ) "wn  eed a.pat "   
}lecov 1aalue;
.) {
  sm= 3 t:
    $uinsodes.n.yyllsode;(obj, cat  .   retyyash.recov!node)l pState sNEr_vivify(obj, cat ) $0] });ash.r sNEr_assert_safe_pat _keys(node.cat        $uinkee }lnode.cat l(argu(-1 .   retyyash.r$uinpapue;xpr(str)papue;(obj, v yytn) {
 ify(node.cat  ) anesspapue;[key] lsval } ane}[   soEleg(str)query(obj, v yytn) {
 ify(cat  , 1 .   retyya}

:3,"Pat :ch)) {
yyr_vivifyxpr,n       obj, f) {
 , $0] })   
   =r=sr ch,cknde;

  assert.ok(objf scanSttrkeProto , "objf eedo totbh (n'htthes"     assert.ok(f) {
 , "wn  eed a.pat "   
}l ypepat i  .str): p; re: p; ()) {
  anesslmap(,n       componue;)  lega q.3 omponue;.: {  ype: .$0] }  w      sNEr_assert_safe_pat _keys(cat    
   =r=srtV0] }  }fn       cat ) $0] })       $uinkee }lcat l)op() aness$uinsodes.nls_[t$0] }(obj, cat        ecov!node)l        srtV0] }(

th[$0])
e ),

soElegkee }ppa'cLit",  ? {} : []         sodes.nls_[t$0] }(obj, cat              ls_[t_assert_safe_key(key       sode[key] lsval } ane}[  srtV0] }(

th) $0] });ash soEleg(str)query(obj, f) {
  [0 } }

:3,"Pat :ch)) {
yyrqueryxpr,n       obj, f) {
 , coue;)   
t assert.ok(objf scanSttrkeProto , "objf eedo totbh (n'htthes"     assert.ok(_is_f) {
 (f) {
  , "wn  eed a.pat "   
t $uin psult;
  .yyllsode;(obj, f) {
 , coue;)anesslmap(,n       r     pStater.$0] }  w      pStaterpsult;  };

:3,"Pat :ch)) {
yyr: thsxpr,n       obj, f) {
 , coue;)   
t assert.ok(objf scanSttrkeProto , "objf eedo totbh (n'htthes"     assert.ok(f) {
 , "wn  eed a.pat "   
}l ype psult;
  .yyllsode;(obj, f) {
 , coue;)anesslmap(,n       r     pStater.pat i w      pStaterpsult;  };

:3,"Pat :ch)) {
yyrsodess.n,n       obj, f) {
 , coue;)   
t assert.ok(objf scanSttrkeProto , "objf eedo totbh (n'htthes"     assert.ok(f) {
 , "wn  eed a.pat "   
}lecovcoue; }ppa0)l pState    
   ypepat i  .str): p; re: p; ()) {
  ;    sNEr_assert_safe_ omponue;s(cat       =r={
ndlxp;
  .yyllhandlxpr;
f.r$uinpap
}

;
    {$$[th:}['$']$[$0] } }objf} ]    $uinmt)  e;
  [];
   n ctcat lsh');
 &&$$[th[> 1: {  ype: .{
yy  ] 'ue: ')lcat l   retyyam =ecov!cat lsh');
)lega q.3p '
}

;yam =cat lforEach(,n       componue;[0to in)e  
tra.erow
    e;[? yy.asm= coue;)  pStatse=te. =r={
ndlxpfnehandlxprtresolve(componue;t    la =r=_pap
}

;
      
    pap
}

;lforEach(,n       p    
t  exhn ct
    e;[? yy.asm= coue;)  pStatse=te.}l ype psult;
  {
ndlxp(componue;,$$, coue;);

   exhn ctise;
  }lcat lsh');
   1)e        t // ef we'esaitrough scan: mponue;s we'esarone    alue;xt)  e;
  xt)  e;[$0])
e  psult;
|| []          {
            ie// otherwiselaccumulate(yydeiarry n  errough       ie_pap
}

;
  _pap
}

;[$0])
e  psult;
|| []                w     }lpap
}

;
  _pap
}

;;

  }w      pStatecoue; ? xt)  e;[(argu(0, coue;) : xt)  e;  };

:3,"Pat :ch)) {
yyrn) {
 ify  }fn       cat )   
t assert.ok(cat ) "wn  eed a.pat "   
}l =r=s) {
 inen$'  
}l =r=.emplates }lu
   y'" })
e   b-
e   b': '..{{$0] }}}'      'e   b-
e   b': '.{{$0] }}}'      '" })
e   b- });
yy.a': '..[{{$0] }}}]'      'e   b- });
yy.a': '[{{$0] }}}]'
    s.trpat i  .str)_norm

    cat    
  cat lforEach(,n       componue;)e  
tra.erowcomponue;.: {  ype: .{
yy  ] 'ue: ')l pStatse     $uinkee }l[componue;.scend, componue;. "membNu"]cjoin('-      }l =r=.emplatei  .emplates[key];
t be =r=$0] }; 
tra.erowcomponue;.: {  ype: .{
yy  ] ' Lit",   lue: ')     labe =] }  }:3,"tn) {
 ify( omponue;.: {  ype: .$0] })aness {
             =] }  }componue;.: {  ype: .$0] } aness} 
tra.erow!.emplate) ErowE(straalue;
"c:uldn'eifind=.emplatei" + key   erforsn {
 i+  .emplate.replue;
/{{$0] }}}/) $0] });ash}w      pStatesn {
 ya}

:3,"Pat :ch)) {
yyr_norm

     }fn       cat )   
t assert.ok(cat ) "wn  eed a.pat "   
}lp xtra.ckippat i =ricLit",")e  
tra. soEleg(str): p; re: p; (cat    
   isSen ctMoA_eAt.isA_eAt(cat ) xpr.a.erow$[th[> i =ricLit",")e  
tra. =r=_pat i  [ es: {  ype: "root",   lue: $$[$0-1] }"$"asm.    
    pat lforEach(,n       componue;[0to in)e  
tra.a.erowcomponue;  ] '$  xprise;
  }pa0)l pStat;

   exhn ct.a.erowcomponue;  ] icLit"," xprcomponue;.xt)  ("^" + dict.i,   lue: e+ "$"))s           sNEr_assert_safe_key(componue;t         ie_pat :c bal{         ca "membNu" }'
e   b'          luild",  'e   b'e         lu: {  ype: "roo$0-1] }componue;[0t",   'i,   lue: 'a}
    retu}t          {
         ual tr ldnd
yy  }.a.erowcomponue;  ] i name}"
?           'icLit",   lue: ' : ' Lit",   lue: ' s.tratar{}n ct,
yy  ]= ' Lit",   lue: ')  sNEr_assert_safe_key(componue;t         ie_pat :c bal{         ca "membNu" }' });
yy.a'c         luild",  'e   b'e         lu: {  ype: "roo$0-1] }componue;[0t",   ,
yy }
    retu}t    labe         NErow     }l pState_$[th;

   isSen ctMoA_eAt.isA_eAt(cat ) xpr.a.erow$[th[> i =rihtthes" e  
tra. soEleg$[th   }
   ;yowE(straalue;
"c:uldn'ei '{nrstyydepat i"e+ p;t    }

:3,"Pat :ch)) {
yyr_assert_safe_keyble,n       key.asm =ecov_is_   afe_key(key  t:
     sowE(straalue;
"U  afe key in=:3,"Pat : " + key     } }

:3,"Pat :ch)) {
yyr_assert_safe_pat _keys  }fn       cat )   a.erow!A_eAt.isA_eAt(cat ))  pStatse=tpat lforEach(,n       key.asm =a.erowkee }ppa'$')  pStatse=te.n ct.a.erowkee }ppa'cLit", )  sNEr_assert_safe_key(key     }  NErow  }

:3,"Pat :ch)) {
yyr_assert_safe_: mponue;s =),n       componue;s t:
   =r=sr ch,cknde;
a.erow!A_eAt.isA_eAt(componue;s )l pStat;

  ');
 heckE {  ype:  =),n       : {  ype: ) hash.recov!: {  ype: )  pStatse=te.n ct: {  ype: .{
yy  ]= 'i,   lue: 'a|| : {  ype: .{
yy  ]= ' Lit",   lue: ')     labels_[t_assert_safe_key(: {  ype: .$0] });        soEle aness} 
tra.erow: {  ype: .{
yy  ]= 'lue: ' xprA_eAt.isA_eAt(: {  ype: .$0] }))     labe: {  ype: .$0] }lforEach(,n       componue;)     labebeerowcomponue; xprcomponue;.: {  ype: ) hash.r=te.i checkE {  ype: ( omponue;.: {  ype: )se=te.i F         }            ;

  componue;slforEach(,n       componue;)     laerowcomponue; xprcomponue;.: {  ype: ) hash.r=tcheckE {  ype: ( omponue;.: {  ype: )se=te.}ash}w  }[fproc}, ){_is_f) {
 (obj t:
   pStateProto  ch)) {
yyrtoSLit",.Coms,obj)  ] '[htthes SLit",]'  }[fproc}, ){_is_   afe_key(key t:
   pStatekee }ppa'__ch)) __'a|| kee }ppa'ch)) {
yy'a|| kee }ppa'icoli) Pe} '  }

:3,"Pat :Handlxpr =)Handlxpr;
:3,"Pat :P ';
    P ';
 se ) {
 scanStt =) ewe:3,"Pat ;
 scanStt.:3,"Pat i  :3,"Pat ;
torts){.Es   fuf}l scanStt;
f   "./dictPATH"./{
ndlxps":4H"./: p; r":6,"assert":8}],6,1equire,module,exports){
     funct) {
rowEs w   rule,ex('./rowEs w')  ) {
rp p; r  }rule,ex('../genmembed/: p; r     ) {
P p; r  },n        t:
f.r$uinpap; r  } eweg

   r.P
   r(   
}l =r=_(strtahash  }

   r.(strtahashse=tpa   r.yy.(strtahash  },n        t:
    n ctca   r.yy.
yy.asm =  }lpap  r.yy.
yyr(i;
}

   (             _(strtahash.apply(p ';
 ,  1aalue;s);
  }
    pState

   r;  };

to    :rowEs w   rowEs w;
orts){.Es   fuf}lP ';
 se    "../genmembed/: p; r":1H"./rowEs w":"}],7(require,module,exports){
     functorts){.Es   fuf}l,n       arr,rsn;
 , end,rsnep)   
t n ct.a.erowsn;
  ppa'cLit", )  sowE(straalue;
"sn;
  canoveibh (}cLit",");
t n ct.a.erow
e   pa'cLit", )  sowE(straalue;
"eydeianoveibh (}cLit",");
t n ct.a.erowsnep ppa'cLit", )  sowE(straalue;
"snepeianoveibh (}cLit",");

}l =r=lsymboarrlsh');
0 
t n ctsnep pppa0)l sowE(straalue;
"snepeianoveibh zero");
t snep p snep ? integ: (snep) : 1ls
  // norm

    nega  vee$0] }s
 wsn;
  pwsn;
  < 0 ?=lsym+wsn;
  :wsn;
 ;
t 
e   }
e  < 0 ?=lsym+w
e  :w
e ls
  // ress: { extue;s to extue;s
 wsn;
  pwinteg: (sn;
  pp= 0 ?=0 : !sn;
  ?ctsnep > 0 ?=0 : lsym  1)e:wsn;
 );
t 
e   }integ: (
e   p= 0 ?=0 : !
e  ?ctsnep > 0 ?=lsym: -1  :w
e )ls
  // clamp extue;s
 wsn;
  pwsnep > 0 ?=Mat lmax(0, sn;
 ) :=Mat lmin(len,wsn;
 );
t 
e   }snep > 0 ?=Mat lmin(end,rl    :=Mat lmax(-1,w
e )ls
  //  soElegempty n cextue;s are;lexpwards
t n ctsnep > 0 &&}
e  <= sn;
 )  pState    t n ctsnep < 0 &&}sn;
  < }
e )l pState    
   ype psult
      
  in Sy$uin extsn;
 ; i ! }
e ; i +=rsnep)       n cttsnep < 0 &&}i < }
e )l||ctsnep > 0 &&}ism= 
e ))h
           psult:c balarr[i])d];
}     pStaterpsult  }[fproc}, ){integ: (v

 t:
   pStateSLit",(v

 ]xt)  (/^[0-9]+$/) ?$$[$0]) } v

 t:     Nname}.isF(i;
e v

 t?$$[$0]) } v

, 10  :=0  }[f   fun8(require,module,exports){
     funct// http://wiki.ue;
onjs.org/wiki/Unit_Testing/1.0
//t// THIS IS NOT TESTED NOR LIKELY TO WORK OUTSIDE V8!
//t// Originallyxfrom narwhal.js (http://narwhaljs.org)
// Copyrigh;  c  2009 Thomas Robinson <280north[$0m>
//t// Permiype:  is hereby rownted, fre  of charge, to any person obtaint ofa copyt// ofpt rirsoftware;yydeassocimbed docalue;mbNu"e exesct, ba'Software'),

o
// re

f s scanSoftwaree memouttrecLitcbNu", .ranest of memouttlimi;mbNu"ethe
// righ;s to usd, copy,portify,poerge, publish, dicLitbu
  }sublicensd, and/or
// sell copies ofpt anSoftware, and to permit persons to whom scanSoftwareeis
// furnished to do so }subthes ut scanfollowt of: {associap
//t// The above copyrigh; note: tand t rirpermiype:  note: tshallibh .ranes[d in
// (ll copies or (});tan
}

    fe: s ofpt anSoftware.
//t// THE SOFTWARE IS PROVIDED 'AS IS', WITHOUT WE",3NTY OF ANY KIND, ",32:"Q ORt// IMPLIED, INCLU_MEM BUT NOT LIMITED TO THE WE",3NTIES OF MERCHANTABILITY,t// FITN:"Q FOR A PARTICUOT" NURPOSE AND NONINFQ_STEMENT. IN NO EVENT SHALL THEt// AUTHORS BE LI,":2 FOR ANY CLAIM, DAMAGES OR OTHER LI,"ILITY, WHETHER IN ANt// ACTTH_ OF CONTRACT, TORT OR OTHERWISE, ARISMEM FROM, OUT OF OR IN CONNECTTH_t// WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

//  tmisusedf s sode  NEro will () uallyxloadpt anutilports){fwe dep
e  on
// vep;usxloadt ofscanbuiltinnutilports){fas happe s otherwise
// t rirecpaebugf s sodeports){floadt ofar a {
as I amf: {cerned ) {
utilpparule,ex(' til/     ) {
pSue: t(oA_eAt.ch)) {
yyrnue:   ) {
hasOwngetProto  ch)) {
yyrhasOwname (ch);

// 1. The asserttorts){fese memsl,n      sa haty sowEt// Assertr()Elue;'s  tmispap
}culait: {associs are;oveimet. The
// (sserttorts){fmu);
con: r  ut scanfollowt ofinterface.
t) {
assertt(oorts){.Es   fuf}lok;

// 2. The Assertr()Elue;recp{nd];
 f s assert.
// straassert.Assertr()Elue;({ mes
   : mes
   ,t//                             () ual: () ual,t//                             expeccanStexpeccanu}t 
assert.Assertr()Elue;w }proc}, ){Assertr()Elue;()) {
   t:
  (str)et},nda'Assertr()Elue;';    sNEr() ualf}lo) {
  r() ual;    sNErexpeccanu}lo) {
  rexpeccan;    sNEr "membe;w }o) {
  r "membe;  t n cto) {
  rmes
   ) hash.r sNErmes
   w }o) {
  rmes
   ;ash.r sNErgenmembedMes
   w }
    se=t {
           sNErmes
   w }getMes
   sNErow  fFou sNErgenmembedMes
   w }        }
}l =r=s)ue;Sn;
 FRfier()w }o) {
  rs)ue;Sn;
 FRfier()w|| fail0 
t n ctahash.capturnalue;Trac ) hash.rahash.capturnalue;Trac (knde[0s)ue;Sn;
 FRfier());
=t}   
          // non v8 browsxpr so we can havh (}cLacktrac 
    $uinerr  } eweElue;(       ecoverrrs)ue;)     labe =r=outt= errrs)ue;;

t  exh//{try to}cLitpsusele: gfrt},s   labe =r=fn_et},ndas)ue;Sn;
 FRfier())et},se=te.}l ypeidxw }ouyr(idexOf('\n' +=fn_et},     laben ctidxwd=e =s          // oStt we havh locmbed scanfRfier()wfrt},         // wn  eed to}cLitpsoutte, Tytht ofbeforeeit (and its linn)         $uinsext_linnw }ouyr(idexOf('\n',eidxw+ 1)se=te.i F outt= ouyr(});trt",(eext_linnw+ 1)se=te.i }
       v yytn)ackt= ouyse=te.s
  }
};

// assert.Assertr()Elue;w scanSttrkeElue;
 til.inherits(assert.Assertr()Elue;,eElue;);
$ Rfier() replue;r key) $0] })     n ct til.isU'{nd];
 (v

 }))s       pState'' +=val } ane}[  n ct til.isNname}(v

 })y&& !isF(i;
e v

 }))s       pState$0] }ltoSLit",() ane}[  n ct til.isFn       v0] })l||c til.isRegExp v

 }))s       pState$0] }ltoSLit",() ane}[   pState$0] }  }[fproc}, ){alu])
ee(s, n)     n ct til.isSLit",(s))s       pState;[? yy.as< n ? se:ws[(argu(0, ));
=t} 
           pState;;
=t} }[fproc}, ){getMes
   sls_[ t:
   pState lu])
ee(:3,"tn) {
 ify(ls_[t() ual, replue;r , 128) + ' ' +ash.r=te.ils_[t "membe;w+ ' ' +ash.r=te.i lu])
ee(:3,"tn) {
 ify(ls_[texpeccan, replue;r , 128)  }[f// At {  yue; onlyiscanthre  keys lue;io;
 fabove are;usedfandf//  '{nrstood by erowlpec. Implelue;afe: s or (})oorts){s can pass
// other keys ut scanAssertr()Elue;'s icoli) Pe} c- scay will be
// ignored.

// 3. A  'hf scanfollowt of,n      samu);
 sowE(a){Assertr()Elue;
//  tmisa corresp {as of: {associrecpoveimet,e mem a mes
   a hat
// maylbe  '{nd];
  n coveiese memd.  A  'assertr()emetho
siese mem
// both scan() ualfand expeccanu$0] }s ut scanassertr()eelue;wfe;
// display purposes.[fproc}, ){fail(() ual, expeccan, mes
   ,  "membe;[0s)ue;Sn;
 FRfier())t:
  (sowE(straassert.Assertr()Elue;({ash.rmes
   : mes
   ,t    () ual: () ual,t    expeccanStexpeccan,t     "membe;:  "membe;[erforsn;e;Sn;
 FRfier():rsn;e;Sn;
 FRfier()ash}w  }[f// EXTENQQ_S!iallows in Swell behavhdeelue;cp{nd];
 f
   where.
assert.failw }
 il0 
// 4. Puranassertr()e: r s  tmther a  =] } ecptruthy,
as determined // by !!guard.
// assert.ok(guard, mes
   _op );
// Thrirsfunclue; ecpule,value; to assert.equaltrr }, !!guard,t// mes
   _op );. Toe: r  cLitcblyxfor scan =] } rr }, use
// (ssert.cLitcbEqualtrr }, guard, mes
   _op );.[fproc}, ){ok($0] }s.mes
   ) hashecov!v0] })lfail($0] }s.rr }, mes
   , '==', assert.okw  }[assert.okf}lok;

// 5. The equalitynassertr()e: r s shallow, coerc veeequalityn mem
//{==.
// assert.equalt() ual, expeccan, mes
   _op );

assert.equalw }proc}, ){equalt() ual, expeccan, mes
   ) hashecov() ualf! }
xpeccan){fail(() ual, expeccan, mes
   , '==', assert.equal ; =;

// 6. The non-equalitynassertr()e: r s in Swtmther two'htthess are;oveiequal
//  mem != assert.nobEqualt() ual, expeccan, mes
   _op );

assert.nobEqualw }proc}, ){nobEqualt() ual, expeccan, mes
   ) hashecov() ualf= }
xpeccan){{ash.rfail(() ual, expeccan, mes
   , '!=', assert.nobEqual);
=t} };
$// 7. The equ,valuecanassertr()e: r s a deepeequalitynrelafe: .
// assert.deepEqualt() ual, expeccan, mes
   _op );

assert.deepEqualw }proc}, ){deepEqualt() ual, expeccan, mes
   ) hashecov!_deepEqualt() ual, expeccan)){{ash.rfail(() ual, expeccan, mes
   , 'deepEqual', assert.deepEqual);
=t} };
$proc}, ){_" epEqualt() ual, expeccan)t:
  // 7.1. A  'i,   lcalu$0] }s are;ule,value;,
as determined by ===.
shecov() ualf=  }
xpeccan){{ash.r pState      
t  isSen ctMo til.isBufferv() ual)y&&  til.isBuffervexpeccan)){{ash.recov() ual[? yy.as! }
xpeccanlsh');
)lega q.3
    se
t e:in Sy$uin extra.ial () ual[? yy.a {i++)e        ecov() ual[i] ined
xpeccan[i])  soEleg
    se=te.sperfor pState      
t // 7.2. Ifterow: {eccanu$0] }recpaeDateioroto , scan() ualf$0] }rec
t // ule,value; ifeit ecpalsopaeDateioroto a hatyrefxpr ut scanst},ntime.
t  isSen ctMo til.isDs_[(
) ual)y&&  til.isDs_[(expeccan)){{ash.r pState() ual[getTime()f=  }
xpeccan[getTime()  
t // 7.3 Ifterow: {eccanu$0] }recpaeRegExpioroto , scan() ualf$0] }rec
t // ule,value; ifeit ecpalsopaeRegExpioroto   mem scanst},nsour: tand
t // ch) (chi e (`global`, `multilinn`, `lastIidex`, `ignoreCase`).
t  isSen ctMo til.isRegExp 
) ual)y&&  til.isRegExp expeccan)){{ash.r pState() ual[sour: t=  }
xpeccan[sour: t&&            () ual[globalf=  }
xpeccan[globalf&&            () ual[multilinnf=  }
xpeccan[multilinnf&&            () ual[lastIidexf=  }
xpeccan[lastIidexf&&            () ual[ignoreCasef=  }
xpeccan[ignoreCase  
t // 7.4. Other pairsa hatydoroveiboth passr.a.erow =] }  ed=htthes',
t // ule,valuecerecp{ntermined by ==.
t  isSen ctMo! til.isProto  
) ual)y&& ! til.isProto  expeccan)){{ash.r pState() ualf= }
xpeccan  
t // 7.5 For (ll other Proto  pairs, .ranest ofA_eAt'htthess, ule,valuecerec
  // retermined by havt ofscanst},n name}'hf owned ch) (chi e (as veplue:d
t //  mem Proto  ch)) {
yyrhasOwname (ch).Coms), scanst},nset rowkeec
  // (alemoughroveineue: arilyiscanst},nord;r , ule,value; $0] }s in Se, Ty
  // corresp {as ofkey) yydean'i,   lcalu'ch)) {
yy'ach) (ch). Not   ,hec
  // accoue;s in Sboth et},dfandrise;
ed ch) (chi e oteA_eAts.
=t} 
           pStateobjEle,vt() ual, expeccan);
=t} }[fproc}, ){isA_aalue;s(htthes)t:
   pStateProto  ch)) {
yyrtoSLit",.Coms,objhes)t ] '[htthes A_aalue;s]'  }[fproc}, ){objEle,vt(, b t:
  n ct til.isNnllOrU'{nd];
 (a)l||c til.isNnllOrU'{nd];
 (b))      soEleg
    se=t// an'i,   lcalu'ch)) {
yy'ach) (ch).
shecov( ch)) {
yy inedb ch)) {
yy)  soEleg
    se=t// if on}recpaeprimi  ve, scanother mu);
bh st},   n ct til.isPrimi  ve(a)l||c til.isPrimi  ve(b)){{ash.r pState(f=  }b    }
}l =r=aIsA_auf}l sA_aalue;s(a)e       bIsA_auf}l sA_aalue;s(b);
t n ct(aIsA_auf&& !bIsA_au)l||ct!aIsA_auf&& bIsA_au))      soEleg
    se=tecov(IsA_au)l{ash.ra  }
Sue: .Coms,a)se=te.b  }
Sue: .Coms,b        pState_" epEqualt(, b     }
}l =r=ka  }htthesKeys(a)e       kb  }htthesKeys(b)e       key) ise=t// havt ofscanst},n name}'hf owned ch) (chi e (keys incorpoembese=t// hasOwname (ch))e=tecovka[? yy.as! }kblsh');
)      soEleg
    se=t//scanst},nset rowkeec (alemoughroveineue: arilyiscanst},nord;r ,
  ka.sort(     kb.sort(     //~~~cheap kee : r 
  in Sy extka[? yy.as- 1;}ism= ra.i--.asm =a.erowka[i] in kb[i])        soEleg
    se=t}   //ule,value; $0] }s in Se, Ty corresp {as ofkey) yyd   //~~~po: i.ty expens veedeepe: r 
  in Sy extka[? yy.as- 1;}ism= ra.i--.asm =a.keybleka[i]      ecov!_" epEqualt([key],$b[key]))  soEleg
    se=t}    pState      }[f// 8. The non-equ,valuecanassertr()e: r s in Sany deepeinequality.
// assert.notDeepEqualt() ual, expeccan, mes
   _op );

assert.notDeepEqualw }proc}, ){nobDeepEqualt() ual, expeccan, mes
   ) hashecov_deepEqualt() ual, expeccan)){{ash.rfail(() ual, expeccan, mes
   , 'nobDeepEqual', assert.nobDeepEqual);
=t} };
$// 9. The cLitcb equalitynassertr()e: r s sLitcb equality,
as determined by ===.
// (ssert.cLitcbEqualt() ual, expeccan, mes
   _op );

assert.cLitcbEqualw }proc}, ){cLitcbEqualt() ual, expeccan, mes
   ) hashecov() ualf!  }
xpeccan){{ash.rfail(() ual, expeccan, mes
   , '===', assert.cLitcbEqual);
=t} };
$// 10. The cLitcb non-equalitynassertr()e: r s in ScLitcb inequality, as
// retermined by !==.  assert.nobSLitcbEqualt() ual, expeccan, mes
   _op );

assert.nobSLitcbEqualw }proc}, ){nobSLitcbEqualt() ual, expeccan, mes
   ) hashecov() ualf== }
xpeccan){{ash.rfail(() ual, expeccan, mes
   , '!==', assert.nobSLitcbEqual);
=t} };
$proc}, ){expeccanExcep     a) ual, expeccan)t:
  ecov!a) ualf);
!
xpeccan){{ash.r pState
    se=t} 
  ecovProto  ch)) {
yyrtoSLit",.Coms,
xpeccan){ ] '[htthes RegExp]'){{ash.r pState
xpeccan[: r  
) ual);
t  isSen ctMoa) ualf scanSttrke
xpeccan){{ash.r pState      t  isSen ctMo
xpeccan[Coms,{}, 
) ual)yd]=     ){{ash.r pState      t   
t  soEleg
    se}[fproc}, ){_asowEs(sh:uldTsowE, block, expeccan, mes
   ) hash =r=a) ual;    n ct til.isSLit",(expeccan)){{ash.rmes
   w }expeccan;     expeccan  }    se  }
   ;ry  e=te.block() ane} cgexta(,.ast    () ualw }ese  }
   mes
   w }(expeccan &&}
xpeccan[et},n? ' (' +=
xpeccan[et},n+ ').' : '.') +ash.r=te.i:  (mes
   w? ' ' + mes
   w: '.')0 
t n ctsh:uldTsowEf&& !
) ual)y{ash.rfail(() ual, expeccan, 'Miypeng expeccan excep    ' + mes
   )se=t} 
  ecov!sh:uldTsowEf&& expeccanExcep     a) ual, expeccan))y{ash.rfail(() ual, expeccan, 'Goei 'wwnted excep    ' + mes
   )se=t} 
  ecovtsh:uldTsowEf&& () ualw&& expeccanf&&       !expeccanExcep     a) ual, expeccan))y||ct!sh:uldTsowEf&& () ual  t:
     sowE(() ual;   } }[f// 11. Expeccanfut scowE(a){elue;:
// (ssert.asowEs(block, Elue;_op , mes
   _op );

assert.asowEsf}l,n       block, /*o) {
 al*/elue;,e/*o) {
 al*/mes
   ) hash_asowEs.apply(knde[0[    $[$0])
e 
Sue: .Coms,a1aalue;s)) ; =;

// EXTENQQ_S!iT rirecpannoyt ofso writ toutside t rirorts){.
assert.doesNotTsowEf}l,n       block, /*o) {
 al*/mes
   ) hash_asowEs.apply(knde[0[
    $[$0])
e 
Sue: .Coms,a1aalue;s)) ; =;

assert.ifahash  },n       err    ecoverr) {scowE(err;}}   ) {
htthesKeysgetProto  keysw|| froc}, ){(obj t:
  $uinkee;
        in Sy$uinkey in=obj t:
    ecovhasOwn.Coms,obj, key  tkee;:c balkey     }    pStatekee;  };

   " til/":11}],9(require,module,exports){
     functn ct.a.erowProto  createi  ] 'equire,m' t:
  // emplelue;afe: xfrom styydardlnode.js ' til'rorts){   mrts){.Es   fuf}l,n       inherits(cbe;[0superCtor        Pe} .super_ndasuperCtor     Pe} .ch)) {
yy =wProto  create(superCtor.ch)) {
yy, hash.r=tccoli) Pe} :s          $0] }: Pe} e         eicLit= 't:g
    e         writ= 't:grr },         con:igur= 't:grr }              w     ;
} 
        // old school shim in Sold browsxpr   mrts){.Es   fuf}l,n       inherits(cbe;[0superCtor        Pe} .super_ndasuperCtor     $uinTempCte;w }proc}, ){  t:      TempCte;.ch)) {
yy =wsuperCtor.ch)) {
yy     Pe} .ch)) {
yy =wstraTempCte;()     Pe} .ch)) {
yy.icoli) Pe} c= Pe}    } }[f   fun10(require,module,exports){
     functorts){.Es   fuf}l,n       isBufferv(rg)t:
   pStatearg xpr.a.erowarg = ed=htthes'     xpr.a.erowarg.copyi  ] 'equire,m'     xpr.a.erowarg.fill   ] 'equire,m'     xpr.a.erowarg.readUInt8   ] 'equire,m'se}[   fun11(require,module,exports){
     funct(proc}, ){ proue: ,globalnct// Copyrigh; Joyue;,
Inc.fandrother NodepconLitbu
ors.
//t// Permiype:  is hereby rownted, fre  of charge, to any person obtaint ofa
// copy ofpt rirsoftware;yydeassocimbed docalue;mbNu"e exesct, b
// "Software"),

o re

f s scanSoftwaree memouttrecLitcbNu", .ranest o
//  memouttlimi;mbNu"ethe righ;s to usd, copy,portify,poerge, publish,
// disLitbu
  }sublicensd, and/or sell copies ofpt anSoftware, and to permit
// persons to whom scanSoftwareeis furnished to do so }subthes ut sca
// followt of: {associap
//t// The above copyrigh; note: tand t rirpermiype:  note: tshallibh .ranes[d
// in (ll copies or (});tan
}

    fe: s ofpt anSoftware.
//t// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WE",3NTY OF ANY KIND, ",32:"Qt// OR IMPLIED, INCLU_MEM BUT NOT LIMITED TO THE WE",3NTIES OFt// MERCHANTABILITY, FITN:"Q FOR A PARTICUOT" NURPOSE AND NONINFQ_STEMENT. INt// NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LI,":2 FOR ANY CLAIM,t// DAMAGES OR OTHER LI,"ILITY, WHETHER IN AN ACTTH_ OF CONTRACT, TORT ORt// OTHERWISE, ARISMEM FROM, OUT OF OR IN CONNECTTH_ WITH THE SOFTWARE OR THEt// USE OR OTHER DEALINGS IN THE SOFTWARE.

 =r=form
tRegExpi= /%[sdj%]/g;
     fu.form
t  },n       f.asm =ecov!isSLit",(f )s      ) {
htthes;
        }lin Sy$uin extra.ial (1aalue;
.) {
   {i++)e        htthes;:c balinlpect,a1aalue;s[i])              pStateobjhes;:join(' ')se=t} 
  $uin ext1    $uin;_auf}la1aalue;s;
}l =r=lsymboargslsh');
0    =r=s) f= SLit",(f).replue;
form
tRegExp,},n       x t:
    ecovxf=  }'%%')  pStat '%'      ecovism= l     pStat x      swiexta(n)e           ba'%s':  pStateSLit",(args[i++]            ba'%d':  pStateNname}(args[i++]            ba'%j':
  retu a;ry  e=te.       soEleg:3,"tn) {
 ify(args[i++]         ne} cgexta(_)  e=te.       soEleg'[Circulai]'se=te.i F         ress: {:   retse: soElegxse=te.}ash}w  }lin Sy$uinxmboargs[i] .ial len;nxmboargs[++i]) :
    n ctisNnll(n)e);
!isProto  x))     labes) f+= ' ' + xse=te.}{
            s) f+= ' ' + inlpect,x)se=te.}ash}    pStatesn   };

t// Marka hatyanmetho

sh:uld oveibh used.
// RpStatcpaeortifiedl,n       which waatcpoStt by ress: {.
// If --no-deprecasocirecpse , scaneit ecpa no-op.
     fu.deprecas   }fn       fn, msg t:
  // Allowlin Sdeprecaso ofscingsf s scanproue:  rowsn;
 o ofup.
shecovisU'{nd];
 (global.proue: )){{ash.r pState,n        t:
    .r pState
xp  fu.deprecas  fn, msg .apply(knde[0 1aalue;s); =te.}se=t} 
  ecovproue: .noDeprecasocird]=     ){{ash.r pStatefnse=t} 
  $uinwaatan  }
    se=tproc}, ){deprecas d  t:
    n ct!waatan)e        ecovproue: .scowEDeprecasoci)s           sowE(straalue;
msg     labe isSen ctMoproue: .srac Deprecasoci)s          icolole.srac 
msg     labe isSen           icolole.elue;
msg     labe    labewaatan  }      t          pStatefn.apply(knde[0 1aalue;s); =t  
t  soElegdeprecas d  };

t$uin" buauf}l{};t$uin" buaEnvir: ;

xp  fu.debuglog  }proc}, )(fet.asm =ecovisU'{nd];
 (" buaEnvir: ))     " buaEnvir:   }
roue: .env.NODE_DEBUGe);
''se=tset .nlst.toUpperCas (     n ct!" buau[set]) :
    n ctstraRegExp '\\b' + set + '\\b', 'i')[: r  " buaEnvir: ))     labe =r=pid  }
roue: .pid;       rebuau[set]  },n        t:
    labe =r=msgw }exp  fu.form
t.apply(exp  fu[0 1aalue;s); =te.    icolole.elue;
'%s %d: %s'chie , pid, msg     labe se=te.}{
            rebuau[set]  },n        t:}se=te.}ash}    pStaterebuau[set]  };

t/**
 * Echos scan =] } rowae$0] }l Trys ut print scan =] } rut
 *  s scanb r  way po: i.te gives scandifferue; types.[ *
 * @param {Proto }}objfThe obthes ut print ouyr
 * @param {Proto }}opts O) {
 al}o) {
  ioroto a hatyaxpres scanoutpuyr
 */
/* legacy }obj,
sh:wHidden,wdept ) colors*/fproc}, ){inlpect,obj,
opts t:
  // ress: { o) {
  
  ');
 tx }lu
   yseen: [][erforsny
   :rsny
   NoColor
be se=t// legacy...
}lecov 1aalue;
.) {
  sm= 3 tctx.dept f}la1aalue;s[2   t n ct 1aalue;
.) {
  sm= 4 tctx.colorsf}la1aalue;s[3   t n ctisBoolean(opts  t:
    // legacy...
}l tctx.sh:wHiddenw }o) s  t  isSen ctMoopts t:
    // goa(yy "o) {
  "ioroto      exp  fu._extued(ctx,
opts se=t}   // set ress: { o) {
  
  ecovisU'{nd];
 (ctx.sh:wHidden))tctx.sh:wHiddenw }
    se=tecovisU'{nd];
 (ctx.dept ) tctx.dept f}l2se=tecovisU'{nd];
 (ctx.colors) tctx.colorsf}l
    se=tecovisU'{nd];
 (ctx.customInlpect) tctx.customInlpect  }      t erowctx.colors)tctx.sny
   ndas)y
   WithColor;ash soElegform
tV0] }(ctx,
obj,
ctx.dept )se}[exp  fu.inlpect  }inlpect;

t// http://en.wikipedia.org/wiki/ANSI_escape_: de#graphics
inlpect.colorsf}l:
  'bold' : [1, 22][erf'italic' : [3, 23][erf' '{nrlinn' : [4, 24][erf'invep; ' : [7, 27][erf'whit ' : [37, 39][erf'grey' : [90, 39][erf'black' : [30, 39][erf'blu ' : [34, 39][erf'cyan' : [36, 39][erf'green' : [32, 39][erf'mague;m' : [35, 39][erf'red' : [31, 39][erf'yellow' : [33, 39] =;

// Don'ei  ba'blu ' oveivi i.te on cmd.exe
inlpect.s)y
es }lu
  'lpecial': 'cyan'[erf' name}': 'yellow'[erf'boolean': 'yellow'[erf' '{nd];
 ': 'grey'[erf' nll': 'bold'[erf'cLit", :f'green'[erf'date :f'mague;m',
t // "et},":finten {
 ally oveis)y
 ngerf'regexp :f'red' };

tproc}, ){cLy
   WithColor()) ,{cLy
eTyp ) hash =r=cLy
e  }inlpect.s)y
es[cLy
eTyp ]0 
t n ctsnyl ){{ash.r pState'\u001b[' + inlpect.colors[cLy
e][> i+ 'm' + s) f+ash.r=te.i: '\u001b[' + inlpect.colors[cLy
e][1 i+ 'm';
=t} 
           pState;tr;   } }[ftproc}, ){cLy
   NoColor()) ,{cLy
eTyp ) hash pStatesn   }[ftproc}, ){a_eAtToHabalarray) hash =r=hashf}l{};t
t a_eAt.forEach(,n       v

, idn)e      hash[val]w }        }w      pStatehash  }[ftproc}, ){form
tV0] }(ctx,
$0] }s.recur; Times t:
  // Pse mem a hooklin Suser-lpecifiedlinlpect ,n      s.
  // Checka haty$0] }recpanioroto   mem anlinlpect ,n       on it t erowctx.customInlpect &&       $0] }r&&       isFn       v0] }.inlpect)r&&       // Fexpresoutterowutilports){, it'slinlpect ,n       ecpspecial       $0] }.inlpect !  }
xp  fu.inlpect &&       // Alsopfexpresouttany ph)) {
yy htthes;
ust ofscancirculaitcheck.       ! v0] }.icoli) Pe} cxprv

 }.icoli) Pe} .ch)) {
yy ==lsval } )s      ) {
ret .n$0] }.inlpect(recur; Times,
ctx       ecov!isSLit",(ret) t:
    .r pSf}l
orm
tV0] }(ctx,
rets.recur; Times   t          pStateret; =t  
t // Psimi  ve typeseianoveihavh ch) (chi ef.r$uinpsimi  ve }l
orm
tPrimi  ve(ctx,
$0] }     n ctpsimi  ve){{ash.r pStatepsimi  ve; =t  
t // Looklupfscankee;
ofpt anhtthes.
  $uinkee;
  Proto  keys($0] }      =r=$i i.teKeysgeta_eAtToHabalkeys   
}lecovctx.sh:wHidden)asm =a.key;
  Proto  getOwname (ch)Nt},s($0] }       
t // IE doesn'eimakeeelue;wfields non-eicLit= 'te=t// http://msdn.microsoft[$0m/en-us/library/ie/dww52sbt(v=vs.94).aspxe=tecovisalue;
$0] })aness  xprlkeysr(idexOf('mes
   ')sm= ra|| keesr(idexOf('" })yy.ae,m' td=e =){{ash.r pStateform
talue;
$0] })      
t // Some type'hf oroto   memouttch) (chi e can bh shortcutcan[
a.erowkee
.) {
  spppa0)l:
    n ctisFn       v0] }))     labe =r=et},nda$0] }.et},n? ': ' +=val }.et},n:
''se=tsh.r pStatectx.sny
   ('[Fn      ' +=et},n+ ']', 'lpecial'   t         n ctisRegExp v

 }))s      .r pStatectx.sny
   (RegExp ch)) {
yyrtoSLit",.Coms,v

 }),f'regexp    t         n ctisDs_[(v

 }))s      .r pStatectx.sny
   (Ds_[ ch)) {
yyrtoSLit",.Coms,v

 }),f'date    t         n ctisalue;
$0] }))s      .r pStateform
talue;
$0] })    e.}ash}     =r=basef= '', a_eAt'}l
    , brac ;
   '{', '}']  
t // MakeeA_eAt'saya haty sey are;A_eAte=tecovisA_eAt($0] }))s      a_eAt'}l      t   brac ;
   '[', ']']      
t // Makee,n      sasaya haty sey are;,n      s
  n ctisFn       v0] }))     la =r=enda$0] }.et},n? ': ' +=val }.et},n:
''se=tshbasef= ' [Fn      ' +=en+ ']'      
t // MakeeRegExpsasaya haty sey are;RegExps
  n ctisRegExp v

 }))s      basef= ' ' +=RegExp ch)) {
yyrtoSLit",.Coms,v

 })      
t // Makeedates  mem ch) (chi e firr  cayiscandate
  n ctisDs_[(v

 }))s      basef= ' ' +=Ds_[ ch)) {
yyrtoUTCSLit",.Coms,v

 })      
t // Makeeelue;w mem mes
   wfirr  cayiscanelue;
  n ctisalue;
$0] }))s      basef= ' ' +=form
talue;
$0] })      
t erowkee
.) {
  spppa0 xprl!a_eAt'||=val }.) {
  sppe =){{ash.r pStatebrac ;[> i+ basef+ebrac ;[1]      
t erowrecur; Times < 0)l:
    n ctisRegExp v

 }))s      .r pStatectx.sny
   (RegExp ch)) {
yyrtoSLit",.Coms,v

 }),f'regexp    t    {
             pStatectx.sny
   ('[Proto ]', 'lpecial'   t         
t ctx.seen:c bal$0] })  
be =r=outpuyse=tn ct 1ray) hash =outpuy }l
orm
tA_eAt(ctx,
$0] }s.recur; Times,=$i i.teKeys, keys);
=t} 
          outpuy }lkee
.map(,n       key.asm =a..r pStateform
tame (ch)(ctx,
$0] }s.recur; Times,=$i i.teKeys, key, a_eAt   t    )      
t ctx.seen:cop() a    pStaterpduceToSingleSLit",(outpuy, base, brac ;)  }[ftproc}, ){form
tPrimi  ve(ctx,
$0] } asm =ecovisU'{nd];
 (v

 }))
     pStatectx.sny
   (' '{nd];
 ',f' '{nd];
 ')se=tecovisSLit",(v

 }))     la =r=semplef= '\'' +=:3,"tn) {
 ify(v

 }).replue;
/^"|"$/g, '')
                                             .replue;
/'/g, "\\'")
                                             .replue;
/\\"/g, '"') + '\''se=tsh pStatectx.sny
   (semple,a'cLit", ) ane}[  n ctisNname}(v

 }))
     pStatectx.sny
   ('' +=val },f' name}')  t n ctisBoolean(v

 }))
     pStatectx.sny
   ('' +=val },f'boolean'     // For some reason .a.erow nll ecpihtthes", so lpecial    bahere.
  n ctisNnll(v

 }))
     pStatectx.sny
   (' nll',f' nll')  }[ftproc}, ){form
talue;
$0] }) hash pState'[' + ahash.ch)) {
yyrtoSLit",.Coms,v

 })n+ ']'  }[ftproc}, ){form
tA_eAt(ctx,
$0] }s.recur; Times,=$i i.teKeys, keys) hash =r=outpuy }l      in Sy$uin extr, lnda$0] }.) {
   {ial l; ++i t:
    ecovhasOwname (ch)($0] }s.SLit",(i)))s      .routpuyrc balform
tame (ch)(ctx,
$0] }s.recur; Times,=$i i.teKeys,
          SLit",(i)s.rr })   t    {
            outpuyrc bal'')se=te.}ash}   kee
.forEach(,n       key.asm =a.erow!key]xt)  (/^\d+$/))s      .routpuyrc balform
tame (ch)(ctx,
$0] }s.recur; Times,=$i i.teKeys,
          key, rr })   t    ash}w  }l pStateoutpuyse}[ftproc}, ){form
tPre (ch)(ctx,
$0] }s.recur; Times,=$i i.teKeys, key, a_eAt  hash =r=et},, f) ,wdesc  }ldesc
  Proto  getOwname (ch)D })yy.ae;
$0] }, key '||=oo$0-1] }$0-1][key] }  t n ctdesc get.asm =a.erowdesc set)     labes) f=ectx.sny
   ('[Getter/Setter]', 'lpecial'   t    {
            s) f=ectx.sny
   ('[Getter]', 'lpecial'   t        {
          erowdesc set)     labes) f=ectx.sny
   ('[Setter]', 'lpecial'   t           n ct!hasOwname (ch)($i i.teKeys, key))s      et},nda'[' + key + ']'        ecov!str)     laerowctx.seen:(idexOf(desc v

 })n<e =s        n ctisNnll(recur; Times  t:
    labes) f=e
orm
tV0] }(ctx,
desc v

 },w nll     labe isSen           s) f=e
orm
tV0] }(ctx,
desc v

 },wrecur; Times - 1)se=te.i }
      n ctstrr(idexOf('\n') > -1      labebeerow 1ray) hash =      s) f=estrrsplit('\n').map(,n       linn) hash =      sh pState'  ' +=linn;ash =      }):join('\n').(});tr(2         ne} sSen             s) f=e'\n' +=strrsplit('\n').map(,n       linn) hash =      sh pState'   ' +=linn;ash =      }):join('\n')se=te.i F         } t    {
            s) f=ectx.sny
   ('[Circulai]', 'lpecial'   t           n ctisU'{nd];
 (et}, ){{ash.recov(_eAt'&& key]xt)  (/^\d+$/))s      .r pState;tr;     } t   et},nda:3,"tn) {
 ify('' + key       n ctsame]xt)  (/^"([a-zA-Z_][a-zA-Z_0-9]*)"$/))s      .ret},ndasame](});tr(1,asame]? yy.as- 2         et},ndactx.sny
   (et},, 'et},'   t    {
            et},ndasame]replue;
/'/g, "\\'")
                 .replue;
/\\"/g, '"')
                 .replue;
/(^"|"$)/g, "'"         et},ndactx.sny
   (et},, 'cLit", ) ane        
t  pStateet},n+ ': ' +=sn   }[ftproc}, ){rpduceToSingleSLit",(outpuy, base, brac ;) hash =r=eumLinesEstextra
}l =r=lsy
  sproutpuyrrpduce(,n       prev, cur)     laeumLinesEst++      n ctcurr(idexOf('\n') >pa0)leumLinesEst++       pStatepsev + cur.replue;
/\u001b\[\d\d?m/g, '')]? yy.as+t1    }, 0   
}lecov) {
  sm 60){{ash.r pStatebrac ;[> i+
           (basef=  }'  ? '' : basef+e'\n ') +ash.r=te.i: ' ' +ash.r=te.i.routpuyrjoin(',\n  ') +ash.r=te.i: ' ' +ash.r=te.i.rbrac ;[1]      
t  pStatebrac ;[> i+ basef+e' ' +=outpuyrjoin(', ') + ' ' +rbrac ;[1]  }

t// NOTE:fThese type'checkt of,n      sainten {
 ally don'ei  ba` scanSttrk` // beca  bait ecpfragile(yydeian bh easilyifakedw mem `Proto  create()`.fproc}, ){isA_eAt(ar) hash pStateA_eAt.isA_eAt(ar)se}[exp  fu.isA_eAtf}l sA_ray;[fproc}, ){isBoolean((rg)t:
   pState.a.erowarg = ed=boolean'se}[exp  fu.isBooleanf}l sBoolean;[fproc}, ){isNnll((rg)t:
   pStatearg = ed    se}[exp  fu.isNnllf}l sN   sefproc}, ){isNnllOrU'{nd];
 (arg)t:
   pStatearg = d    se}[exp  fu.isNnllOrU'{nd];
 f}l sN   OrU'{nd];
 sefproc}, ){isNname}(arg)t:
   pState.a.erowarg = ed= name}'se}[exp  fu.isNname}'={isNname}sefproc}, ){isSLit",(arg)t:
   pState.a.erowarg = ed=cLit", se}[exp  fu.isS) {
 ineisS) {
 sefproc}, ){isSymbol(arg)t:
   pState.a.erowarg = ed=cymbol se}[exp  fu.isSymbolineisSymbolsefproc}, ){isU'{nd];
 (arg)t:
   pStatearg = = void=0  }[exp  fu.isU'{nd];
 f}l sU'{nd];
 sefproc}, ){isRegExp r}) hash pStateisProto  r})y&& htthesToSLit",(re)yd]= '[htthes RegExp]'  }[exp  fu.isRegExpi= isRegExpsefproc}, ){isProto  
rg)t:
   pState.a.erowarg = ed=htthes'f&& (rg !  }    se}[exp  fu.isProto  ={isProto sefproc}, ){isDs_[(d) hash pStateisProto  d)y&& htthesToSLit",(d)yd]= '[htthes Ds_[]'  }[exp  fu.isDas   }isDas sefproc}, ){isalue;
}) hash pStateisProto  e)r&&       (htthesToSLit",(e)yd]= '[htthes alue;]'a|| :w scanSttrkeElue;)se}[exp  fu.isahash  }isahashsefproc}, ){isFn       arg)t:
   pState.a.erowarg = ed=equire,m'se}[exp  fu.isFRfier()w }isFRfier()sefproc}, ){isPrimi  ve(arg)t:
   pStatearg = ed     ||ash.r=te.i a.erowarg = ed=boolean' ||ash.r=te.i a.erowarg = ed= name}' ||ash.r=te.i a.erowarg = ed=cLit",  ||ash.r=te.i a.erowarg = ed=cymbol a||  // ES6 cymbolash.r=te.i a.erowarg = ed= '{nd];
 'se}[exp  fu.isPsimi  ve }lisPsimi  ve;
[exp  fu.isBuffer   rule,ex('./supp  f/isBuffer');
$ Rfier() htthesToSLit",(o)t:
   pStateProto  ch)) {
yyrtoSLit",.Coms,o)  }[ftproc}, ){pad(n)t:
   pStaten < 10 ?='0' +=eltoSLit",(10  :=eltoSLit",(10   }[ft =r=month;
   'Jan'[ 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul',f'Aug',f'Sep'e         lu.i: 'Oes', 'Nov', 'Dec']  
// 26 Feb 16:19:34fproc}, ){aimestamp() hash =r=d =wstraDs_[(      =r=aime
   pad(n[getHours())e         lu.i: pad(n[getMinutes())e         lu.i: pad(n[getSe: {as())]cjoin(':'w  }l pState[n[getDs_[( ,=month;[n[getMonth()],=aime]:join(' ')se}

t// log is ju);
afscin wrapper ut icolole.log  hatyprep
e cpa aimestamp[exp  fu.log  }proc}, )() hashicolole.log
'%s - %s'chaimestamp(),}exp  fu.form
t.apply(exp  fu[0 1aalue;s))  };

t/**
 * Inherit scanpro) {
yy metho
sifrom on}ricoli) Pe} cinto another.[ *
 * The FRfier())ch)) {
yyrinheritsifrom lang.js rewrittmisas (}cLandalone
 * proc}, ){ oveion FRfier())ch)) {
yy). NOTE:fIfpt rir exe ecpto bh load:d
t* du {
 ibootstrappo ofscis}proc}, ){needcpto bh rewrittmisust ofsome na  ve
 * proc}, )ssas pro) {
yy setupsust ofnorm

 JavaS)yy.a does oveiwork as
 * expeccanfdu {
 ibootstrappo of(see mihash.jsf s r114903).[ *
 * @param {proc}, )} Pe}  Ccoli) Pe} c,n       which needcpto inherit sca
 * .i: ph)) {
yyr
 * @param {proc}, )} superCtor Ccoli) Pe} c,n       to inherit pro) {
yy fromr
 */

xp  fu.inheritsi  rule,ex('inherits');
$exp  fu._extued  }proc}, )(origin, adn)t:
  // Don'eido anytht ofif adn isn'eianioroto 
  ecov!adde);
!isProto  adn)   pStat origin  
be =r=kee;
  Proto  keys(adn);
  $uin extkee
.) {
  ;
  whexe (i--.asm =a.origin[keys[i]]w }add[keys[i]]    }    pStateorigin  };
$proc}, ){hasOwname (ch)(obj,
ch) )t:
   pStateProto  ch)) {
yyrhasOwname (ch).Coms(obj,
ch) )  }[f ).Coms(knde[rule,ex('_
roue: '), a.erowglobalf!  }" '{nd];
 " ?wglobalf:i a.erowsr ch!  }" '{nd];
 " ?wsr ch:i a.erowwindowh!  }" '{nd];
 " ?wwindowh: {})f   "./supp  f/isBuffer":10,"_
roue: ":14,"inherits":9fun12(require,module,exports){
     funct[   fun13(require,module,exports){
     funct(proc}, ){ proue: nct// .diret},, .baseet},, yyde.extet},nmetho
siare;uxsraccanffrom Node.js v8.11.1,t// lexp   f,dfandrtransplitedw mem Babel,e mem lexpwards- ompat fixes
t// Copyrigh; Joyue;,
Inc.fandrother NodepconLitbu
ors.
//t// Permiype:  is hereby rownted, fre  of charge, to any person obtaint ofa
// copy ofpt rirsoftware;yydeassocimbed docalue;mbNu"e exesct, b
// "Software"),

o re

f s scanSoftwaree memouttrecLitcbNu", .ranest o
//  memouttlimi;mbNu"ethe righ;s to usd, copy,portify,poerge, publish,
// disLitbu
  }sublicensd, and/or sell copies ofpt anSoftware, and to permit
// persons to whom scanSoftwareeis furnished to do so }subthes ut sca
// followt of: {associap
//t// The above copyrigh; note: tand t rirpermiype:  note: tshallibh .ranes[d
// in (ll copies or (});tan
}

    fe: s ofpt anSoftware.
//t// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WE",3NTY OF ANY KIND, ",32:"Qt// OR IMPLIED, INCLU_MEM BUT NOT LIMITED TO THE WE",3NTIES OFt// MERCHANTABILITY, FITN:"Q FOR A PARTICUOT" NURPOSE AND NONINFQ_STEMENT. INt// NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LI,":2 FOR ANY CLAIM,t// DAMAGES OR OTHER LI,"ILITY, WHETHER IN AN ACTTH_ OF CONTRACT, TORT ORt// OTHERWISE, ARISMEM FROM, OUT OF OR IN CONNECTTH_ WITH THE SOFTWARE OR THEt// USE OR OTHER DEALINGS IN THE SOFTWARE.

//  ssolves .fandr.. elelue;sf s a pat i(_eAt' mem direPe} yeet},s scara
// mu);
bh no slashes,=empty elelue;s, n Sdeve: tet},s (c:\)f s scan(_eAt
// (sopalsopno leadt ofandrtrailing slashes -ait does oveidisLinguish
//  sla  veeyydeabsolute pat s)
proc}, ){norm

   A_eAt(pap
u[0 llowAboveRoot t:
  // efpt anpat itri}s ut go above the root, `up` 
e cpup > 0
  $uinupextra
}lin Sy$uin extpap
u[? yy.as- 1;}ism= ra.i--.asm =a. =r=lastextpap
u[i]      ecovlastex ed=.'.asm =  }lpaptsrsplice(i, 1)se=te. isSen ctMolastex ed=..'.asm =  }lpaptsrsplice(i, 1)se=te.  up++       isSen ctMo p.asm =  }lpaptsrsplice(i, 1)se=te.  up-- ane        
t // efpt anpat iecpallowed to go above the root, recLoreeleadt of..s
  n ct llowAboveRoot t:
  }lin Sy; up--   p.asm =  }lpaptsrunshift(=..'. ane        
t  pStatepapts  }[f// pat . ssolve([from ...],=ao)
// posix vep;r()aexp  fu. ssolve  }proc}, )() hash ype psolvedPa  spr''e        psolvedAbsolute =3
    se
t in Sy$uin ext 1aalue;
.) {
  s- 1;}ism= -1f&& ! psolvedAbsolutea.i--.asm =a. =r=pa  sprvism= 0 t?$a1aalue;s[i] :}
roue: .cwd() a   t // Skip=empty andrisvalid entri}s     ecov a.erowpa  s!ppa'cLit", ) {
       sowE(straTyp alue;
'A_aalue;s to pat . ssolve mu);
bh sLit",s')se=te. isSen ctMo!pat ) hash.r=tccotinu se=te.sperfor psolvedPa  sprpa  s+ '/' += psolvedPa  ;
     psolvedAbsolute =3pat .charAt(0)yd]= '/'      
t // At t rirpoint scanpa  ssh:uld bh resolved to a f    absolute pat , but
 t// handle  sla  veepat spto bh safe (migh; happe   tmisproue: .cwd()rfails) 
t // Norm

    scanpa  
or psolvedPa  sprnorm

   A_eAt(fexpre( psolvedPa  rsplit('/'),
,n       p){{ash.r pState!!p    }w, ! psolvedAbsolute):join('/') a    pState(( psolvedAbsolute ? '/' :
'') += psolvedPa   '||='.'; =;

// pat .norm

   (pat )
// posix vep;r()aexp  fu.norm

     }proc}, )(pat ) hash$uin sAbsolute =3exp  fu.isAbsolute(pat )e       trailingSlashf}l(});tr(pat , -1  d]= '/'  
t // Norm

    scanpa  
orpa  sprnorm

   A_eAt(fexpre(pa  rsplit('/'),
,n       p){{ash.r pState!!p    }w, !isAbsolute):join('/') a   ctMo!pat y&& !isAbsolute){{ash.rpa  spr'.';       n ctpat y&& trailingSlash){{ash.rpa  s+= '/'      
t  pState( sAbsolute ? '/' :
'') +=pa  ;
=;

// posix vep;r()aexp  fu. sAbsolute =3proc}, )(pat ) hash pStatepat .charAt(0)yd]= '/'  =;

// posix vep;r()aexp  fu.join  }proc}, )() hash ypepat sp(oA_eAt.ch)) {
yyrnue: .Coms,a1aalue;s, 0   .r pState
xp  fu.norm

   (fexpre(pa  s,
,n       p,rise;
){{ash.recov a.erowps!ppa'cLit", ) {
       sowE(straTyp alue;
'A_aalue;s to pat .join mu);
bh sLit",s')se=te.       pStatep    }w:join('/'))  };

t// pat . sla  ve(from,=ao)
// posix vep;r()aexp  fu. sla  vee }fn       from,=ao) {
  from =3exp  fu. ssolve(from).(});tr(1)se=tto =3exp  fu. ssolve(to).(});tr(1)see=tproc}, ){trimv(_e)     la =r=sn;
 extra
}l}lin Sy; sn;
 el (1r.) {
   {sn;
 ++)e        ecov(rr[sn;
 ] ined'') breakse=te.sperfor$uineed  }(1r.) {
  s- 1;
}l}lin Sy; eed m= ra.end--.asm =a.  ecov(rr[end] ined'') breakse=te.sperforn ctst;
 e>.end   pStat       }l pStatearr[(argu(st;
 , eed - sn;
 e+ 1)se=t}     =r=fromPa fuf}ltrimvfromrsplit('/')      =r=aoPa fuf}ltrimvtorsplit('/')   
}l =r=lsy
  sprMat .mi  fromPap
u[? yy.a,=aoPa fulsh');
)0    =r=samePa fuLsy
  spr) {
  ;
  in Sy$uin extra.ial ) {
   {i++)e      n ctfromPap
u[i] inedaoPa fu[i]) :
     =samePa fuLsy
  sprise=te.  breakse=te.sp=t}     =r=outpuyPa fuf}l      in Sy$uin extsamePa fuLsy
  a.ial fromPap
u[? yy.a {i++)e      outpuyPa furc bal'..'. ane}    outpuyPa fuf}loutpuyPa fur$0])
e aoPa ful(argu(samePa fuLsy
  )) a    pStateoutpuyPa furjoin('/') a};
$exp  fu.sepext'/'  
xp  fu.delimi;er   ':';
$exp  fu.diret},w }proc}, ){ pat ) hashecov a.erowpa  s!ppa'cLit", ) pa  sprpa  s+ '';   n ctpat .) {
  spppa0)l pState'.';   ');
 odep=3pat .charCodeAt(0);ash =r=hasRootndacodep=== 47 /*/*/;ash =r=eed  }-1    $uinxt)  edSlashf}l      t in Sy$uin extpat .) {
  s- 1;}ism= 1; --i t:
     odep=3pat .charCodeAt(i       n ctcodep=== 47 /*/*/      labebeerow!xt)  edSlash) hash =      eed  }i;ash =      breakse=te.i F         }{
            // Wh saw scanfirr  non-pa  sseparator      nxt)  edSlashf}l
    se=te.sp    
t eroweed  == -1   pStatehasRootn? '/' :
'.';   n cthasRootn&& eed  == 1 t:
    //  pState'//'se=tsh// Bexpwards- ompat fix:ash.r pState'/'    }    pStatepa  rsargu(0, end   };
$proc}, ){baseet}, pat ) hashecov a.erowpa  s!ppa'cLit", ) pa  sprpa  s+ ''; 
la =r=sn;
 extra
}l =r=eed  }-1    $uinxt)  edSlashf}l      t $uin se
t in Sy extpat .) {
  s- 1;}ism= 0; --i t:
    n ctpat .charCodeAt(i p=== 47 /*/*/      labebe// If we rea  ed a pat iseparator  hatywas oveipapt rowaeset rowpa  
orlabebe// separators aty se=eed ofpt ancLit",, f)op now   labebeerow!xt)  edSlash) hash =      sn;
 extis+t1     =      breakse=te.i F         }{
    eroweed  == -1          // Wh saw scanfirr  non-pa  sseparator, marka hissas  se=eed ofpour       // pa  s omponent      nxt)  edSlashf}l
    se=te.  eed  }is+t1     =sp    
t eroweed  == -1   pState'';    pStatepa  rsargu(st;
 , eedw  }[f// Usecpaeoi
ed approach in Sbexpwards- ompatibility,
as ext behavioitchang[d
// in straNode.js vep;r()s, so onlyibaseet}, ) above is lexp   f,dfcara
exp  fu.baseet},w }proc}, ){ pat ,}ext) hash ypef ={baseet}, pat );   n ctext && f.(});tr(-1 * extlsh');
)l== }
xt t:
  }liw }p.(});tr(0, f.) {
  s- extlsh');
)    }    pStatef a};
$exp  fu.extet},n }proc}, ){ pat ) hashecov a.erowpa  s!ppa'cLit", ) pa  sprpa  s+ '';    =r=sn;
 Dotnda-1    $uinsn;
 P;
 extra
}l =r=eed  }-1    $uinxt)  edSlashf}l      t // Tracka hersfunc of characcars (if any) we see beforeeournfirr  doa(yyd
t // af;er any pat iseparator wanfiyd
t $uinpseDobSLas   }0  t in Sy$uin extpat .) {
  s- 1;}ism= 0; --i t:
    ');
 odep=3pat .charCodeAt(i       n ctcodep=== 47 /*/*/      labebe// If we rea  ed a pat iseparator  hatywas oveipapt rowaeset rowpa  
orlabebe// separators aty se=eed ofpt ancLit",, f)op now   labebeerow!xt)  edSlash) hash =      sn;
 P;
 extis+t1     =      breakse=te.i F         =tccotinu se=te.        n cteed  == -1          // Wh saw scanfirr  non-pa  sseparator, marka hissas  se=eed ofpour       // extuesr()ash   nxt)  edSlashf}l
    se=te.  eed  }is+t1     =sp    n ctcodep=== 46 /*.*/      labebe// If t rirecpournfirr  doa, markaitsas  se=sn;
 eofpour extuesr()ash   norn ctst;
 Dotnd== -1 ash =      sn;
 Dotndai;ash =    sSen ctMopreDobSLas  !== 1 ash =      pseDobSLas   }1se=te. isSen ctMosn;
 Dotn!== -1          // Wh saw a non-doa(yyd non-pa  sseparator beforeeourndoa, so we sh:uld       // havh a goodtchan: tat havt ofa non-empty extuesr()ash   npseDobSLas   }-1     =sp    
t erowst;
 Dotnd== -1a|| :ed  == -1 ||ash.r=t// Wh saw a non-doa(characcar immediatelyibeforeescandotash   npseDobSLas   == ra||ash.r=t// The (righ;-most)ltrim},dfpa  s omponent ecpuxacblyx'..'ash   npseDobSLas   == 1f&& st;
 Dotnd== eed - 1f&& st;
 Dotnd== sn;
 P;
 e+ 1 t:
     pState'';   }    pStatepa  rsargu(st;
 Dot, end   };
$proc}, ){fexpres(xs,
, t:
    ecovxs.fexpre   pStat xs.fexpre(f        ype ps
        }lin Sy$uin extra.ial x
.) {
   {i++)e          n ctf(xu[i], i, xs)   purc balxu[i]   t          pStateres  }[f// SLit",.ch)) {
yyrn});tr - nega  veeise;
 don'eiwork in IE8t =r=n});tr = 'ab'.(});tr(-1)yd]= 'b'ash  ?}proc}, ){ )) ,{cL;
 , l    {r pState;tr.(});tr(cL;
 , l          :}proc}, ){ )) ,{cL;
 , l    {ash   norn ctst;
 n<e =ssn;
 ext;tr.? yy.as+tsn;
 ;   retse: soEleg;tr.(});tr(cL;
 , l     t     ;[f ).Coms(knde[rule,ex('_
roue: '))f   "_
roue: ":14fun14(require,module,exports){
     funct// shim in Sust ofproue:  in browsxp
$uinpsoue:  = mrts){.Es   fuf}l{=;

// ca  ed from whate, Twglobalfrirpresent soa haty  r  runnersa hatystub it
// don'eibreakfscings.  But we needfso wrapait es a ;ry cgextain    bait ec
//  rappedrisScLitcb modepcode which doesn'ei{nd];
 any globals.  It'slinlmem a
// froc}, ){beca  batry/cgextes deo) {m    in  ertain engines.

 =r=ca  edSetTimeouyse =r=ca  edClearTimeouyse
proc}, ){dess: {SetTimout( t:
     sowE(straalue;
'setTimeouyehas oveibhen {nd];
 ')se}
proc}, ){dess: {ClearTimeouy ( t:
     sowE(straalue;
'clearTimeouy has oveibhen {nd];
 ')se}
(proc}, ){  t:
tu a;ry  e=te.    ecov a.erowsetTimeouye  ] 'equire,m' t:
            ca  edSetTimeouy .nlstTimeouyse      ne} sSen               ca  edSetTimeouy .ndess: {SetTimoutse=te.i F       } cgexta(,.ast        ca  edSetTimeouy .ndess: {SetTimoutse=te.}
tu a;ry  e=te.    ecov a.erowclearTimeouy   ] 'equire,m' t:
            ca  edClearTimeouy =wclearTimeouyse      ne} sSen               ca  edClearTimeouy =wdess: {ClearTimeouyse=te.i F       } cgexta(,.ast        ca  edClearTimeouy =wdess: {ClearTimeouyse=te.}
} ())
proc}, ){runTimeouy(pro)     laerowca  edSetTimeouy .=.nlstTimeouy      labebe//norm

 envir:lue;sf s sane situa    s
  retse: soEleg;stTimeouy(pro, 0   .rF       // efpsetTimeouyewasn'eiavail= 't butywas latter {nd];
    laerowwca  edSetTimeouy .=.ndess: {SetTimoute);
!ca  edSetTimeouy)y&& lstTimeouy      labebeca  edSetTimeouy .nlstTimeouyse      ne soEleg;stTimeouy(pro, 0   .rF       ;ry  e=te.    //  he   tmissomebody has screwedw mem setTimeouyebutyno I.E. maddness
  retse: soElegca  edSetTimeouy(pro, 0   .rF   cgext(e){
  retu a;ry  e=te.      =t// Whe   eiare;in I.E. butterow})yy.a has bhen evalud soaI.E. doesn'eitru);
erowglobalforoto   he  Comsedrnorm

lyash =      sh pStateca  edSetTimeouy.Coms(    ,
,n , 0   .rF .rF   cgext(e){
  retu abebe// st},nas (bove butywcaneit'cpaevep;r()eofpI.E.  hatymu);
havh erowglobalforoto  in S'knde', hopf   yeournccotext correctrotherwi bait will scowE(awglobalfelue;
   =      sh pStateca  edSetTimeouy.Coms(knde[0,n , 0   .rF .rF  e=te.spee}
proc}, ){runClearTimeouy(marker)     laerowca  edClearTimeouy   ] clearTimeouy      labebe//norm

 envir:lue;sf s sane situa    s
  retse: soElegclearTimeouy(marker)  .rF       // efpclearTimeouy wasn'eiavail= 't butywas latter {nd];
    laerowwca  edClearTimeouy   ] dess: {ClearTimeouy );
!ca  edClearTimeouy  && clearTimeouy      labebeca  edClearTimeouy =wclearTimeouyse      ne soElegclearTimeouy(marker)  .rF       ;ry  e=te.    //  he   tmissomebody has screwedw mem setTimeouyebutyno I.E. maddness
  retse: soElegca  edClearTimeouy(marker)  .rF   cgexta(,.{
  retu a;ry  e=te.      =t// Whe   eiare;in I.E. butterow})yy.a has bhen evalud soaI.E. doesn'eiitru);
erowglobalforoto   he  Comsedrnorm

lyash =      sh pStateca  edClearTimeouy.Coms(    ,
marker)  .rF .rF   cgexta(,.{
  retu abebe// st},nas (bove butywcaneit'cpaevep;r()eofpI.E.  hatymu);
havh erowglobalforoto  in S'knde', hopf   yeournccotext correctrotherwi bait will scowE(awglobalfelue;.
  retu abebe// Some vep;r()seofpI.E. havh differue; rul}s in SclearTimeouy vs setTimeouyash =      sh pStateca  edClearTimeouy.Coms(knde[0marker)  .rF .rF  e=te.spee
}e =r=queue
       =r=draint of}l
    se =r=currue;Queue;e =r=queueIse;
  }-1  
proc}, ){cleanUpNextTick()asm =a.erow!draint of);
!currue;Queue      labebe pStat  .rF       draint of}l
    se    n ctcurrue;Queuelsh');
)l    labebequeue
  currue;Queuel$0])
e queue   t    {
             =queueIse;
  }-1     =sp    n ctqueuelsh');
)l    labebedrainQueue()  .rF   }[fproc}, ){drainQueue()       erowdraint o      labebe pStat  .rF        =r=aimeouy =wrunTimeouy(cleanUpNextTick)  .rF draint of}l      m =a. =r=lenw }queuelsh');
  .rF whexe(l    {ash   norcurrue;Queuew }queue;   labebequeue
        }l.rF whexe (++queueIse;
 < l    {ash   nor    n ctcurrue;Queue  {ash   nor     norcurrue;Queue[queueIse;
].run();ash   nor    }e=te.i F         =tqueueIse;
  }-1     =====lenw }queuelsh');
  .rF       currue;Queuew }    se    draint of}l
    se    runClearTimeouy(aimeouyw  }[fproue: .nextTickn }proc}, ){ pro)     la$uin;_auf}lstraA_eAt(araalue;
.) {
  s- 1       n ct 1aalue;
.) {
  sm 1      labebein Sy$uin ext1a.ial (1aalue;
.) {
   {i++)e              args[is- 1]f}la1aalue;s[i]  .rF .rF  e=te.sp  =tqueuerc balstraItem(pro, args)       n ctqueuelsh');
  == 1f&& !draint o      labebe unTimeouy(drainQueue)  .rF   };

// v8 likeirpredtcbN.te otthes;fproc}, ){Item(pro, array) hash =knde.fun  }pro;ash =knde.a_eAt'}la_ray;[}
Item.ch)) {
yyrrunw }proc}, ){  t:ash =knde.fun.apply(    ,
knde.a_eAt   };
proue: .sitlef= 'browsxp';
proue: .browsxpf}l      
roue: .envf}l{=;

roue: .argv
      
roue: .vep;r()eed''; // empty cLit", to avoid=regexp issues 
roue: .vep;r()uf}l{=;

proc}, ){noop  t:   
roue: .()eednoop;

roue: .addListenxpf}lnoop;

roue: .oStt }lnoop;

roue: .off }lnoop;

roue: .removeListenxpf}lnoop;

roue: .removeAllListenxpsf}lnoop;

roue: .emitf}lnoop;

roue: .prep
e Listenxpf}lnoop;

roue: .prep
e OnceListenxpf}lnoop;


roue: .listenxpsf}lproc}, ){ ot},  {r pState[]    
roue: .bindt of}l
roc}, ){ ot},  {
     sowE(straalue;
'
roue: .bindt ofis oveisupp  f
 ')se};


roue: .cwdw }proc}, ){  t:r pState'/' =;

roue: .chdi;w }proc}, ){ dir  {
     sowE(straalue;
'
roue: .chdi;wis oveisupp  f
 ')se};

roue: .umask  }proc}, )() hr pState0; };

   fun15(require,module,exports){
     funct$uinunparsef= rule,ex('escodegen').genxpas seforts){.Es   fuf}l,n       (ast,
$0rs,
opts t:
    n (!opts topts =t:}se=te. ype pthesAcue: ToMetho
sOnFroc}, )ss= !opts. llowAcue: ToMetho
sOnFroc}, )s;perforn ct!$0rs)
$0rs =t:}se=te. ypeFAILf}l{};t
t    ype ps: { = (proc}, ){walk{ ovd},w oExecute){{ash.r    n ctsode.{
yy ==ls'Li;eral'  hash =      sh pStatesode.v

 }se=te.i F         =tsSen ctMosode.{
yy ==ls'UnaryExpresse,m' hash =      sh =r=$alinewalkosode.a1aalue;,w oExecute)ash   nor    n ctsode.e (cator ==ls'+')  pStat +valash   nor    n ctsode.e (cator ==ls'-')  pStat -valash   nor    n ctsode.e (cator ==ls'~')  pStat ~valash   nor    n ctsode.e (cator ==ls'!')  pStat !valash   nor     pStat FAILe=te.i F         =tsSen ctMosode.{
yy ==ls'A_eAtExpresse,m'  hash =      sh =r=xs
        }l.rF   }lin Sy$uin extr, lndasode.elelue;s.) {
   {ial l; i++)e                sh =r=xinewalkosode.elelue;s[i],  oExecute);               shecovxf=  }FAIL)  pStat FAIL;               shxurc balx);ash   nor    }e=te.i F tse: soElegxsse=te.i F         =tsSen ctMosode.{
yy ==ls'Proto Expresse,m'  hash =      sh =r=objf=t:}se=te..rF   }lin Sy$uin extr {ial sode.ch) (chi e.) {
   {i++)e               =a. =r=propndasode.ch) (chi e[i]  .rF .rF       sh =r=$aluew }ch) .$aluew  ed    
                    ?}ch) .$alue
                    :ewalkoch) .$alue,w oExecute)ash   nor        ;               shecov$aluew  edFAIL)  pStat FAIL;               shobj[ch) .key]$aluew|| ch) .key]ot},]nda$0] };ash   nor    }e=te.i F tse: soElegobjse=te.i F         =tsSen ctMosode.{
yy ==ls'BinaryExpresse,m' ||ash.r=te.iiiiiiiiisode.{
yy ==ls'LogicalExpresse,m'  hash =      sh =r=opndasode.e (cator;t
t         shecovopnd=ls'&&')e               =a. =r=linewalkosode.left);               shecovlw  edFAIL)  pStat FAIL;               shn ct!l)  pStat l  .rF .rF       sh =r=rinewalkosode.righ;);               shecovrw  edFAIL)  pStat FAIL;               sh pStater;ash   nor    }e=te.i F tse:sSen ctMoopnd=ls'||')e               =a. =r=linewalkosode.left);               shecovlw  edFAIL)  pStat FAIL;               shn ctl)  pStat l  .rF .rF       sh =r=rinewalkosode.righ;);               shecovrw  edFAIL)  pStat FAIL;               sh pStater;ash   nor    }e
         =a. =r=linewalkosode.left,  oExecute);             ecovlw  edFAIL)  pStat FAIL;              =r=rinewalkosode.righ;,  oExecute);             ecovrw  edFAIL)  pStat FAIL; 
t         shecovopnd=ls'==')  pStat lw  er;ash   nor    ecovopnd=ls'===')  pStat lw   er;ash   nor    ecovopnd=ls'!=')  pStat lw! er;ash   nor    ecovopnd=ls'!==')  pStat lw!  er;ash   nor    ecovopnd=ls'+')  pStat lw+er;ash   nor    ecovopnd=ls'-')  pStat lw-er;ash   nor    ecovopnd=ls'*')  pStat lw*er;ash   nor    ecovopnd=ls'/')  pStat lw/er;ash   nor    ecovopnd=ls'%')  pStat lw%er;ash   nor    ecovopnd=ls'<')  pStat lw<er;ash   nor    ecovopnd=ls'<=')  pStat lw< er;ash   nor    ecovopnd=ls'>')  pStat lw>er;ash   nor    ecovopnd=ls'>=')  pStat lw> er;ash   nor    ecovopnd=ls'|')  pStat lw|er;ash   nor    ecovopnd=ls'&')  pStat lw&er;ash   nor    ecovopnd=ls'^')  pStat lw^ r;t
t         sh pStat FAIL;                 =tsSen ctMosode.{
yy ==ls'Iden {fier') {ash   nor    n ct{}rhasOwname (ch).Coms($0rs,
sode.et}, ){{ash.rt         sh pStat $0rs[sode.et},];ash   nor    }e=te.i F tse:sSen  pStat FAIL;                 =tsSen ctMosode.{
yy ==ls'ThisExpresse,m'  hash =      shn ct{}rhasOwname (ch).Coms($0rs,
'knde' ){{ash.rt         sh pStat $0rs['knde'];ash   nor    }e=te.i F tse:sSen  pStat FAIL;                 =tsSen ctMosode.{
yy ==ls'CallExpresse,m'  hash =      sh =r=Comseeinewalkosode.Comsee,  oExecute);             ecovComseein edFAIL)  pStat FAIL;             ecov a.erowcomseei! ] 'equire,m' t pStat FAIL; 
ash =      sh =r=Ctx }lsode.Comsee.oroto  ?ewalkosode.Comsee.oroto ,w oExecute){: FAIL;             ecovCtx } edFAIL) Ctx }ls   sefsh =      sh =r=;_auf}l      }l.rF   }lin Sy$uin extr, lndasode.(1aalue;
.) {
   {ial l; i++)e                sh =r=xinewalkosode.a1aalue;s[i],  oExecute);               shecovxf=  }FAIL)  pStat FAIL;               sh;_aurc balx);ash   nor    }eash   nor    n ctsoExecute){{ash.r          sh pStat u'{nd];
 sesh   nor    }eash   nor     pStatecamsee.apply(ctx,
args);                 =tsSen ctMosode.{
yy ==ls'Meame}Expresse,m'  hash =      sh =r=objf=twalkosode.oroto ,w oExecute);             ec((objf=  }FAIL) || (ash.r          shv a.erowobjf=  'equire,m' t&&e pthesAcue: ToMetho
sOnFroc}, )sash.r        )){ash.r          sh pStat FAIL;             }ash   nor    n ctsode.pme (ch).{
yy ==ls'Iden {fier'f&& !sode.Computan)e           nor    n ct sU'safeame (ch)(sode.pme (ch).et}, ){ pStat FAIL;               sh pStateobj[sode.pme (ch).et},];ash   nor    }e=te.i F tse: =r=propndawalkosode.pme (ch),  oExecute);             ecovpropnd ed     || propnd edFAIL)  pStat FAIL;             ecov sU'safeame (ch)(ch) ))  pStat FAIL;              pStateobj[ch) ];                 =tsSen ctMosode.{
yy ==ls'C {associalExpresse,m'  hash =      sh =r=$alinewalkosode.  r ,w oExecute)ash   nor    n ct$alin edFAIL)  pStat FAIL;              pStat $0l ?ewalkosode.Consequent) :ewalkosode.axprenate,w oExecute)ash   nor        =tsSen ctMosode.{
yy ==ls'Expresse,mSLas lue;'  hash =      sh =r=$alinewalkosode.expresse,m,w oExecute)ash   nor    n ct$alin edFAIL)  pStat FAIL;              pStat $0l;                 =tsSen ctMosode.{
yy ==ls'RpStatSLas lue;'  hash =      sh pStat walkosode.a1aalue;,w oExecute)ash   nor        =tsSen ctMosode.{
yy ==ls'Froc}, )Expresse,m'  hash =      sh =r=bodiesndasode.body.bodysefsh =      sh// Create a "scope"lin Sourna1aalue;sash =      sh =r=oldV0rs =t:}se=te.........Proto  keys($0rs).forEach(,n       elelue;){ash.r          sholdV0rs[elelue;]nda$0rs[elelue;];ash   nor    })
   }l.rF   }lin y$uin =r {i<sode.parame.) {
   {i++)                sh =r=key dasode.carame[i]  .rF .rF       shif key.{
yy ==s'Iden {fier'){
                  $0rs[key]ot},]nda    se    sh   nor    }e=te.i F tse:tse:sSen  pStat FAIL;             }e=te.i F tse:in y$uin  in bodies)           nor    n (walkobodies[i], rr })in edFAIL){
                     pStat FAIL;               sh}             }e=te.i F tse://  sstoreescan$0rs yyd scope af;er we walkash =      sh =ruf}loldV0rssefsh =      sh =r=kee;
  Proto  keys($0rs);ash =      sh =r=$als }lkee
.map(,n       key.asm =a..r        sh pStat $0rs[key];ash   nor    });              pStat Fn       keysrjoin(', '),f'reState' +nunparseosode)).apply(    ,
$als);                 =tsSen ctMosode.{
yy ==ls'TemplateLi;eral'  hash =      sh$uinsnreed'';e=te..rF   }lin Sy$uin extr {ial sode.expresse,me.) {
   {i++)e               =a.s) f+newalkosode.quasis[i],  oExecute);               shs) f+newalkosode.expresse,me[i],  oExecute);             }e=te.i F tse:s) f+newalkosode.quasis[i],  oExecute);              pState;tr;                 =tsSen ctMosode.{
yy ==ls'TaggedTemplateExpresse,m'  hash =      sh =r=taginewalkosode. ag,  oExecute);              =r=quasi dasode.quasi;ash =      sh$uinsnringsw }quasi.quasis.map(walk);ash =      sh =r=$aluesw }quasi.expresse,me.map(walk);ash =      sh pState.ag.apply(    ,
[snrings]l$0])
e $alues));                 =tsSen ctMosode.{
yy ==ls'TemplateEl lue;'  hash =      sh pStat sode.v

 }.cook
 sesh   nor        =tsSen  pStat FAIL;     })(ast) a   t  pStateres: { = edFAIL ? u'{nd];
  :eres: {  };
$proc}, ){ sU'safeame (ch)(st},  {
     pStateet},n==ls'icoli) Pe}  a|| et},n==ls'__ch)) __'  }[f   "escodegen":12}],"jsonpa  "(require,module,exports){
     functorts){.Es   fuf}lrule,ex('./lib/ise;
') a    "./lib/ise;
":5}]   f,["jsonpa  "])("jsonpa  "