const { convertXML } = require("simple-xml-to-json");

module.exports.responseHooks = [
  ({ response }) => {
    const responseBody = response.getBody().toString();
    try {
      if (responseBody) {
        const text = String(responseBody);
        const textXml = text.replace(/&lt;/g, "<").replace(/&gt;/g, ">");
        const json = xmlToJsonParse(textXml);
        response.setBody(json);
        return;
      } else {
        response.setBody(responseBody);
      }
    } catch (error) {
      response.setBody(responseBody);
    }
  },
];

function removeFirstXmlHeader(xml) {
  let newXml = xml.replace(/^<\?xml.*?\?>/, "");
  newXml = newXml.replace(/<SOAP-ENV:Envelope.*?>/, "");
  newXml = newXml.replace(/<\/SOAP-ENV:Envelope>/, "");
  newXml = newXml.replace(/<SOAP-ENV:Body>/, "");
  newXml = newXml.replace(/<\/SOAP-ENV:Body>/, "");
  newXml = newXml.replace(/<ns1:ConsultaResponse>/, "");
  newXml = newXml.replace(/<\/ns1:ConsultaResponse>/, "");
  newXml = newXml.replace(/<return.*?>/, "");
  newXml = newXml.replace(/<\/return>/, "");
  return newXml.trim();
}

function xmlToJsonParse(xml) {
  const xmlHeaderRemoved = removeFirstXmlHeader(xml);
  const myJson = JSON.stringify(convertXML(xmlHeaderRemoved));
  return myJson;
}
