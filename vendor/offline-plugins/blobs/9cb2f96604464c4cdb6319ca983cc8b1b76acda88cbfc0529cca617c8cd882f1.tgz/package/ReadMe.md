## Pluggin que transforma XML em JSON

### Não há muita explicação, porque esse é um projeto privado