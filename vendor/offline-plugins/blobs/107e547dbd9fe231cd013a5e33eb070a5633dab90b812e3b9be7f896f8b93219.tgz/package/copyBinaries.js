/*
 * Copyright (c) Microsoft Corporation. All rights reserved.
 * Licensed under the MIT License.
 */
var fs = require("fs");
var path = require("path");

var supportedPlatform = ["win32","darwin", "linux"];
var supportedArch = ["x64", "ia32", "arm64"];

if (!supportedPlatform.includes(process.platform)) {
    return;
}

var platformMapping = {
    "win32": "windows",
    "darwin": "macos",
    "linux": "linux"
};

// If ./dist doesn't exist this is a clean install and binaries don't exist yet
if (fs.existsSync(path.join(__dirname, "dist"))) {
    // Validate that the current system's architecture is supported
    if (supportedArch.includes(process.arch)) {
        var arch = process.arch == "ia32" ? "x86" : process.arch;
        var platform = platformMapping[process.platform];
        var sourceDir = path.join(__dirname, "dist", platform, arch);
        if (fs.existsSync(sourceDir)){
            var destDir = path.join(__dirname, "dist");
            var files = fs.readdirSync(sourceDir);
            // Copy both binaries to the root folder
            files.forEach(filename => {
                var sourceFile = path.join(sourceDir, filename);
                var destFile = path.join(destDir, filename);
                fs.copyFileSync(sourceFile, destFile);

            });
        }
    }
}
