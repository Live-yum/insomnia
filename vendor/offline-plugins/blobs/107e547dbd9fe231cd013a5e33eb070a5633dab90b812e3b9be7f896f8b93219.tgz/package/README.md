# Microsoft Authentication Library - Node Runtime Interop (msal-node-runtime)

This package is not intended or supported for direct use, please refer to [`msal-node`](https://www.npmjs.com/package/@azure/msal-node) and [`msal-node-extensions`](https://www.npmjs.com/package/@azure/msal-node-extensions) to add authentication to your Node.js app.
