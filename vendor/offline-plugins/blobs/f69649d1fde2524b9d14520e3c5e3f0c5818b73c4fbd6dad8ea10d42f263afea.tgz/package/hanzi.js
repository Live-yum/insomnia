

// 'use strict';
const crypto = require('crypto');

//生成加密强伪随机数据. size参数是指示要生成的字节数的数值。
function aa(len){
        // isFinite 判断是否为有限数值
    if (!Number.isFinite(len)) {
        throw new TypeError('Expected a finite number');
    }
    return crypto.randomBytes(Math.ceil(len / 2)).toString('hex').slice(0, len);
}

console.log(aa(13))




// 随机生成生僻汉字
function getRandomText(){ 
    eval( "var word=" +  '"\\u' + (Math.round(Math.random() * 20901) + 19968).toString(16)+'"')//生成随机生僻汉字
    return word;
}

// console.log(getRandomText())


