

var Random = require('./random/')

// console.log(Random.first()) // 随机生成一个常见的英文名。


// console.log(Random.img('320x240',`${Random.color()}`, `${Random.id()}.png`, 'aaa'))


// console.log(Random.bool(0,3)) // 返回一个随机的布尔值。

// console.log(Random.natural(2,100000000000000))  // 返回一个随机的自然数（大于等于 0 的整数）。

/**
 * Example template tag that generates a random number 
 * between a user-provided MIN and MAX
 */
module.exports.templateTags = [{
    name: 'random',
    displayName: 'Random Everything',
    description: 'Generate random things',
    args: [
        {
            displayName: 'dateType',
            type: 'enum', //枚举类型
            options: [
              { displayName: '英文文本', value: 'paragraph' },
              { displayName: '中文句子', value: 'cparagraph' },
              { displayName: '字母', value: 'word' },
              { displayName: '汉字', value: 'cword' },
              { displayName: '中文名', value: 'cname' },
              { displayName: '英文名', value: 'name' },
              { displayName: 'URL', value: 'url' },
              { displayName: '身份证', value: 'id' },
              { displayName: '城市', value: 'city' },
              { displayName: 'color', value: 'color' },
              { displayName: 'img', value: 'img' },
              { displayName: '正整数', value: 'natural' },
            ],
        },
        // {   
        //     help: '',
        //     displayName: 'Minimum',
        //     description: 'Minimum potential value',
        //     type: 'number',
        //     defaultValue: 0
        // }, 
        {   
            help: args => args[0].value == 'img' ? 'img width' : 'Minimum',
            displayName: 'Minimum',
            description: 'Minimum potential value',
            type: 'number',
            defaultValue: 0
        }, 
        {
            help: args => args[0].value == 'img' ? 'img height' : 'Maximum',
            displayName: 'Maximum',
            description: 'Maximum potential value',
            type: 'number',
            defaultValue: 100
        },
        // {
        //     help: '一个或多个汉字--长度',
        //     displayName: '长度',
        //     type: 'number',
        //     placeholder: '一个或多个汉字--长度',
        //     hide: args => args[0].value !== 'cword',
        // },
    ],
    async run (context, dateType = 'ctitle', min, max) {
        if (typeof dateType === 'string') {
            dateType = dateType.toLowerCase();
        }
        switch (dateType) {
            case 'paragraph':
                return Random.paragraph(min, max);
            case 'cparagraph':
                return Random.cparagraph(min, max);
            case 'word':
                return Random.word(min, max);
            case 'cword':
                return Random.cword(min, max);
            case 'name':
                return Random.name();
            case 'cname':
                return Random.cname();
            case 'url':
                return Random.url();
            case 'id':
                return Random.id();
            case 'city':
                return Random.city();
            case 'color':
                return Random.color();
            case 'natural':
                return Random.natural(min, max);
            case 'img':
                return Random.img(`${min}x${max}`,`${Random.color()}`, `${Random.id()}.png`, `${Random.word(1,20)}`)
            default:
                throw new Error(`Invalid date type "${dateType}"`)
        }
    }
}];
