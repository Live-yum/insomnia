# Changelog
All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.3.0] - 2023-04-25
- Allows passing of custom storage handler which can be used to override the fact that this lib writes to localstorage

## [1.2.15] - 2021-08-09

### Changed
- Readme and post install message

## [1.2.14] - 2021-04-29
### Changed
- Dependency upgrade:
   - https://github.com/supertokens/browser-tabs-lock/pull/21
   - https://github.com/supertokens/browser-tabs-lock/pull/19
   - https://github.com/supertokens/browser-tabs-lock/pull/16


## [1.2.13] - 2021-04-24
### Changed
- Upgraded version of Lodash: https://github.com/supertokens/browser-tabs-lock/issues/20
