var wsse = require('wsse');
/**
 * Example template tag that generates a random number
 * between a user-provided MIN and MAX
 */
module.exports.templateTags = [{
    name: 'WSSE',
    displayName: 'WSSE',
    description: 'Generate a WSSE header',
    args: [
        {
            displayName: 'Username',
            description: 'Username',
            type: 'string'
        },
        {
            displayName: 'API Key',
            description: 'Username API Key',
            type: 'string'
        }
    ],
    async run (context, username, apikey) {
      var token = wsse({ username: username, password: apikey });

      return token.getWSSEHeader({ nonceBase64: true });
    }
}];
