# Insomnia WSSE header

## Installation

```
$ npm install insomnia-plugin-wsse
```
