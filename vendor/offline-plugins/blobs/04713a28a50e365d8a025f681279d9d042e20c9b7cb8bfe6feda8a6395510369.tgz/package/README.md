# Insomnia request response hook for base64 decode/encode

set header with name:_base64_ when need encode request body. when response is base64 auto decode.