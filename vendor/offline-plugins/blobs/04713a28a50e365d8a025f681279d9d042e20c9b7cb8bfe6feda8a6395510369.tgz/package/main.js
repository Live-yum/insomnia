const isBase64 = require('is-base64');

function base64Encode(str) {
    return Buffer.from(str).toString('base64');
}

function base64Decode(str) {
    return Buffer.from(str, 'base64').toString('utf-8');
}

function real64(req) {
    const envBase64 = req.getEnvironmentVariable('_base64_');
    const base64 = req.getHeader('_base64_');
    var realBase64 = false;
    if (base64 == null) {
        realBase64 = (envBase64 && envBase64.toString() == '1');
    } else {
        realBase64 = base64.toString() == '1';
    }
    return realBase64;
}

module.exports.requestHooks = [
    (context) => {
        const req = context.request;
        var realBase64 = real64(req);

        if (!realBase64) {
            return;
        }

        if (req.getBody() && req.getBody().text && req.getBody().text.length > 0) {
            if (req.getMethod().toUpperCase() === 'POST') {
                req.setBodyText(base64Encode(req.getBody().text));
            }
            if (req.getMethod().toUpperCase() == 'GET') {
                req.settingEncodeUrl(false);
                req.setUrl(req.getUrl() + '?' + base64Encode(req.getBody().text));
                req.setBodyText('');
            }
        }
    }
];

module.exports.responseHooks = [
    context => {
        const req = context.request;
        const resp = context.response;
        const base64 = req.getHeader('_base64_d_');
        if (base64 != null) {
            return;
        }


        const rspText = resp.getBody().toString();
        if (resp.getBody().length > 0) {
            var is64 = false;
            try {
                is64 = isBase64(rspText);
            } catch (e) {
                is64 = real64(req);
            }
            if (is64) {
                resp.setBody(Buffer.from(base64Decode(rspText)));
            }

        }
    }
];