import { _ep0, _mw0, command } from "../commandBuilder";
import { CreateOpsMetadata$ } from "../schemas/schemas_0";
export class CreateOpsMetadataCommand extends command(_ep0, _mw0, "CreateOpsMetadata", CreateOpsMetadata$) {
}
