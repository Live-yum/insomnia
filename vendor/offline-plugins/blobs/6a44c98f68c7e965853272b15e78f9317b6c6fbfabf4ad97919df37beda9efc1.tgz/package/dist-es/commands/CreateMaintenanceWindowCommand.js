import { _ep0, _mw0, command } from "../commandBuilder";
import { CreateMaintenanceWindow$ } from "../schemas/schemas_0";
export class CreateMaintenanceWindowCommand extends command(_ep0, _mw0, "CreateMaintenanceWindow", CreateMaintenanceWindow$) {
}
