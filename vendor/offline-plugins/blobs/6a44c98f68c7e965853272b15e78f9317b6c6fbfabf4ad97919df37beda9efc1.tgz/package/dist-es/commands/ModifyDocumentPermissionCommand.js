import { _ep0, _mw0, command } from "../commandBuilder";
import { ModifyDocumentPermission$ } from "../schemas/schemas_0";
export class ModifyDocumentPermissionCommand extends command(_ep0, _mw0, "ModifyDocumentPermission", ModifyDocumentPermission$) {
}
