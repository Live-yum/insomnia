import { _ep0, _mw0, command } from "../commandBuilder";
import { GetMaintenanceWindowTask$ } from "../schemas/schemas_0";
export class GetMaintenanceWindowTaskCommand extends command(_ep0, _mw0, "GetMaintenanceWindowTask", GetMaintenanceWindowTask$) {
}
