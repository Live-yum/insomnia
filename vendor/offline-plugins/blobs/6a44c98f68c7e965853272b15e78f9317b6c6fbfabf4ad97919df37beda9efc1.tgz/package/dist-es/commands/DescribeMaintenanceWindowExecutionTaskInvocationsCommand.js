import { _ep0, _mw0, command } from "../commandBuilder";
import { DescribeMaintenanceWindowExecutionTaskInvocations$ } from "../schemas/schemas_0";
export class DescribeMaintenanceWindowExecutionTaskInvocationsCommand extends command(_ep0, _mw0, "DescribeMaintenanceWindowExecutionTaskInvocations", DescribeMaintenanceWindowExecutionTaskInvocations$) {
}
