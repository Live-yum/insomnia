import { _ep0, _mw0, command } from "../commandBuilder";
import { CreateAssociation$ } from "../schemas/schemas_0";
export class CreateAssociationCommand extends command(_ep0, _mw0, "CreateAssociation", CreateAssociation$) {
}
