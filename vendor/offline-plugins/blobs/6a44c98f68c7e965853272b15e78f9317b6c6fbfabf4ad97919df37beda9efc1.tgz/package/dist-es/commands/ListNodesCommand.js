import { _ep0, _mw0, command } from "../commandBuilder";
import { ListNodes$ } from "../schemas/schemas_0";
export class ListNodesCommand extends command(_ep0, _mw0, "ListNodes", ListNodes$) {
}
