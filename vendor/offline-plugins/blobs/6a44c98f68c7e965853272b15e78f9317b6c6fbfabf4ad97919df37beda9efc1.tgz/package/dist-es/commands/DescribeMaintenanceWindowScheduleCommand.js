import { _ep0, _mw0, command } from "../commandBuilder";
import { DescribeMaintenanceWindowSchedule$ } from "../schemas/schemas_0";
export class DescribeMaintenanceWindowScheduleCommand extends command(_ep0, _mw0, "DescribeMaintenanceWindowSchedule", DescribeMaintenanceWindowSchedule$) {
}
