import { _ep0, _mw0, command } from "../commandBuilder";
import { DescribePatchGroups$ } from "../schemas/schemas_0";
export class DescribePatchGroupsCommand extends command(_ep0, _mw0, "DescribePatchGroups", DescribePatchGroups$) {
}
