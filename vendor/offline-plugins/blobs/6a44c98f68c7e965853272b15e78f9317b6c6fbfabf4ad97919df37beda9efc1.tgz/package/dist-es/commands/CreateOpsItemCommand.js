import { _ep0, _mw0, command } from "../commandBuilder";
import { CreateOpsItem$ } from "../schemas/schemas_0";
export class CreateOpsItemCommand extends command(_ep0, _mw0, "CreateOpsItem", CreateOpsItem$) {
}
