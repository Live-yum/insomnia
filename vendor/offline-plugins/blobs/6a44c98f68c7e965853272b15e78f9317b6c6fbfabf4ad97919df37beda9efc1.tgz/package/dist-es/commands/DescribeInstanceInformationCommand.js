import { _ep0, _mw0, command } from "../commandBuilder";
import { DescribeInstanceInformation$ } from "../schemas/schemas_0";
export class DescribeInstanceInformationCommand extends command(_ep0, _mw0, "DescribeInstanceInformation", DescribeInstanceInformation$) {
}
