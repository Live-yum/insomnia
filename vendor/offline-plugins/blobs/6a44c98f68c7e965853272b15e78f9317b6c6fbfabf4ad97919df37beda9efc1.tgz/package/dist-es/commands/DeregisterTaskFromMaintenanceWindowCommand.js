import { _ep0, _mw0, command } from "../commandBuilder";
import { DeregisterTaskFromMaintenanceWindow$ } from "../schemas/schemas_0";
export class DeregisterTaskFromMaintenanceWindowCommand extends command(_ep0, _mw0, "DeregisterTaskFromMaintenanceWindow", DeregisterTaskFromMaintenanceWindow$) {
}
