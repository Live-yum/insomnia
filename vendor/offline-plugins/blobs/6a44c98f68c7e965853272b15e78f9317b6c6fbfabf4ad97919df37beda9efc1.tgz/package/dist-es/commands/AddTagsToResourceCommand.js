import { _ep0, _mw0, command } from "../commandBuilder";
import { AddTagsToResource$ } from "../schemas/schemas_0";
export class AddTagsToResourceCommand extends command(_ep0, _mw0, "AddTagsToResource", AddTagsToResource$) {
}
