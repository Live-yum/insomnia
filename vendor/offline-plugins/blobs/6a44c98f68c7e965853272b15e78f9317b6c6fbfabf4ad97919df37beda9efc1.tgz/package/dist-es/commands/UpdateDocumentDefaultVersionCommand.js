import { _ep0, _mw0, command } from "../commandBuilder";
import { UpdateDocumentDefaultVersion$ } from "../schemas/schemas_0";
export class UpdateDocumentDefaultVersionCommand extends command(_ep0, _mw0, "UpdateDocumentDefaultVersion", UpdateDocumentDefaultVersion$) {
}
