import { _ep0, _mw0, command } from "../commandBuilder";
import { DescribeActivations$ } from "../schemas/schemas_0";
export class DescribeActivationsCommand extends command(_ep0, _mw0, "DescribeActivations", DescribeActivations$) {
}
