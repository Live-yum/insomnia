import { _ep0, _mw0, command } from "../commandBuilder";
import { UpdateAssociationStatus$ } from "../schemas/schemas_0";
export class UpdateAssociationStatusCommand extends command(_ep0, _mw0, "UpdateAssociationStatus", UpdateAssociationStatus$) {
}
