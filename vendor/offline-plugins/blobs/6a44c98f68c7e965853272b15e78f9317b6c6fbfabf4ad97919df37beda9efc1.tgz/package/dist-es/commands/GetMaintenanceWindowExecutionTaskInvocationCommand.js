import { _ep0, _mw0, command } from "../commandBuilder";
import { GetMaintenanceWindowExecutionTaskInvocation$ } from "../schemas/schemas_0";
export class GetMaintenanceWindowExecutionTaskInvocationCommand extends command(_ep0, _mw0, "GetMaintenanceWindowExecutionTaskInvocation", GetMaintenanceWindowExecutionTaskInvocation$) {
}
