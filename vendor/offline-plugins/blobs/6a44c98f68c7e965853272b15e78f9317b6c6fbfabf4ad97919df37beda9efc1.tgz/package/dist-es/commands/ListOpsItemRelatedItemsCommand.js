import { _ep0, _mw0, command } from "../commandBuilder";
import { ListOpsItemRelatedItems$ } from "../schemas/schemas_0";
export class ListOpsItemRelatedItemsCommand extends command(_ep0, _mw0, "ListOpsItemRelatedItems", ListOpsItemRelatedItems$) {
}
