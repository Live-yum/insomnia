import { _ep0, _mw0, command } from "../commandBuilder";
import { ResetServiceSetting$ } from "../schemas/schemas_0";
export class ResetServiceSettingCommand extends command(_ep0, _mw0, "ResetServiceSetting", ResetServiceSetting$) {
}
