import { _ep0, _mw0, command } from "../commandBuilder";
import { UpdateDocument$ } from "../schemas/schemas_0";
export class UpdateDocumentCommand extends command(_ep0, _mw0, "UpdateDocument", UpdateDocument$) {
}
