import { _ep0, _mw0, command } from "../commandBuilder";
import { UnlabelParameterVersion$ } from "../schemas/schemas_0";
export class UnlabelParameterVersionCommand extends command(_ep0, _mw0, "UnlabelParameterVersion", UnlabelParameterVersion$) {
}
