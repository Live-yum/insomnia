import { _ep0, _mw0, command } from "../commandBuilder";
import { CreateAssociationBatch$ } from "../schemas/schemas_0";
export class CreateAssociationBatchCommand extends command(_ep0, _mw0, "CreateAssociationBatch", CreateAssociationBatch$) {
}
