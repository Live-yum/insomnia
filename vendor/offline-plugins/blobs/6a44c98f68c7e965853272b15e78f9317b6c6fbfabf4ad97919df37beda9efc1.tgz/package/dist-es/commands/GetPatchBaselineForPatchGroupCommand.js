import { _ep0, _mw0, command } from "../commandBuilder";
import { GetPatchBaselineForPatchGroup$ } from "../schemas/schemas_0";
export class GetPatchBaselineForPatchGroupCommand extends command(_ep0, _mw0, "GetPatchBaselineForPatchGroup", GetPatchBaselineForPatchGroup$) {
}
