import { _ep0, _mw0, command } from "../commandBuilder";
import { GetParameter$ } from "../schemas/schemas_0";
export class GetParameterCommand extends command(_ep0, _mw0, "GetParameter", GetParameter$) {
}
