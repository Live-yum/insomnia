import { _ep0, _mw0, command } from "../commandBuilder";
import { DeleteParameters$ } from "../schemas/schemas_0";
export class DeleteParametersCommand extends command(_ep0, _mw0, "DeleteParameters", DeleteParameters$) {
}
