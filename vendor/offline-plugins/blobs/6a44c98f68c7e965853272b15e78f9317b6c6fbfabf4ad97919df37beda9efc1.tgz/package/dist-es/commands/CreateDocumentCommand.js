import { _ep0, _mw0, command } from "../commandBuilder";
import { CreateDocument$ } from "../schemas/schemas_0";
export class CreateDocumentCommand extends command(_ep0, _mw0, "CreateDocument", CreateDocument$) {
}
