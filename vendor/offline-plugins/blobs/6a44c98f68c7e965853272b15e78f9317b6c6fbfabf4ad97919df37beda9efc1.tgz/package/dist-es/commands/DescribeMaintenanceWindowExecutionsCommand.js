import { _ep0, _mw0, command } from "../commandBuilder";
import { DescribeMaintenanceWindowExecutions$ } from "../schemas/schemas_0";
export class DescribeMaintenanceWindowExecutionsCommand extends command(_ep0, _mw0, "DescribeMaintenanceWindowExecutions", DescribeMaintenanceWindowExecutions$) {
}
