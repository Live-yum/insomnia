import { _ep0, _mw0, command } from "../commandBuilder";
import { GetPatchBaseline$ } from "../schemas/schemas_0";
export class GetPatchBaselineCommand extends command(_ep0, _mw0, "GetPatchBaseline", GetPatchBaseline$) {
}
