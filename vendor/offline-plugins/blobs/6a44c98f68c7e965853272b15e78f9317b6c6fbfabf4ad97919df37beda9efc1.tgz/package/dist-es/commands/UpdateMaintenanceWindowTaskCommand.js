import { _ep0, _mw0, command } from "../commandBuilder";
import { UpdateMaintenanceWindowTask$ } from "../schemas/schemas_0";
export class UpdateMaintenanceWindowTaskCommand extends command(_ep0, _mw0, "UpdateMaintenanceWindowTask", UpdateMaintenanceWindowTask$) {
}
