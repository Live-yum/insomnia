import { _ep0, _mw0, command } from "../commandBuilder";
import { GetInventory$ } from "../schemas/schemas_0";
export class GetInventoryCommand extends command(_ep0, _mw0, "GetInventory", GetInventory$) {
}
