import { _ep0, _mw0, command } from "../commandBuilder";
import { UpdateMaintenanceWindow$ } from "../schemas/schemas_0";
export class UpdateMaintenanceWindowCommand extends command(_ep0, _mw0, "UpdateMaintenanceWindow", UpdateMaintenanceWindow$) {
}
