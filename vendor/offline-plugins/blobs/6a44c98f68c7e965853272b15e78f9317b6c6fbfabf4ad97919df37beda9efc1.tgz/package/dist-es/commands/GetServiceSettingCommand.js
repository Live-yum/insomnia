import { _ep0, _mw0, command } from "../commandBuilder";
import { GetServiceSetting$ } from "../schemas/schemas_0";
export class GetServiceSettingCommand extends command(_ep0, _mw0, "GetServiceSetting", GetServiceSetting$) {
}
