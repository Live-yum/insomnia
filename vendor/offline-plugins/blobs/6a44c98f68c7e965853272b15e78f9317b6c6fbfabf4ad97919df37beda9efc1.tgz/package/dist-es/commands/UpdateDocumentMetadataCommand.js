import { _ep0, _mw0, command } from "../commandBuilder";
import { UpdateDocumentMetadata$ } from "../schemas/schemas_0";
export class UpdateDocumentMetadataCommand extends command(_ep0, _mw0, "UpdateDocumentMetadata", UpdateDocumentMetadata$) {
}
