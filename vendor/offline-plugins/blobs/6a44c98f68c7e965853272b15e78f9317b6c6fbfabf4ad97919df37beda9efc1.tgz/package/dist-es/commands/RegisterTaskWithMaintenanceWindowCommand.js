import { _ep0, _mw0, command } from "../commandBuilder";
import { RegisterTaskWithMaintenanceWindow$ } from "../schemas/schemas_0";
export class RegisterTaskWithMaintenanceWindowCommand extends command(_ep0, _mw0, "RegisterTaskWithMaintenanceWindow", RegisterTaskWithMaintenanceWindow$) {
}
