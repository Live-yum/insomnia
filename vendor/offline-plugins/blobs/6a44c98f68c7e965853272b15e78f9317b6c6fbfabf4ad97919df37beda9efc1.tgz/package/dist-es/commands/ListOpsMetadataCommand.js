import { _ep0, _mw0, command } from "../commandBuilder";
import { ListOpsMetadata$ } from "../schemas/schemas_0";
export class ListOpsMetadataCommand extends command(_ep0, _mw0, "ListOpsMetadata", ListOpsMetadata$) {
}
