import { _ep0, _mw0, command } from "../commandBuilder";
import { DeletePatchBaseline$ } from "../schemas/schemas_0";
export class DeletePatchBaselineCommand extends command(_ep0, _mw0, "DeletePatchBaseline", DeletePatchBaseline$) {
}
