import { _ep0, _mw0, command } from "../commandBuilder";
import { UpdateOpsItem$ } from "../schemas/schemas_0";
export class UpdateOpsItemCommand extends command(_ep0, _mw0, "UpdateOpsItem", UpdateOpsItem$) {
}
