import { _ep0, _mw0, command } from "../commandBuilder";
import { GetMaintenanceWindow$ } from "../schemas/schemas_0";
export class GetMaintenanceWindowCommand extends command(_ep0, _mw0, "GetMaintenanceWindow", GetMaintenanceWindow$) {
}
