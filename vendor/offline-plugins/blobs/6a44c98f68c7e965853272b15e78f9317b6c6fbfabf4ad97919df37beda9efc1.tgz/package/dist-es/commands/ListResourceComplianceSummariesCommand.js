import { _ep0, _mw0, command } from "../commandBuilder";
import { ListResourceComplianceSummaries$ } from "../schemas/schemas_0";
export class ListResourceComplianceSummariesCommand extends command(_ep0, _mw0, "ListResourceComplianceSummaries", ListResourceComplianceSummaries$) {
}
