import { _ep0, _mw0, command } from "../commandBuilder";
import { DescribeAssociationExecutionTargets$ } from "../schemas/schemas_0";
export class DescribeAssociationExecutionTargetsCommand extends command(_ep0, _mw0, "DescribeAssociationExecutionTargets", DescribeAssociationExecutionTargets$) {
}
