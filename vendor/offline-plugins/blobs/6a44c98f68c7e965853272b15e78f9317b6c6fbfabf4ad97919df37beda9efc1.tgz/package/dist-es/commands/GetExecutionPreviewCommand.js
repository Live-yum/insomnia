import { _ep0, _mw0, command } from "../commandBuilder";
import { GetExecutionPreview$ } from "../schemas/schemas_0";
export class GetExecutionPreviewCommand extends command(_ep0, _mw0, "GetExecutionPreview", GetExecutionPreview$) {
}
