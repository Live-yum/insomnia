import { _ep0, _mw0, command } from "../commandBuilder";
import { ListComplianceItems$ } from "../schemas/schemas_0";
export class ListComplianceItemsCommand extends command(_ep0, _mw0, "ListComplianceItems", ListComplianceItems$) {
}
