import { _ep0, _mw0, command } from "../commandBuilder";
import { ListResourceDataSync$ } from "../schemas/schemas_0";
export class ListResourceDataSyncCommand extends command(_ep0, _mw0, "ListResourceDataSync", ListResourceDataSync$) {
}
