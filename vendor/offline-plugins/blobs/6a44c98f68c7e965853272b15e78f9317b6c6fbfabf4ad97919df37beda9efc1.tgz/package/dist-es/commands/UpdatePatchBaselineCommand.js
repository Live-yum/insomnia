import { _ep0, _mw0, command } from "../commandBuilder";
import { UpdatePatchBaseline$ } from "../schemas/schemas_0";
export class UpdatePatchBaselineCommand extends command(_ep0, _mw0, "UpdatePatchBaseline", UpdatePatchBaseline$) {
}
