import { _ep0, _mw0, command } from "../commandBuilder";
import { RegisterTargetWithMaintenanceWindow$ } from "../schemas/schemas_0";
export class RegisterTargetWithMaintenanceWindowCommand extends command(_ep0, _mw0, "RegisterTargetWithMaintenanceWindow", RegisterTargetWithMaintenanceWindow$) {
}
