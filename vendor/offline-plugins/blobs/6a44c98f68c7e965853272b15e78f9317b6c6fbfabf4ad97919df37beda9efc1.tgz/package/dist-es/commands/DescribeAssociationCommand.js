import { _ep0, _mw0, command } from "../commandBuilder";
import { DescribeAssociation$ } from "../schemas/schemas_0";
export class DescribeAssociationCommand extends command(_ep0, _mw0, "DescribeAssociation", DescribeAssociation$) {
}
