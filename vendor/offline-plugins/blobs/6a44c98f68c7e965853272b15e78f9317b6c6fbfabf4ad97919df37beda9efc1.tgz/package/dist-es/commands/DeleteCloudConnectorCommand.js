import { _ep0, _mw0, command } from "../commandBuilder";
import { DeleteCloudConnector$ } from "../schemas/schemas_0";
export class DeleteCloudConnectorCommand extends command(_ep0, _mw0, "DeleteCloudConnector", DeleteCloudConnector$) {
}
