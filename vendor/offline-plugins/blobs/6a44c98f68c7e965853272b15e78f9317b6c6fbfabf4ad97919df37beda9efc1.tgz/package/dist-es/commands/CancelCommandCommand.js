import { _ep0, _mw0, command } from "../commandBuilder";
import { CancelCommand$ } from "../schemas/schemas_0";
export class CancelCommandCommand extends command(_ep0, _mw0, "CancelCommand", CancelCommand$) {
}
