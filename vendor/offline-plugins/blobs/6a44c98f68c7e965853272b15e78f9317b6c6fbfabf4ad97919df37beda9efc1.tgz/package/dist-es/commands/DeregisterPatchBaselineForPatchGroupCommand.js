import { _ep0, _mw0, command } from "../commandBuilder";
import { DeregisterPatchBaselineForPatchGroup$ } from "../schemas/schemas_0";
export class DeregisterPatchBaselineForPatchGroupCommand extends command(_ep0, _mw0, "DeregisterPatchBaselineForPatchGroup", DeregisterPatchBaselineForPatchGroup$) {
}
