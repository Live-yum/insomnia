import { _ep0, _mw0, command } from "../commandBuilder";
import { DeleteResourceDataSync$ } from "../schemas/schemas_0";
export class DeleteResourceDataSyncCommand extends command(_ep0, _mw0, "DeleteResourceDataSync", DeleteResourceDataSync$) {
}
