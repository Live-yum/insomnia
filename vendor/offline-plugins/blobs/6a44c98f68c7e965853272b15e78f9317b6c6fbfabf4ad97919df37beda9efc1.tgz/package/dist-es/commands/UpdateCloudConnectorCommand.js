import { _ep0, _mw0, command } from "../commandBuilder";
import { UpdateCloudConnector$ } from "../schemas/schemas_0";
export class UpdateCloudConnectorCommand extends command(_ep0, _mw0, "UpdateCloudConnector", UpdateCloudConnector$) {
}
