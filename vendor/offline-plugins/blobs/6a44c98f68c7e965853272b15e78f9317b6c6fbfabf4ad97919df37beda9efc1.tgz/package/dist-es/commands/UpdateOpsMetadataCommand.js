import { _ep0, _mw0, command } from "../commandBuilder";
import { UpdateOpsMetadata$ } from "../schemas/schemas_0";
export class UpdateOpsMetadataCommand extends command(_ep0, _mw0, "UpdateOpsMetadata", UpdateOpsMetadata$) {
}
