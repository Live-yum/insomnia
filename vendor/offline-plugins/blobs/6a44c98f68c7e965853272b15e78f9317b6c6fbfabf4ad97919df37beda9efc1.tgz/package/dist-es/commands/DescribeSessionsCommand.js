import { _ep0, _mw0, command } from "../commandBuilder";
import { DescribeSessions$ } from "../schemas/schemas_0";
export class DescribeSessionsCommand extends command(_ep0, _mw0, "DescribeSessions", DescribeSessions$) {
}
