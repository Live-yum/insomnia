import { _ep0, _mw0, command } from "../commandBuilder";
import { DeleteResourcePolicy$ } from "../schemas/schemas_0";
export class DeleteResourcePolicyCommand extends command(_ep0, _mw0, "DeleteResourcePolicy", DeleteResourcePolicy$) {
}
