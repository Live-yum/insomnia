import { _ep0, _mw0, command } from "../commandBuilder";
import { SendCommand$ } from "../schemas/schemas_0";
export class SendCommandCommand extends command(_ep0, _mw0, "SendCommand", SendCommand$) {
}
