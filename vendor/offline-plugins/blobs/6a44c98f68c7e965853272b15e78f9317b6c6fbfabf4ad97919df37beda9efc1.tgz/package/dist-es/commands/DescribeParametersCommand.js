import { _ep0, _mw0, command } from "../commandBuilder";
import { DescribeParameters$ } from "../schemas/schemas_0";
export class DescribeParametersCommand extends command(_ep0, _mw0, "DescribeParameters", DescribeParameters$) {
}
