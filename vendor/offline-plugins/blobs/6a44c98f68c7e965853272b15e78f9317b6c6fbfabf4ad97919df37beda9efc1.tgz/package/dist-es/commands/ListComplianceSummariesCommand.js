import { _ep0, _mw0, command } from "../commandBuilder";
import { ListComplianceSummaries$ } from "../schemas/schemas_0";
export class ListComplianceSummariesCommand extends command(_ep0, _mw0, "ListComplianceSummaries", ListComplianceSummaries$) {
}
