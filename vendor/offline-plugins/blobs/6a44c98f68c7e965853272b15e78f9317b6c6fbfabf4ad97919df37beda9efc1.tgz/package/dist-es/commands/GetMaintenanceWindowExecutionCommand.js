import { _ep0, _mw0, command } from "../commandBuilder";
import { GetMaintenanceWindowExecution$ } from "../schemas/schemas_0";
export class GetMaintenanceWindowExecutionCommand extends command(_ep0, _mw0, "GetMaintenanceWindowExecution", GetMaintenanceWindowExecution$) {
}
