import { _ep0, _mw0, command } from "../commandBuilder";
import { DescribeOpsItems$ } from "../schemas/schemas_0";
export class DescribeOpsItemsCommand extends command(_ep0, _mw0, "DescribeOpsItems", DescribeOpsItems$) {
}
