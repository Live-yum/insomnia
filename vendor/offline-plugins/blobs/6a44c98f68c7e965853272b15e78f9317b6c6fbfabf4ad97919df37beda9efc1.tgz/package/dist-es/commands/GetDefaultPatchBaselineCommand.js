import { _ep0, _mw0, command } from "../commandBuilder";
import { GetDefaultPatchBaseline$ } from "../schemas/schemas_0";
export class GetDefaultPatchBaselineCommand extends command(_ep0, _mw0, "GetDefaultPatchBaseline", GetDefaultPatchBaseline$) {
}
