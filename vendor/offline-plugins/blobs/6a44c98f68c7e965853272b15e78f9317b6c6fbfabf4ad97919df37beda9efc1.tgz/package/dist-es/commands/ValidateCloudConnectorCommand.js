import { _ep0, _mw0, command } from "../commandBuilder";
import { ValidateCloudConnector$ } from "../schemas/schemas_0";
export class ValidateCloudConnectorCommand extends command(_ep0, _mw0, "ValidateCloudConnector", ValidateCloudConnector$) {
}
