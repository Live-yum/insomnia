import { _ep0, _mw0, command } from "../commandBuilder";
import { StopAutomationExecution$ } from "../schemas/schemas_0";
export class StopAutomationExecutionCommand extends command(_ep0, _mw0, "StopAutomationExecution", StopAutomationExecution$) {
}
