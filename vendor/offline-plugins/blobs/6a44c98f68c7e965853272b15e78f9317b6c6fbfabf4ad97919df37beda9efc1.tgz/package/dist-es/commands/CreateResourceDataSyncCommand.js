import { _ep0, _mw0, command } from "../commandBuilder";
import { CreateResourceDataSync$ } from "../schemas/schemas_0";
export class CreateResourceDataSyncCommand extends command(_ep0, _mw0, "CreateResourceDataSync", CreateResourceDataSync$) {
}
