import { _ep0, _mw0, command } from "../commandBuilder";
import { DescribeAutomationStepExecutions$ } from "../schemas/schemas_0";
export class DescribeAutomationStepExecutionsCommand extends command(_ep0, _mw0, "DescribeAutomationStepExecutions", DescribeAutomationStepExecutions$) {
}
