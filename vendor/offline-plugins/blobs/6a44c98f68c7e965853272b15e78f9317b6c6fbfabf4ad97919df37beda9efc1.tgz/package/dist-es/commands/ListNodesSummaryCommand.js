import { _ep0, _mw0, command } from "../commandBuilder";
import { ListNodesSummary$ } from "../schemas/schemas_0";
export class ListNodesSummaryCommand extends command(_ep0, _mw0, "ListNodesSummary", ListNodesSummary$) {
}
