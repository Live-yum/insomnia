import { _ep0, _mw0, command } from "../commandBuilder";
import { StartAutomationExecution$ } from "../schemas/schemas_0";
export class StartAutomationExecutionCommand extends command(_ep0, _mw0, "StartAutomationExecution", StartAutomationExecution$) {
}
