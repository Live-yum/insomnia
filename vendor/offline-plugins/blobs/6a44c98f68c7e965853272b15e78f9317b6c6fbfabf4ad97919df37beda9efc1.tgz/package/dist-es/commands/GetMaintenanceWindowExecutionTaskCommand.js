import { _ep0, _mw0, command } from "../commandBuilder";
import { GetMaintenanceWindowExecutionTask$ } from "../schemas/schemas_0";
export class GetMaintenanceWindowExecutionTaskCommand extends command(_ep0, _mw0, "GetMaintenanceWindowExecutionTask", GetMaintenanceWindowExecutionTask$) {
}
