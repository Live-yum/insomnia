import { _ep0, _mw0, command } from "../commandBuilder";
import { GetInventorySchema$ } from "../schemas/schemas_0";
export class GetInventorySchemaCommand extends command(_ep0, _mw0, "GetInventorySchema", GetInventorySchema$) {
}
