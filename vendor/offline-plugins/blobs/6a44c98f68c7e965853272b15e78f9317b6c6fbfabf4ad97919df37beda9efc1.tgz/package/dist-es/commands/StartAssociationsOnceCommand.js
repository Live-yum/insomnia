import { _ep0, _mw0, command } from "../commandBuilder";
import { StartAssociationsOnce$ } from "../schemas/schemas_0";
export class StartAssociationsOnceCommand extends command(_ep0, _mw0, "StartAssociationsOnce", StartAssociationsOnce$) {
}
