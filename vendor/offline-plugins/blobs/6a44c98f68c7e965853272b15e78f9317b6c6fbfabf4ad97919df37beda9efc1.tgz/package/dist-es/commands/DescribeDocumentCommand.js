import { _ep0, _mw0, command } from "../commandBuilder";
import { DescribeDocument$ } from "../schemas/schemas_0";
export class DescribeDocumentCommand extends command(_ep0, _mw0, "DescribeDocument", DescribeDocument$) {
}
