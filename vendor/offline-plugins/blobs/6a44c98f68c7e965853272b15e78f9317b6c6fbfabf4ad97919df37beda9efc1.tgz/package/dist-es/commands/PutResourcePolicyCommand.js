import { _ep0, _mw0, command } from "../commandBuilder";
import { PutResourcePolicy$ } from "../schemas/schemas_0";
export class PutResourcePolicyCommand extends command(_ep0, _mw0, "PutResourcePolicy", PutResourcePolicy$) {
}
