import { _ep0, _mw0, command } from "../commandBuilder";
import { DescribePatchBaselines$ } from "../schemas/schemas_0";
export class DescribePatchBaselinesCommand extends command(_ep0, _mw0, "DescribePatchBaselines", DescribePatchBaselines$) {
}
