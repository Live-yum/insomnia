import { _ep0, _mw0, command } from "../commandBuilder";
import { GetParameters$ } from "../schemas/schemas_0";
export class GetParametersCommand extends command(_ep0, _mw0, "GetParameters", GetParameters$) {
}
