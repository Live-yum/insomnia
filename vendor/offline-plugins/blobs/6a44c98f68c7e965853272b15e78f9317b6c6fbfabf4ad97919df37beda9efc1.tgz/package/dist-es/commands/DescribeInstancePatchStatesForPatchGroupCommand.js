import { _ep0, _mw0, command } from "../commandBuilder";
import { DescribeInstancePatchStatesForPatchGroup$ } from "../schemas/schemas_0";
export class DescribeInstancePatchStatesForPatchGroupCommand extends command(_ep0, _mw0, "DescribeInstancePatchStatesForPatchGroup", DescribeInstancePatchStatesForPatchGroup$) {
}
