import { _ep0, _mw0, command } from "../commandBuilder";
import { DeregisterManagedInstance$ } from "../schemas/schemas_0";
export class DeregisterManagedInstanceCommand extends command(_ep0, _mw0, "DeregisterManagedInstance", DeregisterManagedInstance$) {
}
