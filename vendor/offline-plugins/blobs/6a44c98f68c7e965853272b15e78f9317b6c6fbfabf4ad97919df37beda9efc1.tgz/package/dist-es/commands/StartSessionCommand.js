import { _ep0, _mw0, command } from "../commandBuilder";
import { StartSession$ } from "../schemas/schemas_0";
export class StartSessionCommand extends command(_ep0, _mw0, "StartSession", StartSession$) {
}
