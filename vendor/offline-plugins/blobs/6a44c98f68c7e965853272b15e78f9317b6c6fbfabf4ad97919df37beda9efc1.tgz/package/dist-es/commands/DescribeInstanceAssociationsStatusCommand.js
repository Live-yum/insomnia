import { _ep0, _mw0, command } from "../commandBuilder";
import { DescribeInstanceAssociationsStatus$ } from "../schemas/schemas_0";
export class DescribeInstanceAssociationsStatusCommand extends command(_ep0, _mw0, "DescribeInstanceAssociationsStatus", DescribeInstanceAssociationsStatus$) {
}
