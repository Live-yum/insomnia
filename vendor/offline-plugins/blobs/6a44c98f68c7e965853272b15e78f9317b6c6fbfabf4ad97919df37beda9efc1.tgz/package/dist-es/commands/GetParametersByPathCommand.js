import { _ep0, _mw0, command } from "../commandBuilder";
import { GetParametersByPath$ } from "../schemas/schemas_0";
export class GetParametersByPathCommand extends command(_ep0, _mw0, "GetParametersByPath", GetParametersByPath$) {
}
