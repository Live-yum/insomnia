import { _ep0, _mw0, command } from "../commandBuilder";
import { ListCommands$ } from "../schemas/schemas_0";
export class ListCommandsCommand extends command(_ep0, _mw0, "ListCommands", ListCommands$) {
}
