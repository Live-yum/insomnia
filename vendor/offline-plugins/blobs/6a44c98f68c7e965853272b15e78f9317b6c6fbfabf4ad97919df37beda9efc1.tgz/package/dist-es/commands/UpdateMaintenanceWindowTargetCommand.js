import { _ep0, _mw0, command } from "../commandBuilder";
import { UpdateMaintenanceWindowTarget$ } from "../schemas/schemas_0";
export class UpdateMaintenanceWindowTargetCommand extends command(_ep0, _mw0, "UpdateMaintenanceWindowTarget", UpdateMaintenanceWindowTarget$) {
}
