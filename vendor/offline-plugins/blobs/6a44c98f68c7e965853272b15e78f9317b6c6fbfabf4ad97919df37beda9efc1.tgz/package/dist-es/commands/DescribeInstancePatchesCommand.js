import { _ep0, _mw0, command } from "../commandBuilder";
import { DescribeInstancePatches$ } from "../schemas/schemas_0";
export class DescribeInstancePatchesCommand extends command(_ep0, _mw0, "DescribeInstancePatches", DescribeInstancePatches$) {
}
