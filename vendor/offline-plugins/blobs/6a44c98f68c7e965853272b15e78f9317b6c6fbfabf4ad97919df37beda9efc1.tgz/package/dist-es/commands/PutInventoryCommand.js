import { _ep0, _mw0, command } from "../commandBuilder";
import { PutInventory$ } from "../schemas/schemas_0";
export class PutInventoryCommand extends command(_ep0, _mw0, "PutInventory", PutInventory$) {
}
