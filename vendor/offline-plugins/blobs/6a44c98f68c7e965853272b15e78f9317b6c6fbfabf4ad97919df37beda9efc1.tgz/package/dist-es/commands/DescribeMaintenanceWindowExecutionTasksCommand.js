import { _ep0, _mw0, command } from "../commandBuilder";
import { DescribeMaintenanceWindowExecutionTasks$ } from "../schemas/schemas_0";
export class DescribeMaintenanceWindowExecutionTasksCommand extends command(_ep0, _mw0, "DescribeMaintenanceWindowExecutionTasks", DescribeMaintenanceWindowExecutionTasks$) {
}
