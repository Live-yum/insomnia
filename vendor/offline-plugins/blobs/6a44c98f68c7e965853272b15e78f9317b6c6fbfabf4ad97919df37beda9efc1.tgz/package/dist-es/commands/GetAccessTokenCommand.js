import { _ep0, _mw0, command } from "../commandBuilder";
import { GetAccessToken$ } from "../schemas/schemas_0";
export class GetAccessTokenCommand extends command(_ep0, _mw0, "GetAccessToken", GetAccessToken$) {
}
