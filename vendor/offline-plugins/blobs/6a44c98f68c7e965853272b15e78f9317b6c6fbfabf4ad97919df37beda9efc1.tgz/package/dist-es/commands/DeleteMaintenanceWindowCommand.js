import { _ep0, _mw0, command } from "../commandBuilder";
import { DeleteMaintenanceWindow$ } from "../schemas/schemas_0";
export class DeleteMaintenanceWindowCommand extends command(_ep0, _mw0, "DeleteMaintenanceWindow", DeleteMaintenanceWindow$) {
}
