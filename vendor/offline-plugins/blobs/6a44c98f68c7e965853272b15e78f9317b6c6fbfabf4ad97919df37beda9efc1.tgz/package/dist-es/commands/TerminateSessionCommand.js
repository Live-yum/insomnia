import { _ep0, _mw0, command } from "../commandBuilder";
import { TerminateSession$ } from "../schemas/schemas_0";
export class TerminateSessionCommand extends command(_ep0, _mw0, "TerminateSession", TerminateSession$) {
}
