import { _ep0, _mw0, command } from "../commandBuilder";
import { GetCloudConnector$ } from "../schemas/schemas_0";
export class GetCloudConnectorCommand extends command(_ep0, _mw0, "GetCloudConnector", GetCloudConnector$) {
}
