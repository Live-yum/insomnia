import { _ep0, _mw0, command } from "../commandBuilder";
import { DescribeInstanceProperties$ } from "../schemas/schemas_0";
export class DescribeInstancePropertiesCommand extends command(_ep0, _mw0, "DescribeInstanceProperties", DescribeInstanceProperties$) {
}
