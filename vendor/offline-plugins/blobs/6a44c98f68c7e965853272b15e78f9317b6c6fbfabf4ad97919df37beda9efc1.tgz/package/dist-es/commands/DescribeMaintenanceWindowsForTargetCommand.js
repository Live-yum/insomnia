import { _ep0, _mw0, command } from "../commandBuilder";
import { DescribeMaintenanceWindowsForTarget$ } from "../schemas/schemas_0";
export class DescribeMaintenanceWindowsForTargetCommand extends command(_ep0, _mw0, "DescribeMaintenanceWindowsForTarget", DescribeMaintenanceWindowsForTarget$) {
}
