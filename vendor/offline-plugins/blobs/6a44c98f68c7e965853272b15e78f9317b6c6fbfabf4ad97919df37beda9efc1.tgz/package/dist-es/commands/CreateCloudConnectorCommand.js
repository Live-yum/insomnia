import { _ep0, _mw0, command } from "../commandBuilder";
import { CreateCloudConnector$ } from "../schemas/schemas_0";
export class CreateCloudConnectorCommand extends command(_ep0, _mw0, "CreateCloudConnector", CreateCloudConnector$) {
}
