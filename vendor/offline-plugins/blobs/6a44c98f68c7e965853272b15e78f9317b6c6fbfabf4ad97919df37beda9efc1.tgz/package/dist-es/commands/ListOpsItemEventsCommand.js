import { _ep0, _mw0, command } from "../commandBuilder";
import { ListOpsItemEvents$ } from "../schemas/schemas_0";
export class ListOpsItemEventsCommand extends command(_ep0, _mw0, "ListOpsItemEvents", ListOpsItemEvents$) {
}
