import { _ep0, _mw0, command } from "../commandBuilder";
import { DescribePatchProperties$ } from "../schemas/schemas_0";
export class DescribePatchPropertiesCommand extends command(_ep0, _mw0, "DescribePatchProperties", DescribePatchProperties$) {
}
