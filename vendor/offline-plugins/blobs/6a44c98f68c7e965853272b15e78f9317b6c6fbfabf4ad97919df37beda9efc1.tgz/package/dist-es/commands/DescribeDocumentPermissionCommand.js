import { _ep0, _mw0, command } from "../commandBuilder";
import { DescribeDocumentPermission$ } from "../schemas/schemas_0";
export class DescribeDocumentPermissionCommand extends command(_ep0, _mw0, "DescribeDocumentPermission", DescribeDocumentPermission$) {
}
