import { _ep0, _mw0, command } from "../commandBuilder";
import { UpdateManagedInstanceRole$ } from "../schemas/schemas_0";
export class UpdateManagedInstanceRoleCommand extends command(_ep0, _mw0, "UpdateManagedInstanceRole", UpdateManagedInstanceRole$) {
}
