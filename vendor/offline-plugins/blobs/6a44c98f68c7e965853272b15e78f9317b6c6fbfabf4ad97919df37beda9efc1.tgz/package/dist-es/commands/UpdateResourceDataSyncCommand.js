import { _ep0, _mw0, command } from "../commandBuilder";
import { UpdateResourceDataSync$ } from "../schemas/schemas_0";
export class UpdateResourceDataSyncCommand extends command(_ep0, _mw0, "UpdateResourceDataSync", UpdateResourceDataSync$) {
}
