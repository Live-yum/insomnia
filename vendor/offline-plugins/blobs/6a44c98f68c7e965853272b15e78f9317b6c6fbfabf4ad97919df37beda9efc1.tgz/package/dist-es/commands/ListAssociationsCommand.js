import { _ep0, _mw0, command } from "../commandBuilder";
import { ListAssociations$ } from "../schemas/schemas_0";
export class ListAssociationsCommand extends command(_ep0, _mw0, "ListAssociations", ListAssociations$) {
}
