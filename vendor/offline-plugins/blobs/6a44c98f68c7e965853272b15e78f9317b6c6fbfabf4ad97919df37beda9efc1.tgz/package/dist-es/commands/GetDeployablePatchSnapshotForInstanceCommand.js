import { _ep0, _mw0, command } from "../commandBuilder";
import { GetDeployablePatchSnapshotForInstance$ } from "../schemas/schemas_0";
export class GetDeployablePatchSnapshotForInstanceCommand extends command(_ep0, _mw0, "GetDeployablePatchSnapshotForInstance", GetDeployablePatchSnapshotForInstance$) {
}
