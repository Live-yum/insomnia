import { _ep0, _mw0, command } from "../commandBuilder";
import { GetCommandInvocation$ } from "../schemas/schemas_0";
export class GetCommandInvocationCommand extends command(_ep0, _mw0, "GetCommandInvocation", GetCommandInvocation$) {
}
