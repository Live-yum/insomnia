import { _ep0, _mw0, command } from "../commandBuilder";
import { LabelParameterVersion$ } from "../schemas/schemas_0";
export class LabelParameterVersionCommand extends command(_ep0, _mw0, "LabelParameterVersion", LabelParameterVersion$) {
}
