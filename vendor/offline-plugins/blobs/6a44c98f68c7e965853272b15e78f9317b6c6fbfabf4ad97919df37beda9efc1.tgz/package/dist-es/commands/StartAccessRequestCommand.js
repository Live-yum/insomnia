import { _ep0, _mw0, command } from "../commandBuilder";
import { StartAccessRequest$ } from "../schemas/schemas_0";
export class StartAccessRequestCommand extends command(_ep0, _mw0, "StartAccessRequest", StartAccessRequest$) {
}
