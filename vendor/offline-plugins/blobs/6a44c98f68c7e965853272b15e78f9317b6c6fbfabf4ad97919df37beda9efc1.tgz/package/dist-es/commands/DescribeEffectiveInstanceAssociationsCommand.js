import { _ep0, _mw0, command } from "../commandBuilder";
import { DescribeEffectiveInstanceAssociations$ } from "../schemas/schemas_0";
export class DescribeEffectiveInstanceAssociationsCommand extends command(_ep0, _mw0, "DescribeEffectiveInstanceAssociations", DescribeEffectiveInstanceAssociations$) {
}
