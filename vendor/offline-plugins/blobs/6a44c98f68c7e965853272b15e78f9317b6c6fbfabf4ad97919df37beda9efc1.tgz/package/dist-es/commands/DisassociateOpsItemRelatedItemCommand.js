import { _ep0, _mw0, command } from "../commandBuilder";
import { DisassociateOpsItemRelatedItem$ } from "../schemas/schemas_0";
export class DisassociateOpsItemRelatedItemCommand extends command(_ep0, _mw0, "DisassociateOpsItemRelatedItem", DisassociateOpsItemRelatedItem$) {
}
