import { _ep0, _mw0, command } from "../commandBuilder";
import { RemoveTagsFromResource$ } from "../schemas/schemas_0";
export class RemoveTagsFromResourceCommand extends command(_ep0, _mw0, "RemoveTagsFromResource", RemoveTagsFromResource$) {
}
