import { _ep0, _mw0, command } from "../commandBuilder";
import { GetParameterHistory$ } from "../schemas/schemas_0";
export class GetParameterHistoryCommand extends command(_ep0, _mw0, "GetParameterHistory", GetParameterHistory$) {
}
