import { _ep0, _mw0, command } from "../commandBuilder";
import { StartExecutionPreview$ } from "../schemas/schemas_0";
export class StartExecutionPreviewCommand extends command(_ep0, _mw0, "StartExecutionPreview", StartExecutionPreview$) {
}
