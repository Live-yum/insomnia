import { _ep0, _mw0, command } from "../commandBuilder";
import { ListDocuments$ } from "../schemas/schemas_0";
export class ListDocumentsCommand extends command(_ep0, _mw0, "ListDocuments", ListDocuments$) {
}
