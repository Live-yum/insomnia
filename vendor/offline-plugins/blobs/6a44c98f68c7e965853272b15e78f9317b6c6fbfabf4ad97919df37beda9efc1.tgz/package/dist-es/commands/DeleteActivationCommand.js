import { _ep0, _mw0, command } from "../commandBuilder";
import { DeleteActivation$ } from "../schemas/schemas_0";
export class DeleteActivationCommand extends command(_ep0, _mw0, "DeleteActivation", DeleteActivation$) {
}
