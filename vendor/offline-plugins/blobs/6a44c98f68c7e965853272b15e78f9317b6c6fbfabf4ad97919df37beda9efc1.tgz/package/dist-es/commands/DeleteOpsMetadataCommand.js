import { _ep0, _mw0, command } from "../commandBuilder";
import { DeleteOpsMetadata$ } from "../schemas/schemas_0";
export class DeleteOpsMetadataCommand extends command(_ep0, _mw0, "DeleteOpsMetadata", DeleteOpsMetadata$) {
}
