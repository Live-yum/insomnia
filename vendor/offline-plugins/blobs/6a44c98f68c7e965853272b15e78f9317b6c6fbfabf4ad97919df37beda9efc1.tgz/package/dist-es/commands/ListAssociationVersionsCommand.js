import { _ep0, _mw0, command } from "../commandBuilder";
import { ListAssociationVersions$ } from "../schemas/schemas_0";
export class ListAssociationVersionsCommand extends command(_ep0, _mw0, "ListAssociationVersions", ListAssociationVersions$) {
}
