import { _ep0, _mw0, command } from "../commandBuilder";
import { RegisterPatchBaselineForPatchGroup$ } from "../schemas/schemas_0";
export class RegisterPatchBaselineForPatchGroupCommand extends command(_ep0, _mw0, "RegisterPatchBaselineForPatchGroup", RegisterPatchBaselineForPatchGroup$) {
}
