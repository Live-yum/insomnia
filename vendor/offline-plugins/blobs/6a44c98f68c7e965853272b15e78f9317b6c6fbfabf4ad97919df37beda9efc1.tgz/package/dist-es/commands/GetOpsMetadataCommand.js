import { _ep0, _mw0, command } from "../commandBuilder";
import { GetOpsMetadata$ } from "../schemas/schemas_0";
export class GetOpsMetadataCommand extends command(_ep0, _mw0, "GetOpsMetadata", GetOpsMetadata$) {
}
