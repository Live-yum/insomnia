import { _ep0, _mw0, command } from "../commandBuilder";
import { ListCloudConnectors$ } from "../schemas/schemas_0";
export class ListCloudConnectorsCommand extends command(_ep0, _mw0, "ListCloudConnectors", ListCloudConnectors$) {
}
