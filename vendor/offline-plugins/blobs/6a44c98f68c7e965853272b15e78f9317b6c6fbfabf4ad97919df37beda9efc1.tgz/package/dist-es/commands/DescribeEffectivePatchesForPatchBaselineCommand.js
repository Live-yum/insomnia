import { _ep0, _mw0, command } from "../commandBuilder";
import { DescribeEffectivePatchesForPatchBaseline$ } from "../schemas/schemas_0";
export class DescribeEffectivePatchesForPatchBaselineCommand extends command(_ep0, _mw0, "DescribeEffectivePatchesForPatchBaseline", DescribeEffectivePatchesForPatchBaseline$) {
}
