import { _ep0, _mw0, command } from "../commandBuilder";
import { CreateActivation$ } from "../schemas/schemas_0";
export class CreateActivationCommand extends command(_ep0, _mw0, "CreateActivation", CreateActivation$) {
}
