import { _ep0, _mw0, command } from "../commandBuilder";
import { DescribeInstancePatchStates$ } from "../schemas/schemas_0";
export class DescribeInstancePatchStatesCommand extends command(_ep0, _mw0, "DescribeInstancePatchStates", DescribeInstancePatchStates$) {
}
