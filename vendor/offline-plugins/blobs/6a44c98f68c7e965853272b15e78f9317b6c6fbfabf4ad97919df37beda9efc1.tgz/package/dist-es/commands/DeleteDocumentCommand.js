import { _ep0, _mw0, command } from "../commandBuilder";
import { DeleteDocument$ } from "../schemas/schemas_0";
export class DeleteDocumentCommand extends command(_ep0, _mw0, "DeleteDocument", DeleteDocument$) {
}
