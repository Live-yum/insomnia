import { _ep0, _mw0, command } from "../commandBuilder";
import { SendAutomationSignal$ } from "../schemas/schemas_0";
export class SendAutomationSignalCommand extends command(_ep0, _mw0, "SendAutomationSignal", SendAutomationSignal$) {
}
