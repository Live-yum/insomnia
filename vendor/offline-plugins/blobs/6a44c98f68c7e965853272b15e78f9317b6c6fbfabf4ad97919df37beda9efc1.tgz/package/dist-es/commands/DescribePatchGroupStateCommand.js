import { _ep0, _mw0, command } from "../commandBuilder";
import { DescribePatchGroupState$ } from "../schemas/schemas_0";
export class DescribePatchGroupStateCommand extends command(_ep0, _mw0, "DescribePatchGroupState", DescribePatchGroupState$) {
}
