import { _ep0, _mw0, command } from "../commandBuilder";
import { DeleteInventory$ } from "../schemas/schemas_0";
export class DeleteInventoryCommand extends command(_ep0, _mw0, "DeleteInventory", DeleteInventory$) {
}
