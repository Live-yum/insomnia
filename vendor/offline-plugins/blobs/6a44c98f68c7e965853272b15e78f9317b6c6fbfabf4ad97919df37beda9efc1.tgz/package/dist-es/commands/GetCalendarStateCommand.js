import { _ep0, _mw0, command } from "../commandBuilder";
import { GetCalendarState$ } from "../schemas/schemas_0";
export class GetCalendarStateCommand extends command(_ep0, _mw0, "GetCalendarState", GetCalendarState$) {
}
