import { _ep0, _mw0, command } from "../commandBuilder";
import { GetAutomationExecution$ } from "../schemas/schemas_0";
export class GetAutomationExecutionCommand extends command(_ep0, _mw0, "GetAutomationExecution", GetAutomationExecution$) {
}
