import { _ep0, _mw0, command } from "../commandBuilder";
import { DescribeMaintenanceWindowTasks$ } from "../schemas/schemas_0";
export class DescribeMaintenanceWindowTasksCommand extends command(_ep0, _mw0, "DescribeMaintenanceWindowTasks", DescribeMaintenanceWindowTasks$) {
}
