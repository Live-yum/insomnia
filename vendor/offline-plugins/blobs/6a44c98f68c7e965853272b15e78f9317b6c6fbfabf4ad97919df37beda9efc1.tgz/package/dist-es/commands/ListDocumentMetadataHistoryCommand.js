import { _ep0, _mw0, command } from "../commandBuilder";
import { ListDocumentMetadataHistory$ } from "../schemas/schemas_0";
export class ListDocumentMetadataHistoryCommand extends command(_ep0, _mw0, "ListDocumentMetadataHistory", ListDocumentMetadataHistory$) {
}
