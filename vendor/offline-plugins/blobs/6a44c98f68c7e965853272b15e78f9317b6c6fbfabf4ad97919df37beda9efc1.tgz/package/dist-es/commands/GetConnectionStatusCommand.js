import { _ep0, _mw0, command } from "../commandBuilder";
import { GetConnectionStatus$ } from "../schemas/schemas_0";
export class GetConnectionStatusCommand extends command(_ep0, _mw0, "GetConnectionStatus", GetConnectionStatus$) {
}
