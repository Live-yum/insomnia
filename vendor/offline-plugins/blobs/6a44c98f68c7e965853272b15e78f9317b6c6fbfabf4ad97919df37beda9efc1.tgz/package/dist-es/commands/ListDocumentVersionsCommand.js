import { _ep0, _mw0, command } from "../commandBuilder";
import { ListDocumentVersions$ } from "../schemas/schemas_0";
export class ListDocumentVersionsCommand extends command(_ep0, _mw0, "ListDocumentVersions", ListDocumentVersions$) {
}
