import { _ep0, _mw0, command } from "../commandBuilder";
import { ListInventoryEntries$ } from "../schemas/schemas_0";
export class ListInventoryEntriesCommand extends command(_ep0, _mw0, "ListInventoryEntries", ListInventoryEntries$) {
}
