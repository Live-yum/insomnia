import { _ep0, _mw0, command } from "../commandBuilder";
import { CreatePatchBaseline$ } from "../schemas/schemas_0";
export class CreatePatchBaselineCommand extends command(_ep0, _mw0, "CreatePatchBaseline", CreatePatchBaseline$) {
}
