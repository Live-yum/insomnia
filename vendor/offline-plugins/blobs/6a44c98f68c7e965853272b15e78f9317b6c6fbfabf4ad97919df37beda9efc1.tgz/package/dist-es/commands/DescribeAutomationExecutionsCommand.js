import { _ep0, _mw0, command } from "../commandBuilder";
import { DescribeAutomationExecutions$ } from "../schemas/schemas_0";
export class DescribeAutomationExecutionsCommand extends command(_ep0, _mw0, "DescribeAutomationExecutions", DescribeAutomationExecutions$) {
}
