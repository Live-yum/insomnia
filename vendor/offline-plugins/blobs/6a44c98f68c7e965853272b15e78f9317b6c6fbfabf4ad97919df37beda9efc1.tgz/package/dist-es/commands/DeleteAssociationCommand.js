import { _ep0, _mw0, command } from "../commandBuilder";
import { DeleteAssociation$ } from "../schemas/schemas_0";
export class DeleteAssociationCommand extends command(_ep0, _mw0, "DeleteAssociation", DeleteAssociation$) {
}
