import { _ep0, _mw0, command } from "../commandBuilder";
import { ResumeSession$ } from "../schemas/schemas_0";
export class ResumeSessionCommand extends command(_ep0, _mw0, "ResumeSession", ResumeSession$) {
}
