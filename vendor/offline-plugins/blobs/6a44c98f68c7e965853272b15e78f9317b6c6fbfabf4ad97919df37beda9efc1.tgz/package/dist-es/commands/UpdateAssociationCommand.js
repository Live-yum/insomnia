import { _ep0, _mw0, command } from "../commandBuilder";
import { UpdateAssociation$ } from "../schemas/schemas_0";
export class UpdateAssociationCommand extends command(_ep0, _mw0, "UpdateAssociation", UpdateAssociation$) {
}
