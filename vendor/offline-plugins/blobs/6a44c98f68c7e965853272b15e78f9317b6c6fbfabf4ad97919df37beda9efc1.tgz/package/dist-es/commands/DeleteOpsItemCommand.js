import { _ep0, _mw0, command } from "../commandBuilder";
import { DeleteOpsItem$ } from "../schemas/schemas_0";
export class DeleteOpsItemCommand extends command(_ep0, _mw0, "DeleteOpsItem", DeleteOpsItem$) {
}
