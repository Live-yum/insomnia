import { _ep0, _mw0, command } from "../commandBuilder";
import { DescribeInventoryDeletions$ } from "../schemas/schemas_0";
export class DescribeInventoryDeletionsCommand extends command(_ep0, _mw0, "DescribeInventoryDeletions", DescribeInventoryDeletions$) {
}
