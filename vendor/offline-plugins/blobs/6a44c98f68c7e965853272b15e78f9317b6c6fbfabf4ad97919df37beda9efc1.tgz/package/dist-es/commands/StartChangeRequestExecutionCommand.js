import { _ep0, _mw0, command } from "../commandBuilder";
import { StartChangeRequestExecution$ } from "../schemas/schemas_0";
export class StartChangeRequestExecutionCommand extends command(_ep0, _mw0, "StartChangeRequestExecution", StartChangeRequestExecution$) {
}
