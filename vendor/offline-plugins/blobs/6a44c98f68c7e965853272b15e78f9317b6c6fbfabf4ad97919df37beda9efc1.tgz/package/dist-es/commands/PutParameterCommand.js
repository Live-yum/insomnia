import { _ep0, _mw0, command } from "../commandBuilder";
import { PutParameter$ } from "../schemas/schemas_0";
export class PutParameterCommand extends command(_ep0, _mw0, "PutParameter", PutParameter$) {
}
