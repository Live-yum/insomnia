import { _ep0, _mw0, command } from "../commandBuilder";
import { DescribeAvailablePatches$ } from "../schemas/schemas_0";
export class DescribeAvailablePatchesCommand extends command(_ep0, _mw0, "DescribeAvailablePatches", DescribeAvailablePatches$) {
}
