import { _ep0, _mw0, command } from "../commandBuilder";
import { CancelMaintenanceWindowExecution$ } from "../schemas/schemas_0";
export class CancelMaintenanceWindowExecutionCommand extends command(_ep0, _mw0, "CancelMaintenanceWindowExecution", CancelMaintenanceWindowExecution$) {
}
