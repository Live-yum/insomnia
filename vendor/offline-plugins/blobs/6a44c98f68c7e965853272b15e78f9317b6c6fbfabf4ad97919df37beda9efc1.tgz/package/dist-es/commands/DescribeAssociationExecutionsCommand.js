import { _ep0, _mw0, command } from "../commandBuilder";
import { DescribeAssociationExecutions$ } from "../schemas/schemas_0";
export class DescribeAssociationExecutionsCommand extends command(_ep0, _mw0, "DescribeAssociationExecutions", DescribeAssociationExecutions$) {
}
