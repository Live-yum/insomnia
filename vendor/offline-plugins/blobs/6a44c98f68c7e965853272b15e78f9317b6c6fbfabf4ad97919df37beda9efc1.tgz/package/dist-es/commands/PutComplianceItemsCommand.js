import { _ep0, _mw0, command } from "../commandBuilder";
import { PutComplianceItems$ } from "../schemas/schemas_0";
export class PutComplianceItemsCommand extends command(_ep0, _mw0, "PutComplianceItems", PutComplianceItems$) {
}
