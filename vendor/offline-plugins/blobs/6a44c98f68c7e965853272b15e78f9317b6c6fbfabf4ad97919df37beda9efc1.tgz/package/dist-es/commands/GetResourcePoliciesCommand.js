import { _ep0, _mw0, command } from "../commandBuilder";
import { GetResourcePolicies$ } from "../schemas/schemas_0";
export class GetResourcePoliciesCommand extends command(_ep0, _mw0, "GetResourcePolicies", GetResourcePolicies$) {
}
