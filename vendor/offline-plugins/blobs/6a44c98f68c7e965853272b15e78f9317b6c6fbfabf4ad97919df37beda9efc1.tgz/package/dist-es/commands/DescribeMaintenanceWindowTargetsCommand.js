import { _ep0, _mw0, command } from "../commandBuilder";
import { DescribeMaintenanceWindowTargets$ } from "../schemas/schemas_0";
export class DescribeMaintenanceWindowTargetsCommand extends command(_ep0, _mw0, "DescribeMaintenanceWindowTargets", DescribeMaintenanceWindowTargets$) {
}
