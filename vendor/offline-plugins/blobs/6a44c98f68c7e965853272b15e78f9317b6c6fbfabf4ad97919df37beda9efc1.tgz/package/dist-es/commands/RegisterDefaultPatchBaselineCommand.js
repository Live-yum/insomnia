import { _ep0, _mw0, command } from "../commandBuilder";
import { RegisterDefaultPatchBaseline$ } from "../schemas/schemas_0";
export class RegisterDefaultPatchBaselineCommand extends command(_ep0, _mw0, "RegisterDefaultPatchBaseline", RegisterDefaultPatchBaseline$) {
}
