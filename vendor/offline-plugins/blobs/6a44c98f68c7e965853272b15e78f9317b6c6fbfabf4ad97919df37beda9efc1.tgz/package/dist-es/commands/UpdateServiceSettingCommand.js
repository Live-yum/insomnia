import { _ep0, _mw0, command } from "../commandBuilder";
import { UpdateServiceSetting$ } from "../schemas/schemas_0";
export class UpdateServiceSettingCommand extends command(_ep0, _mw0, "UpdateServiceSetting", UpdateServiceSetting$) {
}
