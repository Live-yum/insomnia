import { _ep0, _mw0, command } from "../commandBuilder";
import { DescribeMaintenanceWindows$ } from "../schemas/schemas_0";
export class DescribeMaintenanceWindowsCommand extends command(_ep0, _mw0, "DescribeMaintenanceWindows", DescribeMaintenanceWindows$) {
}
