import { _ep0, _mw0, command } from "../commandBuilder";
import { AssociateOpsItemRelatedItem$ } from "../schemas/schemas_0";
export class AssociateOpsItemRelatedItemCommand extends command(_ep0, _mw0, "AssociateOpsItemRelatedItem", AssociateOpsItemRelatedItem$) {
}
