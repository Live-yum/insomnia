import { _ep0, _mw0, command } from "../commandBuilder";
import { DeregisterTargetFromMaintenanceWindow$ } from "../schemas/schemas_0";
export class DeregisterTargetFromMaintenanceWindowCommand extends command(_ep0, _mw0, "DeregisterTargetFromMaintenanceWindow", DeregisterTargetFromMaintenanceWindow$) {
}
