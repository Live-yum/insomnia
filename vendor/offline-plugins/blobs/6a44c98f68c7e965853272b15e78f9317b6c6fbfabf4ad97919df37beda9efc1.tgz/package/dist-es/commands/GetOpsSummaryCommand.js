import { _ep0, _mw0, command } from "../commandBuilder";
import { GetOpsSummary$ } from "../schemas/schemas_0";
export class GetOpsSummaryCommand extends command(_ep0, _mw0, "GetOpsSummary", GetOpsSummary$) {
}
