import { createPaginator } from "@smithy/core";
import { ListCloudConnectorsCommand, } from "../commands/ListCloudConnectorsCommand";
import { SSMClient } from "../SSMClient";
export const paginateListCloudConnectors = createPaginator(SSMClient, ListCloudConnectorsCommand, "NextToken", "NextToken", "MaxResults");
