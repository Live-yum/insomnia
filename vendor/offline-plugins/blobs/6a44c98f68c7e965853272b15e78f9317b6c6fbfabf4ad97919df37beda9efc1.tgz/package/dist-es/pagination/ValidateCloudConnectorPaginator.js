import { createPaginator } from "@smithy/core";
import { ValidateCloudConnectorCommand, } from "../commands/ValidateCloudConnectorCommand";
import { SSMClient } from "../SSMClient";
export const paginateValidateCloudConnector = createPaginator(SSMClient, ValidateCloudConnectorCommand, "NextToken", "NextToken", "MaxResults");
