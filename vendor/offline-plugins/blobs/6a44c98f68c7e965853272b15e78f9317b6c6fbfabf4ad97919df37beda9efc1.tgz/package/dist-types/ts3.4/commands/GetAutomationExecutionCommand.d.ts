import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { GetAutomationExecutionRequest, GetAutomationExecutionResult } from "../models/models_0";
export { __MetadataBearer };
export interface GetAutomationExecutionCommandInput extends GetAutomationExecutionRequest {}
export interface GetAutomationExecutionCommandOutput
  extends GetAutomationExecutionResult, __MetadataBearer {}
declare const GetAutomationExecutionCommand_base: {
  new (
    input: GetAutomationExecutionCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    GetAutomationExecutionCommandInput,
    GetAutomationExecutionCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: GetAutomationExecutionCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    GetAutomationExecutionCommandInput,
    GetAutomationExecutionCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class GetAutomationExecutionCommand extends GetAutomationExecutionCommand_base {
  protected static __types: {
    api: {
      input: GetAutomationExecutionRequest;
      output: GetAutomationExecutionResult;
    };
    sdk: {
      input: GetAutomationExecutionCommandInput;
      output: GetAutomationExecutionCommandOutput;
    };
  };
}
