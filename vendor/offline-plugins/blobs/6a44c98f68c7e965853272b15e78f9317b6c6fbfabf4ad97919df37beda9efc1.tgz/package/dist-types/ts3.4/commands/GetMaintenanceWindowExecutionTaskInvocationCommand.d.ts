import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  GetMaintenanceWindowExecutionTaskInvocationRequest,
  GetMaintenanceWindowExecutionTaskInvocationResult,
} from "../models/models_0";
export { __MetadataBearer };
export interface GetMaintenanceWindowExecutionTaskInvocationCommandInput extends GetMaintenanceWindowExecutionTaskInvocationRequest {}
export interface GetMaintenanceWindowExecutionTaskInvocationCommandOutput
  extends GetMaintenanceWindowExecutionTaskInvocationResult, __MetadataBearer {}
declare const GetMaintenanceWindowExecutionTaskInvocationCommand_base: {
  new (
    input: GetMaintenanceWindowExecutionTaskInvocationCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    GetMaintenanceWindowExecutionTaskInvocationCommandInput,
    GetMaintenanceWindowExecutionTaskInvocationCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: GetMaintenanceWindowExecutionTaskInvocationCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    GetMaintenanceWindowExecutionTaskInvocationCommandInput,
    GetMaintenanceWindowExecutionTaskInvocationCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class GetMaintenanceWindowExecutionTaskInvocationCommand extends GetMaintenanceWindowExecutionTaskInvocationCommand_base {
  protected static __types: {
    api: {
      input: GetMaintenanceWindowExecutionTaskInvocationRequest;
      output: GetMaintenanceWindowExecutionTaskInvocationResult;
    };
    sdk: {
      input: GetMaintenanceWindowExecutionTaskInvocationCommandInput;
      output: GetMaintenanceWindowExecutionTaskInvocationCommandOutput;
    };
  };
}
