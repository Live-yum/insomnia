import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  DescribeAvailablePatchesRequest,
  DescribeAvailablePatchesResult,
} from "../models/models_0";
export { __MetadataBearer };
export interface DescribeAvailablePatchesCommandInput extends DescribeAvailablePatchesRequest {}
export interface DescribeAvailablePatchesCommandOutput
  extends DescribeAvailablePatchesResult, __MetadataBearer {}
declare const DescribeAvailablePatchesCommand_base: {
  new (
    input: DescribeAvailablePatchesCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DescribeAvailablePatchesCommandInput,
    DescribeAvailablePatchesCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    ...[input]: [] | [DescribeAvailablePatchesCommandInput]
  ): import("@smithy/core/client").CommandImpl<
    DescribeAvailablePatchesCommandInput,
    DescribeAvailablePatchesCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class DescribeAvailablePatchesCommand extends DescribeAvailablePatchesCommand_base {
  protected static __types: {
    api: {
      input: DescribeAvailablePatchesRequest;
      output: DescribeAvailablePatchesResult;
    };
    sdk: {
      input: DescribeAvailablePatchesCommandInput;
      output: DescribeAvailablePatchesCommandOutput;
    };
  };
}
