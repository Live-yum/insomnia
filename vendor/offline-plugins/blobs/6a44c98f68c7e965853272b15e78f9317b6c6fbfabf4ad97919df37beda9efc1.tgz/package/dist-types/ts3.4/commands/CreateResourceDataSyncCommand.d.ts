import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { CreateResourceDataSyncRequest, CreateResourceDataSyncResult } from "../models/models_0";
export { __MetadataBearer };
export interface CreateResourceDataSyncCommandInput extends CreateResourceDataSyncRequest {}
export interface CreateResourceDataSyncCommandOutput
  extends CreateResourceDataSyncResult, __MetadataBearer {}
declare const CreateResourceDataSyncCommand_base: {
  new (
    input: CreateResourceDataSyncCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    CreateResourceDataSyncCommandInput,
    CreateResourceDataSyncCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: CreateResourceDataSyncCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    CreateResourceDataSyncCommandInput,
    CreateResourceDataSyncCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class CreateResourceDataSyncCommand extends CreateResourceDataSyncCommand_base {
  protected static __types: {
    api: {
      input: CreateResourceDataSyncRequest;
      output: {};
    };
    sdk: {
      input: CreateResourceDataSyncCommandInput;
      output: CreateResourceDataSyncCommandOutput;
    };
  };
}
