import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { GetAccessTokenRequest, GetAccessTokenResponse } from "../models/models_0";
export { __MetadataBearer };
export interface GetAccessTokenCommandInput extends GetAccessTokenRequest {}
export interface GetAccessTokenCommandOutput extends GetAccessTokenResponse, __MetadataBearer {}
declare const GetAccessTokenCommand_base: {
  new (
    input: GetAccessTokenCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    GetAccessTokenCommandInput,
    GetAccessTokenCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: GetAccessTokenCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    GetAccessTokenCommandInput,
    GetAccessTokenCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class GetAccessTokenCommand extends GetAccessTokenCommand_base {
  protected static __types: {
    api: {
      input: GetAccessTokenRequest;
      output: GetAccessTokenResponse;
    };
    sdk: {
      input: GetAccessTokenCommandInput;
      output: GetAccessTokenCommandOutput;
    };
  };
}
