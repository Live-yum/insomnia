import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { CreateOpsMetadataRequest, CreateOpsMetadataResult } from "../models/models_0";
export { __MetadataBearer };
export interface CreateOpsMetadataCommandInput extends CreateOpsMetadataRequest {}
export interface CreateOpsMetadataCommandOutput extends CreateOpsMetadataResult, __MetadataBearer {}
declare const CreateOpsMetadataCommand_base: {
  new (
    input: CreateOpsMetadataCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    CreateOpsMetadataCommandInput,
    CreateOpsMetadataCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: CreateOpsMetadataCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    CreateOpsMetadataCommandInput,
    CreateOpsMetadataCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class CreateOpsMetadataCommand extends CreateOpsMetadataCommand_base {
  protected static __types: {
    api: {
      input: CreateOpsMetadataRequest;
      output: CreateOpsMetadataResult;
    };
    sdk: {
      input: CreateOpsMetadataCommandInput;
      output: CreateOpsMetadataCommandOutput;
    };
  };
}
