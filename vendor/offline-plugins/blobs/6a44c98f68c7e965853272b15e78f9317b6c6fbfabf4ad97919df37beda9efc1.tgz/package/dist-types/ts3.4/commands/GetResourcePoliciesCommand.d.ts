import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { GetResourcePoliciesRequest, GetResourcePoliciesResponse } from "../models/models_1";
export { __MetadataBearer };
export interface GetResourcePoliciesCommandInput extends GetResourcePoliciesRequest {}
export interface GetResourcePoliciesCommandOutput
  extends GetResourcePoliciesResponse, __MetadataBearer {}
declare const GetResourcePoliciesCommand_base: {
  new (
    input: GetResourcePoliciesCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    GetResourcePoliciesCommandInput,
    GetResourcePoliciesCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: GetResourcePoliciesCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    GetResourcePoliciesCommandInput,
    GetResourcePoliciesCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class GetResourcePoliciesCommand extends GetResourcePoliciesCommand_base {
  protected static __types: {
    api: {
      input: GetResourcePoliciesRequest;
      output: GetResourcePoliciesResponse;
    };
    sdk: {
      input: GetResourcePoliciesCommandInput;
      output: GetResourcePoliciesCommandOutput;
    };
  };
}
