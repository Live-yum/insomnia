import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { DeleteActivationRequest, DeleteActivationResult } from "../models/models_0";
export { __MetadataBearer };
export interface DeleteActivationCommandInput extends DeleteActivationRequest {}
export interface DeleteActivationCommandOutput extends DeleteActivationResult, __MetadataBearer {}
declare const DeleteActivationCommand_base: {
  new (
    input: DeleteActivationCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DeleteActivationCommandInput,
    DeleteActivationCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: DeleteActivationCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DeleteActivationCommandInput,
    DeleteActivationCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class DeleteActivationCommand extends DeleteActivationCommand_base {
  protected static __types: {
    api: {
      input: DeleteActivationRequest;
      output: {};
    };
    sdk: {
      input: DeleteActivationCommandInput;
      output: DeleteActivationCommandOutput;
    };
  };
}
