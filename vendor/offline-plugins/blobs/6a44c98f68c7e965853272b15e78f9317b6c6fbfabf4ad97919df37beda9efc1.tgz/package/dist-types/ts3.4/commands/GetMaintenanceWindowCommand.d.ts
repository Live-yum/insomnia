import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { GetMaintenanceWindowRequest, GetMaintenanceWindowResult } from "../models/models_0";
export { __MetadataBearer };
export interface GetMaintenanceWindowCommandInput extends GetMaintenanceWindowRequest {}
export interface GetMaintenanceWindowCommandOutput
  extends GetMaintenanceWindowResult, __MetadataBearer {}
declare const GetMaintenanceWindowCommand_base: {
  new (
    input: GetMaintenanceWindowCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    GetMaintenanceWindowCommandInput,
    GetMaintenanceWindowCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: GetMaintenanceWindowCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    GetMaintenanceWindowCommandInput,
    GetMaintenanceWindowCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class GetMaintenanceWindowCommand extends GetMaintenanceWindowCommand_base {
  protected static __types: {
    api: {
      input: GetMaintenanceWindowRequest;
      output: GetMaintenanceWindowResult;
    };
    sdk: {
      input: GetMaintenanceWindowCommandInput;
      output: GetMaintenanceWindowCommandOutput;
    };
  };
}
