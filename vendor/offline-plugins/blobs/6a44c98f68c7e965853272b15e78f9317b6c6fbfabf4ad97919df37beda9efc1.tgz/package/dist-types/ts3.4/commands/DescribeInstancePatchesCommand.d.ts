import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { DescribeInstancePatchesRequest, DescribeInstancePatchesResult } from "../models/models_0";
export { __MetadataBearer };
export interface DescribeInstancePatchesCommandInput extends DescribeInstancePatchesRequest {}
export interface DescribeInstancePatchesCommandOutput
  extends DescribeInstancePatchesResult, __MetadataBearer {}
declare const DescribeInstancePatchesCommand_base: {
  new (
    input: DescribeInstancePatchesCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DescribeInstancePatchesCommandInput,
    DescribeInstancePatchesCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: DescribeInstancePatchesCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DescribeInstancePatchesCommandInput,
    DescribeInstancePatchesCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class DescribeInstancePatchesCommand extends DescribeInstancePatchesCommand_base {
  protected static __types: {
    api: {
      input: DescribeInstancePatchesRequest;
      output: DescribeInstancePatchesResult;
    };
    sdk: {
      input: DescribeInstancePatchesCommandInput;
      output: DescribeInstancePatchesCommandOutput;
    };
  };
}
