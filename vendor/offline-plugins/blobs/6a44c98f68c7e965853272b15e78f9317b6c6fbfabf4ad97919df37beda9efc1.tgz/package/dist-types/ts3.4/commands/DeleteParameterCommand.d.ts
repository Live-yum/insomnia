import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { DeleteParameterRequest, DeleteParameterResult } from "../models/models_0";
export { __MetadataBearer };
export interface DeleteParameterCommandInput extends DeleteParameterRequest {}
export interface DeleteParameterCommandOutput extends DeleteParameterResult, __MetadataBearer {}
declare const DeleteParameterCommand_base: {
  new (
    input: DeleteParameterCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DeleteParameterCommandInput,
    DeleteParameterCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: DeleteParameterCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DeleteParameterCommandInput,
    DeleteParameterCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class DeleteParameterCommand extends DeleteParameterCommand_base {
  protected static __types: {
    api: {
      input: DeleteParameterRequest;
      output: {};
    };
    sdk: {
      input: DeleteParameterCommandInput;
      output: DeleteParameterCommandOutput;
    };
  };
}
