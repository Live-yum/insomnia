import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  GetDeployablePatchSnapshotForInstanceRequest,
  GetDeployablePatchSnapshotForInstanceResult,
} from "../models/models_0";
export { __MetadataBearer };
export interface GetDeployablePatchSnapshotForInstanceCommandInput extends GetDeployablePatchSnapshotForInstanceRequest {}
export interface GetDeployablePatchSnapshotForInstanceCommandOutput
  extends GetDeployablePatchSnapshotForInstanceResult, __MetadataBearer {}
declare const GetDeployablePatchSnapshotForInstanceCommand_base: {
  new (
    input: GetDeployablePatchSnapshotForInstanceCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    GetDeployablePatchSnapshotForInstanceCommandInput,
    GetDeployablePatchSnapshotForInstanceCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: GetDeployablePatchSnapshotForInstanceCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    GetDeployablePatchSnapshotForInstanceCommandInput,
    GetDeployablePatchSnapshotForInstanceCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class GetDeployablePatchSnapshotForInstanceCommand extends GetDeployablePatchSnapshotForInstanceCommand_base {
  protected static __types: {
    api: {
      input: GetDeployablePatchSnapshotForInstanceRequest;
      output: GetDeployablePatchSnapshotForInstanceResult;
    };
    sdk: {
      input: GetDeployablePatchSnapshotForInstanceCommandInput;
      output: GetDeployablePatchSnapshotForInstanceCommandOutput;
    };
  };
}
