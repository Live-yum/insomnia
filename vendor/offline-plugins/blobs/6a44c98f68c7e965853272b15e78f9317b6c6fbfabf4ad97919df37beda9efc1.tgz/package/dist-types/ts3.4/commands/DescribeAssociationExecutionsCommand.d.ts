import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  DescribeAssociationExecutionsRequest,
  DescribeAssociationExecutionsResult,
} from "../models/models_0";
export { __MetadataBearer };
export interface DescribeAssociationExecutionsCommandInput extends DescribeAssociationExecutionsRequest {}
export interface DescribeAssociationExecutionsCommandOutput
  extends DescribeAssociationExecutionsResult, __MetadataBearer {}
declare const DescribeAssociationExecutionsCommand_base: {
  new (
    input: DescribeAssociationExecutionsCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DescribeAssociationExecutionsCommandInput,
    DescribeAssociationExecutionsCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: DescribeAssociationExecutionsCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DescribeAssociationExecutionsCommandInput,
    DescribeAssociationExecutionsCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class DescribeAssociationExecutionsCommand extends DescribeAssociationExecutionsCommand_base {
  protected static __types: {
    api: {
      input: DescribeAssociationExecutionsRequest;
      output: DescribeAssociationExecutionsResult;
    };
    sdk: {
      input: DescribeAssociationExecutionsCommandInput;
      output: DescribeAssociationExecutionsCommandOutput;
    };
  };
}
