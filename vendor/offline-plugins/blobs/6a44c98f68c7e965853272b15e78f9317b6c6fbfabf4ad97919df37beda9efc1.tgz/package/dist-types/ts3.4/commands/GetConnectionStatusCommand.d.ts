import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { GetConnectionStatusRequest, GetConnectionStatusResponse } from "../models/models_0";
export { __MetadataBearer };
export interface GetConnectionStatusCommandInput extends GetConnectionStatusRequest {}
export interface GetConnectionStatusCommandOutput
  extends GetConnectionStatusResponse, __MetadataBearer {}
declare const GetConnectionStatusCommand_base: {
  new (
    input: GetConnectionStatusCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    GetConnectionStatusCommandInput,
    GetConnectionStatusCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: GetConnectionStatusCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    GetConnectionStatusCommandInput,
    GetConnectionStatusCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class GetConnectionStatusCommand extends GetConnectionStatusCommand_base {
  protected static __types: {
    api: {
      input: GetConnectionStatusRequest;
      output: GetConnectionStatusResponse;
    };
    sdk: {
      input: GetConnectionStatusCommandInput;
      output: GetConnectionStatusCommandOutput;
    };
  };
}
