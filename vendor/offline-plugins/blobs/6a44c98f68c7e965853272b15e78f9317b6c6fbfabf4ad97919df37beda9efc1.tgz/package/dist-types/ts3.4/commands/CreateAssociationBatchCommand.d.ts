import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { CreateAssociationBatchRequest, CreateAssociationBatchResult } from "../models/models_0";
export { __MetadataBearer };
export interface CreateAssociationBatchCommandInput extends CreateAssociationBatchRequest {}
export interface CreateAssociationBatchCommandOutput
  extends CreateAssociationBatchResult, __MetadataBearer {}
declare const CreateAssociationBatchCommand_base: {
  new (
    input: CreateAssociationBatchCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    CreateAssociationBatchCommandInput,
    CreateAssociationBatchCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: CreateAssociationBatchCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    CreateAssociationBatchCommandInput,
    CreateAssociationBatchCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class CreateAssociationBatchCommand extends CreateAssociationBatchCommand_base {
  protected static __types: {
    api: {
      input: CreateAssociationBatchRequest;
      output: CreateAssociationBatchResult;
    };
    sdk: {
      input: CreateAssociationBatchCommandInput;
      output: CreateAssociationBatchCommandOutput;
    };
  };
}
