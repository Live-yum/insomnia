import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  DescribeEffectivePatchesForPatchBaselineRequest,
  DescribeEffectivePatchesForPatchBaselineResult,
} from "../models/models_0";
export { __MetadataBearer };
export interface DescribeEffectivePatchesForPatchBaselineCommandInput extends DescribeEffectivePatchesForPatchBaselineRequest {}
export interface DescribeEffectivePatchesForPatchBaselineCommandOutput
  extends DescribeEffectivePatchesForPatchBaselineResult, __MetadataBearer {}
declare const DescribeEffectivePatchesForPatchBaselineCommand_base: {
  new (
    input: DescribeEffectivePatchesForPatchBaselineCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DescribeEffectivePatchesForPatchBaselineCommandInput,
    DescribeEffectivePatchesForPatchBaselineCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: DescribeEffectivePatchesForPatchBaselineCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DescribeEffectivePatchesForPatchBaselineCommandInput,
    DescribeEffectivePatchesForPatchBaselineCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class DescribeEffectivePatchesForPatchBaselineCommand extends DescribeEffectivePatchesForPatchBaselineCommand_base {
  protected static __types: {
    api: {
      input: DescribeEffectivePatchesForPatchBaselineRequest;
      output: DescribeEffectivePatchesForPatchBaselineResult;
    };
    sdk: {
      input: DescribeEffectivePatchesForPatchBaselineCommandInput;
      output: DescribeEffectivePatchesForPatchBaselineCommandOutput;
    };
  };
}
