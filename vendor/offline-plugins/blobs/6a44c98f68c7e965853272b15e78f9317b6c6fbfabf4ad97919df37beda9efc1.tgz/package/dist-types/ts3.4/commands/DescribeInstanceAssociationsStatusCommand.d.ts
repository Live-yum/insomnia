import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  DescribeInstanceAssociationsStatusRequest,
  DescribeInstanceAssociationsStatusResult,
} from "../models/models_0";
export { __MetadataBearer };
export interface DescribeInstanceAssociationsStatusCommandInput extends DescribeInstanceAssociationsStatusRequest {}
export interface DescribeInstanceAssociationsStatusCommandOutput
  extends DescribeInstanceAssociationsStatusResult, __MetadataBearer {}
declare const DescribeInstanceAssociationsStatusCommand_base: {
  new (
    input: DescribeInstanceAssociationsStatusCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DescribeInstanceAssociationsStatusCommandInput,
    DescribeInstanceAssociationsStatusCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: DescribeInstanceAssociationsStatusCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DescribeInstanceAssociationsStatusCommandInput,
    DescribeInstanceAssociationsStatusCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class DescribeInstanceAssociationsStatusCommand extends DescribeInstanceAssociationsStatusCommand_base {
  protected static __types: {
    api: {
      input: DescribeInstanceAssociationsStatusRequest;
      output: DescribeInstanceAssociationsStatusResult;
    };
    sdk: {
      input: DescribeInstanceAssociationsStatusCommandInput;
      output: DescribeInstanceAssociationsStatusCommandOutput;
    };
  };
}
