import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  DescribeInstanceInformationRequest,
  DescribeInstanceInformationResult,
} from "../models/models_0";
export { __MetadataBearer };
export interface DescribeInstanceInformationCommandInput extends DescribeInstanceInformationRequest {}
export interface DescribeInstanceInformationCommandOutput
  extends DescribeInstanceInformationResult, __MetadataBearer {}
declare const DescribeInstanceInformationCommand_base: {
  new (
    input: DescribeInstanceInformationCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DescribeInstanceInformationCommandInput,
    DescribeInstanceInformationCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    ...[input]: [] | [DescribeInstanceInformationCommandInput]
  ): import("@smithy/core/client").CommandImpl<
    DescribeInstanceInformationCommandInput,
    DescribeInstanceInformationCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class DescribeInstanceInformationCommand extends DescribeInstanceInformationCommand_base {
  protected static __types: {
    api: {
      input: DescribeInstanceInformationRequest;
      output: DescribeInstanceInformationResult;
    };
    sdk: {
      input: DescribeInstanceInformationCommandInput;
      output: DescribeInstanceInformationCommandOutput;
    };
  };
}
