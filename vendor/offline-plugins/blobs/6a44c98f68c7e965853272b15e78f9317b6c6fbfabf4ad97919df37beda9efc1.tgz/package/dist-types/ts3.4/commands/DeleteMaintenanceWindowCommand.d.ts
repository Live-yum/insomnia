import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { DeleteMaintenanceWindowRequest, DeleteMaintenanceWindowResult } from "../models/models_0";
export { __MetadataBearer };
export interface DeleteMaintenanceWindowCommandInput extends DeleteMaintenanceWindowRequest {}
export interface DeleteMaintenanceWindowCommandOutput
  extends DeleteMaintenanceWindowResult, __MetadataBearer {}
declare const DeleteMaintenanceWindowCommand_base: {
  new (
    input: DeleteMaintenanceWindowCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DeleteMaintenanceWindowCommandInput,
    DeleteMaintenanceWindowCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: DeleteMaintenanceWindowCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DeleteMaintenanceWindowCommandInput,
    DeleteMaintenanceWindowCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class DeleteMaintenanceWindowCommand extends DeleteMaintenanceWindowCommand_base {
  protected static __types: {
    api: {
      input: DeleteMaintenanceWindowRequest;
      output: DeleteMaintenanceWindowResult;
    };
    sdk: {
      input: DeleteMaintenanceWindowCommandInput;
      output: DeleteMaintenanceWindowCommandOutput;
    };
  };
}
