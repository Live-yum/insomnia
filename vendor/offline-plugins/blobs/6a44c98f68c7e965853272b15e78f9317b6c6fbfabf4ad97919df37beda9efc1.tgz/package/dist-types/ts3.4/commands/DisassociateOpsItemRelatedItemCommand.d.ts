import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  DisassociateOpsItemRelatedItemRequest,
  DisassociateOpsItemRelatedItemResponse,
} from "../models/models_0";
export { __MetadataBearer };
export interface DisassociateOpsItemRelatedItemCommandInput extends DisassociateOpsItemRelatedItemRequest {}
export interface DisassociateOpsItemRelatedItemCommandOutput
  extends DisassociateOpsItemRelatedItemResponse, __MetadataBearer {}
declare const DisassociateOpsItemRelatedItemCommand_base: {
  new (
    input: DisassociateOpsItemRelatedItemCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DisassociateOpsItemRelatedItemCommandInput,
    DisassociateOpsItemRelatedItemCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: DisassociateOpsItemRelatedItemCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DisassociateOpsItemRelatedItemCommandInput,
    DisassociateOpsItemRelatedItemCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class DisassociateOpsItemRelatedItemCommand extends DisassociateOpsItemRelatedItemCommand_base {
  protected static __types: {
    api: {
      input: DisassociateOpsItemRelatedItemRequest;
      output: {};
    };
    sdk: {
      input: DisassociateOpsItemRelatedItemCommandInput;
      output: DisassociateOpsItemRelatedItemCommandOutput;
    };
  };
}
