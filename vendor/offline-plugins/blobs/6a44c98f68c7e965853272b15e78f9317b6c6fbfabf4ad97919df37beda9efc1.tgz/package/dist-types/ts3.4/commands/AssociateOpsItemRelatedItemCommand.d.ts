import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  AssociateOpsItemRelatedItemRequest,
  AssociateOpsItemRelatedItemResponse,
} from "../models/models_0";
export { __MetadataBearer };
export interface AssociateOpsItemRelatedItemCommandInput extends AssociateOpsItemRelatedItemRequest {}
export interface AssociateOpsItemRelatedItemCommandOutput
  extends AssociateOpsItemRelatedItemResponse, __MetadataBearer {}
declare const AssociateOpsItemRelatedItemCommand_base: {
  new (
    input: AssociateOpsItemRelatedItemCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    AssociateOpsItemRelatedItemCommandInput,
    AssociateOpsItemRelatedItemCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: AssociateOpsItemRelatedItemCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    AssociateOpsItemRelatedItemCommandInput,
    AssociateOpsItemRelatedItemCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class AssociateOpsItemRelatedItemCommand extends AssociateOpsItemRelatedItemCommand_base {
  protected static __types: {
    api: {
      input: AssociateOpsItemRelatedItemRequest;
      output: AssociateOpsItemRelatedItemResponse;
    };
    sdk: {
      input: AssociateOpsItemRelatedItemCommandInput;
      output: AssociateOpsItemRelatedItemCommandOutput;
    };
  };
}
