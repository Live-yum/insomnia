import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { DeleteDocumentRequest, DeleteDocumentResult } from "../models/models_0";
export { __MetadataBearer };
export interface DeleteDocumentCommandInput extends DeleteDocumentRequest {}
export interface DeleteDocumentCommandOutput extends DeleteDocumentResult, __MetadataBearer {}
declare const DeleteDocumentCommand_base: {
  new (
    input: DeleteDocumentCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DeleteDocumentCommandInput,
    DeleteDocumentCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: DeleteDocumentCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DeleteDocumentCommandInput,
    DeleteDocumentCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class DeleteDocumentCommand extends DeleteDocumentCommand_base {
  protected static __types: {
    api: {
      input: DeleteDocumentRequest;
      output: {};
    };
    sdk: {
      input: DeleteDocumentCommandInput;
      output: DeleteDocumentCommandOutput;
    };
  };
}
