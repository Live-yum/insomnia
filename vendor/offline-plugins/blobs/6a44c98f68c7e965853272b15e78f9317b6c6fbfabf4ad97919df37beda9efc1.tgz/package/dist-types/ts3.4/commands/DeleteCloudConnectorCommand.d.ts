import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { DeleteCloudConnectorRequest, DeleteCloudConnectorResult } from "../models/models_0";
export { __MetadataBearer };
export interface DeleteCloudConnectorCommandInput extends DeleteCloudConnectorRequest {}
export interface DeleteCloudConnectorCommandOutput
  extends DeleteCloudConnectorResult, __MetadataBearer {}
declare const DeleteCloudConnectorCommand_base: {
  new (
    input: DeleteCloudConnectorCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DeleteCloudConnectorCommandInput,
    DeleteCloudConnectorCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: DeleteCloudConnectorCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DeleteCloudConnectorCommandInput,
    DeleteCloudConnectorCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class DeleteCloudConnectorCommand extends DeleteCloudConnectorCommand_base {
  protected static __types: {
    api: {
      input: DeleteCloudConnectorRequest;
      output: DeleteCloudConnectorResult;
    };
    sdk: {
      input: DeleteCloudConnectorCommandInput;
      output: DeleteCloudConnectorCommandOutput;
    };
  };
}
