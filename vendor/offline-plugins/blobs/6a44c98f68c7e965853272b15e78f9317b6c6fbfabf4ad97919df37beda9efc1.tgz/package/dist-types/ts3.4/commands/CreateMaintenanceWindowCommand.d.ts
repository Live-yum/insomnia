import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { CreateMaintenanceWindowRequest, CreateMaintenanceWindowResult } from "../models/models_0";
export { __MetadataBearer };
export interface CreateMaintenanceWindowCommandInput extends CreateMaintenanceWindowRequest {}
export interface CreateMaintenanceWindowCommandOutput
  extends CreateMaintenanceWindowResult, __MetadataBearer {}
declare const CreateMaintenanceWindowCommand_base: {
  new (
    input: CreateMaintenanceWindowCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    CreateMaintenanceWindowCommandInput,
    CreateMaintenanceWindowCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: CreateMaintenanceWindowCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    CreateMaintenanceWindowCommandInput,
    CreateMaintenanceWindowCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class CreateMaintenanceWindowCommand extends CreateMaintenanceWindowCommand_base {
  protected static __types: {
    api: {
      input: CreateMaintenanceWindowRequest;
      output: CreateMaintenanceWindowResult;
    };
    sdk: {
      input: CreateMaintenanceWindowCommandInput;
      output: CreateMaintenanceWindowCommandOutput;
    };
  };
}
