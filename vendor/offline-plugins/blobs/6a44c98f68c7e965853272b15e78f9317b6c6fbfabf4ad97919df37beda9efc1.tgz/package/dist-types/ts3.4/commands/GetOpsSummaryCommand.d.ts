import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { GetOpsSummaryResult } from "../models/models_0";
import { GetOpsSummaryRequest } from "../models/models_1";
export { __MetadataBearer };
export interface GetOpsSummaryCommandInput extends GetOpsSummaryRequest {}
export interface GetOpsSummaryCommandOutput extends GetOpsSummaryResult, __MetadataBearer {}
declare const GetOpsSummaryCommand_base: {
  new (
    input: GetOpsSummaryCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    GetOpsSummaryCommandInput,
    GetOpsSummaryCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    ...[input]: [] | [GetOpsSummaryCommandInput]
  ): import("@smithy/core/client").CommandImpl<
    GetOpsSummaryCommandInput,
    GetOpsSummaryCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class GetOpsSummaryCommand extends GetOpsSummaryCommand_base {
  protected static __types: {
    api: {
      input: GetOpsSummaryRequest;
      output: GetOpsSummaryResult;
    };
    sdk: {
      input: GetOpsSummaryCommandInput;
      output: GetOpsSummaryCommandOutput;
    };
  };
}
