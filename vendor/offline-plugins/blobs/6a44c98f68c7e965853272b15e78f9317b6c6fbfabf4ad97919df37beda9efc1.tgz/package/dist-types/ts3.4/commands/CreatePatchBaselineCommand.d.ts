import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { CreatePatchBaselineRequest, CreatePatchBaselineResult } from "../models/models_0";
export { __MetadataBearer };
export interface CreatePatchBaselineCommandInput extends CreatePatchBaselineRequest {}
export interface CreatePatchBaselineCommandOutput
  extends CreatePatchBaselineResult, __MetadataBearer {}
declare const CreatePatchBaselineCommand_base: {
  new (
    input: CreatePatchBaselineCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    CreatePatchBaselineCommandInput,
    CreatePatchBaselineCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: CreatePatchBaselineCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    CreatePatchBaselineCommandInput,
    CreatePatchBaselineCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class CreatePatchBaselineCommand extends CreatePatchBaselineCommand_base {
  protected static __types: {
    api: {
      input: CreatePatchBaselineRequest;
      output: CreatePatchBaselineResult;
    };
    sdk: {
      input: CreatePatchBaselineCommandInput;
      output: CreatePatchBaselineCommandOutput;
    };
  };
}
