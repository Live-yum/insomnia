import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { AddTagsToResourceRequest, AddTagsToResourceResult } from "../models/models_0";
export { __MetadataBearer };
export interface AddTagsToResourceCommandInput extends AddTagsToResourceRequest {}
export interface AddTagsToResourceCommandOutput extends AddTagsToResourceResult, __MetadataBearer {}
declare const AddTagsToResourceCommand_base: {
  new (
    input: AddTagsToResourceCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    AddTagsToResourceCommandInput,
    AddTagsToResourceCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: AddTagsToResourceCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    AddTagsToResourceCommandInput,
    AddTagsToResourceCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class AddTagsToResourceCommand extends AddTagsToResourceCommand_base {
  protected static __types: {
    api: {
      input: AddTagsToResourceRequest;
      output: {};
    };
    sdk: {
      input: AddTagsToResourceCommandInput;
      output: AddTagsToResourceCommandOutput;
    };
  };
}
