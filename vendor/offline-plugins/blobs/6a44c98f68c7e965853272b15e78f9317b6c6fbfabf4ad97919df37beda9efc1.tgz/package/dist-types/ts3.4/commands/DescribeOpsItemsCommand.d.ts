import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { DescribeOpsItemsRequest, DescribeOpsItemsResponse } from "../models/models_0";
export { __MetadataBearer };
export interface DescribeOpsItemsCommandInput extends DescribeOpsItemsRequest {}
export interface DescribeOpsItemsCommandOutput extends DescribeOpsItemsResponse, __MetadataBearer {}
declare const DescribeOpsItemsCommand_base: {
  new (
    input: DescribeOpsItemsCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DescribeOpsItemsCommandInput,
    DescribeOpsItemsCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    ...[input]: [] | [DescribeOpsItemsCommandInput]
  ): import("@smithy/core/client").CommandImpl<
    DescribeOpsItemsCommandInput,
    DescribeOpsItemsCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class DescribeOpsItemsCommand extends DescribeOpsItemsCommand_base {
  protected static __types: {
    api: {
      input: DescribeOpsItemsRequest;
      output: DescribeOpsItemsResponse;
    };
    sdk: {
      input: DescribeOpsItemsCommandInput;
      output: DescribeOpsItemsCommandOutput;
    };
  };
}
