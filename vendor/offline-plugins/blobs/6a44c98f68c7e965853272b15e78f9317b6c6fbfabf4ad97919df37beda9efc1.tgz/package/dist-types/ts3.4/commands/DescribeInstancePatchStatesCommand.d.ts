import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  DescribeInstancePatchStatesRequest,
  DescribeInstancePatchStatesResult,
} from "../models/models_0";
export { __MetadataBearer };
export interface DescribeInstancePatchStatesCommandInput extends DescribeInstancePatchStatesRequest {}
export interface DescribeInstancePatchStatesCommandOutput
  extends DescribeInstancePatchStatesResult, __MetadataBearer {}
declare const DescribeInstancePatchStatesCommand_base: {
  new (
    input: DescribeInstancePatchStatesCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DescribeInstancePatchStatesCommandInput,
    DescribeInstancePatchStatesCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: DescribeInstancePatchStatesCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DescribeInstancePatchStatesCommandInput,
    DescribeInstancePatchStatesCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class DescribeInstancePatchStatesCommand extends DescribeInstancePatchStatesCommand_base {
  protected static __types: {
    api: {
      input: DescribeInstancePatchStatesRequest;
      output: DescribeInstancePatchStatesResult;
    };
    sdk: {
      input: DescribeInstancePatchStatesCommandInput;
      output: DescribeInstancePatchStatesCommandOutput;
    };
  };
}
