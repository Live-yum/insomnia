import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { GetDefaultPatchBaselineRequest, GetDefaultPatchBaselineResult } from "../models/models_0";
export { __MetadataBearer };
export interface GetDefaultPatchBaselineCommandInput extends GetDefaultPatchBaselineRequest {}
export interface GetDefaultPatchBaselineCommandOutput
  extends GetDefaultPatchBaselineResult, __MetadataBearer {}
declare const GetDefaultPatchBaselineCommand_base: {
  new (
    input: GetDefaultPatchBaselineCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    GetDefaultPatchBaselineCommandInput,
    GetDefaultPatchBaselineCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    ...[input]: [] | [GetDefaultPatchBaselineCommandInput]
  ): import("@smithy/core/client").CommandImpl<
    GetDefaultPatchBaselineCommandInput,
    GetDefaultPatchBaselineCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class GetDefaultPatchBaselineCommand extends GetDefaultPatchBaselineCommand_base {
  protected static __types: {
    api: {
      input: GetDefaultPatchBaselineRequest;
      output: GetDefaultPatchBaselineResult;
    };
    sdk: {
      input: GetDefaultPatchBaselineCommandInput;
      output: GetDefaultPatchBaselineCommandOutput;
    };
  };
}
