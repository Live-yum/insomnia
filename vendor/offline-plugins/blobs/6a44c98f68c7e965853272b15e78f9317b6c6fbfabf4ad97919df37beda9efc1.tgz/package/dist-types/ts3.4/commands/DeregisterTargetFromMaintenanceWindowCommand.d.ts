import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  DeregisterTargetFromMaintenanceWindowRequest,
  DeregisterTargetFromMaintenanceWindowResult,
} from "../models/models_0";
export { __MetadataBearer };
export interface DeregisterTargetFromMaintenanceWindowCommandInput extends DeregisterTargetFromMaintenanceWindowRequest {}
export interface DeregisterTargetFromMaintenanceWindowCommandOutput
  extends DeregisterTargetFromMaintenanceWindowResult, __MetadataBearer {}
declare const DeregisterTargetFromMaintenanceWindowCommand_base: {
  new (
    input: DeregisterTargetFromMaintenanceWindowCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DeregisterTargetFromMaintenanceWindowCommandInput,
    DeregisterTargetFromMaintenanceWindowCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: DeregisterTargetFromMaintenanceWindowCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DeregisterTargetFromMaintenanceWindowCommandInput,
    DeregisterTargetFromMaintenanceWindowCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class DeregisterTargetFromMaintenanceWindowCommand extends DeregisterTargetFromMaintenanceWindowCommand_base {
  protected static __types: {
    api: {
      input: DeregisterTargetFromMaintenanceWindowRequest;
      output: DeregisterTargetFromMaintenanceWindowResult;
    };
    sdk: {
      input: DeregisterTargetFromMaintenanceWindowCommandInput;
      output: DeregisterTargetFromMaintenanceWindowCommandOutput;
    };
  };
}
