import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { CreateCloudConnectorRequest, CreateCloudConnectorResult } from "../models/models_0";
export { __MetadataBearer };
export interface CreateCloudConnectorCommandInput extends CreateCloudConnectorRequest {}
export interface CreateCloudConnectorCommandOutput
  extends CreateCloudConnectorResult, __MetadataBearer {}
declare const CreateCloudConnectorCommand_base: {
  new (
    input: CreateCloudConnectorCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    CreateCloudConnectorCommandInput,
    CreateCloudConnectorCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: CreateCloudConnectorCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    CreateCloudConnectorCommandInput,
    CreateCloudConnectorCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class CreateCloudConnectorCommand extends CreateCloudConnectorCommand_base {
  protected static __types: {
    api: {
      input: CreateCloudConnectorRequest;
      output: CreateCloudConnectorResult;
    };
    sdk: {
      input: CreateCloudConnectorCommandInput;
      output: CreateCloudConnectorCommandOutput;
    };
  };
}
