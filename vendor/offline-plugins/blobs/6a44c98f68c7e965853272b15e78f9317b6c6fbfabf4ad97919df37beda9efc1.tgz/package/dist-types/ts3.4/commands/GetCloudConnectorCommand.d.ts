import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { GetCloudConnectorRequest, GetCloudConnectorResult } from "../models/models_0";
export { __MetadataBearer };
export interface GetCloudConnectorCommandInput extends GetCloudConnectorRequest {}
export interface GetCloudConnectorCommandOutput extends GetCloudConnectorResult, __MetadataBearer {}
declare const GetCloudConnectorCommand_base: {
  new (
    input: GetCloudConnectorCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    GetCloudConnectorCommandInput,
    GetCloudConnectorCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: GetCloudConnectorCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    GetCloudConnectorCommandInput,
    GetCloudConnectorCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class GetCloudConnectorCommand extends GetCloudConnectorCommand_base {
  protected static __types: {
    api: {
      input: GetCloudConnectorRequest;
      output: GetCloudConnectorResult;
    };
    sdk: {
      input: GetCloudConnectorCommandInput;
      output: GetCloudConnectorCommandOutput;
    };
  };
}
