import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { CreateOpsItemRequest, CreateOpsItemResponse } from "../models/models_0";
export { __MetadataBearer };
export interface CreateOpsItemCommandInput extends CreateOpsItemRequest {}
export interface CreateOpsItemCommandOutput extends CreateOpsItemResponse, __MetadataBearer {}
declare const CreateOpsItemCommand_base: {
  new (
    input: CreateOpsItemCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    CreateOpsItemCommandInput,
    CreateOpsItemCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: CreateOpsItemCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    CreateOpsItemCommandInput,
    CreateOpsItemCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class CreateOpsItemCommand extends CreateOpsItemCommand_base {
  protected static __types: {
    api: {
      input: CreateOpsItemRequest;
      output: CreateOpsItemResponse;
    };
    sdk: {
      input: CreateOpsItemCommandInput;
      output: CreateOpsItemCommandOutput;
    };
  };
}
