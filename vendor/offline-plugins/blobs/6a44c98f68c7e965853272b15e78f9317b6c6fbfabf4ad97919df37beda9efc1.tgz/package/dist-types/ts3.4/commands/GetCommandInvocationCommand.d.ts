import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { GetCommandInvocationRequest, GetCommandInvocationResult } from "../models/models_0";
export { __MetadataBearer };
export interface GetCommandInvocationCommandInput extends GetCommandInvocationRequest {}
export interface GetCommandInvocationCommandOutput
  extends GetCommandInvocationResult, __MetadataBearer {}
declare const GetCommandInvocationCommand_base: {
  new (
    input: GetCommandInvocationCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    GetCommandInvocationCommandInput,
    GetCommandInvocationCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: GetCommandInvocationCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    GetCommandInvocationCommandInput,
    GetCommandInvocationCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class GetCommandInvocationCommand extends GetCommandInvocationCommand_base {
  protected static __types: {
    api: {
      input: GetCommandInvocationRequest;
      output: GetCommandInvocationResult;
    };
    sdk: {
      input: GetCommandInvocationCommandInput;
      output: GetCommandInvocationCommandOutput;
    };
  };
}
