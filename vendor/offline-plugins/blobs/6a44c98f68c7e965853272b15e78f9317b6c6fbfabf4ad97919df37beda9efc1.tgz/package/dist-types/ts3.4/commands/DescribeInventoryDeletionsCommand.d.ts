import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  DescribeInventoryDeletionsRequest,
  DescribeInventoryDeletionsResult,
} from "../models/models_0";
export { __MetadataBearer };
export interface DescribeInventoryDeletionsCommandInput extends DescribeInventoryDeletionsRequest {}
export interface DescribeInventoryDeletionsCommandOutput
  extends DescribeInventoryDeletionsResult, __MetadataBearer {}
declare const DescribeInventoryDeletionsCommand_base: {
  new (
    input: DescribeInventoryDeletionsCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DescribeInventoryDeletionsCommandInput,
    DescribeInventoryDeletionsCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    ...[input]: [] | [DescribeInventoryDeletionsCommandInput]
  ): import("@smithy/core/client").CommandImpl<
    DescribeInventoryDeletionsCommandInput,
    DescribeInventoryDeletionsCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class DescribeInventoryDeletionsCommand extends DescribeInventoryDeletionsCommand_base {
  protected static __types: {
    api: {
      input: DescribeInventoryDeletionsRequest;
      output: DescribeInventoryDeletionsResult;
    };
    sdk: {
      input: DescribeInventoryDeletionsCommandInput;
      output: DescribeInventoryDeletionsCommandOutput;
    };
  };
}
