import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { GetParametersRequest, GetParametersResult } from "../models/models_0";
export { __MetadataBearer };
export interface GetParametersCommandInput extends GetParametersRequest {}
export interface GetParametersCommandOutput extends GetParametersResult, __MetadataBearer {}
declare const GetParametersCommand_base: {
  new (
    input: GetParametersCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    GetParametersCommandInput,
    GetParametersCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: GetParametersCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    GetParametersCommandInput,
    GetParametersCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class GetParametersCommand extends GetParametersCommand_base {
  protected static __types: {
    api: {
      input: GetParametersRequest;
      output: GetParametersResult;
    };
    sdk: {
      input: GetParametersCommandInput;
      output: GetParametersCommandOutput;
    };
  };
}
