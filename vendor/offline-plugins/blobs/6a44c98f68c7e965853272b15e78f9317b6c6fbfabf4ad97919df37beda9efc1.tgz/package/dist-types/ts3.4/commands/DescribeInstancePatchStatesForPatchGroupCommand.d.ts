import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  DescribeInstancePatchStatesForPatchGroupRequest,
  DescribeInstancePatchStatesForPatchGroupResult,
} from "../models/models_0";
export { __MetadataBearer };
export interface DescribeInstancePatchStatesForPatchGroupCommandInput extends DescribeInstancePatchStatesForPatchGroupRequest {}
export interface DescribeInstancePatchStatesForPatchGroupCommandOutput
  extends DescribeInstancePatchStatesForPatchGroupResult, __MetadataBearer {}
declare const DescribeInstancePatchStatesForPatchGroupCommand_base: {
  new (
    input: DescribeInstancePatchStatesForPatchGroupCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DescribeInstancePatchStatesForPatchGroupCommandInput,
    DescribeInstancePatchStatesForPatchGroupCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: DescribeInstancePatchStatesForPatchGroupCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DescribeInstancePatchStatesForPatchGroupCommandInput,
    DescribeInstancePatchStatesForPatchGroupCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class DescribeInstancePatchStatesForPatchGroupCommand extends DescribeInstancePatchStatesForPatchGroupCommand_base {
  protected static __types: {
    api: {
      input: DescribeInstancePatchStatesForPatchGroupRequest;
      output: DescribeInstancePatchStatesForPatchGroupResult;
    };
    sdk: {
      input: DescribeInstancePatchStatesForPatchGroupCommandInput;
      output: DescribeInstancePatchStatesForPatchGroupCommandOutput;
    };
  };
}
