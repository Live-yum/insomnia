import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { DescribeAssociationRequest, DescribeAssociationResult } from "../models/models_0";
export { __MetadataBearer };
export interface DescribeAssociationCommandInput extends DescribeAssociationRequest {}
export interface DescribeAssociationCommandOutput
  extends DescribeAssociationResult, __MetadataBearer {}
declare const DescribeAssociationCommand_base: {
  new (
    input: DescribeAssociationCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DescribeAssociationCommandInput,
    DescribeAssociationCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    ...[input]: [] | [DescribeAssociationCommandInput]
  ): import("@smithy/core/client").CommandImpl<
    DescribeAssociationCommandInput,
    DescribeAssociationCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class DescribeAssociationCommand extends DescribeAssociationCommand_base {
  protected static __types: {
    api: {
      input: DescribeAssociationRequest;
      output: DescribeAssociationResult;
    };
    sdk: {
      input: DescribeAssociationCommandInput;
      output: DescribeAssociationCommandOutput;
    };
  };
}
