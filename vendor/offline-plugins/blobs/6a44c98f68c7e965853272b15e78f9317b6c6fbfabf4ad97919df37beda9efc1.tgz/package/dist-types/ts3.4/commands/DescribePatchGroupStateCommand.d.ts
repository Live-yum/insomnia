import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { DescribePatchGroupStateRequest, DescribePatchGroupStateResult } from "../models/models_0";
export { __MetadataBearer };
export interface DescribePatchGroupStateCommandInput extends DescribePatchGroupStateRequest {}
export interface DescribePatchGroupStateCommandOutput
  extends DescribePatchGroupStateResult, __MetadataBearer {}
declare const DescribePatchGroupStateCommand_base: {
  new (
    input: DescribePatchGroupStateCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DescribePatchGroupStateCommandInput,
    DescribePatchGroupStateCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: DescribePatchGroupStateCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DescribePatchGroupStateCommandInput,
    DescribePatchGroupStateCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class DescribePatchGroupStateCommand extends DescribePatchGroupStateCommand_base {
  protected static __types: {
    api: {
      input: DescribePatchGroupStateRequest;
      output: DescribePatchGroupStateResult;
    };
    sdk: {
      input: DescribePatchGroupStateCommandInput;
      output: DescribePatchGroupStateCommandOutput;
    };
  };
}
