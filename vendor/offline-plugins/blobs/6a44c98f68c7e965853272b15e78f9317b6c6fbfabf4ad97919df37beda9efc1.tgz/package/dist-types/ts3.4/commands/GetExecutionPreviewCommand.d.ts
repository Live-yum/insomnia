import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { GetExecutionPreviewRequest, GetExecutionPreviewResponse } from "../models/models_0";
export { __MetadataBearer };
export interface GetExecutionPreviewCommandInput extends GetExecutionPreviewRequest {}
export interface GetExecutionPreviewCommandOutput
  extends GetExecutionPreviewResponse, __MetadataBearer {}
declare const GetExecutionPreviewCommand_base: {
  new (
    input: GetExecutionPreviewCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    GetExecutionPreviewCommandInput,
    GetExecutionPreviewCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: GetExecutionPreviewCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    GetExecutionPreviewCommandInput,
    GetExecutionPreviewCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class GetExecutionPreviewCommand extends GetExecutionPreviewCommand_base {
  protected static __types: {
    api: {
      input: GetExecutionPreviewRequest;
      output: GetExecutionPreviewResponse;
    };
    sdk: {
      input: GetExecutionPreviewCommandInput;
      output: GetExecutionPreviewCommandOutput;
    };
  };
}
