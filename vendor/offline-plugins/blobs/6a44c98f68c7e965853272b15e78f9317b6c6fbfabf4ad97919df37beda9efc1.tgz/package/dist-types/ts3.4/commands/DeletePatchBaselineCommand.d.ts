import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { DeletePatchBaselineRequest, DeletePatchBaselineResult } from "../models/models_0";
export { __MetadataBearer };
export interface DeletePatchBaselineCommandInput extends DeletePatchBaselineRequest {}
export interface DeletePatchBaselineCommandOutput
  extends DeletePatchBaselineResult, __MetadataBearer {}
declare const DeletePatchBaselineCommand_base: {
  new (
    input: DeletePatchBaselineCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DeletePatchBaselineCommandInput,
    DeletePatchBaselineCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: DeletePatchBaselineCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DeletePatchBaselineCommandInput,
    DeletePatchBaselineCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class DeletePatchBaselineCommand extends DeletePatchBaselineCommand_base {
  protected static __types: {
    api: {
      input: DeletePatchBaselineRequest;
      output: DeletePatchBaselineResult;
    };
    sdk: {
      input: DeletePatchBaselineCommandInput;
      output: DeletePatchBaselineCommandOutput;
    };
  };
}
