import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  DeregisterTaskFromMaintenanceWindowRequest,
  DeregisterTaskFromMaintenanceWindowResult,
} from "../models/models_0";
export { __MetadataBearer };
export interface DeregisterTaskFromMaintenanceWindowCommandInput extends DeregisterTaskFromMaintenanceWindowRequest {}
export interface DeregisterTaskFromMaintenanceWindowCommandOutput
  extends DeregisterTaskFromMaintenanceWindowResult, __MetadataBearer {}
declare const DeregisterTaskFromMaintenanceWindowCommand_base: {
  new (
    input: DeregisterTaskFromMaintenanceWindowCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DeregisterTaskFromMaintenanceWindowCommandInput,
    DeregisterTaskFromMaintenanceWindowCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: DeregisterTaskFromMaintenanceWindowCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DeregisterTaskFromMaintenanceWindowCommandInput,
    DeregisterTaskFromMaintenanceWindowCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class DeregisterTaskFromMaintenanceWindowCommand extends DeregisterTaskFromMaintenanceWindowCommand_base {
  protected static __types: {
    api: {
      input: DeregisterTaskFromMaintenanceWindowRequest;
      output: DeregisterTaskFromMaintenanceWindowResult;
    };
    sdk: {
      input: DeregisterTaskFromMaintenanceWindowCommandInput;
      output: DeregisterTaskFromMaintenanceWindowCommandOutput;
    };
  };
}
