import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  DescribeDocumentPermissionRequest,
  DescribeDocumentPermissionResponse,
} from "../models/models_0";
export { __MetadataBearer };
export interface DescribeDocumentPermissionCommandInput extends DescribeDocumentPermissionRequest {}
export interface DescribeDocumentPermissionCommandOutput
  extends DescribeDocumentPermissionResponse, __MetadataBearer {}
declare const DescribeDocumentPermissionCommand_base: {
  new (
    input: DescribeDocumentPermissionCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DescribeDocumentPermissionCommandInput,
    DescribeDocumentPermissionCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: DescribeDocumentPermissionCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DescribeDocumentPermissionCommandInput,
    DescribeDocumentPermissionCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class DescribeDocumentPermissionCommand extends DescribeDocumentPermissionCommand_base {
  protected static __types: {
    api: {
      input: DescribeDocumentPermissionRequest;
      output: DescribeDocumentPermissionResponse;
    };
    sdk: {
      input: DescribeDocumentPermissionCommandInput;
      output: DescribeDocumentPermissionCommandOutput;
    };
  };
}
