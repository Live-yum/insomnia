import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { DescribeParametersRequest, DescribeParametersResult } from "../models/models_0";
export { __MetadataBearer };
export interface DescribeParametersCommandInput extends DescribeParametersRequest {}
export interface DescribeParametersCommandOutput
  extends DescribeParametersResult, __MetadataBearer {}
declare const DescribeParametersCommand_base: {
  new (
    input: DescribeParametersCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DescribeParametersCommandInput,
    DescribeParametersCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    ...[input]: [] | [DescribeParametersCommandInput]
  ): import("@smithy/core/client").CommandImpl<
    DescribeParametersCommandInput,
    DescribeParametersCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class DescribeParametersCommand extends DescribeParametersCommand_base {
  protected static __types: {
    api: {
      input: DescribeParametersRequest;
      output: DescribeParametersResult;
    };
    sdk: {
      input: DescribeParametersCommandInput;
      output: DescribeParametersCommandOutput;
    };
  };
}
