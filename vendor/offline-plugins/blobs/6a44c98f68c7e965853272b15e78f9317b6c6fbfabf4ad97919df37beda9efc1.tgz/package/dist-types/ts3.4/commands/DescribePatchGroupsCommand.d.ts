import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { DescribePatchGroupsRequest, DescribePatchGroupsResult } from "../models/models_0";
export { __MetadataBearer };
export interface DescribePatchGroupsCommandInput extends DescribePatchGroupsRequest {}
export interface DescribePatchGroupsCommandOutput
  extends DescribePatchGroupsResult, __MetadataBearer {}
declare const DescribePatchGroupsCommand_base: {
  new (
    input: DescribePatchGroupsCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DescribePatchGroupsCommandInput,
    DescribePatchGroupsCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    ...[input]: [] | [DescribePatchGroupsCommandInput]
  ): import("@smithy/core/client").CommandImpl<
    DescribePatchGroupsCommandInput,
    DescribePatchGroupsCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class DescribePatchGroupsCommand extends DescribePatchGroupsCommand_base {
  protected static __types: {
    api: {
      input: DescribePatchGroupsRequest;
      output: DescribePatchGroupsResult;
    };
    sdk: {
      input: DescribePatchGroupsCommandInput;
      output: DescribePatchGroupsCommandOutput;
    };
  };
}
