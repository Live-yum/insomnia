import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  GetMaintenanceWindowExecutionRequest,
  GetMaintenanceWindowExecutionResult,
} from "../models/models_0";
export { __MetadataBearer };
export interface GetMaintenanceWindowExecutionCommandInput extends GetMaintenanceWindowExecutionRequest {}
export interface GetMaintenanceWindowExecutionCommandOutput
  extends GetMaintenanceWindowExecutionResult, __MetadataBearer {}
declare const GetMaintenanceWindowExecutionCommand_base: {
  new (
    input: GetMaintenanceWindowExecutionCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    GetMaintenanceWindowExecutionCommandInput,
    GetMaintenanceWindowExecutionCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: GetMaintenanceWindowExecutionCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    GetMaintenanceWindowExecutionCommandInput,
    GetMaintenanceWindowExecutionCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class GetMaintenanceWindowExecutionCommand extends GetMaintenanceWindowExecutionCommand_base {
  protected static __types: {
    api: {
      input: GetMaintenanceWindowExecutionRequest;
      output: GetMaintenanceWindowExecutionResult;
    };
    sdk: {
      input: GetMaintenanceWindowExecutionCommandInput;
      output: GetMaintenanceWindowExecutionCommandOutput;
    };
  };
}
