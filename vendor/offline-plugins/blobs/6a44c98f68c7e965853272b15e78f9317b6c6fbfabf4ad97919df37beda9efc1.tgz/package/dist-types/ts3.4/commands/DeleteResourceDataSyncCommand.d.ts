import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { DeleteResourceDataSyncRequest, DeleteResourceDataSyncResult } from "../models/models_0";
export { __MetadataBearer };
export interface DeleteResourceDataSyncCommandInput extends DeleteResourceDataSyncRequest {}
export interface DeleteResourceDataSyncCommandOutput
  extends DeleteResourceDataSyncResult, __MetadataBearer {}
declare const DeleteResourceDataSyncCommand_base: {
  new (
    input: DeleteResourceDataSyncCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DeleteResourceDataSyncCommandInput,
    DeleteResourceDataSyncCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: DeleteResourceDataSyncCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DeleteResourceDataSyncCommandInput,
    DeleteResourceDataSyncCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class DeleteResourceDataSyncCommand extends DeleteResourceDataSyncCommand_base {
  protected static __types: {
    api: {
      input: DeleteResourceDataSyncRequest;
      output: {};
    };
    sdk: {
      input: DeleteResourceDataSyncCommandInput;
      output: DeleteResourceDataSyncCommandOutput;
    };
  };
}
