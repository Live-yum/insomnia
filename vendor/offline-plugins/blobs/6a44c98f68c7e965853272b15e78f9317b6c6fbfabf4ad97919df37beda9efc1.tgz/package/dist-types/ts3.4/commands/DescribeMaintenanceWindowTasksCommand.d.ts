import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  DescribeMaintenanceWindowTasksRequest,
  DescribeMaintenanceWindowTasksResult,
} from "../models/models_0";
export { __MetadataBearer };
export interface DescribeMaintenanceWindowTasksCommandInput extends DescribeMaintenanceWindowTasksRequest {}
export interface DescribeMaintenanceWindowTasksCommandOutput
  extends DescribeMaintenanceWindowTasksResult, __MetadataBearer {}
declare const DescribeMaintenanceWindowTasksCommand_base: {
  new (
    input: DescribeMaintenanceWindowTasksCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DescribeMaintenanceWindowTasksCommandInput,
    DescribeMaintenanceWindowTasksCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: DescribeMaintenanceWindowTasksCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DescribeMaintenanceWindowTasksCommandInput,
    DescribeMaintenanceWindowTasksCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class DescribeMaintenanceWindowTasksCommand extends DescribeMaintenanceWindowTasksCommand_base {
  protected static __types: {
    api: {
      input: DescribeMaintenanceWindowTasksRequest;
      output: DescribeMaintenanceWindowTasksResult;
    };
    sdk: {
      input: DescribeMaintenanceWindowTasksCommandInput;
      output: DescribeMaintenanceWindowTasksCommandOutput;
    };
  };
}
