import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { DeleteParametersRequest, DeleteParametersResult } from "../models/models_0";
export { __MetadataBearer };
export interface DeleteParametersCommandInput extends DeleteParametersRequest {}
export interface DeleteParametersCommandOutput extends DeleteParametersResult, __MetadataBearer {}
declare const DeleteParametersCommand_base: {
  new (
    input: DeleteParametersCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DeleteParametersCommandInput,
    DeleteParametersCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: DeleteParametersCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DeleteParametersCommandInput,
    DeleteParametersCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class DeleteParametersCommand extends DeleteParametersCommand_base {
  protected static __types: {
    api: {
      input: DeleteParametersRequest;
      output: DeleteParametersResult;
    };
    sdk: {
      input: DeleteParametersCommandInput;
      output: DeleteParametersCommandOutput;
    };
  };
}
