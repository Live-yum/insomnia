import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { CancelCommandRequest, CancelCommandResult } from "../models/models_0";
export { __MetadataBearer };
export interface CancelCommandCommandInput extends CancelCommandRequest {}
export interface CancelCommandCommandOutput extends CancelCommandResult, __MetadataBearer {}
declare const CancelCommandCommand_base: {
  new (
    input: CancelCommandCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    CancelCommandCommandInput,
    CancelCommandCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: CancelCommandCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    CancelCommandCommandInput,
    CancelCommandCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class CancelCommandCommand extends CancelCommandCommand_base {
  protected static __types: {
    api: {
      input: CancelCommandRequest;
      output: {};
    };
    sdk: {
      input: CancelCommandCommandInput;
      output: CancelCommandCommandOutput;
    };
  };
}
