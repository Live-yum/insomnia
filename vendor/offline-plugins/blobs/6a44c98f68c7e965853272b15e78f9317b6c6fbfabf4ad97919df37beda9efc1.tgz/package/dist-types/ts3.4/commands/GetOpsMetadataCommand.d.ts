import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { GetOpsMetadataRequest, GetOpsMetadataResult } from "../models/models_0";
export { __MetadataBearer };
export interface GetOpsMetadataCommandInput extends GetOpsMetadataRequest {}
export interface GetOpsMetadataCommandOutput extends GetOpsMetadataResult, __MetadataBearer {}
declare const GetOpsMetadataCommand_base: {
  new (
    input: GetOpsMetadataCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    GetOpsMetadataCommandInput,
    GetOpsMetadataCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: GetOpsMetadataCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    GetOpsMetadataCommandInput,
    GetOpsMetadataCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class GetOpsMetadataCommand extends GetOpsMetadataCommand_base {
  protected static __types: {
    api: {
      input: GetOpsMetadataRequest;
      output: GetOpsMetadataResult;
    };
    sdk: {
      input: GetOpsMetadataCommandInput;
      output: GetOpsMetadataCommandOutput;
    };
  };
}
