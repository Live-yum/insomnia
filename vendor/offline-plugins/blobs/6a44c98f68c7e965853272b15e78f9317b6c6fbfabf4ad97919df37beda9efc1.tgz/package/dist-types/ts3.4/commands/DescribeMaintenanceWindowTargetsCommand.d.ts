import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  DescribeMaintenanceWindowTargetsRequest,
  DescribeMaintenanceWindowTargetsResult,
} from "../models/models_0";
export { __MetadataBearer };
export interface DescribeMaintenanceWindowTargetsCommandInput extends DescribeMaintenanceWindowTargetsRequest {}
export interface DescribeMaintenanceWindowTargetsCommandOutput
  extends DescribeMaintenanceWindowTargetsResult, __MetadataBearer {}
declare const DescribeMaintenanceWindowTargetsCommand_base: {
  new (
    input: DescribeMaintenanceWindowTargetsCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DescribeMaintenanceWindowTargetsCommandInput,
    DescribeMaintenanceWindowTargetsCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: DescribeMaintenanceWindowTargetsCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DescribeMaintenanceWindowTargetsCommandInput,
    DescribeMaintenanceWindowTargetsCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class DescribeMaintenanceWindowTargetsCommand extends DescribeMaintenanceWindowTargetsCommand_base {
  protected static __types: {
    api: {
      input: DescribeMaintenanceWindowTargetsRequest;
      output: DescribeMaintenanceWindowTargetsResult;
    };
    sdk: {
      input: DescribeMaintenanceWindowTargetsCommandInput;
      output: DescribeMaintenanceWindowTargetsCommandOutput;
    };
  };
}
