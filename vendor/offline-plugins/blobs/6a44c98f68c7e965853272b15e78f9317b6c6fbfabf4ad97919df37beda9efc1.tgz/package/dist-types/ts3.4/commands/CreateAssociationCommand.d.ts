import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { CreateAssociationRequest, CreateAssociationResult } from "../models/models_0";
export { __MetadataBearer };
export interface CreateAssociationCommandInput extends CreateAssociationRequest {}
export interface CreateAssociationCommandOutput extends CreateAssociationResult, __MetadataBearer {}
declare const CreateAssociationCommand_base: {
  new (
    input: CreateAssociationCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    CreateAssociationCommandInput,
    CreateAssociationCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: CreateAssociationCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    CreateAssociationCommandInput,
    CreateAssociationCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class CreateAssociationCommand extends CreateAssociationCommand_base {
  protected static __types: {
    api: {
      input: CreateAssociationRequest;
      output: CreateAssociationResult;
    };
    sdk: {
      input: CreateAssociationCommandInput;
      output: CreateAssociationCommandOutput;
    };
  };
}
