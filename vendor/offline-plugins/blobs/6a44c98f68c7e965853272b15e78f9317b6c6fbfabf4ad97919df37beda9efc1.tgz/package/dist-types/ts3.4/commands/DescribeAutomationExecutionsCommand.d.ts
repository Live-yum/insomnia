import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  DescribeAutomationExecutionsRequest,
  DescribeAutomationExecutionsResult,
} from "../models/models_0";
export { __MetadataBearer };
export interface DescribeAutomationExecutionsCommandInput extends DescribeAutomationExecutionsRequest {}
export interface DescribeAutomationExecutionsCommandOutput
  extends DescribeAutomationExecutionsResult, __MetadataBearer {}
declare const DescribeAutomationExecutionsCommand_base: {
  new (
    input: DescribeAutomationExecutionsCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DescribeAutomationExecutionsCommandInput,
    DescribeAutomationExecutionsCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    ...[input]: [] | [DescribeAutomationExecutionsCommandInput]
  ): import("@smithy/core/client").CommandImpl<
    DescribeAutomationExecutionsCommandInput,
    DescribeAutomationExecutionsCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class DescribeAutomationExecutionsCommand extends DescribeAutomationExecutionsCommand_base {
  protected static __types: {
    api: {
      input: DescribeAutomationExecutionsRequest;
      output: DescribeAutomationExecutionsResult;
    };
    sdk: {
      input: DescribeAutomationExecutionsCommandInput;
      output: DescribeAutomationExecutionsCommandOutput;
    };
  };
}
