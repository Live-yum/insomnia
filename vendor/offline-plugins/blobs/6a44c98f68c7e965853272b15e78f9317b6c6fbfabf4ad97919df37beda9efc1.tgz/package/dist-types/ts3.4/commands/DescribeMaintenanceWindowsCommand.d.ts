import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  DescribeMaintenanceWindowsRequest,
  DescribeMaintenanceWindowsResult,
} from "../models/models_0";
export { __MetadataBearer };
export interface DescribeMaintenanceWindowsCommandInput extends DescribeMaintenanceWindowsRequest {}
export interface DescribeMaintenanceWindowsCommandOutput
  extends DescribeMaintenanceWindowsResult, __MetadataBearer {}
declare const DescribeMaintenanceWindowsCommand_base: {
  new (
    input: DescribeMaintenanceWindowsCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DescribeMaintenanceWindowsCommandInput,
    DescribeMaintenanceWindowsCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    ...[input]: [] | [DescribeMaintenanceWindowsCommandInput]
  ): import("@smithy/core/client").CommandImpl<
    DescribeMaintenanceWindowsCommandInput,
    DescribeMaintenanceWindowsCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class DescribeMaintenanceWindowsCommand extends DescribeMaintenanceWindowsCommand_base {
  protected static __types: {
    api: {
      input: DescribeMaintenanceWindowsRequest;
      output: DescribeMaintenanceWindowsResult;
    };
    sdk: {
      input: DescribeMaintenanceWindowsCommandInput;
      output: DescribeMaintenanceWindowsCommandOutput;
    };
  };
}
