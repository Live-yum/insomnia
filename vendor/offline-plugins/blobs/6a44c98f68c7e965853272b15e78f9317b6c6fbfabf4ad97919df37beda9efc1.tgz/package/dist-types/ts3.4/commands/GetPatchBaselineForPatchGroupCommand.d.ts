import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  GetPatchBaselineForPatchGroupRequest,
  GetPatchBaselineForPatchGroupResult,
} from "../models/models_1";
export { __MetadataBearer };
export interface GetPatchBaselineForPatchGroupCommandInput extends GetPatchBaselineForPatchGroupRequest {}
export interface GetPatchBaselineForPatchGroupCommandOutput
  extends GetPatchBaselineForPatchGroupResult, __MetadataBearer {}
declare const GetPatchBaselineForPatchGroupCommand_base: {
  new (
    input: GetPatchBaselineForPatchGroupCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    GetPatchBaselineForPatchGroupCommandInput,
    GetPatchBaselineForPatchGroupCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: GetPatchBaselineForPatchGroupCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    GetPatchBaselineForPatchGroupCommandInput,
    GetPatchBaselineForPatchGroupCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class GetPatchBaselineForPatchGroupCommand extends GetPatchBaselineForPatchGroupCommand_base {
  protected static __types: {
    api: {
      input: GetPatchBaselineForPatchGroupRequest;
      output: GetPatchBaselineForPatchGroupResult;
    };
    sdk: {
      input: GetPatchBaselineForPatchGroupCommandInput;
      output: GetPatchBaselineForPatchGroupCommandOutput;
    };
  };
}
