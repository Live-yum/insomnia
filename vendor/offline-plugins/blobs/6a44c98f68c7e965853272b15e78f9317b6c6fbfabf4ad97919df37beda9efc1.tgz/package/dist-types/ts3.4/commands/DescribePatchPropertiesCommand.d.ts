import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { DescribePatchPropertiesRequest, DescribePatchPropertiesResult } from "../models/models_0";
export { __MetadataBearer };
export interface DescribePatchPropertiesCommandInput extends DescribePatchPropertiesRequest {}
export interface DescribePatchPropertiesCommandOutput
  extends DescribePatchPropertiesResult, __MetadataBearer {}
declare const DescribePatchPropertiesCommand_base: {
  new (
    input: DescribePatchPropertiesCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DescribePatchPropertiesCommandInput,
    DescribePatchPropertiesCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: DescribePatchPropertiesCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DescribePatchPropertiesCommandInput,
    DescribePatchPropertiesCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class DescribePatchPropertiesCommand extends DescribePatchPropertiesCommand_base {
  protected static __types: {
    api: {
      input: DescribePatchPropertiesRequest;
      output: DescribePatchPropertiesResult;
    };
    sdk: {
      input: DescribePatchPropertiesCommandInput;
      output: DescribePatchPropertiesCommandOutput;
    };
  };
}
