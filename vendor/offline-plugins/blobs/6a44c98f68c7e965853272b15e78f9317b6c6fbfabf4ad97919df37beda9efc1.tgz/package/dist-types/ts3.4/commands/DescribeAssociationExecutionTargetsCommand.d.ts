import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  DescribeAssociationExecutionTargetsRequest,
  DescribeAssociationExecutionTargetsResult,
} from "../models/models_0";
export { __MetadataBearer };
export interface DescribeAssociationExecutionTargetsCommandInput extends DescribeAssociationExecutionTargetsRequest {}
export interface DescribeAssociationExecutionTargetsCommandOutput
  extends DescribeAssociationExecutionTargetsResult, __MetadataBearer {}
declare const DescribeAssociationExecutionTargetsCommand_base: {
  new (
    input: DescribeAssociationExecutionTargetsCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DescribeAssociationExecutionTargetsCommandInput,
    DescribeAssociationExecutionTargetsCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: DescribeAssociationExecutionTargetsCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DescribeAssociationExecutionTargetsCommandInput,
    DescribeAssociationExecutionTargetsCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class DescribeAssociationExecutionTargetsCommand extends DescribeAssociationExecutionTargetsCommand_base {
  protected static __types: {
    api: {
      input: DescribeAssociationExecutionTargetsRequest;
      output: DescribeAssociationExecutionTargetsResult;
    };
    sdk: {
      input: DescribeAssociationExecutionTargetsCommandInput;
      output: DescribeAssociationExecutionTargetsCommandOutput;
    };
  };
}
