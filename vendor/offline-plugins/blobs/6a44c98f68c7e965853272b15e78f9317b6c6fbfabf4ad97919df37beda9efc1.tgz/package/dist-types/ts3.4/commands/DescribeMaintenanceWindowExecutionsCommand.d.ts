import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  DescribeMaintenanceWindowExecutionsRequest,
  DescribeMaintenanceWindowExecutionsResult,
} from "../models/models_0";
export { __MetadataBearer };
export interface DescribeMaintenanceWindowExecutionsCommandInput extends DescribeMaintenanceWindowExecutionsRequest {}
export interface DescribeMaintenanceWindowExecutionsCommandOutput
  extends DescribeMaintenanceWindowExecutionsResult, __MetadataBearer {}
declare const DescribeMaintenanceWindowExecutionsCommand_base: {
  new (
    input: DescribeMaintenanceWindowExecutionsCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DescribeMaintenanceWindowExecutionsCommandInput,
    DescribeMaintenanceWindowExecutionsCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: DescribeMaintenanceWindowExecutionsCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DescribeMaintenanceWindowExecutionsCommandInput,
    DescribeMaintenanceWindowExecutionsCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class DescribeMaintenanceWindowExecutionsCommand extends DescribeMaintenanceWindowExecutionsCommand_base {
  protected static __types: {
    api: {
      input: DescribeMaintenanceWindowExecutionsRequest;
      output: DescribeMaintenanceWindowExecutionsResult;
    };
    sdk: {
      input: DescribeMaintenanceWindowExecutionsCommandInput;
      output: DescribeMaintenanceWindowExecutionsCommandOutput;
    };
  };
}
