import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { GetParametersByPathRequest, GetParametersByPathResult } from "../models/models_1";
export { __MetadataBearer };
export interface GetParametersByPathCommandInput extends GetParametersByPathRequest {}
export interface GetParametersByPathCommandOutput
  extends GetParametersByPathResult, __MetadataBearer {}
declare const GetParametersByPathCommand_base: {
  new (
    input: GetParametersByPathCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    GetParametersByPathCommandInput,
    GetParametersByPathCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: GetParametersByPathCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    GetParametersByPathCommandInput,
    GetParametersByPathCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class GetParametersByPathCommand extends GetParametersByPathCommand_base {
  protected static __types: {
    api: {
      input: GetParametersByPathRequest;
      output: GetParametersByPathResult;
    };
    sdk: {
      input: GetParametersByPathCommandInput;
      output: GetParametersByPathCommandOutput;
    };
  };
}
