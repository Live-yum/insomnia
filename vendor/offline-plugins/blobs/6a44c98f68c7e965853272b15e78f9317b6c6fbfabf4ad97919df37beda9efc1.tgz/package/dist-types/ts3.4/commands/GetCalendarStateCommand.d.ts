import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { GetCalendarStateRequest, GetCalendarStateResponse } from "../models/models_0";
export { __MetadataBearer };
export interface GetCalendarStateCommandInput extends GetCalendarStateRequest {}
export interface GetCalendarStateCommandOutput extends GetCalendarStateResponse, __MetadataBearer {}
declare const GetCalendarStateCommand_base: {
  new (
    input: GetCalendarStateCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    GetCalendarStateCommandInput,
    GetCalendarStateCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: GetCalendarStateCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    GetCalendarStateCommandInput,
    GetCalendarStateCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class GetCalendarStateCommand extends GetCalendarStateCommand_base {
  protected static __types: {
    api: {
      input: GetCalendarStateRequest;
      output: GetCalendarStateResponse;
    };
    sdk: {
      input: GetCalendarStateCommandInput;
      output: GetCalendarStateCommandOutput;
    };
  };
}
