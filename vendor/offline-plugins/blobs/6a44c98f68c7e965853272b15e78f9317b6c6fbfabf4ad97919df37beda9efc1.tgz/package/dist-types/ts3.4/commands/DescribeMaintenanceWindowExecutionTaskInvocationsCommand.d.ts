import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  DescribeMaintenanceWindowExecutionTaskInvocationsRequest,
  DescribeMaintenanceWindowExecutionTaskInvocationsResult,
} from "../models/models_0";
export { __MetadataBearer };
export interface DescribeMaintenanceWindowExecutionTaskInvocationsCommandInput extends DescribeMaintenanceWindowExecutionTaskInvocationsRequest {}
export interface DescribeMaintenanceWindowExecutionTaskInvocationsCommandOutput
  extends DescribeMaintenanceWindowExecutionTaskInvocationsResult, __MetadataBearer {}
declare const DescribeMaintenanceWindowExecutionTaskInvocationsCommand_base: {
  new (
    input: DescribeMaintenanceWindowExecutionTaskInvocationsCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DescribeMaintenanceWindowExecutionTaskInvocationsCommandInput,
    DescribeMaintenanceWindowExecutionTaskInvocationsCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: DescribeMaintenanceWindowExecutionTaskInvocationsCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DescribeMaintenanceWindowExecutionTaskInvocationsCommandInput,
    DescribeMaintenanceWindowExecutionTaskInvocationsCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class DescribeMaintenanceWindowExecutionTaskInvocationsCommand extends DescribeMaintenanceWindowExecutionTaskInvocationsCommand_base {
  protected static __types: {
    api: {
      input: DescribeMaintenanceWindowExecutionTaskInvocationsRequest;
      output: DescribeMaintenanceWindowExecutionTaskInvocationsResult;
    };
    sdk: {
      input: DescribeMaintenanceWindowExecutionTaskInvocationsCommandInput;
      output: DescribeMaintenanceWindowExecutionTaskInvocationsCommandOutput;
    };
  };
}
