import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { GetInventorySchemaRequest, GetInventorySchemaResult } from "../models/models_0";
export { __MetadataBearer };
export interface GetInventorySchemaCommandInput extends GetInventorySchemaRequest {}
export interface GetInventorySchemaCommandOutput
  extends GetInventorySchemaResult, __MetadataBearer {}
declare const GetInventorySchemaCommand_base: {
  new (
    input: GetInventorySchemaCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    GetInventorySchemaCommandInput,
    GetInventorySchemaCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    ...[input]: [] | [GetInventorySchemaCommandInput]
  ): import("@smithy/core/client").CommandImpl<
    GetInventorySchemaCommandInput,
    GetInventorySchemaCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class GetInventorySchemaCommand extends GetInventorySchemaCommand_base {
  protected static __types: {
    api: {
      input: GetInventorySchemaRequest;
      output: GetInventorySchemaResult;
    };
    sdk: {
      input: GetInventorySchemaCommandInput;
      output: GetInventorySchemaCommandOutput;
    };
  };
}
