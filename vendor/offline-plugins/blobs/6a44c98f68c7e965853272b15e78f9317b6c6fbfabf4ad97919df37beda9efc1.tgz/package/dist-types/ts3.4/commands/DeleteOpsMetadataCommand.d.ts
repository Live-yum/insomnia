import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { DeleteOpsMetadataRequest, DeleteOpsMetadataResult } from "../models/models_0";
export { __MetadataBearer };
export interface DeleteOpsMetadataCommandInput extends DeleteOpsMetadataRequest {}
export interface DeleteOpsMetadataCommandOutput extends DeleteOpsMetadataResult, __MetadataBearer {}
declare const DeleteOpsMetadataCommand_base: {
  new (
    input: DeleteOpsMetadataCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DeleteOpsMetadataCommandInput,
    DeleteOpsMetadataCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: DeleteOpsMetadataCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DeleteOpsMetadataCommandInput,
    DeleteOpsMetadataCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class DeleteOpsMetadataCommand extends DeleteOpsMetadataCommand_base {
  protected static __types: {
    api: {
      input: DeleteOpsMetadataRequest;
      output: {};
    };
    sdk: {
      input: DeleteOpsMetadataCommandInput;
      output: DeleteOpsMetadataCommandOutput;
    };
  };
}
