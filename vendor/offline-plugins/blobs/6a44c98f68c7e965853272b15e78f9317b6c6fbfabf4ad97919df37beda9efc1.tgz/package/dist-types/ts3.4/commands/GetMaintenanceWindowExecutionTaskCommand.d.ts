import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  GetMaintenanceWindowExecutionTaskRequest,
  GetMaintenanceWindowExecutionTaskResult,
} from "../models/models_0";
export { __MetadataBearer };
export interface GetMaintenanceWindowExecutionTaskCommandInput extends GetMaintenanceWindowExecutionTaskRequest {}
export interface GetMaintenanceWindowExecutionTaskCommandOutput
  extends GetMaintenanceWindowExecutionTaskResult, __MetadataBearer {}
declare const GetMaintenanceWindowExecutionTaskCommand_base: {
  new (
    input: GetMaintenanceWindowExecutionTaskCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    GetMaintenanceWindowExecutionTaskCommandInput,
    GetMaintenanceWindowExecutionTaskCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: GetMaintenanceWindowExecutionTaskCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    GetMaintenanceWindowExecutionTaskCommandInput,
    GetMaintenanceWindowExecutionTaskCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class GetMaintenanceWindowExecutionTaskCommand extends GetMaintenanceWindowExecutionTaskCommand_base {
  protected static __types: {
    api: {
      input: GetMaintenanceWindowExecutionTaskRequest;
      output: GetMaintenanceWindowExecutionTaskResult;
    };
    sdk: {
      input: GetMaintenanceWindowExecutionTaskCommandInput;
      output: GetMaintenanceWindowExecutionTaskCommandOutput;
    };
  };
}
