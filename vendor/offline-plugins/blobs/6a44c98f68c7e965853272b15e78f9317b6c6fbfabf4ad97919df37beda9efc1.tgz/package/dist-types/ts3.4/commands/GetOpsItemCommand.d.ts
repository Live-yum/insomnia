import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { GetOpsItemRequest, GetOpsItemResponse } from "../models/models_0";
export { __MetadataBearer };
export interface GetOpsItemCommandInput extends GetOpsItemRequest {}
export interface GetOpsItemCommandOutput extends GetOpsItemResponse, __MetadataBearer {}
declare const GetOpsItemCommand_base: {
  new (
    input: GetOpsItemCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    GetOpsItemCommandInput,
    GetOpsItemCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: GetOpsItemCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    GetOpsItemCommandInput,
    GetOpsItemCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class GetOpsItemCommand extends GetOpsItemCommand_base {
  protected static __types: {
    api: {
      input: GetOpsItemRequest;
      output: GetOpsItemResponse;
    };
    sdk: {
      input: GetOpsItemCommandInput;
      output: GetOpsItemCommandOutput;
    };
  };
}
