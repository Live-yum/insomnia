import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  DeregisterManagedInstanceRequest,
  DeregisterManagedInstanceResult,
} from "../models/models_0";
export { __MetadataBearer };
export interface DeregisterManagedInstanceCommandInput extends DeregisterManagedInstanceRequest {}
export interface DeregisterManagedInstanceCommandOutput
  extends DeregisterManagedInstanceResult, __MetadataBearer {}
declare const DeregisterManagedInstanceCommand_base: {
  new (
    input: DeregisterManagedInstanceCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DeregisterManagedInstanceCommandInput,
    DeregisterManagedInstanceCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: DeregisterManagedInstanceCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DeregisterManagedInstanceCommandInput,
    DeregisterManagedInstanceCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class DeregisterManagedInstanceCommand extends DeregisterManagedInstanceCommand_base {
  protected static __types: {
    api: {
      input: DeregisterManagedInstanceRequest;
      output: {};
    };
    sdk: {
      input: DeregisterManagedInstanceCommandInput;
      output: DeregisterManagedInstanceCommandOutput;
    };
  };
}
