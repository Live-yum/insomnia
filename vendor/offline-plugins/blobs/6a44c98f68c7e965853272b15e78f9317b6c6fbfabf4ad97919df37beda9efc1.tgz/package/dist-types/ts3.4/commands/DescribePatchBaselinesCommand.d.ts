import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { DescribePatchBaselinesRequest, DescribePatchBaselinesResult } from "../models/models_0";
export { __MetadataBearer };
export interface DescribePatchBaselinesCommandInput extends DescribePatchBaselinesRequest {}
export interface DescribePatchBaselinesCommandOutput
  extends DescribePatchBaselinesResult, __MetadataBearer {}
declare const DescribePatchBaselinesCommand_base: {
  new (
    input: DescribePatchBaselinesCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DescribePatchBaselinesCommandInput,
    DescribePatchBaselinesCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    ...[input]: [] | [DescribePatchBaselinesCommandInput]
  ): import("@smithy/core/client").CommandImpl<
    DescribePatchBaselinesCommandInput,
    DescribePatchBaselinesCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class DescribePatchBaselinesCommand extends DescribePatchBaselinesCommand_base {
  protected static __types: {
    api: {
      input: DescribePatchBaselinesRequest;
      output: DescribePatchBaselinesResult;
    };
    sdk: {
      input: DescribePatchBaselinesCommandInput;
      output: DescribePatchBaselinesCommandOutput;
    };
  };
}
