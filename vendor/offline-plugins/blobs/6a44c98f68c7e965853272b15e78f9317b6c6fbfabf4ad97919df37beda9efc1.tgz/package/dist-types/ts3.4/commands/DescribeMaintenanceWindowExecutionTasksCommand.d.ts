import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  DescribeMaintenanceWindowExecutionTasksRequest,
  DescribeMaintenanceWindowExecutionTasksResult,
} from "../models/models_0";
export { __MetadataBearer };
export interface DescribeMaintenanceWindowExecutionTasksCommandInput extends DescribeMaintenanceWindowExecutionTasksRequest {}
export interface DescribeMaintenanceWindowExecutionTasksCommandOutput
  extends DescribeMaintenanceWindowExecutionTasksResult, __MetadataBearer {}
declare const DescribeMaintenanceWindowExecutionTasksCommand_base: {
  new (
    input: DescribeMaintenanceWindowExecutionTasksCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DescribeMaintenanceWindowExecutionTasksCommandInput,
    DescribeMaintenanceWindowExecutionTasksCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: DescribeMaintenanceWindowExecutionTasksCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DescribeMaintenanceWindowExecutionTasksCommandInput,
    DescribeMaintenanceWindowExecutionTasksCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class DescribeMaintenanceWindowExecutionTasksCommand extends DescribeMaintenanceWindowExecutionTasksCommand_base {
  protected static __types: {
    api: {
      input: DescribeMaintenanceWindowExecutionTasksRequest;
      output: DescribeMaintenanceWindowExecutionTasksResult;
    };
    sdk: {
      input: DescribeMaintenanceWindowExecutionTasksCommandInput;
      output: DescribeMaintenanceWindowExecutionTasksCommandOutput;
    };
  };
}
