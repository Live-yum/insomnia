import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  DeregisterPatchBaselineForPatchGroupRequest,
  DeregisterPatchBaselineForPatchGroupResult,
} from "../models/models_0";
export { __MetadataBearer };
export interface DeregisterPatchBaselineForPatchGroupCommandInput extends DeregisterPatchBaselineForPatchGroupRequest {}
export interface DeregisterPatchBaselineForPatchGroupCommandOutput
  extends DeregisterPatchBaselineForPatchGroupResult, __MetadataBearer {}
declare const DeregisterPatchBaselineForPatchGroupCommand_base: {
  new (
    input: DeregisterPatchBaselineForPatchGroupCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DeregisterPatchBaselineForPatchGroupCommandInput,
    DeregisterPatchBaselineForPatchGroupCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: DeregisterPatchBaselineForPatchGroupCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DeregisterPatchBaselineForPatchGroupCommandInput,
    DeregisterPatchBaselineForPatchGroupCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class DeregisterPatchBaselineForPatchGroupCommand extends DeregisterPatchBaselineForPatchGroupCommand_base {
  protected static __types: {
    api: {
      input: DeregisterPatchBaselineForPatchGroupRequest;
      output: DeregisterPatchBaselineForPatchGroupResult;
    };
    sdk: {
      input: DeregisterPatchBaselineForPatchGroupCommandInput;
      output: DeregisterPatchBaselineForPatchGroupCommandOutput;
    };
  };
}
