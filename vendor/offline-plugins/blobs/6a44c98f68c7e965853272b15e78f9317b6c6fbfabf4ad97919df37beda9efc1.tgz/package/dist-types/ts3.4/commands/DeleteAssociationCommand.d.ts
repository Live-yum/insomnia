import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { DeleteAssociationRequest, DeleteAssociationResult } from "../models/models_0";
export { __MetadataBearer };
export interface DeleteAssociationCommandInput extends DeleteAssociationRequest {}
export interface DeleteAssociationCommandOutput extends DeleteAssociationResult, __MetadataBearer {}
declare const DeleteAssociationCommand_base: {
  new (
    input: DeleteAssociationCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DeleteAssociationCommandInput,
    DeleteAssociationCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    ...[input]: [] | [DeleteAssociationCommandInput]
  ): import("@smithy/core/client").CommandImpl<
    DeleteAssociationCommandInput,
    DeleteAssociationCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class DeleteAssociationCommand extends DeleteAssociationCommand_base {
  protected static __types: {
    api: {
      input: DeleteAssociationRequest;
      output: {};
    };
    sdk: {
      input: DeleteAssociationCommandInput;
      output: DeleteAssociationCommandOutput;
    };
  };
}
