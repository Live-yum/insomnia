import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  CancelMaintenanceWindowExecutionRequest,
  CancelMaintenanceWindowExecutionResult,
} from "../models/models_0";
export { __MetadataBearer };
export interface CancelMaintenanceWindowExecutionCommandInput extends CancelMaintenanceWindowExecutionRequest {}
export interface CancelMaintenanceWindowExecutionCommandOutput
  extends CancelMaintenanceWindowExecutionResult, __MetadataBearer {}
declare const CancelMaintenanceWindowExecutionCommand_base: {
  new (
    input: CancelMaintenanceWindowExecutionCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    CancelMaintenanceWindowExecutionCommandInput,
    CancelMaintenanceWindowExecutionCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: CancelMaintenanceWindowExecutionCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    CancelMaintenanceWindowExecutionCommandInput,
    CancelMaintenanceWindowExecutionCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class CancelMaintenanceWindowExecutionCommand extends CancelMaintenanceWindowExecutionCommand_base {
  protected static __types: {
    api: {
      input: CancelMaintenanceWindowExecutionRequest;
      output: CancelMaintenanceWindowExecutionResult;
    };
    sdk: {
      input: CancelMaintenanceWindowExecutionCommandInput;
      output: CancelMaintenanceWindowExecutionCommandOutput;
    };
  };
}
