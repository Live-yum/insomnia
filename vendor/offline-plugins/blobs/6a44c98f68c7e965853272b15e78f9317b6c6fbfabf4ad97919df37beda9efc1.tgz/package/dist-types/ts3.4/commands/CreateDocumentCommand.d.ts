import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { CreateDocumentRequest, CreateDocumentResult } from "../models/models_0";
export { __MetadataBearer };
export interface CreateDocumentCommandInput extends CreateDocumentRequest {}
export interface CreateDocumentCommandOutput extends CreateDocumentResult, __MetadataBearer {}
declare const CreateDocumentCommand_base: {
  new (
    input: CreateDocumentCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    CreateDocumentCommandInput,
    CreateDocumentCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: CreateDocumentCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    CreateDocumentCommandInput,
    CreateDocumentCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class CreateDocumentCommand extends CreateDocumentCommand_base {
  protected static __types: {
    api: {
      input: CreateDocumentRequest;
      output: CreateDocumentResult;
    };
    sdk: {
      input: CreateDocumentCommandInput;
      output: CreateDocumentCommandOutput;
    };
  };
}
