import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  DescribeEffectiveInstanceAssociationsRequest,
  DescribeEffectiveInstanceAssociationsResult,
} from "../models/models_0";
export { __MetadataBearer };
export interface DescribeEffectiveInstanceAssociationsCommandInput extends DescribeEffectiveInstanceAssociationsRequest {}
export interface DescribeEffectiveInstanceAssociationsCommandOutput
  extends DescribeEffectiveInstanceAssociationsResult, __MetadataBearer {}
declare const DescribeEffectiveInstanceAssociationsCommand_base: {
  new (
    input: DescribeEffectiveInstanceAssociationsCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DescribeEffectiveInstanceAssociationsCommandInput,
    DescribeEffectiveInstanceAssociationsCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: DescribeEffectiveInstanceAssociationsCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DescribeEffectiveInstanceAssociationsCommandInput,
    DescribeEffectiveInstanceAssociationsCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class DescribeEffectiveInstanceAssociationsCommand extends DescribeEffectiveInstanceAssociationsCommand_base {
  protected static __types: {
    api: {
      input: DescribeEffectiveInstanceAssociationsRequest;
      output: DescribeEffectiveInstanceAssociationsResult;
    };
    sdk: {
      input: DescribeEffectiveInstanceAssociationsCommandInput;
      output: DescribeEffectiveInstanceAssociationsCommandOutput;
    };
  };
}
