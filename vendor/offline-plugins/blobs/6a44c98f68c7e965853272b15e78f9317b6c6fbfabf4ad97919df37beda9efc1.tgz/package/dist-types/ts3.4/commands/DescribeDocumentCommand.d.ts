import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { DescribeDocumentRequest, DescribeDocumentResult } from "../models/models_0";
export { __MetadataBearer };
export interface DescribeDocumentCommandInput extends DescribeDocumentRequest {}
export interface DescribeDocumentCommandOutput extends DescribeDocumentResult, __MetadataBearer {}
declare const DescribeDocumentCommand_base: {
  new (
    input: DescribeDocumentCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DescribeDocumentCommandInput,
    DescribeDocumentCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: DescribeDocumentCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DescribeDocumentCommandInput,
    DescribeDocumentCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class DescribeDocumentCommand extends DescribeDocumentCommand_base {
  protected static __types: {
    api: {
      input: DescribeDocumentRequest;
      output: DescribeDocumentResult;
    };
    sdk: {
      input: DescribeDocumentCommandInput;
      output: DescribeDocumentCommandOutput;
    };
  };
}
