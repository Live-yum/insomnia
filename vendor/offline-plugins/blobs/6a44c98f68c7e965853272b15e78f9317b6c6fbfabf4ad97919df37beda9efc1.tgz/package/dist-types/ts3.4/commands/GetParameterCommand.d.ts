import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { GetParameterRequest, GetParameterResult } from "../models/models_0";
export { __MetadataBearer };
export interface GetParameterCommandInput extends GetParameterRequest {}
export interface GetParameterCommandOutput extends GetParameterResult, __MetadataBearer {}
declare const GetParameterCommand_base: {
  new (
    input: GetParameterCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    GetParameterCommandInput,
    GetParameterCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: GetParameterCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    GetParameterCommandInput,
    GetParameterCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class GetParameterCommand extends GetParameterCommand_base {
  protected static __types: {
    api: {
      input: GetParameterRequest;
      output: GetParameterResult;
    };
    sdk: {
      input: GetParameterCommandInput;
      output: GetParameterCommandOutput;
    };
  };
}
