import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { DeleteInventoryRequest, DeleteInventoryResult } from "../models/models_0";
export { __MetadataBearer };
export interface DeleteInventoryCommandInput extends DeleteInventoryRequest {}
export interface DeleteInventoryCommandOutput extends DeleteInventoryResult, __MetadataBearer {}
declare const DeleteInventoryCommand_base: {
  new (
    input: DeleteInventoryCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DeleteInventoryCommandInput,
    DeleteInventoryCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: DeleteInventoryCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DeleteInventoryCommandInput,
    DeleteInventoryCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class DeleteInventoryCommand extends DeleteInventoryCommand_base {
  protected static __types: {
    api: {
      input: DeleteInventoryRequest;
      output: DeleteInventoryResult;
    };
    sdk: {
      input: DeleteInventoryCommandInput;
      output: DeleteInventoryCommandOutput;
    };
  };
}
