import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { DescribeActivationsRequest, DescribeActivationsResult } from "../models/models_0";
export { __MetadataBearer };
export interface DescribeActivationsCommandInput extends DescribeActivationsRequest {}
export interface DescribeActivationsCommandOutput
  extends DescribeActivationsResult, __MetadataBearer {}
declare const DescribeActivationsCommand_base: {
  new (
    input: DescribeActivationsCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DescribeActivationsCommandInput,
    DescribeActivationsCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    ...[input]: [] | [DescribeActivationsCommandInput]
  ): import("@smithy/core/client").CommandImpl<
    DescribeActivationsCommandInput,
    DescribeActivationsCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class DescribeActivationsCommand extends DescribeActivationsCommand_base {
  protected static __types: {
    api: {
      input: DescribeActivationsRequest;
      output: DescribeActivationsResult;
    };
    sdk: {
      input: DescribeActivationsCommandInput;
      output: DescribeActivationsCommandOutput;
    };
  };
}
