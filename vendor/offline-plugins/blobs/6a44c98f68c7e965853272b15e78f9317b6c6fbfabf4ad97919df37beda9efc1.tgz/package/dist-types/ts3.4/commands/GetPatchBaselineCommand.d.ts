import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { GetPatchBaselineRequest, GetPatchBaselineResult } from "../models/models_1";
export { __MetadataBearer };
export interface GetPatchBaselineCommandInput extends GetPatchBaselineRequest {}
export interface GetPatchBaselineCommandOutput extends GetPatchBaselineResult, __MetadataBearer {}
declare const GetPatchBaselineCommand_base: {
  new (
    input: GetPatchBaselineCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    GetPatchBaselineCommandInput,
    GetPatchBaselineCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: GetPatchBaselineCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    GetPatchBaselineCommandInput,
    GetPatchBaselineCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class GetPatchBaselineCommand extends GetPatchBaselineCommand_base {
  protected static __types: {
    api: {
      input: GetPatchBaselineRequest;
      output: GetPatchBaselineResult;
    };
    sdk: {
      input: GetPatchBaselineCommandInput;
      output: GetPatchBaselineCommandOutput;
    };
  };
}
