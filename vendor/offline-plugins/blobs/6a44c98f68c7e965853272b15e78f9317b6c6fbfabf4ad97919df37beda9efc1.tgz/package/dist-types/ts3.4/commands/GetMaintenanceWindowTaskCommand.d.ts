import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  GetMaintenanceWindowTaskRequest,
  GetMaintenanceWindowTaskResult,
} from "../models/models_0";
export { __MetadataBearer };
export interface GetMaintenanceWindowTaskCommandInput extends GetMaintenanceWindowTaskRequest {}
export interface GetMaintenanceWindowTaskCommandOutput
  extends GetMaintenanceWindowTaskResult, __MetadataBearer {}
declare const GetMaintenanceWindowTaskCommand_base: {
  new (
    input: GetMaintenanceWindowTaskCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    GetMaintenanceWindowTaskCommandInput,
    GetMaintenanceWindowTaskCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: GetMaintenanceWindowTaskCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    GetMaintenanceWindowTaskCommandInput,
    GetMaintenanceWindowTaskCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class GetMaintenanceWindowTaskCommand extends GetMaintenanceWindowTaskCommand_base {
  protected static __types: {
    api: {
      input: GetMaintenanceWindowTaskRequest;
      output: GetMaintenanceWindowTaskResult;
    };
    sdk: {
      input: GetMaintenanceWindowTaskCommandInput;
      output: GetMaintenanceWindowTaskCommandOutput;
    };
  };
}
