import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  DescribeMaintenanceWindowsForTargetRequest,
  DescribeMaintenanceWindowsForTargetResult,
} from "../models/models_0";
export { __MetadataBearer };
export interface DescribeMaintenanceWindowsForTargetCommandInput extends DescribeMaintenanceWindowsForTargetRequest {}
export interface DescribeMaintenanceWindowsForTargetCommandOutput
  extends DescribeMaintenanceWindowsForTargetResult, __MetadataBearer {}
declare const DescribeMaintenanceWindowsForTargetCommand_base: {
  new (
    input: DescribeMaintenanceWindowsForTargetCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DescribeMaintenanceWindowsForTargetCommandInput,
    DescribeMaintenanceWindowsForTargetCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: DescribeMaintenanceWindowsForTargetCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DescribeMaintenanceWindowsForTargetCommandInput,
    DescribeMaintenanceWindowsForTargetCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class DescribeMaintenanceWindowsForTargetCommand extends DescribeMaintenanceWindowsForTargetCommand_base {
  protected static __types: {
    api: {
      input: DescribeMaintenanceWindowsForTargetRequest;
      output: DescribeMaintenanceWindowsForTargetResult;
    };
    sdk: {
      input: DescribeMaintenanceWindowsForTargetCommandInput;
      output: DescribeMaintenanceWindowsForTargetCommandOutput;
    };
  };
}
