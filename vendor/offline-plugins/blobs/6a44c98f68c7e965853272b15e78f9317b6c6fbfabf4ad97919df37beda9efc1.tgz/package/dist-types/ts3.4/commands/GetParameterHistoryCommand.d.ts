import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { GetParameterHistoryRequest, GetParameterHistoryResult } from "../models/models_0";
export { __MetadataBearer };
export interface GetParameterHistoryCommandInput extends GetParameterHistoryRequest {}
export interface GetParameterHistoryCommandOutput
  extends GetParameterHistoryResult, __MetadataBearer {}
declare const GetParameterHistoryCommand_base: {
  new (
    input: GetParameterHistoryCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    GetParameterHistoryCommandInput,
    GetParameterHistoryCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: GetParameterHistoryCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    GetParameterHistoryCommandInput,
    GetParameterHistoryCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class GetParameterHistoryCommand extends GetParameterHistoryCommand_base {
  protected static __types: {
    api: {
      input: GetParameterHistoryRequest;
      output: GetParameterHistoryResult;
    };
    sdk: {
      input: GetParameterHistoryCommandInput;
      output: GetParameterHistoryCommandOutput;
    };
  };
}
