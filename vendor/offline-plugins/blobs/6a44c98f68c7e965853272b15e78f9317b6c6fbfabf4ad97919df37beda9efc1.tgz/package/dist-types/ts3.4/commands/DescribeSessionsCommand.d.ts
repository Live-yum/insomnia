import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { DescribeSessionsRequest, DescribeSessionsResponse } from "../models/models_0";
export { __MetadataBearer };
export interface DescribeSessionsCommandInput extends DescribeSessionsRequest {}
export interface DescribeSessionsCommandOutput extends DescribeSessionsResponse, __MetadataBearer {}
declare const DescribeSessionsCommand_base: {
  new (
    input: DescribeSessionsCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DescribeSessionsCommandInput,
    DescribeSessionsCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: DescribeSessionsCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DescribeSessionsCommandInput,
    DescribeSessionsCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class DescribeSessionsCommand extends DescribeSessionsCommand_base {
  protected static __types: {
    api: {
      input: DescribeSessionsRequest;
      output: DescribeSessionsResponse;
    };
    sdk: {
      input: DescribeSessionsCommandInput;
      output: DescribeSessionsCommandOutput;
    };
  };
}
