import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { CreateActivationRequest, CreateActivationResult } from "../models/models_0";
export { __MetadataBearer };
export interface CreateActivationCommandInput extends CreateActivationRequest {}
export interface CreateActivationCommandOutput extends CreateActivationResult, __MetadataBearer {}
declare const CreateActivationCommand_base: {
  new (
    input: CreateActivationCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    CreateActivationCommandInput,
    CreateActivationCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: CreateActivationCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    CreateActivationCommandInput,
    CreateActivationCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class CreateActivationCommand extends CreateActivationCommand_base {
  protected static __types: {
    api: {
      input: CreateActivationRequest;
      output: CreateActivationResult;
    };
    sdk: {
      input: CreateActivationCommandInput;
      output: CreateActivationCommandOutput;
    };
  };
}
