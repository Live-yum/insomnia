import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { GetInventoryResult } from "../models/models_0";
import { GetInventoryRequest } from "../models/models_1";
export { __MetadataBearer };
export interface GetInventoryCommandInput extends GetInventoryRequest {}
export interface GetInventoryCommandOutput extends GetInventoryResult, __MetadataBearer {}
declare const GetInventoryCommand_base: {
  new (
    input: GetInventoryCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    GetInventoryCommandInput,
    GetInventoryCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    ...[input]: [] | [GetInventoryCommandInput]
  ): import("@smithy/core/client").CommandImpl<
    GetInventoryCommandInput,
    GetInventoryCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class GetInventoryCommand extends GetInventoryCommand_base {
  protected static __types: {
    api: {
      input: GetInventoryRequest;
      output: GetInventoryResult;
    };
    sdk: {
      input: GetInventoryCommandInput;
      output: GetInventoryCommandOutput;
    };
  };
}
