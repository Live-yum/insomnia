import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { DeleteOpsItemRequest, DeleteOpsItemResponse } from "../models/models_0";
export { __MetadataBearer };
export interface DeleteOpsItemCommandInput extends DeleteOpsItemRequest {}
export interface DeleteOpsItemCommandOutput extends DeleteOpsItemResponse, __MetadataBearer {}
declare const DeleteOpsItemCommand_base: {
  new (
    input: DeleteOpsItemCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DeleteOpsItemCommandInput,
    DeleteOpsItemCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: DeleteOpsItemCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DeleteOpsItemCommandInput,
    DeleteOpsItemCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class DeleteOpsItemCommand extends DeleteOpsItemCommand_base {
  protected static __types: {
    api: {
      input: DeleteOpsItemRequest;
      output: {};
    };
    sdk: {
      input: DeleteOpsItemCommandInput;
      output: DeleteOpsItemCommandOutput;
    };
  };
}
