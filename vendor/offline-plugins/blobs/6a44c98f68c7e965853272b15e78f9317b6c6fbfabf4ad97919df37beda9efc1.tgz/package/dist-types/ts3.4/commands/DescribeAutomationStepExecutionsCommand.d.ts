import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  DescribeAutomationStepExecutionsRequest,
  DescribeAutomationStepExecutionsResult,
} from "../models/models_0";
export { __MetadataBearer };
export interface DescribeAutomationStepExecutionsCommandInput extends DescribeAutomationStepExecutionsRequest {}
export interface DescribeAutomationStepExecutionsCommandOutput
  extends DescribeAutomationStepExecutionsResult, __MetadataBearer {}
declare const DescribeAutomationStepExecutionsCommand_base: {
  new (
    input: DescribeAutomationStepExecutionsCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DescribeAutomationStepExecutionsCommandInput,
    DescribeAutomationStepExecutionsCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: DescribeAutomationStepExecutionsCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DescribeAutomationStepExecutionsCommandInput,
    DescribeAutomationStepExecutionsCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class DescribeAutomationStepExecutionsCommand extends DescribeAutomationStepExecutionsCommand_base {
  protected static __types: {
    api: {
      input: DescribeAutomationStepExecutionsRequest;
      output: DescribeAutomationStepExecutionsResult;
    };
    sdk: {
      input: DescribeAutomationStepExecutionsCommandInput;
      output: DescribeAutomationStepExecutionsCommandOutput;
    };
  };
}
