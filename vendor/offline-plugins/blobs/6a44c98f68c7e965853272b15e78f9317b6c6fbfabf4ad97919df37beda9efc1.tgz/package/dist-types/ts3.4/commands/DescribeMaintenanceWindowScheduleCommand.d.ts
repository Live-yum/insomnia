import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  DescribeMaintenanceWindowScheduleRequest,
  DescribeMaintenanceWindowScheduleResult,
} from "../models/models_0";
export { __MetadataBearer };
export interface DescribeMaintenanceWindowScheduleCommandInput extends DescribeMaintenanceWindowScheduleRequest {}
export interface DescribeMaintenanceWindowScheduleCommandOutput
  extends DescribeMaintenanceWindowScheduleResult, __MetadataBearer {}
declare const DescribeMaintenanceWindowScheduleCommand_base: {
  new (
    input: DescribeMaintenanceWindowScheduleCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DescribeMaintenanceWindowScheduleCommandInput,
    DescribeMaintenanceWindowScheduleCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    ...[input]: [] | [DescribeMaintenanceWindowScheduleCommandInput]
  ): import("@smithy/core/client").CommandImpl<
    DescribeMaintenanceWindowScheduleCommandInput,
    DescribeMaintenanceWindowScheduleCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class DescribeMaintenanceWindowScheduleCommand extends DescribeMaintenanceWindowScheduleCommand_base {
  protected static __types: {
    api: {
      input: DescribeMaintenanceWindowScheduleRequest;
      output: DescribeMaintenanceWindowScheduleResult;
    };
    sdk: {
      input: DescribeMaintenanceWindowScheduleCommandInput;
      output: DescribeMaintenanceWindowScheduleCommandOutput;
    };
  };
}
