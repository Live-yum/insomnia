import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  DescribeInstancePropertiesRequest,
  DescribeInstancePropertiesResult,
} from "../models/models_0";
export { __MetadataBearer };
export interface DescribeInstancePropertiesCommandInput extends DescribeInstancePropertiesRequest {}
export interface DescribeInstancePropertiesCommandOutput
  extends DescribeInstancePropertiesResult, __MetadataBearer {}
declare const DescribeInstancePropertiesCommand_base: {
  new (
    input: DescribeInstancePropertiesCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DescribeInstancePropertiesCommandInput,
    DescribeInstancePropertiesCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    ...[input]: [] | [DescribeInstancePropertiesCommandInput]
  ): import("@smithy/core/client").CommandImpl<
    DescribeInstancePropertiesCommandInput,
    DescribeInstancePropertiesCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class DescribeInstancePropertiesCommand extends DescribeInstancePropertiesCommand_base {
  protected static __types: {
    api: {
      input: DescribeInstancePropertiesRequest;
      output: DescribeInstancePropertiesResult;
    };
    sdk: {
      input: DescribeInstancePropertiesCommandInput;
      output: DescribeInstancePropertiesCommandOutput;
    };
  };
}
