import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { GetDocumentRequest, GetDocumentResult } from "../models/models_0";
export { __MetadataBearer };
export interface GetDocumentCommandInput extends GetDocumentRequest {}
export interface GetDocumentCommandOutput extends GetDocumentResult, __MetadataBearer {}
declare const GetDocumentCommand_base: {
  new (
    input: GetDocumentCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    GetDocumentCommandInput,
    GetDocumentCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: GetDocumentCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    GetDocumentCommandInput,
    GetDocumentCommandOutput,
    import("..").SSMClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class GetDocumentCommand extends GetDocumentCommand_base {
  protected static __types: {
    api: {
      input: GetDocumentRequest;
      output: GetDocumentResult;
    };
    sdk: {
      input: GetDocumentCommandInput;
      output: GetDocumentCommandOutput;
    };
  };
}
