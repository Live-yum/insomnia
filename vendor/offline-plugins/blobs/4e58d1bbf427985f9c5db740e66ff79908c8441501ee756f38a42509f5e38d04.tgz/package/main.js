const crypto = require('crypto');
const { isBuffer } = require('util');

const replacementContent = 'Will be replaced with HMAC of request body';
const settings = {
  key: null,
  token: null,
  algorithm: null,
  encoding: null,
  jsonPath: null,
  removeWhitespace: false
};

function hmac(payload) {
  const hash = crypto.createHmac('SHA256', settings.key);
  hash.update(payload, 'utf8');
  return hash.digest('base64');
}

function getPath(url) {
  var pathRegex = /.+?\:\/\/.+?(\/.+?)(?:#|\?|$)/;
  var result = url.match(pathRegex);
  return result && result.length > 1 ? result[1] : '';
}

function getQueryString(url) {
  var arrSplit = url.split('?');
  return arrSplit.length > 1 ? url.substring(url.indexOf('?') + 1) : '';
}

module.exports.templateTags = [
  {
    name: 'requestbodyhmac',
    displayName: 'Request body HMAC',
    description: 'HMAC a value or the request body',
    args: [
      {
        displayName: 'Secret Key',
        type: 'string',
        placeholder: 'HMAC Secret Key'
      },
    ],
    async run(context, key = '') {

      settings.key = key;
      return hmac('');
    }
  }
];

module.exports.requestHooks = [
  context => {
    const requestUrl = context.request.getUrl();
    const requestBody = context.request.getBody();
    const httpMethod = context.request.getMethod().toUpperCase();
    const env = context.request.getEnvironment();

    let reqBody = null;
    if (httpMethod == 'GET') {
      reqBody = '';
    } else {
      reqBody = requestBody.text;
    }

    const timestamp = new Date().toISOString();

    let requestPath = getPath(requestUrl);
    let queryString = getQueryString(requestUrl);
    let token = settings.token;
    console.log('req body=>', reqBody);
    console.log('timestamp', timestamp);
    let payload = 'path=' + requestPath + '&verb=' + httpMethod + '&token=Bearer ' + env.token +
      '&timestamp=' + timestamp + '&body=' + reqBody;

    console.log('payload', payload);


    context.request.getHeaders().forEach(h => {
      if (h.name === 'BRI-Signature') {
        context.request.setHeader('BRI-Signature', hmac(payload));
        context.request.setHeader('BRI-Timestamp', timestamp);
      }
    });

  }
];
