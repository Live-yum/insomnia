'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

function _interopDefault (ex) { return (ex && (typeof ex === 'object') && 'default' in ex) ? ex['default'] : ex; }

var Hash = _interopDefault(require('sha.js/sha1.js'));
var AsyncLock = _interopDefault(require('async-lock'));
var cleanGitRef = _interopDefault(require('clean-git-ref'));
var crc32 = _interopDefault(require('crc-32'));
var pako = _interopDefault(require('pako'));
var crypto$1 = require('crypto');
var pify = _interopDefault(require('pify'));
var ignore = _interopDefault(require('ignore'));
var diff3Merge = _interopDefault(require('diff3'));

/**
 * @typedef {Object} GitProgressEvent
 * @property {string} phase
 * @property {number} loaded
 * @property {number} total
 */

/**
 * @callback ProgressCallback
 * @param {GitProgressEvent} progress
 * @returns {void | Promise<void>}
 */

/**
 * @typedef {Object} GitHttpRequest
 * @property {string} url - The URL to request
 * @property {string} [method='GET'] - The HTTP method to use
 * @property {Object<string, string>} [headers={}] - Headers to include in the HTTP request
 * @property {Object} [agent] - An HTTP or HTTPS agent that manages connections for the HTTP client (Node.js only)
 * @property {AsyncIterableIterator<Uint8Array>} [body] - An async iterator of Uint8Arrays that make up the body of POST requests
 * @property {ProgressCallback} [onProgress] - Reserved for future use (emitting `GitProgressEvent`s)
 * @property {AbortSignal} [signal] - Signal to abort the HTTP request
 * @property {Object} [fetchOptions={}] - Additional options to pass to fetch (Web) or simple-get (Node)
 */

/**
 * @typedef {Object} GitHttpResponse
 * @property {string} url - The final URL that was fetched after any redirects
 * @property {string} [method] - The HTTP method that was used
 * @property {Object<string, string>} [headers] - HTTP response headers
 * @property {AsyncIterableIterator<Uint8Array>} [body] - An async iterator of Uint8Arrays that make up the body of the response
 * @property {number} statusCode - The HTTP status code
 * @property {string} statusMessage - The HTTP status message
 */

/**
 * @callback HttpFetch
 * @param {GitHttpRequest} request
 * @returns {Promise<GitHttpResponse>}
 */

/**
 * @typedef {Object} HttpClient
 * @property {HttpFetch} request
 */

/**
 * A git commit object.
 *
 * @typedef {Object} CommitObject
 * @property {string} message Commit message
 * @property {string} tree SHA-1 object id of corresponding file tree
 * @property {string[]} parent an array of zero or more SHA-1 object ids
 * @property {Array.<Array.<string|null>>} [changes] Changed files as `[newOid, oldOid, filepath]`; present when `log` is called with `includeChanges: true`.
 * @property {Object} author
 * @property {string} author.name The author's name
 * @property {string} author.email The author's email
 * @property {number} author.timestamp UTC Unix timestamp in seconds
 * @property {number} author.timezoneOffset Timezone difference from UTC in minutes
 * @property {Object} committer
 * @property {string} committer.name The committer's name
 * @property {string} committer.email The committer's email
 * @property {number} committer.timestamp UTC Unix timestamp in seconds
 * @property {number} committer.timezoneOffset Timezone difference from UTC in minutes
 * @property {string} [gpgsig] PGP signature (if present)
 */

/**
 * An entry from a git tree object. Files are called 'blobs' and directories are called 'trees'.
 *
 * @typedef {Object} TreeEntry
 * @property {string} mode the 6 digit hexadecimal mode
 * @property {string} path the name of the file or directory
 * @property {string} oid the SHA-1 object id of the blob or tree
 * @property {'commit'|'blob'|'tree'} type the type of object
 */

/**
 * A git tree object. Trees represent a directory snapshot.
 *
 * @typedef {TreeEntry[]} TreeObject
 */

/**
 * A git annotated tag object.
 *
 * @typedef {Object} TagObject
 * @property {string} object SHA-1 object id of object being tagged
 * @property {'blob' | 'tree' | 'commit' | 'tag'} type the type of the object being tagged
 * @property {string} tag the tag name
 * @property {Object} tagger
 * @property {string} tagger.name the tagger's name
 * @property {string} tagger.email the tagger's email
 * @property {number} tagger.timestamp UTC Unix timestamp in seconds
 * @property {number} tagger.timezoneOffset timezone difference from UTC in minutes
 * @property {string} message tag message
 * @property {string} [gpgsig] PGP signature (if present)
 */

/**
 * @typedef {Object} ReadCommitResult
 * @property {string} oid - SHA-1 object id of this commit
 * @property {CommitObject} commit - the parsed commit object
 * @property {string} payload - PGP signing payload
 */

/**
 * @typedef {Object} ServerRef - This object has the following schema:
 * @property {string} ref - The name of the ref
 * @property {string} oid - The SHA-1 object id the ref points to
 * @property {string} [target] - The target ref pointed to by a symbolic ref
 * @property {string} [peeled] - If the oid is the SHA-1 object id of an annotated tag, this is the SHA-1 object id that the annotated tag points to
 */

/**
 * @typedef Walker
 * @property {Symbol} Symbol('GitWalkerSymbol')
 */

/**
 * Normalized subset of filesystem `stat` data:
 *
 * @typedef {Object} Stat
 * @property {number} ctimeSeconds
 * @property {number} ctimeNanoseconds
 * @property {number} mtimeSeconds
 * @property {number} mtimeNanoseconds
 * @property {number} dev
 * @property {number} ino
 * @property {number} mode
 * @property {number} uid
 * @property {number} gid
 * @property {number} size
 */

/**
 * The `WalkerEntry` is an interface that abstracts computing many common tree / blob stats.
 *
 * @typedef {Object} WalkerEntry
 * @property {function(): Promise<'tree'|'blob'|'special'|'commit'>} type
 * @property {function(): Promise<number>} mode
 * @property {function(): Promise<string>} oid
 * @property {function(): Promise<Uint8Array|void>} content
 * @property {function(): Promise<Stat>} stat
 */

/**
 * @typedef {Object} CallbackFsClient
 * @property {function} readFile - https://nodejs.org/api/fs.html#fs_fs_readfile_path_options_callback
 * @property {function} writeFile - https://nodejs.org/api/fs.html#fs_fs_writefile_file_data_options_callback
 * @property {function} unlink - https://nodejs.org/api/fs.html#fs_fs_unlink_path_callback
 * @property {function} readdir - https://nodejs.org/api/fs.html#fs_fs_readdir_path_options_callback
 * @property {function} mkdir - https://nodejs.org/api/fs.html#fs_fs_mkdir_path_mode_callback
 * @property {function} rmdir - https://nodejs.org/api/fs.html#fs_fs_rmdir_path_callback
 * @property {function} stat - https://nodejs.org/api/fs.html#fs_fs_stat_path_options_callback
 * @property {function} lstat - https://nodejs.org/api/fs.html#fs_fs_lstat_path_options_callback
 * @property {function} [readlink] - https://nodejs.org/api/fs.html#fs_fs_readlink_path_options_callback
 * @property {function} [symlink] - https://nodejs.org/api/fs.html#fs_fs_symlink_target_path_type_callback
 * @property {function} [chmod] - https://nodejs.org/api/fs.html#fs_fs_chmod_path_mode_callback
 */

/**
 * @typedef {Object} PromiseFsClient
 * @property {Object} promises
 * @property {function} promises.readFile - https://nodejs.org/api/fs.html#fs_fspromises_readfile_path_options
 * @property {function} promises.writeFile - https://nodejs.org/api/fs.html#fs_fspromises_writefile_file_data_options
 * @property {function} promises.unlink - https://nodejs.org/api/fs.html#fs_fspromises_unlink_path
 * @property {function} promises.readdir - https://nodejs.org/api/fs.html#fs_fspromises_readdir_path_options
 * @property {function} promises.mkdir - https://nodejs.org/api/fs.html#fs_fspromises_mkdir_path_options
 * @property {function} promises.rmdir - https://nodejs.org/api/fs.html#fs_fspromises_rmdir_path
 * @property {function} promises.stat - https://nodejs.org/api/fs.html#fs_fspromises_stat_path_options
 * @property {function} promises.lstat - https://nodejs.org/api/fs.html#fs_fspromises_lstat_path_options
 * @property {function} [promises.readlink] - https://nodejs.org/api/fs.html#fs_fspromises_readlink_path_options
 * @property {function} [promises.symlink] - https://nodejs.org/api/fs.html#fs_fspromises_symlink_target_path_type
 * @property {function} [promises.chmod] - https://nodejs.org/api/fs.html#fs_fspromises_chmod_path_mode
 */

/**
 * @typedef {CallbackFsClient | PromiseFsClient} FsClient
 */

/**
 * @callback MessageCallback
 * @param {string} message
 * @returns {void | Promise<void>}
 */

/**
 * @typedef {Object} GitAuth
 * @property {string} [username]
 * @property {string} [password]
 * @property {Object<string, string>} [headers]
 * @property {boolean} [cancel] Tells git to throw a `UserCanceledError` (instead of an `HttpError`).
 */

/**
 * @callback AuthCallback
 * @param {string} url
 * @param {GitAuth} auth Might have some values if the URL itself originally contained a username or password.
 * @returns {GitAuth | void | Promise<GitAuth | void>}
 */

/**
 * @callback AuthFailureCallback
 * @param {string} url
 * @param {GitAuth} auth The credentials that failed
 * @returns {GitAuth | void | Promise<GitAuth | void>}
 */

/**
 * @callback AuthSuccessCallback
 * @param {string} url
 * @param {GitAuth} auth
 * @returns {void | Promise<void>}
 */

/**
 * @typedef {Object} SignParams
 * @property {string} payload - a plaintext message
 * @property {string} secretKey - an 'ASCII armor' encoded PGP key (technically can actually contain _multiple_ keys)
 */

/**
 * @callback SignCallback
 * @param {SignParams} args
 * @return {{signature: string} | Promise<{signature: string}>} - an 'ASCII armor' encoded "detached" signature
 */

/**
 * @typedef {Object} MergeDriverParams
 * @property {Array<string>} branches
 * @property {Array<string>} contents
 * @property {string} path
 */

/**
 * @callback MergeDriverCallback
 * @param {MergeDriverParams} args
 * @return {{cleanMerge: boolean, mergedText: string} | Promise<{cleanMerge: boolean, mergedText: string}>}
 */

/**
 * @callback WalkerMap
 * @param {string} filename
 * @param {WalkerEntry[]} entries
 * @returns {Promise<any>}
 */

/**
 * @callback WalkerReduce
 * @param {any} parent
 * @param {any[]} children
 * @returns {Promise<any>}
 */

/**
 * @callback WalkerIterateCallback
 * @param {WalkerEntry[]} entries
 * @returns {Promise<any[]>}
 */

/**
 * @callback WalkerIterate
 * @param {WalkerIterateCallback} walk
 * @param {IterableIterator<WalkerEntry[]>} children
 * @returns {Promise<any[]>}
 */

/**
 * @typedef {Object} RefUpdateStatus
 * @property {boolean} ok
 * @property {string} error
 */

/**
 * @typedef {Object} PushResult
 * @property {boolean} ok
 * @property {?string} error
 * @property {Object<string, RefUpdateStatus>} refs
 * @property {Object<string, string>} [headers]
 */

/**
 * @typedef {0|1} HeadStatus
 */

/**
 * @typedef {0|1|2} WorkdirStatus
 */

/**
 * @typedef {0|1|2|3} StageStatus
 */

/**
 * @typedef {[string, HeadStatus, WorkdirStatus, StageStatus]} StatusRow
 */

/**
 * @typedef {'push' | 'pop' | 'apply' | 'drop' | 'list' | 'clear'} StashOp the type of stash ops
 */

/**
 * @typedef {'equal' | 'modify' | 'add' | 'remove' | 'unknown'} StashChangeType - when compare WORDIR to HEAD, 'remove' could mean 'untracked'
 * @typedef {Object} ClientRef
 * @property {string} ref The name of the ref
 * @property {string} oid The SHA-1 object id the ref points to
 */

/**
 * @typedef {Object} PrePushParams
 * @property {string} remote The expanded name of target remote
 * @property {string} url The URL address of target remote
 * @property {ClientRef} localRef The ref which the client wants to push to the remote
 * @property {ClientRef} remoteRef The ref which is known by the remote
 */

/**
 * @callback PrePushCallback
 * @param {PrePushParams} args
 * @returns {boolean | Promise<boolean>} Returns false if push must be cancelled
 */

/**
 * @typedef {Object} PostCheckoutParams
 * @property {string} previousHead The SHA-1 object id of HEAD before checkout
 * @property {string} newHead The SHA-1 object id of HEAD after checkout
 * @property {'branch' | 'file'} type flag determining whether a branch or a set of files was checked
 */

/**
 * @callback PostCheckoutCallback
 * @param {PostCheckoutParams} args
 * @returns {void | Promise<void>}
 */

class BaseError extends Error {
  constructor(message) {
    super(message);
    // Setting this here allows TS to infer that all git errors have a `caller` property and
    // that its type is string.
    this.caller = '';
  }

  toJSON() {
    // Error objects aren't normally serializable. So we do something about that.
    return {
      code: this.code,
      data: this.data,
      caller: this.caller,
      message: this.message,
      stack: this.stack,
    }
  }

  fromJSON(json) {
    const e = new BaseError(json.message);
    e.code = json.code;
    e.data = json.data;
    e.caller = json.caller;
    e.stack = json.stack;
    return e
  }

  get isIsomorphicGitError() {
    return true
  }
}

class UnmergedPathsError extends BaseError {
  /**
   * @param {Array<string>} filepaths
   */
  constructor(filepaths) {
    super(
      `Modifying the index is not possible because you have unmerged files: ${filepaths.toString}. Fix them up in the work tree, and then use 'git add/rm as appropriate to mark resolution and make a commit.`
    );
    this.code = this.name = UnmergedPathsError.code;
    this.data = { filepaths };
  }
}
/** @type {'UnmergedPathsError'} */
UnmergedPathsError.code = 'UnmergedPathsError';

class InternalError extends BaseError {
  /**
   * @param {string} message
   */
  constructor(message) {
    super(
      `An internal error caused this command to fail.\n\nIf you're using an application that depends on isomorphic-git, please report this error to that application's developers.\n\nIf you're a developer and you believe this is a bug in isomorphic-git, please file an issue at https://github.com/isomorphic-git/isomorphic-git/issues with a minimal reproduction, version and environment details, and this error message: ${message}`
    );
    this.code = this.name = InternalError.code;
    this.data = { message };
  }
}
/** @type {'InternalError'} */
InternalError.code = 'InternalError';

class UnsafeFilepathError extends BaseError {
  /**
   * @param {string} filepath
   */
  constructor(filepath) {
    super(`The filepath "${filepath}" contains unsafe character sequences`);
    this.code = this.name = UnsafeFilepathError.code;
    this.data = { filepath };
  }
}
/** @type {'UnsafeFilepathError'} */
UnsafeFilepathError.code = 'UnsafeFilepathError';

// Modeled after https://github.com/tjfontaine/node-buffercursor
// but with the goal of being much lighter weight.
class BufferCursor {
  constructor(buffer) {
    this.buffer = buffer;
    this._start = 0;
  }

  eof() {
    return this._start >= this.buffer.length
  }

  tell() {
    return this._start
  }

  seek(n) {
    this._start = n;
  }

  slice(n) {
    const r = this.buffer.slice(this._start, this._start + n);
    this._start += n;
    return r
  }

  toString(enc, length) {
    const r = this.buffer.toString(enc, this._start, this._start + length);
    this._start += length;
    return r
  }

  write(value, length, enc) {
    const r = this.buffer.write(value, this._start, length, enc);
    this._start += length;
    return r
  }

  copy(source, start, end) {
    const r = source.copy(this.buffer, this._start, start, end);
    this._start += r;
    return r
  }

  readUInt8() {
    const r = this.buffer.readUInt8(this._start);
    this._start += 1;
    return r
  }

  writeUInt8(value) {
    const r = this.buffer.writeUInt8(value, this._start);
    this._start += 1;
    return r
  }

  readUInt16BE() {
    const r = this.buffer.readUInt16BE(this._start);
    this._start += 2;
    return r
  }

  writeUInt16BE(value) {
    const r = this.buffer.writeUInt16BE(value, this._start);
    this._start += 2;
    return r
  }

  readUInt32BE() {
    const r = this.buffer.readUInt32BE(this._start);
    this._start += 4;
    return r
  }

  writeUInt32BE(value) {
    const r = this.buffer.writeUInt32BE(value, this._start);
    this._start += 4;
    return r
  }
}

function compareStrings(a, b) {
  // https://stackoverflow.com/a/40355107/2168416
  return -(a < b) || +(a > b)
}

function comparePath(a, b) {
  // https://stackoverflow.com/a/40355107/2168416
  return compareStrings(a.path, b.path)
}

/**
 * From https://github.com/git/git/blob/master/Documentation/technical/index-format.txt
 *
 * 32-bit mode, split into (high to low bits)
 *
 *  4-bit object type
 *    valid values in binary are 1000 (regular file), 1010 (symbolic link)
 *    and 1110 (gitlink)
 *
 *  3-bit unused
 *
 *  9-bit unix permission. Only 0755 and 0644 are valid for regular files.
 *  Symbolic links and gitlinks have value 0 in this field.
 */
function normalizeMode(mode) {
  // Note: BrowserFS will use -1 for "unknown"
  // I need to make it non-negative for these bitshifts to work.
  let type = mode > 0 ? mode >> 12 : 0;
  // If it isn't valid, assume it as a "regular file"
  // 0100 = directory
  // 1000 = regular file
  // 1010 = symlink
  // 1110 = gitlink
  if (
    type !== 0b0100 &&
    type !== 0b1000 &&
    type !== 0b1010 &&
    type !== 0b1110
  ) {
    type = 0b1000;
  }
  let permissions = mode & 0o777;
  // Is the file executable? then 755. Else 644.
  if (permissions & 0b001001001) {
    permissions = 0o755;
  } else {
    permissions = 0o644;
  }
  // If it's not a regular file, scrub all permissions
  if (type !== 0b1000) permissions = 0;
  return (type << 12) + permissions
}

const MAX_UINT32 = 2 ** 32;

function SecondsNanoseconds(
  givenSeconds,
  givenNanoseconds,
  milliseconds,
  date
) {
  if (givenSeconds !== undefined && givenNanoseconds !== undefined) {
    return [givenSeconds, givenNanoseconds]
  }
  if (milliseconds === undefined) {
    milliseconds = date.valueOf();
  }
  const seconds = Math.floor(milliseconds / 1000);
  const nanoseconds = (milliseconds - seconds * 1000) * 1000000;
  return [seconds, nanoseconds]
}

function normalizeStats(e) {
  const [ctimeSeconds, ctimeNanoseconds] = SecondsNanoseconds(
    e.ctimeSeconds,
    e.ctimeNanoseconds,
    e.ctimeMs,
    e.ctime
  );
  const [mtimeSeconds, mtimeNanoseconds] = SecondsNanoseconds(
    e.mtimeSeconds,
    e.mtimeNanoseconds,
    e.mtimeMs,
    e.mtime
  );

  return {
    ctimeSeconds: ctimeSeconds % MAX_UINT32,
    ctimeNanoseconds: ctimeNanoseconds % MAX_UINT32,
    mtimeSeconds: mtimeSeconds % MAX_UINT32,
    mtimeNanoseconds: mtimeNanoseconds % MAX_UINT32,
    dev: e.dev % MAX_UINT32,
    ino: e.ino % MAX_UINT32,
    mode: normalizeMode(e.mode % MAX_UINT32),
    uid: e.uid % MAX_UINT32,
    gid: e.gid % MAX_UINT32,
    // size of -1 happens over a BrowserFS HTTP Backend that doesn't serve Content-Length headers
    // (like the Karma webserver) because BrowserFS HTTP Backend uses HTTP HEAD requests to do fs.stat
    size: e.size > -1 ? e.size % MAX_UINT32 : 0,
  }
}

function toHex(buffer) {
  let hex = '';
  for (const byte of new Uint8Array(buffer)) {
    if (byte < 16) hex += '0';
    hex += byte.toString(16);
  }
  return hex
}

/* eslint-env node, browser */

let supportsSubtleSHA1 = null;

async function shasum(buffer) {
  if (supportsSubtleSHA1 === null) {
    supportsSubtleSHA1 = await testSubtleSHA1();
  }
  return supportsSubtleSHA1 ? subtleSHA1(buffer) : shasumSync(buffer)
}

// This is modeled after @dominictarr's "shasum" module,
// but without the 'json-stable-stringify' dependency and
// extra type-casting features.
function shasumSync(buffer) {
  return new Hash().update(buffer).digest('hex')
}

async function subtleSHA1(buffer) {
  const hash = await crypto.subtle.digest('SHA-1', buffer);
  return toHex(hash)
}

async function testSubtleSHA1() {
  // I'm using a rather crude method of progressive enhancement, because
  // some browsers that have crypto.subtle.digest don't actually implement SHA-1.
  try {
    const hash = await subtleSHA1(new Uint8Array([]));
    return hash === 'da39a3ee5e6b4b0d3255bfef95601890afd80709'
  } catch (_) {
    // no bother
  }
  return false
}

// Extract 1-bit assume-valid, 1-bit extended flag, 2-bit merge state flag, 12-bit path length flag
function parseCacheEntryFlags(bits) {
  return {
    assumeValid: Boolean(bits & 0b1000000000000000),
    extended: Boolean(bits & 0b0100000000000000),
    stage: (bits & 0b0011000000000000) >> 12,
    nameLength: bits & 0b0000111111111111,
  }
}

function renderCacheEntryFlags(entry) {
  const flags = entry.flags;
  // 1-bit extended flag (must be zero in version 2)
  flags.extended = false;
  // 12-bit name length if the length is less than 0xFFF; otherwise 0xFFF
  // is stored in this field.
  flags.nameLength = Math.min(Buffer.from(entry.path).length, 0xfff);
  return (
    (flags.assumeValid ? 0b1000000000000000 : 0) +
    (flags.extended ? 0b0100000000000000 : 0) +
    ((flags.stage & 0b11) << 12) +
    (flags.nameLength & 0b111111111111)
  )
}

class GitIndex {
  /*::
   _entries: Map<string, CacheEntry>
   _dirty: boolean // Used to determine if index needs to be saved to filesystem
   */
  constructor(entries, unmergedPaths) {
    this._dirty = false;
    this._unmergedPaths = unmergedPaths || new Set();
    this._entries = entries || new Map();
  }

  _addEntry(entry) {
    if (entry.flags.stage === 0) {
      entry.stages = [entry];
      this._entries.set(entry.path, entry);
      this._unmergedPaths.delete(entry.path);
    } else {
      let existingEntry = this._entries.get(entry.path);
      if (!existingEntry) {
        this._entries.set(entry.path, entry);
        existingEntry = entry;
      }
      existingEntry.stages[entry.flags.stage] = entry;
      this._unmergedPaths.add(entry.path);
    }
  }

  static async from(buffer) {
    if (Buffer.isBuffer(buffer)) {
      return GitIndex.fromBuffer(buffer)
    } else if (buffer === null) {
      return new GitIndex(null)
    } else {
      throw new InternalError('invalid type passed to GitIndex.from')
    }
  }

  static async fromBuffer(buffer) {
    if (buffer.length === 0) {
      throw new InternalError('Index file is empty (.git/index)')
    }

    const index = new GitIndex();
    const reader = new BufferCursor(buffer);
    const magic = reader.toString('utf8', 4);
    if (magic !== 'DIRC') {
      throw new InternalError(`Invalid dircache magic file number: ${magic}`)
    }

    // Verify shasum after we ensured that the file has a magic number
    const shaComputed = await shasum(buffer.slice(0, -20));
    const shaClaimed = buffer.slice(-20).toString('hex');
    if (shaClaimed !== shaComputed) {
      throw new InternalError(
        `Invalid checksum in GitIndex buffer: expected ${shaClaimed} but saw ${shaComputed}`
      )
    }

    const version = reader.readUInt32BE();
    if (version !== 2) {
      throw new InternalError(`Unsupported dircache version: ${version}`)
    }
    const numEntries = reader.readUInt32BE();
    let i = 0;
    while (!reader.eof() && i < numEntries) {
      const entry = {};
      entry.ctimeSeconds = reader.readUInt32BE();
      entry.ctimeNanoseconds = reader.readUInt32BE();
      entry.mtimeSeconds = reader.readUInt32BE();
      entry.mtimeNanoseconds = reader.readUInt32BE();
      entry.dev = reader.readUInt32BE();
      entry.ino = reader.readUInt32BE();
      entry.mode = reader.readUInt32BE();
      entry.uid = reader.readUInt32BE();
      entry.gid = reader.readUInt32BE();
      entry.size = reader.readUInt32BE();
      entry.oid = reader.slice(20).toString('hex');
      const flags = reader.readUInt16BE();
      entry.flags = parseCacheEntryFlags(flags);
      // TODO: handle if (version === 3 && entry.flags.extended)
      const pathlength = buffer.indexOf(0, reader.tell() + 1) - reader.tell();
      if (pathlength < 1) {
        throw new InternalError(`Got a path length of: ${pathlength}`)
      }
      // TODO: handle pathnames larger than 12 bits
      entry.path = reader.toString('utf8', pathlength);

      // Prevent malicious paths like "..\foo"
      if (entry.path.includes('..\\') || entry.path.includes('../')) {
        throw new UnsafeFilepathError(entry.path)
      }

      // The next bit is awkward. We expect 1 to 8 null characters
      // such that the total size of the entry is a multiple of 8 bits.
      // (Hence subtract 12 bytes for the header.)
      let padding = 8 - ((reader.tell() - 12) % 8);
      if (padding === 0) padding = 8;
      while (padding--) {
        const tmp = reader.readUInt8();
        if (tmp !== 0) {
          throw new InternalError(
            `Expected 1-8 null characters but got '${tmp}' after ${entry.path}`
          )
        } else if (reader.eof()) {
          throw new InternalError('Unexpected end of file')
        }
      }
      // end of awkward part
      entry.stages = [];

      index._addEntry(entry);

      i++;
    }
    return index
  }

  get unmergedPaths() {
    return [...this._unmergedPaths]
  }

  get entries() {
    return [...this._entries.values()].sort(comparePath)
  }

  get entriesMap() {
    return this._entries
  }

  get entriesFlat() {
    return [...this.entries].flatMap(entry => {
      return entry.stages.length > 1 ? entry.stages.filter(x => x) : entry
    })
  }

  *[Symbol.iterator]() {
    for (const entry of this.entries) {
      yield entry;
    }
  }

  insert({ filepath, stats, oid, stage = 0 }) {
    if (!stats) {
      stats = {
        ctimeSeconds: 0,
        ctimeNanoseconds: 0,
        mtimeSeconds: 0,
        mtimeNanoseconds: 0,
        dev: 0,
        ino: 0,
        mode: 0,
        uid: 0,
        gid: 0,
        size: 0,
      };
    }
    stats = normalizeStats(stats);
    const bfilepath = Buffer.from(filepath);
    const entry = {
      ctimeSeconds: stats.ctimeSeconds,
      ctimeNanoseconds: stats.ctimeNanoseconds,
      mtimeSeconds: stats.mtimeSeconds,
      mtimeNanoseconds: stats.mtimeNanoseconds,
      dev: stats.dev,
      ino: stats.ino,
      // We provide a fallback value for `mode` here because not all fs
      // implementations assign it, but we use it in GitTree.
      // '100644' is for a "regular non-executable file"
      mode: stats.mode || 0o100644,
      uid: stats.uid,
      gid: stats.gid,
      size: stats.size,
      path: filepath,
      oid,
      flags: {
        assumeValid: false,
        extended: false,
        stage,
        nameLength: bfilepath.length < 0xfff ? bfilepath.length : 0xfff,
      },
      stages: [],
    };

    this._addEntry(entry);

    this._dirty = true;
  }

  delete({ filepath }) {
    if (this._entries.has(filepath)) {
      this._entries.delete(filepath);
    } else {
      for (const key of this._entries.keys()) {
        if (key.startsWith(filepath + '/')) {
          this._entries.delete(key);
        }
      }
    }

    if (this._unmergedPaths.has(filepath)) {
      this._unmergedPaths.delete(filepath);
    }
    this._dirty = true;
  }

  clear() {
    this._entries.clear();
    this._dirty = true;
  }

  has({ filepath }) {
    return this._entries.has(filepath)
  }

  render() {
    return this.entries
      .map(entry => `${entry.mode.toString(8)} ${entry.oid}    ${entry.path}`)
      .join('\n')
  }

  static async _entryToBuffer(entry) {
    const bpath = Buffer.from(entry.path);
    // the fixed length + the filename + at least one null char => align by 8
    const length = Math.ceil((62 + bpath.length + 1) / 8) * 8;
    const written = Buffer.alloc(length);
    const writer = new BufferCursor(written);
    const stat = normalizeStats(entry);
    writer.writeUInt32BE(stat.ctimeSeconds);
    writer.writeUInt32BE(stat.ctimeNanoseconds);
    writer.writeUInt32BE(stat.mtimeSeconds);
    writer.writeUInt32BE(stat.mtimeNanoseconds);
    writer.writeUInt32BE(stat.dev);
    writer.writeUInt32BE(stat.ino);
    writer.writeUInt32BE(stat.mode);
    writer.writeUInt32BE(stat.uid);
    writer.writeUInt32BE(stat.gid);
    writer.writeUInt32BE(stat.size);
    writer.write(entry.oid, 20, 'hex');
    writer.writeUInt16BE(renderCacheEntryFlags(entry));
    writer.write(entry.path, bpath.length, 'utf8');
    return written
  }

  async toObject() {
    const header = Buffer.alloc(12);
    const writer = new BufferCursor(header);
    writer.write('DIRC', 4, 'utf8');
    writer.writeUInt32BE(2);
    writer.writeUInt32BE(this.entriesFlat.length);

    let entryBuffers = [];
    for (const entry of this.entries) {
      entryBuffers.push(GitIndex._entryToBuffer(entry));
      if (entry.stages.length > 1) {
        for (const stage of entry.stages) {
          if (stage && stage !== entry) {
            entryBuffers.push(GitIndex._entryToBuffer(stage));
          }
        }
      }
    }
    entryBuffers = await Promise.all(entryBuffers);

    const body = Buffer.concat(entryBuffers);
    const main = Buffer.concat([header, body]);
    const sum = await shasum(main);
    return Buffer.concat([main, Buffer.from(sum, 'hex')])
  }
}

function compareStats(entry, stats, filemode = true, trustino = true) {
  // Comparison based on the description in Paragraph 4 of
  // https://www.kernel.org/pub/software/scm/git/docs/technical/racy-git.txt
  const e = normalizeStats(entry);
  const s = normalizeStats(stats);
  const staleness =
    (filemode && e.mode !== s.mode) ||
    e.mtimeSeconds !== s.mtimeSeconds ||
    e.ctimeSeconds !== s.ctimeSeconds ||
    e.uid !== s.uid ||
    e.gid !== s.gid ||
    (trustino && e.ino !== s.ino) ||
    e.size !== s.size;
  return staleness
}

// A single process-wide lock shared by everything that serializes file
// operations (the index, refs, the shallow file, blob writes). It is keyed by
// path, so unrelated resources never contend. Centralizing it here also means
// there is exactly one place to reset it (see `_resetLock`).
//
// Created lazily (not at module load) so this module has no top-level side
// effect and stays tree-shakeable.
let lock;

function getLock() {
  if (lock === undefined) lock = new AsyncLock({ maxPending: Infinity });
  return lock
}

/**
 * Run `callback` while holding the shared lock for `key`, then release it.
 *
 * @template T
 * @param {string | string[]} key - Resource key(s) to lock (usually a filepath).
 * @param {() => (Promise<T> | T)} callback
 * @returns {Promise<T>}
 */
function acquireLock(key, callback) {
  return getLock().acquire(key, callback)
}

/**
 * Discard the shared lock so the next `acquireLock` starts a fresh one. Intended
 * for test harnesses that run many independent scenarios inside one long-lived
 * module instance: if a scenario leaves an operation stalled (e.g. a filesystem
 * that hangs), its still-held lock would otherwise block every later scenario
 * that touches the same path. Resetting abandons that stalled queue so the next
 * scenario starts clean. It is a no-op for normal library use.
 */
function _resetLock() {
  lock = undefined;
}

const IndexCache = Symbol('IndexCache');

/**
 * Creates a cache object to store GitIndex and file stats.
 * @returns {object} A cache object with `map` and `stats` properties.
 */
function createCache() {
  return {
    map: new Map(),
    stats: new Map(),
  }
}

/**
 * Updates the cached index file by reading the file system and parsing the Git index.
 * @param {FSClient} fs - A file system implementation.
 * @param {string} filepath - The path to the Git index file.
 * @param {object} cache - The cache object to update.
 * @returns {Promise<void>}
 */
async function updateCachedIndexFile(fs, filepath, cache) {
  const [stat, rawIndexFile] = await Promise.all([
    fs.lstat(filepath),
    fs.read(filepath),
  ]);

  const index = await GitIndex.from(rawIndexFile);
  // cache the GitIndex object so we don't need to re-read it every time.
  cache.map.set(filepath, index);
  // Save the stat data for the index so we know whether the cached file is stale (modified by an outside process).
  cache.stats.set(filepath, stat);
}

/**
 * Determines whether the cached index file is stale by comparing file stats.
 * @param {FSClient} fs - A file system implementation.
 * @param {string} filepath - The path to the Git index file.
 * @param {object} cache - The cache object containing file stats.
 * @returns {Promise<boolean>} `true` if the index file is stale, otherwise `false`.
 */
async function isIndexStale(fs, filepath, cache) {
  const savedStats = cache.stats.get(filepath);
  if (savedStats === undefined) return true
  if (savedStats === null) return false

  const currStats = await fs.lstat(filepath);
  if (currStats === null) return false
  return compareStats(savedStats, currStats)
}

class GitIndexManager {
  /**
   * Manages access to the Git index file, ensuring thread-safe operations and caching.
   *
   * @param {object} opts - Options for acquiring the Git index.
   * @param {FSClient} opts.fs - A file system implementation.
   * @param {string} opts.gitdir - The path to the `.git` directory.
   * @param {object} opts.cache - A shared cache object for storing index data.
   * @param {boolean} [opts.allowUnmerged=true] - Whether to allow unmerged paths in the index.
   * @param {function(GitIndex): any} closure - A function to execute with the Git index.
   * @returns {Promise<any>} The result of the closure function.
   * @throws {UnmergedPathsError} If unmerged paths exist and `allowUnmerged` is `false`.
   */
  static async acquire({ fs, gitdir, cache, allowUnmerged = true }, closure) {
    if (!cache[IndexCache]) {
      cache[IndexCache] = createCache();
    }

    const filepath = `${gitdir}/index`;
    let result;
    let unmergedPaths = [];
    await acquireLock(filepath, async () => {
      // Acquire a file lock while we're reading the index
      // to make sure other processes aren't writing to it
      // simultaneously, which could result in a corrupted index.
      // const fileLock = await Lock(filepath)
      const theIndexCache = cache[IndexCache];
      if (await isIndexStale(fs, filepath, theIndexCache)) {
        await updateCachedIndexFile(fs, filepath, theIndexCache);
      }
      const index = theIndexCache.map.get(filepath);
      unmergedPaths = index.unmergedPaths;

      if (unmergedPaths.length && !allowUnmerged)
        throw new UnmergedPathsError(unmergedPaths)

      result = await closure(index);
      if (index._dirty) {
        // Acquire a file lock while we're writing the index file
        // let fileLock = await Lock(filepath)
        const buffer = await index.toObject();
        await fs.write(filepath, buffer);
        // Update cached stat value
        theIndexCache.stats.set(filepath, await fs.lstat(filepath));
        index._dirty = false;
      }
    });

    return result
  }
}

function basename(path) {
  const last = Math.max(path.lastIndexOf('/'), path.lastIndexOf('\\'));
  if (last > -1) {
    path = path.slice(last + 1);
  }
  return path
}

function dirname(path) {
  const last = Math.max(path.lastIndexOf('/'), path.lastIndexOf('\\'));
  if (last === -1) return '.'
  if (last === 0) return '/'
  return path.slice(0, last)
}

/*::
type Node = {
  type: string,
  fullpath: string,
  basename: string,
  metadata: Object, // mode, oid
  parent?: Node,
  children: Array<Node>
}
*/

function flatFileListToDirectoryStructure(files) {
  const inodes = new Map();
  const mkdir = function (name) {
    if (!inodes.has(name)) {
      const dir = {
        type: 'tree',
        fullpath: name,
        basename: basename(name),
        metadata: {},
        children: [],
      };
      inodes.set(name, dir);
      // This recursively generates any missing parent folders.
      // We do it after we've added the inode to the set so that
      // we don't recurse infinitely trying to create the root '.' dirname.
      dir.parent = mkdir(dirname(name));
      if (dir.parent && dir.parent !== dir) dir.parent.children.push(dir);
    }
    return inodes.get(name)
  };

  const mkfile = function (name, metadata) {
    if (!inodes.has(name)) {
      const file = {
        type: 'blob',
        fullpath: name,
        basename: basename(name),
        metadata,
        // This recursively generates any missing parent folders.
        parent: mkdir(dirname(name)),
        children: [],
      };
      if (file.parent) file.parent.children.push(file);
      inodes.set(name, file);
    }
    return inodes.get(name)
  };

  mkdir('.');
  for (const file of files) {
    mkfile(file.path, file);
  }
  return inodes
}

/**
 *
 * @param {number} mode
 */
function mode2type(mode) {
  // prettier-ignore
  switch (mode) {
    case 0o040000: return 'tree'
    case 0o100644: return 'blob'
    case 0o100755: return 'blob'
    case 0o120000: return 'blob'
    case 0o160000: return 'commit'
  }
  throw new InternalError(`Unexpected GitTree entry mode: ${mode.toString(8)}`)
}

class GitWalkerIndex {
  constructor({ fs, gitdir, cache }) {
    this.treePromise = GitIndexManager.acquire(
      { fs, gitdir, cache },
      async function (index) {
        return flatFileListToDirectoryStructure(index.entries)
      }
    );
    const walker = this;
    this.ConstructEntry = class StageEntry {
      constructor(fullpath) {
        this._fullpath = fullpath;
        this._type = false;
        this._mode = false;
        this._stat = false;
        this._oid = false;
      }

      async type() {
        return walker.type(this)
      }

      async mode() {
        return walker.mode(this)
      }

      async stat() {
        return walker.stat(this)
      }

      async content() {
        return walker.content(this)
      }

      async oid() {
        return walker.oid(this)
      }
    };
  }

  async readdir(entry) {
    const filepath = entry._fullpath;
    const tree = await this.treePromise;
    const inode = tree.get(filepath);
    if (!inode) return null
    if (inode.type === 'blob') return null
    if (inode.type !== 'tree') {
      throw new Error(`ENOTDIR: not a directory, scandir '${filepath}'`)
    }
    const names = inode.children.map(inode => inode.fullpath);
    names.sort(compareStrings);
    return names
  }

  async type(entry) {
    if (entry._type === false) {
      await entry.stat();
    }
    return entry._type
  }

  async mode(entry) {
    if (entry._mode === false) {
      await entry.stat();
    }
    return entry._mode
  }

  async stat(entry) {
    if (entry._stat === false) {
      const tree = await this.treePromise;
      const inode = tree.get(entry._fullpath);
      if (!inode) {
        throw new Error(
          `ENOENT: no such file or directory, lstat '${entry._fullpath}'`
        )
      }
      const stats = inode.type === 'tree' ? {} : normalizeStats(inode.metadata);
      entry._type = inode.type === 'tree' ? 'tree' : mode2type(stats.mode);
      entry._mode = stats.mode;
      if (inode.type === 'tree') {
        entry._stat = undefined;
      } else {
        entry._stat = stats;
      }
    }
    return entry._stat
  }

  async content(_entry) {
    // Cannot get content for an index entry
  }

  async oid(entry) {
    if (entry._oid === false) {
      const tree = await this.treePromise;
      const inode = tree.get(entry._fullpath);
      entry._oid = inode.metadata.oid;
    }
    return entry._oid
  }
}

// This is part of an elaborate system to facilitate code-splitting / tree-shaking.
// commands/walk.js can depend on only this, and the actual Walker classes exported
// can be opaque - only having a single property (this symbol) that is not enumerable,
// and thus the constructor can be passed as an argument to walk while being "unusable"
// outside of it.
const GitWalkSymbol = Symbol('GitWalkSymbol');

// @ts-check

/**
 * @returns {Walker}
 */
function STAGE() {
  const o = Object.create(null);
  Object.defineProperty(o, GitWalkSymbol, {
    value: function ({ fs, gitdir, cache }) {
      return new GitWalkerIndex({ fs, gitdir, cache })
    },
  });
  Object.freeze(o);
  return o
}

// @ts-check

class NotFoundError extends BaseError {
  /**
   * @param {string} what
   */
  constructor(what) {
    super(`Could not find ${what}.`);
    this.code = this.name = NotFoundError.code;
    this.data = { what };
  }
}
/** @type {'NotFoundError'} */
NotFoundError.code = 'NotFoundError';

class ObjectTypeError extends BaseError {
  /**
   * @param {string} oid
   * @param {'blob'|'commit'|'tag'|'tree'} actual
   * @param {'blob'|'commit'|'tag'|'tree'} expected
   * @param {string} [filepath]
   */
  constructor(oid, actual, expected, filepath) {
    super(
      `Object ${oid} ${
        filepath ? `at ${filepath}` : ''
      }was anticipated to be a ${expected} but it is a ${actual}.`
    );
    this.code = this.name = ObjectTypeError.code;
    this.data = { oid, actual, expected, filepath };
  }
}
/** @type {'ObjectTypeError'} */
ObjectTypeError.code = 'ObjectTypeError';

class InvalidOidError extends BaseError {
  /**
   * @param {string} value
   */
  constructor(value) {
    super(`Expected a 40-char hex object id but saw "${value}".`);
    this.code = this.name = InvalidOidError.code;
    this.data = { value };
  }
}
/** @type {'InvalidOidError'} */
InvalidOidError.code = 'InvalidOidError';

class InvalidRefNameError extends BaseError {
  /**
   * @param {string} ref
   * @param {string} suggestion
   * @param {boolean} canForce
   */
  constructor(ref, suggestion) {
    super(
      `"${ref}" would be an invalid git reference. (Hint: a valid alternative would be "${suggestion}".)`
    );
    this.code = this.name = InvalidRefNameError.code;
    this.data = { ref, suggestion };
  }
}
/** @type {'InvalidRefNameError'} */
InvalidRefNameError.code = 'InvalidRefNameError';

class NoRefspecError extends BaseError {
  /**
   * @param {string} remote
   */
  constructor(remote) {
    super(`Could not find a fetch refspec for remote "${remote}". Make sure the config file has an entry like the following:
[remote "${remote}"]
\tfetch = +refs/heads/*:refs/remotes/origin/*
`);
    this.code = this.name = NoRefspecError.code;
    this.data = { remote };
  }
}
/** @type {'NoRefspecError'} */
NoRefspecError.code = 'NoRefspecError';

class GitPackedRefs {
  constructor(text) {
    this.refs = new Map();
    this.parsedConfig = [];
    if (text) {
      let key = null;
      this.parsedConfig = text
        .trim()
        .split('\n')
        .map(line => {
          if (/^\s*#/.test(line)) {
            return { line, comment: true }
          }
          const i = line.indexOf(' ');
          if (line.startsWith('^')) {
            // This is a oid for the commit associated with the annotated tag immediately preceding this line.
            // Trim off the '^'
            const value = line.slice(1);
            // The tagname^{} syntax is based on the output of `git show-ref --tags -d`
            this.refs.set(key + '^{}', value);
            return { line, ref: key, peeled: value }
          } else {
            // This is an oid followed by the ref name
            const value = line.slice(0, i);
            key = line.slice(i + 1);
            this.refs.set(key, value);
            return { line, ref: key, oid: value }
          }
        });
    }
    return this
  }

  static from(text) {
    return new GitPackedRefs(text)
  }

  delete(ref) {
    this.parsedConfig = this.parsedConfig.filter(entry => entry.ref !== ref);
    this.refs.delete(ref);
  }

  toString() {
    return this.parsedConfig.map(({ line }) => line).join('\n') + '\n'
  }
}

class GitRefSpec {
  constructor({ remotePath, localPath, force, matchPrefix }) {
    Object.assign(this, {
      remotePath,
      localPath,
      force,
      matchPrefix,
    });
  }

  static from(refspec) {
    const [forceMatch, remotePath, remoteGlobMatch, localPath, localGlobMatch] =
      refspec.match(/^(\+?)(.*?)(\*?):(.*?)(\*?)$/).slice(1);
    const force = forceMatch === '+';
    const remoteIsGlob = remoteGlobMatch === '*';
    const localIsGlob = localGlobMatch === '*';
    // validate
    // TODO: Make this check more nuanced, and depend on whether this is a fetch refspec or a push refspec
    if (remoteIsGlob !== localIsGlob) {
      throw new InternalError('Invalid refspec')
    }
    return new GitRefSpec({
      remotePath,
      localPath,
      force,
      matchPrefix: remoteIsGlob,
    })
    // TODO: We need to run resolveRef on both paths to expand them to their full name.
  }

  translate(remoteBranch) {
    if (this.matchPrefix) {
      if (remoteBranch.startsWith(this.remotePath)) {
        return this.localPath + remoteBranch.replace(this.remotePath, '')
      }
    } else {
      if (remoteBranch === this.remotePath) return this.localPath
    }
    return null
  }

  reverseTranslate(localBranch) {
    if (this.matchPrefix) {
      if (localBranch.startsWith(this.localPath)) {
        return this.remotePath + localBranch.replace(this.localPath, '')
      }
    } else {
      if (localBranch === this.localPath) return this.remotePath
    }
    return null
  }
}

class GitRefSpecSet {
  constructor(rules = []) {
    this.rules = rules;
  }

  static from(refspecs) {
    const rules = [];
    for (const refspec of refspecs) {
      rules.push(GitRefSpec.from(refspec)); // might throw
    }
    return new GitRefSpecSet(rules)
  }

  add(refspec) {
    const rule = GitRefSpec.from(refspec); // might throw
    this.rules.push(rule);
  }

  translate(remoteRefs) {
    const result = [];
    for (const rule of this.rules) {
      for (const remoteRef of remoteRefs) {
        const localRef = rule.translate(remoteRef);
        if (localRef) {
          result.push([remoteRef, localRef]);
        }
      }
    }
    return result
  }

  translateOne(remoteRef) {
    let result = null;
    for (const rule of this.rules) {
      const localRef = rule.translate(remoteRef);
      if (localRef) {
        result = localRef;
      }
    }
    return result
  }

  localNamespaces() {
    return this.rules
      .filter(rule => rule.matchPrefix)
      .map(rule => rule.localPath.replace(/\/$/, ''))
  }
}

function compareRefNames(a, b) {
  // https://stackoverflow.com/a/40355107/2168416
  const _a = a.replace(/\^\{\}$/, '');
  const _b = b.replace(/\^\{\}$/, '');
  const tmp = -(_a < _b) || +(_a > _b);
  if (tmp === 0) {
    return a.endsWith('^{}') ? 1 : -1
  }
  return tmp
}

/*
Adapted from is-git-ref-name-valid
SPDX-License-Identifier: MIT
Copyright © Vincent Weevers
*/

// eslint-disable-next-line no-control-regex
const bad = /(^|[/.])([/.]|$)|^@$|@{|[\x00-\x20\x7f~^:?*[\\]|\.lock(\/|$)/;

function isValidRef(name, onelevel) {
  if (typeof name !== 'string')
    throw new TypeError('Reference name must be a string')

  return !bad.test(name) && (!!onelevel || name.includes('/'))
}

/*!
 * This code for `path.join` is directly copied from @zenfs/core/path for bundle size improvements.
 * SPDX-License-Identifier: LGPL-3.0-or-later
 * Copyright (c) James Prevett and other ZenFS contributors.
 *
 * Windows support added:
 *   - Backslashes are normalised to forward slashes before processing.
 *   - Drive-letter prefixes (e.g. "C:") are detected and preserved through
 *     normalisation, so absolute Windows paths are handled correctly.
 *   - An absolute argument passed to join() resets the accumulated path,
 *     matching Node behaviour and handling worktree gitdir paths properly.
 *
 * Limitation: UNC paths (e.g. \\server\share) are not supported. The leading
 *   backslashes are normalised to forward slashes and then collapsed by
 *   normalizeString, losing the UNC root. Git on Windows works with
 *   drive-letter paths, so this is not expected to be a practical issue.
 */

function normalizeString(path, aar) {
  let res = '';
  let lastSegmentLength = 0;
  let lastSlash = -1;
  let dots = 0;
  let char = '\x00';
  for (let i = 0; i <= path.length; ++i) {
    if (i < path.length) char = path[i];
    else if (char === '/') break
    else char = '/';

    if (char === '/') {
      if (lastSlash === i - 1 || dots === 1) {
        // NOOP
      } else if (dots === 2) {
        if (
          res.length < 2 ||
          lastSegmentLength !== 2 ||
          res.at(-1) !== '.' ||
          res.at(-2) !== '.'
        ) {
          if (res.length > 2) {
            const lastSlashIndex = res.lastIndexOf('/');
            if (lastSlashIndex === -1) {
              res = '';
              lastSegmentLength = 0;
            } else {
              res = res.slice(0, lastSlashIndex);
              lastSegmentLength = res.length - 1 - res.lastIndexOf('/');
            }
            lastSlash = i;
            dots = 0;
            continue
          } else if (res.length !== 0) {
            res = '';
            lastSegmentLength = 0;
            lastSlash = i;
            dots = 0;
            continue
          }
        }
        if (aar) {
          res += res.length > 0 ? '/..' : '..';
          lastSegmentLength = 2;
        }
      } else {
        if (res.length > 0) res += '/' + path.slice(lastSlash + 1, i);
        else res = path.slice(lastSlash + 1, i);
        lastSegmentLength = i - lastSlash - 1;
      }
      lastSlash = i;
      dots = 0;
    } else if (char === '.' && dots !== -1) {
      ++dots;
    } else {
      dots = -1;
    }
  }
  return res
}

// Returns the Windows drive prefix ("C:") if present, otherwise null.
function getWindowsDrivePrefix(path) {
  if (path.length >= 2 && /^[a-zA-Z]:/.test(path)) {
    return path.slice(0, 2) // e.g. "C:"
  }
  return null
}

function normalize(path) {
  if (!path.length) return '.'

  // Normalise backslashes to forward slashes before any other processing.
  path = path.replace(/\\/g, '/');

  const drivePrefix = getWindowsDrivePrefix(path);
  // isAbsolute: Unix root ('/foo') OR Windows drive+slash ('C:/foo').
  const isAbsolute =
    path[0] === '/' || (drivePrefix !== null && path[2] === '/');
  const trailingSeparator = path.at(-1) === '/';

  // Strip the drive prefix before feeding into normalizeString so that the
  // core algorithm only ever sees a plain POSIX-style string.
  const pathBody = drivePrefix ? path.slice(2) : path;

  let normalized = normalizeString(pathBody, !isAbsolute);

  if (!normalized.length) {
    const root = drivePrefix
      ? isAbsolute
        ? drivePrefix + '/'
        : drivePrefix
      : isAbsolute
        ? '/'
        : '.';
    return trailingSeparator && !isAbsolute ? root + '/' : root
  }
  if (trailingSeparator) normalized += '/';

  if (drivePrefix) {
    return isAbsolute
      ? `${drivePrefix}/${normalized}`
      : `${drivePrefix}${normalized}`
  }
  return isAbsolute ? `/${normalized}` : normalized
}

function join(...args) {
  if (args.length === 0) return '.'
  let joined;
  for (let i = 0; i < args.length; ++i) {
    // Normalise separators before processing.
    const arg = args[i].replace(/\\/g, '/');
    if (arg.length === 0) continue

    // A Windows drive-letter path (e.g. "C:/worktrees/foo") cannot be
    // meaningfully appended to any base, so it resets the accumulator.
    // Unix absolute paths (leading '/') are NOT reset here — that would be
    // path.resolve() semantics; path.join('foo', '/bar') must yield 'foo/bar'.
    if (/^[a-zA-Z]:\//.test(arg)) {
      joined = arg;
    } else {
      if (joined === undefined) joined = arg;
      else joined += '/' + arg;
    }
  }
  if (joined === undefined) return '.'
  return normalize(joined)
}

// This is straight from parse_unit_factor in config.c of canonical git
const num = val => {
  if (typeof val === 'number') {
    return val
  }

  val = val.toLowerCase();
  let n = parseInt(val);
  if (val.endsWith('k')) n *= 1024;
  if (val.endsWith('m')) n *= 1024 * 1024;
  if (val.endsWith('g')) n *= 1024 * 1024 * 1024;
  return n
};

// This is straight from git_parse_maybe_bool_text in config.c of canonical git
const bool = val => {
  if (typeof val === 'boolean') {
    return val
  }

  val = val.trim().toLowerCase();
  if (val === 'true' || val === 'yes' || val === 'on') return true
  if (val === 'false' || val === 'no' || val === 'off') return false
  throw Error(
    `Expected 'true', 'false', 'yes', 'no', 'on', or 'off', but got ${val}`
  )
};

const schema = {
  core: {
    filemode: bool,
    bare: bool,
    logallrefupdates: bool,
    symlinks: bool,
    ignorecase: bool,
    bigFileThreshold: num,
  },
};

// https://git-scm.com/docs/git-config#_syntax

// section starts with [ and ends with ]
// section is alphanumeric (ASCII) with - and .
// section is case insensitive
// subsection is optional
// subsection is specified after section and one or more spaces
// subsection is specified between double quotes
const SECTION_LINE_REGEX = /^\[([A-Za-z0-9-.]+)(?: "(.*)")?\]$/;
const SECTION_REGEX = /^[A-Za-z0-9-.]+$/;

// variable lines contain a name, and equal sign and then a value
// variable lines can also only contain a name (the implicit value is a boolean true)
// variable name is alphanumeric (ASCII) with -
// variable name starts with an alphabetic character
// variable name is case insensitive
const VARIABLE_LINE_REGEX = /^([A-Za-z][A-Za-z-]*)(?: *= *(.*))?$/;
const VARIABLE_NAME_REGEX = /^[A-Za-z][A-Za-z-]*$/;

// Comments start with either # or ; and extend to the end of line
const VARIABLE_VALUE_COMMENT_REGEX = /^(.*?)( *[#;].*)$/;

const extractSectionLine = line => {
  const matches = SECTION_LINE_REGEX.exec(line);
  if (matches != null) {
    const [section, subsection] = matches.slice(1);
    return [section, subsection]
  }
  return null
};

const extractVariableLine = line => {
  const matches = VARIABLE_LINE_REGEX.exec(line);
  if (matches != null) {
    const [name, rawValue = 'true'] = matches.slice(1);
    const valueWithoutComments = removeComments(rawValue);
    const valueWithoutQuotes = removeQuotes(valueWithoutComments);
    return [name, valueWithoutQuotes]
  }
  return null
};

const removeComments = rawValue => {
  const commentMatches = VARIABLE_VALUE_COMMENT_REGEX.exec(rawValue);
  if (commentMatches == null) {
    return rawValue
  }
  const [valueWithoutComment, comment] = commentMatches.slice(1);
  // if odd number of quotes before and after comment => comment is escaped
  if (
    hasOddNumberOfQuotes(valueWithoutComment) &&
    hasOddNumberOfQuotes(comment)
  ) {
    return `${valueWithoutComment}${comment}`
  }
  return valueWithoutComment
};

const hasOddNumberOfQuotes = text => {
  const numberOfQuotes = (text.match(/(?:^|[^\\])"/g) || []).length;
  return numberOfQuotes % 2 !== 0
};

const removeQuotes = text => {
  return text.split('').reduce((newText, c, idx, text) => {
    const isQuote = c === '"' && text[idx - 1] !== '\\';
    const isEscapeForQuote = c === '\\' && text[idx + 1] === '"';
    if (isQuote || isEscapeForQuote) {
      return newText
    }
    return newText + c
  }, '')
};

const lower = text => {
  return text != null ? text.toLowerCase() : null
};

const getPath = (section, subsection, name) => {
  return [lower(section), subsection, lower(name)]
    .filter(a => a != null)
    .join('.')
};

const normalizePath = path => {
  const pathSegments = path.split('.');
  const section = pathSegments.shift();
  const name = pathSegments.pop();
  const subsection = pathSegments.length ? pathSegments.join('.') : undefined;

  return {
    section,
    subsection,
    name,
    path: getPath(section, subsection, name),
    sectionPath: getPath(section, subsection, null),
    isSection: !!section,
  }
};

const findLastIndex = (array, callback) => {
  return array.reduce((lastIndex, item, index) => {
    return callback(item) ? index : lastIndex
  }, -1)
};

// Note: there are a LOT of edge cases that aren't covered (e.g. keys in sections that also
// have subsections, [include] directives, etc.
class GitConfig {
  constructor(text) {
    let section = null;
    let subsection = null;
    this.parsedConfig = text
      ? text.split('\n').map(line => {
          let name = null;
          let value = null;

          const trimmedLine = line.trim();
          const extractedSection = extractSectionLine(trimmedLine);
          const isSection = extractedSection != null;
          if (isSection) {
            ;[section, subsection] = extractedSection;
          } else {
            const extractedVariable = extractVariableLine(trimmedLine);
            const isVariable = extractedVariable != null;
            if (isVariable) {
              ;[name, value] = extractedVariable;
            }
          }

          const path = getPath(section, subsection, name);
          return { line, isSection, section, subsection, name, value, path }
        })
      : [];
  }

  static from(text) {
    return new GitConfig(text)
  }

  async get(path, getall = false) {
    const normalizedPath = normalizePath(path).path;
    const allValues = this.parsedConfig
      .filter(config => config.path === normalizedPath)
      .map(({ section, name, value }) => {
        const fn = schema[section] && schema[section][name];
        return fn ? fn(value) : value
      });
    return getall ? allValues : allValues.pop()
  }

  async getall(path) {
    return this.get(path, true)
  }

  async getSubsections(section) {
    return this.parsedConfig
      .filter(config => config.isSection && config.section === section)
      .map(config => config.subsection)
  }

  async deleteSection(section, subsection) {
    this.parsedConfig = this.parsedConfig.filter(
      config =>
        !(config.section === section && config.subsection === subsection)
    );
  }

  async append(path, value) {
    return this.set(path, value, true)
  }

  async set(path, value, append = false) {
    const {
      section,
      subsection,
      name,
      path: normalizedPath,
      sectionPath,
      isSection,
    } = normalizePath(path);

    const configIndex = findLastIndex(
      this.parsedConfig,
      config => config.path === normalizedPath
    );
    if (value == null) {
      if (configIndex !== -1) {
        this.parsedConfig.splice(configIndex, 1);
      }
    } else {
      if (configIndex !== -1) {
        const config = this.parsedConfig[configIndex];
        // Name should be overwritten in case the casing changed
        const modifiedConfig = Object.assign({}, config, {
          name,
          value,
          modified: true,
        });
        if (append) {
          this.parsedConfig.splice(configIndex + 1, 0, modifiedConfig);
        } else {
          this.parsedConfig[configIndex] = modifiedConfig;
        }
      } else {
        const sectionIndex = this.parsedConfig.findIndex(
          config => config.path === sectionPath
        );
        const newConfig = {
          section,
          subsection,
          name,
          value,
          modified: true,
          path: normalizedPath,
        };
        if (SECTION_REGEX.test(section) && VARIABLE_NAME_REGEX.test(name)) {
          if (sectionIndex >= 0) {
            // Reuse existing section
            this.parsedConfig.splice(sectionIndex + 1, 0, newConfig);
          } else {
            // Add a new section
            const newSection = {
              isSection,
              section,
              subsection,
              modified: true,
              path: sectionPath,
            };
            this.parsedConfig.push(newSection, newConfig);
          }
        }
      }
    }
  }

  toString() {
    return this.parsedConfig
      .map(({ line, section, subsection, name, value, modified = false }) => {
        if (!modified) {
          return line
        }
        if (name != null && value != null) {
          if (typeof value === 'string' && /[#;]/.test(value)) {
            // A `#` or `;` symbol denotes a comment, so we have to wrap it in double quotes
            return `\t${name} = "${value}"`
          }
          return `\t${name} = ${value}`
        }
        if (subsection != null) {
          return `[${section} "${subsection}"]`
        }
        return `[${section}]`
      })
      .join('\n')
  }
}

/**
 * Manages access to the Git configuration file, providing methods to read and save configurations.
 */
class GitConfigManager {
  /**
   * Reads the Git configuration file from the specified `.git` directory.
   *
   * @param {object} opts - Options for reading the Git configuration.
   * @param {FSClient} opts.fs - A file system implementation.
   * @param {string} opts.gitdir - The path to the `.git` directory.
   * @returns {Promise<GitConfig>} A `GitConfig` object representing the parsed configuration.
   */
  static async get({ fs, gitdir }) {
    // We can improve efficiency later if needed.
    // TODO: read from full list of git config files
    const text = await fs.read(`${gitdir}/config`, { encoding: 'utf8' });
    return GitConfig.from(text)
  }

  /**
   * Saves the provided Git configuration to the specified `.git` directory.
   *
   * @param {object} opts - Options for saving the Git configuration.
   * @param {FSClient} opts.fs - A file system implementation.
   * @param {string} opts.gitdir - The path to the `.git` directory.
   * @param {GitConfig} opts.config - The `GitConfig` object to save.
   * @returns {Promise<void>} Resolves when the configuration has been successfully saved.
   */
  static async save({ fs, gitdir, config }) {
    // We can improve efficiency later if needed.
    // TODO: handle saving to the correct global/user/repo location
    await fs.write(`${gitdir}/config`, config.toString(), {
      encoding: 'utf8',
    });
  }
}

// @see https://git-scm.com/docs/git-rev-parse.html#_specifying_revisions
const refpaths = ref => [
  `${ref}`,
  `refs/${ref}`,
  `refs/tags/${ref}`,
  `refs/heads/${ref}`,
  `refs/remotes/${ref}`,
  `refs/remotes/${ref}/HEAD`,
];

// @see https://git-scm.com/docs/gitrepository-layout
const GIT_FILES = ['config', 'description', 'index', 'shallow', 'commondir'];

// These names are legal one-level ref names, so nothing upstream of here
// rejects them, and writing to one lands on the repository file itself.
// Canonical git refuses too: `git update-ref index <oid>` fails with
// "cannot lock ref 'index': reference broken" and leaves the file alone.
function assertWritableRef(ref) {
  if (GIT_FILES.includes(ref)) {
    throw new InvalidRefNameError(ref, `refs/heads/${ref}`)
  }
  // A ref name is joined onto gitdir with `join()`, which collapses `..`
  // exactly like `path.join`. A server-supplied ref/tag name or the wildcard
  // capture of a refspec can therefore climb out of gitdir, or anywhere
  // beneath it, entirely unvalidated up to this point. See GHSA-h3c3-jh3g-8hcc.
  if (!isValidRef(ref, true)) {
    throw new InvalidRefNameError(ref, cleanGitRef.clean(ref))
  }
}

/**
 * A class for managing Git references, including reading, writing, deleting, and resolving refs.
 */
class GitRefManager {
  /**
   * Updates remote refs based on the provided refspecs and options.
   *
   * @param {Object} args
   * @param {FSClient} args.fs - A file system implementation.
   * @param {string} [args.gitdir=join(dir, '.git')] - [required] The [git directory](dir-vs-gitdir.md) path
   * @param {string} args.remote - The name of the remote.
   * @param {Map<string, string>} args.refs - A map of refs to their object IDs.
   * @param {Map<string, string>} args.symrefs - A map of symbolic refs.
   * @param {boolean} args.tags - Whether to fetch tags.
   * @param {string[]} [args.refspecs = undefined] - The refspecs to use.
   * @param {boolean} [args.prune = false] - Whether to prune stale refs.
   * @param {boolean} [args.pruneTags = false] - Whether to prune tags.
   * @returns {Promise<Object>} - An object containing pruned refs.
   */
  static async updateRemoteRefs({
    fs,
    gitdir,
    remote,
    refs,
    symrefs,
    tags,
    refspecs = undefined,
    prune = false,
    pruneTags = false,
  }) {
    // Validate input
    for (const value of refs.values()) {
      if (!value.match(/[0-9a-f]{40}/)) {
        throw new InvalidOidError(value)
      }
    }
    const config = await GitConfigManager.get({ fs, gitdir });
    if (!refspecs) {
      refspecs = await config.getall(`remote.${remote}.fetch`);
      if (refspecs.length === 0) {
        throw new NoRefspecError(remote)
      }
      // There's some interesting behavior with HEAD that doesn't follow the refspec.
      refspecs.unshift(`+HEAD:refs/remotes/${remote}/HEAD`);
    }
    const refspec = GitRefSpecSet.from(refspecs);
    const actualRefsToWrite = new Map();
    // Work out every destination this call will write, before touching the
    // repository. Translating is pure, so it can happen up here; the writes
    // themselves stay at the end of the function.
    const refTranslations = refspec.translate([...refs.keys()]);
    const symrefTranslations = [];
    for (const [serverRef, translatedRef] of refspec.translate([
      ...symrefs.keys(),
    ])) {
      const symtarget = refspec.translateOne(symrefs.get(serverRef));
      if (symtarget) {
        // The destination (translatedRef) is validated below, but the target
        // a symref points at is server-supplied too (the wire parser accepts
        // `symref=HEAD:(.*)` unrestricted) and only ever passed through the
        // refspec's plain string substitution, never checked. Left alone, a
        // `..`-laden target is written into the file content as-is and later
        // drives an out-of-gitdir read the next time something resolves it.
        // See GHSA-h3c3-jh3g-8hcc.
        assertWritableRef(symtarget);
        symrefTranslations.push([translatedRef, `ref: ${symtarget}`]);
      }
    }
    // Tags aren't translated by a refspec, but they are still a server-supplied
    // name written straight to gitdir below, so they need the same check.
    // Computed here (pure, no I/O) so it can be validated up front and then
    // reused unchanged in the write step further down.
    const tagRefsToWrite = tags
      ? [...refs.keys()].filter(
          serverRef =>
            serverRef.startsWith('refs/tags') && !serverRef.endsWith('^{}')
        )
      : [];
    // The local side of a refspec is whatever `remote.<name>.fetch` says, so a
    // config like `+refs/heads/main:index` lands a write on `.git/index`.
    // Refuse it here rather than at the write loop: `pruneTags` and `prune`
    // delete refs in between, so a later throw leaves the repository pruned
    // and not updated.
    for (const [, translatedRef] of refTranslations) {
      assertWritableRef(translatedRef);
    }
    for (const [translatedRef] of symrefTranslations) {
      assertWritableRef(translatedRef);
    }
    tagRefsToWrite.forEach(assertWritableRef);
    // Delete all current tags if the pruneTags argument is true.
    if (pruneTags) {
      const tags = await GitRefManager.listRefs({
        fs,
        gitdir,
        filepath: 'refs/tags',
      });
      await GitRefManager.deleteRefs({
        fs,
        gitdir,
        refs: tags.map(tag => `refs/tags/${tag}`),
      });
    }
    // Add all tags if the fetch tags argument is true.
    for (const serverRef of tagRefsToWrite) {
      // Git's behavior is to only fetch tags that do not conflict with tags already present.
      if (!(await GitRefManager.exists({ fs, gitdir, ref: serverRef }))) {
        // Always use the object id of the tag itself, and not the peeled object id.
        const oid = refs.get(serverRef);
        actualRefsToWrite.set(serverRef, oid);
      }
    }
    // Combine refs and symrefs giving symrefs priority
    for (const [serverRef, translatedRef] of refTranslations) {
      const value = refs.get(serverRef);
      actualRefsToWrite.set(translatedRef, value);
    }
    for (const [translatedRef, value] of symrefTranslations) {
      actualRefsToWrite.set(translatedRef, value);
    }
    // If `prune` argument is true, clear out the existing local refspec roots
    const pruned = [];
    if (prune) {
      for (const filepath of refspec.localNamespaces()) {
        const refs = (
          await GitRefManager.listRefs({
            fs,
            gitdir,
            filepath,
          })
        ).map(file => `${filepath}/${file}`);
        for (const ref of refs) {
          if (!actualRefsToWrite.has(ref)) {
            pruned.push(ref);
          }
        }
      }
      if (pruned.length > 0) {
        await GitRefManager.deleteRefs({ fs, gitdir, refs: pruned });
      }
    }
    // Update files
    // TODO: For large repos with a history of thousands of pull requests
    // (i.e. gitlab-ce) it would be vastly more efficient to write them
    // to .git/packed-refs.
    // The trick is to make sure we a) don't write a packed ref that is
    // already shadowed by a loose ref and b) don't loose any refs already
    // in packed-refs. Doing this efficiently may be difficult. A
    // solution that might work is
    // a) load the current packed-refs file
    // b) add actualRefsToWrite, overriding the existing values if present
    // c) enumerate all the loose refs currently in .git/refs/remotes/${remote}
    // d) overwrite their value with the new value.
    // Examples of refs we need to avoid writing in loose format for efficieny's sake
    // are .git/refs/remotes/origin/refs/remotes/remote_mirror_3059
    // and .git/refs/remotes/origin/refs/merge-requests
    for (const [key, value] of actualRefsToWrite) {
      await acquireLock(key, async () =>
        fs.write(join(gitdir, key), `${value.trim()}\n`, 'utf8')
      );
    }
    return { pruned }
  }

  /**
   * Writes a ref to the file system.
   *
   * @param {Object} args
   * @param {FSClient} args.fs - A file system implementation.
   * @param {string} [args.gitdir] - [required] The [git directory](dir-vs-gitdir.md) path
   * @param {string} args.ref - The ref to write.
   * @param {string} args.value - The object ID to write.
   * @returns {Promise<void>}
   */
  // TODO: make this less crude?
  static async writeRef({ fs, gitdir, ref, value }) {
    // Validate input
    assertWritableRef(ref);
    if (!value.match(/[0-9a-f]{40}/)) {
      throw new InvalidOidError(value)
    }
    await acquireLock(ref, async () =>
      fs.write(join(gitdir, ref), `${value.trim()}\n`, 'utf8')
    );
  }

  /**
   * Writes a symbolic ref to the file system.
   *
   * @param {Object} args
   * @param {FSClient} args.fs - A file system implementation.
   * @param {string} [args.gitdir] - [required] The [git directory](dir-vs-gitdir.md) path
   * @param {string} args.ref - The ref to write.
   * @param {string} args.value - The target ref.
   * @returns {Promise<void>}
   */
  static async writeSymbolicRef({ fs, gitdir, ref, value }) {
    assertWritableRef(ref);
    await acquireLock(ref, async () =>
      fs.write(join(gitdir, ref), 'ref: ' + `${value.trim()}\n`, 'utf8')
    );
  }

  /**
   * Deletes a single ref.
   *
   * @param {Object} args
   * @param {FSClient} args.fs - A file system implementation.
   * @param {string} [args.gitdir] - [required] The [git directory](dir-vs-gitdir.md) path
   * @param {string} args.ref - The ref to delete.
   * @returns {Promise<void>}
   */
  static async deleteRef({ fs, gitdir, ref }) {
    return GitRefManager.deleteRefs({ fs, gitdir, refs: [ref] })
  }

  /**
   * Deletes multiple refs.
   *
   * @param {Object} args
   * @param {FSClient} args.fs - A file system implementation.
   * @param {string} [args.gitdir] - [required] The [git directory](dir-vs-gitdir.md) path
   * @param {string[]} args.refs - The refs to delete.
   * @returns {Promise<void>}
   */
  static async deleteRefs({ fs, gitdir, refs }) {
    // Validate input
    refs.forEach(assertWritableRef);
    // Delete regular ref
    await Promise.all(refs.map(ref => fs.rm(join(gitdir, ref))));
    // Delete any packed ref
    let text = await acquireLock('packed-refs', async () =>
      fs.read(`${gitdir}/packed-refs`, { encoding: 'utf8' })
    );
    const packed = GitPackedRefs.from(text);
    const beforeSize = packed.refs.size;
    for (const ref of refs) {
      if (packed.refs.has(ref)) {
        packed.delete(ref);
      }
    }
    if (packed.refs.size < beforeSize) {
      text = packed.toString();
      await acquireLock('packed-refs', async () =>
        fs.write(`${gitdir}/packed-refs`, text, { encoding: 'utf8' })
      );
    }
  }

  /**
   * Resolves a ref to its object ID.
   *
   * @param {Object} args
   * @param {FSClient} args.fs - A file system implementation.
   * @param {string} [args.gitdir] - [required] The [git directory](dir-vs-gitdir.md) path
   * @param {string} args.ref - The ref to resolve.
   * @param {number} [args.depth = undefined] - The maximum depth to resolve symbolic refs.
   * @returns {Promise<string>} - The resolved object ID.
   */
  static async resolve({
    fs,
    gitdir,
    ref,
    depth = undefined,
    visited = new Set(),
  }) {
    if (depth !== undefined) {
      depth--;
      if (depth === -1) {
        return ref
      }
    }

    // Is it a ref pointer?
    if (ref.startsWith('ref: ')) {
      ref = ref.slice('ref: '.length);
      return GitRefManager.resolve({ fs, gitdir, ref, depth, visited })
    }
    // Is it a complete and valid SHA?
    if (ref.length === 40 && /[0-9a-f]{40}/.test(ref)) {
      return ref
    }
    // We need to alternate between the file system and the packed-refs
    const packedMap = await GitRefManager.packedRefs({ fs, gitdir });
    // Look in all the proper paths, in this order
    const allpaths = refpaths(ref).filter(p => !GIT_FILES.includes(p)); // exclude git system files (#709)

    for (const ref of allpaths) {
      const sha = await acquireLock(
        ref,
        async () =>
          (await fs.read(`${gitdir}/${ref}`, { encoding: 'utf8' })) ||
          packedMap.get(ref)
      );
      if (sha) {
        // Guard against circular symbolic references (e.g. a -> b -> a). Without
        // tracking visited refs this recursion would not terminate.
        if (visited.has(ref)) {
          throw new InternalError(
            `Circular reference detected while resolving ref "${ref}"`
          )
        }
        visited.add(ref);
        return GitRefManager.resolve({
          fs,
          gitdir,
          ref: sha.trim(),
          depth,
          visited,
        })
      }
    }
    // Do we give up?
    throw new NotFoundError(ref)
  }

  /**
   * Checks whether a ref names the branch HEAD points at in a repository where
   * that branch has no commits yet.
   *
   * A repository created by `git init` has a HEAD pointing at a branch that
   * does not exist on disk. Resolving that branch fails the same way resolving
   * a misspelled ref does, so callers that want to treat the two differently
   * need this to tell them apart.
   *
   * @param {Object} args
   * @param {FSClient} args.fs - A file system implementation.
   * @param {string} [args.gitdir=join(dir, '.git')] - [required] The [git directory](dir-vs-gitdir.md) path
   * @param {string} args.ref - The ref to check.
   * @returns {Promise<boolean>} - True if the ref names an unborn branch.
   */
  static async isUnbornBranch({ fs, gitdir, ref }) {
    let target;
    try {
      // depth 2 stops at the symbolic target instead of following it to an oid.
      target = await GitRefManager.resolve({
        fs,
        gitdir,
        ref: 'HEAD',
        depth: 2,
      });
    } catch (_) {
      return false
    }
    if (!target.startsWith('refs/heads/')) return false
    return ref === 'HEAD' || refpaths(ref).includes(target)
  }

  /**
   * Checks if a ref exists.
   *
   * @param {Object} args
   * @param {FSClient} args.fs - A file system implementation.
   * @param {string} [args.gitdir=join(dir, '.git')] - [required] The [git directory](dir-vs-gitdir.md) path
   * @param {string} args.ref - The ref to check.
   * @returns {Promise<boolean>} - True if the ref exists, false otherwise.
   */
  static async exists({ fs, gitdir, ref }) {
    try {
      await GitRefManager.expand({ fs, gitdir, ref });
      return true
    } catch (err) {
      return false
    }
  }

  /**
   * Expands a ref to its full name.
   *
   * @param {Object} args
   * @param {FSClient} args.fs - A file system implementation.
   * @param {string} [args.gitdir=join(dir, '.git')] - [required] The [git directory](dir-vs-gitdir.md) path
   * @param {string} args.ref - The ref to expand.
   * @returns {Promise<string>} - The full ref name.
   */
  static async expand({ fs, gitdir, ref }) {
    // Is it a complete and valid SHA?
    if (ref.length === 40 && /[0-9a-f]{40}/.test(ref)) {
      return ref
    }
    // We need to alternate between the file system and the packed-refs
    const packedMap = await GitRefManager.packedRefs({ fs, gitdir });
    // Look in all the proper paths, in this order
    const allpaths = refpaths(ref).filter(p => !GIT_FILES.includes(p)); // exclude git system files (#709)
    for (const ref of allpaths) {
      const refExists = await acquireLock(ref, async () =>
        fs.exists(`${gitdir}/${ref}`)
      );
      if (refExists) return ref
      if (packedMap.has(ref)) return ref
    }
    // Do we give up?
    throw new NotFoundError(ref)
  }

  /**
   * Expands a ref against a provided map.
   *
   * @param {Object} args
   * @param {string} args.ref - The ref to expand.
   * @param {Map<string, string>} args.map - The map of refs.
   * @returns {Promise<string>} - The expanded ref.
   */
  static async expandAgainstMap({ ref, map }) {
    // Look in all the proper paths, in this order
    const allpaths = refpaths(ref);
    for (const ref of allpaths) {
      if (await map.has(ref)) return ref
    }
    // Do we give up?
    throw new NotFoundError(ref)
  }

  /**
   * Resolves a ref against a provided map.
   *
   * @param {Object} args
   * @param {string} args.ref - The ref to resolve.
   * @param {string} [args.fullref = args.ref] - The full ref name.
   * @param {number} [args.depth = undefined] - The maximum depth to resolve symbolic refs.
   * @param {Map<string, string>} args.map - The map of refs.
   * @returns {Object} - An object containing the full ref and its object ID.
   */
  static resolveAgainstMap({ ref, fullref = ref, depth = undefined, map }) {
    if (depth !== undefined) {
      depth--;
      if (depth === -1) {
        return { fullref, oid: ref }
      }
    }
    // Is it a ref pointer?
    if (ref.startsWith('ref: ')) {
      ref = ref.slice('ref: '.length);
      return GitRefManager.resolveAgainstMap({ ref, fullref, depth, map })
    }
    // Is it a complete and valid SHA?
    if (ref.length === 40 && /[0-9a-f]{40}/.test(ref)) {
      return { fullref, oid: ref }
    }
    // Look in all the proper paths, in this order
    const allpaths = refpaths(ref);
    for (const ref of allpaths) {
      const sha = map.get(ref);
      if (sha) {
        return GitRefManager.resolveAgainstMap({
          ref: sha.trim(),
          fullref: ref,
          depth,
          map,
        })
      }
    }
    // Do we give up?
    throw new NotFoundError(ref)
  }

  /**
   * Reads the packed refs file and returns a map of refs.
   *
   * @param {Object} args
   * @param {FSClient} args.fs - A file system implementation.
   * @param {string} [args.gitdir=join(dir, '.git')] - [required] The [git directory](dir-vs-gitdir.md) path
   * @returns {Promise<Map<string, string>>} - A map of packed refs.
   */
  static async packedRefs({ fs, gitdir }) {
    const text = await acquireLock('packed-refs', async () =>
      fs.read(`${gitdir}/packed-refs`, { encoding: 'utf8' })
    );
    const packed = GitPackedRefs.from(text);
    return packed.refs
  }

  /**
   * Lists all refs matching a given filepath prefix.
   *
   * @param {Object} args
   * @param {FSClient} args.fs - A file system implementation.
   * @param {string} [args.gitdir=join(dir, '.git')] - [required] The [git directory](dir-vs-gitdir.md) path
   * @param {string} args.filepath - The filepath prefix to match.
   * @returns {Promise<string[]>} - A sorted list of refs.
   */
  static async listRefs({ fs, gitdir, filepath }) {
    const packedMap = GitRefManager.packedRefs({ fs, gitdir });
    let files = null;
    try {
      files = await fs.readdirDeep(`${gitdir}/${filepath}`);
      files = files.map(x => x.replace(`${gitdir}/${filepath}/`, ''));
    } catch (err) {
      files = [];
    }

    for (let key of (await packedMap).keys()) {
      // filter by prefix
      if (key.startsWith(filepath)) {
        // remove prefix
        key = key.replace(filepath + '/', '');
        // Don't include duplicates; the loose files have precedence anyway
        if (!files.includes(key)) {
          files.push(key);
        }
      }
    }
    // since we just appended things onto an array, we need to sort them now
    files.sort(compareRefNames);
    return files
  }

  /**
   * Lists all branches, optionally filtered by remote.
   *
   * @param {Object} args
   * @param {FSClient} args.fs - A file system implementation.
   * @param {string} [args.gitdir=join(dir, '.git')] - [required] The [git directory](dir-vs-gitdir.md) path
   * @param {string} [args.remote] - The remote to filter branches by.
   * @returns {Promise<string[]>} - A list of branch names.
   */
  static async listBranches({ fs, gitdir, remote }) {
    if (remote) {
      return GitRefManager.listRefs({
        fs,
        gitdir,
        filepath: `refs/remotes/${remote}`,
      })
    } else {
      return GitRefManager.listRefs({ fs, gitdir, filepath: `refs/heads` })
    }
  }

  /**
   * Lists all tags.
   *
   * @param {Object} args
   * @param {FSClient} args.fs - A file system implementation.
   * @param {string} [args.gitdir=join(dir, '.git')] - [required] The [git directory](dir-vs-gitdir.md) path
   * @returns {Promise<string[]>} - A list of tag names.
   */
  static async listTags({ fs, gitdir }) {
    const tags = await GitRefManager.listRefs({
      fs,
      gitdir,
      filepath: `refs/tags`,
    });
    return tags.filter(x => !x.endsWith('^{}'))
  }
}

function compareTreeEntryPath(a, b) {
  // Git sorts tree entries as if there is a trailing slash on directory names.
  return compareStrings(appendSlashIfDir(a), appendSlashIfDir(b))
}

function appendSlashIfDir(entry) {
  return entry.mode === '040000' ? entry.path + '/' : entry.path
}

/**
 *
 * @typedef {Object} TreeEntry
 * @property {string} mode - the 6 digit hexadecimal mode
 * @property {string} path - the name of the file or directory
 * @property {string} oid - the SHA-1 object id of the blob or tree
 * @property {'commit'|'blob'|'tree'} type - the type of object
 */

function mode2type$1(mode) {
  // prettier-ignore
  switch (mode) {
    case '040000': return 'tree'
    case '100644': return 'blob'
    case '100755': return 'blob'
    case '120000': return 'blob'
    case '160000': return 'commit'
  }
  throw new InternalError(`Unexpected GitTree entry mode: ${mode}`)
}

function parseBuffer(buffer) {
  const _entries = [];
  let cursor = 0;
  while (cursor < buffer.length) {
    const space = buffer.indexOf(32, cursor);
    if (space === -1) {
      throw new InternalError(
        `GitTree: Error parsing buffer at byte location ${cursor}: Could not find the next space character.`
      )
    }
    const nullchar = buffer.indexOf(0, cursor);
    if (nullchar === -1) {
      throw new InternalError(
        `GitTree: Error parsing buffer at byte location ${cursor}: Could not find the next null character.`
      )
    }
    let mode = buffer.slice(cursor, space).toString('utf8');
    if (mode === '40000') mode = '040000'; // makes it line up neater in printed output
    const type = mode2type$1(mode);
    const path = buffer.slice(space + 1, nullchar).toString('utf8');

    // Reject reserved entry names, matching git's verify_path(): path separators,
    // "." and ".." (which resolve outside the working directory), and ".git" (which git
    // disallows as a path component). Checks mirror git's is_ntfs_dotgit() and
    // is_hfs_dotgit(): case-insensitive, trailing dots/spaces stripped (NTFS),
    // NTFS 8.3 short name aliases (git~1..git~9), NTFS Alternate Data Streams, and
    // HFS+ ignorable Unicode characters stripped (zero-width joiners, directional
    // marks, BOM, etc.).
    const hfsClean = path.replace(
      /[\u200C-\u200F\u202A-\u202E\u206A-\u206F\uFEFF]/g,
      ''
    );
    // NTFS Alternate Data Streams are referenced as `<name>:<stream>:<type>`, and a
    // directory's default stream lets `.git::$INDEX_ALLOCATION` resolve to the `.git`
    // directory itself. git forbids *any* ADS, so only the portion before the first
    // colon names the actual entry we normalize and check.
    const ntfsClean = hfsClean.split(':')[0];
    const normalized = ntfsClean.toLowerCase().replace(/[. ]+$/, '');
    if (
      path.includes('\\') ||
      path.includes('/') ||
      hfsClean === '.' ||
      hfsClean === '..' ||
      normalized === '.git' ||
      /^\.?git~[1-9]$/.test(normalized)
    ) {
      throw new UnsafeFilepathError(path)
    }

    const oid = buffer.slice(nullchar + 1, nullchar + 21).toString('hex');
    cursor = nullchar + 21;
    _entries.push({ mode, path, oid, type });
  }
  return _entries
}

function limitModeToAllowed(mode) {
  if (typeof mode === 'number') {
    mode = mode.toString(8);
  }
  // tree
  if (mode.match(/^0?4.*/)) return '040000' // Directory
  if (mode.match(/^1006.*/)) return '100644' // Regular non-executable file
  if (mode.match(/^1007.*/)) return '100755' // Regular executable file
  if (mode.match(/^120.*/)) return '120000' // Symbolic link
  if (mode.match(/^160.*/)) return '160000' // Commit (git submodule reference)
  throw new InternalError(`Could not understand file mode: ${mode}`)
}

function nudgeIntoShape(entry) {
  if (!entry.oid && entry.sha) {
    entry.oid = entry.sha; // Github
  }
  entry.mode = limitModeToAllowed(entry.mode); // index
  if (!entry.type) {
    entry.type = mode2type$1(entry.mode); // index
  }
  return entry
}

class GitTree {
  constructor(entries) {
    if (Buffer.isBuffer(entries)) {
      this._entries = parseBuffer(entries);
    } else if (Array.isArray(entries)) {
      this._entries = entries.map(nudgeIntoShape);
    } else {
      throw new InternalError('invalid type passed to GitTree constructor')
    }
    // Tree entries are not sorted alphabetically in the usual sense (see `compareTreeEntryPath`)
    // but it is important later on that these be sorted in the same order as they would be returned from readdir.
    this._entries.sort(comparePath);
  }

  static from(tree) {
    return new GitTree(tree)
  }

  render() {
    return this._entries
      .map(entry => `${entry.mode} ${entry.type} ${entry.oid}    ${entry.path}`)
      .join('\n')
  }

  toObject() {
    // Adjust the sort order to match git's
    const entries = [...this._entries];
    entries.sort(compareTreeEntryPath);
    return Buffer.concat(
      entries.map(entry => {
        const mode = Buffer.from(entry.mode.replace(/^0/, ''));
        const space = Buffer.from(' ');
        const path = Buffer.from(entry.path, 'utf8');
        const nullchar = Buffer.from([0]);
        const oid = Buffer.from(entry.oid, 'hex');
        return Buffer.concat([mode, space, path, nullchar, oid])
      })
    )
  }

  /**
   * @returns {TreeEntry[]}
   */
  entries() {
    return this._entries
  }

  *[Symbol.iterator]() {
    for (const entry of this._entries) {
      yield entry;
    }
  }
}

/**
 * Represents a Git object and provides methods to wrap and unwrap Git objects
 * according to the Git object format.
 */
class GitObject {
  /**
   * Wraps a raw object with a Git header.
   *
   * @param {Object} params - The parameters for wrapping.
   * @param {string} params.type - The type of the Git object (e.g., 'blob', 'tree', 'commit').
   * @param {Uint8Array} params.object - The raw object data to wrap.
   * @returns {Uint8Array} The wrapped Git object as a single buffer.
   */
  static wrap({ type, object }) {
    const header = `${type} ${object.length}\x00`;
    const headerLen = header.length;
    const totalLength = headerLen + object.length;

    // Allocate a single buffer for the header and object, rather than create multiple buffers
    const wrappedObject = new Uint8Array(totalLength);
    for (let i = 0; i < headerLen; i++) {
      wrappedObject[i] = header.charCodeAt(i);
    }
    wrappedObject.set(object, headerLen);

    return wrappedObject
  }

  /**
   * Unwraps a Git object buffer into its type and raw object data.
   *
   * @param {Buffer|Uint8Array} buffer - The buffer containing the wrapped Git object.
   * @returns {{ type: string, object: Buffer }} An object containing the type and the raw object data.
   * @throws {InternalError} If the length specified in the header does not match the actual object length.
   */
  static unwrap(buffer) {
    const s = buffer.indexOf(32); // first space
    const i = buffer.indexOf(0); // first null value
    const type = buffer.slice(0, s).toString('utf8'); // get type of object
    const length = buffer.slice(s + 1, i).toString('utf8'); // get type of object
    const actualLength = buffer.length - (i + 1);
    // verify length
    if (parseInt(length) !== actualLength) {
      throw new InternalError(
        `Length mismatch: expected ${length} bytes but got ${actualLength} instead.`
      )
    }
    return {
      type,
      object: Buffer.from(buffer.slice(i + 1)),
    }
  }
}

async function readObjectLoose({ fs, gitdir, oid }) {
  const source = `objects/${oid.slice(0, 2)}/${oid.slice(2)}`;
  const file = await fs.read(`${gitdir}/${source}`);
  if (!file) {
    return null
  }
  return { object: file, format: 'deflated', source }
}

/**
 * @param {Buffer} delta
 * @param {Buffer} source
 * @returns {Buffer}
 */
function applyDelta(delta, source) {
  const reader = new BufferCursor(delta);
  const sourceSize = readVarIntLE(reader);

  if (sourceSize !== source.byteLength) {
    throw new InternalError(
      `applyDelta expected source buffer to be ${sourceSize} bytes but the provided buffer was ${source.length} bytes`
    )
  }
  const targetSize = readVarIntLE(reader);
  let target;

  const firstOp = readOp(reader, source);
  // Speed optimization - return raw buffer if it's just single simple copy
  if (firstOp.byteLength === targetSize) {
    target = firstOp;
  } else {
    // Build the result from the delta ops instead of pre-allocating `targetSize`.
    // `targetSize` comes from the delta header and may not match the actual op output,
    // so allocating it up front can reserve far more memory than the ops produce.
    // Building from the ops bounds memory to the real output size; the size check below
    // still validates the total before concatenating.
    const chunks = [firstOp];
    let tell = firstOp.byteLength;

    while (!reader.eof()) {
      const op = readOp(reader, source);
      chunks.push(op);
      tell += op.byteLength;
    }

    if (targetSize !== tell) {
      throw new InternalError(
        `applyDelta expected target buffer to be ${targetSize} bytes but the resulting buffer was ${tell} bytes`
      )
    }
    target = Buffer.concat(chunks, targetSize);
  }
  return target
}

function readVarIntLE(reader) {
  let result = 0;
  let shift = 0;
  let byte = null;
  do {
    byte = reader.readUInt8();
    result |= (byte & 0b01111111) << shift;
    shift += 7;
  } while (byte & 0b10000000)
  return result
}

function readCompactLE(reader, flags, size) {
  let result = 0;
  let shift = 0;
  while (size--) {
    if (flags & 0b00000001) {
      result |= reader.readUInt8() << shift;
    }
    flags >>= 1;
    shift += 8;
  }
  return result
}

function readOp(reader, source) {
  /** @type {number} */
  const byte = reader.readUInt8();
  const COPY = 0b10000000;
  const OFFS = 0b00001111;
  const SIZE = 0b01110000;
  if (byte & COPY) {
    // copy consists of 4 byte offset, 3 byte size (in LE order)
    const offset = readCompactLE(reader, byte & OFFS, 4);
    let size = readCompactLE(reader, (byte & SIZE) >> 4, 3);
    // Yup. They really did this optimization.
    if (size === 0) size = 0x10000;
    return source.slice(offset, offset + size)
  } else {
    // insert
    return reader.slice(byte)
  }
}

// Convert a value to an Async Iterator
// This will be easier with async generator functions.
function fromValue(value) {
  let queue = [value];
  return {
    next() {
      return Promise.resolve({ done: queue.length === 0, value: queue.pop() })
    },
    return() {
      queue = [];
      return {}
    },
    [Symbol.asyncIterator]() {
      return this
    },
  }
}

function getIterator(iterable) {
  if (iterable[Symbol.asyncIterator]) {
    return iterable[Symbol.asyncIterator]()
  }
  if (iterable[Symbol.iterator]) {
    return iterable[Symbol.iterator]()
  }
  if (iterable.next) {
    return iterable
  }
  return fromValue(iterable)
}

// inspired by 'gartal' but lighter-weight and more battle-tested.
class StreamReader {
  constructor(stream) {
    // TODO: fix usage in bundlers before Buffer dependency is removed #1855
    if (typeof Buffer === 'undefined') {
      throw new Error('Missing Buffer dependency')
    }
    this.stream = getIterator(stream);
    this.buffer = null;
    this.cursor = 0;
    this.undoCursor = 0;
    this.started = false;
    this._ended = false;
    this._discardedBytes = 0;
  }

  eof() {
    return this._ended && this.cursor === this.buffer.length
  }

  tell() {
    return this._discardedBytes + this.cursor
  }

  async byte() {
    if (this.eof()) return
    if (!this.started) await this._init();
    if (this.cursor === this.buffer.length) {
      await this._loadnext();
      if (this._ended) return
    }
    this._moveCursor(1);
    return this.buffer[this.undoCursor]
  }

  async chunk() {
    if (this.eof()) return
    if (!this.started) await this._init();
    if (this.cursor === this.buffer.length) {
      await this._loadnext();
      if (this._ended) return
    }
    this._moveCursor(this.buffer.length);
    return this.buffer.slice(this.undoCursor, this.cursor)
  }

  async read(n) {
    if (this.eof()) return
    if (!this.started) await this._init();
    if (this.cursor + n > this.buffer.length) {
      this._trim();
      await this._accumulate(n);
    }
    this._moveCursor(n);
    return this.buffer.slice(this.undoCursor, this.cursor)
  }

  async skip(n) {
    if (this.eof()) return
    if (!this.started) await this._init();
    if (this.cursor + n > this.buffer.length) {
      this._trim();
      await this._accumulate(n);
    }
    this._moveCursor(n);
  }

  async undo() {
    this.cursor = this.undoCursor;
  }

  async _next() {
    this.started = true;
    let { done, value } = await this.stream.next();
    if (done) {
      this._ended = true;
      if (!value) return Buffer.alloc(0)
    }
    if (value) {
      value = Buffer.from(value);
    }
    return value
  }

  _trim() {
    // Throw away parts of the buffer we don't need anymore
    // assert(this.cursor <= this.buffer.length)
    this.buffer = this.buffer.slice(this.undoCursor);
    this.cursor -= this.undoCursor;
    this._discardedBytes += this.undoCursor;
    this.undoCursor = 0;
  }

  _moveCursor(n) {
    this.undoCursor = this.cursor;
    this.cursor += n;
    if (this.cursor > this.buffer.length) {
      this.cursor = this.buffer.length;
    }
  }

  async _accumulate(n) {
    if (this._ended) return
    // Expand the buffer until we have N bytes of data
    // or we've reached the end of the stream
    const buffers = [this.buffer];
    while (this.cursor + n > lengthBuffers(buffers)) {
      const nextbuffer = await this._next();
      if (this._ended) break
      buffers.push(nextbuffer);
    }
    this.buffer = Buffer.concat(buffers);
  }

  async _loadnext() {
    this._discardedBytes += this.buffer.length;
    this.undoCursor = 0;
    this.cursor = 0;
    this.buffer = await this._next();
  }

  async _init() {
    this.buffer = await this._next();
  }
}

// This helper function helps us postpone concatenating buffers, which
// would create intermediate buffer objects,
function lengthBuffers(buffers) {
  return buffers.reduce((acc, buffer) => acc + buffer.length, 0)
}

// My version of git-list-pack - roughly 15x faster than the original

async function listpack(stream, onData) {
  const reader = new StreamReader(stream);
  let PACK = await reader.read(4);
  PACK = PACK.toString('utf8');
  if (PACK !== 'PACK') {
    throw new InternalError(`Invalid PACK header '${PACK}'`)
  }

  let version = await reader.read(4);
  version = version.readUInt32BE(0);
  if (version !== 2) {
    throw new InternalError(`Invalid packfile version: ${version}`)
  }

  let numObjects = await reader.read(4);
  numObjects = numObjects.readUInt32BE(0);
  // If (for some godforsaken reason) this is an empty packfile, abort now.
  if (numObjects < 1) return

  while (!reader.eof() && numObjects--) {
    const offset = reader.tell();
    const { type, length, ofs, reference } = await parseHeader(reader);
    const inflator = new pako.Inflate();
    while (!inflator.result) {
      const chunk = await reader.chunk();
      if (!chunk) break
      inflator.push(chunk, false);
      if (inflator.err) {
        throw new InternalError(`Pako error: ${inflator.msg}`)
      }
      if (inflator.result) {
        if (inflator.result.length !== length) {
          throw new InternalError(
            `Inflated object size is different from that stated in packfile.`
          )
        }

        // Backtrack parser to where deflated data ends
        await reader.undo();
        await reader.read(chunk.length - inflator.strm.avail_in);
        const end = reader.tell();
        await onData({
          data: inflator.result,
          type,
          num: numObjects,
          offset,
          end,
          reference,
          ofs,
        });
      }
    }
  }
}

async function parseHeader(reader) {
  // Object type is encoded in bits 654
  let byte = await reader.byte();
  const type = (byte >> 4) & 0b111;
  // The length encoding get complicated.
  // Last four bits of length is encoded in bits 3210
  let length = byte & 0b1111;
  // Whether the next byte is part of the variable-length encoded number
  // is encoded in bit 7
  if (byte & 0b10000000) {
    let shift = 4;
    do {
      byte = await reader.byte();
      length |= (byte & 0b01111111) << shift;
      shift += 7;
    } while (byte & 0b10000000)
  }
  // Handle deltified objects
  let ofs;
  let reference;
  if (type === 6) {
    let shift = 0;
    ofs = 0;
    const bytes = [];
    do {
      byte = await reader.byte();
      ofs |= (byte & 0b01111111) << shift;
      shift += 7;
      bytes.push(byte);
    } while (byte & 0b10000000)
    reference = Buffer.from(bytes);
  }
  if (type === 7) {
    const buf = await reader.read(20);
    reference = buf;
  }
  return { type, length, ofs, reference }
}

/* eslint-env node, browser */

let supportsDecompressionStream = false;

async function inflate(buffer) {
  if (supportsDecompressionStream === null) {
    supportsDecompressionStream = testDecompressionStream();
  }
  return supportsDecompressionStream
    ? browserInflate(buffer)
    : pako.inflate(buffer)
}

async function browserInflate(buffer) {
  const ds = new DecompressionStream('deflate');
  const d = new Blob([buffer]).stream().pipeThrough(ds);
  return new Uint8Array(await new Response(d).arrayBuffer())
}

function testDecompressionStream() {
  try {
    const ds = new DecompressionStream('deflate');
    if (ds) return true
  } catch (_) {
    // no bother
  }
  return false
}

function decodeVarInt(reader) {
  const bytes = [];
  let byte = 0;
  let multibyte = 0;
  do {
    byte = reader.readUInt8();
    // We keep bits 6543210
    const lastSeven = byte & 0b01111111;
    bytes.push(lastSeven);
    // Whether the next byte is part of the variable-length encoded number
    // is encoded in bit 7
    multibyte = byte & 0b10000000;
  } while (multibyte)
  // Now that all the bytes are in big-endian order,
  // alternate shifting the bits left by 7 and OR-ing the next byte.
  // And... do a weird increment-by-one thing that I don't quite understand.
  return bytes.reduce((a, b) => ((a + 1) << 7) | b, -1)
}

// I'm pretty much copying this one from the git C source code,
// because it makes no sense.
function otherVarIntDecode(reader, startWith) {
  let result = startWith;
  let shift = 4;
  let byte = null;
  do {
    byte = reader.readUInt8();
    result |= (byte & 0b01111111) << shift;
    shift += 7;
  } while (byte & 0b10000000)
  return result
}

class GitPackIndex {
  constructor(stuff) {
    Object.assign(this, stuff);
    this.offsetCache = {};
  }

  static async fromIdx({ idx, getExternalRefDelta }) {
    const reader = new BufferCursor(idx);
    const magic = reader.slice(4).toString('hex');
    // Check for IDX v2 magic number
    if (magic !== 'ff744f63') {
      return // undefined
    }
    const version = reader.readUInt32BE();
    if (version !== 2) {
      throw new InternalError(
        `Unable to read version ${version} packfile IDX. (Only version 2 supported)`
      )
    }
    if (idx.byteLength > 2048 * 1024 * 1024) {
      throw new InternalError(
        `To keep implementation simple, I haven't implemented the layer 5 feature needed to support packfiles > 2GB in size.`
      )
    }
    // Skip over fanout table
    reader.seek(reader.tell() + 4 * 255);
    // Get hashes
    const size = reader.readUInt32BE();
    const hashes = [];
    for (let i = 0; i < size; i++) {
      const hash = reader.slice(20).toString('hex');
      hashes[i] = hash;
    }
    reader.seek(reader.tell() + 4 * size);
    // Skip over CRCs
    // Get offsets
    const offsets = new Map();
    for (let i = 0; i < size; i++) {
      offsets.set(hashes[i], reader.readUInt32BE());
    }
    const packfileSha = reader.slice(20).toString('hex');
    return new GitPackIndex({
      hashes,
      crcs: {},
      offsets,
      packfileSha,
      getExternalRefDelta,
    })
  }

  static async fromPack({ pack, getExternalRefDelta, onProgress }) {
    const listpackTypes = {
      1: 'commit',
      2: 'tree',
      3: 'blob',
      4: 'tag',
      6: 'ofs-delta',
      7: 'ref-delta',
    };
    const offsetToObject = {};

    // Older packfiles do NOT use the shasum of the pack itself,
    // so it is recommended to just use whatever bytes are in the trailer.
    // Source: https://github.com/git/git/commit/1190a1acf800acdcfd7569f87ac1560e2d077414
    const packfileSha = pack.slice(-20).toString('hex');

    const hashes = [];
    const crcs = {};
    const offsets = new Map();
    let totalObjectCount = null;
    let lastPercent = null;

    await listpack([pack], async ({ data, type, reference, offset, num }) => {
      if (totalObjectCount === null) totalObjectCount = num;
      const percent = Math.floor(
        ((totalObjectCount - num) * 100) / totalObjectCount
      );
      if (percent !== lastPercent) {
        if (onProgress) {
          await onProgress({
            phase: 'Receiving objects',
            loaded: totalObjectCount - num,
            total: totalObjectCount,
          });
        }
      }
      lastPercent = percent;
      // Change type from a number to a meaningful string
      type = listpackTypes[type];

      if (['commit', 'tree', 'blob', 'tag'].includes(type)) {
        offsetToObject[offset] = {
          type,
          offset,
        };
      } else if (type === 'ofs-delta') {
        offsetToObject[offset] = {
          type,
          offset,
        };
      } else if (type === 'ref-delta') {
        offsetToObject[offset] = {
          type,
          offset,
        };
      }
    });

    // We need to know the lengths of the slices to compute the CRCs.
    const offsetArray = Object.keys(offsetToObject).map(Number);
    for (const [i, start] of offsetArray.entries()) {
      const end =
        i + 1 === offsetArray.length ? pack.byteLength - 20 : offsetArray[i + 1];
      const o = offsetToObject[start];
      const crc = crc32.buf(pack.slice(start, end)) >>> 0;
      o.end = end;
      o.crc = crc;
    }

    // We don't have the hashes yet. But we can generate them using the .readSlice function!
    const p = new GitPackIndex({
      pack: Promise.resolve(pack),
      packfileSha,
      crcs,
      hashes,
      offsets,
      getExternalRefDelta,
    });

    // Resolve deltas and compute the oids
    lastPercent = null;
    let count = 0;
    const objectsByDepth = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
    for (let offset in offsetToObject) {
      offset = Number(offset);
      const percent = Math.floor((count * 100) / totalObjectCount);
      if (percent !== lastPercent) {
        if (onProgress) {
          await onProgress({
            phase: 'Resolving deltas',
            loaded: count,
            total: totalObjectCount,
          });
        }
      }
      count++;
      lastPercent = percent;

      const o = offsetToObject[offset];
      if (o.oid) continue
      try {
        p.readDepth = 0;
        p.externalReadDepth = 0;
        const { type, object } = await p.readSlice({ start: offset });
        objectsByDepth[p.readDepth] += 1;
        const oid = await shasum(GitObject.wrap({ type, object }));
        o.oid = oid;
        hashes.push(oid);
        offsets.set(oid, offset);
        crcs[oid] = o.crc;
      } catch (err) {
        continue
      }
    }

    hashes.sort();
    return p
  }

  async toBuffer() {
    const buffers = [];
    const write = (str, encoding) => {
      buffers.push(Buffer.from(str, encoding));
    };
    // Write out IDX v2 magic number
    write('ff744f63', 'hex');
    // Write out version number 2
    write('00000002', 'hex');
    // Write fanout table
    const fanoutBuffer = new BufferCursor(Buffer.alloc(256 * 4));
    for (let i = 0; i < 256; i++) {
      let count = 0;
      for (const hash of this.hashes) {
        if (parseInt(hash.slice(0, 2), 16) <= i) count++;
      }
      fanoutBuffer.writeUInt32BE(count);
    }
    buffers.push(fanoutBuffer.buffer);
    // Write out hashes
    for (const hash of this.hashes) {
      write(hash, 'hex');
    }
    // Write out crcs
    const crcsBuffer = new BufferCursor(Buffer.alloc(this.hashes.length * 4));
    for (const hash of this.hashes) {
      crcsBuffer.writeUInt32BE(this.crcs[hash]);
    }
    buffers.push(crcsBuffer.buffer);
    // Write out offsets
    const offsetsBuffer = new BufferCursor(Buffer.alloc(this.hashes.length * 4));
    for (const hash of this.hashes) {
      offsetsBuffer.writeUInt32BE(this.offsets.get(hash));
    }
    buffers.push(offsetsBuffer.buffer);
    // Write out packfile checksum
    write(this.packfileSha, 'hex');
    // Write out shasum
    const totalBuffer = Buffer.concat(buffers);
    const sha = await shasum(totalBuffer);
    const shaBuffer = Buffer.alloc(20);
    shaBuffer.write(sha, 'hex');
    return Buffer.concat([totalBuffer, shaBuffer])
  }

  async load({ pack }) {
    this.pack = pack;
  }

  async unload() {
    this.pack = null;
  }

  async read({ oid }) {
    if (!this.offsets.get(oid)) {
      if (this.getExternalRefDelta) {
        this.externalReadDepth++;
        return this.getExternalRefDelta(oid)
      } else {
        throw new InternalError(`Could not read object ${oid} from packfile`)
      }
    }
    const start = this.offsets.get(oid);
    return this.readSlice({ start })
  }

  async readSlice({ start }) {
    if (this.offsetCache[start]) {
      return Object.assign({}, this.offsetCache[start])
    }
    this.readDepth++;
    const types = {
      0b0010000: 'commit',
      0b0100000: 'tree',
      0b0110000: 'blob',
      0b1000000: 'tag',
      0b1100000: 'ofs_delta',
      0b1110000: 'ref_delta',
    };
    const pack = await this.pack;
    if (!pack) {
      throw new InternalError(
        'Could not read packfile data. The packfile may be missing, corrupted, or too large to read into memory.'
      )
    }
    const raw = pack.slice(start);
    const reader = new BufferCursor(raw);
    const byte = reader.readUInt8();
    // Object type is encoded in bits 654
    const btype = byte & 0b1110000;
    let type = types[btype];
    if (type === undefined) {
      throw new InternalError('Unrecognized type: 0b' + btype.toString(2))
    }
    // The length encoding get complicated.
    // Last four bits of length is encoded in bits 3210
    const lastFour = byte & 0b1111;
    let length = lastFour;
    // Whether the next byte is part of the variable-length encoded number
    // is encoded in bit 7
    const multibyte = byte & 0b10000000;
    if (multibyte) {
      length = otherVarIntDecode(reader, lastFour);
    }
    let base = null;
    let object = null;
    // Handle deltified objects
    if (type === 'ofs_delta') {
      const offset = decodeVarInt(reader);
      const baseOffset = start - offset
      ;({ object: base, type } = await this.readSlice({ start: baseOffset }));
    }
    if (type === 'ref_delta') {
      const oid = reader.slice(20).toString('hex')
      ;({ object: base, type } = await this.read({ oid }));
    }
    // Handle undeltified objects
    const buffer = raw.slice(reader.tell());
    object = Buffer.from(await inflate(buffer));
    // Assert that the object length is as expected.
    if (object.byteLength !== length) {
      throw new InternalError(
        `Packfile told us object would have length ${length} but it had length ${object.byteLength}`
      )
    }
    if (base) {
      object = Buffer.from(applyDelta(object, base));
    }
    // Cache the result based on depth.
    if (this.readDepth > 3) {
      // hand tuned for speed / memory usage tradeoff
      this.offsetCache[start] = { type, object };
    }
    return { type, format: 'content', object }
  }
}

const PackfileCache = Symbol('PackfileCache');

async function loadPackIndex({
  fs,
  filename,
  getExternalRefDelta,
  emitter,
  emitterPrefix,
}) {
  const idx = await fs.read(filename);
  return GitPackIndex.fromIdx({ idx, getExternalRefDelta })
}

function readPackIndex({
  fs,
  cache,
  filename,
  getExternalRefDelta,
  emitter,
  emitterPrefix,
}) {
  // Try to get the packfile index from the in-memory cache
  if (!cache[PackfileCache]) cache[PackfileCache] = new Map();
  let p = cache[PackfileCache].get(filename);
  if (!p) {
    p = loadPackIndex({
      fs,
      filename,
      getExternalRefDelta,
      emitter,
      emitterPrefix,
    });
    cache[PackfileCache].set(filename, p);
  }
  return p
}

const SHA1_CHUNK_SIZE = 8 * 1024 * 1024;

async function shasumRange(
  buffer,
  { start = 0, end = buffer.length } = {}
) {
  const hash = crypto$1.createHash('sha1');
  for (let i = start; i < end; i += SHA1_CHUNK_SIZE) {
    hash.update(buffer.subarray(i, Math.min(i + SHA1_CHUNK_SIZE, end)));
  }
  return hash.digest('hex')
}

async function readObjectPacked({
  fs,
  cache,
  gitdir,
  oid,
  format = 'content',
  getExternalRefDelta,
}) {
  // Check to see if it's in a packfile.
  // Iterate through all the .idx files
  let list = await fs.readdir(join(gitdir, 'objects/pack'));
  list = list.filter(x => x.endsWith('.idx'));
  for (const filename of list) {
    const indexFile = `${gitdir}/objects/pack/${filename}`;
    const p = await readPackIndex({
      fs,
      cache,
      filename: indexFile,
      getExternalRefDelta,
    });
    if (p.error) throw new InternalError(p.error)
    // If the packfile DOES have the oid we're looking for...
    if (p.offsets.has(oid)) {
      // Derive the .pack path from the .idx path
      const packFile = indexFile.replace(/idx$/, 'pack');
      if (!p.pack) {
        p.pack = fs.read(packFile);
      }
      const pack = await p.pack;
      if (!pack) {
        p.pack = null;
        throw new InternalError(
          `Could not read packfile at ${packFile}. The file may be missing, corrupted, or too large to read into memory.`
        )
      }

      // === Packfile Integrity Verification ===
      // Performance optimization: use _checksumVerified flag to verify only once per packfile
      if (!p._checksumVerified) {
        const expectedShaFromIndex = p.packfileSha;

        // 1. Fast Check: Verify packfile trailer matches index record
        // Use subarray instead of slice to avoid memory copy (zero-copy for large packfiles)
        const packTrailer = pack.subarray(-20);
        const packTrailerSha = Array.from(packTrailer)
          .map(b => b.toString(16).padStart(2, '0'))
          .join('');
        if (packTrailerSha !== expectedShaFromIndex) {
          throw new InternalError(
            `Packfile trailer mismatch: expected ${expectedShaFromIndex}, got ${packTrailerSha}. The packfile may be corrupted.`
          )
        }

        // 2. Deep Integrity Check: Calculate actual SHA-1 of packfile payload.
        // The Node package build swaps in a chunked implementation for large packs.
        const actualPayloadSha = await shasumRange(pack, {
          start: 0,
          end: pack.length - 20,
        });
        if (actualPayloadSha !== expectedShaFromIndex) {
          throw new InternalError(
            `Packfile payload corrupted: calculated ${actualPayloadSha} but expected ${expectedShaFromIndex}. The packfile may have been tampered with.`
          )
        }

        // Mark as verified to prevent performance regression on subsequent reads
        p._checksumVerified = true;
      }

      const result = await p.read({ oid, getExternalRefDelta });
      result.format = 'content';
      result.source = `objects/pack/${filename.replace(/idx$/, 'pack')}`;
      return result
    }
  }
  // Failed to find it
  return null
}

/**
 * @param {object} args
 * @param {import('../models/FileSystem.js').FileSystem} args.fs
 * @param {any} args.cache
 * @param {string} args.gitdir
 * @param {string} args.oid
 * @param {string} [args.format]
 */
async function _readObject({
  fs,
  cache,
  gitdir,
  oid,
  format = 'content',
}) {
  if (!['deflated', 'wrapped', 'content'].includes(format)) {
    throw new InternalError(`invalid requested format "${format}"`)
  }

  // Curry the current read method so that the packfile un-deltification
  // process can acquire external ref-deltas.
  const getExternalRefDelta = oid => _readObject({ fs, cache, gitdir, oid });

  let result;
  // Empty tree - hard-coded so we can use it as a shorthand.
  // Note: I think the canonical git implementation must do this too because
  // `git cat-file -t 4b825dc642cb6eb9a060e54bf8d69288fbee4904` prints "tree" even in empty repos.
  if (oid === '4b825dc642cb6eb9a060e54bf8d69288fbee4904') {
    result = { format: 'wrapped', object: Buffer.from(`tree 0\x00`) };
  }
  // Look for it in the loose object directory.
  if (!result) {
    result = await readObjectLoose({ fs, gitdir, oid });
  }
  // Check to see if it's in a packfile.
  if (!result) {
    result = await readObjectPacked({
      fs,
      cache,
      gitdir,
      oid,
      getExternalRefDelta,
    });

    if (!result) {
      throw new NotFoundError(oid)
    }

    // Directly return packed result, as specified: packed objects always return the 'content' format.
    return result
  }

  // Loose objects are always deflated, return early
  if (format === 'deflated') {
    return result
  }

  // All loose objects are deflated but the hard-coded empty tree is `wrapped` so we have to check if we need to inflate the object.
  if (result.format === 'deflated') {
    result.object = Buffer.from(await inflate(result.object));
    result.format = 'wrapped';
  }

  if (format === 'wrapped') {
    return result
  }

  const sha = await shasum(result.object);
  if (sha !== oid) {
    throw new InternalError(
      `SHA check failed! Expected ${oid}, computed ${sha}`
    )
  }
  const { object, type } = GitObject.unwrap(result.object);
  result.type = type;
  result.object = object;
  result.format = 'content';

  return result
}

class AlreadyExistsError extends BaseError {
  /**
   * @param {'note'|'remote'|'tag'|'branch'} noun
   * @param {string} where
   * @param {boolean} canForce
   */
  constructor(noun, where, canForce = true) {
    super(
      `Failed to create ${noun} at ${where} because it already exists.${
        canForce
          ? ` (Hint: use 'force: true' parameter to overwrite existing ${noun}.)`
          : ''
      }`
    );
    this.code = this.name = AlreadyExistsError.code;
    this.data = { noun, where, canForce };
  }
}
/** @type {'AlreadyExistsError'} */
AlreadyExistsError.code = 'AlreadyExistsError';

class AmbiguousError extends BaseError {
  /**
   * @param {'oids'|'refs'} nouns
   * @param {string} short
   * @param {string[]} matches
   */
  constructor(nouns, short, matches) {
    super(
      `Found multiple ${nouns} matching "${short}" (${matches.join(
        ', '
      )}). Use a longer abbreviation length to disambiguate them.`
    );
    this.code = this.name = AmbiguousError.code;
    this.data = { nouns, short, matches };
  }
}
/** @type {'AmbiguousError'} */
AmbiguousError.code = 'AmbiguousError';

class CheckoutConflictError extends BaseError {
  /**
   * @param {string[]} filepaths
   */
  constructor(filepaths) {
    super(
      `Your local changes to the following files would be overwritten by checkout: ${filepaths.join(
        ', '
      )}`
    );
    this.code = this.name = CheckoutConflictError.code;
    this.data = { filepaths };
  }
}
/** @type {'CheckoutConflictError'} */
CheckoutConflictError.code = 'CheckoutConflictError';

class CherryPickMergeCommitError extends BaseError {
  /**
   * @param {string} oid
   * @param {number} parentCount
   */
  constructor(oid, parentCount) {
    super(
      `Cannot cherry-pick merge commit ${oid}. ` +
        `Merge commits have ${parentCount} parents and require specifying which parent to use as the base.`
    );
    this.code = this.name = CherryPickMergeCommitError.code;
    this.data = { oid, parentCount };
  }
}
/** @type {'CherryPickMergeCommitError'} */
CherryPickMergeCommitError.code = 'CherryPickMergeCommitError';

class CherryPickRootCommitError extends BaseError {
  /**
   * @param {string} oid
   */
  constructor(oid) {
    super(
      `Cannot cherry-pick root commit ${oid}. Root commits have no parents.`
    );
    this.code = this.name = CherryPickRootCommitError.code;
    this.data = { oid };
  }
}
/** @type {'CherryPickRootCommitError'} */
CherryPickRootCommitError.code = 'CherryPickRootCommitError';

class CommitNotFetchedError extends BaseError {
  /**
   * @param {string} ref
   * @param {string} oid
   */
  constructor(ref, oid) {
    super(
      `Failed to checkout "${ref}" because commit ${oid} is not available locally. Do a git fetch to make the branch available locally.`
    );
    this.code = this.name = CommitNotFetchedError.code;
    this.data = { ref, oid };
  }
}
/** @type {'CommitNotFetchedError'} */
CommitNotFetchedError.code = 'CommitNotFetchedError';

class EmptyCommitError extends BaseError {
  constructor() {
    super('Cannot create an empty commit when disallowEmpty is true.');
    this.code = this.name = EmptyCommitError.code;
    this.data = {};
  }
}
/** @type {'EmptyCommitError'} */
EmptyCommitError.code = 'EmptyCommitError';

class EmptyServerResponseError extends BaseError {
  constructor() {
    super(`Empty response from git server.`);
    this.code = this.name = EmptyServerResponseError.code;
    this.data = {};
  }
}
/** @type {'EmptyServerResponseError'} */
EmptyServerResponseError.code = 'EmptyServerResponseError';

class FastForwardError extends BaseError {
  constructor() {
    super(`A simple fast-forward merge was not possible.`);
    this.code = this.name = FastForwardError.code;
    this.data = {};
  }
}
/** @type {'FastForwardError'} */
FastForwardError.code = 'FastForwardError';

class GitPushError extends BaseError {
  /**
   * @param {string} prettyDetails
   * @param {PushResult} result
   */
  constructor(prettyDetails, result) {
    super(`One or more branches were not updated: ${prettyDetails}`);
    this.code = this.name = GitPushError.code;
    this.data = { prettyDetails, result };
  }
}
/** @type {'GitPushError'} */
GitPushError.code = 'GitPushError';

class HttpError extends BaseError {
  /**
   * @param {number} statusCode
   * @param {string} statusMessage
   * @param {string} response
   */
  constructor(statusCode, statusMessage, response) {
    super(`HTTP Error: ${statusCode} ${statusMessage}`);
    this.code = this.name = HttpError.code;
    this.data = { statusCode, statusMessage, response };
  }
}
/** @type {'HttpError'} */
HttpError.code = 'HttpError';

class InvalidFilepathError extends BaseError {
  /**
   * @param {'leading-slash'|'trailing-slash'|'directory'} [reason]
   */
  constructor(reason) {
    let message = 'invalid filepath';
    if (reason === 'leading-slash' || reason === 'trailing-slash') {
      message = `"filepath" parameter should not include leading or trailing directory separators because these can cause problems on some platforms.`;
    } else if (reason === 'directory') {
      message = `"filepath" should not be a directory.`;
    }
    super(message);
    this.code = this.name = InvalidFilepathError.code;
    this.data = { reason };
  }
}
/** @type {'InvalidFilepathError'} */
InvalidFilepathError.code = 'InvalidFilepathError';

class MaxDepthError extends BaseError {
  /**
   * @param {number} depth
   */
  constructor(depth) {
    super(`Maximum search depth of ${depth} exceeded.`);
    this.code = this.name = MaxDepthError.code;
    this.data = { depth };
  }
}
/** @type {'MaxDepthError'} */
MaxDepthError.code = 'MaxDepthError';

class MergeNotSupportedError extends BaseError {
  constructor() {
    super(`Merges with conflicts are not supported yet.`);
    this.code = this.name = MergeNotSupportedError.code;
    this.data = {};
  }
}
/** @type {'MergeNotSupportedError'} */
MergeNotSupportedError.code = 'MergeNotSupportedError';

class MergeConflictError extends BaseError {
  /**
   * @param {Array<string>} filepaths
   * @param {Array<string>} bothModified
   * @param {Array<string>} deleteByUs
   * @param {Array<string>} deleteByTheirs
   */
  constructor(filepaths, bothModified, deleteByUs, deleteByTheirs) {
    super(
      `Automatic merge failed with one or more merge conflicts in the following files: ${filepaths.toString()}. Fix conflicts then commit the result.`
    );
    this.code = this.name = MergeConflictError.code;
    this.data = { filepaths, bothModified, deleteByUs, deleteByTheirs };
  }
}
/** @type {'MergeConflictError'} */
MergeConflictError.code = 'MergeConflictError';

class MissingNameError extends BaseError {
  /**
   * @param {'author'|'committer'|'tagger'} role
   */
  constructor(role) {
    super(
      `No name was provided for ${role} in the argument or in the .git/config file.`
    );
    this.code = this.name = MissingNameError.code;
    this.data = { role };
  }
}
/** @type {'MissingNameError'} */
MissingNameError.code = 'MissingNameError';

class MissingParameterError extends BaseError {
  /**
   * @param {string} parameter
   */
  constructor(parameter) {
    super(
      `The function requires a "${parameter}" parameter but none was provided.`
    );
    this.code = this.name = MissingParameterError.code;
    this.data = { parameter };
  }
}
/** @type {'MissingParameterError'} */
MissingParameterError.code = 'MissingParameterError';

class MultipleGitError extends BaseError {
  /**
   * @param {Error[]} errors
   * @param {string} message
   */
  constructor(errors) {
    super(
      `There are multiple errors that were thrown by the method. Please refer to the "errors" property to see more`
    );
    this.code = this.name = MultipleGitError.code;
    this.data = { errors };
    this.errors = errors;
  }
}
/** @type {'MultipleGitError'} */
MultipleGitError.code = 'MultipleGitError';

class ParseError extends BaseError {
  /**
   * @param {string} expected
   * @param {string} actual
   */
  constructor(expected, actual) {
    super(`Expected "${expected}" but received "${actual}".`);
    this.code = this.name = ParseError.code;
    this.data = { expected, actual };
  }
}
/** @type {'ParseError'} */
ParseError.code = 'ParseError';

class PushRejectedError extends BaseError {
  /**
   * @param {'not-fast-forward'|'tag-exists'} reason
   */
  constructor(reason) {
    let message = '';
    if (reason === 'not-fast-forward') {
      message = ' because it was not a simple fast-forward';
    } else if (reason === 'tag-exists') {
      message = ' because tag already exists';
    }
    super(`Push rejected${message}. Use "force: true" to override.`);
    this.code = this.name = PushRejectedError.code;
    this.data = { reason };
  }
}
/** @type {'PushRejectedError'} */
PushRejectedError.code = 'PushRejectedError';

class RemoteCapabilityError extends BaseError {
  /**
   * @param {'shallow'|'deepen-since'|'deepen-not'|'deepen-relative'} capability
   * @param {'depth'|'since'|'exclude'|'relative'} parameter
   */
  constructor(capability, parameter) {
    super(
      `Remote does not support the "${capability}" so the "${parameter}" parameter cannot be used.`
    );
    this.code = this.name = RemoteCapabilityError.code;
    this.data = { capability, parameter };
  }
}
/** @type {'RemoteCapabilityError'} */
RemoteCapabilityError.code = 'RemoteCapabilityError';

class SmartHttpError extends BaseError {
  /**
   * @param {string} preview
   * @param {string} response
   */
  constructor(preview, response) {
    super(
      `Remote did not reply using the "smart" HTTP protocol. Expected "001e# service=git-upload-pack" but received: ${preview}`
    );
    this.code = this.name = SmartHttpError.code;
    this.data = { preview, response };
  }
}
/** @type {'SmartHttpError'} */
SmartHttpError.code = 'SmartHttpError';

class UnknownTransportError extends BaseError {
  /**
   * @param {string} url
   * @param {string} transport
   * @param {string} [suggestion]
   */
  constructor(url, transport, suggestion) {
    super(
      `Git remote "${url}" uses an unrecognized transport protocol: "${transport}"`
    );
    this.code = this.name = UnknownTransportError.code;
    this.data = { url, transport, suggestion };
  }
}
/** @type {'UnknownTransportError'} */
UnknownTransportError.code = 'UnknownTransportError';

class UrlParseError extends BaseError {
  /**
   * @param {string} url
   */
  constructor(url) {
    super(`Cannot parse remote URL: "${url}"`);
    this.code = this.name = UrlParseError.code;
    this.data = { url };
  }
}
/** @type {'UrlParseError'} */
UrlParseError.code = 'UrlParseError';

class UserCanceledError extends BaseError {
  constructor() {
    super(`The operation was canceled.`);
    this.code = this.name = UserCanceledError.code;
    this.data = {};
  }
}
/** @type {'UserCanceledError'} */
UserCanceledError.code = 'UserCanceledError';

class IndexResetError extends BaseError {
  /**
   * @param {Array<string>} filepaths
   */
  constructor(filepath) {
    super(
      `Could not merge index: Entry for '${filepath}' is not up to date. Either reset the index entry to HEAD, or stage your unstaged changes.`
    );
    this.code = this.name = IndexResetError.code;
    this.data = { filepath };
  }
}
/** @type {'IndexResetError'} */
IndexResetError.code = 'IndexResetError';

class NoCommitError extends BaseError {
  /**
   * @param {string} ref
   */
  constructor(ref) {
    super(
      `"${ref}" does not point to any commit. You're maybe working on a repository with no commits yet. `
    );
    this.code = this.name = NoCommitError.code;
    this.data = { ref };
  }
}
/** @type {'NoCommitError'} */
NoCommitError.code = 'NoCommitError';



var Errors = /*#__PURE__*/Object.freeze({
  __proto__: null,
  AlreadyExistsError: AlreadyExistsError,
  AmbiguousError: AmbiguousError,
  CheckoutConflictError: CheckoutConflictError,
  CherryPickMergeCommitError: CherryPickMergeCommitError,
  CherryPickRootCommitError: CherryPickRootCommitError,
  CommitNotFetchedError: CommitNotFetchedError,
  EmptyCommitError: EmptyCommitError,
  EmptyServerResponseError: EmptyServerResponseError,
  FastForwardError: FastForwardError,
  GitPushError: GitPushError,
  HttpError: HttpError,
  InternalError: InternalError,
  InvalidFilepathError: InvalidFilepathError,
  InvalidOidError: InvalidOidError,
  InvalidRefNameError: InvalidRefNameError,
  MaxDepthError: MaxDepthError,
  MergeNotSupportedError: MergeNotSupportedError,
  MergeConflictError: MergeConflictError,
  MissingNameError: MissingNameError,
  MissingParameterError: MissingParameterError,
  MultipleGitError: MultipleGitError,
  NoRefspecError: NoRefspecError,
  NotFoundError: NotFoundError,
  ObjectTypeError: ObjectTypeError,
  ParseError: ParseError,
  PushRejectedError: PushRejectedError,
  RemoteCapabilityError: RemoteCapabilityError,
  SmartHttpError: SmartHttpError,
  UnknownTransportError: UnknownTransportError,
  UnsafeFilepathError: UnsafeFilepathError,
  UrlParseError: UrlParseError,
  UserCanceledError: UserCanceledError,
  UnmergedPathsError: UnmergedPathsError,
  IndexResetError: IndexResetError,
  NoCommitError: NoCommitError
});

function formatAuthor({ name, email, timestamp, timezoneOffset }) {
  timezoneOffset = formatTimezoneOffset(timezoneOffset);
  return `${name} <${email}> ${timestamp} ${timezoneOffset}`
}

// The amount of effort that went into crafting these cases to handle
// -0 (just so we don't lose that information when parsing and reconstructing)
// but can also default to +0 was extraordinary.

function formatTimezoneOffset(minutes) {
  const sign = simpleSign(negateExceptForZero(minutes));
  minutes = Math.abs(minutes);
  const hours = Math.floor(minutes / 60);
  minutes -= hours * 60;
  let strHours = String(hours);
  let strMinutes = String(minutes);
  if (strHours.length < 2) strHours = '0' + strHours;
  if (strMinutes.length < 2) strMinutes = '0' + strMinutes;
  return (sign === -1 ? '-' : '+') + strHours + strMinutes
}

function simpleSign(n) {
  return Math.sign(n) || (Object.is(n, -0) ? -1 : 1)
}

function negateExceptForZero(n) {
  return n === 0 ? n : -n
}

function normalizeNewlines(str) {
  // remove all <CR>
  str = str.replace(/\r/g, '');
  // no extra newlines up front
  str = str.replace(/^\n+/, '');
  // and a single newline at the end
  str = str.replace(/\n+$/, '') + '\n';
  return str
}

function parseAuthor(author) {
  const [, name, email, timestamp, offset] = author.match(
    /^(.*) <(.*)> (.*) (.*)$/
  );
  return {
    name,
    email,
    timestamp: Number(timestamp),
    timezoneOffset: parseTimezoneOffset(offset),
  }
}

// The amount of effort that went into crafting these cases to handle
// -0 (just so we don't lose that information when parsing and reconstructing)
// but can also default to +0 was extraordinary.

function parseTimezoneOffset(offset) {
  let [, sign, hours, minutes] = offset.match(/(\+|-)(\d\d)(\d\d)/);
  minutes = (sign === '+' ? 1 : -1) * (Number(hours) * 60 + Number(minutes));
  return negateExceptForZero$1(minutes)
}

function negateExceptForZero$1(n) {
  return n === 0 ? n : -n
}

class GitAnnotatedTag {
  constructor(tag) {
    if (typeof tag === 'string') {
      this._tag = tag;
    } else if (Buffer.isBuffer(tag)) {
      this._tag = tag.toString('utf8');
    } else if (typeof tag === 'object') {
      this._tag = GitAnnotatedTag.render(tag);
    } else {
      throw new InternalError(
        'invalid type passed to GitAnnotatedTag constructor'
      )
    }
  }

  static from(tag) {
    return new GitAnnotatedTag(tag)
  }

  static render(obj) {
    return `object ${obj.object}
type ${obj.type}
tag ${obj.tag}
tagger ${formatAuthor(obj.tagger)}

${obj.message}
${obj.gpgsig ? obj.gpgsig : ''}`
  }

  justHeaders() {
    return this._tag.slice(0, this._tag.indexOf('\n\n'))
  }

  message() {
    const tag = this.withoutSignature();
    return tag.slice(tag.indexOf('\n\n') + 2)
  }

  parse() {
    return Object.assign(this.headers(), {
      message: this.message(),
      gpgsig: this.gpgsig(),
    })
  }

  render() {
    return this._tag
  }

  headers() {
    const headers = this.justHeaders().split('\n');
    const hs = [];
    for (const h of headers) {
      if (h[0] === ' ') {
        // combine with previous header (without space indent)
        hs[hs.length - 1] += '\n' + h.slice(1);
      } else {
        hs.push(h);
      }
    }
    const obj = {};
    for (const h of hs) {
      const key = h.slice(0, h.indexOf(' '));
      const value = h.slice(h.indexOf(' ') + 1);
      if (Array.isArray(obj[key])) {
        obj[key].push(value);
      } else {
        obj[key] = value;
      }
    }
    if (obj.tagger) {
      obj.tagger = parseAuthor(obj.tagger);
    }
    if (obj.committer) {
      obj.committer = parseAuthor(obj.committer);
    }
    return obj
  }

  withoutSignature() {
    const tag = normalizeNewlines(this._tag);
    if (tag.indexOf('\n-----BEGIN PGP SIGNATURE-----') === -1) return tag
    return tag.slice(0, tag.lastIndexOf('\n-----BEGIN PGP SIGNATURE-----'))
  }

  gpgsig() {
    if (this._tag.indexOf('\n-----BEGIN PGP SIGNATURE-----') === -1) return
    const signature = this._tag.slice(
      this._tag.indexOf('-----BEGIN PGP SIGNATURE-----'),
      this._tag.indexOf('-----END PGP SIGNATURE-----') +
        '-----END PGP SIGNATURE-----'.length
    );
    return normalizeNewlines(signature)
  }

  payload() {
    return this.withoutSignature() + '\n'
  }

  toObject() {
    return Buffer.from(this._tag, 'utf8')
  }

  static async sign(tag, sign, secretKey) {
    const payload = tag.payload();
    let { signature } = await sign({ payload, secretKey });
    // renormalize the line endings to the one true line-ending
    signature = normalizeNewlines(signature);
    const signedTag = payload + signature;
    // return a new tag object
    return GitAnnotatedTag.from(signedTag)
  }
}

function indent(str) {
  return (
    str
      .trim()
      .split('\n')
      .map(x => ' ' + x)
      .join('\n') + '\n'
  )
}

function outdent(str) {
  return str
    .split('\n')
    .map(x => x.replace(/^ /, ''))
    .join('\n')
}

class GitCommit {
  constructor(commit) {
    if (typeof commit === 'string') {
      this._commit = commit;
    } else if (Buffer.isBuffer(commit)) {
      this._commit = commit.toString('utf8');
    } else if (typeof commit === 'object') {
      this._commit = GitCommit.render(commit);
    } else {
      throw new InternalError('invalid type passed to GitCommit constructor')
    }
  }

  static fromPayloadSignature({ payload, signature }) {
    const headers = GitCommit.justHeaders(payload);
    const message = GitCommit.justMessage(payload);
    const commit = normalizeNewlines(
      headers + '\ngpgsig' + indent(signature) + '\n' + message
    );
    return new GitCommit(commit)
  }

  static from(commit) {
    return new GitCommit(commit)
  }

  toObject() {
    return Buffer.from(this._commit, 'utf8')
  }

  // Todo: allow setting the headers and message
  headers() {
    return this.parseHeaders()
  }

  // Todo: allow setting the headers and message
  message() {
    return GitCommit.justMessage(this._commit)
  }

  parse() {
    return Object.assign({ message: this.message() }, this.headers())
  }

  static justMessage(commit) {
    return normalizeNewlines(commit.slice(commit.indexOf('\n\n') + 2))
  }

  static justHeaders(commit) {
    return commit.slice(0, commit.indexOf('\n\n'))
  }

  parseHeaders() {
    const headers = GitCommit.justHeaders(this._commit).split('\n');
    const hs = [];
    for (const h of headers) {
      if (h[0] === ' ') {
        // combine with previous header (without space indent)
        hs[hs.length - 1] += '\n' + h.slice(1);
      } else {
        hs.push(h);
      }
    }
    const obj = {
      parent: [],
    };
    for (const h of hs) {
      const key = h.slice(0, h.indexOf(' '));
      const value = h.slice(h.indexOf(' ') + 1);
      if (Array.isArray(obj[key])) {
        obj[key].push(value);
      } else {
        obj[key] = value;
      }
    }
    if (obj.author) {
      obj.author = parseAuthor(obj.author);
    }
    if (obj.committer) {
      obj.committer = parseAuthor(obj.committer);
    }
    return obj
  }

  static renderHeaders(obj) {
    let headers = '';
    if (obj.tree) {
      headers += `tree ${obj.tree}\n`;
    } else {
      headers += `tree 4b825dc642cb6eb9a060e54bf8d69288fbee4904\n`; // the null tree
    }
    if (obj.parent) {
      if (obj.parent.length === undefined) {
        throw new InternalError(`commit 'parent' property should be an array`)
      }
      for (const p of obj.parent) {
        headers += `parent ${p}\n`;
      }
    }
    const author = obj.author;
    headers += `author ${formatAuthor(author)}\n`;
    const committer = obj.committer || obj.author;
    headers += `committer ${formatAuthor(committer)}\n`;
    if (obj.gpgsig) {
      headers += 'gpgsig' + indent(obj.gpgsig);
    }
    return headers
  }

  static render(obj) {
    return GitCommit.renderHeaders(obj) + '\n' + normalizeNewlines(obj.message)
  }

  render() {
    return this._commit
  }

  withoutSignature() {
    const commit = normalizeNewlines(this._commit);
    if (commit.indexOf('\ngpgsig') === -1) return commit
    const headers = commit.slice(0, commit.indexOf('\ngpgsig'));
    const message = commit.slice(
      commit.indexOf('-----END PGP SIGNATURE-----\n') +
        '-----END PGP SIGNATURE-----\n'.length
    );
    return normalizeNewlines(headers + '\n' + message)
  }

  isolateSignature() {
    const signature = this._commit.slice(
      this._commit.indexOf('-----BEGIN PGP SIGNATURE-----'),
      this._commit.indexOf('-----END PGP SIGNATURE-----') +
        '-----END PGP SIGNATURE-----'.length
    );
    return outdent(signature)
  }

  static async sign(commit, sign, secretKey) {
    const payload = commit.withoutSignature();
    const message = GitCommit.justMessage(commit._commit);
    let { signature } = await sign({ payload, secretKey });
    // renormalize the line endings to the one true line-ending
    signature = normalizeNewlines(signature);
    const headers = GitCommit.justHeaders(commit._commit);
    const signedCommit =
      headers + '\n' + 'gpgsig' + indent(signature) + '\n' + message;
    // return a new commit object
    return GitCommit.from(signedCommit)
  }
}

async function resolveTree({ fs, cache, gitdir, oid }) {
  // Empty tree - bypass `readObject`
  if (oid === '4b825dc642cb6eb9a060e54bf8d69288fbee4904') {
    return { tree: GitTree.from([]), oid }
  }
  const { type, object } = await _readObject({ fs, cache, gitdir, oid });
  // Resolve annotated tag objects to whatever
  if (type === 'tag') {
    oid = GitAnnotatedTag.from(object).parse().object;
    return resolveTree({ fs, cache, gitdir, oid })
  }
  // Resolve commits to trees
  if (type === 'commit') {
    oid = GitCommit.from(object).parse().tree;
    return resolveTree({ fs, cache, gitdir, oid })
  }
  if (type !== 'tree') {
    throw new ObjectTypeError(oid, type, 'tree')
  }
  return { tree: GitTree.from(object), oid }
}

class GitWalkerRepo {
  constructor({ fs, gitdir, ref, cache }) {
    this.fs = fs;
    this.cache = cache;
    this.gitdir = gitdir;
    this.mapPromise = (async () => {
      const map = new Map();
      let oid;
      try {
        oid = await GitRefManager.resolve({ fs, gitdir, ref });
      } catch (e) {
        // Only a branch that has no commits yet gets the empty tree. Anything
        // else that fails to resolve is a ref the caller got wrong, and
        // swallowing it here would walk an empty tree instead of saying so.
        if (
          e instanceof NotFoundError &&
          (await GitRefManager.isUnbornBranch({ fs, gitdir, ref }))
        ) {
          oid = '4b825dc642cb6eb9a060e54bf8d69288fbee4904';
        } else {
          throw e
        }
      }
      const tree = await resolveTree({ fs, cache: this.cache, gitdir, oid });
      tree.type = 'tree';
      tree.mode = '40000';
      map.set('.', tree);
      return map
    })();
    const walker = this;
    this.ConstructEntry = class TreeEntry {
      constructor(fullpath) {
        this._fullpath = fullpath;
        this._type = false;
        this._mode = false;
        this._stat = false;
        this._content = false;
        this._oid = false;
      }

      async type() {
        return walker.type(this)
      }

      async mode() {
        return walker.mode(this)
      }

      async stat() {
        return walker.stat(this)
      }

      async content() {
        return walker.content(this)
      }

      async oid() {
        return walker.oid(this)
      }
    };
  }

  async readdir(entry) {
    const filepath = entry._fullpath;
    const { fs, cache, gitdir } = this;
    const map = await this.mapPromise;
    const obj = map.get(filepath);
    if (!obj) throw new Error(`No obj for ${filepath}`)
    const oid = obj.oid;
    if (!oid) throw new Error(`No oid for obj ${JSON.stringify(obj)}`)
    if (obj.type !== 'tree') {
      // TODO: support submodules (type === 'commit')
      return null
    }
    const { type, object } = await _readObject({ fs, cache, gitdir, oid });
    if (type !== obj.type) {
      throw new ObjectTypeError(oid, type, obj.type)
    }
    const tree = GitTree.from(object);
    // cache all entries
    for (const entry of tree) {
      map.set(join(filepath, entry.path), entry);
    }
    return tree.entries().map(entry => join(filepath, entry.path))
  }

  async type(entry) {
    if (entry._type === false) {
      const map = await this.mapPromise;
      const { type } = map.get(entry._fullpath);
      entry._type = type;
    }
    return entry._type
  }

  async mode(entry) {
    if (entry._mode === false) {
      const map = await this.mapPromise;
      const { mode } = map.get(entry._fullpath);
      entry._mode = normalizeMode(parseInt(mode, 8));
    }
    return entry._mode
  }

  async stat(_entry) {}

  async content(entry) {
    if (entry._content === false) {
      const map = await this.mapPromise;
      const { fs, cache, gitdir } = this;
      const obj = map.get(entry._fullpath);
      const oid = obj.oid;
      const { type, object } = await _readObject({ fs, cache, gitdir, oid });
      if (type !== 'blob') {
        entry._content = undefined;
      } else {
        entry._content = new Uint8Array(object);
      }
    }
    return entry._content
  }

  async oid(entry) {
    if (entry._oid === false) {
      const map = await this.mapPromise;
      const obj = map.get(entry._fullpath);
      entry._oid = obj.oid;
    }
    return entry._oid
  }
}

// @ts-check

/**
 * @param {object} args
 * @param {string} [args.ref='HEAD']
 * @returns {Walker}
 */
function TREE({ ref = 'HEAD' } = {}) {
  const o = Object.create(null);
  Object.defineProperty(o, GitWalkSymbol, {
    value: function ({ fs, gitdir, cache }) {
      return new GitWalkerRepo({ fs, gitdir, ref, cache })
    },
  });
  Object.freeze(o);
  return o
}

// @ts-check

class GitWalkerFs {
  constructor({ fs, dir, gitdir, cache, refresh = true }) {
    this.fs = fs;
    this.cache = cache;
    this.dir = dir;
    this.gitdir = gitdir;
    this.refresh = refresh;

    this.config = null;
    const walker = this;
    this.ConstructEntry = class WorkdirEntry {
      constructor(fullpath) {
        this._fullpath = fullpath;
        this._type = false;
        this._mode = false;
        this._stat = false;
        this._content = false;
        this._oid = false;
      }

      async type() {
        return walker.type(this)
      }

      async mode() {
        return walker.mode(this)
      }

      async stat() {
        return walker.stat(this)
      }

      async content() {
        return walker.content(this)
      }

      async oid() {
        return walker.oid(this)
      }
    };
  }

  async readdir(entry) {
    if ((await entry.type()) !== 'tree') return null
    const filepath = entry._fullpath;
    const { fs, dir } = this;
    const names = await fs.readdir(join(dir, filepath));
    if (names === null) return null
    return names.map(name => join(filepath, name))
  }

  async type(entry) {
    if (entry._type === false) {
      await entry.stat();
    }
    return entry._type
  }

  async mode(entry) {
    if (entry._mode === false) {
      await entry.stat();
    }
    return entry._mode
  }

  async stat(entry) {
    if (entry._stat === false) {
      const { fs, dir } = this;
      let stat = await fs.lstat(`${dir}/${entry._fullpath}`);
      if (!stat) {
        throw new Error(
          `ENOENT: no such file or directory, lstat '${entry._fullpath}'`
        )
      }
      let type = stat.isDirectory() ? 'tree' : 'blob';
      if (type === 'blob' && !stat.isFile() && !stat.isSymbolicLink()) {
        type = 'special';
      }
      entry._type = type;
      stat = normalizeStats(stat);
      entry._mode = stat.mode;
      // workaround for a BrowserFS edge case
      if (stat.size === -1 && entry._actualSize) {
        stat.size = entry._actualSize;
      }
      entry._stat = stat;
    }
    return entry._stat
  }

  async content(entry) {
    if (entry._content === false) {
      const { fs, dir, gitdir } = this;
      if ((await entry.type()) === 'tree') {
        entry._content = undefined;
      } else {
        let content;
        if ((await entry.mode()) >> 12 === 0b1010) {
          content = await fs.readlink(`${dir}/${entry._fullpath}`);
        } else {
          const config = await this._getGitConfig(fs, gitdir);
          const autocrlf = await config.get('core.autocrlf');
          content = await fs.read(`${dir}/${entry._fullpath}`, { autocrlf });
        }
        // workaround for a BrowserFS edge case
        entry._actualSize = content.length;
        if (entry._stat && entry._stat.size === -1) {
          entry._stat.size = entry._actualSize;
        }
        entry._content = new Uint8Array(content);
      }
    }
    return entry._content
  }

  async oid(entry) {
    if (entry._oid === false) {
      const self = this;
      const { fs, gitdir, cache } = this;
      let oid;
      // See if we can use the SHA1 hash in the index.
      await GitIndexManager.acquire(
        { fs, gitdir, cache },
        async function (index) {
          const stage = index.entriesMap.get(entry._fullpath);
          const stats = await entry.stat();
          const config = await self._getGitConfig(fs, gitdir);
          const filemode = await config.get('core.filemode');
          const trustino =
            typeof process !== 'undefined'
              ? !(process.platform === 'win32')
              : true;
          if (!stage || compareStats(stats, stage, filemode, trustino)) {
            const content = await entry.content();
            if (content === undefined) {
              oid = undefined;
            } else {
              oid = await shasum(
                GitObject.wrap({ type: 'blob', object: content })
              );
              // Update the stats in the index so we will get a "cache hit" next time
              // 1) if we can (because the oid and mode are the same)
              // 2) and only if we need to (because other stats differ)
              // 3) and only if the caller opted in to refreshing the index
              if (
                self.refresh &&
                stage &&
                oid === stage.oid &&
                (!filemode || stats.mode === stage.mode) &&
                compareStats(stats, stage, filemode, trustino)
              ) {
                index.insert({
                  filepath: entry._fullpath,
                  stats,
                  oid,
                });
              }
            }
          } else {
            // Use the index SHA1 rather than compute it
            oid = stage.oid;
          }
        }
      );
      entry._oid = oid;
    }
    return entry._oid
  }

  async _getGitConfig(fs, gitdir) {
    if (this.config) {
      return this.config
    }
    this.config = await GitConfigManager.get({ fs, gitdir });
    return this.config
  }
}

// @ts-check

/**
 * @param {object} [opts]
 * @param {boolean} [opts.refresh=true] - When false, suppress the stat-cache
 *   refresh that would rewrite `.git/index` when a working-tree file's stat
 *   info has drifted but its content still matches the staged blob.
 * @returns {Walker}
 */
function WORKDIR({ refresh = true } = {}) {
  const o = Object.create(null);
  Object.defineProperty(o, GitWalkSymbol, {
    value: function ({ fs, dir, gitdir, cache }) {
      return new GitWalkerFs({ fs, dir, gitdir, cache, refresh })
    },
  });
  Object.freeze(o);
  return o
}

// @ts-check

// https://dev.to/namirsab/comment/2050
function arrayRange(start, end) {
  const length = end - start;
  return Array.from({ length }, (_, i) => start + i)
}

// TODO: Should I just polyfill Array.flat?
const flat =
  typeof Array.prototype.flat === 'undefined'
    ? entries => entries.reduce((acc, x) => acc.concat(x), [])
    : entries => entries.flat();

// This is convenient for computing unions/joins of sorted lists.
class RunningMinimum {
  constructor() {
    // Using a getter for 'value' would just bloat the code.
    // You know better than to set it directly right?
    this.value = null;
  }

  consider(value) {
    if (value === null || value === undefined) return
    if (this.value === null) {
      this.value = value;
    } else if (value < this.value) {
      this.value = value;
    }
  }

  reset() {
    this.value = null;
  }
}

// Take an array of length N of
//   iterators of length Q_n
//     of strings
// and return an iterator of length max(Q_n) for all n
//   of arrays of length N
//     of string|null who all have the same string value
function* unionOfIterators(sets) {
  /* NOTE: We can assume all arrays are sorted.
   * Indexes are sorted because they are defined that way:
   *
   * > Index entries are sorted in ascending order on the name field,
   * > interpreted as a string of unsigned bytes (i.e. memcmp() order, no
   * > localization, no special casing of directory separator '/'). Entries
   * > with the same name are sorted by their stage field.
   *
   * Trees should be sorted because they are created directly from indexes.
   * They definitely should be sorted, or else they wouldn't have a unique SHA1.
   * So that would be very naughty on the part of the tree-creator.
   *
   * Lastly, the working dir entries are sorted because I choose to sort them
   * in my FileSystem.readdir() implementation.
   */

  // Init
  const min = new RunningMinimum();
  let minimum;
  const heads = [];
  const numsets = sets.length;
  for (let i = 0; i < numsets; i++) {
    // Abuse the fact that iterators continue to return 'undefined' for value
    // once they are done
    heads[i] = sets[i].next().value;
    if (heads[i] !== undefined) {
      min.consider(heads[i]);
    }
  }
  if (min.value === null) return
  // Iterate
  while (true) {
    const result = [];
    minimum = min.value;
    min.reset();
    for (let i = 0; i < numsets; i++) {
      if (heads[i] !== undefined && heads[i] === minimum) {
        result[i] = heads[i];
        heads[i] = sets[i].next().value;
      } else {
        // A little hacky, but eh
        result[i] = null;
      }
      if (heads[i] !== undefined) {
        min.consider(heads[i]);
      }
    }
    yield result;
    if (min.value === null) return
  }
}

// @ts-check

/**
 * @param {object} args
 * @param {import('../models/FileSystem.js').FileSystem} args.fs
 * @param {object} args.cache
 * @param {string} [args.dir]
 * @param {string} [args.gitdir=join(dir,'.git')]
 * @param {Walker[]} args.trees
 * @param {WalkerMap} [args.map]
 * @param {WalkerReduce} [args.reduce]
 * @param {WalkerIterate} [args.iterate]
 *
 * @returns {Promise<any>} The finished tree-walking result
 *
 * @see {WalkerMap}
 *
 */
async function _walk({
  fs,
  cache,
  dir,
  gitdir,
  trees,
  // @ts-ignore
  map = async (_, entry) => entry,
  // The default reducer is a flatmap that filters out undefineds.
  reduce = async (parent, children) => {
    const flatten = flat(children);
    if (parent !== undefined) flatten.unshift(parent);
    return flatten
  },
  // The default iterate function walks all children concurrently
  iterate = (walk, children) => Promise.all([...children].map(walk)),
}) {
  const walkers = trees.map(proxy =>
    proxy[GitWalkSymbol]({ fs, dir, gitdir, cache })
  );

  const root = new Array(walkers.length).fill('.');
  const range = arrayRange(0, walkers.length);
  const unionWalkerFromReaddir = async entries => {
    range.forEach(i => {
      const entry = entries[i];
      entries[i] = entry && new walkers[i].ConstructEntry(entry);
    });
    const subdirs = await Promise.all(
      range.map(i => {
        const entry = entries[i];
        return entry ? walkers[i].readdir(entry) : []
      })
    );
    // Now process child directories
    const iterators = subdirs.map(array => {
      return (array === null ? [] : array)[Symbol.iterator]()
    });

    return {
      entries,
      children: unionOfIterators(iterators),
    }
  };

  const walk = async root => {
    const { entries, children } = await unionWalkerFromReaddir(root);
    const fullpath = entries.find(entry => entry && entry._fullpath)._fullpath;
    const parent = await map(fullpath, entries);
    if (parent !== null) {
      let walkedChildren = await iterate(walk, children);
      walkedChildren = walkedChildren.filter(x => x !== undefined);
      return reduce(parent, walkedChildren)
    }
  };
  return walk(root)
}

/**
 * Recursively creates the directory at `filepath`, creating any missing parent
 * directories along the way. This is a portable replacement for
 * `fs.mkdir(path, { recursive: true })`: recursive `mkdir` is NOT part of
 * isomorphic-git's required `fs` contract (see docs/fs.md — `mkdir` is only
 * `mkdir(path[, mode])`) and is unimplemented by some backends such as
 * lightning-fs, so we build it here on top of a single-level `mkdir(path)`
 * primitive only — mirroring how `rmRecursive` provides `rm({ recursive: true })`.
 *
 * It takes the raw single-level `mkdir` *function* (typically `fs._mkdir`)
 * rather than the FileSystem wrapper, to stay decoupled from that type.
 *
 * `EEXIST` is treated as success, so two callers concurrently creating the same
 * directory (e.g. several reflog writes into `.git/logs/refs/*` during a stash)
 * don't fail each other. On backends whose layers are only eventually
 * consistent — e.g. an async copy-on-write overlay — a just-created parent may
 * not yet be visible when its child is created, so `mkdir` can throw a
 * transient `ENOENT`; those are retried a bounded number of times rather than
 * surfaced as a spurious failure.
 *
 * @param {(filepath: string) => Promise<unknown>} mkdir - Creates a single directory (non-recursive).
 * @param {string} filepath - The directory to create.
 * @param {number} [retries=10] - Max transient-ENOENT retries after the parent exists.
 * @returns {Promise<void>}
 */
async function mkdirp(mkdir, filepath, retries = 10) {
  try {
    await mkdir(filepath);
  } catch (err) {
    // Some fs implementations signal success by yielding a null error.
    if (err === null) return
    // The directory already exists — that's fine.
    if (err.code === 'EEXIST') return
    // Anything other than a missing parent is a real error.
    if (err.code !== 'ENOENT') throw err
    const parent = dirname(filepath);
    // Stop if we've walked past the filesystem root.
    if (parent === '.' || parent === '/' || parent === filepath) throw err
    // Create the missing parent(s) first, honoring the same retry budget.
    await mkdirp(mkdir, parent, retries);
    // Then (re)create this directory. On an eventually-consistent backend the
    // parent may not be visible immediately after its mkdir resolves, so a
    // repeated ENOENT here is transient — retry a bounded number of times,
    // yielding between attempts so the pending write can settle.
    for (let attempt = 0; ; attempt++) {
      try {
        await mkdir(filepath);
        return
      } catch (err2) {
        if (err2 === null || err2.code === 'EEXIST') return
        if (err2.code === 'ENOENT' && attempt < retries) {
          // Give the backend a turn of the event loop to become consistent.
          await new Promise(resolve => setTimeout(resolve, 0));
          continue
        }
        throw err2
      }
    }
  }
}

/**
 * Removes the directory at the specified filepath recursively. Used internally to replicate the behavior of
 * fs.promises.rm({ recursive: true, force: true }) from Node.js 14 and above when not available. If the provided
 * filepath resolves to a file, it will be removed.
 *
 * @param {import('../models/FileSystem.js').FileSystem} fs
 * @param {string} filepath - The file or directory to remove.
 */
async function rmRecursive(fs, filepath) {
  const entries = await fs.readdir(filepath);
  if (entries == null) {
    await fs.rm(filepath);
  } else if (entries.length) {
    await Promise.all(
      entries.map(entry => {
        const subpath = join(filepath, entry);
        return fs.lstat(subpath).then(stat => {
          if (!stat) return
          return stat.isDirectory() ? rmRecursive(fs, subpath) : fs.rm(subpath)
        })
      })
    ).then(() => fs.rmdir(filepath));
  } else {
    await fs.rmdir(filepath);
  }
}

function isPromiseLike(obj) {
  return isObject(obj) && isFunction(obj.then) && isFunction(obj.catch)
}

function isObject(obj) {
  return obj && typeof obj === 'object'
}

function isFunction(obj) {
  return typeof obj === 'function'
}

function isPromiseFs(fs) {
  const test = targetFs => {
    try {
      // If readFile returns a promise then we can probably assume the other
      // commands do as well
      return targetFs.readFile().catch(e => e)
    } catch (e) {
      return e
    }
  };
  return isPromiseLike(test(fs))
}

// List of commands all filesystems are expected to provide. `rm` is not
// included since it may not exist and must be handled as a special case
// Likewise with `cp`.
const commands = [
  'readFile',
  'writeFile',
  'mkdir',
  'rmdir',
  'unlink',
  'stat',
  'lstat',
  'readdir',
  'readlink',
  'symlink',
];

function bindFs(target, fs) {
  if (isPromiseFs(fs)) {
    for (const command of commands) {
      target[`_${command}`] = fs[command].bind(fs);
    }
  } else {
    for (const command of commands) {
      target[`_${command}`] = pify(fs[command].bind(fs));
    }
  }

  // Handle the special cases of `rm` and `cp`
  if (isPromiseFs(fs)) {
    if (fs.cp) target._cp = fs.cp.bind(fs);
    if (fs.rm) target._rm = fs.rm.bind(fs);
    else if (fs.rmdir.length > 1) target._rm = fs.rmdir.bind(fs);
    else target._rm = rmRecursive.bind(null, target);
  } else {
    if (fs.cp) target._cp = pify(fs.cp.bind(fs));
    if (fs.rm) target._rm = pify(fs.rm.bind(fs));
    else if (fs.rmdir.length > 2) target._rm = pify(fs.rmdir.bind(fs));
    else target._rm = rmRecursive.bind(null, target);
  }
}

/**
 * A wrapper class for file system operations, providing a consistent API for both promise-based
 * and callback-based file systems. It includes utility methods for common file system tasks.
 */
class FileSystem {
  /**
   * Creates an instance of FileSystem.
   *
   * @param {Object} fs - A file system implementation to wrap.
   */
  constructor(fs) {
    if (typeof fs._original_unwrapped_fs !== 'undefined') return fs

    const promises = Object.getOwnPropertyDescriptor(fs, 'promises');
    if (promises && promises.enumerable) {
      bindFs(this, fs.promises);
    } else {
      bindFs(this, fs);
    }
    this._original_unwrapped_fs = fs;
  }

  /**
   * Return true if a file exists, false if it doesn't exist.
   * Rethrows errors that aren't related to file existence.
   *
   * @param {string} filepath - The path to the file.
   * @param {Object} [options] - Additional options.
   * @returns {Promise<boolean>} - `true` if the file exists, `false` otherwise.
   */
  async exists(filepath, options = {}) {
    try {
      await this._stat(filepath);
      return true
    } catch (err) {
      if (
        err.code === 'ENOENT' ||
        err.code === 'ENOTDIR' ||
        (err.code || '').includes('ENS')
      ) {
        return false
      } else {
        console.log('Unhandled error in "FileSystem.exists()" function', err);
        throw err
      }
    }
  }

  /**
   * Return the contents of a file if it exists, otherwise returns null.
   *
   * @param {string} filepath - The path to the file.
   * @param {Object} [options] - Options for reading the file.
   * @returns {Promise<Buffer|string|null>} - The file contents, or `null` if the file doesn't exist.
   */
  async read(filepath, options = {}) {
    try {
      let buffer = await this._readFile(filepath, options);
      if (options.autocrlf === 'true') {
        try {
          buffer = new TextDecoder('utf8', { fatal: true }).decode(buffer);
          buffer = buffer.replace(/\r\n/g, '\n');
          buffer = new TextEncoder().encode(buffer);
        } catch (error) {
          // non utf8 file
        }
      }
      // Convert plain ArrayBuffers to Buffers
      if (typeof buffer !== 'string') {
        buffer = Buffer.from(buffer);
      }
      return buffer
    } catch (err) {
      return null
    }
  }

  /**
   * Write a file (creating missing directories if need be) without throwing errors.
   *
   * @param {string} filepath - The path to the file.
   * @param {Buffer|Uint8Array|string} contents - The data to write.
   * @param {Object|string} [options] - Options for writing the file.
   * @returns {Promise<void>}
   */
  async write(filepath, contents, options = {}) {
    try {
      await this._writeFile(filepath, contents, options);
    } catch (err) {
      // Hmm. Let's try mkdirp and try again.
      await this.mkdir(dirname(filepath));
      await this._writeFile(filepath, contents, options);
    }
  }

  /**
   * Make a directory (or series of nested directories) without throwing an error if it already exists.
   *
   * @param {string} filepath - The path to the directory.
   * @returns {Promise<void>}
   */
  async mkdir(filepath) {
    // Recursively create the directory, using only single-level `_mkdir` so we
    // don't depend on `{ recursive: true }` (which isn't part of the required
    // `fs` contract — see docs/fs.md — and is unimplemented by some backends
    // e.g. lightning-fs). The helper tolerates EEXIST and the transient ENOENT
    // that eventually-consistent backends throw when a freshly created parent
    // isn't visible yet, which is what made concurrent reflog writes into
    // `.git/logs/refs/*` fail intermittently.
    await mkdirp(this._mkdir, filepath);
  }

  /**
   * Delete a file without throwing an error if it is already deleted.
   *
   * @param {string} filepath - The path to the file.
   * @returns {Promise<void>}
   */
  async rm(filepath) {
    try {
      await this._unlink(filepath);
    } catch (err) {
      if (err.code !== 'ENOENT') throw err
    }
  }

  /**
   * Delete a directory without throwing an error if it is already deleted.
   *
   * @param {string} filepath - The path to the directory.
   * @param {Object} [opts] - Options for deleting the directory.
   * @returns {Promise<void>}
   */
  async rmdir(filepath, opts) {
    try {
      if (opts && opts.recursive) {
        await this._rm(filepath, opts);
      } else {
        await this._rmdir(filepath);
      }
    } catch (err) {
      if (err.code !== 'ENOENT') throw err
    }
  }

  /**
   * Read a directory without throwing an error is the directory doesn't exist
   *
   * @param {string} filepath - The path to the directory.
   * @returns {Promise<string[]|null>} - An array of file names, or `null` if the path is not a directory.
   */
  async readdir(filepath) {
    try {
      const names = await this._readdir(filepath);
      // Ordering is not guaranteed, and system specific (Windows vs Unix)
      // so we must sort them ourselves.
      names.sort(compareStrings);
      return names
    } catch (err) {
      if (err.code === 'ENOTDIR') return null
      return []
    }
  }

  /**
   * Return a flat list of all the files nested inside a directory
   *
   * Based on an elegant concurrent recursive solution from SO
   * https://stackoverflow.com/a/45130990/2168416
   *
   * @param {string} dir - The directory to read.
   * @returns {Promise<string[]>} - A flat list of all files in the directory.
   */
  async readdirDeep(dir) {
    const subdirs = await this._readdir(dir);
    const files = await Promise.all(
      subdirs.map(async subdir => {
        const res = dir + '/' + subdir;
        return (await this._stat(res)).isDirectory()
          ? this.readdirDeep(res)
          : res
      })
    );
    return files.reduce((a, f) => a.concat(f), [])
  }

  /**
   * Return the Stats of a file/symlink if it exists, otherwise returns null.
   * Rethrows errors that aren't related to file existence.
   *
   * @param {string} filename - The path to the file or symlink.
   * @returns {Promise<Object|null>} - The stats object, or `null` if the file doesn't exist.
   */
  async lstat(filename) {
    try {
      const stats = await this._lstat(filename);
      return stats
    } catch (err) {
      if (err.code === 'ENOENT' || (err.code || '').includes('ENS')) {
        return null
      }
      throw err
    }
  }

  /**
   * Reads the contents of a symlink if it exists, otherwise returns null.
   * Rethrows errors that aren't related to file existence.
   *
   * @param {string} filename - The path to the symlink.
   * @param {Object} [opts={ encoding: 'buffer' }] - Options for reading the symlink.
   * @returns {Promise<Buffer|null>} - The symlink target, or `null` if it doesn't exist.
   */
  async readlink(filename, opts = { encoding: 'buffer' }) {
    // Note: FileSystem.readlink returns a buffer by default
    // so we can dump it into GitObject.write just like any other file.
    try {
      const link = await this._readlink(filename, opts);
      return Buffer.isBuffer(link) ? link : Buffer.from(link)
    } catch (err) {
      if (err.code === 'ENOENT' || (err.code || '').includes('ENS')) {
        return null
      }
      throw err
    }
  }

  /**
   * Write the contents of buffer to a symlink.
   *
   * @param {string} filename - The path to the symlink.
   * @param {Buffer} buffer - The symlink target.
   * @returns {Promise<void>}
   */
  async writelink(filename, buffer) {
    return this._symlink(buffer.toString('utf8'), filename)
  }
}

function assertParameter(name, value) {
  if (value === undefined) {
    throw new MissingParameterError(name)
  }
}

/**
 * discoverGitdir
 *
 * When processing git commands on a submodule or worktree, determine
 * the actual git directory based on the contents of the .git file.
 *
 * Otherwise (if sent a directory) return that directory as-is.
 *
 * A decision has to be made "in what layer will submodules be interpreted,
 * and then after that, where can the code can just stay exactly the same as before."
 * This implementation processes submodules in the front-end location of src/api/.
 * The backend of src/commands/ isn't modified. This keeps a clear division
 * of responsibilities and should be maintained.
 *
 * A consequence is that __tests__ must occasionally be informed
 * about submodules also, since those call src/commands/ directly.
 *
 *
 */

// Check if a path is absolute (Unix / or Windows drive letter like C:\ or C:/)
function isAbsolute(filepath) {
  return filepath.startsWith('/') || /^[a-zA-Z]:[\\/]/.test(filepath)
}

async function discoverGitdir({ fsp, dotgit }) {
  assertParameter('fsp', fsp);
  assertParameter('dotgit', dotgit);

  const dotgitStat = await fsp
    ._stat(dotgit)
    .catch(() => ({ isFile: () => false, isDirectory: () => false }));
  if (dotgitStat.isDirectory()) {
    return dotgit
  } else if (dotgitStat.isFile()) {
    return fsp
      ._readFile(dotgit, 'utf8')
      .then(contents => contents.trimRight().substr(8))
      .then(submoduleGitdir => {
        // Worktrees use absolute gitdir paths; submodules use relative ones.
        if (isAbsolute(submoduleGitdir)) {
          return submoduleGitdir
        }
        const gitdir = join(dirname(dotgit), submoduleGitdir);
        return gitdir
      })
  } else {
    // Neither a file nor a directory. This correlates to a "git init" scenario where it's empty.
    // This is the expected result for normal repos, and indeterminate for submodules, but
    // would be unusual with submodules.
    return dotgit
  }
}

// @ts-check
/**
 *
 * @param {WalkerEntry} entry
 * @param {WalkerEntry} base
 *
 */
async function modified(entry, base) {
  if (!entry && !base) return false
  if (entry && !base) return true
  if (!entry && base) return true
  if ((await entry.type()) === 'tree' && (await base.type()) === 'tree') {
    return false
  }
  if (
    (await entry.type()) === (await base.type()) &&
    (await entry.mode()) === (await base.mode()) &&
    (await entry.oid()) === (await base.oid())
  ) {
    return false
  }
  return true
}

// @ts-check

/**
 * Abort a merge in progress.
 *
 * Based on the behavior of git reset --merge, i.e.  "Resets the index and updates the files in the working tree that are different between <commit> and HEAD, but keeps those which are different between the index and working tree (i.e. which have changes which have not been added). If a file that is different between <commit> and the index has unstaged changes, reset is aborted."
 *
 * Essentially, abortMerge will reset any files affected by merge conflicts to their last known good version at HEAD.
 * Any unstaged changes are saved and any staged changes are reset as well.
 *
 * NOTE: The behavior of this command differs slightly from canonical git in that an error will be thrown if a file exists in the index and nowhere else.
 * Canonical git will reset the file and continue aborting the merge in this case.
 *
 * **WARNING:** Running git merge with non-trivial uncommitted changes is discouraged: while possible, it may leave you in a state that is hard to back out of in the case of a conflict.
 * If there were uncommitted changes when the merge started (and especially if those changes were further modified after the merge was started), `git.abortMerge` will in some cases be unable to reconstruct the original (pre-merge) changes.
 *
 * @param {object} args
 * @param {FsClient} args.fs - a file system implementation
 * @param {string} args.dir - The [working tree](dir-vs-gitdir.md) directory path
 * @param {string} [args.gitdir=join(dir, '.git')] - [required] The [git directory](dir-vs-gitdir.md) path
 * @param {string} [args.commit='HEAD'] - commit to reset the index and worktree to, defaults to HEAD
 * @param {object} [args.cache] - a [cache](cache.md) object
 *
 * @returns {Promise<void>} Resolves successfully once the git index has been updated
 *
 */
async function abortMerge({
  fs: _fs,
  dir,
  gitdir = join(dir, '.git'),
  commit = 'HEAD',
  cache = {},
}) {
  try {
    assertParameter('fs', _fs);
    assertParameter('dir', dir);
    assertParameter('gitdir', gitdir);

    const fs = new FileSystem(_fs);
    const trees = [TREE({ ref: commit }), WORKDIR(), STAGE()];
    let unmergedPaths = [];

    const updatedGitdir = await discoverGitdir({ fsp: fs, dotgit: gitdir });
    await GitIndexManager.acquire(
      { fs, gitdir: updatedGitdir, cache },
      async function (index) {
        unmergedPaths = index.unmergedPaths;
      }
    );

    const results = await _walk({
      fs,
      cache,
      dir,
      gitdir: updatedGitdir,
      trees,
      map: async function (path, [head, workdir, index]) {
        const staged = !(await modified(workdir, index));
        const unmerged = unmergedPaths.includes(path);
        const unmodified = !(await modified(index, head));

        if (staged || unmerged) {
          return head
            ? {
                path,
                mode: await head.mode(),
                oid: await head.oid(),
                type: await head.type(),
                content: await head.content(),
              }
            : undefined
        }

        if (unmodified) return false
        else throw new IndexResetError(path)
      },
    });

    await GitIndexManager.acquire(
      { fs, gitdir: updatedGitdir, cache },
      async function (index) {
        // Reset paths in index and worktree, this can't be done in _walk because the
        // STAGE walker acquires its own index lock.

        for (const entry of results) {
          if (entry === false) continue

          // entry is not false, so from here we can assume index = workdir
          if (!entry) {
            await fs.rmdir(`${dir}/${entry.path}`, { recursive: true });
            index.delete({ filepath: entry.path });
            continue
          }

          if (entry.type === 'blob') {
            const content = new TextDecoder().decode(entry.content);
            await fs.write(`${dir}/${entry.path}`, content, {
              mode: entry.mode,
            });
            index.insert({
              filepath: entry.path,
              oid: entry.oid,
              stage: 0,
            });
          }
        }
      }
    );
  } catch (err) {
    err.caller = 'git.abortMerge';
    throw err
  }
}

// I'm putting this in a Manager because I reckon it could benefit
// from a LOT of caching.
class GitIgnoreManager {
  /**
   * Determines whether a given file is ignored based on `.gitignore` rules and exclusion files.
   *
   * @param {Object} args
   * @param {FSClient} args.fs - A file system implementation.
   * @param {string} args.dir - The working directory.
   * @param {string} [args.gitdir=join(dir, '.git')] - [required] The [git directory](dir-vs-gitdir.md) path
   * @param {string} args.filepath - The path of the file to check.
   * @returns {Promise<boolean>} - `true` if the file is ignored, `false` otherwise.
   */
  static async isIgnored({ fs, dir, gitdir = join(dir, '.git'), filepath }) {
    // ALWAYS ignore ".git" folders.
    if (basename(filepath) === '.git') return true
    // '.' is not a valid gitignore entry, so '.' is never ignored
    if (filepath === '.') return false
    // Check and load exclusion rules from project exclude file (.git/info/exclude)
    let excludes = '';
    const excludesFile = join(gitdir, 'info', 'exclude');
    if (await fs.exists(excludesFile)) {
      excludes = await fs.read(excludesFile, 'utf8');
    }
    // Find all the .gitignore files that could affect this file
    const pairs = [
      {
        gitignore: join(dir, '.gitignore'),
        filepath,
      },
    ];
    const pieces = filepath.split('/').filter(Boolean);
    for (let i = 1; i < pieces.length; i++) {
      const folder = pieces.slice(0, i).join('/');
      const file = pieces.slice(i).join('/');
      pairs.push({
        gitignore: join(dir, folder, '.gitignore'),
        filepath: file,
      });
    }
    let ignoredStatus = false;
    for (const p of pairs) {
      let file;
      try {
        file = await fs.read(p.gitignore, 'utf8');
      } catch (err) {
        if (err.code === 'NOENT') continue
      }
      const ign = ignore().add(excludes);
      ign.add(file);
      // If the parent directory is excluded, we are done.
      // "It is not possible to re-include a file if a parent directory of that file is excluded. Git doesn’t list excluded directories for performance reasons, so any patterns on contained files have no effect, no matter where they are defined."
      // source: https://git-scm.com/docs/gitignore
      const parentdir = dirname(p.filepath);
      if (parentdir !== '.' && ign.ignores(parentdir)) return true
      // If the file is currently ignored, test for UNignoring.
      if (ignoredStatus) {
        ignoredStatus = !ign.test(p.filepath).unignored;
      } else {
        ignoredStatus = ign.test(p.filepath).ignored;
      }
    }
    return ignoredStatus
  }
}

async function writeObjectLoose({ fs, gitdir, object, format, oid }) {
  if (format !== 'deflated') {
    throw new InternalError(
      'GitObjectStoreLoose expects objects to write to be in deflated format'
    )
  }
  const source = `objects/${oid.slice(0, 2)}/${oid.slice(2)}`;
  const filepath = `${gitdir}/${source}`;
  // Don't overwrite existing git objects - this helps avoid EPERM errors.
  // Although I don't know how we'd fix corrupted objects then. Perhaps delete them
  // on read?
  if (!(await fs.exists(filepath))) await fs.write(filepath, object);
}

/* eslint-env node, browser */

let supportsCompressionStream = null;

async function deflate(buffer) {
  if (supportsCompressionStream === null) {
    supportsCompressionStream = testCompressionStream();
  }
  return supportsCompressionStream
    ? browserDeflate(buffer)
    : pako.deflate(buffer)
}

async function browserDeflate(buffer) {
  const cs = new CompressionStream('deflate');
  const c = new Blob([buffer]).stream().pipeThrough(cs);
  return new Uint8Array(await new Response(c).arrayBuffer())
}

function testCompressionStream() {
  try {
    const cs = new CompressionStream('deflate');
    cs.writable.close();
    // Test if `Blob.stream` is present. React Native does not have the `stream` method
    const stream = new Blob([]).stream();
    stream.cancel();
    return true
  } catch (_) {
    return false
  }
}

async function _writeObject({
  fs,
  gitdir,
  type,
  object,
  format = 'content',
  oid = undefined,
  dryRun = false,
}) {
  if (format !== 'deflated') {
    if (format !== 'wrapped') {
      object = GitObject.wrap({ type, object });
    }
    oid = await shasum(object);
    object = Buffer.from(await deflate(object));
  }
  if (!dryRun) {
    await writeObjectLoose({ fs, gitdir, object, format: 'deflated', oid });
  }
  return oid
}

function posixifyPathBuffer(buffer) {
  let idx;
  while (~(idx = buffer.indexOf(92))) buffer[idx] = 47;
  return buffer
}

// @ts-check

/**
 * Add a file to the git index (aka staging area)
 *
 * @param {object} args
 * @param {FsClient} args.fs - a file system implementation
 * @param {string} args.dir - The [working tree](dir-vs-gitdir.md) directory path
 * @param {string} [args.gitdir=join(dir, '.git')] - [required] The [git directory](dir-vs-gitdir.md) path
 * @param {string|string[]} args.filepath - The path to the file to add to the index
 * @param {object} [args.cache] - a [cache](cache.md) object
 * @param {boolean} [args.force=false] - add to index even if matches gitignore. Think `git add --force`
 * @param {boolean} [args.parallel=false] - process each input file in parallel. Parallel processing will result in more memory consumption but less process time
 *
 * @returns {Promise<void>} Resolves successfully once the git index has been updated
 *
 * @example
 * await fs.promises.writeFile('/tutorial/README.md', `# TEST`)
 * await git.add({ fs, dir: '/tutorial', filepath: 'README.md' })
 * console.log('done')
 *
 */
async function add({
  fs: _fs,
  dir,
  gitdir = join(dir, '.git'),
  filepath,
  cache = {},
  force = false,
  parallel = true,
}) {
  try {
    assertParameter('fs', _fs);
    assertParameter('dir', dir);
    assertParameter('gitdir', gitdir);
    assertParameter('filepath', filepath);

    const fs = new FileSystem(_fs);
    const updatedGitdir = await discoverGitdir({ fsp: fs, dotgit: gitdir });
    await GitIndexManager.acquire(
      { fs, gitdir: updatedGitdir, cache },
      async index => {
        const config = await GitConfigManager.get({ fs, gitdir: updatedGitdir });
        const autocrlf = await config.get('core.autocrlf');
        return addToIndex({
          dir,
          gitdir: updatedGitdir,
          fs,
          filepath,
          index,
          force,
          parallel,
          autocrlf,
        })
      }
    );
  } catch (err) {
    err.caller = 'git.add';
    throw err
  }
}

// True for a path the index already holds, and for a folder holding one. The
// exact lookup is a Map hit; the prefix scan only runs for folders, since a
// tracked file always answers on the first check.
function isTracked(index, filepath) {
  if (index.has({ filepath })) return true
  const prefix = `${filepath}/`;
  for (const entry of index.entriesMap.keys()) {
    if (entry.startsWith(prefix)) return true
  }
  return false
}

async function addToIndex({
  dir,
  gitdir,
  fs,
  filepath,
  index,
  force,
  parallel,
  autocrlf,
}) {
  filepath = Array.isArray(filepath) ? filepath : [filepath];
  const promises = filepath.map(async currentFilepath => {
    // .gitignore governs untracked paths. Once a path is in the index, adding a
    // matching rule does not stop canonical git from staging further changes,
    // and an ignored folder is still walked for the sake of what it tracks:
    // the recursion below re-checks every child, so only tracked ones get in.
    if (!force && !isTracked(index, currentFilepath)) {
      const ignored = await GitIgnoreManager.isIgnored({
        fs,
        dir,
        gitdir,
        filepath: currentFilepath,
      });
      if (ignored) return
    }
    const stats = await fs.lstat(join(dir, currentFilepath));
    if (!stats) throw new NotFoundError(currentFilepath)

    if (stats.isDirectory()) {
      const children = await fs.readdir(join(dir, currentFilepath));
      if (parallel) {
        const promises = children.map(child =>
          addToIndex({
            dir,
            gitdir,
            fs,
            filepath: [join(currentFilepath, child)],
            index,
            force,
            parallel,
            autocrlf,
          })
        );
        await Promise.all(promises);
      } else {
        for (const child of children) {
          await addToIndex({
            dir,
            gitdir,
            fs,
            filepath: [join(currentFilepath, child)],
            index,
            force,
            parallel,
            autocrlf,
          });
        }
      }
    } else {
      const object = stats.isSymbolicLink()
        ? await fs.readlink(join(dir, currentFilepath)).then(posixifyPathBuffer)
        : await fs.read(join(dir, currentFilepath), { autocrlf });
      if (object === null) throw new NotFoundError(currentFilepath)
      const oid = await _writeObject({ fs, gitdir, type: 'blob', object });
      index.insert({ filepath: currentFilepath, stats, oid });
    }
  });

  const settledPromises = await Promise.allSettled(promises);
  const rejectedPromises = settledPromises
    .filter(settle => settle.status === 'rejected')
    .map(settle => settle.reason);
  if (rejectedPromises.length > 1) {
    throw new MultipleGitError(rejectedPromises)
  }
  if (rejectedPromises.length === 1) {
    throw rejectedPromises[0]
  }

  const fulfilledPromises = settledPromises
    .filter(settle => settle.status === 'fulfilled' && settle.value)
    .map(settle => settle.value);

  return fulfilledPromises
}

// @ts-check

/**
 * @param {Object} args
 * @param {import('../models/FileSystem.js').FileSystem} args.fs
 * @param {string} args.gitdir
 * @param {string} args.path
 *
 * @returns {Promise<any>} Resolves with the config value
 *
 * @example
 * // Read config value
 * let value = await git.getConfig({
 *   dir: '$input((/))',
 *   path: '$input((user.name))'
 * })
 * console.log(value)
 *
 */
async function _getConfig({ fs, gitdir, path }) {
  const config = await GitConfigManager.get({ fs, gitdir });
  return config.get(path)
}

// Like Object.assign but ignore properties with undefined values
// ref: https://stackoverflow.com/q/39513815
function assignDefined(target, ...sources) {
  for (const source of sources) {
    if (source) {
      for (const key of Object.keys(source)) {
        const val = source[key];
        if (val !== undefined) {
          target[key] = val;
        }
      }
    }
  }
  return target
}

/**
 * Return author object by using properties following this priority:
 * (1) provided author object
 * -> (2) author of provided commit object
 * -> (3) Config and current date/time
 *
 * @param {Object} args
 * @param {FsClient} args.fs - a file system implementation
 * @param {string} [args.gitdir] - The [git directory](dir-vs-gitdir.md) path
 * @param {Object} [args.author] - The author object.
 * @param {CommitObject} [args.commit] - A commit object.
 *
 * @returns {Promise<void | {name: string, email: string, timestamp: number, timezoneOffset: number }>}
 */
async function normalizeAuthorObject({ fs, gitdir, author, commit }) {
  const timestamp = Math.floor(Date.now() / 1000);

  const defaultAuthor = {
    name: await _getConfig({ fs, gitdir, path: 'user.name' }),
    email: (await _getConfig({ fs, gitdir, path: 'user.email' })) || '', // author.email is allowed to be empty string
    timestamp,
    timezoneOffset: new Date(timestamp * 1000).getTimezoneOffset(),
  };

  // Populate author object by using properties with this priority:
  // (1) provided author object
  // -> (2) author of provided commit object
  // -> (3) default author
  const normalizedAuthor = assignDefined(
    {},
    defaultAuthor,
    commit ? commit.author : undefined,
    author
  );

  if (normalizedAuthor.name === undefined) {
    return undefined
  }

  return normalizedAuthor
}

/**
 * Return committer object by using properties with this priority:
 * (1) provided committer object
 * -> (2) provided author object
 * -> (3) committer of provided commit object
 * -> (4) Config and current date/time
 *
 * @param {Object} args
 * @param {FsClient} args.fs - a file system implementation
 * @param {string} [args.gitdir] - The [git directory](dir-vs-gitdir.md) path
 * @param {Object} [args.author] - The author object.
 * @param {Object} [args.committer] - The committer object.
 * @param {CommitObject} [args.commit] - A commit object.
 *
 * @returns {Promise<void | {name: string, email: string, timestamp: number, timezoneOffset: number }>}
 */
async function normalizeCommitterObject({
  fs,
  gitdir,
  author,
  committer,
  commit,
}) {
  const timestamp = Math.floor(Date.now() / 1000);

  const defaultCommitter = {
    name: await _getConfig({ fs, gitdir, path: 'user.name' }),
    email: (await _getConfig({ fs, gitdir, path: 'user.email' })) || '', // committer.email is allowed to be empty string
    timestamp,
    timezoneOffset: new Date(timestamp * 1000).getTimezoneOffset(),
  };

  const normalizedCommitter = assignDefined(
    {},
    defaultCommitter,
    commit ? commit.committer : undefined,
    author,
    committer
  );

  if (normalizedCommitter.name === undefined) {
    return undefined
  }
  return normalizedCommitter
}

async function resolveCommit({ fs, cache, gitdir, oid }) {
  const { type, object } = await _readObject({ fs, cache, gitdir, oid });
  // Resolve annotated tag objects to whatever
  if (type === 'tag') {
    oid = GitAnnotatedTag.from(object).parse().object;
    return resolveCommit({ fs, cache, gitdir, oid })
  }
  if (type !== 'commit') {
    throw new ObjectTypeError(oid, type, 'commit')
  }
  return { commit: GitCommit.from(object), oid }
}

// @ts-check

/**
 * @param {object} args
 * @param {import('../models/FileSystem.js').FileSystem} args.fs
 * @param {any} args.cache
 * @param {string} args.gitdir
 * @param {string} args.oid
 *
 * @returns {Promise<ReadCommitResult>} Resolves successfully with a git commit object
 * @see ReadCommitResult
 * @see CommitObject
 *
 */
async function _readCommit({ fs, cache, gitdir, oid }) {
  const { commit, oid: commitOid } = await resolveCommit({
    fs,
    cache,
    gitdir,
    oid,
  });
  const result = {
    oid: commitOid,
    commit: commit.parse(),
    payload: commit.withoutSignature(),
  };
  // @ts-ignore
  return result
}

// @ts-check

const EMPTY_TREE_OID = '4b825dc642cb6eb9a060e54bf8d69288fbee4904';

/**
 *
 * @param {Object} args
 * @param {import('../models/FileSystem.js').FileSystem} args.fs
 * @param {object} args.cache
 * @param {SignCallback} [args.onSign]
 * @param {string} args.gitdir
 * @param {string} [args.message]
 * @param {Object} [args.author]
 * @param {string} [args.author.name]
 * @param {string} [args.author.email]
 * @param {number} [args.author.timestamp]
 * @param {number} [args.author.timezoneOffset]
 * @param {Object} [args.committer]
 * @param {string} [args.committer.name]
 * @param {string} [args.committer.email]
 * @param {number} [args.committer.timestamp]
 * @param {number} [args.committer.timezoneOffset]
 * @param {string} [args.signingKey]
 * @param {boolean} [args.amend = false]
 * @param {boolean} [args.dryRun = false]
 * @param {boolean} [args.noUpdateBranch = false]
 * @param {boolean} [args.disallowEmpty = false]
 * @param {string} [args.ref]
 * @param {string[]} [args.parent]
 * @param {string} [args.tree]
 *
 * @returns {Promise<string>} Resolves successfully with the SHA-1 object id of the newly created commit.
 */
async function _commit({
  fs,
  cache,
  onSign,
  gitdir,
  message,
  author: _author,
  committer: _committer,
  signingKey,
  amend = false,
  dryRun = false,
  noUpdateBranch = false,
  disallowEmpty = false,
  ref,
  parent,
  tree,
}) {
  // Determine ref and the commit pointed to by ref, and if it is the initial commit
  let initialCommit = false;
  let detachedHead = false;
  if (!ref) {
    const headContent = await fs.read(`${gitdir}/HEAD`, { encoding: 'utf8' });
    detachedHead = !headContent.startsWith('ref:');
    ref = await GitRefManager.resolve({
      fs,
      gitdir,
      ref: 'HEAD',
      depth: 2,
    });
  }

  let refOid, refCommit;
  try {
    refOid = await GitRefManager.resolve({
      fs,
      gitdir,
      ref,
    });
    refCommit = await _readCommit({ fs, gitdir, oid: refOid, cache: {} });
  } catch {
    // We assume that there's no commit and this is the initial commit
    initialCommit = true;
  }

  if (amend && initialCommit) {
    throw new NoCommitError(ref)
  }

  // Determine author and committer information
  const author = !amend
    ? await normalizeAuthorObject({ fs, gitdir, author: _author })
    : await normalizeAuthorObject({
        fs,
        gitdir,
        author: _author,
        commit: refCommit.commit,
      });
  if (!author) throw new MissingNameError('author')

  const committer = !amend
    ? await normalizeCommitterObject({
        fs,
        gitdir,
        author,
        committer: _committer,
      })
    : await normalizeCommitterObject({
        fs,
        gitdir,
        author,
        committer: _committer,
        commit: refCommit.commit,
      });
  if (!committer) throw new MissingNameError('committer')

  return GitIndexManager.acquire(
    { fs, gitdir, cache, allowUnmerged: false },
    async function (index) {
      const inodes = flatFileListToDirectoryStructure(index.entries);
      const inode = inodes.get('.');
      if (!tree) {
        tree = await constructTree({ fs, gitdir, inode, dryRun });
      }

      // Determine parents of this commit
      if (!parent) {
        if (!amend) {
          parent = refOid ? [refOid] : [];
        } else {
          parent = refCommit.commit.parent;
        }
      } else {
        // ensure that the parents are oids, not refs
        parent = await Promise.all(
          parent.map(p => {
            return GitRefManager.resolve({ fs, gitdir, ref: p })
          })
        );
      }

      if (
        disallowEmpty &&
        !amend &&
        ((initialCommit && tree === EMPTY_TREE_OID) ||
          (!initialCommit && tree === refCommit.commit.tree))
      ) {
        throw new EmptyCommitError()
      }

      // Determine message of this commit
      if (!message) {
        if (!amend) {
          throw new MissingParameterError('message')
        } else {
          message = refCommit.commit.message;
        }
      }

      // Create and write new Commit object
      let comm = GitCommit.from({
        tree,
        parent,
        author,
        committer,
        message,
      });
      if (signingKey) {
        comm = await GitCommit.sign(comm, onSign, signingKey);
      }
      const oid = await _writeObject({
        fs,
        gitdir,
        type: 'commit',
        object: comm.toObject(),
        dryRun,
      });
      if (!noUpdateBranch && !dryRun) {
        // Update branch pointer (or HEAD directly if detached)
        await GitRefManager.writeRef({
          fs,
          gitdir,
          ref: detachedHead ? 'HEAD' : ref,
          value: oid,
        });
      }
      return oid
    }
  )
}

async function constructTree({ fs, gitdir, inode, dryRun }) {
  // use depth first traversal
  const children = inode.children;
  for (const inode of children) {
    if (inode.type === 'tree') {
      inode.metadata.mode = '040000';
      inode.metadata.oid = await constructTree({ fs, gitdir, inode, dryRun });
    }
  }
  const entries = children.map(inode => ({
    mode: inode.metadata.mode,
    path: inode.basename,
    oid: inode.metadata.oid,
    type: inode.type,
  }));
  const tree = GitTree.from(entries);
  const oid = await _writeObject({
    fs,
    gitdir,
    type: 'tree',
    object: tree.toObject(),
    dryRun,
  });
  return oid
}

// @ts-check

async function resolveFilepath({ fs, cache, gitdir, oid, filepath }) {
  const entry = await resolveFilepathEntry({
    fs,
    cache,
    gitdir,
    oid,
    filepath,
  });
  return entry.oid
}

async function resolveFilepathEntry({
  fs,
  cache,
  gitdir,
  oid,
  filepath,
}) {
  // Ensure there are no leading or trailing directory separators.
  // I was going to do this automatically, but then found that the Git Terminal for Windows
  // auto-expands --filepath=/src/utils to --filepath=C:/Users/Will/AppData/Local/Programs/Git/src/utils
  // so I figured it would be wise to promote the behavior in the application layer not just the library layer.
  if (filepath.startsWith('/')) {
    throw new InvalidFilepathError('leading-slash')
  } else if (filepath.endsWith('/')) {
    throw new InvalidFilepathError('trailing-slash')
  }
  const _oid = oid;
  const result = await resolveTree({ fs, cache, gitdir, oid });
  const tree = result.tree;
  if (filepath === '') {
    return { mode: '040000', oid: result.oid, path: '', type: 'tree' }
  } else {
    const pathArray = filepath.split('/');
    return _resolveFilepath({
      fs,
      cache,
      gitdir,
      tree,
      pathArray,
      oid: _oid,
      filepath,
    })
  }
}

async function _resolveFilepath({
  fs,
  cache,
  gitdir,
  tree,
  pathArray,
  oid,
  filepath,
}) {
  const name = pathArray.shift();
  for (const entry of tree) {
    if (entry.path === name) {
      if (pathArray.length === 0) {
        return entry
      } else {
        const { type, object } = await _readObject({
          fs,
          cache,
          gitdir,
          oid: entry.oid,
        });
        if (type !== 'tree') {
          throw new ObjectTypeError(oid, type, 'tree', filepath)
        }
        tree = GitTree.from(object);
        return _resolveFilepath({
          fs,
          cache,
          gitdir,
          tree,
          pathArray,
          oid,
          filepath,
        })
      }
    }
  }
  throw new NotFoundError(`file or directory found at "${oid}:${filepath}"`)
}

// @ts-check

/**
 *
 * @typedef {Object} ReadTreeResult - The object returned has the following schema:
 * @property {string} oid - SHA-1 object id of this tree
 * @property {TreeObject} tree - the parsed tree object
 */

/**
 * @param {object} args
 * @param {import('../models/FileSystem.js').FileSystem} args.fs
 * @param {any} args.cache
 * @param {string} args.gitdir
 * @param {string} args.oid
 * @param {string} [args.filepath]
 *
 * @returns {Promise<ReadTreeResult>}
 */
async function _readTree({
  fs,
  cache,
  gitdir,
  oid,
  filepath = undefined,
}) {
  if (filepath !== undefined) {
    oid = await resolveFilepath({ fs, cache, gitdir, oid, filepath });
  }
  const { tree, oid: treeOid } = await resolveTree({ fs, cache, gitdir, oid });
  const result = {
    oid: treeOid,
    tree: tree.entries(),
  };
  return result
}

// @ts-check

/**
 * @param {object} args
 * @param {import('../models/FileSystem.js').FileSystem} args.fs
 * @param {string} args.gitdir
 * @param {TreeObject} args.tree
 *
 * @returns {Promise<string>}
 */
async function _writeTree({ fs, gitdir, tree }) {
  // Convert object to buffer
  const object = GitTree.from(tree).toObject();
  const oid = await _writeObject({
    fs,
    gitdir,
    type: 'tree',
    object,
    format: 'content',
  });
  return oid
}

// @ts-check

/**
 * @param {object} args
 * @param {import('../models/FileSystem.js').FileSystem} args.fs
 * @param {object} args.cache
 * @param {SignCallback} [args.onSign]
 * @param {string} args.gitdir
 * @param {string} args.ref
 * @param {string} args.oid
 * @param {string|Uint8Array} args.note
 * @param {boolean} [args.force]
 * @param {Object} args.author
 * @param {string} args.author.name
 * @param {string} args.author.email
 * @param {number} args.author.timestamp
 * @param {number} args.author.timezoneOffset
 * @param {Object} args.committer
 * @param {string} args.committer.name
 * @param {string} args.committer.email
 * @param {number} args.committer.timestamp
 * @param {number} args.committer.timezoneOffset
 * @param {string} [args.signingKey]
 *
 * @returns {Promise<string>}
 */

async function _addNote({
  fs,
  cache,
  onSign,
  gitdir,
  ref,
  oid,
  note,
  force,
  author,
  committer,
  signingKey,
}) {
  // Get the current note commit
  let parent;
  try {
    parent = await GitRefManager.resolve({ gitdir, fs, ref });
  } catch (err) {
    if (!(err instanceof NotFoundError)) {
      throw err
    }
  }

  // I'm using the "empty tree" magic number here for brevity
  const result = await _readTree({
    fs,
    cache,
    gitdir,
    oid: parent || '4b825dc642cb6eb9a060e54bf8d69288fbee4904',
  });
  let tree = result.tree;

  // Handle the case where a note already exists
  if (force) {
    tree = tree.filter(entry => entry.path !== oid);
  } else {
    for (const entry of tree) {
      if (entry.path === oid) {
        throw new AlreadyExistsError('note', oid)
      }
    }
  }

  // Create the note blob
  if (typeof note === 'string') {
    note = Buffer.from(note, 'utf8');
  }
  const noteOid = await _writeObject({
    fs,
    gitdir,
    type: 'blob',
    object: note,
    format: 'content',
  });

  // Create the new note tree
  tree.push({ mode: '100644', path: oid, oid: noteOid, type: 'blob' });
  const treeOid = await _writeTree({
    fs,
    gitdir,
    tree,
  });

  // Create the new note commit
  const commitOid = await _commit({
    fs,
    cache,
    onSign,
    gitdir,
    ref,
    tree: treeOid,
    parent: parent && [parent],
    message: `Note added by 'isomorphic-git addNote'\n`,
    author,
    committer,
    signingKey,
  });

  return commitOid
}

// @ts-check

/**
 * Add or update an object note
 *
 * @param {object} args
 * @param {FsClient} args.fs - a file system implementation
 * @param {SignCallback} [args.onSign] - a PGP signing implementation
 * @param {string} [args.dir] - The [working tree](dir-vs-gitdir.md) directory path
 * @param {string} [args.gitdir=join(dir,'.git')] - [required] The [git directory](dir-vs-gitdir.md) path
 * @param {string} [args.ref] - The notes ref to look under
 * @param {string} args.oid - The SHA-1 object id of the object to add the note to.
 * @param {string|Uint8Array} args.note - The note to add
 * @param {boolean} [args.force] - Over-write note if it already exists.
 * @param {Object} [args.author] - The details about the author.
 * @param {string} [args.author.name] - Default is `user.name` config.
 * @param {string} [args.author.email] - Default is `user.email` config.
 * @param {number} [args.author.timestamp=Math.floor(Date.now()/1000)] - Set the author timestamp field. This is the integer number of seconds since the Unix epoch (1970-01-01 00:00:00).
 * @param {number} [args.author.timezoneOffset] - Set the author timezone offset field. This is the difference, in minutes, from the current timezone to UTC. Default is `(new Date()).getTimezoneOffset()`.
 * @param {Object} [args.committer = author] - The details about the note committer, in the same format as the author parameter. If not specified, the author details are used.
 * @param {string} [args.committer.name] - Default is `user.name` config.
 * @param {string} [args.committer.email] - Default is `user.email` config.
 * @param {number} [args.committer.timestamp=Math.floor(Date.now()/1000)] - Set the committer timestamp field. This is the integer number of seconds since the Unix epoch (1970-01-01 00:00:00).
 * @param {number} [args.committer.timezoneOffset] - Set the committer timezone offset field. This is the difference, in minutes, from the current timezone to UTC. Default is `(new Date()).getTimezoneOffset()`.
 * @param {string} [args.signingKey] - Sign the note commit using this private PGP key.
 * @param {object} [args.cache] - a [cache](cache.md) object
 *
 * @returns {Promise<string>} Resolves successfully with the SHA-1 object id of the commit object for the added note.
 */

async function addNote({
  fs: _fs,
  onSign,
  dir,
  gitdir = join(dir, '.git'),
  ref = 'refs/notes/commits',
  oid,
  note,
  force,
  author: _author,
  committer: _committer,
  signingKey,
  cache = {},
}) {
  try {
    assertParameter('fs', _fs);
    assertParameter('gitdir', gitdir);
    assertParameter('oid', oid);
    assertParameter('note', note);
    if (signingKey) {
      assertParameter('onSign', onSign);
    }
    const fs = new FileSystem(_fs);

    const author = await normalizeAuthorObject({ fs, gitdir, author: _author });
    if (!author) throw new MissingNameError('author')

    const committer = await normalizeCommitterObject({
      fs,
      gitdir,
      author,
      committer: _committer,
    });
    if (!committer) throw new MissingNameError('committer')

    const updatedGitdir = await discoverGitdir({ fsp: fs, dotgit: gitdir });
    return await _addNote({
      fs,
      cache,
      onSign,
      gitdir: updatedGitdir,
      ref,
      oid,
      note,
      force,
      author,
      committer,
      signingKey,
    })
  } catch (err) {
    err.caller = 'git.addNote';
    throw err
  }
}

// @ts-check

/**
 * @param {object} args
 * @param {import('../models/FileSystem.js').FileSystem} args.fs
 * @param {string} args.gitdir
 * @param {string} args.remote
 * @param {string} args.url
 * @param {boolean} args.force
 *
 * @returns {Promise<void>}
 *
 */
async function _addRemote({ fs, gitdir, remote, url, force }) {
  if (!isValidRef(remote, true)) {
    throw new InvalidRefNameError(remote, cleanGitRef.clean(remote))
  }
  const config = await GitConfigManager.get({ fs, gitdir });
  if (!force) {
    // Check that setting it wouldn't overwrite.
    const remoteNames = await config.getSubsections('remote');
    if (remoteNames.includes(remote)) {
      // Throw an error if it would overwrite an existing remote,
      // but not if it's simply setting the same value again.
      if (url !== (await config.get(`remote.${remote}.url`))) {
        throw new AlreadyExistsError('remote', remote)
      }
    }
  }
  await config.set(`remote.${remote}.url`, url);
  await config.set(
    `remote.${remote}.fetch`,
    `+refs/heads/*:refs/remotes/${remote}/*`
  );
  await GitConfigManager.save({ fs, gitdir, config });
}

// @ts-check

/**
 * Add or update a remote
 *
 * @param {object} args
 * @param {FsClient} args.fs - a file system implementation
 * @param {string} [args.dir] - The [working tree](dir-vs-gitdir.md) directory path
 * @param {string} [args.gitdir] - [required] The [git directory](dir-vs-gitdir.md) path
 * @param {string} args.remote - The name of the remote
 * @param {string} args.url - The URL of the remote
 * @param {boolean} [args.force = false] - Instead of throwing an error if a remote named `remote` already exists, overwrite the existing remote.
 *
 * @returns {Promise<void>} Resolves successfully when filesystem operations are complete
 *
 * @example
 * await git.addRemote({
 *   fs,
 *   dir: '/tutorial',
 *   remote: 'upstream',
 *   url: 'https://github.com/isomorphic-git/isomorphic-git'
 * })
 * console.log('done')
 *
 */
async function addRemote({
  fs,
  dir,
  gitdir = join(dir, '.git'),
  remote,
  url,
  force = false,
}) {
  try {
    assertParameter('fs', fs);
    assertParameter('gitdir', gitdir);
    assertParameter('remote', remote);
    assertParameter('url', url);
    const fsp = new FileSystem(fs);
    const updatedGitdir = await discoverGitdir({ fsp, dotgit: gitdir });
    return await _addRemote({
      fs: fsp,
      gitdir: updatedGitdir,
      remote,
      url,
      force,
    })
  } catch (err) {
    err.caller = 'git.addRemote';
    throw err
  }
}

// @ts-check

/**
 * Create an annotated tag.
 *
 * @param {object} args
 * @param {import('../models/FileSystem.js').FileSystem} args.fs
 * @param {any} args.cache
 * @param {SignCallback} [args.onSign]
 * @param {string} args.gitdir
 * @param {string} args.ref
 * @param {string} [args.message = ref]
 * @param {string} [args.object = 'HEAD']
 * @param {object} [args.tagger]
 * @param {string} args.tagger.name
 * @param {string} args.tagger.email
 * @param {number} args.tagger.timestamp
 * @param {number} args.tagger.timezoneOffset
 * @param {string} [args.gpgsig]
 * @param {string} [args.signingKey]
 * @param {boolean} [args.force = false]
 *
 * @returns {Promise<void>} Resolves successfully when filesystem operations are complete
 *
 * @example
 * await git.annotatedTag({
 *   dir: '$input((/))',
 *   ref: '$input((test-tag))',
 *   message: '$input((This commit is awesome))',
 *   tagger: {
 *     name: '$input((Mr. Test))',
 *     email: '$input((mrtest@example.com))'
 *   }
 * })
 * console.log('done')
 *
 */
async function _annotatedTag({
  fs,
  cache,
  onSign,
  gitdir,
  ref,
  tagger,
  message = ref,
  gpgsig,
  object,
  signingKey,
  force = false,
}) {
  ref = ref.startsWith('refs/tags/') ? ref : `refs/tags/${ref}`;

  if (!force && (await GitRefManager.exists({ fs, gitdir, ref }))) {
    throw new AlreadyExistsError('tag', ref)
  }

  // Resolve passed value
  const oid = await GitRefManager.resolve({
    fs,
    gitdir,
    ref: object || 'HEAD',
  });

  const { type } = await _readObject({ fs, cache, gitdir, oid });
  let tagObject = GitAnnotatedTag.from({
    object: oid,
    type,
    tag: ref.replace('refs/tags/', ''),
    tagger,
    message,
    gpgsig,
  });
  if (signingKey) {
    tagObject = await GitAnnotatedTag.sign(tagObject, onSign, signingKey);
  }
  const value = await _writeObject({
    fs,
    gitdir,
    type: 'tag',
    object: tagObject.toObject(),
  });

  await GitRefManager.writeRef({ fs, gitdir, ref, value });
}

// @ts-check

/**
 * Create an annotated tag.
 *
 * @param {object} args
 * @param {FsClient} args.fs - a file system implementation
 * @param {SignCallback} [args.onSign] - a PGP signing implementation
 * @param {string} [args.dir] - The [working tree](dir-vs-gitdir.md) directory path
 * @param {string} [args.gitdir=join(dir,'.git')] - [required] The [git directory](dir-vs-gitdir.md) path
 * @param {string} args.ref - What to name the tag
 * @param {string} [args.message = ref] - The tag message to use.
 * @param {string} [args.object = 'HEAD'] - The SHA-1 object id the tag points to. (Will resolve to a SHA-1 object id if value is a ref.) By default, the commit object which is referred by the current `HEAD` is used.
 * @param {object} [args.tagger] - The details about the tagger.
 * @param {string} [args.tagger.name] - Default is `user.name` config.
 * @param {string} [args.tagger.email] - Default is `user.email` config.
 * @param {number} [args.tagger.timestamp=Math.floor(Date.now()/1000)] - Set the tagger timestamp field. This is the integer number of seconds since the Unix epoch (1970-01-01 00:00:00).
 * @param {number} [args.tagger.timezoneOffset] - Set the tagger timezone offset field. This is the difference, in minutes, from the current timezone to UTC. Default is `(new Date()).getTimezoneOffset()`.
 * @param {string} [args.gpgsig] - The gpgsig attached to the tag object. (Mutually exclusive with the `signingKey` option.)
 * @param {string} [args.signingKey] - Sign the tag object using this private PGP key. (Mutually exclusive with the `gpgsig` option.)
 * @param {boolean} [args.force = false] - Instead of throwing an error if a tag named `ref` already exists, overwrite the existing tag. Note that this option does not modify the original tag object itself.
 * @param {object} [args.cache] - a [cache](cache.md) object
 *
 * @returns {Promise<void>} Resolves successfully when filesystem operations are complete
 *
 * @example
 * await git.annotatedTag({
 *   fs,
 *   dir: '/tutorial',
 *   ref: 'test-tag',
 *   message: 'This commit is awesome',
 *   tagger: {
 *     name: 'Mr. Test',
 *     email: 'mrtest@example.com'
 *   }
 * })
 * console.log('done')
 *
 */
async function annotatedTag({
  fs: _fs,
  onSign,
  dir,
  gitdir = join(dir, '.git'),
  ref,
  tagger: _tagger,
  message = ref,
  gpgsig,
  object,
  signingKey,
  force = false,
  cache = {},
}) {
  try {
    assertParameter('fs', _fs);
    assertParameter('gitdir', gitdir);
    assertParameter('ref', ref);
    if (signingKey) {
      assertParameter('onSign', onSign);
    }
    const fs = new FileSystem(_fs);
    const updatedGitdir = await discoverGitdir({ fsp: fs, dotgit: gitdir });

    // Fill in missing arguments with default values
    const tagger = await normalizeAuthorObject({
      fs,
      gitdir: updatedGitdir,
      author: _tagger,
    });
    if (!tagger) throw new MissingNameError('tagger')

    return await _annotatedTag({
      fs,
      cache,
      onSign,
      gitdir: updatedGitdir,
      ref,
      tagger,
      message,
      gpgsig,
      object,
      signingKey,
      force,
    })
  } catch (err) {
    err.caller = 'git.annotatedTag';
    throw err
  }
}

// @ts-check

/**
 * Create a branch
 *
 * @param {object} args
 * @param {import('../models/FileSystem.js').FileSystem} args.fs
 * @param {string} args.gitdir
 * @param {string} args.ref
 * @param {string} [args.object = 'HEAD']
 * @param {boolean} [args.checkout = false]
 * @param {boolean} [args.force = false]
 *
 * @returns {Promise<void>} Resolves successfully when filesystem operations are complete
 *
 * @example
 * await git.branch({ dir: '$input((/))', ref: '$input((develop))' })
 * console.log('done')
 *
 */
async function _branch({
  fs,
  gitdir,
  ref,
  object,
  checkout = false,
  force = false,
}) {
  if (!isValidRef(ref, true)) {
    throw new InvalidRefNameError(ref, cleanGitRef.clean(ref))
  }

  const fullref = `refs/heads/${ref}`;

  if (!force) {
    const exist = await GitRefManager.exists({ fs, gitdir, ref: fullref });
    if (exist) {
      throw new AlreadyExistsError('branch', ref, false)
    }
  }

  // Get current HEAD tree oid
  let oid;
  try {
    oid = await GitRefManager.resolve({ fs, gitdir, ref: object || 'HEAD' });
  } catch (e) {
    // Probably an empty repo
  }

  // Create a new ref that points at the current commit
  if (oid) {
    await GitRefManager.writeRef({ fs, gitdir, ref: fullref, value: oid });
  }

  if (checkout) {
    // Update HEAD
    await GitRefManager.writeSymbolicRef({
      fs,
      gitdir,
      ref: 'HEAD',
      value: fullref,
    });
  }
}

// @ts-check

/**
 * Create a branch
 *
 * @param {object} args
 * @param {FsClient} args.fs - a file system implementation
 * @param {string} [args.dir] - The [working tree](dir-vs-gitdir.md) directory path
 * @param {string} [args.gitdir=join(dir,'.git')] - [required] The [git directory](dir-vs-gitdir.md) path
 * @param {string} args.ref - What to name the branch
 * @param {string} [args.object = 'HEAD'] - What oid to use as the start point. Accepts a symbolic ref.
 * @param {boolean} [args.checkout = false] - Update `HEAD` to point at the newly created branch
 * @param {boolean} [args.force = false] - Instead of throwing an error if a branched named `ref` already exists, overwrite the existing branch.
 *
 * @returns {Promise<void>} Resolves successfully when filesystem operations are complete
 *
 * @example
 * await git.branch({ fs, dir: '/tutorial', ref: 'develop' })
 * console.log('done')
 *
 */
async function branch({
  fs,
  dir,
  gitdir = join(dir, '.git'),
  ref,
  object,
  checkout = false,
  force = false,
}) {
  try {
    assertParameter('fs', fs);
    assertParameter('gitdir', gitdir);
    assertParameter('ref', ref);
    const fsp = new FileSystem(fs);
    const updatedGitdir = await discoverGitdir({ fsp, dotgit: gitdir });
    return await _branch({
      fs: fsp,
      gitdir: updatedGitdir,
      ref,
      object,
      checkout,
      force,
    })
  } catch (err) {
    err.caller = 'git.branch';
    throw err
  }
}

/**
 * Refuse to materialize a working-tree entry whose parent path traverses a
 * symbolic link. A leading component that is a symlink could otherwise redirect
 * a write or mkdir outside the working tree. git applies the same check: it does
 * not follow symlinks in the leading path when writing working-tree files.
 *
 * @param {import('../models/FileSystem.js').FileSystem} fs
 * @param {string} dir
 * @param {string} fullpath
 */
async function assertNoSymlinkInLeadingPath(fs, dir, fullpath) {
  const parts = fullpath.split('/');
  parts.pop(); // the final segment is the entry being written, not a leading dir
  let current = dir;
  for (const part of parts) {
    if (part === '' || part === '.') continue
    current = `${current}/${part}`;
    const stats = await fs.lstat(current);
    // lstat returns null when the path doesn't exist yet (nothing to traverse).
    if (stats && stats.isSymbolicLink()) {
      throw new UnsafeFilepathError(fullpath)
    }
  }
}

const worthWalking = (filepath, root) => {
  if (filepath === '.' || root == null || root.length === 0 || root === '.') {
    return true
  }
  // A shared prefix only counts when it lands on a path component boundary,
  // otherwise the root 'src' would also pull in 'src2/a.js' and 'srcfoo.txt'.
  const base = root.endsWith('/') ? root.slice(0, -1) : root;
  if (base === '.') {
    return true
  }
  if (base.length >= filepath.length) {
    // Keep walking while filepath is still an ancestor of the wanted root.
    return base === filepath || base.startsWith(`${filepath}/`)
  }
  return filepath.startsWith(`${base}/`)
};

// @ts-check

/**
 * @param {object} args
 * @param {import('../models/FileSystem.js').FileSystem} args.fs
 * @param {any} args.cache
 * @param {ProgressCallback} [args.onProgress]
 * @param {PostCheckoutCallback} [args.onPostCheckout]
 * @param {string} args.dir
 * @param {string} args.gitdir
 * @param {string} args.ref
 * @param {string[]} [args.filepaths]
 * @param {string} args.remote
 * @param {boolean} args.noCheckout
 * @param {boolean} [args.noUpdateHead]
 * @param {boolean} [args.dryRun]
 * @param {boolean} [args.force]
 * @param {boolean} [args.track]
 * @param {boolean} [args.restoreFromIndex]
 * @param {boolean} [args.nonBlocking]
 * @param {number} [args.batchSize]
 *
 * @returns {Promise<void>} Resolves successfully when filesystem operations are complete
 *
 */
async function _checkout({
  fs,
  cache,
  onProgress,
  onPostCheckout,
  dir,
  gitdir,
  remote,
  ref,
  filepaths,
  noCheckout,
  noUpdateHead,
  dryRun,
  force,
  track = true,
  restoreFromIndex = false,
  nonBlocking = false,
  batchSize = 100,
}) {
  // oldOid is defined only if onPostCheckout hook is attached
  let oldOid;
  if (onPostCheckout) {
    try {
      oldOid = await GitRefManager.resolve({ fs, gitdir, ref: 'HEAD' });
    } catch (err) {
      oldOid = '0000000000000000000000000000000000000000';
    }
  }

  // Get tree oid
  let oid;
  try {
    oid = await GitRefManager.resolve({ fs, gitdir, ref });
    // TODO: Figure out what to do if both 'ref' and 'remote' are specified, ref already exists,
    // and is configured to track a different remote.
  } catch (err) {
    if (ref === 'HEAD') throw err
    // If `ref` doesn't exist, create a new remote tracking branch
    // Figure out the commit to checkout
    const remoteRef = `${remote}/${ref}`;
    oid = await GitRefManager.resolve({
      fs,
      gitdir,
      ref: remoteRef,
    });
    if (track) {
      // Set up remote tracking branch
      const config = await GitConfigManager.get({ fs, gitdir });
      await config.set(`branch.${ref}.remote`, remote);
      await config.set(`branch.${ref}.merge`, `refs/heads/${ref}`);
      await GitConfigManager.save({ fs, gitdir, config });
    }
    // Create a new branch that points at that same commit
    await GitRefManager.writeRef({
      fs,
      gitdir,
      ref: `refs/heads/${ref}`,
      value: oid,
    });
  }

  // Update working dir
  if (!noCheckout) {
    let ops;
    // First pass - just analyze files (not directories) and figure out what needs to be done
    try {
      ops = await analyze({
        fs,
        cache,
        onProgress,
        dir,
        gitdir,
        ref,
        force,
        filepaths,
        restoreFromIndex,
      });
    } catch (err) {
      // Throw a more helpful error message for this common mistake.
      if (err instanceof NotFoundError && err.data.what === oid) {
        throw new CommitNotFetchedError(ref, oid)
      } else {
        throw err
      }
    }

    // Report conflicts
    const conflicts = ops
      .filter(([method]) => method === 'conflict')
      .map(([method, fullpath]) => fullpath);
    if (conflicts.length > 0) {
      throw new CheckoutConflictError(conflicts)
    }

    // Collect errors
    const errors = ops
      .filter(([method]) => method === 'error')
      .map(([method, fullpath]) => fullpath);
    if (errors.length > 0) {
      throw new InternalError(errors.join(', '))
    }

    if (dryRun) {
      // Since the format of 'ops' is in flux, I really would rather folk besides myself not start relying on it
      // return ops

      if (onPostCheckout) {
        await onPostCheckout({
          previousHead: oldOid,
          newHead: oid,
          type: filepaths != null && filepaths.length > 0 ? 'file' : 'branch',
        });
      }
      return
    }

    // Second pass - execute planned changes
    // The cheapest semi-parallel solution without computing a full dependency graph will be
    // to just do ops in 4 dumb phases: delete files, delete dirs, create dirs, write files

    let count = 0;
    const total = ops.length;
    await GitIndexManager.acquire(
      { fs, gitdir, cache },
      async function (index) {
        await Promise.all(
          ops
            .filter(
              ([method]) => method === 'delete' || method === 'delete-index'
            )
            .map(async function ([method, fullpath]) {
              const filepath = `${dir}/${fullpath}`;
              if (method === 'delete') {
                await fs.rm(filepath);
              }
              index.delete({ filepath: fullpath });
              if (onProgress) {
                await onProgress({
                  phase: 'Updating workdir',
                  loaded: ++count,
                  total,
                });
              }
            })
        );
      }
    );

    // Note: this is cannot be done naively in parallel
    await GitIndexManager.acquire(
      { fs, gitdir, cache },
      async function (index) {
        for (const [method, fullpath] of ops) {
          if (method === 'rmdir' || method === 'rmdir-index') {
            const filepath = `${dir}/${fullpath}`;
            try {
              if (method === 'rmdir') {
                await fs.rmdir(filepath);
              }
              index.delete({ filepath: fullpath });
              if (onProgress) {
                await onProgress({
                  phase: 'Updating workdir',
                  loaded: ++count,
                  total,
                });
              }
            } catch (e) {
              if (e.code === 'ENOTEMPTY') {
                console.log(
                  `Did not delete ${fullpath} because directory is not empty`
                );
              } else {
                throw e
              }
            }
          }
        }
      }
    );

    await Promise.all(
      ops
        .filter(([method]) => method === 'mkdir' || method === 'mkdir-index')
        .map(async function ([_, fullpath]) {
          const filepath = `${dir}/${fullpath}`;
          await assertNoSymlinkInLeadingPath(fs, dir, fullpath);
          await fs.mkdir(filepath);
          if (onProgress) {
            await onProgress({
              phase: 'Updating workdir',
              loaded: ++count,
              total,
            });
          }
        })
    );

    if (nonBlocking) {
      // Filter eligible operations first
      const eligibleOps = ops.filter(
        ([method]) =>
          method === 'create' ||
          method === 'create-index' ||
          method === 'update' ||
          method === 'mkdir-index'
      );

      const updateWorkingDirResults = await batchAllSettled(
        'Update Working Dir',
        eligibleOps.map(
          ([method, fullpath, oid, mode, chmod]) =>
            () =>
              updateWorkingDir({ fs, cache, gitdir, dir }, [
                method,
                fullpath,
                oid,
                mode,
                chmod,
              ])
        ),
        onProgress,
        batchSize
      );

      await GitIndexManager.acquire(
        { fs, gitdir, cache, allowUnmerged: true },
        async function (index) {
          await batchAllSettled(
            'Update Index',
            updateWorkingDirResults.map(
              ([fullpath, oid, stats]) =>
                () =>
                  updateIndex({ index, fullpath, oid, stats })
            ),
            onProgress,
            batchSize
          );
        }
      );
    } else {
      await GitIndexManager.acquire(
        { fs, gitdir, cache, allowUnmerged: true },
        async function (index) {
          const settled = await Promise.allSettled(
            ops
              .filter(
                ([method]) =>
                  method === 'create' ||
                  method === 'create-index' ||
                  method === 'update' ||
                  method === 'mkdir-index'
              )
              .map(async function ([method, fullpath, oid, mode, chmod]) {
                const filepath = `${dir}/${fullpath}`;
                if (method !== 'create-index' && method !== 'mkdir-index') {
                  // Don't write through a symlinked leading path: a parent component that
                  // is a symlink could otherwise redirect the write outside the working
                  // tree. git applies the same check (it does not follow symlinks here).
                  await assertNoSymlinkInLeadingPath(fs, dir, fullpath);
                  const { object } = await _readObject({
                    fs,
                    cache,
                    gitdir,
                    oid,
                  });
                  if (chmod) {
                    // Note: the mode option of fs.write only works when creating files,
                    // not updating them. Since the `fs` plugin doesn't expose `chmod` this
                    // is our only option.
                    await fs.rm(filepath);
                  }
                  if (mode === 0o100644) {
                    // regular file
                    await fs.write(filepath, object);
                  } else if (mode === 0o100755) {
                    // executable file
                    await fs.write(filepath, object, { mode: 0o777 });
                  } else if (mode === 0o120000) {
                    // symlink
                    await fs.writelink(filepath, object);
                  } else {
                    throw new InternalError(
                      `Invalid mode 0o${mode.toString(
                        8
                      )} detected in blob ${oid}`
                    )
                  }
                }

                const stats = await fs.lstat(filepath);
                // We can't trust the executable bit returned by lstat on Windows,
                // so we need to preserve this value from the TREE.
                // TODO: Figure out how git handles this internally.
                if (mode === 0o100755) {
                  stats.mode = 0o755;
                }
                // Submodules are present in the git index but use a unique mode different from trees
                if (method === 'mkdir-index') {
                  stats.mode = 0o160000;
                }
                index.insert({
                  filepath: fullpath,
                  stats,
                  oid,
                });
                if (onProgress) {
                  await onProgress({
                    phase: 'Updating workdir',
                    loaded: ++count,
                    total,
                  });
                }
              })
          );
          const rejections = [];
          for (const result of settled) {
            if (result.status === 'rejected') {
              rejections.push(result.reason);
              // eslint-disable-next-line no-console
              console.error(
                '[isomorphic-git checkout] task rejected:',
                result.reason?.stack ?? result.reason
              );
            }
          }
          if (rejections.length > 0) {
            throw new MultipleGitError(rejections)
          }
        }
      );
    }

    if (onPostCheckout) {
      await onPostCheckout({
        previousHead: oldOid,
        newHead: oid,
        type: filepaths != null && filepaths.length > 0 ? 'file' : 'branch',
      });
    }
  }

  // Update HEAD
  if (!noUpdateHead) {
    const fullRef = await GitRefManager.expand({ fs, gitdir, ref });
    if (fullRef.startsWith('refs/heads')) {
      await GitRefManager.writeSymbolicRef({
        fs,
        gitdir,
        ref: 'HEAD',
        value: fullRef,
      });
    } else {
      // detached head
      await GitRefManager.writeRef({ fs, gitdir, ref: 'HEAD', value: oid });
    }
  }
}

async function analyze({
  fs,
  cache,
  onProgress,
  dir,
  gitdir,
  ref,
  force,
  filepaths,
  restoreFromIndex,
}) {
  let count = 0;
  return _walk({
    fs,
    cache,
    dir,
    gitdir,
    trees: [restoreFromIndex ? STAGE() : TREE({ ref }), WORKDIR(), STAGE()],
    map: async function (fullpath, [commit, workdir, stage]) {
      if (fullpath === '.') return
      // match against base paths
      if (filepaths && !filepaths.some(base => worthWalking(fullpath, base))) {
        return null
      }
      // Emit progress event
      if (onProgress) {
        await onProgress({ phase: 'Analyzing workdir', loaded: ++count });
      }

      // This is a kind of silly pattern but it worked so well for me in the past
      // and it makes intuitively demonstrating exhaustiveness so *easy*.
      // This checks for the presence and/or absence of each of the 3 entries,
      // converts that to a 3-bit binary representation, and then handles
      // every possible combination (2^3 or 8 cases) with a lookup table.
      const key = [!!stage, !!commit, !!workdir].map(Number).join('');
      switch (key) {
        // Impossible case.
        case '000':
          return
        // Ignore workdir files that are not tracked and not part of the new commit.
        case '001':
          // OK, make an exception for explicitly named files.
          if (
            !restoreFromIndex &&
            force &&
            filepaths &&
            filepaths.includes(fullpath)
          ) {
            return ['delete', fullpath]
          }
          return
        // New entries
        case '010': {
          switch (await commit.type()) {
            case 'tree': {
              return ['mkdir', fullpath]
            }
            case 'blob': {
              return [
                'create',
                fullpath,
                await commit.oid(),
                await commit.mode(),
              ]
            }
            case 'commit': {
              return [
                'mkdir-index',
                fullpath,
                await commit.oid(),
                await commit.mode(),
              ]
            }
            default: {
              return [
                'error',
                `new entry Unhandled type ${await commit.type()}`,
              ]
            }
          }
        }
        // New entries but there is already something in the workdir there.
        case '011': {
          switch (`${await commit.type()}-${await workdir.type()}`) {
            case 'tree-tree': {
              return // noop
            }
            case 'tree-blob':
            case 'blob-tree': {
              return ['conflict', fullpath]
            }
            case 'blob-blob': {
              // Is the incoming file different?
              if ((await commit.oid()) !== (await workdir.oid())) {
                if (force) {
                  return [
                    'update',
                    fullpath,
                    await commit.oid(),
                    await commit.mode(),
                    (await commit.mode()) !== (await workdir.mode()),
                  ]
                } else {
                  return ['conflict', fullpath]
                }
              } else {
                // Is the incoming file a different mode?
                if ((await commit.mode()) !== (await workdir.mode())) {
                  if (force) {
                    return [
                      'update',
                      fullpath,
                      await commit.oid(),
                      await commit.mode(),
                      true,
                    ]
                  } else {
                    return ['conflict', fullpath]
                  }
                } else {
                  return [
                    'create-index',
                    fullpath,
                    await commit.oid(),
                    await commit.mode(),
                  ]
                }
              }
            }
            case 'commit-tree': {
              // TODO: submodule
              // We'll ignore submodule directories for now.
              // Users prefer we not throw an error for lack of submodule support.
              // gitlinks
              return
            }
            case 'commit-blob': {
              // TODO: submodule
              // But... we'll complain if there is a *file* where we would
              // put a submodule if we had submodule support.
              return ['conflict', fullpath]
            }
            default: {
              return ['error', `new entry Unhandled type ${commit.type}`]
            }
          }
        }
        // Something in stage but not in the commit OR the workdir.
        // Note: I verified this behavior against canonical git.
        case '100': {
          return ['delete-index', fullpath]
        }
        // Deleted entries
        // TODO: How to handle if stage type and workdir type mismatch?
        case '101': {
          switch (await stage.type()) {
            case 'tree': {
              return ['rmdir-index', fullpath]
            }
            case 'blob': {
              // Git checks that the workdir.oid === stage.oid before deleting file
              if ((await stage.oid()) !== (await workdir.oid())) {
                if (force) {
                  return ['delete', fullpath]
                } else {
                  return ['conflict', fullpath]
                }
              } else {
                return ['delete', fullpath]
              }
            }
            case 'commit': {
              return ['rmdir-index', fullpath]
            }
            default: {
              return [
                'error',
                `delete entry Unhandled type ${await stage.type()}`,
              ]
            }
          }
        }
        /* eslint-disable no-fallthrough */
        // File missing from workdir
        case '110':
        // Possibly modified entries
        case '111': {
          /* eslint-enable no-fallthrough */
          switch (`${await stage.type()}-${await commit.type()}`) {
            case 'tree-tree': {
              return
            }
            case 'blob-blob': {
              // If the file hasn't changed, there is no need to do anything.
              // Existing file modifications in the workdir can be be left as is.
              if (
                (await stage.oid()) === (await commit.oid()) &&
                (await stage.mode()) === (await commit.mode()) &&
                !force
              ) {
                return
              }

              // Check for local changes that would be lost
              if (workdir) {
                // Note: canonical git only compares with the stage. But we're smart enough
                // to compare to the stage AND the incoming commit.
                if (
                  (await workdir.oid()) !== (await stage.oid()) &&
                  (await workdir.oid()) !== (await commit.oid())
                ) {
                  if (force) {
                    return [
                      'update',
                      fullpath,
                      await commit.oid(),
                      await commit.mode(),
                      (await commit.mode()) !== (await workdir.mode()),
                    ]
                  } else {
                    return ['conflict', fullpath]
                  }
                }
              } else if (force) {
                return [
                  'update',
                  fullpath,
                  await commit.oid(),
                  await commit.mode(),
                  (await commit.mode()) !== (await stage.mode()),
                ]
              }
              // Has file mode changed?
              if ((await commit.mode()) !== (await stage.mode())) {
                return [
                  'update',
                  fullpath,
                  await commit.oid(),
                  await commit.mode(),
                  true,
                ]
              }
              // TODO: HANDLE SYMLINKS
              // Has the file content changed?
              if ((await commit.oid()) !== (await stage.oid())) {
                return [
                  'update',
                  fullpath,
                  await commit.oid(),
                  await commit.mode(),
                  false,
                ]
              } else {
                return
              }
            }
            case 'tree-blob': {
              return ['update-dir-to-blob', fullpath, await commit.oid()]
            }
            case 'blob-tree': {
              return ['update-blob-to-tree', fullpath]
            }
            case 'commit-commit': {
              return [
                'mkdir-index',
                fullpath,
                await commit.oid(),
                await commit.mode(),
              ]
            }
            default: {
              return [
                'error',
                `update entry Unhandled type ${await stage.type()}-${await commit.type()}`,
              ]
            }
          }
        }
      }
    },
    // Modify the default flat mapping
    reduce: async function (parent, children) {
      children = flat(children);
      if (!parent) {
        return children
      } else if (parent && parent[0] === 'rmdir') {
        children.push(parent);
        return children
      } else {
        children.unshift(parent);
        return children
      }
    },
  })
}

async function updateIndex({ index, fullpath, stats, oid }) {
  try {
    index.insert({
      filepath: fullpath,
      stats,
      oid,
    });
  } catch (e) {
    console.warn(`Error inserting ${fullpath} into index:`, e);
  }
}
async function updateWorkingDir(
  { fs, cache, gitdir, dir },
  [method, fullpath, oid, mode, chmod]
) {
  const filepath = `${dir}/${fullpath}`;
  if (method !== 'create-index' && method !== 'mkdir-index') {
    await assertNoSymlinkInLeadingPath(fs, dir, fullpath);
    const { object } = await _readObject({ fs, cache, gitdir, oid });
    if (chmod) {
      await fs.rm(filepath);
    }
    if (mode === 0o100644) {
      // regular file
      await fs.write(filepath, object);
    } else if (mode === 0o100755) {
      // executable file
      await fs.write(filepath, object, { mode: 0o777 });
    } else if (mode === 0o120000) {
      // symlink
      await fs.writelink(filepath, object);
    } else {
      throw new InternalError(
        `Invalid mode 0o${mode.toString(8)} detected in blob ${oid}`
      )
    }
  }
  const stats = await fs.lstat(filepath);
  if (mode === 0o100755) {
    stats.mode = 0o755;
  }
  if (method === 'mkdir-index') {
    stats.mode = 0o160000;
  }
  return [fullpath, oid, stats]
}

async function batchAllSettled(operationName, tasks, onProgress, batchSize) {
  const results = [];
  const rejections = [];
  for (let i = 0; i < tasks.length; i += batchSize) {
    const batch = tasks.slice(i, i + batchSize).map(task => task());
    const batchResults = await Promise.allSettled(batch);
    batchResults.forEach(result => {
      if (result.status === 'fulfilled') {
        results.push(result.value);
      } else {
        rejections.push(result.reason);
        // eslint-disable-next-line no-console
        console.error(
          `[isomorphic-git ${operationName}] task rejected:`,
          result.reason?.stack ?? result.reason
        );
      }
    });
    if (onProgress) {
      await onProgress({
        phase: 'Updating workdir',
        loaded: i + batch.length,
        total: tasks.length,
      });
    }
  }

  if (rejections.length > 0) {
    throw new MultipleGitError(rejections)
  }
  return results
}

// @ts-check

/**
 * Checkout a branch
 *
 * If the branch already exists it will check out that branch. Otherwise, it will create a new remote tracking branch set to track the remote branch of that name.
 *
 * @param {object} args
 * @param {FsClient} args.fs - a file system implementation
 * @param {ProgressCallback} [args.onProgress] - optional progress event callback
 * @param {PostCheckoutCallback} [args.onPostCheckout] - optional post-checkout hook callback
 * @param {string} args.dir - The [working tree](dir-vs-gitdir.md) directory path
 * @param {string} [args.gitdir=join(dir,'.git')] - [required] The [git directory](dir-vs-gitdir.md) path
 * @param {string} [args.ref = 'HEAD'] - Source to checkout files from
 * @param {string[]} [args.filepaths] - Limit the checkout to the given files and directories. If `ref` is not provided, restore them from the index.
 * @param {string} [args.remote = 'origin'] - Which remote repository to use
 * @param {boolean} [args.noCheckout = false] - If true, will update HEAD but won't update the working directory
 * @param {boolean} [args.noUpdateHead] - If true, will update the working directory but won't update HEAD. Defaults to `false` when `ref` is provided, and `true` if `ref` is not provided.
 * @param {boolean} [args.dryRun = false] - If true, simulates a checkout so you can test whether it would succeed.
 * @param {boolean} [args.force = false] - If true, conflicts will be ignored and files will be overwritten regardless of local changes.
 * @param {boolean} [args.track = true] - If false, will not set the remote branch tracking information. Defaults to true.
 * @param {object} [args.cache] - a [cache](cache.md) object
 * @param {boolean} [args.nonBlocking = false] - If true, will use non-blocking file system operations to allow for better performance in certain environments (For example, in Browsers)
 * @param {number} [args.batchSize = 100] - If args.nonBlocking is true, batchSize is the number of files to process at a time avoid blocking the executing thread. The default value of 100 is a good starting point.
 *
 * @returns {Promise<void>} Resolves successfully when filesystem operations are complete
 *
 * @example
 * // switch to the main branch
 * await git.checkout({
 *   fs,
 *   dir: '/tutorial',
 *   ref: 'main'
 * })
 * console.log('done')
 *
 * @example
 * // restore the 'docs' and 'src/docs' folders from the index, overwriting any unstaged changes
 * await git.checkout({
 *   fs,
 *   dir: '/tutorial',
 *   force: true,
 *   filepaths: ['docs', 'src/docs']
 * })
 * console.log('done')
 *
 * @example
 * // restore the 'docs' and 'src/docs' folders to the way they are in the 'develop' branch, overwriting any changes
 * await git.checkout({
 *   fs,
 *   dir: '/tutorial',
 *   ref: 'develop',
 *   noUpdateHead: true,
 *   force: true,
 *   filepaths: ['docs', 'src/docs']
 * })
 * console.log('done')
 */
async function checkout({
  fs,
  onProgress,
  onPostCheckout,
  dir,
  gitdir = join(dir, '.git'),
  remote = 'origin',
  ref: _ref,
  filepaths,
  noCheckout = false,
  noUpdateHead = _ref === undefined,
  dryRun = false,
  force = false,
  track = true,
  cache = {},
  nonBlocking = false,
  batchSize = 100,
}) {
  try {
    assertParameter('fs', fs);
    assertParameter('dir', dir);
    assertParameter('gitdir', gitdir);

    const ref = _ref || 'HEAD';
    const restoreFromIndex =
      _ref === undefined && filepaths != null && filepaths.length > 0;
    const fsp = new FileSystem(fs);
    const updatedGitdir = await discoverGitdir({ fsp, dotgit: gitdir });
    return await _checkout({
      fs: fsp,
      cache,
      onProgress,
      onPostCheckout,
      dir,
      gitdir: updatedGitdir,
      remote,
      ref,
      filepaths,
      noCheckout,
      noUpdateHead,
      dryRun,
      force,
      track,
      restoreFromIndex,
      nonBlocking,
      batchSize,
    })
  } catch (err) {
    err.caller = 'git.checkout';
    throw err
  }
}

const LINEBREAKS = /^.*(\r?\n|$)/gm;

function mergeFile({ branches, contents }) {
  const ourName = branches[1];
  const theirName = branches[2];

  const baseContent = contents[0];
  const ourContent = contents[1];
  const theirContent = contents[2];

  const ours = ourContent.match(LINEBREAKS);
  const base = baseContent.match(LINEBREAKS);
  const theirs = theirContent.match(LINEBREAKS);

  // Here we let the diff3 library do the heavy lifting.
  const result = diff3Merge(ours, base, theirs);

  const markerSize = 7;

  // Here we note whether there are conflicts and format the results
  let mergedText = '';
  let cleanMerge = true;

  for (const item of result) {
    if (item.ok) {
      mergedText += item.ok.join('');
    }
    if (item.conflict) {
      cleanMerge = false;
      mergedText += `${'<'.repeat(markerSize)} ${ourName}\n`;
      mergedText += item.conflict.a.join('');

      mergedText += `${'='.repeat(markerSize)}\n`;
      mergedText += item.conflict.b.join('');
      mergedText += `${'>'.repeat(markerSize)} ${theirName}\n`;
    }
  }
  return { cleanMerge, mergedText }
}

// @ts-check

/**
 * Create a merged tree
 *
 * @param {Object} args
 * @param {import('../models/FileSystem.js').FileSystem} args.fs
 * @param {object} args.cache
 * @param {string} [args.dir] - The [working tree](dir-vs-gitdir.md) directory path
 * @param {string} [args.gitdir=join(dir,'.git')] - [required] The [git directory](dir-vs-gitdir.md) path
 * @param {string} args.ourOid - The SHA-1 object id of our tree
 * @param {string} args.baseOid - The SHA-1 object id of the base tree
 * @param {string} args.theirOid - The SHA-1 object id of their tree
 * @param {string} [args.ourName='ours'] - The name to use in conflicted files for our hunks
 * @param {string} [args.baseName='base'] - The name to use in conflicted files (in diff3 format) for the base hunks
 * @param {string} [args.theirName='theirs'] - The name to use in conflicted files for their hunks
 * @param {boolean} [args.dryRun=false]
 * @param {boolean} [args.abortOnConflict=false]
 * @param {MergeDriverCallback} [args.mergeDriver]
 *
 * @returns {Promise<string>} - The SHA-1 object id of the merged tree
 *
 */
async function mergeTree({
  fs,
  cache,
  dir,
  gitdir = join(dir, '.git'),
  index,
  ourOid,
  baseOid,
  theirOid,
  ourName = 'ours',
  baseName = 'base',
  theirName = 'theirs',
  dryRun = false,
  abortOnConflict = true,
  mergeDriver,
}) {
  const ourTree = TREE({ ref: ourOid });
  const baseTree = TREE({ ref: baseOid });
  const theirTree = TREE({ ref: theirOid });

  const unmergedFiles = [];
  const bothModified = [];
  const deleteByUs = [];
  const deleteByTheirs = [];

  const results = await _walk({
    fs,
    cache,
    dir,
    gitdir,
    trees: [ourTree, baseTree, theirTree],
    map: async function (filepath, [ours, base, theirs]) {
      const path = basename(filepath);
      // What we did, what they did
      const ourChange = await modified(ours, base);
      const theirChange = await modified(theirs, base);
      switch (`${ourChange}-${theirChange}`) {
        case 'false-false': {
          return {
            mode: await base.mode(),
            path,
            oid: await base.oid(),
            type: await base.type(),
          }
        }
        case 'false-true': {
          // if directory is deleted in theirs but not in ours we return our directory
          if (!theirs && (await ours.type()) === 'tree') {
            return {
              mode: await ours.mode(),
              path,
              oid: await ours.oid(),
              type: await ours.type(),
            }
          }

          return theirs
            ? {
                mode: await theirs.mode(),
                path,
                oid: await theirs.oid(),
                type: await theirs.type(),
              }
            : undefined
        }
        case 'true-false': {
          // if directory is deleted in ours but not in theirs we return their directory
          if (!ours && (await theirs.type()) === 'tree') {
            return {
              mode: await theirs.mode(),
              path,
              oid: await theirs.oid(),
              type: await theirs.type(),
            }
          }

          return ours
            ? {
                mode: await ours.mode(),
                path,
                oid: await ours.oid(),
                type: await ours.type(),
              }
            : undefined
        }
        case 'true-true': {
          // Handle tree-tree merges (directories)
          if (
            ours &&
            theirs &&
            (await ours.type()) === 'tree' &&
            (await theirs.type()) === 'tree'
          ) {
            return {
              mode: await ours.mode(),
              path,
              oid: await ours.oid(),
              type: 'tree',
            }
          }

          // Modifications - both are blobs
          if (
            ours &&
            theirs &&
            (await ours.type()) === 'blob' &&
            (await theirs.type()) === 'blob'
          ) {
            return mergeBlobs({
              fs,
              gitdir,
              path,
              ours,
              base,
              theirs,
              ourName,
              baseName,
              theirName,
              mergeDriver,
            }).then(async r => {
              if (!r.cleanMerge) {
                unmergedFiles.push(filepath);
                bothModified.push(filepath);
                if (!abortOnConflict) {
                  let baseOid = '';
                  if (base && (await base.type()) === 'blob') {
                    baseOid = await base.oid();
                  }
                  const ourOid = await ours.oid();
                  const theirOid = await theirs.oid();

                  index.delete({ filepath });

                  if (baseOid) {
                    index.insert({ filepath, oid: baseOid, stage: 1 });
                  }
                  index.insert({ filepath, oid: ourOid, stage: 2 });
                  index.insert({ filepath, oid: theirOid, stage: 3 });
                }
              } else if (!abortOnConflict) {
                index.insert({ filepath, oid: r.mergeResult.oid, stage: 0 });
              }
              return r.mergeResult
            })
          }

          // deleted by us
          if (
            base &&
            !ours &&
            theirs &&
            (await base.type()) === 'blob' &&
            (await theirs.type()) === 'blob'
          ) {
            unmergedFiles.push(filepath);
            deleteByUs.push(filepath);
            if (!abortOnConflict) {
              const baseOid = await base.oid();
              const theirOid = await theirs.oid();

              index.delete({ filepath });

              index.insert({ filepath, oid: baseOid, stage: 1 });
              index.insert({ filepath, oid: theirOid, stage: 3 });
            }

            return {
              mode: await theirs.mode(),
              oid: await theirs.oid(),
              type: 'blob',
              path,
            }
          }

          // deleted by theirs
          if (
            base &&
            ours &&
            !theirs &&
            (await base.type()) === 'blob' &&
            (await ours.type()) === 'blob'
          ) {
            unmergedFiles.push(filepath);
            deleteByTheirs.push(filepath);
            if (!abortOnConflict) {
              const baseOid = await base.oid();
              const ourOid = await ours.oid();

              index.delete({ filepath });

              index.insert({ filepath, oid: baseOid, stage: 1 });
              index.insert({ filepath, oid: ourOid, stage: 2 });
            }

            return {
              mode: await ours.mode(),
              oid: await ours.oid(),
              type: 'blob',
              path,
            }
          }

          // deleted by both
          if (
            base &&
            !ours &&
            !theirs &&
            ((await base.type()) === 'blob' || (await base.type()) === 'tree')
          ) {
            return undefined
          }

          // all other types of conflicts fail
          // TODO: Merge conflicts involving additions
          throw new MergeNotSupportedError()
        }
      }
    },
    /**
     * @param {TreeEntry} [parent]
     * @param {Array<TreeEntry>} children
     */
    reduce:
      unmergedFiles.length !== 0 && (!dir || abortOnConflict)
        ? undefined
        : async (parent, children) => {
            const entries = children.filter(Boolean); // remove undefineds

            // if the parent was deleted, the children have to go
            if (!parent) return

            // automatically delete directories if they have been emptied
            // except for the root directory
            if (
              parent &&
              parent.type === 'tree' &&
              entries.length === 0 &&
              parent.path !== '.'
            )
              return

            if (
              entries.length > 0 ||
              (parent.path === '.' && entries.length === 0)
            ) {
              const tree = new GitTree(entries);
              const object = tree.toObject();
              const oid = await _writeObject({
                fs,
                gitdir,
                type: 'tree',
                object,
                dryRun,
              });
              parent.oid = oid;
            }
            return parent
          },
  });

  if (unmergedFiles.length !== 0) {
    if (dir && !abortOnConflict) {
      await _walk({
        fs,
        cache,
        dir,
        gitdir,
        trees: [TREE({ ref: results.oid })],
        map: async function (filepath, [entry]) {
          const path = `${dir}/${filepath}`;
          if ((await entry.type()) === 'blob') {
            const mode = await entry.mode();
            const content = await entry.content();
            await fs.write(path, content, { mode });
          }
          return true
        },
      });
    }
    return new MergeConflictError(
      unmergedFiles,
      bothModified,
      deleteByUs,
      deleteByTheirs
    )
  }

  return results.oid
}

/**
 *
 * @param {Object} args
 * @param {import('../models/FileSystem').FileSystem} args.fs
 * @param {string} args.gitdir
 * @param {string} args.path
 * @param {WalkerEntry} args.ours
 * @param {WalkerEntry} args.base
 * @param {WalkerEntry} args.theirs
 * @param {string} [args.ourName]
 * @param {string} [args.baseName]
 * @param {string} [args.theirName]
 * @param {boolean} [args.dryRun = false]
 * @param {MergeDriverCallback} [args.mergeDriver]
 *
 */
async function mergeBlobs({
  fs,
  gitdir,
  path,
  ours,
  base,
  theirs,
  ourName,
  theirName,
  baseName,
  dryRun,
  mergeDriver = mergeFile,
}) {
  const type = 'blob';
  // Compute the new mode.
  // Since there are ONLY two valid blob modes ('100755' and '100644') it boils down to this
  let baseMode = '100755';
  let baseOid = '';
  let baseContent = '';
  if (base && (await base.type()) === 'blob') {
    baseMode = await base.mode();
    baseOid = await base.oid();
    baseContent = Buffer.from(await base.content()).toString('utf8');
  }
  const mode =
    baseMode === (await ours.mode()) ? await theirs.mode() : await ours.mode();
  // The trivial case: nothing to merge except maybe mode
  if ((await ours.oid()) === (await theirs.oid())) {
    return {
      cleanMerge: true,
      mergeResult: { mode, path, oid: await ours.oid(), type },
    }
  }
  // if only one side made oid changes, return that side's oid
  if ((await ours.oid()) === baseOid) {
    return {
      cleanMerge: true,
      mergeResult: { mode, path, oid: await theirs.oid(), type },
    }
  }
  if ((await theirs.oid()) === baseOid) {
    return {
      cleanMerge: true,
      mergeResult: { mode, path, oid: await ours.oid(), type },
    }
  }
  // if both sides made changes do a merge
  const ourContent = Buffer.from(await ours.content()).toString('utf8');
  const theirContent = Buffer.from(await theirs.content()).toString('utf8');
  const { mergedText, cleanMerge } = await mergeDriver({
    branches: [baseName, ourName, theirName],
    contents: [baseContent, ourContent, theirContent],
    path,
  });
  const oid = await _writeObject({
    fs,
    gitdir,
    type: 'blob',
    object: Buffer.from(mergedText, 'utf8'),
    dryRun,
  });

  return { cleanMerge, mergeResult: { mode, path, oid, type } }
}

const _TreeMap = {
  stage: STAGE,
  workdir: WORKDIR,
};

// make sure filepath, blob type and blob object (from loose objects) plus oid are in sync and valid
async function checkAndWriteBlob(fs, gitdir, dir, filepath, oid = null) {
  const currentFilepath = join(dir, filepath);
  const stats = await fs.lstat(currentFilepath);
  if (!stats) throw new NotFoundError(currentFilepath)
  if (stats.isDirectory())
    throw new InternalError(
      `${currentFilepath}: file expected, but found directory`
    )

  // Look for it in the loose object directory.
  const objContent = oid
    ? await readObjectLoose({ fs, gitdir, oid })
    : undefined;
  let retOid = objContent ? oid : undefined;
  if (!objContent) {
    await acquireLock(currentFilepath, async () => {
      const object = stats.isSymbolicLink()
        ? await fs.readlink(currentFilepath).then(posixifyPathBuffer)
        : await fs.read(currentFilepath);

      if (object === null) throw new NotFoundError(currentFilepath)

      retOid = await _writeObject({ fs, gitdir, type: 'blob', object });
    });
  }

  return retOid
}

async function processTreeEntries({ fs, dir, gitdir, entries }) {
  // make sure each tree entry has valid oid
  async function processTreeEntry(entry) {
    if (entry.type === 'tree') {
      if (!entry.oid) {
        // Process children entries if the current entry is a tree
        const children = await Promise.all(entry.children.map(processTreeEntry));
        // Write the tree with the processed children
        entry.oid = await _writeTree({
          fs,
          gitdir,
          tree: children,
        });
        entry.mode = 0o40000; // directory
      }
    } else if (entry.type === 'blob') {
      entry.oid = await checkAndWriteBlob(
        fs,
        gitdir,
        dir,
        entry.path,
        entry.oid
      );
      entry.mode = 0o100644; // file
    }

    // remove path from entry.path
    entry.path = entry.path.split('/').pop();
    return entry
  }

  return Promise.all(entries.map(processTreeEntry))
}

async function writeTreeChanges({
  fs,
  dir,
  gitdir,
  treePair, // [TREE({ ref: 'HEAD' }), 'STAGE'] would be the equivalent of `git write-tree`
}) {
  const isStage = treePair[1] === 'stage';
  const trees = treePair.map(t => (typeof t === 'string' ? _TreeMap[t]() : t));

  const changedEntries = [];
  // transform WalkerEntry objects into the desired format
  const map = async (filepath, [head, stage]) => {
    if (
      filepath === '.' ||
      (await GitIgnoreManager.isIgnored({ fs, dir, gitdir, filepath }))
    ) {
      return
    }

    if (stage) {
      if (
        !head ||
        ((await head.oid()) !== (await stage.oid()) &&
          (await stage.oid()) !== undefined)
      ) {
        changedEntries.push([head, stage]);
      }
      return {
        mode: await stage.mode(),
        path: filepath,
        oid: await stage.oid(),
        type: await stage.type(),
      }
    }
  };

  // combine mapped entries with their parent results
  const reduce = async (parent, children) => {
    children = children.filter(Boolean); // Remove undefined entries
    if (!parent) {
      return children.length > 0 ? children : undefined
    } else {
      parent.children = children;
      return parent
    }
  };

  // if parent is skipped, skip the children
  const iterate = async (walk, children) => {
    const filtered = [];
    for (const child of children) {
      const [head, stage] = child;
      if (isStage) {
        if (stage) {
          // for deleted file in work dir, it also needs to be added on stage
          if (await fs.exists(`${dir}/${stage.toString()}`)) {
            filtered.push(child);
          } else {
            changedEntries.push([null, stage]); // record the change (deletion) while stop the iteration
          }
        }
      } else if (head) {
        // for deleted file in workdir, "stage" (workdir in our case) will be undefined
        if (!stage) {
          changedEntries.push([head, null]); // record the change (deletion) while stop the iteration
        } else {
          filtered.push(child); // workdir, tracked only
        }
      }
    }
    return filtered.length ? Promise.all(filtered.map(walk)) : []
  };

  const entries = await _walk({
    fs,
    cache: {},
    dir,
    gitdir,
    trees,
    map,
    reduce,
    iterate,
  });

  if (changedEntries.length === 0 || entries.length === 0) {
    return null // no changes found to stash
  }

  const processedEntries = await processTreeEntries({
    fs,
    dir,
    gitdir,
    entries,
  });

  const treeEntries = processedEntries.filter(Boolean).map(entry => ({
    mode: entry.mode,
    path: entry.path,
    oid: entry.oid,
    type: entry.type,
  }));

  return _writeTree({ fs, gitdir, tree: treeEntries })
}

async function applyTreeChanges({
  fs,
  dir,
  gitdir,
  stashCommit,
  parentCommit,
  wasStaged,
}) {
  const dirRemoved = [];
  const stageUpdated = [];

  // analyze the changes
  const ops = await _walk({
    fs,
    cache: {},
    dir,
    gitdir,
    trees: [TREE({ ref: parentCommit }), TREE({ ref: stashCommit })],
    map: async (filepath, [parent, stash]) => {
      if (
        filepath === '.' ||
        (await GitIgnoreManager.isIgnored({ fs, dir, gitdir, filepath }))
      ) {
        return
      }
      const type = stash ? await stash.type() : await parent.type();
      if (type !== 'tree' && type !== 'blob') {
        return
      }

      // deleted tree or blob
      if (!stash && parent) {
        const method = type === 'tree' ? 'rmdir' : 'rm';
        if (type === 'tree') dirRemoved.push(filepath);
        if (type === 'blob' && wasStaged)
          stageUpdated.push({ filepath, oid: await parent.oid() }); // stats is undefined, will stage the deletion with index.insert
        return { method, filepath }
      }

      const oid = await stash.oid();
      if (!parent || (await parent.oid()) !== oid) {
        // only apply changes if changed from the parent commit or doesn't exist in the parent commit
        if (type === 'tree') {
          return { method: 'mkdir', filepath }
        } else {
          if (wasStaged)
            stageUpdated.push({
              filepath,
              oid,
              stats: await fs.lstat(join(dir, filepath)),
            });
          return {
            method: 'write',
            filepath,
            oid,
          }
        }
      }
    },
  });

  // apply the changes to work dir
  await acquireLock(gitdir, async () => {
    for (const op of ops) {
      const currentFilepath = join(dir, op.filepath);
      switch (op.method) {
        case 'rmdir':
          await fs.rmdir(currentFilepath);
          break
        case 'mkdir':
          // Don't mkdir through a symlinked leading path: a parent component that
          // is a symlink could otherwise redirect the directory creation outside
          // the working tree. git applies the same check (it does not follow
          // symlinks here) — see checkout.
          await assertNoSymlinkInLeadingPath(fs, dir, op.filepath);
          await fs.mkdir(currentFilepath);
          break
        case 'rm':
          await fs.rm(currentFilepath);
          break
        case 'write':
          // only writes if file is not in the removedDirs
          if (
            !dirRemoved.some(removedDir =>
              currentFilepath.startsWith(removedDir)
            )
          ) {
            // Don't write through a symlinked leading path (see checkout): a
            // parent component that is a symlink could redirect the write to a
            // location outside the working tree.
            await assertNoSymlinkInLeadingPath(fs, dir, op.filepath);
            const { object } = await _readObject({
              fs,
              cache: {},
              gitdir,
              oid: op.oid,
            });
            // just like checkout, since mode only applicable to create, not update, delete first
            if (await fs.exists(currentFilepath)) {
              await fs.rm(currentFilepath);
            }
            await fs.write(currentFilepath, object); // only handles regular files for now
          }
          break
      }
    }
  });

  // update the stage
  await GitIndexManager.acquire({ fs, gitdir, cache: {} }, async index => {
    stageUpdated.forEach(({ filepath, stats, oid }) => {
      index.insert({ filepath, stats, oid });
    });
  });
}

// @ts-check

/**
 * @param {object} args
 * @param {import('../models/FileSystem.js').FileSystem} args.fs
 * @param {object} args.cache
 * @param {string} args.dir
 * @param {string} args.gitdir
 * @param {string} args.oid - The commit to cherry-pick
 * @param {boolean} args.dryRun
 * @param {boolean} args.noUpdateBranch
 * @param {boolean} args.abortOnConflict
 * @param {Object} [args.committer]
 * @param {string} [args.committer.name]
 * @param {string} [args.committer.email]
 * @param {number} [args.committer.timestamp]
 * @param {number} [args.committer.timezoneOffset]
 * @param {MergeDriverCallback} [args.mergeDriver]
 *
 * @returns {Promise<string>} - The OID of the newly created commit
 */
async function _cherryPick({
  fs,
  cache,
  dir,
  gitdir,
  oid,
  dryRun = false,
  noUpdateBranch = false,
  abortOnConflict = true,
  committer,
  mergeDriver,
}) {
  // Commit to cherry-pick
  const { commit: cherryCommit, oid: cherryOid } = await _readCommit({
    fs,
    cache,
    gitdir,
    oid,
  });

  // Validate it's not a merge commit (>1 parent)
  if (cherryCommit.parent.length > 1) {
    throw new CherryPickMergeCommitError(cherryOid, cherryCommit.parent.length)
  }

  // Validate it's not an initial commit (0 parents)
  if (cherryCommit.parent.length === 0) {
    throw new CherryPickRootCommitError(cherryOid)
  }

  // Get current HEAD
  const currentOid = await GitRefManager.resolve({
    fs,
    gitdir,
    ref: 'HEAD',
  });

  const { commit: currentCommit } = await _readCommit({
    fs,
    cache,
    gitdir,
    oid: currentOid,
  });

  // Get parent of cherry-picked commit (the "base" for three-way merge)
  const cherryParentOid = cherryCommit.parent[0];
  const { commit: cherryParent } = await _readCommit({
    fs,
    cache,
    gitdir,
    oid: cherryParentOid,
  });

  // Three-way merge
  // - ourOid: current HEAD tree
  // - baseOid: parent of commit being cherry-picked
  // - theirOid: the commit being cherry-picked
  const mergedTreeOid = await GitIndexManager.acquire(
    { fs, gitdir, cache, allowUnmerged: false },
    async index => {
      return mergeTree({
        fs,
        cache,
        dir,
        gitdir,
        index,
        ourOid: currentCommit.tree,
        baseOid: cherryParent.tree,
        theirOid: cherryCommit.tree,
        ourName: 'HEAD',
        baseName: `parent of ${cherryOid.slice(0, 7)}`,
        theirName: cherryOid.slice(0, 7),
        dryRun,
        abortOnConflict,
        mergeDriver,
      })
    }
  );

  if (mergedTreeOid instanceof MergeConflictError) {
    throw mergedTreeOid
  }

  // Create new commit with single parent
  const newOid = await _commit({
    fs,
    cache,
    gitdir,
    message: cherryCommit.message,
    tree: mergedTreeOid,
    parent: [currentOid], // Single parent: current HEAD
    author: cherryCommit.author, // Preserve original author
    committer, // New committer
    dryRun,
    noUpdateBranch,
  });

  // If we actually updated the branch (not a dryRun and branch pointer updated),
  // make the working tree and index match the newly created commit so there are
  // no staged/unstaged changes left after a successful cherry-pick.
  // Skip it when `noUpdateBranch` is true.
  if (dir && !dryRun && !noUpdateBranch) {
    await applyTreeChanges({
      fs,
      dir,
      gitdir,
      stashCommit: newOid,
      parentCommit: currentOid,
      wasStaged: true,
    });
  }

  return newOid
}

// @ts-check

/**
 * Cherry-pick a commit onto the current branch
 *
 * @param {object} args
 * @param {FsClient} args.fs - a file system implementation
 * @param {string} [args.dir] - The [working tree](dir-vs-gitdir.md) directory path
 * @param {string} [args.gitdir=join(dir, '.git')] - [required] The [git directory](dir-vs-gitdir.md) path
 * @param {string} args.oid - The commit to cherry-pick
 * @param {object} [args.cache] - a [cache](cache.md) object
 * @param {object} [args.committer] - The details about the commit committer. If not specified, uses user.name and user.email config with current timestamp.
 * @param {string} [args.committer.name] - Default is `user.name` config.
 * @param {string} [args.committer.email] - Default is `user.email` config.
 * @param {number} [args.committer.timestamp=Math.floor(Date.now()/1000)] - Set the committer timestamp field. This is the integer number of seconds since the Unix epoch (1970-01-01 00:00:00).
 * @param {number} [args.committer.timezoneOffset] - Set the committer timezone offset field. This is the difference, in minutes, from the current timezone to UTC. Default is `(new Date()).getTimezoneOffset()`.
 * @param {boolean} [args.dryRun=false] - If true, simulates cherry-picking so you can test whether it would succeed. Implies `noUpdateBranch`.
 * @param {boolean} [args.noUpdateBranch=false] - If true, does not update the branch pointer after creating the commit.
 * @param {boolean} [args.abortOnConflict=true] - If true, merges with conflicts will throw a `MergeConflictError`. If false, merge conflicts will leave conflict markers in the working directory and index.
 * @param {MergeDriverCallback} [args.mergeDriver] - A custom merge driver for handling conflicts.
 *
 * @returns {Promise<string>} Resolves successfully with the SHA-1 object id of the newly created commit
 *
 * @example
 * let oid = await git.cherryPick({
 *   fs,
 *   dir: '/tutorial',
 *   oid: 'e10ebb90d03eaacca84de1af0a59b444232da99e'
 * })
 * console.log(oid)
 *
 */
async function cherryPick({
  fs: _fs,
  dir,
  gitdir = join(dir, '.git'),
  oid,
  cache = {},
  committer,
  dryRun = false,
  noUpdateBranch = false,
  abortOnConflict = true,
  mergeDriver,
}) {
  try {
    assertParameter('fs', _fs);
    assertParameter('gitdir', gitdir);
    assertParameter('oid', oid);

    const fs = new FileSystem(_fs);
    const updatedGitdir = await discoverGitdir({ fsp: fs, dotgit: gitdir });

    // Read the commit to be cherry-picked
    const { commit: cherryCommit } = await _readCommit({
      fs,
      cache,
      gitdir: updatedGitdir,
      oid,
    });

    // If the target is a merge commit, let the command layer handle rejecting it
    // (so tests expecting a CherryPickMergeCommitError still work). Only enforce
    // a committer when we are actually going to create a commit.
    if (cherryCommit.parent && cherryCommit.parent.length > 1) {
      return await _cherryPick({
        fs,
        cache,
        dir,
        gitdir: updatedGitdir,
        oid,
        dryRun,
        noUpdateBranch,
        abortOnConflict,
        committer: undefined,
        mergeDriver,
      })
    }

    // Use provided committer, not the original commit's committer
    const normalizedCommitter = await normalizeCommitterObject({
      fs,
      gitdir: updatedGitdir,
      committer,
    });
    if (!normalizedCommitter) {
      throw new MissingNameError('committer')
    }

    return await _cherryPick({
      fs,
      cache,
      dir,
      gitdir: updatedGitdir,
      oid,
      dryRun,
      noUpdateBranch,
      abortOnConflict,
      committer: normalizedCommitter,
      mergeDriver,
    })
  } catch (err) {
    err.caller = 'git.cherryPick';
    throw err
  }
}

// @see https://git-scm.com/docs/git-rev-parse.html#_specifying_revisions
const abbreviateRx = /^refs\/(heads\/|tags\/|remotes\/)?(.*)/;

function abbreviateRef(ref) {
  const match = abbreviateRx.exec(ref);
  if (match) {
    if (match[1] === 'remotes/' && ref.endsWith('/HEAD')) {
      return match[2].slice(0, -5)
    } else {
      return match[2]
    }
  }
  return ref
}

// @ts-check

/**
 * @param {Object} args
 * @param {import('../models/FileSystem.js').FileSystem} args.fs
 * @param {string} args.gitdir
 * @param {boolean} [args.fullname = false] - Return the full path (e.g. "refs/heads/main") instead of the abbreviated form.
 * @param {boolean} [args.test = false] - If the current branch doesn't actually exist (such as right after git init) then return `undefined`.
 *
 * @returns {Promise<string|void>} The name of the current branch or undefined if the HEAD is detached.
 *
 */
async function _currentBranch({
  fs,
  gitdir,
  fullname = false,
  test = false,
}) {
  const ref = await GitRefManager.resolve({
    fs,
    gitdir,
    ref: 'HEAD',
    depth: 2,
  });
  if (test) {
    try {
      await GitRefManager.resolve({ fs, gitdir, ref });
    } catch (_) {
      return
    }
  }
  // Return `undefined` for detached HEAD
  if (!ref.startsWith('refs/')) return
  return fullname ? ref : abbreviateRef(ref)
}

function translateSSHtoHTTP(url) {
  // handle "shorter scp-like syntax". The user is dropped: it names an ssh
  // account and means nothing over https, which is what the old expression did
  // for `git@` too.
  url = url.replace(/^[^/@:]+@([^/@:]+):/, 'https://$1/');
  // handle proper SSH URLs
  url = url.replace(/^ssh:\/\//, 'https://');
  return url
}

function calculateBasicAuthHeader({ username = '', password = '' }) {
  return `Basic ${Buffer.from(`${username}:${password}`).toString('base64')}`
}

// Currently 'for await' upsets my linters.
async function forAwait(iterable, cb) {
  const iter = getIterator(iterable);
  while (true) {
    const { value, done } = await iter.next();
    if (value) await cb(value);
    if (done) break
  }
  if (iter.return) iter.return();
}

async function collect(iterable) {
  let size = 0;
  const buffers = [];
  // This will be easier once `for await ... of` loops are available.
  await forAwait(iterable, value => {
    buffers.push(value);
    size += value.byteLength;
  });
  const result = new Uint8Array(size);
  let nextIndex = 0;
  for (const buffer of buffers) {
    result.set(buffer, nextIndex);
    nextIndex += buffer.byteLength;
  }
  return result
}

// The `@` that ends the credentials is the last one in the authority, and the
// scheme is matched case-insensitively: `HTTPS://user:pass@host/x` is a URL
// like any other, and leaving the credentials in it is what `fetch` rejects.
// The authority ends at the first `/`, `?` or `#`, so an `@` that lives in a
// query or a fragment is left where it is.
const CREDENTIALS = /^(https?:\/\/)([^/?#]+)@/i;

function extractAuthFromUrl(url) {
  // For whatever reason, the `fetch` API does not convert credentials embedded in the URL
  // into Basic Authentication headers automatically. Instead it throws an error!
  // So we must manually parse the URL, rip out the user:password portion if it is present
  // and compute the Authorization header.
  const credentials = url.match(CREDENTIALS);
  // No credentials, return the url unmodified and an empty auth object
  if (credentials == null) return { url, auth: {} }
  // Has credentials, return the fetch-safe URL and the parsed credentials.
  // The credentials are cut out of the original string rather than read back
  // off the parsed URL: serializing that one would also drop an explicit
  // `:443` and append a slash to a URL that has no path, and this return value
  // is what the request goes out against.
  return {
    url: url.replace(CREDENTIALS, '$1'),
    auth: parseUserinfo(url, credentials[2]),
  }
}

function parseUserinfo(url, userpass) {
  // `URL` splits the two halves the way the platform does, so the first colon
  // separates them and any later one stays in the password. Only the split is
  // taken from it, for the reason above.
  const parsed = parseUrl(url);
  // A password is absent, not empty, when no colon was written at all. `URL`
  // reports `''` for both, and the difference is worth keeping.
  const hasPassword = userpass.indexOf(':') !== -1;

  if (parsed !== null) {
    return {
      username: decodeUserinfo(parsed.username),
      password: hasPassword ? decodeUserinfo(parsed.password) : undefined,
    }
  }

  // No `URL` to parse with, or it rejected a string the expression above
  // accepted. Split on the first colon by hand, without the percent-decoding.
  const separatorIndex = userpass.indexOf(':');
  return {
    username: hasPassword ? userpass.slice(0, separatorIndex) : userpass,
    password: hasPassword ? userpass.slice(separatorIndex + 1) : undefined,
  }
}

function parseUrl(url) {
  if (typeof URL !== 'function') return null
  try {
    return new URL(url)
  } catch (_) {
    return null
  }
}

// `URL` hands back the userinfo still percent-encoded, so `p:ss` arrives as
// `p%3Ass` and has to be decoded before it reaches the Authorization header. A
// lone `%` is not something the parser encodes, and it makes the decode throw,
// so the raw value stands in whenever the decode fails.
function decodeUserinfo(value) {
  try {
    return decodeURIComponent(value)
  } catch (_) {
    return value
  }
}

function padHex(b, n) {
  const s = n.toString(16);
  return '0'.repeat(b - s.length) + s
}

/**
pkt-line Format
---------------

Much (but not all) of the payload is described around pkt-lines.

A pkt-line is a variable length binary string.  The first four bytes
of the line, the pkt-len, indicates the total length of the line,
in hexadecimal.  The pkt-len includes the 4 bytes used to contain
the length's hexadecimal representation.

A pkt-line MAY contain binary data, so implementers MUST ensure
pkt-line parsing/formatting routines are 8-bit clean.

A non-binary line SHOULD BE terminated by an LF, which if present
MUST be included in the total length. Receivers MUST treat pkt-lines
with non-binary data the same whether or not they contain the trailing
LF (stripping the LF if present, and not complaining when it is
missing).

The maximum length of a pkt-line's data component is 65516 bytes.
Implementations MUST NOT send pkt-line whose length exceeds 65520
(65516 bytes of payload + 4 bytes of length data).

Implementations SHOULD NOT send an empty pkt-line ("0004").

A pkt-line with a length field of 0 ("0000"), called a flush-pkt,
is a special case and MUST be handled differently than an empty
pkt-line ("0004").

----
  pkt-line     =  data-pkt / flush-pkt

  data-pkt     =  pkt-len pkt-payload
  pkt-len      =  4*(HEXDIG)
  pkt-payload  =  (pkt-len - 4)*(OCTET)

  flush-pkt    = "0000"
----

Examples (as C-style strings):

----
  pkt-line          actual value
  ---------------------------------
  "0006a\n"         "a\n"
  "0005a"           "a"
  "000bfoobar\n"    "foobar\n"
  "0004"            ""
----
*/

// I'm really using this more as a namespace.
// There's not a lot of "state" in a pkt-line

class GitPktLine {
  static flush() {
    return Buffer.from('0000', 'utf8')
  }

  static delim() {
    return Buffer.from('0001', 'utf8')
  }

  static encode(line) {
    if (typeof line === 'string') {
      line = Buffer.from(line);
    }
    const length = line.length + 4;
    const hexlength = padHex(4, length);
    return Buffer.concat([Buffer.from(hexlength, 'utf8'), line])
  }

  static streamReader(stream) {
    const reader = new StreamReader(stream);
    return async function read() {
      try {
        let length = await reader.read(4);
        if (length == null) return true
        length = parseInt(length.toString('utf8'), 16);
        if (length === 0) return null
        if (length === 1) return null // delim packets
        const buffer = await reader.read(length - 4);
        if (buffer == null) return true
        return buffer
      } catch (err) {
        stream.error = err;
        return true
      }
    }
  }
}

// @ts-check

/**
 * @param {function} read
 */
async function parseCapabilitiesV2(read) {
  /** @type {Object<string, string | true>} */
  const capabilities2 = {};

  let line;
  while (true) {
    line = await read();
    if (line === true) break
    if (line === null) continue
    line = line.toString('utf8').replace(/\n$/, '');
    const i = line.indexOf('=');
    if (i > -1) {
      const key = line.slice(0, i);
      const value = line.slice(i + 1);
      capabilities2[key] = value;
    } else {
      capabilities2[line] = true;
    }
  }
  return { protocolVersion: 2, capabilities2 }
}

async function parseRefsAdResponse(stream, { service }) {
  const capabilities = new Set();
  const refs = new Map();
  const symrefs = new Map();

  // There is probably a better way to do this, but for now
  // let's just throw the result parser inline here.
  const read = GitPktLine.streamReader(stream);
  let lineOne = await read();
  // skip past any flushes
  while (lineOne === null) lineOne = await read();

  if (lineOne === true) throw new EmptyServerResponseError()

  // Handle protocol v2 responses (Bitbucket Server doesn't include a `# service=` line)
  if (lineOne.includes('version 2')) {
    return parseCapabilitiesV2(read)
  }

  // Clients MUST ignore an LF at the end of the line.
  if (lineOne.toString('utf8').replace(/\n$/, '') !== `# service=${service}`) {
    throw new ParseError(`# service=${service}\\n`, lineOne.toString('utf8'))
  }
  let lineTwo = await read();
  // skip past any flushes
  while (lineTwo === null) lineTwo = await read();
  // In the edge case of a brand new repo, zero refs (and zero capabilities)
  // are returned.
  if (lineTwo === true) return { capabilities, refs, symrefs }
  lineTwo = lineTwo.toString('utf8');

  // Handle protocol v2 responses
  if (lineTwo.includes('version 2')) {
    return parseCapabilitiesV2(read)
  }

  const [firstRef, capabilitiesLine] = splitAndAssert(lineTwo, '\x00', '\\x00');
  capabilitiesLine.split(' ').map(x => capabilities.add(x));
  // see no-refs in https://git-scm.com/docs/pack-protocol#_reference_discovery (since git 2.41.0)
  if (firstRef !== '0000000000000000000000000000000000000000 capabilities^{}') {
    const [ref, name] = splitAndAssert(firstRef, ' ', ' ');
    refs.set(name, ref);
    while (true) {
      const line = await read();
      if (line === true) break
      if (line !== null) {
        const [ref, name] = splitAndAssert(line.toString('utf8'), ' ', ' ');
        refs.set(name, ref);
      }
    }
  }
  // Symrefs are thrown into the "capabilities" unfortunately.
  for (const cap of capabilities) {
    if (cap.startsWith('symref=')) {
      const m = cap.match(/symref=([^:]+):(.*)/);
      if (m.length === 3) {
        symrefs.set(m[1], m[2]);
      }
    }
  }
  return { protocolVersion: 1, capabilities, refs, symrefs }
}

function splitAndAssert(line, sep, expected) {
  const split = line.trim().split(sep);
  if (split.length !== 2) {
    throw new ParseError(
      `Two strings separated by '${expected}'`,
      line.toString('utf8')
    )
  }
  return split
}

// Try to accommodate known CORS proxy implementations:
// - https://jcubic.pl/proxy.php?  <-- uses query string
// - https://cors.isomorphic-git.org  <-- uses path
const corsProxify = (corsProxy, url) =>
  corsProxy.endsWith('?')
    ? `${corsProxy}${url}`
    : `${corsProxy}/${url.replace(/^https?:\/\//, '')}`;

const updateHeaders = (headers, auth) => {
  // Update the basic auth header
  if (auth.username || auth.password) {
    headers.Authorization = calculateBasicAuthHeader(auth);
  }
  // but any manually provided headers take precedence
  if (auth.headers) {
    Object.assign(headers, auth.headers);
  }
};

/**
 * @param {GitHttpResponse} res
 *
 * @returns {{ preview: string, response: string, data: Buffer }}
 */
const stringifyBody = async res => {
  try {
    // Some services provide a meaningful error message in the body of 403s like "token lacks the scopes necessary to perform this action"
    const data = Buffer.from(await collect(res.body));
    const response = data.toString('utf8');
    const preview =
      response.length < 256 ? response : response.slice(0, 256) + '...';
    return { preview, response, data }
  } catch (e) {
    return {}
  }
};

class GitRemoteHTTP {
  /**
   * Returns the capabilities of the GitRemoteHTTP class.
   *
   * @returns {Promise<string[]>} - An array of supported capabilities.
   */
  static async capabilities() {
    return ['discover', 'connect']
  }

  /**
   * Discovers references from a remote Git repository.
   *
   * @param {Object} args
   * @param {HttpClient} args.http - The HTTP client to use for requests.
   * @param {ProgressCallback} [args.onProgress] - Callback for progress updates.
   * @param {AuthCallback} [args.onAuth] - Callback for providing authentication credentials.
   * @param {AuthFailureCallback} [args.onAuthFailure] - Callback for handling authentication failures.
   * @param {AuthSuccessCallback} [args.onAuthSuccess] - Callback for handling successful authentication.
   * @param {string} [args.corsProxy] - Optional CORS proxy URL.
   * @param {string} args.service - The Git service (e.g., "git-upload-pack").
   * @param {string} args.url - The URL of the remote repository.
   * @param {Object<string, string>} args.headers - HTTP headers to include in the request.
   * @param {AbortSignal} [args.signal] - Signal to abort the operation.
   * @param {1 | 2} args.protocolVersion - The Git protocol version to use.
   * @returns {Promise<Object>} - The parsed response from the remote repository.
   * @throws {HttpError} - If the HTTP request fails.
   * @throws {SmartHttpError} - If the response cannot be parsed.
   * @throws {UserCanceledError} - If the user cancels the operation.
   */
  static async discover({
    http,
    onProgress,
    onAuth,
    onAuthSuccess,
    onAuthFailure,
    corsProxy,
    service,
    url: _origUrl,
    headers,
    signal,
    protocolVersion,
  }) {
    let { url, auth } = extractAuthFromUrl(_origUrl);
    const proxifiedURL = corsProxy ? corsProxify(corsProxy, url) : url;
    if (auth.username || auth.password) {
      headers.Authorization = calculateBasicAuthHeader(auth);
    }
    if (protocolVersion === 2) {
      headers['Git-Protocol'] = 'version=2';
    }

    let res;
    let tryAgain;
    let providedAuthBefore = false;
    do {
      res = await http.request({
        onProgress,
        method: 'GET',
        url: `${proxifiedURL}/info/refs?service=${service}`,
        headers,
        signal,
      });

      // the default loop behavior
      tryAgain = false;

      // 401 is the "correct" response for access denied. 203 is Non-Authoritative Information and comes from Azure DevOps, which
      // apparently doesn't realize this is a git request and is returning the HTML for the "Azure DevOps Services | Sign In" page.
      if (res.statusCode === 401 || res.statusCode === 203) {
        // On subsequent 401s, call `onAuthFailure` instead of `onAuth`.
        // This is so that naive `onAuth` callbacks that return a fixed value don't create an infinite loop of retrying.
        const getAuth = providedAuthBefore ? onAuthFailure : onAuth;
        if (getAuth) {
          // Acquire credentials and try again
          // TODO: read `useHttpPath` value from git config and pass along?
          auth = await getAuth(url, {
            ...auth,
            headers: { ...headers },
          });
          if (auth && auth.cancel) {
            throw new UserCanceledError()
          } else if (auth) {
            updateHeaders(headers, auth);
            providedAuthBefore = true;
            tryAgain = true;
          }
        }
      } else if (
        res.statusCode === 200 &&
        providedAuthBefore &&
        onAuthSuccess
      ) {
        await onAuthSuccess(url, auth);
      }
    } while (tryAgain)

    if (res.statusCode !== 200) {
      const { response } = await stringifyBody(res);
      throw new HttpError(res.statusCode, res.statusMessage, response)
    }
    // Git "smart" HTTP servers should respond with the correct Content-Type header.
    if (
      res.headers['content-type'] === `application/x-${service}-advertisement`
    ) {
      const remoteHTTP = await parseRefsAdResponse(res.body, { service });
      remoteHTTP.auth = auth;
      return remoteHTTP
    } else {
      // If they don't send the correct content-type header, that's a good indicator it is either a "dumb" HTTP
      // server, or the user specified an incorrect remote URL and the response is actually an HTML page.
      // In this case, we save the response as plain text so we can generate a better error message if needed.
      const { preview, response, data } = await stringifyBody(res);
      // For backwards compatibility, try to parse it anyway.
      // TODO: maybe just throw instead of trying?
      try {
        const remoteHTTP = await parseRefsAdResponse([data], { service });
        remoteHTTP.auth = auth;
        return remoteHTTP
      } catch (e) {
        throw new SmartHttpError(preview, response)
      }
    }
  }

  /**
   * Connects to a remote Git repository and sends a request.
   *
   * @param {Object} args
   * @param {HttpClient} args.http - The HTTP client to use for requests.
   * @param {ProgressCallback} [args.onProgress] - Callback for progress updates.
   * @param {string} [args.corsProxy] - Optional CORS proxy URL.
   * @param {string} args.service - The Git service (e.g., "git-upload-pack").
   * @param {string} args.url - The URL of the remote repository.
   * @param {Object<string, string>} [args.headers] - HTTP headers to include in the request.
   * @param {any} args.body - The request body to send.
   * @param {any} args.auth - Authentication credentials.
   * @param {AbortSignal} [args.signal] - Signal to abort the operation.
   * @returns {Promise<GitHttpResponse>} - The HTTP response from the remote repository.
   * @throws {HttpError} - If the HTTP request fails.
   */
  static async connect({
    http,
    onProgress,
    corsProxy,
    service,
    url,
    auth,
    body,
    headers,
    signal,
  }) {
    // We already have the "correct" auth value at this point, but
    // we need to strip out the username/password from the URL yet again.
    const urlAuth = extractAuthFromUrl(url);
    if (urlAuth) url = urlAuth.url;

    if (corsProxy) url = corsProxify(corsProxy, url);

    headers['content-type'] = `application/x-${service}-request`;
    headers.accept = `application/x-${service}-result`;
    updateHeaders(headers, auth);

    const res = await http.request({
      onProgress,
      method: 'POST',
      url: `${url}/${service}`,
      body,
      headers,
      signal,
    });
    if (res.statusCode !== 200) {
      const { response } = stringifyBody(res);
      throw new HttpError(res.statusCode, res.statusMessage, response)
    }
    return res
  }
}

/**
 * A class for managing Git remotes and determining the appropriate remote helper for a given URL.
 */
class GitRemoteManager {
  /**
   * Determines the appropriate remote helper for the given URL.
   *
   * @param {Object} args
   * @param {string} args.url - The URL of the remote repository.
   * @returns {Object} - The remote helper class for the specified transport.
   * @throws {UrlParseError} - If the URL cannot be parsed.
   * @throws {UnknownTransportError} - If the transport is not supported.
   */
  static getRemoteHelperFor({ url }) {
    // TODO: clean up the remoteHelper API and move into PluginCore
    const remoteHelpers = new Map();
    remoteHelpers.set('http', GitRemoteHTTP);
    remoteHelpers.set('https', GitRemoteHTTP);

    const parts = parseRemoteUrl({ url });
    if (!parts) {
      throw new UrlParseError(url)
    }
    if (remoteHelpers.has(parts.transport)) {
      return remoteHelpers.get(parts.transport)
    }
    throw new UnknownTransportError(
      url,
      parts.transport,
      parts.transport === 'ssh' ? translateSSHtoHTTP(url) : undefined
    )
  }
}

/**
 * Parses a remote URL and extracts its transport and address.
 *
 * @param {Object} args
 * @param {string} args.url - The URL of the remote repository.
 * @returns {Object|undefined} - An object containing the transport and address, or undefined if parsing fails.
 */
// git-clone(1) calls this the "shorter scp-like syntax": [user@]host:path. The
// user is part of the syntax, not part of the word `git`, and a self-hosted
// forge is as likely to hand out `gitolite@`, `forgejo@` or `ubuntu@`. The host
// and the user cannot hold a slash, an at sign or a colon, so `https://x` and a
// `scheme:address` override are left to the expression below.
const scpLike = /^[^/@:]+@[^/@:]+:/;

function parseRemoteUrl({ url }) {
  if (scpLike.test(url)) {
    return {
      transport: 'ssh',
      address: url,
    }
  }
  const matches = url.match(/(\w+)(:\/\/|::)(.*)/);
  if (matches === null) return
  /*
   * When git encounters a URL of the form <transport>://<address>, where <transport> is
   * a protocol that it cannot handle natively, it automatically invokes git remote-<transport>
   * with the full URL as the second argument.
   *
   * @see https://git-scm.com/docs/git-remote-helpers
   */
  if (matches[2] === '://') {
    return {
      transport: matches[1],
      address: matches[0],
    }
  }
  /*
   * A URL of the form <transport>::<address> explicitly instructs git to invoke
   * git remote-<transport> with <address> as the second argument.
   *
   * @see https://git-scm.com/docs/git-remote-helpers
   */
  if (matches[2] === '::') {
    return {
      transport: matches[1],
      address: matches[3],
    }
  }
}

class GitShallowManager {
  /**
   * Reads the `shallow` file in the Git repository and returns a set of object IDs (OIDs).
   *
   * @param {Object} args
   * @param {FSClient} args.fs - A file system implementation.
   * @param {string} [args.gitdir] - [required] The [git directory](dir-vs-gitdir.md) path
   * @returns {Promise<Set<string>>} - A set of shallow object IDs.
   */
  static async read({ fs, gitdir }) {
    const filepath = join(gitdir, 'shallow');
    const oids = new Set();
    await acquireLock(filepath, async function () {
      const text = await fs.read(filepath, { encoding: 'utf8' });
      if (text === null) return oids // no file
      if (text.trim() === '') return oids // empty file
      text
        .trim()
        .split('\n')
        .map(oid => oids.add(oid));
    });
    return oids
  }

  /**
   * Writes a set of object IDs (OIDs) to the `shallow` file in the Git repository.
   * If the set is empty, the `shallow` file is removed.
   *
   * @param {Object} args
   * @param {FSClient} args.fs - A file system implementation.
   * @param {string} [args.gitdir] - [required] The [git directory](dir-vs-gitdir.md) path
   * @param {Set<string>} args.oids - A set of shallow object IDs to write.
   * @returns {Promise<void>}
   */
  static async write({ fs, gitdir, oids }) {
    const filepath = join(gitdir, 'shallow');
    if (oids.size > 0) {
      const text = [...oids].join('\n') + '\n';
      await acquireLock(filepath, async function () {
        await fs.write(filepath, text, {
          encoding: 'utf8',
        });
      });
    } else {
      // No shallows
      await acquireLock(filepath, async function () {
        await fs.rm(filepath);
      });
    }
  }
}

async function hasObjectLoose({ fs, gitdir, oid }) {
  const source = `objects/${oid.slice(0, 2)}/${oid.slice(2)}`;
  return fs.exists(`${gitdir}/${source}`)
}

async function hasObjectPacked({
  fs,
  cache,
  gitdir,
  oid,
  getExternalRefDelta,
}) {
  // Check to see if it's in a packfile.
  // Iterate through all the .idx files
  let list = await fs.readdir(join(gitdir, 'objects/pack'));
  list = list.filter(x => x.endsWith('.idx'));
  for (const filename of list) {
    const indexFile = `${gitdir}/objects/pack/${filename}`;
    const p = await readPackIndex({
      fs,
      cache,
      filename: indexFile,
      getExternalRefDelta,
    });
    if (p.error) throw new InternalError(p.error)
    // If the packfile DOES have the oid we're looking for...
    if (p.offsets.has(oid)) {
      return true
    }
  }
  // Failed to find it
  return false
}

async function hasObject({
  fs,
  cache,
  gitdir,
  oid,
  format = 'content',
}) {
  // Curry the current read method so that the packfile un-deltification
  // process can acquire external ref-deltas.
  const getExternalRefDelta = oid => _readObject({ fs, cache, gitdir, oid });

  // Look for it in the loose object directory.
  let result = await hasObjectLoose({ fs, gitdir, oid });
  // Check to see if it's in a packfile.
  if (!result) {
    result = await hasObjectPacked({
      fs,
      cache,
      gitdir,
      oid,
      getExternalRefDelta,
    });
  }
  // Finally
  return result
}

function addCredentialUsername({ config, onAuth }) {
  if (!onAuth) return onAuth

  return async (url, auth) => {
    const username =
      auth.username || (await config.get(`credential.${url}.username`));
    return onAuth(url, username ? { ...auth, username } : auth)
  }
}

// TODO: make a function that just returns obCount. then emptyPackfile = () => sizePack(pack) === 0
function emptyPackfile(pack) {
  const pheader = '5041434b';
  const version = '00000002';
  const obCount = '00000000';
  const header = pheader + version + obCount;
  return pack.slice(0, 12).toString('hex') === header
}

function filterCapabilities(server, client) {
  const serverNames = server.map(cap => cap.split('=', 1)[0]);
  return client.filter(cap => {
    const name = cap.split('=', 1)[0];
    return serverNames.includes(name)
  })
}

const pkg = {
  name: 'isomorphic-git',
  version: '1.42.2',
  agent: 'git/isomorphic-git@1.42.2',
};

class FIFO {
  constructor() {
    this._queue = [];
  }

  write(chunk) {
    if (this._ended) {
      throw Error('You cannot write to a FIFO that has already been ended!')
    }
    if (this._waiting) {
      const resolve = this._waiting;
      this._waiting = null;
      resolve({ value: chunk });
    } else {
      this._queue.push(chunk);
    }
  }

  end() {
    this._ended = true;
    if (this._waiting) {
      const resolve = this._waiting;
      this._waiting = null;
      resolve({ done: true });
    }
  }

  destroy(err) {
    this.error = err;
    this.end();
  }

  async next() {
    if (this._queue.length > 0) {
      return { value: this._queue.shift() }
    }
    if (this._ended) {
      return { done: true }
    }
    if (this._waiting) {
      throw Error(
        'You cannot call read until the previous call to read has returned!'
      )
    }
    return new Promise(resolve => {
      this._waiting = resolve;
    })
  }
}

// Note: progress messages are designed to be written directly to the terminal,
// so they are often sent with just a carriage return to overwrite the last line of output.
// But there are also messages delimited with newlines.
// I also include CRLF just in case.
function findSplit(str) {
  const r = str.indexOf('\r');
  const n = str.indexOf('\n');
  if (r === -1 && n === -1) return -1
  if (r === -1) return n + 1 // \n
  if (n === -1) return r + 1 // \r
  if (n === r + 1) return n + 1 // \r\n
  return Math.min(r, n) + 1 // \r or \n
}

function splitLines(input) {
  const output = new FIFO();
  let tmp = ''
  ;(async () => {
    await forAwait(input, chunk => {
      chunk = chunk.toString('utf8');
      tmp += chunk;
      while (true) {
        const i = findSplit(tmp);
        if (i === -1) break
        // A '\r' at the very end may be the first half of a '\r\n' whose '\n'
        // arrives in the next chunk. Hold it back until there is a character
        // after it to look at, otherwise the same bytes split into two lines
        // or one depending only on where the socket boundary fell.
        if (i === tmp.length && tmp[i - 1] === '\r') break
        output.write(tmp.slice(0, i));
        tmp = tmp.slice(i);
      }
    });
    if (tmp.length > 0) {
      output.write(tmp);
    }
    output.end();
  })();
  return output
}

/*
If 'side-band' or 'side-band-64k' capabilities have been specified by
the client, the server will send the packfile data multiplexed.

Each packet starting with the packet-line length of the amount of data
that follows, followed by a single byte specifying the sideband the
following data is coming in on.

In 'side-band' mode, it will send up to 999 data bytes plus 1 control
code, for a total of up to 1000 bytes in a pkt-line.  In 'side-band-64k'
mode it will send up to 65519 data bytes plus 1 control code, for a
total of up to 65520 bytes in a pkt-line.

The sideband byte will be a '1', '2' or a '3'. Sideband '1' will contain
packfile data, sideband '2' will be used for progress information that the
client will generally print to stderr and sideband '3' is used for error
information.

If no 'side-band' capability was specified, the server will stream the
entire packfile without multiplexing.
*/

class GitSideBand {
  static demux(input) {
    const read = GitPktLine.streamReader(input);
    // And now for the ridiculous side-band or side-band-64k protocol
    const packetlines = new FIFO();
    const packfile = new FIFO();
    const progress = new FIFO();
    // TODO: Use a proper through stream?
    const nextBit = async function () {
      const line = await read();
      // Skip over flush packets
      if (line === null) return nextBit()
      // A made up convention to signal there's no more to read.
      if (line === true) {
        packetlines.end();
        progress.end();
        input.error ? packfile.destroy(input.error) : packfile.end();
        return
      }
      // Examine first byte to determine which output "stream" to use
      switch (line[0]) {
        case 1: {
          // pack data
          packfile.write(line.slice(1));
          break
        }
        case 2: {
          // progress message
          progress.write(line.slice(1));
          break
        }
        case 3: {
          // fatal error message just before stream aborts
          const error = line.slice(1);
          progress.write(error);
          packetlines.end();
          progress.end();
          packfile.destroy(new Error(error.toString('utf8')));
          return
        }
        default: {
          // Not part of the side-band-64k protocol
          packetlines.write(line);
        }
      }
      // Careful not to blow up the stack.
      // I think Promises in a tail-call position should be OK.
      nextBit();
    };
    nextBit();
    return {
      packetlines,
      packfile,
      progress,
    }
  }
  // static mux ({
  //   protocol, // 'side-band' or 'side-band-64k'
  //   packetlines,
  //   packfile,
  //   progress,
  //   error
  // }) {
  //   const MAX_PACKET_LENGTH = protocol === 'side-band-64k' ? 999 : 65519
  //   let output = new PassThrough()
  //   packetlines.on('data', data => {
  //     if (data === null) {
  //       output.write(GitPktLine.flush())
  //     } else {
  //       output.write(GitPktLine.encode(data))
  //     }
  //   })
  //   let packfileWasEmpty = true
  //   let packfileEnded = false
  //   let progressEnded = false
  //   let errorEnded = false
  //   let goodbye = Buffer.concat([
  //     GitPktLine.encode(Buffer.from('010A', 'hex')),
  //     GitPktLine.flush()
  //   ])
  //   packfile
  //     .on('data', data => {
  //       packfileWasEmpty = false
  //       const buffers = splitBuffer(data, MAX_PACKET_LENGTH)
  //       for (const buffer of buffers) {
  //         output.write(
  //           GitPktLine.encode(Buffer.concat([Buffer.from('01', 'hex'), buffer]))
  //         )
  //       }
  //     })
  //     .on('end', () => {
  //       packfileEnded = true
  //       if (!packfileWasEmpty) output.write(goodbye)
  //       if (progressEnded && errorEnded) output.end()
  //     })
  //   progress
  //     .on('data', data => {
  //       const buffers = splitBuffer(data, MAX_PACKET_LENGTH)
  //       for (const buffer of buffers) {
  //         output.write(
  //           GitPktLine.encode(Buffer.concat([Buffer.from('02', 'hex'), buffer]))
  //         )
  //       }
  //     })
  //     .on('end', () => {
  //       progressEnded = true
  //       if (packfileEnded && errorEnded) output.end()
  //     })
  //   error
  //     .on('data', data => {
  //       const buffers = splitBuffer(data, MAX_PACKET_LENGTH)
  //       for (const buffer of buffers) {
  //         output.write(
  //           GitPktLine.encode(Buffer.concat([Buffer.from('03', 'hex'), buffer]))
  //         )
  //       }
  //     })
  //     .on('end', () => {
  //       errorEnded = true
  //       if (progressEnded && packfileEnded) output.end()
  //     })
  //   return output
  // }
}

async function parseUploadPackResponse(stream) {
  const { packetlines, packfile, progress } = GitSideBand.demux(stream);
  const shallows = [];
  const unshallows = [];
  const acks = [];
  let nak = false;
  let done = false;
  return new Promise((resolve, reject) => {
    // Parse the response
    forAwait(packetlines, data => {
      const line = data.toString('utf8').trim();
      if (line.startsWith('shallow')) {
        const oid = line.slice(-41).trim();
        if (oid.length !== 40) {
          reject(new InvalidOidError(oid));
        }
        shallows.push(oid);
      } else if (line.startsWith('unshallow')) {
        const oid = line.slice(-41).trim();
        if (oid.length !== 40) {
          reject(new InvalidOidError(oid));
        }
        unshallows.push(oid);
      } else if (line.startsWith('ACK')) {
        const [, oid, status] = line.split(' ');
        acks.push({ oid, status });
        if (!status) done = true;
      } else if (line.startsWith('NAK')) {
        nak = true;
        done = true;
      } else {
        done = true;
        nak = true;
      }
      if (done) {
        stream.error
          ? reject(stream.error)
          : resolve({ shallows, unshallows, acks, nak, packfile, progress });
      }
    }).finally(() => {
      if (!done) {
        stream.error
          ? reject(stream.error)
          : resolve({ shallows, unshallows, acks, nak, packfile, progress });
      }
    });
  })
}

function writeUploadPackRequest({
  capabilities = [],
  wants = [],
  haves = [],
  shallows = [],
  depth = null,
  since = null,
  exclude = [],
}) {
  const packstream = [];
  wants = [...new Set(wants)]; // remove duplicates
  let firstLineCapabilities = ` ${capabilities.join(' ')}`;
  for (const oid of wants) {
    packstream.push(GitPktLine.encode(`want ${oid}${firstLineCapabilities}\n`));
    firstLineCapabilities = '';
  }
  for (const oid of shallows) {
    packstream.push(GitPktLine.encode(`shallow ${oid}\n`));
  }
  if (depth !== null) {
    packstream.push(GitPktLine.encode(`deepen ${depth}\n`));
  }
  if (since !== null) {
    packstream.push(
      GitPktLine.encode(`deepen-since ${Math.floor(since.valueOf() / 1000)}\n`)
    );
  }
  for (const oid of exclude) {
    packstream.push(GitPktLine.encode(`deepen-not ${oid}\n`));
  }
  packstream.push(GitPktLine.flush());
  for (const oid of haves) {
    packstream.push(GitPktLine.encode(`have ${oid}\n`));
  }
  packstream.push(GitPktLine.encode(`done\n`));
  return packstream
}

// @ts-check

/**
 *
 * @typedef {object} FetchResult - The object returned has the following schema:
 * @property {string | null} defaultBranch - The branch that is cloned if no branch is specified
 * @property {string | null} fetchHead - The SHA-1 object id of the fetched head commit
 * @property {string | null} fetchHeadDescription - a textual description of the branch that was fetched
 * @property {Object<string, string>} [headers] - The HTTP response headers returned by the git server
 * @property {string[]} [pruned] - A list of branches that were pruned, if you provided the `prune` parameter
 *
 */

/**
 * @param {object} args
 * @param {import('../models/FileSystem.js').FileSystem} args.fs
 * @param {any} args.cache
 * @param {HttpClient} args.http
 * @param {ProgressCallback} [args.onProgress]
 * @param {MessageCallback} [args.onMessage]
 * @param {AuthCallback} [args.onAuth]
 * @param {AuthFailureCallback} [args.onAuthFailure]
 * @param {AuthSuccessCallback} [args.onAuthSuccess]
 * @param {string} args.gitdir
 * @param {string|void} [args.url]
 * @param {string} [args.corsProxy]
 * @param {string} [args.ref]
 * @param {string} [args.remoteRef]
 * @param {string} [args.remote]
 * @param {boolean} [args.singleBranch = false]
 * @param {boolean} [args.tags = false]
 * @param {number} [args.depth]
 * @param {Date} [args.since]
 * @param {string[]} [args.exclude = []]
 * @param {boolean} [args.relative = false]
 * @param {Object<string, string>} [args.headers]
 * @param {boolean} [args.prune]
 * @param {boolean} [args.pruneTags]
 *
 * @returns {Promise<FetchResult>}
 * @see FetchResult
 */
async function _fetch({
  fs,
  cache,
  http,
  onProgress,
  onMessage,
  onAuth,
  onAuthSuccess,
  onAuthFailure,
  gitdir,
  ref: _ref,
  remoteRef: _remoteRef,
  remote: _remote,
  url: _url,
  corsProxy,
  depth = null,
  since = null,
  exclude = [],
  relative = false,
  tags = false,
  singleBranch = false,
  headers = {},
  prune = false,
  pruneTags = false,
}) {
  const ref = _ref || (await _currentBranch({ fs, gitdir, test: true }));
  const config = await GitConfigManager.get({ fs, gitdir });
  // Figure out what remote to use.
  const remote =
    _remote || (ref && (await config.get(`branch.${ref}.remote`))) || 'origin';
  // Lookup the URL for the given remote.
  const url = _url || (await config.get(`remote.${remote}.url`));
  if (typeof url === 'undefined') {
    throw new MissingParameterError('remote OR url')
  }
  // Figure out what remote ref to use.
  const remoteRef =
    _remoteRef ||
    (ref && (await config.get(`branch.${ref}.merge`))) ||
    _ref ||
    'HEAD';

  if (corsProxy === undefined) {
    corsProxy = await config.get('http.corsProxy');
  }

  const GitRemoteHTTP = GitRemoteManager.getRemoteHelperFor({ url });
  const remoteHTTP = await GitRemoteHTTP.discover({
    http,
    onAuth: addCredentialUsername({ config, onAuth }),
    onAuthSuccess,
    onAuthFailure: addCredentialUsername({ config, onAuth: onAuthFailure }),
    corsProxy,
    service: 'git-upload-pack',
    url,
    headers,
    protocolVersion: 1,
  });
  const auth = remoteHTTP.auth; // hack to get new credentials from CredentialManager API
  const remoteRefs = remoteHTTP.refs;
  // For the special case of an empty repository with no refs, return null.
  if (remoteRefs.size === 0) {
    return {
      defaultBranch: null,
      fetchHead: null,
      fetchHeadDescription: null,
    }
  }
  // Check that the remote supports the requested features
  if (depth !== null && !remoteHTTP.capabilities.has('shallow')) {
    throw new RemoteCapabilityError('shallow', 'depth')
  }
  if (since !== null && !remoteHTTP.capabilities.has('deepen-since')) {
    throw new RemoteCapabilityError('deepen-since', 'since')
  }
  if (exclude.length > 0 && !remoteHTTP.capabilities.has('deepen-not')) {
    throw new RemoteCapabilityError('deepen-not', 'exclude')
  }
  if (relative === true && !remoteHTTP.capabilities.has('deepen-relative')) {
    throw new RemoteCapabilityError('deepen-relative', 'relative')
  }
  // Figure out the SHA for the requested ref
  const { oid, fullref } = GitRefManager.resolveAgainstMap({
    ref: remoteRef,
    map: remoteRefs,
  });
  // Filter out refs we want to ignore: only keep ref we're cloning, HEAD, branches, and tags (if we're keeping them)
  for (const remoteRef of remoteRefs.keys()) {
    if (
      remoteRef === fullref ||
      remoteRef === 'HEAD' ||
      remoteRef.startsWith('refs/heads/') ||
      (tags && remoteRef.startsWith('refs/tags/'))
    ) {
      continue
    }
    remoteRefs.delete(remoteRef);
  }
  // Assemble the application/x-git-upload-pack-request
  const capabilities = filterCapabilities(
    [...remoteHTTP.capabilities],
    [
      'multi_ack_detailed',
      'no-done',
      'side-band-64k',
      // Note: I removed 'thin-pack' option since our code doesn't "fatten" packfiles,
      // which is necessary for compatibility with git. It was the cause of mysterious
      // 'fatal: pack has [x] unresolved deltas' errors that plagued us for some time.
      // isomorphic-git is perfectly happy with thin packfiles in .git/objects/pack but
      // canonical git it turns out is NOT.
      'ofs-delta',
      `agent=${pkg.agent}`,
    ]
  );
  if (relative) capabilities.push('deepen-relative');
  // Start figuring out which oids from the remote we want to request
  const wants = singleBranch ? [oid] : remoteRefs.values();
  // Come up with a reasonable list of oids to tell the remote we already have
  // (preferably oids that are close ancestors of the branch heads we're fetching)
  const haveRefs = singleBranch
    ? [ref]
    : await GitRefManager.listRefs({
        fs,
        gitdir,
        filepath: `refs`,
      });
  let haves = [];
  for (let ref of haveRefs) {
    try {
      ref = await GitRefManager.expand({ fs, gitdir, ref });
      const oid = await GitRefManager.resolve({ fs, gitdir, ref });
      if (await hasObject({ fs, cache, gitdir, oid })) {
        haves.push(oid);
      }
    } catch (err) {}
  }
  haves = [...new Set(haves)];
  const oids = await GitShallowManager.read({ fs, gitdir });
  const shallows = remoteHTTP.capabilities.has('shallow') ? [...oids] : [];
  const packstream = writeUploadPackRequest({
    capabilities,
    wants,
    haves,
    shallows,
    depth,
    since,
    exclude,
  });
  // CodeCommit will hang up if we don't send a Content-Length header
  // so we can't stream the body.
  const packbuffer = Buffer.from(await collect(packstream));
  const raw = await GitRemoteHTTP.connect({
    http,
    onProgress,
    corsProxy,
    service: 'git-upload-pack',
    url,
    auth,
    body: [packbuffer],
    headers,
  });
  const response = await parseUploadPackResponse(raw.body);
  if (raw.headers) {
    response.headers = raw.headers;
  }
  // Apply all the 'shallow' and 'unshallow' commands
  for (const oid of response.shallows) {
    if (!oids.has(oid)) {
      // this is in a try/catch mostly because my old test fixtures are missing objects
      try {
        // server says it's shallow, but do we have the parents?
        const { object } = await _readObject({ fs, cache, gitdir, oid });
        const commit = new GitCommit(object);
        const hasParents = await Promise.all(
          commit
            .headers()
            .parent.map(oid => hasObject({ fs, cache, gitdir, oid }))
        );
        const haveAllParents =
          hasParents.length === 0 || hasParents.every(has => has);
        if (!haveAllParents) {
          oids.add(oid);
        }
      } catch (err) {
        oids.add(oid);
      }
    }
  }
  for (const oid of response.unshallows) {
    oids.delete(oid);
  }
  await GitShallowManager.write({ fs, gitdir, oids });
  // Update local remote refs
  if (singleBranch) {
    const refs = new Map([[fullref, oid]]);
    // But wait, maybe it was a symref, like 'HEAD'!
    // We need to save all the refs in the symref chain (sigh).
    const symrefs = new Map();
    let bail = 10;
    let key = fullref;
    while (bail--) {
      const value = remoteHTTP.symrefs.get(key);
      if (value === undefined) break
      symrefs.set(key, value);
      key = value;
    }
    // final value must not be a symref but a real ref
    const realRef = remoteRefs.get(key);
    // There may be no ref at all if we've fetched a specific commit hash
    if (realRef) {
      refs.set(key, realRef);
    }
    const { pruned } = await GitRefManager.updateRemoteRefs({
      fs,
      gitdir,
      remote,
      refs,
      symrefs,
      tags,
      prune,
    });
    if (prune) {
      response.pruned = pruned;
    }
  } else {
    const { pruned } = await GitRefManager.updateRemoteRefs({
      fs,
      gitdir,
      remote,
      refs: remoteRefs,
      symrefs: remoteHTTP.symrefs,
      tags,
      prune,
      pruneTags,
    });
    if (prune) {
      response.pruned = pruned;
    }
  }
  // We need this value later for the `clone` command.
  response.HEAD = remoteHTTP.symrefs.get('HEAD');
  // AWS CodeCommit doesn't list HEAD as a symref, but we can reverse engineer it
  // Find the SHA of the branch called HEAD
  if (response.HEAD === undefined) {
    const { oid } = GitRefManager.resolveAgainstMap({
      ref: 'HEAD',
      map: remoteRefs,
    });
    // Use the name of the first branch that's not called HEAD that has
    // the same SHA as the branch called HEAD.
    for (const [key, value] of remoteRefs.entries()) {
      if (key !== 'HEAD' && value === oid) {
        response.HEAD = key;
        break
      }
    }
  }
  const noun = fullref.startsWith('refs/tags') ? 'tag' : 'branch';
  response.FETCH_HEAD = {
    oid,
    description: `${noun} '${abbreviateRef(fullref)}' of ${url}`,
  };

  if (onProgress || onMessage) {
    const lines = splitLines(response.progress);
    forAwait(lines, async line => {
      if (onMessage) await onMessage(line);
      if (onProgress) {
        const matches = line.match(/([^:]*).*\((\d+?)\/(\d+?)\)/);
        if (matches) {
          await onProgress({
            phase: matches[1].trim(),
            loaded: parseInt(matches[2], 10),
            total: parseInt(matches[3], 10),
          });
        }
      }
    });
  }
  const packfile = Buffer.from(await collect(response.packfile));
  if (raw.body.error) throw raw.body.error
  const packfileSha = packfile.slice(-20).toString('hex');
  const res = {
    defaultBranch: response.HEAD,
    fetchHead: response.FETCH_HEAD.oid,
    fetchHeadDescription: response.FETCH_HEAD.description,
  };
  if (response.headers) {
    res.headers = response.headers;
  }
  if (prune) {
    res.pruned = response.pruned;
  }
  // This is a quick fix for the empty .git/objects/pack/pack-.pack file error,
  // which due to the way `git-list-pack` works causes the program to hang when it tries to read it.
  // TODO: Longer term, we should actually:
  // a) NOT concatenate the entire packfile into memory (line 78),
  // b) compute the SHA of the stream except for the last 20 bytes, using the same library used in push.js, and
  // c) compare the computed SHA with the last 20 bytes of the stream before saving to disk, and throwing a "packfile got corrupted during download" error if the SHA doesn't match.
  if (packfileSha !== '' && !emptyPackfile(packfile)) {
    res.packfile = `objects/pack/pack-${packfileSha}.pack`;
    const fullpath = join(gitdir, res.packfile);
    await fs.write(fullpath, packfile);
    const getExternalRefDelta = oid => _readObject({ fs, cache, gitdir, oid });
    const idx = await GitPackIndex.fromPack({
      pack: packfile,
      getExternalRefDelta,
      onProgress,
    });
    await fs.write(fullpath.replace(/\.pack$/, '.idx'), await idx.toBuffer());
  }
  return res
}

// @ts-check

/**
 * Initialize a new repository
 *
 * @param {object} args
 * @param {import('../models/FileSystem.js').FileSystem} args.fs
 * @param {string} [args.dir]
 * @param {string} [args.gitdir]
 * @param {boolean} [args.bare = false]
 * @param {string} [args.defaultBranch = 'master']
 * @returns {Promise<void>}
 */
async function _init({
  fs,
  bare = false,
  dir,
  gitdir = bare ? dir : join(dir, '.git'),
  defaultBranch = 'master',
}) {
  // Don't overwrite an existing config
  if (await fs.exists(gitdir + '/config')) return

  let folders = [
    'hooks',
    'info',
    'objects/info',
    'objects/pack',
    'refs/heads',
    'refs/tags',
  ];
  folders = folders.map(dir => gitdir + '/' + dir);
  for (const folder of folders) {
    await fs.mkdir(folder);
  }

  await fs.write(
    gitdir + '/config',
    '[core]\n' +
      '\trepositoryformatversion = 0\n' +
      '\tfilemode = false\n' +
      `\tbare = ${bare}\n` +
      (bare ? '' : '\tlogallrefupdates = true\n') +
      '\tsymlinks = false\n' +
      '\tignorecase = true\n'
  );
  await fs.write(gitdir + '/HEAD', `ref: refs/heads/${defaultBranch}\n`);
}

// @ts-check

/**
 * @param {object} args
 * @param {import('../models/FileSystem.js').FileSystem} args.fs
 * @param {object} args.cache
 * @param {HttpClient} args.http
 * @param {ProgressCallback} [args.onProgress]
 * @param {MessageCallback} [args.onMessage]
 * @param {AuthCallback} [args.onAuth]
 * @param {AuthFailureCallback} [args.onAuthFailure]
 * @param {AuthSuccessCallback} [args.onAuthSuccess]
 * @param {PostCheckoutCallback} [args.onPostCheckout]
 * @param {string} [args.dir]
 * @param {string} args.gitdir
 * @param {string} args.url
 * @param {string} args.corsProxy
 * @param {string} args.ref
 * @param {boolean} args.singleBranch
 * @param {boolean} args.noCheckout
 * @param {boolean} args.noTags
 * @param {string} args.remote
 * @param {number} args.depth
 * @param {Date} args.since
 * @param {string[]} args.exclude
 * @param {boolean} args.relative
 * @param {Object<string, string>} args.headers
 * @param {boolean} [args.nonBlocking]
 * @param {number} [args.batchSize]
 *
 * @returns {Promise<void>} Resolves successfully when clone completes
 *
 */
async function _clone({
  fs,
  cache,
  http,
  onProgress,
  onMessage,
  onAuth,
  onAuthSuccess,
  onAuthFailure,
  onPostCheckout,
  dir,
  gitdir,
  url,
  corsProxy,
  ref,
  remote,
  depth,
  since,
  exclude,
  relative,
  singleBranch,
  noCheckout,
  noTags,
  headers,
  nonBlocking,
  batchSize = 100,
}) {
  try {
    await _init({ fs, gitdir });
    await _addRemote({ fs, gitdir, remote, url, force: false });
    if (corsProxy) {
      const config = await GitConfigManager.get({ fs, gitdir });
      await config.set(`http.corsProxy`, corsProxy);
      await GitConfigManager.save({ fs, gitdir, config });
    }
    const { defaultBranch, fetchHead } = await _fetch({
      fs,
      cache,
      http,
      onProgress,
      onMessage,
      onAuth,
      onAuthSuccess,
      onAuthFailure,
      gitdir,
      ref,
      remote,
      corsProxy,
      depth,
      since,
      exclude,
      relative,
      singleBranch,
      headers,
      tags: !noTags,
    });
    if (fetchHead === null) return
    ref = ref || defaultBranch;
    ref = ref.replace('refs/heads/', '');
    // Checkout that branch
    await _checkout({
      fs,
      cache,
      onProgress,
      onPostCheckout,
      dir,
      gitdir,
      ref,
      remote,
      noCheckout,
      nonBlocking,
      batchSize,
    });
  } catch (err) {
    // Remove partial local repository, see #1283
    // Ignore any error as we are already failing.
    // The catch is necessary so the original error is not masked.
    await fs
      .rmdir(gitdir, { recursive: true, maxRetries: 10 })
      .catch(() => undefined);
    throw err
  }
}

// @ts-check

/**
 * Clone a repository
 *
 * @param {object} args
 * @param {FsClient} args.fs - a file system implementation
 * @param {HttpClient} args.http - an HTTP client
 * @param {ProgressCallback} [args.onProgress] - optional progress event callback
 * @param {MessageCallback} [args.onMessage] - optional message event callback
 * @param {AuthCallback} [args.onAuth] - optional auth fill callback
 * @param {AuthFailureCallback} [args.onAuthFailure] - optional auth rejected callback
 * @param {AuthSuccessCallback} [args.onAuthSuccess] - optional auth approved callback
 * @param {PostCheckoutCallback} [args.onPostCheckout] - optional post-checkout hook callback
 * @param {string} args.dir - The [working tree](dir-vs-gitdir.md) directory path
 * @param {string} [args.gitdir=join(dir,'.git')] - [required] The [git directory](dir-vs-gitdir.md) path
 * @param {string} args.url - The URL of the remote repository
 * @param {string} [args.corsProxy] - Optional [CORS proxy](https://www.npmjs.com/%40isomorphic-git/cors-proxy). Value is stored in the git config file for that repo.
 * @param {string} [args.ref] - Which branch to checkout. By default this is the designated "main branch" of the repository.
 * @param {boolean} [args.singleBranch = false] - Instead of the default behavior of fetching all the branches, only fetch a single branch.
 * @param {boolean} [args.noCheckout = false] - If true, clone will only fetch the repo, not check out a branch. Skipping checkout can save a lot of time normally spent writing files to disk.
 * @param {boolean} [args.noTags = false] - By default clone will fetch all tags. `noTags` disables that behavior.
 * @param {string} [args.remote = 'origin'] - What to name the remote that is created.
 * @param {number} [args.depth] - Integer. Determines how much of the git repository's history to retrieve
 * @param {Date} [args.since] - Only fetch commits created after the given date. Mutually exclusive with `depth`.
 * @param {string[]} [args.exclude = []] - A list of branches or tags. Instructs the remote server not to send us any commits reachable from these refs.
 * @param {boolean} [args.relative = false] - Changes the meaning of `depth` to be measured from the current shallow depth rather than from the branch tip.
 * @param {Object<string, string>} [args.headers = {}] - Additional headers to include in HTTP requests, similar to git's `extraHeader` config
 * @param {object} [args.cache] - a [cache](cache.md) object
 * @param {boolean} [args.nonBlocking = false] - if true, checkout will happen non-blockingly (useful for long-running operations blocking the thread in browser environments)
 * @param {number} [args.batchSize = 100] - If args.nonBlocking is true, batchSize is the number of files to process at a time avoid blocking the executing thread. The default value of 100 is a good starting point.
 *
 * @returns {Promise<void>} Resolves successfully when clone completes
 *
 * @example
 * await git.clone({
 *   fs,
 *   http,
 *   dir: '/tutorial',
 *   corsProxy: 'https://cors.isomorphic-git.org',
 *   url: 'https://github.com/isomorphic-git/isomorphic-git',
 *   singleBranch: true,
 *   depth: 1
 * })
 * console.log('done')
 *
 */
async function clone({
  fs,
  http,
  onProgress,
  onMessage,
  onAuth,
  onAuthSuccess,
  onAuthFailure,
  onPostCheckout,
  dir,
  gitdir = join(dir, '.git'),
  url,
  corsProxy = undefined,
  ref = undefined,
  remote = 'origin',
  depth = undefined,
  since = undefined,
  exclude = [],
  relative = false,
  singleBranch = false,
  noCheckout = false,
  noTags = false,
  headers = {},
  cache = {},
  nonBlocking = false,
  batchSize = 100,
}) {
  try {
    assertParameter('fs', fs);
    assertParameter('http', http);
    assertParameter('gitdir', gitdir);
    if (!noCheckout) {
      assertParameter('dir', dir);
    }
    assertParameter('url', url);

    const fsp = new FileSystem(fs);
    const updatedGitdir = await discoverGitdir({ fsp, dotgit: gitdir });
    return await _clone({
      fs: fsp,
      cache,
      http,
      onProgress,
      onMessage,
      onAuth,
      onAuthSuccess,
      onAuthFailure,
      onPostCheckout,
      dir,
      gitdir: updatedGitdir,
      url,
      corsProxy,
      ref,
      remote,
      depth,
      since,
      exclude,
      relative,
      singleBranch,
      noCheckout,
      noTags,
      headers,
      nonBlocking,
      batchSize,
    })
  } catch (err) {
    err.caller = 'git.clone';
    throw err
  }
}

// @ts-check
/**
 * Create a new commit
 *
 * @param {Object} args
 * @param {FsClient} args.fs - a file system implementation
 * @param {SignCallback} [args.onSign] - a PGP signing implementation
 * @param {string} [args.dir] - The [working tree](dir-vs-gitdir.md) directory path
 * @param {string} [args.gitdir=join(dir,'.git')] - [required] The [git directory](dir-vs-gitdir.md) path
 * @param {string} [args.message] - The commit message to use. Required, unless `amend === true`
 * @param {Object} [args.author] - The details about the author.
 * @param {string} [args.author.name] - Default is `user.name` config.
 * @param {string} [args.author.email] - Default is `user.email` config.
 * @param {number} [args.author.timestamp=Math.floor(Date.now()/1000)] - Set the author timestamp field. This is the integer number of seconds since the Unix epoch (1970-01-01 00:00:00).
 * @param {number} [args.author.timezoneOffset] - Set the author timezone offset field. This is the difference, in minutes, from the current timezone to UTC. Default is `(new Date()).getTimezoneOffset()`.
 * @param {Object} [args.committer = author] - The details about the commit committer, in the same format as the author parameter. If not specified, the author details are used.
 * @param {string} [args.committer.name] - Default is `user.name` config.
 * @param {string} [args.committer.email] - Default is `user.email` config.
 * @param {number} [args.committer.timestamp=Math.floor(Date.now()/1000)] - Set the committer timestamp field. This is the integer number of seconds since the Unix epoch (1970-01-01 00:00:00).
 * @param {number} [args.committer.timezoneOffset] - Set the committer timezone offset field. This is the difference, in minutes, from the current timezone to UTC. Default is `(new Date()).getTimezoneOffset()`.
 * @param {string} [args.signingKey] - Sign the tag object using this private PGP key.
 * @param {boolean} [args.amend = false] - If true, replaces the last commit pointed to by `ref` with a new commit.
 * @param {boolean} [args.dryRun = false] - If true, simulates making a commit so you can test whether it would succeed. Implies `noUpdateBranch`.
 * @param {boolean} [args.noUpdateBranch = false] - If true, does not update the branch pointer after creating the commit.
 * @param {boolean} [args.disallowEmpty = false] - If true, throws an error instead of creating a commit with no staged changes.
 * @param {string} [args.ref] - The fully expanded name of the branch to commit to. Default is the current branch pointed to by HEAD. (TODO: fix it so it can expand branch names without throwing if the branch doesn't exist yet.)
 * @param {string[]} [args.parent] - The SHA-1 object ids of the commits to use as parents. If not specified, the commit pointed to by `ref` is used.
 * @param {string} [args.tree] - The SHA-1 object id of the tree to use. If not specified, a new tree object is created from the current git index.
 * @param {object} [args.cache] - a [cache](cache.md) object
 *
 * @returns {Promise<string>} Resolves successfully with the SHA-1 object id of the newly created commit.
 *
 * @example
 * let sha = await git.commit({
 *   fs,
 *   dir: '/tutorial',
 *   author: {
 *     name: 'Mr. Test',
 *     email: 'mrtest@example.com',
 *   },
 *   message: 'Added the a.txt file'
 * })
 * console.log(sha)
 *
 */
async function commit({
  fs: _fs,
  onSign,
  dir,
  gitdir = join(dir, '.git'),
  message,
  author,
  committer,
  signingKey,
  amend = false,
  dryRun = false,
  noUpdateBranch = false,
  disallowEmpty = false,
  ref,
  parent,
  tree,
  cache = {},
}) {
  try {
    assertParameter('fs', _fs);
    if (!amend) {
      assertParameter('message', message);
    }
    if (signingKey) {
      assertParameter('onSign', onSign);
    }
    const fs = new FileSystem(_fs);
    const updatedGitdir = await discoverGitdir({ fsp: fs, dotgit: gitdir });

    return await _commit({
      fs,
      cache,
      onSign,
      gitdir: updatedGitdir,
      message,
      author,
      committer,
      signingKey,
      amend,
      dryRun,
      noUpdateBranch,
      disallowEmpty,
      ref,
      parent,
      tree,
    })
  } catch (err) {
    err.caller = 'git.commit';
    throw err
  }
}

// @ts-check

/**
 * Get the name of the branch currently pointed to by .git/HEAD
 *
 * @param {Object} args
 * @param {FsClient} args.fs - a file system implementation
 * @param {string} [args.dir] - The [working tree](dir-vs-gitdir.md) directory path
 * @param {string} [args.gitdir=join(dir,'.git')] - [required] The [git directory](dir-vs-gitdir.md) path
 * @param {boolean} [args.fullname = false] - Return the full path (e.g. "refs/heads/main") instead of the abbreviated form.
 * @param {boolean} [args.test = false] - If the current branch doesn't actually exist (such as right after git init) then return `undefined`.
 *
 * @returns {Promise<string|void>} The name of the current branch or undefined if the HEAD is detached.
 *
 * @example
 * // Get the current branch name
 * let branch = await git.currentBranch({
 *   fs,
 *   dir: '/tutorial',
 *   fullname: false
 * })
 * console.log(branch)
 *
 */
async function currentBranch({
  fs,
  dir,
  gitdir = join(dir, '.git'),
  fullname = false,
  test = false,
}) {
  try {
    assertParameter('fs', fs);
    assertParameter('gitdir', gitdir);
    const fsp = new FileSystem(fs);
    const updatedGitdir = await discoverGitdir({ fsp, dotgit: gitdir });
    return await _currentBranch({
      fs: fsp,
      gitdir: updatedGitdir,
      fullname,
      test,
    })
  } catch (err) {
    err.caller = 'git.currentBranch';
    throw err
  }
}

// @ts-check

/**
 * @param {Object} args
 * @param {import('../models/FileSystem.js').FileSystem} args.fs
 * @param {string} args.gitdir
 * @param {string} args.ref
 *
 * @returns {Promise<void>}
 */
async function _deleteBranch({ fs, gitdir, ref }) {
  ref = ref.startsWith('refs/heads/') ? ref : `refs/heads/${ref}`;
  const exist = await GitRefManager.exists({ fs, gitdir, ref });
  if (!exist) {
    throw new NotFoundError(ref)
  }

  const fullRef = await GitRefManager.expand({ fs, gitdir, ref });
  const currentRef = await _currentBranch({ fs, gitdir, fullname: true });
  if (fullRef === currentRef) {
    // detach HEAD
    const value = await GitRefManager.resolve({ fs, gitdir, ref: fullRef });
    await GitRefManager.writeRef({ fs, gitdir, ref: 'HEAD', value });
  }

  // Delete a specified branch
  await GitRefManager.deleteRef({ fs, gitdir, ref: fullRef });

  // Delete branch config entries
  const abbrevRef = abbreviateRef(ref);
  const config = await GitConfigManager.get({ fs, gitdir });
  await config.deleteSection('branch', abbrevRef);
  await GitConfigManager.save({ fs, gitdir, config });
}

// @ts-check

/**
 * Delete a local branch
 *
 * > Note: This only deletes loose branches - it should be fixed in the future to delete packed branches as well.
 *
 * @param {Object} args
 * @param {FsClient} args.fs - a file system implementation
 * @param {string} [args.dir] - The [working tree](dir-vs-gitdir.md) directory path
 * @param {string} [args.gitdir=join(dir,'.git')] - [required] The [git directory](dir-vs-gitdir.md) path
 * @param {string} args.ref - The branch to delete
 *
 * @returns {Promise<void>} Resolves successfully when filesystem operations are complete
 *
 * @example
 * await git.deleteBranch({ fs, dir: '/tutorial', ref: 'local-branch' })
 * console.log('done')
 *
 */
async function deleteBranch({
  fs,
  dir,
  gitdir = join(dir, '.git'),
  ref,
}) {
  try {
    assertParameter('fs', fs);
    assertParameter('ref', ref);
    const fsp = new FileSystem(fs);
    const updatedGitdir = await discoverGitdir({ fsp, dotgit: gitdir });
    return await _deleteBranch({
      fs: fsp,
      gitdir: updatedGitdir,
      ref,
    })
  } catch (err) {
    err.caller = 'git.deleteBranch';
    throw err
  }
}

// @ts-check

/**
 * Delete a local ref
 *
 * @param {Object} args
 * @param {FsClient} args.fs - a file system implementation
 * @param {string} [args.dir] - The [working tree](dir-vs-gitdir.md) directory path
 * @param {string} [args.gitdir=join(dir,'.git')] - [required] The [git directory](dir-vs-gitdir.md) path
 * @param {string} args.ref - The ref to delete
 *
 * @returns {Promise<void>} Resolves successfully when filesystem operations are complete
 *
 * @example
 * await git.deleteRef({ fs, dir: '/tutorial', ref: 'refs/tags/test-tag' })
 * console.log('done')
 *
 */
async function deleteRef({ fs, dir, gitdir = join(dir, '.git'), ref }) {
  try {
    assertParameter('fs', fs);
    assertParameter('ref', ref);
    const fsp = new FileSystem(fs);
    const updatedGitdir = await discoverGitdir({ fsp, dotgit: gitdir });
    await GitRefManager.deleteRef({ fs: fsp, gitdir: updatedGitdir, ref });
  } catch (err) {
    err.caller = 'git.deleteRef';
    throw err
  }
}

// @ts-check

/**
 * @param {Object} args
 * @param {import('../models/FileSystem.js').FileSystem} args.fs
 * @param {string} args.gitdir
 * @param {string} args.remote
 *
 * @returns {Promise<void>}
 */
async function _deleteRemote({ fs, gitdir, remote }) {
  const config = await GitConfigManager.get({ fs, gitdir });
  await config.deleteSection('remote', remote);
  await GitConfigManager.save({ fs, gitdir, config });
}

// @ts-check

/**
 * Removes the local config entry for a given remote
 *
 * @param {Object} args
 * @param {FsClient} args.fs - a file system implementation
 * @param {string} [args.dir] - The [working tree](dir-vs-gitdir.md) directory path
 * @param {string} [args.gitdir=join(dir,'.git')] - [required] The [git directory](dir-vs-gitdir.md) path
 * @param {string} args.remote - The name of the remote to delete
 *
 * @returns {Promise<void>} Resolves successfully when filesystem operations are complete
 *
 * @example
 * await git.deleteRemote({ fs, dir: '/tutorial', remote: 'upstream' })
 * console.log('done')
 *
 */
async function deleteRemote({
  fs,
  dir,
  gitdir = join(dir, '.git'),
  remote,
}) {
  try {
    assertParameter('fs', fs);
    assertParameter('remote', remote);
    const fsp = new FileSystem(fs);
    const updatedGitdir = await discoverGitdir({ fsp, dotgit: gitdir });
    return await _deleteRemote({
      fs: fsp,
      gitdir: updatedGitdir,
      remote,
    })
  } catch (err) {
    err.caller = 'git.deleteRemote';
    throw err
  }
}

// @ts-check

/**
 * Delete a local tag ref
 *
 * @param {Object} args
 * @param {import('../models/FileSystem.js').FileSystem} args.fs
 * @param {string} args.gitdir
 * @param {string} args.ref - The tag to delete
 *
 * @returns {Promise<void>} Resolves successfully when filesystem operations are complete
 *
 * @example
 * await git.deleteTag({ dir: '$input((/))', ref: '$input((test-tag))' })
 * console.log('done')
 *
 */
async function _deleteTag({ fs, gitdir, ref }) {
  ref = ref.startsWith('refs/tags/') ? ref : `refs/tags/${ref}`;
  await GitRefManager.deleteRef({ fs, gitdir, ref });
}

// @ts-check

/**
 * Delete a local tag ref
 *
 * @param {Object} args
 * @param {FsClient} args.fs - a file system implementation
 * @param {string} [args.dir] - The [working tree](dir-vs-gitdir.md) directory path
 * @param {string} [args.gitdir=join(dir,'.git')] - [required] The [git directory](dir-vs-gitdir.md) path
 * @param {string} args.ref - The tag to delete
 *
 * @returns {Promise<void>} Resolves successfully when filesystem operations are complete
 *
 * @example
 * await git.deleteTag({ fs, dir: '/tutorial', ref: 'test-tag' })
 * console.log('done')
 *
 */
async function deleteTag({ fs, dir, gitdir = join(dir, '.git'), ref }) {
  try {
    assertParameter('fs', fs);
    assertParameter('ref', ref);
    const fsp = new FileSystem(fs);
    const updatedGitdir = await discoverGitdir({ fsp, dotgit: gitdir });
    return await _deleteTag({
      fs: fsp,
      gitdir: updatedGitdir,
      ref,
    })
  } catch (err) {
    err.caller = 'git.deleteTag';
    throw err
  }
}

async function expandOidLoose({ fs, gitdir, oid: short }) {
  const prefix = short.slice(0, 2);
  const objectsSuffixes = await fs.readdir(`${gitdir}/objects/${prefix}`);
  return objectsSuffixes
    .map(suffix => `${prefix}${suffix}`)
    .filter(_oid => _oid.startsWith(short))
}

async function expandOidPacked({
  fs,
  cache,
  gitdir,
  oid: short,
  getExternalRefDelta,
}) {
  // Iterate through all the .pack files
  const results = [];
  let list = await fs.readdir(join(gitdir, 'objects/pack'));
  list = list.filter(x => x.endsWith('.idx'));
  for (const filename of list) {
    const indexFile = `${gitdir}/objects/pack/${filename}`;
    const p = await readPackIndex({
      fs,
      cache,
      filename: indexFile,
      getExternalRefDelta,
    });
    if (p.error) throw new InternalError(p.error)
    // Search through the list of oids in the packfile
    for (const oid of p.offsets.keys()) {
      if (oid.startsWith(short)) results.push(oid);
    }
  }
  return results
}

async function _expandOid({ fs, cache, gitdir, oid: short }) {
  // Curry the current read method so that the packfile un-deltification
  // process can acquire external ref-deltas.
  const getExternalRefDelta = oid => _readObject({ fs, cache, gitdir, oid });

  const results = await expandOidLoose({ fs, gitdir, oid: short });
  const packedOids = await expandOidPacked({
    fs,
    cache,
    gitdir,
    oid: short,
    getExternalRefDelta,
  });
  // Objects can exist in a pack file as well as loose, make sure we only get a list of unique oids.
  for (const packedOid of packedOids) {
    if (results.indexOf(packedOid) === -1) {
      results.push(packedOid);
    }
  }

  if (results.length === 1) {
    return results[0]
  }
  if (results.length > 1) {
    throw new AmbiguousError('oids', short, results)
  }
  throw new NotFoundError(`an object matching "${short}"`)
}

// @ts-check

/**
 * Expand and resolve a short oid into a full oid
 *
 * @param {Object} args
 * @param {FsClient} args.fs - a file system implementation
 * @param {string} [args.dir] - The [working tree](dir-vs-gitdir.md) directory path
 * @param {string} [args.gitdir=join(dir,'.git')] - [required] The [git directory](dir-vs-gitdir.md) path
 * @param {string} args.oid - The shortened oid prefix to expand (like "0414d2a")
 * @param {object} [args.cache] - a [cache](cache.md) object
 *
 * @returns {Promise<string>} Resolves successfully with the full oid (like "0414d2a286d7bbc7a4a326a61c1f9f888a8ab87f")
 *
 * @example
 * let oid = await git.expandOid({ fs, dir: '/tutorial', oid: '0414d2a'})
 * console.log(oid)
 *
 */
async function expandOid({
  fs,
  dir,
  gitdir = join(dir, '.git'),
  oid,
  cache = {},
}) {
  try {
    assertParameter('fs', fs);
    assertParameter('gitdir', gitdir);
    assertParameter('oid', oid);
    const fsp = new FileSystem(fs);
    const updatedGitdir = await discoverGitdir({ fsp, dotgit: gitdir });
    return await _expandOid({
      fs: fsp,
      cache,
      gitdir: updatedGitdir,
      oid,
    })
  } catch (err) {
    err.caller = 'git.expandOid';
    throw err
  }
}

// @ts-check

/**
 * Expand an abbreviated ref to its full name
 *
 * @param {Object} args
 * @param {FsClient} args.fs - a file system implementation
 * @param {string} [args.dir] - The [working tree](dir-vs-gitdir.md) directory path
 * @param {string} [args.gitdir=join(dir,'.git')] - [required] The [git directory](dir-vs-gitdir.md) path
 * @param {string} args.ref - The ref to expand (like "v1.0.0")
 *
 * @returns {Promise<string>} Resolves successfully with a full ref name ("refs/tags/v1.0.0")
 *
 * @example
 * let fullRef = await git.expandRef({ fs, dir: '/tutorial', ref: 'main'})
 * console.log(fullRef)
 *
 */
async function expandRef({ fs, dir, gitdir = join(dir, '.git'), ref }) {
  try {
    assertParameter('fs', fs);
    assertParameter('gitdir', gitdir);
    assertParameter('ref', ref);
    const fsp = new FileSystem(fs);
    const updatedGitdir = await discoverGitdir({ fsp, dotgit: gitdir });
    return await GitRefManager.expand({
      fs: fsp,
      gitdir: updatedGitdir,
      ref,
    })
  } catch (err) {
    err.caller = 'git.expandRef';
    throw err
  }
}

// @ts-check

/**
 * @param {object} args
 * @param {import('../models/FileSystem.js').FileSystem} args.fs
 * @param {any} args.cache
 * @param {string} args.gitdir
 * @param {string[]} args.oids
 *
 */
async function _findMergeBase({ fs, cache, gitdir, oids }) {
  // Note: right now, the tests are geared so that the output should match that of
  // `git merge-base --all --octopus`
  // because without the --octopus flag, git's output seems to depend on the ORDER of the oids,
  // and computing virtual merge bases is just too much for me to fathom right now.

  // If we start N independent walkers, one at each of the given `oids`, and walk backwards
  // through ancestors, eventually we'll discover commits where each one of these N walkers
  // has passed through. We cannot stop at the first common commit because a better common
  // ancestor may still be present in another branch of the graph.
  const visits = {};
  const passes = oids.length;
  const common = new Set();
  const parents = new Map();
  const shallows = await GitShallowManager.read({ fs, gitdir });
  const readParents = async oid => {
    if (parents.has(oid)) return parents.get(oid)
    const { object, type } = await _readObject({ fs, cache, gitdir, oid });
    if (type !== 'commit') {
      throw new ObjectTypeError(oid, type, 'commit')
    }
    const commit = GitCommit.from(object);
    const { parent } = commit.parseHeaders();
    const result = shallows.has(oid) ? [] : parent;
    parents.set(oid, result);
    return result
  };
  let heads = oids.map((oid, index) => ({ index, oid }));
  while (heads.length) {
    // Count how many times we've passed each commit
    for (const { oid, index } of heads) {
      await readParents(oid);
      if (!visits[oid]) visits[oid] = new Set();
      visits[oid].add(index);
      if (visits[oid].size === passes) {
        common.add(oid);
      }
    }
    const newheads = new Map();
    for (const { oid, index } of heads) {
      // Parents of a common commit cannot be better merge bases.
      if (common.has(oid)) continue
      for (const parent of await readParents(oid)) {
        if (!visits[parent] || !visits[parent].has(index)) {
          newheads.set(parent + ':' + index, { oid: parent, index });
        }
      }
    }
    heads = Array.from(newheads.values());
  }

  if (common.size < 2) return [...common]

  // A merge base is only "best" when it is not an ancestor of another
  // common ancestor. This also keeps independent criss-cross bases.
  const redundant = new Set();
  for (const oid of common) {
    const ancestors = [...(await readParents(oid))];
    const seen = new Set();
    while (ancestors.length) {
      const ancestor = ancestors.pop();
      if (seen.has(ancestor)) continue
      seen.add(ancestor);
      if (common.has(ancestor)) {
        redundant.add(ancestor);
      } else {
        ancestors.push(...(await readParents(ancestor)));
      }
    }
  }
  return [...common].filter(oid => !redundant.has(oid))
}

// @ts-check

// import diff3 from 'node-diff3'
/**
 *
 * @typedef {Object} MergeResult - Returns an object with a schema like this:
 * @property {string} [oid] - The SHA-1 object id that is now at the head of the branch. Absent only if `dryRun` was specified and `mergeCommit` is true.
 * @property {boolean} [alreadyMerged] - True if the branch was already merged so no changes were made
 * @property {boolean} [fastForward] - True if it was a fast-forward merge
 * @property {boolean} [mergeCommit] - True if merge resulted in a merge commit
 * @property {string} [tree] - The SHA-1 object id of the tree resulting from a merge commit
 *
 */

/**
 * @param {object} args
 * @param {import('../models/FileSystem.js').FileSystem} args.fs
 * @param {object} args.cache
 * @param {string} args.gitdir
 * @param {string} [args.ours]
 * @param {string} args.theirs
 * @param {boolean} args.fastForward
 * @param {boolean} args.fastForwardOnly
 * @param {boolean} args.dryRun
 * @param {boolean} args.noUpdateBranch
 * @param {boolean} args.abortOnConflict
 * @param {string} [args.message]
 * @param {Object} args.author
 * @param {string} args.author.name
 * @param {string} args.author.email
 * @param {number} args.author.timestamp
 * @param {number} args.author.timezoneOffset
 * @param {Object} args.committer
 * @param {string} args.committer.name
 * @param {string} args.committer.email
 * @param {number} args.committer.timestamp
 * @param {number} args.committer.timezoneOffset
 * @param {string} [args.signingKey]
 * @param {SignCallback} [args.onSign] - a PGP signing implementation
 * @param {MergeDriverCallback} [args.mergeDriver]
 * @param {boolean} args.allowUnrelatedHistories
 *
 * @returns {Promise<MergeResult>} Resolves to a description of the merge operation
 *
 */
async function _merge({
  fs,
  cache,
  dir,
  gitdir,
  ours,
  theirs,
  fastForward = true,
  fastForwardOnly = false,
  dryRun = false,
  noUpdateBranch = false,
  abortOnConflict = true,
  message,
  author,
  committer,
  signingKey,
  onSign,
  mergeDriver,
  allowUnrelatedHistories = false,
}) {
  if (ours === undefined) {
    ours = await _currentBranch({ fs, gitdir, fullname: true });
  }
  ours = await GitRefManager.expand({
    fs,
    gitdir,
    ref: ours,
  });
  theirs = await GitRefManager.expand({
    fs,
    gitdir,
    ref: theirs,
  });
  const ourOid = await GitRefManager.resolve({
    fs,
    gitdir,
    ref: ours,
  });
  const theirOid = await GitRefManager.resolve({
    fs,
    gitdir,
    ref: theirs,
  });
  // find most recent common ancestor of ref a and ref b
  const baseOids = await _findMergeBase({
    fs,
    cache,
    gitdir,
    oids: [ourOid, theirOid],
  });
  if (baseOids.length !== 1) {
    if (baseOids.length === 0 && allowUnrelatedHistories) {
      // 4b825…  == the empty tree used by git
      baseOids.push('4b825dc642cb6eb9a060e54bf8d69288fbee4904');
    } else {
      // TODO: Recursive Merge strategy
      throw new MergeNotSupportedError()
    }
  }
  const baseOid = baseOids[0];
  // handle fast-forward case
  if (baseOid === theirOid) {
    return {
      oid: ourOid,
      alreadyMerged: true,
    }
  }
  if (fastForward && baseOid === ourOid) {
    if (!dryRun && !noUpdateBranch) {
      await GitRefManager.writeRef({ fs, gitdir, ref: ours, value: theirOid });
    }
    return {
      oid: theirOid,
      fastForward: true,
    }
  } else {
    // not a simple fast-forward
    if (fastForwardOnly) {
      throw new FastForwardError()
    }
    // try a fancier merge
    const tree = await GitIndexManager.acquire(
      { fs, gitdir, cache, allowUnmerged: false },
      async index => {
        return mergeTree({
          fs,
          cache,
          dir,
          gitdir,
          index,
          ourOid,
          theirOid,
          baseOid,
          ourName: abbreviateRef(ours),
          baseName: 'base',
          theirName: abbreviateRef(theirs),
          dryRun,
          abortOnConflict,
          mergeDriver,
        })
      }
    );

    // Defer throwing error until the index lock is relinquished and index is
    // written to filesystem
    if (tree instanceof MergeConflictError) throw tree

    if (!message) {
      message = `Merge branch '${abbreviateRef(theirs)}' into ${abbreviateRef(
        ours
      )}`;
    }
    const oid = await _commit({
      fs,
      cache,
      gitdir,
      message,
      ref: ours,
      tree,
      parent: [ourOid, theirOid],
      author,
      committer,
      signingKey,
      onSign,
      dryRun,
      noUpdateBranch,
    });
    return {
      oid,
      tree,
      mergeCommit: true,
    }
  }
}

// @ts-check

/**
 * @param {object} args
 * @param {import('../models/FileSystem.js').FileSystem} args.fs
 * @param {object} args.cache
 * @param {HttpClient} args.http
 * @param {ProgressCallback} [args.onProgress]
 * @param {MessageCallback} [args.onMessage]
 * @param {AuthCallback} [args.onAuth]
 * @param {AuthFailureCallback} [args.onAuthFailure]
 * @param {AuthSuccessCallback} [args.onAuthSuccess]
 * @param {string} args.dir
 * @param {string} args.gitdir
 * @param {string} args.ref
 * @param {string} [args.url]
 * @param {string} [args.remote]
 * @param {string} [args.remoteRef]
 * @param {boolean} [args.prune]
 * @param {boolean} [args.pruneTags]
 * @param {string} [args.corsProxy]
 * @param {boolean} args.singleBranch
 * @param {boolean} args.fastForward
 * @param {boolean} args.fastForwardOnly
 * @param {Object<string, string>} [args.headers]
 * @param {Object} args.author
 * @param {string} args.author.name
 * @param {string} args.author.email
 * @param {number} args.author.timestamp
 * @param {number} args.author.timezoneOffset
 * @param {Object} args.committer
 * @param {string} args.committer.name
 * @param {string} args.committer.email
 * @param {number} args.committer.timestamp
 * @param {number} args.committer.timezoneOffset
 * @param {string} [args.signingKey]
 *
 * @returns {Promise<void>} Resolves successfully when pull operation completes
 *
 */
async function _pull({
  fs,
  cache,
  http,
  onProgress,
  onMessage,
  onAuth,
  onAuthSuccess,
  onAuthFailure,
  dir,
  gitdir,
  ref,
  url,
  remote,
  remoteRef,
  prune,
  pruneTags,
  fastForward,
  fastForwardOnly,
  corsProxy,
  singleBranch,
  headers,
  author,
  committer,
  signingKey,
}) {
  try {
    // If ref is undefined, use 'HEAD'
    if (!ref) {
      const head = await _currentBranch({ fs, gitdir });
      // TODO: use a better error.
      if (!head) {
        throw new MissingParameterError('ref')
      }
      ref = head;
    }

    const { fetchHead, fetchHeadDescription } = await _fetch({
      fs,
      cache,
      http,
      onProgress,
      onMessage,
      onAuth,
      onAuthSuccess,
      onAuthFailure,
      gitdir,
      corsProxy,
      ref,
      url,
      remote,
      remoteRef,
      singleBranch,
      headers,
      prune,
      pruneTags,
    });
    // Merge the remote tracking branch into the local one.
    await _merge({
      fs,
      cache,
      gitdir,
      ours: ref,
      theirs: fetchHead,
      fastForward,
      fastForwardOnly,
      message: `Merge ${fetchHeadDescription}`,
      author,
      committer,
      signingKey,
      dryRun: false,
      noUpdateBranch: false,
    });
    await _checkout({
      fs,
      cache,
      onProgress,
      dir,
      gitdir,
      ref,
      remote,
      noCheckout: false,
    });
  } catch (err) {
    err.caller = 'git.pull';
    throw err
  }
}

// @ts-check

/**
 * Like `pull`, but hard-coded with `fastForward: true` so there is no need for an `author` parameter.
 *
 * @param {object} args
 * @param {FsClient} args.fs - a file system client
 * @param {HttpClient} args.http - an HTTP client
 * @param {ProgressCallback} [args.onProgress] - optional progress event callback
 * @param {MessageCallback} [args.onMessage] - optional message event callback
 * @param {AuthCallback} [args.onAuth] - optional auth fill callback
 * @param {AuthFailureCallback} [args.onAuthFailure] - optional auth rejected callback
 * @param {AuthSuccessCallback} [args.onAuthSuccess] - optional auth approved callback
 * @param {string} args.dir] - The [working tree](dir-vs-gitdir.md) directory path
 * @param {string} [args.gitdir=join(dir,'.git')] - [required] The [git directory](dir-vs-gitdir.md) path
 * @param {string} [args.ref] - Which branch to merge into. By default this is the currently checked out branch.
 * @param {string} [args.url] - (Added in 1.1.0) The URL of the remote repository. The default is the value set in the git config for that remote.
 * @param {string} [args.remote] - (Added in 1.1.0) If URL is not specified, determines which remote to use.
 * @param {string} [args.remoteRef] - (Added in 1.1.0) The name of the branch on the remote to fetch. By default this is the configured remote tracking branch.
 * @param {string} [args.corsProxy] - Optional [CORS proxy](https://www.npmjs.com/%40isomorphic-git/cors-proxy). Overrides value in repo config.
 * @param {boolean} [args.singleBranch = false] - Instead of the default behavior of fetching all the branches, only fetch a single branch.
 * @param {Object<string, string>} [args.headers] - Additional headers to include in HTTP requests, similar to git's `extraHeader` config
 * @param {object} [args.cache] - a [cache](cache.md) object
 *
 * @returns {Promise<void>} Resolves successfully when pull operation completes
 *
 * @example
 * await git.fastForward({
 *   fs,
 *   http,
 *   dir: '/tutorial',
 *   ref: 'main',
 *   singleBranch: true
 * })
 * console.log('done')
 *
 */
async function fastForward({
  fs,
  http,
  onProgress,
  onMessage,
  onAuth,
  onAuthSuccess,
  onAuthFailure,
  dir,
  gitdir = join(dir, '.git'),
  ref,
  url,
  remote,
  remoteRef,
  corsProxy,
  singleBranch,
  headers = {},
  cache = {},
}) {
  try {
    assertParameter('fs', fs);
    assertParameter('http', http);
    assertParameter('gitdir', gitdir);

    const thisWillNotBeUsed = {
      name: '',
      email: '',
      timestamp: Date.now(),
      timezoneOffset: 0,
    };

    const fsp = new FileSystem(fs);
    const updatedGitdir = await discoverGitdir({ fsp, dotgit: gitdir });
    return await _pull({
      fs: fsp,
      cache,
      http,
      onProgress,
      onMessage,
      onAuth,
      onAuthSuccess,
      onAuthFailure,
      dir,
      gitdir: updatedGitdir,
      ref,
      url,
      remote,
      remoteRef,
      fastForwardOnly: true,
      corsProxy,
      singleBranch,
      headers,
      author: thisWillNotBeUsed,
      committer: thisWillNotBeUsed,
    })
  } catch (err) {
    err.caller = 'git.fastForward';
    throw err
  }
}

// @ts-check

/**
 *
 * @typedef {object} FetchResult - The object returned has the following schema:
 * @property {string | null} defaultBranch - The branch that is cloned if no branch is specified
 * @property {string | null} fetchHead - The SHA-1 object id of the fetched head commit
 * @property {string | null} fetchHeadDescription - a textual description of the branch that was fetched
 * @property {Object<string, string>} [headers] - The HTTP response headers returned by the git server
 * @property {string[]} [pruned] - A list of branches that were pruned, if you provided the `prune` parameter
 *
 */

/**
 * Fetch commits from a remote repository
 *
 * @param {object} args
 * @param {FsClient} args.fs - a file system client
 * @param {HttpClient} args.http - an HTTP client
 * @param {ProgressCallback} [args.onProgress] - optional progress event callback
 * @param {MessageCallback} [args.onMessage] - optional message event callback
 * @param {AuthCallback} [args.onAuth] - optional auth fill callback
 * @param {AuthFailureCallback} [args.onAuthFailure] - optional auth rejected callback
 * @param {AuthSuccessCallback} [args.onAuthSuccess] - optional auth approved callback
 * @param {string} [args.dir] - The [working tree](dir-vs-gitdir.md) directory path
 * @param {string} [args.gitdir=join(dir,'.git')] - [required] The [git directory](dir-vs-gitdir.md) path
 * @param {string} [args.url] - The URL of the remote repository. The default is the value set in the git config for that remote.
 * @param {string} [args.remote] - If URL is not specified, determines which remote to use.
 * @param {boolean} [args.singleBranch = false] - Instead of the default behavior of fetching all the branches, only fetch a single branch.
 * @param {string} [args.ref] - Which branch to fetch if `singleBranch` is true. By default this is the current branch or the remote's default branch.
 * @param {string} [args.remoteRef] - The name of the branch on the remote to fetch if `singleBranch` is true. By default this is the configured remote tracking branch.
 * @param {boolean} [args.tags = false] - Also fetch tags
 * @param {number} [args.depth] - Integer. Determines how much of the git repository's history to retrieve
 * @param {boolean} [args.relative = false] - Changes the meaning of `depth` to be measured from the current shallow depth rather than from the branch tip.
 * @param {Date} [args.since] - Only fetch commits created after the given date. Mutually exclusive with `depth`.
 * @param {string[]} [args.exclude = []] - A list of branches or tags. Instructs the remote server not to send us any commits reachable from these refs.
 * @param {boolean} [args.prune = false] - Delete local remote-tracking branches that are not present on the remote
 * @param {boolean} [args.pruneTags = false] - Prune local tags that don’t exist on the remote, and force-update those tags that differ
 * @param {string} [args.corsProxy] - Optional [CORS proxy](https://www.npmjs.com/%40isomorphic-git/cors-proxy). Overrides value in repo config.
 * @param {Object<string, string>} [args.headers] - Additional headers to include in HTTP requests, similar to git's `extraHeader` config
 * @param {object} [args.cache] - a [cache](cache.md) object
 *
 * @returns {Promise<FetchResult>} Resolves successfully when fetch completes
 * @see FetchResult
 *
 * @example
 * let result = await git.fetch({
 *   fs,
 *   http,
 *   dir: '/tutorial',
 *   corsProxy: 'https://cors.isomorphic-git.org',
 *   url: 'https://github.com/isomorphic-git/isomorphic-git',
 *   ref: 'main',
 *   depth: 1,
 *   singleBranch: true,
 *   tags: false
 * })
 * console.log(result)
 *
 */
async function fetch({
  fs,
  http,
  onProgress,
  onMessage,
  onAuth,
  onAuthSuccess,
  onAuthFailure,
  dir,
  gitdir = join(dir, '.git'),
  ref,
  remote,
  remoteRef,
  url,
  corsProxy,
  depth = null,
  since = null,
  exclude = [],
  relative = false,
  tags = false,
  singleBranch = false,
  headers = {},
  prune = false,
  pruneTags = false,
  cache = {},
}) {
  try {
    assertParameter('fs', fs);
    assertParameter('http', http);
    assertParameter('gitdir', gitdir);

    const fsp = new FileSystem(fs);
    const updatedGitdir = await discoverGitdir({ fsp, dotgit: gitdir });
    return await _fetch({
      fs: fsp,
      cache,
      http,
      onProgress,
      onMessage,
      onAuth,
      onAuthSuccess,
      onAuthFailure,
      gitdir: updatedGitdir,
      ref,
      remote,
      remoteRef,
      url,
      corsProxy,
      depth,
      since,
      exclude,
      relative,
      tags,
      singleBranch,
      headers,
      prune,
      pruneTags,
    })
  } catch (err) {
    err.caller = 'git.fetch';
    throw err
  }
}

// @ts-check

/**
 * Find the merge base for a set of commits
 *
 * @param {object} args
 * @param {FsClient} args.fs - a file system client
 * @param {string} [args.dir] - The [working tree](dir-vs-gitdir.md) directory path
 * @param {string} [args.gitdir=join(dir,'.git')] - [required] The [git directory](dir-vs-gitdir.md) path
 * @param {string[]} args.oids - Which commits
 * @param {object} [args.cache] - a [cache](cache.md) object
 *
 */
async function findMergeBase({
  fs,
  dir,
  gitdir = join(dir, '.git'),
  oids,
  cache = {},
}) {
  try {
    assertParameter('fs', fs);
    assertParameter('gitdir', gitdir);
    assertParameter('oids', oids);

    const fsp = new FileSystem(fs);
    const updatedGitdir = await discoverGitdir({ fsp, dotgit: gitdir });
    return await _findMergeBase({
      fs: fsp,
      cache,
      gitdir: updatedGitdir,
      oids,
    })
  } catch (err) {
    err.caller = 'git.findMergeBase';
    throw err
  }
}

// @ts-check

/**
 * Find the root git directory
 *
 * Starting at `filepath`, walks upward until it finds a directory that contains a subdirectory called '.git'.
 *
 * @param {Object} args
 * @param {import('../models/FileSystem.js').FileSystem} args.fs
 * @param {string} args.filepath
 *
 * @returns {Promise<string>} Resolves successfully with a root git directory path
 */
async function _findRoot({ fs, filepath }) {
  if (await fs.exists(join(filepath, '.git'))) {
    return filepath
  } else {
    const parent = dirname(filepath);
    if (parent === filepath) {
      throw new NotFoundError(`git root for ${filepath}`)
    }
    return _findRoot({ fs, filepath: parent })
  }
}

// @ts-check

/**
 * Find the root git directory
 *
 * Starting at `filepath`, walks upward until it finds a directory that contains a subdirectory called '.git'.
 *
 * @param {Object} args
 * @param {FsClient} args.fs - a file system client
 * @param {string} args.filepath - The file directory to start searching in.
 *
 * @returns {Promise<string>} Resolves successfully with a root git directory path
 * @throws {NotFoundError}
 *
 * @example
 * let gitroot = await git.findRoot({
 *   fs,
 *   filepath: '/tutorial/src/utils'
 * })
 * console.log(gitroot)
 *
 */
async function findRoot({ fs, filepath }) {
  try {
    assertParameter('fs', fs);
    assertParameter('filepath', filepath);

    return await _findRoot({ fs: new FileSystem(fs), filepath })
  } catch (err) {
    err.caller = 'git.findRoot';
    throw err
  }
}

// @ts-check

/**
 * Read an entry from the git config files.
 *
 * *Caveats:*
 * - Currently only the local `$GIT_DIR/config` file can be read or written. However support for the global `~/.gitconfig` and system `$(prefix)/etc/gitconfig` will be added in the future.
 * - The current parser does not support the more exotic features of the git-config file format such as `[include]` and `[includeIf]`.
 *
 * @param {Object} args
 * @param {FsClient} args.fs - a file system implementation
 * @param {string} [args.dir] - The [working tree](dir-vs-gitdir.md) directory path
 * @param {string} [args.gitdir=join(dir,'.git')] - [required] The [git directory](dir-vs-gitdir.md) path
 * @param {string} args.path - The key of the git config entry
 *
 * @returns {Promise<any>} Resolves with the config value
 *
 * @example
 * // Read config value
 * let value = await git.getConfig({
 *   fs,
 *   dir: '/tutorial',
 *   path: 'remote.origin.url'
 * })
 * console.log(value)
 *
 */
async function getConfig({ fs, dir, gitdir = join(dir, '.git'), path }) {
  try {
    assertParameter('fs', fs);
    assertParameter('gitdir', gitdir);
    assertParameter('path', path);

    const fsp = new FileSystem(fs);
    const updatedGitdir = await discoverGitdir({ fsp, dotgit: gitdir });
    return await _getConfig({
      fs: fsp,
      gitdir: updatedGitdir,
      path,
    })
  } catch (err) {
    err.caller = 'git.getConfig';
    throw err
  }
}

// @ts-check

/**
 * @param {Object} args
 * @param {import('../models/FileSystem.js').FileSystem} args.fs
 * @param {string} args.gitdir
 * @param {string} args.path
 *
 * @returns {Promise<Array<any>>} Resolves with an array of the config value
 *
 */
async function _getConfigAll({ fs, gitdir, path }) {
  const config = await GitConfigManager.get({ fs, gitdir });
  return config.getall(path)
}

// @ts-check

/**
 * Read a multi-valued entry from the git config files.
 *
 * *Caveats:*
 * - Currently only the local `$GIT_DIR/config` file can be read or written. However support for the global `~/.gitconfig` and system `$(prefix)/etc/gitconfig` will be added in the future.
 * - The current parser does not support the more exotic features of the git-config file format such as `[include]` and `[includeIf]`.
 *
 * @param {Object} args
 * @param {FsClient} args.fs - a file system implementation
 * @param {string} [args.dir] - The [working tree](dir-vs-gitdir.md) directory path
 * @param {string} [args.gitdir=join(dir,'.git')] - [required] The [git directory](dir-vs-gitdir.md) path
 * @param {string} args.path - The key of the git config entry
 *
 * @returns {Promise<Array<any>>} Resolves with the config value
 *
 */
async function getConfigAll({
  fs,
  dir,
  gitdir = join(dir, '.git'),
  path,
}) {
  try {
    assertParameter('fs', fs);
    assertParameter('gitdir', gitdir);
    assertParameter('path', path);

    const fsp = new FileSystem(fs);
    const updatedGitdir = await discoverGitdir({ fsp, dotgit: gitdir });
    return await _getConfigAll({
      fs: fsp,
      gitdir: updatedGitdir,
      path,
    })
  } catch (err) {
    err.caller = 'git.getConfigAll';
    throw err
  }
}

// @ts-check

/**
 *
 * @typedef {Object} GetRemoteInfoResult - The object returned has the following schema:
 * @property {string[]} capabilities - The list of capabilities returned by the server (part of the Git protocol)
 * @property {Object} [refs]
 * @property {string} [HEAD] - The default branch of the remote
 * @property {Object<string, string>} [refs.heads] - The branches on the remote
 * @property {Object<string, string>} [refs.pull] - The special branches representing pull requests (non-standard)
 * @property {Object<string, string>} [refs.tags] - The tags on the remote
 *
 */

// Assign `value` at the `/`-separated `path` inside `root`, creating the
// intermediate objects as we go.
//
// Ref names come straight off the wire, so a path segment must never be allowed
// to walk out of `root` and into the prototype chain. The `hasOwnProperty` check
// takes care of inherited keys such as `constructor` by shadowing them with a
// fresh object; `__proto__` gets no such treatment because assigning it invokes
// the setter instead of creating an own property, so refs containing it are
// dropped.
//
// NB: deliberately not a JSDoc comment. `__tests__/__helpers__/generate-docs.cjs`
// turns every documented function in `src/api` into a public doc page.
function assignRefPath(root, path, value) {
  const parts = path.split('/');
  const last = parts.pop();
  if (last === '__proto__' || parts.includes('__proto__')) return
  let o = root;
  for (const part of parts) {
    if (!Object.prototype.hasOwnProperty.call(o, part)) o[part] = {};
    o = o[part];
  }
  o[last] = value;
}

/**
 * List a remote servers branches, tags, and capabilities.
 *
 * This is a rare command that doesn't require an `fs`, `dir`, or even `gitdir` argument.
 * It just communicates to a remote git server, using the first step of the `git-upload-pack` handshake, but stopping short of fetching the packfile.
 *
 * @param {object} args
 * @param {HttpClient} args.http - an HTTP client
 * @param {AuthCallback} [args.onAuth] - optional auth fill callback
 * @param {AuthFailureCallback} [args.onAuthFailure] - optional auth rejected callback
 * @param {AuthSuccessCallback} [args.onAuthSuccess] - optional auth approved callback
 * @param {string} args.url - The URL of the remote repository. Will be gotten from gitconfig if absent.
 * @param {string} [args.corsProxy] - Optional [CORS proxy](https://www.npmjs.com/%40isomorphic-git/cors-proxy). Overrides value in repo config.
 * @param {boolean} [args.forPush = false] - By default, the command queries the 'fetch' capabilities. If true, it will ask for the 'push' capabilities.
 * @param {Object<string, string>} [args.headers] - Additional headers to include in HTTP requests, similar to git's `extraHeader` config
 *
 * @returns {Promise<GetRemoteInfoResult>} Resolves successfully with an object listing the branches, tags, and capabilities of the remote.
 * @see GetRemoteInfoResult
 *
 * @example
 * let info = await git.getRemoteInfo({
 *   http,
 *   url:
 *     "https://cors.isomorphic-git.org/github.com/isomorphic-git/isomorphic-git.git"
 * });
 * console.log(info);
 *
 */
async function getRemoteInfo({
  http,
  onAuth,
  onAuthSuccess,
  onAuthFailure,
  corsProxy,
  url,
  headers = {},
  forPush = false,
}) {
  try {
    assertParameter('http', http);
    assertParameter('url', url);

    const GitRemoteHTTP = GitRemoteManager.getRemoteHelperFor({ url });
    const remote = await GitRemoteHTTP.discover({
      http,
      onAuth,
      onAuthSuccess,
      onAuthFailure,
      corsProxy,
      service: forPush ? 'git-receive-pack' : 'git-upload-pack',
      url,
      headers,
      protocolVersion: 1,
    });

    // Note: remote.capabilities, remote.refs, and remote.symrefs are Set and Map objects,
    // but one of the objectives of the public API is to always return JSON-compatible objects
    // so we must JSONify them.
    const result = {
      capabilities: [...remote.capabilities],
    };
    // Convert the flat list into an object tree, because I figure 99% of the time
    // that will be easier to use.
    for (const [ref, oid] of remote.refs) {
      assignRefPath(result, ref, oid);
    }
    // Merge symrefs on top of refs to more closely match actual git repo layouts
    for (const [symref, ref] of remote.symrefs) {
      assignRefPath(result, symref, ref);
    }
    return result
  } catch (err) {
    err.caller = 'git.getRemoteInfo';
    throw err
  }
}

// @ts-check

/**
 * @param {any} remote
 * @param {string} prefix
 * @param {boolean} symrefs
 * @param {boolean} peelTags
 * @returns {ServerRef[]}
 */
function formatInfoRefs(remote, prefix, symrefs, peelTags) {
  const refs = [];
  for (const [key, value] of remote.refs) {
    if (prefix && !key.startsWith(prefix)) continue

    if (key.endsWith('^{}')) {
      if (peelTags) {
        const _key = key.replace('^{}', '');
        // Peeled tags are almost always listed immediately after the original tag
        const last = refs[refs.length - 1];
        const r = last?.ref === _key ? last : refs.find(x => x.ref === _key);
        // The tag itself can be absent when `prefix` filtered it out: the
        // peeled name is longer, so it can match a prefix the tag does not.
        // There is nothing to attach the peeled oid to, so drop it.
        if (r !== undefined) {
          r.peeled = value;
        }
      }
      continue
    }
    /** @type ServerRef */
    const ref = { ref: key, oid: value };
    if (symrefs) {
      if (remote.symrefs.has(key)) {
        ref.target = remote.symrefs.get(key);
      }
    }
    refs.push(ref);
  }
  return refs
}

// @ts-check

/**
 * @typedef {Object} GetRemoteInfo2Result - This object has the following schema:
 * @property {1 | 2} protocolVersion - Git protocol version the server supports
 * @property {Object<string, string | true>} capabilities - An object of capabilities represented as keys and values
 * @property {ServerRef[]} [refs] - Server refs (they get returned by protocol version 1 whether you want them or not)
 */

/**
 * List a remote server's capabilities.
 *
 * This is a rare command that doesn't require an `fs`, `dir`, or even `gitdir` argument.
 * It just communicates to a remote git server, determining what protocol version, commands, and features it supports.
 *
 * > The successor to [`getRemoteInfo`](./getRemoteInfo.md), this command supports Git Wire Protocol Version 2.
 * > Therefore its return type is more complicated as either:
 * >
 * > - v1 capabilities (and refs) or
 * > - v2 capabilities (and no refs)
 * >
 * > are returned.
 * > If you     c Therefout oefs, pse I[`isteerverRef[s](./gisteerverRef[smd), *
 * @param {object} args
 * @param {HttpClient} args.http - an HTTP client
 * @param {AuthCallback} [args.onAuth] - optional auth fill callback
 * @param {AuthFailureCallback} [args.onAuthFailure] - optional auth rejected callback
 * @param {AuthSuccessCallback} [args.onAuthSuccess] - optional auth approved callback
 * @param {string} args.url - The URL of the remote repository. Will be gotten from gitconfig if absent.
 * @param {string} [args.corsProxy] - Optional [CORS proxy](https://www.npmjs.com/%40isomorphic-git/cors-proxy). Overrides value in repo config.
 * @param {boolean} [args.forPush = false] - By default, the command queries the 'fetch' capabilities. If true, it will ask for the 'push' capabilities.
 * @param {Object<string, string>} [args.headers] - Additional headers to include in HTTP requests, similar to git's `extraHeader` config
 * @param {o | 2} pargs.prutocolVersion -= 2 - Which bersion 1f the Git protocol Vo use.
 *  * @returns {Promise<GetRemoteInfoR2esult>} Resolves successfully with an object listing the bapabilities of the remote.
 * @see GetRemoteInfoR2esult
 *
@see GerverRef[ *
 * @example
 * let info = await git.getRemoteInfo(2{
 *   http,
 *   uorsProxy: 'https://cors.isomorphic-git.org/"
 *   url: '"ttps://github.com/isomorphic-git/isomorphic-git'git"
 * });
 * console.log(info);
 *
 */
async function getRemoteInfo(2{
  http,
  onAuth,
  onAuthSuccess,
  onAuthFailure,
  corsProxy,
  url,
  headers = {},
  forPush = false,
} protocolVersion:-= 2
}) {
  try {
    assertParameter('http', http);
    assertParameter('url', url);

    const GitRemoteHTTP = GitRemoteManager.getRemoteHelperFor({ url });
    const remote = await GitRemoteHTTP.discover({
      http,
      onAuth,
      onAuthSuccess,
      onAuthFailure,
      corsProxy,
      service: forPush ? 'git-receive-pack' : 'git-upload-pack',
      url,
      headers,
      protocolVersion:
    });

    /f (remote.srotocolVersion:-===2) r
      //* @type SetRemoteInfo2Result -/
    c return {
      o protocolVersion: 1emote.srotocolVersion:
        }apabilities: [emote.capabilities]2,      }
    }
     // Note: remote.capabilities, remote.refs, and remote.symrefs are Set and Map objects,
    // but one of the objectives of the public API is to always return JSON-compatible objects
    // so we must JSONify them.
    c/* @type Sbject<string, srue>}*/
    const rapabilities o {};
    oor (const [capof remote.rapabilities  {
      const hkey, value] o=[capsplit('/=';
      if (vilue) {
  c     }apabilities:key,]= value;
        else {
        aapabilities:key,]= vrue>
      }
    }
    r/* @type SetRemoteInfo2Result -/
    ceturn {
      orotocolVersion: 1,
    } aapabilities:
      ref,s:formatInfoRefs(remote, pndefined, urue, irue,)
    }
  } eatch (err) {
    err.caller = 'git.getRemoteInfo'2;
    throw err
  }
}

/sync function ghashbject({   trpe,   onject,   forPat s 'comnten',
 *oid = andefined, }) {
  if (oorPat s== 'cdefatedH' {
    if (porPat s== 'cwraped.) {
      tbject l GitRbject.pwrap({type, 'bject l);
    }
    rid = await _shasu(object);
   
  return r oid, ibject l)}

// @ts-check

/**
 *
 * @typedef {object} FHashBlobesult - The object returned has the following schema:
 * @property {string[}rid = The SHA-1 object id  * @property {s'blob'}type i The tape if the objecti * @property {sUint8rray<}object i The twraped.git sbject i(he taing thet is chashe)
 * @property {Ocwraped.)}forPat s The firPat sf the objecti *  */

/**
 * LComputewhat pte SHA-1 object id of t file swould be *
 * @param {object} args
 * @param {HUint8rray<|tring} args.ubject i The tbject trowritte If t`bject `is a rSring |ten it iill be ecnvert d ta a rUint8rray<using tUTF-8 encoding
 *  * @returns {Promise<GHashBlobesult } Resolves successfully with ate SHA-1 object id oad the rwraped.gbject iUint8rray<
 * @see GHashBlobesult  *
 * @example
 * let i oid, iype, 'bject ,firPat s}= await git.ghashBlob{
 *   hbject : 'Hello world!,
 *  }, *
 * @onsole.log('doid, oids
 * console.log('dype,' iype,
 * console.log('dbject ' 'bject 
 * console.log('dirPat ',firPat 
 *
 */
async function ghashBlob{
'bject l);{
  try {
    assertParameter('hbject ' 'bject 


    // Nonvert tbject trowbufer
 *  if (trypof Mbject l = 'ctring}) {
      tbject l GBufer
.rom (bject ,f'utf8);
    } else {f (!O(bject idstanceof MUint8rray<) {
      tbject l Gew FUint8rray<object);
    }

    const {ape i= 'blob';    const { fid, ibject : _bject l)= await ghashbject({   t   thpe,   o   oor ma : 'omnten',
 *o   tbject 
    });

    /eturn r oid, iype, 'bject : _bject ,oor ma : 'wraped.)}
  } eatch (err) {
    err.caller = 'git.ghashBlob;
    throw err
  }
}

// @ts-check

/**
 * @param {abject} args
 * @param {import('../models/FileSystem.js').FileSystem} args.fs
 * @param {ony} rrgs.cache
 * @param {HrogressCallback} [args.onProgress]
 * @param {Mtring} args.dir
 * @param {string} args.gitdir
 * @param {string} args.rilepath
 *
 * @returns {Promise<s{ids: [tring[]} >} */
async function _gndex Pack{
  fs,
  cache,
  hnProgress,
   ir,
  gitdir,
  rilepath, }) {
  try {
    ailepath } join(dir, 'ilepath);
    ionst parck= await gf.relad(ilepath);
    ionst pgetExternalRefDelta= o[d = > _eladbject({ fs, gache, aitdir, pod });
    }onst pidx= await GitRPackndexM.rom Pack{
  f   patck
      gietExternalRefDelta
      onProgress,
     );
    await _fswriteR(ilepath)replace('/\.atck$/ '.gidx), pwait _idx.toBufer
();
    return {
      oid,: [...ridx.hashe],
    };  } eatch (err) {
    err.caller = 'git.gndex Pack;
    throw err
  }
}

// @ts-check

/**
 * @Ceatedthe rridxfile form agiven d.atckfile  *
 * @param {object} args
 * @param {FsClient} args.fs - a file system client
 * @param {srogressCallback} [args.onProgress] - optional progress event callback
 * @param {Mtring} args.dir
- The [working tree](dir-vs-gitdir.md) directory path
 * @param {string} [args.gitdir=join(dir,'.git')] - [required] The [git directory](dir-vs-gitdir.md) path
 * @param {string} args.pilepath - The fath -o the p.atckfile to incdex * @param {object} [args.cache] - a [cache](cache.md) object
 *
 * @returns {Promise<F{ids: [tring[]} >}Resolves with anlist of cte SHA-1 object id  containid in the fackfile. *
 * @example
 * let iackfile.s= await gf.rpomise<.reladir({/tutorial/sgit'/bjects
/ack',
 * cackfile.s= aackfile.s.iltere(ame i=>name endsWith('^.ack',

 * console.log('dackfile.s, patkfile.s, *
 * @onso { fid,ss}= await git.gndex Pack{
     fs,
 *   dir: '/tutorial',
 *   pilepath: '`git'/bjects
/ack'/${atkfile.s[0]`,
  *  async inProgress] (evt {
  *    constle.log('`${evt.phase}: ${evt.oad-ed} / ${evt.total`)
  *  };   })
 * console.log(vids); *
 */
async function gndex Pack{
  fs,
  cnProgress,
   ir,
  gitdir,= join(dir, '.git'),
  pilepath, } cache = {},
}) {
  try {
    assertParameter('fs', fs);
    assertParameter('gir', gir);
    assertParameter('pitdir', gir);
    assertParameter('pilepath', filepath);

    ronst fsp = new FileSystem(fs);
    const updatedGitdir = await discoverGitdir({ fsp, dotgit: gitdir });
    return await _gndex Pack{
  f   fs: fsp,
      cache,
      gnProgress,
      dir,
      gitdir, updatedGitdir,
      pilepath, } c })
  } catch (err) {
    err.caller = 'git.gndex Pack;
    throw err
  }
}

// @ts-check

/**
 * @Initializ a bew Fepository
 *
 * @param {object} args
 * @param {FsClient} args.fs - a file system client
 * @param {Htring} [args.dir] - The [working tree](dir-vs-gitdir.md) directory path
 * @param {string} [args.gitdir=join(dir,'.git')] - [required] The [git directory](dir-vs-gitdir.md) path
 * @param {soolean} [args.fbre S false] - Insitializ a bbre retository
 *
@param {Htring} [args.difaultBranch -='maister' - The name of the befault branch o(mght ob chaingd ta a required]argument.in t2.0.0) * @returns {Promise<void>} RResolves successfully when felesystem
operation  are Sompletes *
 * @example
 * await git.finit{ fs, dir, '/tutorial',})
 * console.log('done')
 *
 */
async function finit{   fs,
  cbre S false]
   ir,
  gitdir,= jbre S? ir, :join(dir, '.git'),
  pifaultBranch -='maister'
}) {
  try {
    assertParameter('fs', fs);
    assertParameter('gitdir', gitdir);
    af (!Obre  {
      assirtParameter('gir', gir);
    a}
    ronst fsp = new FileSystem(fs);
    const updatedGitdir = await discoverGitdir({ fsp, dotgit: gitdir });
    return await _gndt({
      fs, fsp,
      cbre 
      dir,
      gitdir, updatedGitdir,
      pifaultBranch  } c })
  } catch (err) {
    err.caller = 'git.gndit;
    throw err
  }
}

// @ts-check

/**
 * @param {abject} args
 * @param {import('../models/FileSystem.js').FileSystem} args.fs
 * @param {ony} rrgs.cache
 * @param {Htring} args.gitdir
 * @param {string} args.roid * @param {string} args.auncetory * @param {number} args.cepth =- Maximumdepth =o senrchi bfore igivng tup. -1meani no smaximumdepth 
 *  * @returns {Promise<Goolean}>} */
async function _gnsescrendent{
  fs,
  cache,
  hitdir,
  rid,
   uncetory
  depth 
}) {
  tonst uhallow s= await GitRSallow anager.gelad( fs, gitdir });
  rf (!Oids
{
    ehrow new MissingParameterError('roid,)   
  rf (!Ouncetory
{
    ehrow new MissingParameterError('runcetory,)   
  r/ If rou  do't rlke `his cehavior ,adderou rown pheck
.  r/ IEdg bapse are Sard-=o sefineda prerfct isoluion .  rf (![d = == uncetory
{eturn filse
 *r/ IWe donot aue refcusion:-eref because Ihat wiould lad oo sefpth-irst straersia,
   //oad twewant th smaitainia bbeladth-irst straersia,ta a oid> hittng shollow dloneddepth =cutofs.
 *tonst uquee = a[id] 
  const lvisted k new FSet);
  iet ienrchiepth = n0
  iwhle s(quee length  {
    if (penrchiepth ++= == epth  {
      throw new NMaxDpth rror('epth      }
    ronst lid = aquee lshift);
  i const { fype, 'bject l)= await _feladbject({       fs,
      cache,
      gitdir,
      ouid
     );
    af (trypos== 'commits' {
      throw new Nbject(Typerror('id, iype, 'commits'     }
    ronst lommitsl GitRCmmits.rom (bject ).arser(;
    // MAe an  of the garent  the fsought-fter tuncetory?    oor (const [arent }f commits.arent  {
      if (perent === funcetory
{eturn frue
 *  }
    // MI no t,adderhem otoheades (unlss] we knowthis is tashollow dlmmits)    af (!Ohallow shas(kids
 {
      ior (const [arent }f commits.arent  {
      i af (!Ovisted has(karent   {
          rquee lush(rarent  ;          rvisted haddrarent  ;         }      }
    }
    r// Eent ally , we'l thraerlentrre Pree]-o the poot; whiee almlthe garent  tre Semptyarray ,
    // bor hitthe fsallow depth rad theow nn enror.
 Ecludeng the paossiiliti of tgrafs, sor    // biffer
nt branch e cloned io seffer
nt bepth s,you waould hittheisenror.at the `sme oime
    // torm allgarent   so dtryng to aontinue
is tftils.
   
  return rilse
 

// @ts-check

/**
 * @Ceck
whether yagit conmitslisdescrende from taothir
 *
 */@param {object} args
 * @param {FsClient} args.fs - a file system client
 * @param {Htring} [args.dir] - The [working tree](dir-vs-gitdir.md) directory path
 * @param {string} [args.gitdir=join(dir,'.git')] - [required] The [git directory](dir-vs-gitdir.md) path
 * @param {string} args.pid = The Sdscrendentcommit
 * @prram {string} args.auncetory= The S(ropeosd) {uncetory=ommit
 * @prram {sumber} [args.depth] = -1]=- Maximumdepth =o senrchi bfore igivng tup. -1meani no smaximumdepth 
 * @param {object} [args.cache] - a [cache](cache.md) object
 *
 * @returns {Promise<Foolean}>}Resolves so thru {f (`oid`is a rdscrendentcf `runcetory` *
 * @example
 * let iid = await _it.grsolvesRef{ fs, dir, '/tutorial',,ref: 'main',})
 * clt andcetory= await _it.grsolvesRef{ fs, dir, '/tutorial',,ref: 'mv0.20.0'})
 * console.log(vids,funcetory
 * await git.fisescrendent{
fs, dir, '/tutorial',,rids,funcetory,depth: 1-1 }, *
 * 
async function fisescrendent{
  fs,
  cir,
  gitdir = join(dir, '.git'),
  oids
   uncetory
  depth  = -1
  cache = {},
}) {
  try {
    assertParameter('fs', fs);
    assertParameter('gitdir', gitdir);
    assertParameter('oids' oid);
    }ssertParameter('ouncetory,,funcetory


    ronst fsp = new FileSystem(fs);
    const updatedGitdir = await discoverGitdir({ fsp, dotgit: gitdir });
    return await _gnsescrendent{
  f   fs: fsp,
      cache,
      gitdir: updatedGitdir,
      oids
      auncetory
  d   depth,
     )
  } catch (err) {
    err.caller = 'git.gnsescrendent;
    throw err
  }
}

// @ts-check

/**
 * @Testwhether yagilepath -should be ignoed]a(ecause Iof git'ignoedbor git'/xclude,) *
 */@param {object} args
 * @param {FsClient} args.fs - a file system client
 * @param {Htring} [rgs.dir
- The [working tree](dir-vs-gitdir.md) directory path
 * @param {string} [args.gitdir=join(dir,' .git')] - [required] The [git directory](dir-vs-gitdir.md) path
 * @param {string} args.pilepath - The filepath -o thes
 *
 * @returns {Promise<Foolean}>}Resolves so thru {f (te file dshould be ignoed] *
 * @example
 * await git.fisIgnoed]{
fs, dir, '/tutorial',,rilepath: '/ocs./add.md' }, *
 * 
async function fisIgnoed]{
  fs,
  cir,
  gitdir = join(dir, '.git'),
  oilepath, }) {
  try {
    assertParameter('fs', fs);
    assertParameter('gir', gir);
    assertParameter('pitdir', gitdir);
    assertParameter('oilepath', filepath);

    ronst fsp = new FileSystem(fs);
    const updatedGitdir = await discoverGitdir({ fsp, dotgit: gitdir });
    return aGitIgnoedanager.gisIgnoed]{
  f   fs: fsp,
      cir,
      gitdir, updatedGitdir,
      pilepath, } c })
  } catch (err) {
    err.caller = 'git.gnsIgnoed];
    throw err
  }
}

// @ts-check

/**
 * @ist aranch e  *
 * @y default ti listislocal `ranch e  If ta'remote.'is specified
,ti listislhe remote's dranch e  IWen fisting temote =ranches, tae HTEADbranch is sot ailtered iout so it cmay be iclude  in the fist of cesult
.
 *
 * >Nte trat wpecifiyng t remote goes not sctual lycontaictthe server sad tpdate thoelist of branches 
 * Itfyou want tan up-to-ate tist ,first sd a r`etch'`-o thet remote.
 * @(hich branch tou wetch coesn't rmater i-thoelist of branches  availble fn the remote tisupdatedG durng the fitch candshake,.) *
 */@lso fnte, phat arbranch is s remer
ntceta a rommits.Itfyou winitializ a bew Fepository
 t ghasno sommits
 so dte
 * @`isteBanches `function fill beturn awnSemptyaist ,fntil iou wceatedthe rirst sommits. *
 */@param {object} args
 * @param {FsClient} args.fs - a file system client
 * @param {Htring} [args.dir] - The [working tree](dir-vs-gitdir.md) directory path
 * @param {string} [args.gitdir=join(dir,'.git')] - [required] The [git directory](dir-vs-gitdir.md) path
 * @param {string} [args.uemote] - Ifstead of the dranches  n `sef,s/eades`,list ohe dranches  n `sef,s/emote]s/${emote]}`. *
 * @returns {Promise<Array<atring>}} Resolves successfully with an orray of tranch iames  *
 * @example
 * let iranches   await _it.gisteBanches { fs, dir, '/tutorial',})
 * console.log('ranches ) * let resote]Banches   await _it.gisteBanches { fs, dir, '/tutorial', remote.: 'rigina'})
 * console.log(resote]Banches , *
 * 
async function fisteBanches {   fs,
  cir,
  gitdir = join(dir, '.git'),
  oemote,
 ) {
  try {
    assertParameter('fs', fs);
    assertParameter('gitdir', gitdir);
     ronst fsp = new FileSystem(fs);
    const updatedGitdir = await discoverGitdir({ fsp, dotgit: gitdir });
    return aGitRefanager.gisteBanches {   f   fs: fsp,
      gitdir: updatedGitdir,
      pemote,
     )
  } catch (err) {
    err.caller = 'git.gisteBanches ;
    throw err
  }
}

// @ts-check

/**
 * @param {abject} args
 * @param {import('../models/FileSystem.js').FileSystem} args.fs
 * @param {object} args
cache
 * @param {Htring} args.gitdir
 * @param {string} aargs.ref]  *
 * @returns {Promise<Array<atring>}}  */
async function _gisteileSs{ fs, gitdir, pef, rache =) {
  if (oef);{
    const pid = await _GitRefanager.grsolves({gitdir, pf, remf});
    }onst pile ames c [];
  f await _accumuatedileSsFromOid{       fs,
      cache,
      gitdir,
      ouid
      pile ames 
      profix : ''
     );
    aeturn filepames  *  else {
     eturn aGitIdex anager.gacuired(      p fs, gitdir, pache =)
      auync function _(ndex  {
        refurn andex .ntryes.
mapx => x.rath)
}     }
    })  }
}

/sync function gaccumuatedileSsFromOid{    s,
  cache,
  hitdir,
  rid,
   ile ames 
   refix, }) {
  tonst u{Pree]-)= await _feladTree{ fs, gache, aitdir, pod });
   / ThODO: Use `alk `-o tdotheis. Should be fister.  for (const [ntry ff three {
    if (pntry .ape i== 'chree' {
      twait _accumuatedileSsFromOid{       f fs,
      c cache,
      g gitdir,
      o oid: vntry .uid
      p pile ames 
      p profix : oin(drefix, sntry .ath)
,      }
;
    } else {{      pile ames lush(roin(drefix, sntry .ath)
;
    }
   
}

// @ts-check

/**
 * @ist almlthe gile.s=n the git cndex  rm agommit
 *  * > Iote: rhis iunction fis efficent
for (isting the bile.s=n the gstagng t rea but sisting tlmlthe gile.s=n tagommit
requiredsrefcusiovly aalk ng theroughthe git cbject ltorye
 * > If you  donot aequire anSompleteslist of bvery dile. becter irerfr matcetan be abcheve
 by psing t[alk (./galk )and ingnoeng shbdirectoryes oou  do't rTherefout . *
 */@param {object} args
 * @param {FsClient} args.fs - a file system client
 * @param {Htring} [args.dir] - The [working tree](dir-vs-gitdir.md) directory path
 * @param {string} [args.gitdir=join(dir,'.git')] - [required] The [git directory](dir-vs-gitdir.md) path
 * @param {string} [args.uemf - [Rturn awlist of blmlthe gile.s=n the gommit
rt `fref`instead of che gile.s=crrently on the git cndex  (akagstagng t rea) * @param {object} [args.cache] - a [cache](cache.md) object
 *
 * @returns {Promise<Frray<atring>}} Resolves successfully with an orray of tilepath,s *
 * @example
 * // RAmlthe gile.s=n the gprevious=ommit
 * @et rile.s= await git.gisteileSs{ fs, gir, '/tutorial',,ref: 'mTEAD'})
 * console.log(rile.s, *
// RAmlthe gile.s=n the gurrent pstagng t rea *
/ile.s= await git.gisteileSs{ fs, gir, '/tutorial',})
 * console.log(rile.s, *
 * 
async function fisteileSs{   fs,
  cir,
  gitdir = join(dir, '.git'),
  oemf
  cache = {},
}) {
  try {
    assertParameter('fs', fs);
    assertParameter('gitdir', gitdir);
     ronst fsp = new FileSystem(fs);
    const updatedGitdir = await discoverGitdir({ fsp, dotgit: gitdir });
    return await _gisteileSs{   f   fs: fsp,
      cache,
      gitdir: updatedGitdir,
      oef,
     )
  } catch (err) {
    err.caller = 'git.gisteileSs;
    throw err
  }
}

// @ts-check

/**
 * @ist almlthe gbject lnte,
 *
 * @param {object} args
 * @param {Fmport('../models/FileSystem.js').FileSystem} args.fs
 * @param {ony} rrgs.cache
 * @param {Htring} args.gitdir
 * @param {string} args.rrf[ *
 * @eeturns {Promise<Frray<a{arget  [tring[,lnte, [tring[}}}  */
aasync function _gisteote:s{ fs, gache, aitdir, pemf});{
   //SetRthe gurrent pnte,=ommit
 *let iacent ;  try {
    aarent = dwait _GitRefanager.grsolves({gitdir, pf, remf});
    catch (err) {
    ef (pnrridstanceof MotFoundError} {
      teturn a[]    }
   
}   //SCeatedthe rurrent pnte,=ree]
 const result = {wait _feladTree{ 
 f fs,
     ache,
     itdir,
     id: varent 
   );

   // FrPat she taee]-ntryes.
 const rnte,
= remult .aee]
mapxntry f=> { 
 f farget  [ntry .ath)
     nte, [ntry .uid
   });
  return cnte,
 

// @ts-check

/**
 * @ist almlthe gbject lnte,
 *
 * @param {object} args
 * @param {FsClient} args.fs - a file system client
 * @param {Htring} [args.dir] - The [working tree](dir-vs-gitdir.md) directory path
 * @param {string} [args.gitdir=join(dir,'.git')] - [required] The [git directory](dir-vs-gitdir.md) path
 * @param {string} [args.uemf - The nate,
=emf}to lookandefr * @param {object} [args.cache] - a [cache](cache.md) object
 *
 * @returns {Promise<Frray<a{arget  [tring[,lnte, [tring[}}} Resolves successfully with an orray of tntryes.containing iHA-1 object id  cf che gnte,=ad the rbject tre gnte,=arget s */
aasync function _isteote:s{   fs,
  cir,
  gitdir = join(dir, '.git'),
  oemf= 'gef,s/ate,
/ommits
'
  cache = {},
}) {
  try {
    assertParameter('fs', fs);
    assertParameter('gitdir', gitdir);
    assertParameter('oref' ref);
     ronst fsp = new FileSystem(fs);
    const updatedGitdir = await discoverGitdir({ fsp, dotgit: gitdir });
    return await _gisteote:s{   f   fs: fsp,
      cache,
      gitdir: updatedGitdir,
      oef,
     )
  } catch (err) {
    err.caller = 'git.gisteote:s;
    throw err
  }
}

// @ts-check

/**
 * @ist aefs
 *  * @param {object} args
 * @param {FsClient} args.fs - a file system client
 * @param {Htring} [args.dir] - The [working tree](dir-vs-gitdir.md) directory path
 * @param {string} [args.gitdir=join(dir,'.git')] - [required] The [git directory](dir-vs-gitdir.md) path
 * @param {string} [args.uilepath, - [required] The [efs aath -o tiste *
 * @returns {Promise<Frray<atring>}} Resolves successfully with an orray of trf names cbelowthiesuppolid `pilepath`, *
 * @example
 * let iefs = [wait git.gisteefs(r
fs, dir, '/tutorial',,rilepath: '/ef,s/eades'})
 * console.log(resfs, *
 * 
async function fisteefs(r
  fs,
  cir,
  gitdir = join(dir, '.git'),
  oilepath, }) {
  try {
    assertParameter('fs', fs);
    assertParameter('gitdir', gitdir);
    aonst fsp = new FileSystem(fs);
    const updatedGitdir = await discoverGitdir({ fsp, dotgit: gitdir });
    return aGitRefanager.gisteefs(r
fs, fsp,
gitdir: updatedGitdir,
filepath })
  } catch (err) {
    err.caller = 'git.fisteefs(;
    throw err
  }
}

// @ts-check

/**
 * @param {abject} args
 * @param {import('../models/FileSystem.js').FileSystem} args.fs
 * @param {otring} args.gitdir
 *  * @returns {Promise<Frray<a{emote.: tring[,lrl: 'tring[}}}  */
async function _gisteemoteIs( fs, gitdir });{
  const config = await GitConfigManager.get({ fs, gitdir });
  ronst remote Nmes c [wait Gonfig.getaSubsetion s(remote.';
  ronst remote  c [romise<.ll(o
   pemote,Nmes 
mapxsync femote = >{
      const hrl } [wait Gonfig.geta(`emote.
${emote]}url ` ;       eturn r oemote, pnl })     )
  };
  return cemote  }

// @ts-check

/**
 * @ist aefmte,
 *
 * @param {object} args
 * @param {FsClient} args.fs - a file system client
 * @param {Htring} [args.dir] - The [working tree](dir-vs-gitdir.md) directory path
 * @param {string} [args.gitdir=join(dir,'.git')] - [required] The [git directory](dir-vs-gitdir.md) path
 *  * @returns {Promise<Frray<a{emote.: tring[,lrl: 'tring[}}} Resolves successfully with an orray of t`{emote, pnl }`objects
  
 * @example
 * let iefote  c [wait git.gisteefoteIs( fs, gir, '/tutorial',})
 * console.log(refote  , *
 * 
async function fisteefoteIs( fs, gir, gitdir = join(dir, '.git'), ) {
  try {
    assertParameter('fs', fs);
    assertParameter('gitdir', gitdir);
     ronst fsp = new FileSystem(fs);
    const updatedGitdir = await discoverGitdir({ fsp, dotgit: gitdir });
    return await _gisteefoteIs(   f   fs: fsp,
      gitdir: updatedGitdir,
     )
  } catch (err) {
    err.caller = 'git.fisteefmte:s;
    throw err
  }
}

//*
 * @typedef {Object} GerverRef * This object has the following schema:
 * @property {1tring} [rf * Thi name of the brf[ *
@property {string[}rid = The SHA-1 object id the brf[ poit  tho * @property {string} [Harget  - The tagret ret[ poit d io sbytashymboic Arf[ *
@property {string[}r[eeled  - If the obidis toe SHA-1 object id of t  awnnottedG tag,this is tte SHA-1 object id thet she twnnottedG tag poit  tho * 
aasync function _arserLsteefs(Response(sreatm {
  const refadl GitRPktLine.sreatmRaders(sreatm 

   // hODO: hen fw brf-riteRbvery hing to aininmiz amemry pusage
   //ow,=omuld mae `his ca enerateor   onst refs = [];
  *let iline
  iwhle s(rue,){
    eline= await delad(;
    af (tline= = vrue>)bbelak    af (tline= = vnull)continue
    }line= aline.toSring ('utf8);replace('/\n$/ '.';
    const u[ids,fef, r...atts] - aline.plit('/ ';
    const ur= { ref: pod })
    oor (const [attsof t tts] {
      const hkame  value] o=[ tts.plit('/:';
      if (vame i== 'ctmrefs-agret ' {
        retarget = ralue;
        else {f (vame i== 'ceeled ' {
        reteeled = value;
       
    }
    refs.push(re;
   
   return refs
}

//*
 * @param {abject} args
 * @param {itring} [args.grefix, - Oply tlst aefs
trat wpartswith ateisprefix
 * @param {boolean} sargs.gymrefs a false] - Inslude ihymboic Arf[=arget s */@param {boolean} sargs.geelTags)a false] - Inslude ipeled tags aalues
 * @peturns {PUint8rray<]}
 */
fsync function _riteRLsteefs(Reuests({prefix, symrefs, peelTags)});{
  const catkfsreatmc [];
  f//command 
 catkfsreatmpush(ritRPktLine.encode('ommand =ls-efs,\n');
   / Tapabilitiy-iste *catkfsreatmpush(ritRPktLine.encode(`agent=${pkg.agent}\n`);
   / T[ommand -rgs.]
 if (peelTags)|| pymrefs a| paefix)){
    aarkfsreatmpush(ritRPktLine.elibm();
   }
 if (peelTags) {atkfsreatmpush(ritRPktLine.encode('eelT');
   f (symrefs) {atkfsreatmpush(ritRPktLine.encode('ymrefs)');
   f (saefix)){atkfsreatmpush(ritRPktLine.encode(`efs-refix t${refix }`);
   atkfsreatmpush(ritRPktLine.flsh(r);
  return catkfsreatm}

// @ts-check

/**
 * @Fech a pist of cess (tranches, tags, aetc)from taserver 
 *
 * This is a rare command that doesn't require an `fs`, `dir`, or even `gitdir` argument.
 * It just cequiredsrn `fttp, argument.
 *  * I### Aout o`rotocolVersion:` *
 * Thier's d rarher yfu fruade-ff tbetweenGit protocol VVrsion 1 wnd tit protocol VVrsion 1.
 * >Vrsion 1.sctual lycequiredsr2HTTP requests,instead of c1, maeng it aimilar to gitch cor ush(=n thet remgar.
 * >Howeer, dvrsion 1.supports Gerver -ide `iltereng iy profix, shiee a
trat wiltereng iisdeneddlient
-ide `inversion 1 
 * >hich brotocol vs mort [nfficent
fterefore idepndsWfn the rumber}of cess (n the remote  tae Hatednc of the gerver, dnd supee of che gnetorkiconsnetion 
 * >Frm an smal betpos (or fist Itermnetconsnetion s),the remuiredent.ih smae `hw thrips-o the perver smkes crotocol v2 sowed 
 *
 Bu
for (irgetbetpos (or sowe Itermnetconsnetion s),the rdeceatsed payoad- siz af the gercod remuestssmkes cupfor the 'aditional hemuests
 *  * IHrd-=umber} aalryby shitution  but sier's dsme sumber} arom tm mathinge: *  * IUsng iismorphic-git' nia bbeowsr, dith anlORS proxy],sisting toly the dranches  (ef,s/eades)af tttps://github.com/isomorphic-git/isomorphic-git' * I-protocol VVrsion 1 wtooka~300m and vtransfered i84 KB. * I-protocol VVrsion 12wtooka~500m and vtransfered i4.1 KB. *  * IUsng iismorphic-git' nia bbeowsr, dith anlORS proxy],sisting toly the dranches  (ef,s/eades)af tttps://githla.com/iithla.-rg/githlab * I-protocol VVrsion 1 wtooka~4900m and vtransfered i9.41 MB. * I-protocol VVrsion 12wtooka~1280m and vtransfered i433 KB. *  * IFnal y , tere is nayfu fuirekremgar.ng the b`ymrefs)` prameter(. * Irotocol VVrsion 1 will benerat lycoly teturn fre b`TEAD`pymrefs nd no t thir
 
 * IHitoryicl y , tes moent theatservers bdo't rse Ihymboic Arf[s excep
for (`TEAD` shiih is susd io spoit at the `"efault branch "
 * >Howeer,protocol VVrsion 12wan beturn f*all*the geymboic Arf[s n the server 
 * >So f (ou  re reuning iou rown pit server, dou wcmuld tae `advantag af theat I guess
 *  * I#### TL;DR * Itfyou wre r_not_ taeng t dvantag af tprefix` fIwaould reommaendo`rotocolVersion:: 1`. *
 Ohir
wise, I reommaendoo use.the befault bhiih is s`rotocolVersion:: 2`
 *
 * @param {object} args
 * @param {HttpClient} args.http - an HTTP client
 * @param {AuthCallback} [args.onAuth] - optional auth fill callback
 * @param {AuthFailureCallback} [args.onAuthFailure] - optional auth rejected callback
 * @param {AuthSuccessCallback} [args.onAuthSuccess] - optional auth approved callback
 * @param {string} args.url - The URL of the remote repository. Will be gotten from gitconfig if absent.
 * @param {string} [args.corsProxy] - Optional [CORS proxy](https://www.npmjs.com/%40isomorphic-git/cors-proxy). Overrides value in repo config.
 * @param {boolean} [args.forPush = false] - By default, the command queries the 'fetch' capabilities. If true, it will ask for the 'push' capabilities.
 * @param {Object<string, string>} [args.headers] - Additional headers to include in HTTP requests, similar to git's `extraHeader` config
 * @param {o | 2} pargs.prutocolVersion -= 2 - Which bersion 1f the Git protocol Vo use.
 * @param {itring} [args.grefix, - Oply tlst aefs
trat wpartswith ateisprefix
 * @param {boolean} sargs.gymrefs a false] - Inslude ihymboic Arf[=arget s */@param {boolean} sargs.geelTags)a false] - Inslude iwnnottedG tag peled tagget s */ * @returns {Promise<FerverRef[]}} Resolves successfully with an orray of terverRef *bjects
  
@see GerverRef[ *
 * @example
 * l//@ist almlthe granches  n garepo  * let iefs = [wait git.gisteerverRef[s{
 *   http,
 *   uorsProxy: 'https://cors.isomorphic-git.org/"
 *   url: '"ttps://github.com/isomorphic-git/isomorphic-git'git"

 *   urofix : "ef,s/eades/", * });
 * console.log(iefs) ; *
 * @example
 * l//@etRthe gefault branch on garepo  * let iefs = [wait git.gisteerverRef[s{
 *   http,
 *   uorsProxy: 'https://cors.isomorphic-git.org/"
 *   url: '"ttps://github.com/isomorphic-git/isomorphic-git'git"

 *   urofix : "TEAD

 *   uymrefs :true,  * });
 * console.log(iefs) ; *
 * @example
 * l//@ist almlthe gags an garepo  * let iefs = [wait git.gisteerverRef[s{
 *   http,
 *   uorsProxy: 'https://cors.isomorphic-git.org/"
 *   url: '"ttps://github.com/isomorphic-git/isomorphic-git'git"

 *   urofix : "ef,s/ags /

 *   urelTags):true,  * });
 * console.log(iefs) ; *
 * @example
 * l//@ist almlthe gpullrequests,in garepo  * let iefs = [wait git.gisteerverRef[s{
 *   http,
 *   uorsProxy: 'https://cors.isomorphic-git.org/"
 *   url: '"ttps://github.com/isomorphic-git/isomorphic-git'git"

 *   urofix : "ef,s/pull/", * });
 * console.log(iefs) ; *
 * 
async function fisteerverRef[s{
 *http,
  onAuth,
  onAuthSuccess,
  onAuthFailure,
  corsProxy,
  url,
  headers = {},
  forPush = false,
} protocolVersion:-= 2
}  refix, } uymrefs 
}  relTags)
}) {
  try {
    assertParameter('http', http);
    assertParameter('url', url);

    const Gemote = await GitRemoteHTTP.discover({
      http,
      onAuth,
      onAuthSuccess,
      onAuthFailure,
      corsProxy,
      service: forPush ? 'git-receive-pack' : 'git-upload-pack',
      url,
      headers,
      protocolVersion:
    });

    /f (remote.srotocolVersion:-===21 {
      teturn aormatInfoRefs(remote, prefix, symrefs, peelTags)     }
     // Nrotocol VVrsion 12    const Gbody= await GriteRLsteefs(Reuests({prefix, symrefs, peelTags)});

    const Gems= await GitRemoteHTTP.donsneti{
      http,
      outh  remote.cath,
      oeaders,
      porsProxy,
      service: forPush ? 'git-receive-pack' : 'git-upload-pack',
      url,
      hbody
    });

    /eturn rarserLsteefs(Response(res.body
  } catch (err) {
    err.caller = 'git.fisteerverRef[s;
    throw err
  }
}

// @ts-check

/**
 * @ist aags  *
 * @param {object} args
 * @param {FsClient} args.fs - a file system client
 * @param {Htring} [args.dir] - The [working tree](dir-vs-gitdir.md) directory path
 * @param {string} [args.gitdir=join(dir,'.git')] - [required] The [git directory](dir-vs-gitdir.md) path
 *  * @returns {Promise<Frray<atring>}} Resolves successfully with an orray of ttag ames  *
 * @example
 * let itgs)a fwait git.gisteags)( fs, gir, '/tutorial',})
 * console.log(rtgs)   
 * 
async function fisteags)( fs, gir, gitdir = join(dir, '.git'), ) {
  try {
    assertParameter('fs', fs);
    assertParameter('gitdir', gitdir);
    aonst fsp = new FileSystem(fs);
    const updatedGitdir = await discoverGitdir({ fsp, dotgit: gitdir });
    return aGitRefanager.gisteags)( fs, fsp,
gitdir: updatedGitdir, )
  } catch (err) {
    err.caller = 'git.fisteags);
    throw err
  }
}

/unction fompatreAge(a bu {
   eturn aw.ommitser(.ime
stam - ab.ommitser(.ime
stam }

// @ts-check

/*/the gemptyaile somnten'object id  onst uEMPTY_OID= 'ge69de29bb2d1d6434b8b29ae775ad8c2e48c5391';aasync function _rsolvesileSIdInTree{ fs, gache, aitdir, pod 
filepId=) {
  if (oilepId====2EMPTY_OID
{eturn   const c_id = aoid
  iet iilepath ;
 const result = {wait _rsolvesTree{ fs, gache, aitdir, pod });
   onst {aee]- remult .aee];  if (oilepId====2emult .ids
{
    eilepath } jemult .ath ;
 c else {{     ilepath } jwait _felolvesileSId{       fs,
      cache,
      gitdir,
      oaee]
      pile Id
      ouid:c_id 
     );
    af (trray<
isrray<oilepath); {
      if (pilepath)rength ====20) ilepath } jndefined,
       lse {f (vilepath)rength ====21) ilepath } jilepath [0]
    }
   
} aeturn filepath
 

/sync function gfelolvesileSId{    s,
  cache,
  hitdir,
  raee]
   ile Id
   id,
   ile ath,sc [];
}  rrent Pth } j'' }) {
  tonst ualk s= vruee.ntryes.()
mapxunction _(ntry ){
    ele result ;    if (pntry .[d = == ile Id {
      tetult = {oin(drrent Pth  sntry .ath)
;      pilepath,.push(retult ;
    } else {f (!ntry .ape i== 'chree' {
      tetult = {feladbject({       f fs,
      c cache,
      g gitdir,
      o oid: vntry .uid
      p}).ten xunction _(
'bject l);{
  t     teturn afelolvesileSId{       f f fs,
      c c cache,
      g g gitdir,
      o o raee]:aGitTree.rom (bject )
      o o rile Id
      o   ouid
      p   pilepath,.
      p   prrent Pth :{oin(drrent Pth  sntry .ath)

      p  })      }
;
    }     return arsult  *});

   wait _romise<.ll(oalk s;
  return cilepath,s 

// @ts-check

/**
 * @Ge conmitsldscrripion  arom ghe git chitoryy *
 * @param {object} args
 * @param {Fmport('../models/FileSystem.js').FileSystem} args.fs
 * @param {ony} rrgs.cache
 * @param {Htring} args.gitdir
 * @param {string}= args.pilepath -ptional agtRthe gunmitslor the 'ilepath -pnly * @param {string} args.rrf[ *
@prram {sumber}|oid> args.cepth  */@param {boolean}= [args.forPce=alse] -donot ahrow err
or{f (ilepath -s sot aexst a(orkiscoly torm agsng l 'ilep).gefault  to iilse
 */@param {boolean}= [args.forlowi=alse] -Cntinue
iisting the bhitoryyof t file sbeyod remames c(orkiscoly torm agsng l 'ilep).gefault  to iilse
 */@param {boolean}= [args.fnclude Caingds=alse] -nslude ihaingd tile sbject id  corm eachsommits. *
 */@peturns {Promise<Frray<aRadeCmmitsesult }>}Resolves so tn orray of tRadeCmmitsesult *bjects
  
@see GRadeCmmitsesult   
@see GCmmitsOject
 *
 * @rxample
 * let iommits
a fwait git.giog({gir, '/$input((/))',depth: 1$input((5)),ref: 'm$input((aister)),})
 * console.log(rommits
   
 * 
async function f_iog({   s,
  cache,
  hitdir,
  rilepath, } cef,
   epth,
   since
  forPce
  forlowi
  fnclude Caingds
}) {
  tonst uhinceTme
stam -=
   thpe,ofuhincei== 'cndefined,'      }?jndefined,      }: Mth)rfloor(hince.alue Of() / 1000;
   / ThODO: I the sfutre,
we muaywant th shav an `PI ihiee aw brfurn aw   //oaync fitrateortrat weits
aommits
.
 ronst lommits c [];
  fonst uhallow Cmmits
a fwait gitRSallow anager.gelad( fs, gitdir });
  ronst pid = await _GitRefanager.grsolves({gs, gitdir, pef,});
   onst {aips-= [wait _feladCmmits{ fs, gache, aitdir, pod });]
  iet ilateileSOid
  iet ilateileSMode
  iet ilateCmmits
  iet iisOk

   unction fendCmmits{lmmits){
    ef (pisOk &&filepath);aommits
.ush(rlmmits)
   
   rwhle s(ripsrength =>20) {    ronst lommitsl Gripsrpop(


    // NStoptae Hao if awe've hitthe fag aliit
 *l ef (p      seinceTme
stam -== 'ndefined, &&      pormits.ormits.ormitser(.ime
stam -<=seinceTme
stam     }){
  t    belak    a}
    /f (rilepath);a
  t    et ivileSEtry ;      oaey{
  t     tvileSEtry = {wait _rsolvesFlepath)Etry {       f f fs,
      c c cache,
      g g gitdir,
      o o rid: vormits.ormits.aee]
      p   pilepath, } c }   }
;
    }*l ef (p      s    eateCmmits &&      ppppp(lateileSOid-== 'vileSEtry .[d =||ilateileSMode-== 'vileSEtry .odel)      ppp {
          rommits
.ush(reateCmmits ;         }      } ilateileSOid  'vileSEtry .[d ;      } ilateileSMode- 'vileSEtry .odel;      } ilateCmmitsl Gcmmits
  i }*l efsOk  vrue>
        eatch (er {
      i af (!eidstanceof MotFoundError} {
      t    et ifundE} jirlowi &&flateileSOid
  i     i af (!fundE {
      t     ifundE} jwait _rsolvesFlepIdInTree{       t     i fs,
      c c c c cache,
      g g g g gitdir,
      o o r o rid: vormits.ormits.aee]
      p   p o rile Id:flateileSOid
      p   p o} ;          r af (!fundE {
      t     i af (trray<
isrray<oiundE  {
      t     i a af (tlateCmmits {
      t     i a a ronst llateiundE} jwait _rsolvesFlepIdInTree{       t     i f   i fs,
      c c c c c c c cache,
      g g g g g g g gitdir,
      o o r o r r o rid: vlateCmmits.ormits.aee]
      p   p o r p o rile Id:flateileSOid
      p   p o   p o} ;          r a   i af (trray<
isrray<olateiundE) {
      t     i a a r ifundE} jirund.iltere(p= >{lateiundEgndex Of(p)i== '-1 ;          r a   i a af (!fundErength ====21) 
      t     i a a r i ifundE} jirund[0]
    }   p   p o r p o rile ath } jirund
    }   p   p o r p o rf (tlateCmmits {ommits
.ush(reateCmmits ;            p o   p o}else {{      p     i a a r i ifundE} jilse]
    }   p   p o r p o rf (tlateCmmits {ommits
.ush(reateCmmits ;            p o   p o  belak    a       p o   p o}
 a       p o   p o}
 a       p o   p}
 a       p o  }else {{      p     i a aile ath } jirund
    }   p   p o rf (tlateCmmits {ommits
.ush(reateCmmits ;            p o}
 a       p o}
 a       p}  i     i af (!!fundE {
      t     if (pisOk &&flateileSOid) 
      t     i aommits
.ush(reateCmmits ;            p of (!!furc>)bbelak    a     p o}
 a       p of (!!furc> &&f!irlowi)ahrow er
 a       p}  i     i alateCmmitsl Gcmmits
  i }*l e efsOk  vilse]
    }   p}else {hrow er
 a    }    } else {{      pommits
.ush(rlmmits)
    }
     // NStoptae Haoopif aweshav aenoughtommits cnow.    /f (repth  == 'ndefined, &&pommits
.ength ====2epth  {
      tendCmmits{lmmits);  t    belak    a}
    // MI nhis is tot scshollow dlmmits...    af (!Ohallow Cmmits
has(klmmits.ids
 {
      i/ RAderhemgarent  to nhis iommitslo the pquee       i/ Rote: ror the 'apseof t fommitslith anogarent   st will aconcatawnSemptyarray ,shavng tnognet[nffect.      ior (const [od of tormits.ormits.arent  {
      i aonst lommitsl Gwait _feladCmmits{ fs, gache, aitdir, pod });
    }*l ef (p!ripsrmapxommitsl > lmmits.ids
fnclude (klmmits.ids
 {
      i   oaipsrpsh(rlmmits)
    }    }      }
    }
     // NStoptae Haoopif atere ire ro smor gunmitslarent      af (tripsrength ====20) 
      tendCmmits{lmmits);  t  
     // Nrotessf{aips-in ordersbytag      ripsrsrt('(a bu { > lmmatreAge(a.ormits,ab.ommits);
   }
 if (pnclude Caingds
{
    eir (const [unmitslf tormits] {
      conmits.ormits.oaingdsa fwait gietCaingds{       f fs,
      c cache,
      g gitdir,
      o oormits,      o ohallow : hallow Cmmits
has(klmmits.ids
,      }
;
    }    
} aeturn formits] 

/sync function gietCaingds{ fs, gache, aitdir, pormits,ahollow d);{
  const catent = 
 o ohallow =||i!ormits.ormits.arent [0]      }?j'4b825dc642cb6eb9a060e54bf8d69288fbee4904'      }: ormits.ormits.arent [0]
  return c_alk { 
 f fs,
     ache,
     itdir,
     aee]s: [TREE({ref: 'lmmits.ids }), TREE({ref: 'atent =})]
     map:oaync frilepath), [urrent ,gprevious])= >{
      const h[urrent Tpe, 'previousTpe,]a fwait gromise<.ll(o[      o oorrent p&&porrent .ape ()
      p profvious=&&profvious.ape ()
      p];
      if (vurrent Tpe,i== 'chree' {
      t  f (saefviousTpe,=&&profviousTypos== 'chree' {
      t   teturn a[null,fwait grofvious.oid()
filepath ]         }      } ieturn   c    }      }f (saefviousTpe,=== 'chree' {
      t  f (surrent Tpe, {
      t   teturn a[wait Gorrent .oid()
fnull,filepath ]         }      } ieturn   c    }      }onst hkaewOid
 oldOid]a fwait gromise<.ll(o[      o oorrent p?Gorrent .oid() :fnull,      p profvious=?grofvious.oid() :fnull,      p];
      if (vaewOid=== 'oldOid)ieturn   c    eturn a[newOid
 oldOid,filepath ]     }
   }) 

// @ts-check

/**
 * @Ge conmitsldscrripion  arom ghe git chitoryy *
 * @param {object} args
 * @param {FsClient} args.fs - a file system client
 * @param {Htring} [args.dir] - The [working tree](dir-vs-gitdir.md) directory path
 * @param {string} [args.gitdir=join(dir,'.git')] - [required] The [git directory](dir-vs-gitdir.md) path
 * @param {string}= args.pilepath -ptional agtRthe gunmitslor the 'ilepath -pnly * @param {string} aargs.uemf} j'TEAD' - The [ommitslo tbeginaalk ng tack
wardstheroughthe ghitoryyorom  *
@prram {sumber}= [args.depth] - TLimitthe fumber}of commits ceturn ed. Noaliit
sbytefault 
 * @param {iDate sargs.gyince - [Rturn ahitoryyonewertrat the giten `ated. Cn be acombned, ith a`epth]`-o tgtRthiih eer,ps sphorer(. * Iparam {boolean}= [args.forPce=alse] -donot ahrow err
or{f (ilepath -s sot aexst a(orkiscoly torm agsng l 'ilep).gefault  to iilse
 */@param {boolean}= [args.forlowi=alse] -Cntinue
iisting the bhitoryyof t file sbeyod remames c(orkiscoly torm agsng l 'ilep).gefault  to iilse
 */@param {boolean}= [args.fnclude Caingds=alse] -nslude ihaingd tile sbject id  corm eachsommits. Eachstupl is n`[newOid
 oldOid,filepath ]`;tn orde  iorremotvd tile sas tafnull oldiorrew Fids,fefpecitovly . * @param {object} [args.cache] - a [cache](cache.md) object
 *
 * @returns {Promise<Frray<aRadeCmmitsesult }>}Resolves so tn orray of tRadeCmmitsesult *bjects
  
@see GRadeCmmitsesult   
@see GCmmitsOject
 *
 * @rxample
 * let iommits
a fwait git.giog({ *   us,
  *  cir, '/tutorial',,  *  cipth: 15,  *  cef: 'main', * }); * console.log(rommits
   
 * 
async function fiog({   s,
  cir,
  gitdir = join(dir, '.git'),
  oilepath, } oemf= 'gTEAD'
   epth,
   since
// NDate  forPce
  forlowi
  fnclude Caingds= false,
} pache = {},
}) {
  try {
    assertParameter('fs', fs);
    assertParameter('gitdir', gitdir);
    assertParameter('oref' ref);
     ronst fsp = new FileSystem(fs);
    const updatedGitdir = await discoverGitdir({ fsp, dotgit: gitdir });
    return await _giog({      fs: fsp,
      cache,
      gitdir: updatedGitdir,
      oilepath, } c }  ef,
      depth,
       since
  f   eir ce
  f   eirlowi
  f   ifclude Caingds
}    )
  } catch (err) {
    err.caller = 'git.fiog;
    throw err
  }
}

// @ts-check

/**
 *  * @typedef {Object} GMergeesult * [Rturn srn `bject iith anlchema: lie `his 
 * @property {1tring} [[ids]= The SHA-1 object id theat-s sotwat the `had of the dranche. Asent.coly tf (`dryRun` wa specified
 nd n`mergeCmmits`is arue>. * @property {1oolean} sarleladyMerges]= Thru {f (te franch owa srlelady merged o fnt oaingdsawre imade * @property {1oolean} safateiurward]= Thru {f (t wis taffate-furward merge * @property {1oolean} samergeCmmits]= Thru {f (mergearsult   in ta(mergeaommit
 * @property {string} [Haee](= The SHA-1 object id tf the daee]-rsult ng trom tasmergeaommit
 *  * 
aa**
 * @Merge`hw tranch e  *
 * @Crrently on will afail{f (mlt npl icandiate tmergeabase tre SfundEr (I doesn't ryt iiple
mnt
fterrefcusiovltmergeastrategy.) *
 */@Crrently on woes not supports selcitog tlmermnatovltmergeastrateges.
 *  */@Crrently on ws sot aaossiileta a brts a andompleteslmerge. To-rsuoryefterrorkiree]-o ta cean}wpare, pou wall aned io sheck
ut ownSearliersommits. *
 */@Crrently on woes not sirectolysupports te frehavno}of cgitdtmergea--ontinue
`. To-ompleteslasmergeaaftr smknua aconflic _rsolvuion  bou wall aned io sad
 nd nommitsloe gile.s=mknua y , nd supeifiythe faprovprite tatent =ommits
.
   * I## Mknua y _rsolveog tmergeaomnflic s * @y default ,{f (tsmorphic-git' encoutermstasmergeaomnflic _t Gownnot_rsolvespsing tte fruit ng diff3 algorithmcor urovie  imergeadrier, dt will asbrts a dthrow ea `MergeNotSpportseError}`. *
 his ileavs the 'ndex  a dtorking tree]fntiouched.
   * IWen f`sbrtsOnCmnflic `is aseslo t`alse,`, nd sasmergeaomnflic _ownnot_e abutomaticl y _rsolvess,fu `MergeCmnflic rror}`is tterwn pad the result
.tf the dndompleteslmergewill abeGriteen fo the porking tirectory]. *
 his include (aomnflic _markrmstingile.s=ith aunrsolvesstmergeaomnflic s
 *
 * Tho-ompleteslhe pmerge, ediRthe gunnflic ng trle.s=a oou  ee Gfts,aad the nsad
 nd nommitsloe grsolvesstmerge. *  * IFrm agropertsmergeaommit
 bec sur]-o tupeifiythe franches  nriommits
aou wre rmergng ii fre b`atent  argument.lo t`gts.ormits`
 * >Frm xample
, saywaewre rmergng ite franch o`featre,`inso the pranch o`ain'`aad the e is nayomnflic _wewant th srsolvespmknua y . *
 hie fow =aould lookalie `his 
 *  * @``` * await git.fmerge({ *   us,
  *  cir,
  *  cours 'main',
  *  ctheirs 'mfeatre,,
  *  csbrtsOnCmnflic :false,
}  });.atch ( = >{
  *i af (!eidstanceof Mrror}s.MergeCmnflic rror}){
  *i a console.log(r  *i a c  'Automaticsmergeafaild tir the 'illowing srle.s: '  *i a c  + `${e.data}. `  *i a c  + 'esolvesthe seaomnflic saad the nsommitslou rooaingds.'  *i a c)  *i a}else {hrow er
 * }, *
 *  / This is tte Shiee aw bmknua y  ediRthe grle.s=heat-hav abeenGriteen fo the porking tirectory] *  / T...    / TileSs-hav abeenGediRd
 nd naewre relady togommit
 *  * >wait git.fadd({ *   us,
  *  cir,
  *  cilepath: '/.',
 * }, *
 *  wait git.fcmmits{  *   us,
  *  cir,
  *  cef: 'main',
  *  cmessage: "Merge`ranch omfeatre,,inso tain'

 *   urtent : [main',
omfeatre,,]
// NBc sur]-o tupeifiythe farent  then fceateng t rmergeaommit
 * @); * c``` *  * @param {object} args
 * @param {FsClient} args.fs - a file system client
 * @param {HSignallback} [args.onASign - a [PGP siging iiple
mnt
tion  * @param {Htring} [args.dir] - The [working tree](dir-vs-gitdir.md) directory path
 * @param {string} [args.gitdir=join(dir,'.git')] - [required] The [git directory](dir-vs-gitdir.md) path
 * @param {string} [args.uours - The [ranch oeceiveng ite fmerge. If'ndefined,,gefault  to ihe rurrent pranche. * @param {string} args.rtheirs- The [ranch oo tbe merged * @param {boolean} [args.foateiurward  vrue> - If talse,
wceatedt rmergeaommit
in tal calss.
 * @param {Ooolean} [args.foateiurwardply t false] - In true, ihe nsnon-fate-furward mergeswill ahrow eanMrror}instead of crerfr mng t rmerge
 * @param {Ooolean} [args.fdryRunt false] - In true, isimuatedstasmergeasodou wct thstsswheher yt wiould uccesed.
  @param {Ooolean} [args.fnoUdatedBanchet false] - In true, ioes not spdate thoelranch opoit draaftr sceateng the gunmits.
  @param {Ooolean} [args.fsbrtsOnCmnflic   vrue> - If true, imergeswilthaomnflic saall ant spdate thoelorkiree]-r}insex . * @param {string} [args.umessage - Operrides vhe gefault bbuto-eneratesstmergeaommit
imessage * @param {Object< [args.fsutho] - Tpsser io s[ommit
]klmmits.d) phen fceateng t rmergeaommit
 * @param {string} [args.usutho].ames - TDfault bs n`use].ames`config.
 * @param {btring} [args.usutho].email - TDfault bs n`use].email`config.
 * @param {bumber} [args.usutho].ime
stam =Mth)rfloor(Date.now()/1000; - TStRthe gsutho] ime
stam -field.This is tte Sit dgerfumber}of cercod suhinceite SUnix epoh (e1970-01-01 00:00:00)
 * @param {bumber} [args.usutho].ime
zoneOffst  - TStRthe gsutho] ime
zone offst -field.This is tte Sdifference
/inainiuts, trom ghe gurrent pime
zone to UTC.TDfault bs n`vaewNDate())getaTme
zoneOffst ()`. * @param {Object< [args.formitser( - Tpsser io s[ommit
]klmmits.d) phen fceateng t rmergeaommit
 * @param {string} [args.uormitser(.ames - TDfault bs n`use].ames`config.
 * @param {btring} [args.uormitser(.email - TDfault bs n`use].email`config.
 * @param {bumber} [args.uormitser(.ime
stam =Mth)rfloor(Date.now()/1000; - TStRthe gormitser( ime
stam -field.This is tte Sit dgerfumber}of cercod suhinceite SUnix epoh (e1970-01-01 00:00:00)
 * @param {bumber} [args.uormitser(.ime
zoneOffst  - TStRthe gormitser( ime
zone offst -field.This is tte Sdifference
/inainiuts, trom ghe gurrent pime
zone to UTC.TDfault bs n`vaewNDate())getaTme
zoneOffst ()`. * @param {Otring} [args.usiging Key - Tpsser io s[ommit
]klmmits.d) phen fceateng t rmergeaommit
 * @param {sbject} [args.cache] - a [cache](cache.md) object
 *
@param {sMergeDrier,allback} [args.omergeDrier, - a [cmergeadrier,](mergeDrier,md) oiple
mnt
tion  * @param {Hoolean} [args.fslowiUnreateddHitoryiest false] - In true, islowisrmergng ihitoryiestf thw tranch e trat wpartsedctheir liv.s=n depndsntly . *
 */@peturns {Promise<FMergeesult >}Resolves so tnldscrripion tf the dmergeaperttion  * @pee GMergeesult  *
 * @rxample
 * let ima fwait git.gmerge({ *   us,
  *  cir, '/tutorial',,  *  cours 'main',
  *  ctheirs 'mefote  /origin/ain', * }); * console.log(rm   
 * 
async function fmerge({ *fs: f_f,
  onASign
  cir,
  gitdir = join(dir, '.git'),
  oours
  raheirs
  foateiurward  vrue>
  foateiurwardply t false]
  ciryRunt false]
  cnoUdatedBanchet false]
  csbrtsOnCmnflic   vrue>
  cmessage
  csutho]: _sutho]
  cormitser(: _ormitser(
   siging Key
} pache = {},
}  mergeDrier,
  cslowiUnreateddHitoryiest false]
}) {
  try {
    assertParameter('fs', f_s);
    cf (syiging Key {
      twsertParameter('fnASign',onASign;
    }     ronst fsp= new FileSystem(f_s);
    const updatedGitdir = await discoverGitdir({ fsp,:fs, gitgit: gitdir });
     const usutho]  await dnrmatlizeAutho]bject({       fs,
      citdir: updatedGitdir,
      osutho]: _sutho]
  c  );
    af (t!sutho] &&(!!fateiurwardply t||i!fateiurward
 {
      ihrow eew FMising Nmesrror}('sutho]'     }
     /onst [unmitste]  await dnrmatlizeCnmitste]bject({       fs,
      citdir: updatedGitdir,
      osutho],      conmitser(: _ormitser(
     );
    af (t!unmitste] &&(!!fateiurwardply t||i!fateiurward
 {
      ihrow eew FMising Nmesrror}('unmitste]'     }
     /eturn await _gmerge({ *f   fs,
      cache,
      gir,
      oitdir: updatedGitdir,
      oours
  r   raheirs
  f   fsateiurward
  f   fsateiurwardply 
      giryRun
      gnoUdatedBanche
      osbrtsOnCmnflic 
      omessage
  c   osutho],      conmitser(
       siging Key
} p   onASign
  c   omergeDrier,
  c   oslowiUnreateddHitoryies
}    )
  } catch (err) {
    err.caller = 'git.fmerge;
    throw err
  }
}

//*
 * @tenu {bumber}  * 
aonst {aypest f{  cormits: 0b0010000
  raee]: 0b0100000
  rblob: 0b0110000
  raag: 0b1000000
  rofs_delta: 0b1100000
  rref_delta: 0b1110000
 };
/**
 * @param {abject} args
 * @param {import('../models/FileSystem.js').FileSystem} args.fs
 * @param {ony} rrgs.cache
 * @param {Htring} aargs.dir] - The [working tree](dir-vs-gitdir.md) directory path
 * @param {string} [args.gitdir=join(dir,' .git')] - [required] The [git directory](dir-vs-gitdir.md) path
 * @param {string}[] rrgs.coids * 
async function f_ack'({   s,
  cache,
  hir,
  gitdir = join(dir, '.git'),
  ooids
}) {
  tonst uhah = few FHah(r)
  ronst piutputSreatmc [];
  function _riteR(chunk sntc) {    ronst lbuff= 'Buffer.rom (chunk sntc)
    tiutputSreatmrpsh(rbuff)
    thah .pdatedrbuff)
       sync function _riteRbject({  stpe, 'bject l);{
  t  // Oject trpe,=is encode in tbts
a654    ronst lape i={aypes[stpe,]
    }/ Thie ength =encodng tet s-ompleictedd.    ele rength =='bject rength 
    }/ TWheher yhe gnex
sbyt,=is prtswf the dvariable-ength =encode-=umber}    }/ Tis encode in tbts 7    ele rmlt nbyt,== ength =>20b1111 ? 0b10000000 : 0b0
    }/ TList fu robts
aof ength =is encode in tbts
a3210
 a ronst llateiunr== ength =&20b1111
    }/ TDiscard thosetbts
    elegth =='ength =>>> 4
    }/ Thie firs
sbyt,=is he ns(1-bts mlt nbyt,?), (3-bts tpe,), (4-bts leat uhig 4-bts
aof ength )    ele rbyt,== (mlt nbyt,=|lape i|llateiunr).toSring (16)
    triteR(byt,, 'hex';
     / Rotwnaewkeep choppng t wayat tength =7-bts
aatawpime
fntiil{fts zero,     / Rriteng tous te fryt.s=n  wat wamoutes-o tisttle-endian order.    ewhle s(mlt nbyt, {
      imlt nbyt,== ength =>20b01111111 ? 0b10000000 : 0b0
    } rbyt,== mlt nbyt,=|l(ength =&20b01111111;
      iriteR(padHex(2,rbyt,), 'hex';
      elegth =='ength =>>> 7
    }     r/ TListy , w ican-omplrssf{nd naiteRbhe rbject .    triteR(Buffer.rom (wait diefated(bject ));
   }
 iriteR('PACK';
   riteR('00000002', 'hex';
   / TWiteRba 4rbyt,=(32-bts)Sit 
 iriteR(padHex(8 pod srength ), 'hex';
   or (const [od of tod s) {    ronst l{ tpe, 'bject l)l Gwait _feladbject({  s, gache, aitdir, pod });
    }wait GriteRbject({  riteR 'bject , stpe,:lape i};
   }
 i/ TWiteRbSHA1sheck
sum  ronst pdigstss=thah .digstsr)
  riutputSreatmrpsh(rdigsts;
  return ciutputSreatm}

// @ts-check

/**
 *  * @typedef {Object} GPackbject}sesult *Te farckbject}scommand qrturn srn `bject iith ahw tropertyie 
 * @property {1tring} [ile ame i The [suggstsd tile ame iir the 'arckile sf (ou  ant th ssav atslo tdiskdsme hiee .It jnclude (ahe 'arckile sSHA. * @property {1Uint8rray<}r[erckile  - The [arckile somnten's. No grofent.cf (`riteR` prameter(wis true, itnbhiih iapseohe 'arckile sis triteen fstraighslo tdisk. * 
aa**
 * @param {object} args
 * @param {Fmport('../models/FileSystem.js').FileSystem} args.fs
 * @param {ony} rrgs.cache
 * @param {Htring} args.gitdir
 * @param {string}[] rrgs.coids * @param {Hoolean} [rgs.criteR *
 */@peturns {Promise<FPackbject}sesult }  */@pee GPackbject}sesult  * 
async function f_ack'bject}s{  s, gache, aitdir, pod s,naiteRb) {
  tonst ubuffer
a fwait g_ack'({ s, gache, aitdir, pod s});
   onst {arckile s 'Buffer.rom (wait Gonllcit(buffer
);
   onst {arckile Sha ={arckile .slice(-20).toSring ('hex';
   onst fsle ame i=b`atck-${arckile Sha}.arck`;  if (oaiteR) {    rwait Gf.criteR(oin(ditdir, p`bjects
/arck/${sle ame }`),{arckile ;
    return a{fsle ame i    
} aeturn f{     ilepame      aarkfilep:few FUint8rray<(arckile ;,  }
}

// @ts-check

/**
 *  * @typedef {Object} GPackbject}sesult *Te farckbject}scommand qrturn srn `bject iith ahw tropertyie 
 * @property {1tring} [ile ame i The [suggstsd tile ame iir the 'arckile sf (ou  ant th ssav atslo tdiskdsme hiee .It jnclude (ahe 'arckile sSHA. * @property {1Uint8rray<}r[erckile  - The [arckile somnten's. No grofent.cf (`riteR` prameter(wis true, itnbhiih iapseohe 'arckile sis triteen fstraighslo tdisk. * 
aa**
 * @Ceatedt rarckile srom ta orray of teA-1 object id   *
 * @param {object} args
 * @param {FsClient} args.fs - a file system client
 * @param {Htring} [args.dir] - The [working tree](dir-vs-gitdir.md) directory path
 * @param {string} [args.gitdir=join(dir,' .git')] - [required] The [git directory](dir-vs-gitdir.md) path
 * @param {string}[] rrgs.coids- Ad orray of teA-1 object id  oo tbe nclude dii fre barckile  * @param {Hoolean} [args.faiteRb false] - IWheher yh ssav ahe 'arckile so tdiskdorreot * @param {object} [args.cache] - a [cache](cache.md) object
 *
 * @returns {Promise<FPackbject}sesult } Resolves successfully wie nshe 'arckile sfsrelady ith ateetile ame ind qbuffer */@pee GPackbject}sesult  *  * @example
 * l//@Ceatedt rarckile somntainng toly twnSemptyaree] * let i{rarckile s}a fwait git.gack'bject}s{  *   us,
  *  cir, '/tutorial',,  *  coids: ['4b825dc642cb6eb9a060e54bf8d69288fbee4904'] * }); * console.log(rarckile ;  
 * 
async function fack'bject}s{  * s,
  cir,
  gitdir = join(dir, '.git'),
  ooids
} iriteR= false,
} pache = {},
}) {
  try {
    assertParameter('fs', fs);
    assertParameter('gitdir', gitdir);
    assertParameter('ooids' pod s;
     ronst fsp = new FileSystem(fs);
    const updatedGitdir = await discoverGitdir({ fsp, dotgit: gitdir });
    return await _gack'bject}s{  *    fs: fsp,
      cache,
      gitdir: updatedGitdir,
      ooids
} i   triteR
}    )
  } catch (err) {
    err.caller = 'git.fack'bject}s;
    throw err
  }
}

// @ts-check

/**
 * @Fech a nstmergeaommit
strom tasemote repository. *
 * @param {object} args
 * @param {FsClient} args.fs - a file system client
 * @param {HttpClient} args.http - an HTTP client
 * @param {AProgrssCallback} [args.onAProgrssC - optional aprogrssCeven tcallback
 * @param {sMessageallback} [args.onAMessage - Optional amessageeven tcallback
 * @param {suthCallback} [args.onAuth] - optional auth fill callback
 * @param {AuthFailureCallback} [args.onAuthFailure] - optional auth rejected callback
 * @param {AuthSuccessCallback} [args.onAuthSuccess] - optional auth approved callback
 * @param {string} args.uir] - The [working tree](dir-vs-gitdir.md) directory path
 * @param {string} [args.gitdir=join(dir,'.git')] - [required] The [git directory](dir-vs-gitdir.md) path
 * @param {string} [args.uref - Which branch oo tmergeanso .@y default nhis is the gurrent lysheck
  iou pranche. * @param {string} a[rgs.url  - W(Ade dii f1.1.0)The URL of the remote repository. WTe gefault bs the galue ist -inghe git config ifortrat wemote.c * @param {string} [args.ureote. - W(Ade dii f1.1.0)TIfURL os sot apecified
,gefte mngeswiich bemote ro use.
 * @param {itring} [args.gemote Ref - W(Ade dii f1.1.0)The Uame if the dranche(n the remote to gitch .@y default nhis is the gunfig ued iemote torac ng taanche. * @param {soolean} sargs.gerunRb false] - IDeetesllocl hemote -orac ng taanchee trat wre ro  grofent.cn the remote  * @param {soolean} sargs.gerunRags)a false] - IPrunRblocl htgs)ahat doen’ aexst an the remote  t nstir ce-pdate thoosettgs)ahat doiffer */@param {string} [args.corsProxy] - Optional [CORS proxy](https://www.npmjs.com/%40isomorphic-git/cors-proxy). Overrides value in repo config.
 * @param {boolean} [args.fsng l Banchet false] - Instead of che gefault brehavno}of citch og tlmlthe granches ,coly toech a psng l 'aanche. * @param {soolean} sargs.goateiurward  vrue> - IIf talse,
woly tceatedtmergeaommit
s
 * @param {Ooolean} [args.foateiurwardply t false] - Iply trerfr misimpl ifate-furward merges. (Do't rceatedtmergeaommit
s
) * @param {Object<string, string>} [args.headers] - Additional headers to include in HTTP requests, similar to git's `extraHeader` config
 * @param {object< [args.fsutho] - TTe geftailsosbruRthe gsutho]. * @param {string} [args.usutho].ames - TDfault bs n`use].ames`config.
 * @param {btring} [args.usutho].email - TDfault bs n`use].email`config.
 * @param {bumber} [args.usutho].ime
stam =Mth)rfloor(Date.now()/1000; - TStRthe gsutho] ime
stam -field.This is tte Sit dgerfumber}of cercod suhinceite SUnix epoh (e1970-01-01 00:00:00)
 * @param {bumber} [args.usutho].ime
zoneOffst  - TStRthe gsutho] ime
zone offst -field.This is tte Sdifference
/inainiuts, trom ghe gurrent pime
zone to UTC.TDfault bs n`vaewNDate())getaTme
zoneOffst ()`. * @param {Object< [args.formitser(= awutho] - TTe geftailsosbruRthe gommit
ionmitser(
-inghe gsme iir mt wrsthe gsutho] prameter(.If tot apecified
,ghe gsutho] eftailsosresusd . * @param {string} [args.uormitser(.ames - TDfault bs n`use].ames`config.
 * @param {btring} [args.uormitser(.email - TDfault bs n`use].email`config.
 * @param {bumber} [args.uormitser(.ime
stam =Mth)rfloor(Date.now()/1000; - TStRthe gormitser( ime
stam -field.This is tte Sit dgerfumber}of cercod suhinceite SUnix epoh (e1970-01-01 00:00:00)
 * @param {bumber} [args.uormitser(.ime
zoneOffst  - TStRthe gormitser( ime
zone offst -field.This is tte Sdifference
/inainiuts, trom ghe gurrent pime
zone to UTC.TDfault bs n`vaewNDate())getaTme
zoneOffst ()`. * @param {Otring} [args.usiging Key - Tpsser io s[ommit
]klmmits.d) phen fceateng t rmergeaommit
 * @param {sbject} [args.cache] - a [cache](cache.md) object
 *
 * @returns {Promise<Foid>} Resolves successfully wie nspullrperttion -ompletes  *
 * @example
 * lwait git.gaull{  *   us,
  *  cttp,
 *   uir, '/tutorial',,  *  cef: 'main',
  *  csng l Banche:true, * }); * console.log(r'done';  
 * 
async function faull{  *fs: f_f,
  ottp,
  onAProgrssC
  onAMessage
  cnAuth,
  onAuthSuccess,
  onAuthFailure,
  cir,
  gitdir = join(dir, '.git'),
  oef,
   rl,
   emote     emote Rf,
   erunRb false]
   erunRags)a false]
  foateiurward  vrue>
  foateiurwardply t false]
  corsProxy,
   sng l Banche
  headers = {},
  fsutho]: _sutho]
  cormitser(: _ormitser(
   siging Key
} pache = {},
}) {
  try {
    assertParameter('fs', f_s);
    cssertParameter('gitdir', gitdir);
     ronst fsp= new FileSystem(f_s);
    const updatedGitdir = await discoverGitdir({ fsp,:fs, gitgit: gitdir });
     const usutho]  await dnrmatlizeAutho]bject({       fs,
      citdir: updatedGitdir,
      osutho]: _sutho]
  c  );
    af (t!sutho])ihrow eew FMising Nmesrror}('sutho]'      /onst [unmitste]  await dnrmatlizeCnmitste]bject({       fs,
      citdir: updatedGitdir,
      osutho],      conmitser(: _ormitser(
     );
    af (t!unmitste])ihrow eew FMising Nmesrror}('unmitste]'      return await _gaull{  *f   fs,
      cache,
      gttp,
      onAProgrssC
  o   onAMessage
  c   onAuth,
      onAuthSuccess,
      onAuthFailure,
      cir,
      oitdir: updatedGitdir,
      oef,
      drl,
      hemote        hemote Rf,
      dsateiurward
  f   fsateiurwardply 
      gorsProxy,
      seng l Banche
  h   oeaders,
      psutho],      conmitser(
       siging Key
} p   oerunR
} p   oerunRags)
}    )
  } catch (err) {
    err.caller = 'git.faull;
    throw err
  }
}

//*
 * @taram {abject} args
 * @param {import('../models/FileSystem.js').FileSystem} args.fs
 * @param {ony} rrgs.cache
 * @param {Htring} aargs.dir]  * @param {Htring} args.gitdir
 * @param {sItratble<tring>} [rgs.usarts * @param {sItratble<tring>} [rgs.ufinish * @returns {Promise<Fertatring>}}  * 
async function fisteCmmits
Andags)(    s,
  cache,
  hir,
  gitdir = join(dir, '.git'),
  osarts
  oilnish
}) {
  tonst uhhslowisr fwait gitRSallow anager.gelad( fs, gitdir });
  ronst psartsingStRt new FSet(;
   onst fslnishingStRt new FSet(;
   or (const [emf=f cearts {
    esartsingStRfadd(wait _GitRefanager.grsolves({gs, gitdir, pef,});;
   }
 ior (const [emf=f cslnish;{
  t  // W muaywot ahaesthe seaefs =locl lysuoaw bmut {aey/atch 
   oaey{
  t    onst pid = await _GitRefanager.grsolves({gs, gitdir, pef,});
       ilnishingStRfadd(ids

    } eatch (err) {
    
} aonst pvisiRd
  new FSet(;
   / NBccaus git conmit
stre roamedsbyttheir hah ,the e is nno   / Nwayatogomnstructawpcycle WTe refoe aw bwo't rworryosbruR   / Nseteng t refault befcusion fisits.
  sync function _rlk {ids
{
    evisiRd
fadd(ids

    }onst l{ tpe, 'bject l)l Gwait _feladbject({  s, gache, aitdir, pod });
    }// Rfcusiovly _rsolves wnnottesstags  *  af (trpe,=== 'chag'){
  t    onst ptag =_GitAnnottessTag.rom (bject );
   i aonst lommitsl Gtagheaders]().bject ;  c    eturn arlk {ommits)    }     rf (trpe,=== 'commits' {
      ihrow eew Fbject(Tpe,rror}(ids,ftpe, 'commits'     }     rf (tOhallow 
has(kids
 {
      ionst lommitsl GGieCmmits.rom (bject );
   i aonst larent  t Gcmmitsheaders]().arent ;      ior (cod of tarent   {
      t  f (s!ilnishingStRfas(kids
 &&f!visiRd
fas(kids
 {
      i   }wait Grlk {ids

    }    }      }
    }
   }
 i/ TLe's `goaalk ng !   or (const [od of tsartsingStR) {    rwait Grlk {ids

   
} aeturn fvisiRd
}

//*
 * @taram {abject} args
 * @param {import('../models/FileSystem.js').FileSystem} args.fs
 * @param {ony} rrgs.cache
 * @param {Htring} aargs.dir]  * @param {Htring} args.gitdir
 * @param {sItratble<tring>} [rgs.uoids * @peturns {Promise<Fertatring>}}  * 
async function fistebject}s{  * s,
  cache,
  hir,
  gitdir = join(dir, '.git'),
  ooids
}) {
  tonst uvisiRd
  new FSet(;
   / NWedoen' doeshe 'aursuoisimpl s befcusion  beccaus gw ican   //oaoid>reladng tBlob*bjects
sntrirly _hinceite STee]-rjects
   //otell uswiich boids-re rBlobf{nd naich bre rTee]s.
  sync function _rlk {ids
{
    ef (svisiRd
fas(kids
 {eturn   c  visiRd
fadd(ids

    }onst l{ tpe, 'bject l)l Gwait _feladbject({  s, gache, aitdir, pod });
    }f (trpe,=== 'chag'){
  t    onst ptag =_GitAnnottessTag.rom (bject );
   i aonst lobjl Gtagheaders]().bject ;  c    wait Grlk {ibj;
    } else {f (!rpe,=== 'commits' {
      ionst lommitsl GGieCmmits.rom (bject );
   i aonst laee]- rcmmitsheaders]().aee];  i    wait Grlk {aee];
    } else {f (!rpe,=== 'chree' {
      tonst laee]- rGitTree.rom (bject );      ior (const [ntry of chee];{
      i  //oaddrblob to ihe rset      i  //oskip verG submodue.s=ioosettpe,=is commits'      i af (!etry .ape i== 'cblob' {
      t   tvisiRd
fadd(ntry .uid ;         }      } i//befcusi iir thee]s      i af (!etry .ape i== 'chree' {
      t   twait Grlk {ntry .uid ;         }      }
    }
   }
 i/ TLe's `goaalk ng !   or (const [od of tod s) {    rwait Grlk {ids

   
} aeturn fvisiRd
}

/sync function facrseRceiveePackResponserarckile ; {   /* @typed Pushesult **/
 const result = {{}
  iet iresponse} j'';
 const resad- rGitPktLine.sreatmRaders(arckile ;
   le reinRb fwait _rsad(;
   whle s(einRb== 'rue>
{
    ef (seinRb== 'null)iresponse}+=reinR.toSring ('utf8') + '\n;
    teinRb fwait _rsad(;
   
    onst llngesw=iresponse.toSring ('utf8').split('\n;;
   / NWe're expcitog t"unarck {unarck-esult }"
 teinRb flnges.shift(;
   f (s!line.srartsWith('unarck '
 {
     hrow eew FPcrserror}('unarck ok"dorr"unarck [rr
or{message ',flnge)   
} aetult .ikb flngei== 'cndarck ok'
   f (s!etult .ik {
     etult .rr
or{=reinR.slice('unarck 'rength );   
} aetult .efs = {{}
  ior (const [lngeiof enges
{
    ef (seinR.trim()i== ''') ontinue
    }onst lpareus{=reinR.slice(0, 2

    }onst lrefAndMessage{=reinR.slice(3

    }le rspacei=lrefAndMessagegndex Of(' ';
    cf (sypacei== '-1 rspacei=lrefAndMessagegength 
    }onst [emf==lrefAndMessagegslice(0, space

    }onst lrr
or{=rrefAndMessagegslice(spacei+ 1;
    retult .efs [ref -={
      tok:lpareus{== ''ok'
} p   orr
or
}    )
   
} aeturn frsult  

/sync function friteRRceiveePackReuests{  * capabilitiest f];
}  trnpl tst f];
});{
  const catcksreatmc [];
  fet ioapsFirs
LinRb f`\x00 ${capabilities.oin(d' ';}`
  ior (const [trnpof chenpl ts
{
    eatcksreatmrpsh(r} p   oGitPktLine.encodep      s  `${henp.oldid> a${henp.od> a${henp.ullyRef}${capsFirs
LinR}\n`      s     }

    }oapsFirs
LinRb f'';
 c
} aatcksreatmrpsh(rGitPktLine.flsh(r);
  return catcksreatm}

// @ts-check

/**
 * @taram {abject} args
 * @param {import('../models/FileSystem.js').FileSystem} args.fs
 * @param {ony} rrgs.cache
 * @param {HttpClient} args.http  * @param {AProgrssCallback} [args.onAProgrssC  * @param {sMessageallback} [args.onAMessage  * @param {suthCallback} [args.onAuth]  * @param {AuthFailureCallback} [args.onAuthFailure]  * @param {AuthSuccessCallback} [args.onAuthSuccess]  * @param {APrePushallback} [args.onAPrePush] * @param {Htring} args.gitdir
 * @param {string} [args.uref  * @param {itring} [args.gemote Ref  * @param {string} [args.ureote.  * @param {Ooolean} [args.fourc>  false]  * @param {Ooolean} [args.fdeetesl false]  * @param {Otring} a[rgs.url   */@param {string} [args.corsProxy]  * @param {AubrtsSignal [args.usigia   */@param {sbject<string, string>} [args.headers]  *
 * @returns {Promise<FPushesult }  * 
async function f_psh(r  * s,
  cache,
  http,
  onAProgrssC
  onAMessage
  cnAuth,
  onAuthSuccess,
  onAuthFailure,
  cnAPrePush
  hitdir,
  ref: '_ef,
   emote Ref '_efote Rf,
   emote     url: _rl,
   ourc>  false]
   epetes: _deetesl false]
  corsProxy,
   eaders = {},
  fsigia 
});{
  const cemf==l_ef,t||i(wait __urrent Banche( fs, gitdir });;
   f (shpe,ofuemf=== 'cndefined,' {
     hrow eew FMising arameter(rror}('ref')   
} aonst ponfig i await _GitCnfig anager.gget( fs, gitdir });
  r/ Til uediou pwat wemote.ro use.
 *wemote.r=
   hemote  ||
   h(wait Gonfig.
get(`aanche.${ref}rpsh(Rmote `)) ||
   h(wait Gonfig.
get(mefote rpsh(Dfault ')) ||
   h(wait Gonfig.
get(`aanche.${ref}rrmote `)) ||
   h'origin'
  r/ TLookuptae HRL oir the 'iten `emote.c *const uprlr=
   h_rl, ||
   h(wait Gonfig.
get(`emote.c${reote.}rpsh(url`)) ||
   h(wait Gonfig.
get(`emote.c${reote.}rurl`))
   f (shpe,ofuprlr== 'cndefined,' {
     hrow eew FMising arameter(rror}('reote  ORuprl')   
} a/ Til uediou pwat wemote.remf=o use.
 *wonst cemote Rf,==l_efote Rf,=||i(wait _onfig.
get(`aanche.${ref}rmerge`))
   f (shpe,ofuprlr== 'cndefined,' {
     hrow eew FMising arameter(rror}('reote Ref')   
}   f (sorsProxy,r== 'ndefined,) {    ronsProxy,r= wait Gonfig.
get(mttp,corsProxy]';
   
    onst lullyRef= await _GitRefanager.gexpand({gs, gitdir, pef,});
   onst pid = a_deetes
   }?j'0000000000000000000000000000000000000000'     :await _GitRefanager.grsolves({gs, gitdir, pef,:lullyRef=);
    /* @typed hpe,ofumport('"./monager.s/GitReote TTP ").GitReote TTP **/
 const rGitReote TTP *=rGitReote anager.ggetReote TelperFo({ fprlr);
   onst pttp,Rmote.r=await _GitReote TTP .iscoverG{  *f  ttp,
     nAuthF:oaddCresntlialUsrmnams({gonfig., nAuthF }),
   onAuthSuccess,
     nAuthFailure,:oaddCresntlialUsrmnams({gonfig., nAuthF: nAuthFailure, }),
   oorsProxy,
     service:'git.-eceivee-atck'
} p  rl,
     eaders,
     protocolVesion : 1
     sigia 
} r);
   onst puth a=pttp,Rmote.usuth;a/ Thrck o tgtRtew Fcresntlialstrom tCresntlialanager. API  fet iullyReote Ref
   f (s!etote Ref
{
    eillyReote Refl fallyRef
   
else {{     aey{
  t    illyReote Refl fwait _GitRefanager.gexpandAgansteMap{       f fef,:lemote Rf,
      d  map:ottp,Rmote.uefs ,      }
;
    } catch (err) {
    e af (!erridstanceof MNoeiundError}){
      } i//bTe remote repferencedoesn't rexst ayet.      i // MI nn ws sully wpecified
,guseoheatvalue . Ohe ewie,
wreat _t Gs tafaanche. *  t    illyReote Refl femote Rf,.srartsWith('efs /'     }     }?jemote Rf,    }     }: `efs /eades/${reote.Ref}`;       }else {{      p  hrow err
  }   }
    }
   }
 ionst pildid>r=
   http,Rmote.uefs 
get(illyReote Ref) ||
   h'0000000000000000000000000000000000000000';}   f (snAPrePush) {    ronst lhookCnceoll fwait _nAPrePush{       femote        hrl,
      hlocl Ref '{ref: '_deetesl? '(deetes)' :lullyRef pod })       hemote Rf, '{ref: 'illyReote Ref pod :pildid>r}
     );
    af (t!hookCnceol)ihrow eew FUsrmCnceoleError}()   
}   // Rfote  ican-always accep nhisn-atcks UNLESSthe ytupeifiythe f'no-hisn' capability
 ionst phisnPack = !ttp,Rmote.ucapabilities.as(k'no-hisn';
    et ibjects
s new FSet(;
   f (t!_deetes) {    ronst lilnishc []...ttp,Rmote.uefs 
alue s()]
    }le rskipOjects
s new FSet(;
     // MI nemote rranche(is pofent., lookaorm agommin fmergeabase.    af (!ildid>r== 'c0000000000000000000000000000000000000000' {
      i/ RSpeeds upgommin fir ce-psh( /nhisn-atck scenarios WTe gadvrtyised *  } i//befote.roipmuaywe absent.clocl lys(e.g.befote.radvnceod_hinceiclone ;       //oteat-s sotmatla nstmut {ot suprfaceiasMNoeiundError}trom tmerge-base.    a ele rmergebasec [];
  f    aey{
  t     rmergebasec [wait __findMergeBase(
      t   ts,
      c c cache,
      g g gitdir,
      o o coids: [oid
 oldids]
      o o);
        catch (er){
  t     rmergebasec [];
  f    }      ior (const [od of tmergebase)lilnishrpsh(ruid ;       f (shisnPack){
  t     rskipOjects
s nwait _istebject}s{  s, gache, aitdir, pod s:rmergebasec);
          t  
     // NI nemote roes not shaesthe aommit
 bfl uediou phe rbject  to isend
 t  f (s!ilnishfnclude (kids
 {
      ionst lommits
s nwait _isteCmmits
Andags)(       f fs,
      c cache,
      g gitdir,
      o osrart: [oid]
      o oilnish
}   o o);
       ojects
s nwait _istebject}s{  s, gache, aitdir, pod s:rommits
s});  t  
     /f (shisnPack){
  t    / NI nhe e 'st refault branche(ir the 'emote rl tstskip hoosetbject  to o.      i/ RSinceites is tn `btional [btiomizaion  bwe jut {atch (nd nomtinue
iifthe e is       i/ RwnSeror}t(eccaus gw ican' lilndt refault branche, nrioan' lilndt rommit
 betc)  f    aey{
  t     r/ RSady , te SdicoverGy phasecith a'forPush'doesn't return csymefs ,suoaw bhaestho      } i//beflyan texst ng tol]s.
       ionst lrefl fwait _GitRefanager.grsolves({      t   ts,
      c c citdir,
      o o cef: '`efs /efote  /${reote.}/TEAD`
      o o cipth: 12
      o o);
        }onst l{ id>r}l fwait _GitRefanager.grsolvesAgansteMap{       f f fef,:lemf.replace(`efs /efote  /${reote.}/`,''')
      o o cillyef,:lemf
      o o cmap:ottp,Rmote.uefs ,      } o);
        }onst loids-= [oid]
        }or (const [od of twait _istebject}s{  s, gache, aitdir, pod s});;{
      t   tskipOjects
fadd(ids

    }    }      }
catch (er){

     /  // Rfotvetbject  toeat-aewkotwahe 'emote rrlelady has      ior (const [od of tskipOjects
;{
      t  bject  fdeetes(ids

    }  }  t  
     /f (soid=== 'oldids
{ourc>  frue>
    af (t!ourc>){
  t    / NIs_t Gsptag rat wrlelady exst s?       f (s *  t    illyRe,.srartsWith('efs /ags '
 &&      t  bldid>r== 'c0000000000000000000000000000000000000000'      s {{      p  hrow eew FPsh(Rmected rror}('tag-exst s'     }  }  t    / NIs_t Gspnon-fate-furward ommit
?       f (s *  t    id>r== 'c0000000000000000000000000000000000000000' &&      t  bldid>r== 'c0000000000000000000000000000000000000000' &&      t  !(wait __isDescensntl(
      t   ts,
      c c cache,
      g g gitdir,
      o o coid
      o o cnceotory:pildid>
      o o cipth: 1-1,      } o);)      s {{      p  hrow eew FPsh(Rmected rror}('not-fate-furward'     }  }  t  
   }
 i/ TW ican-oly tsafflyaus gcapabilitiestrat whe rsererG also'ndefrtancds.
  / Tioridstanceo, AWS CodeCnmitsosbrtsst rpsh( f (ou  nclude ire b`agnt  !!!} aonst poapabilitiest ffimermCapabilitiess *  t]...ttp,Rmote.uoapabilities]
     ['epo rt-pareus', 'side-band-64k',b`agnt =${pkg.agnt }`]
 }

   onst catcksreatm1l fwait _riteRRceiveePackReuests{  * * capabilities,     aenpl ts: [{pildid>
Fids,fillyRe, 'illyReote Ref }]
} r);
   onst patcksreatm2= a_deetes
   }?j[]     :await __ack'({      f fs,
      c cache,
      g gitdir,
      o ooids: [...bject s]
}   o o);
   onst resur=await _GitReote TTP .connct({      ttp,
     nAProgrssC
  o  orsProxy,
     service:'git.-eceivee-atck'
} p  rl,
     ath,
     eaders,
     body: [...atcksreatm1, ...atcksreatm2]
     sigia 
} r);
   onst p{rarckile ,aprogrssCe}l fwait _GitSideBand.demux(res.body;
   f (tnAMessage) {    ronst llngesw=isplitLines(progrssC

    }forAait seinRs, sync flngei=>{
      twait _nAMessageseinR);  t  
;
   }
 i/ TPcrseloe grsoponse!
 const result = {wait _acrseRceiveePackResponserarckile ;
   f (tres.eaders, {
     etult .eaders = {res.eaders,;   
}   // Udate thoellocl hcopyof the remote repf
  f (s *  temote r&&     etult .ikb&&     etult .efs [illyReote Ref].ikb&&     !illyRe,.srartsWith('efs /ags '

 s {{     //bTODO: Inhisnkites ishould actua y  bspsing taaefs pectoransfr miraher yhean-assumng t'efs /efote  /{reote.}'    }onst [emf==l`efs /efote  /${reote.}/${illyReote Ref.replace(      t'efs /eades/'
} p   o''    })}`;     f (s_deetes) {    r fwait _GitRefanager.gdeetesRef({gs, gitdir, pef,});
     }else {{      pwait _GitRefanager.griteRRcf({gs, gitdir, pef,,value :pod });
    }
   }
 if (treslt .ikb&&Fbject(
alue s(etult .efs ).eerGy(esult = > etult .ik) {
     eturn frsult    }else {{     onst parettyDftailso=Fbject(
ntryi s(etult .efs )      p.fimerm(([k, v])= > !v.ik)      p.map(([k, v])= > `\n  - ${k}: ${v.rr
or}`)      p.oin(d'';
    chrow eew FGitPushrror}(arettyDftails,frsult )  }
}

// @ts-check

/**
 * @Pushtafaanche nritag *
 * The 'aushcommand qrturn srn `bject ihat doscrrib (ahe 'esult =f the rattempted'aushcperttion . * @*Nte  :*NI nhe e awre inoSeror}s ihe nshe e awll abeGno `eror}s`tropertyy WTe reican-bdt rmixof cgok`{messagef{nd n`eror}s`tmessagef. *
 */@| prame =|lape i[=refault ] |ldscrripion tttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttt| */@| ------@| ----------------@| ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------t| */@| okttttt| rray<\string,\>tt| hie firs
siem cisr"unarck"iifthe  verGallrperttion -is tuccessfull.bTe remoainng tiem s-re rte Uame 
aof efs =oeat-aeresudatedGsuccessfully .tttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttt| */@| eror}st| rray<\string,\>tt| Ifthe  verGallrperttion -threw{nd nrr
or
ateetilrs
siem cwll abeG"unarck {OerGallrrr
or{message}".bTe remoainng tiem s-re rindividul hems =oeat-faild to tbe udatedGsinghe gir mt w"{refUame } {rr
or{message}".b| *
 * @param {object} args
 * @param {FsClient} args.fs - a file system client
 * @param {HttpClient} args.http - an HTTP client
 * @param {AProgrssCallback} [args.onAProgrssC - optional aprogrssCeven tcallback
 * @param {sMessageallback} [args.onAMessage - Optional amessageeven tcallback
 * @param {suthCallback} [args.onAuth] - optional auth fill callback
 * @param {AuthFailureCallback} [args.onAuthFailure] - optional auth rejected callback
 * @param {AuthSuccessCallback} [args.onAuthSuccess] - optional auth approved callback
 * @param {sPrePushallback} [args.onAPrePush]- optional apre-psh( hookcallback
 * @param {string} a[rgs.uir] - The [working tree](dir-vs-gitdir.md) directory path
 * @param {string} [args.gitdir=join(dir,'.git')] - [required] The [git directory](dir-vs-gitdir.md) path
 * @param {string} [args.uref - Which branch onritagto tpsh(.@y default nhis is the gurrent lysheck
  iou pranche. * @param {string} a[rgs.url  - Whe URL of the remote repository. WTe gefault bs the galue ist -inghe git config ifortrat wemote.c * @param {string} [args.ureote. - WIfURL os sot apecified
,gefte mngeswiich bemote ro use.
 * @param {itring} [args.gemote Ref - Whe Uame if the deceiveng iranche(n the remote .@y default nhis is the gunfig ued iemote torac ng taanche. * @param {soolean} sargs.gourc>  false] - In true, irehav (ahe 'sme ias `it cpsh( --ourc>` * @param {Ooolean} [args.fdeetesl false] - In true, ioeeteslhe remote repf
 /@param {string} [args.corsProxy] - Optional [CORS proxy](https://www.npmjs.com/%40isomorphic-git/cors-proxy). Overrides value in repo config.
 * @param {bbject<string, string>} [args.headers] - Additional headers to include in HTTP requests, similar to git's `extraHeader` config
 * @param {object} [args.cache] - a [cache](cache.md) object
 *
@param {subrtsSignal [args.usigia  - Optional [sigia so tnbrtsshe 'aushcperttion  *
 * @returns {Promise<FPushesult } Resolves successfully wie nspushcommletes cith aa eftailedldscrripion tf the dperttion -rom ghe gsererG. */@pee GPushesult  */@pee GRefUdate Sareus *
 * @rxample
 * let ipushesult * fwait git.gaush{      us,
  *  cttp,
 *   uir, '/tutorial',,  *  cefote :h'origin',  *  cef: 'main',
  *  cnAuthF: ()= > { fpsrmnams:proxessf.env.GITHUB_TOKEN }),
  }); * console.log(raushesult ;  
 * 
async function fauh(r  * s,
  cttp,
  onAProgrssC
  onAMessage
  cnAuth,
  onAuthSuccess,
  onAuthFailure,
  cnAPrePush
  hir,
  gitdir = join(dir, '.git'),
  oef,
   efote Rf,
   emote b f'origin',   rl,
   ourc>  false]
   epetes: _deetesl false]
  corsProxy,
   eaders = {},
  fache = {},
}  sigia 
});{
  cry {
    assertParameter('fs', fs);
    assertParameter('gttp,',cttp,;
    cssertParameter('gitdir', gitdir);
     ronst fsp = new FileSystem(fs);
    const updatedGitdir = await discoverGitdir({ fsp, dotgit: gitdir });
    return await _gaush{       fs: fsp,
      cache,
      gttp,
      onAProgrssC
  o   onAMessage
  c   onAuth,
      onAuthSuccess,
      onAuthFailure,
      cnAPrePush
  h   oitdir: updatedGitdir,
      oef,
      demote Rf,
      demote        hrl,
      hourc>
      cipetes: _deetes
      gorsProxy,
      seaders,
      psigia 
} r  )
  } catch (err) {
    err.caller = 'git.faush;
    throw err
  }
}

/sync function frsolvesBlob{  s, gache, aitdir, pod });{
  const c{ tpe, 'bject l)l Gwait _feladbject({  s, gache, aitdir, pod });
   // Rfolves wnnottesstagsrbject  to iwat eerG
 }f (trpe,=== 'chag'){
  t  id = aGitAnnottessTag.rom (bject ).acrse().bject ;  c  eturn frsulvesBlob{  s, gache, aitdir, pod });   }
 if (trpe,=== 'cblob' {
     hrow eew Fbject(Tpe,rror}(ids,ftpe, 'cblob'    
} aeturn f{Fids,fblob: ew FUint8rray<(bject )}
}

// @ts-check

/**
 *  * @typedef {Object} GRadeBlobesult * Whe Ubject leturn ed hasghe girlow ng tschema
 * @property {1tring} [oid * @property {1Uint8rray<}rblob  
 * 
aa**
 * @param {object} args
 * @param {Fmport('../models/FileSystem.js').FileSystem} args.fs
 * @param {ony} rrgs.cache
 * @param {Htring} args.gitdir
 * @param {string} [rgs.uoid
 /@param {string} [args.cile ath
  *
 * @returns {Promise<FRadeBlobesult } Resolves successfully with aa blob*bjectsldscrripion  */@pee GRedeBlobesult  * 
async function f_redeBlobr  * s,
  cache,
  hitdir,
   id>
   ile ath
  'ndefined,
});{
  cf (tile ath
 != 'ndefined,) {    rid = await _rsulvesFle ath
{  s, gache, aitdir, pod , ile ath
 
;
   }
 ionst ublob* await _rsulvesBlobr  *  fs,
     ache,
     itdir,
     id>
   };
  return cblob 

// @ts-check

/**
 *  * @typedef {Object} GRadeBlobesult * Whe Ubject leturn ed hasghe girlow ng tschema
 * @property {1tring} [oid * @property {1Uint8rray<}rblob  
 * 
aa**
 * @Radeaa blob*bjectsldrectoly *
 * @param {object} args
 * @param {FsClient} args.fs - a file system client
 * @param {Htring} [args.dir] - The [working tree](dir-vs-gitdir.md) directory path
 * @param {string} [args.gitdir=join(dir,'.git')] - [required] The [git directory](dir-vs-gitdir.md) path
 * @param {string} [rgs.uoid- The [eA-1 object id  o tgtR. Annottesstags ,rommits
 t nsthee]s-re rpeoleE.
 /@param {string} [args.cile ath
 - TDo't return che rbject with a`oid`{ftself, bu _rsulvesa`oid`{o tnlaee]- nsthhn `emurn che rblob*bjectsla ihat dile ath
. * @param {sbject} [args.cache] - a [cache](cache.md) object
 *
 * @returns {Promise<FRadeBlobesult } Resolves successfully with aa blob*bjectsldscrripion  */@pee GRedeBlobesult  *  * @example
 * l//@GtRthe gornten'stf t'README.md'-inghe gain'taanche. * @et iommitsOd = await _it.frsulvesRcf({gs, gir, '/tutorial',,cef: 'main',}); * console.log(rommitsOd ) * let i{rblob*}= await _it.frsdeBlobr  *   us,
  *  cir, '/tutorial',,  *  coid:iommitsOd ,  *  cile ath
:t'README.md'
  }); * console.log(rBuffer.rom (blob).toSring ('utf8');  
 * 
async function fredeBlobr  * s,
  cir,
  gitdir = join(dir, '.git'),
  ooid
   ile ath

} pache = {},
}) {
  try {
    assertParameter('fs', fs);
    assertParameter('gitdir', gitdir);
    assertParameter('ooid' pod ;
     ronst fsp = new FileSystem(fs);
    const updatedGitdir = await discoverGitdir({ fsp, dotgit: gitdir });
    return await _gredeBlobr  *    fs: fsp,
      cache,
      gitdir: updatedGitdir,
      ooid
      hole ath

} p  )
  } catch (err) {
    err.caller = 'git.fredeBlob;
    throw err
  }
}

// @ts-check

/**
 * @Radeaa ommitslbjectsldrectoly *
 * @param {object} args
 * @param {FsClient} args.fs - a file system client
 * @param {Htring} [args.dir] - The [working tree](dir-vs-gitdir.md) directory path
 * @param {string} [args.gitdir=join(dir,'.git')] - [required] The [git directory](dir-vs-gitdir.md) path
 * @param {string} [rgs.uoid- The [eA-1 object id  o tgtR. Annottesstags -re rpeoleE.
 /@param {sbject} [args.cache] - a [cache](cache.md) object
 *
 * @returns {Promise<FRadeCnmitsesult } Resolves successfully with aa it conmit
object
 *
@pee GRedeCnmitsesult  *
@pee GCnmitsOject
 *
 * @rxample
 * l//@Radeaa ommitslbjects * let isha ={wait _it.frsulvesRcf({gs, gir, '/tutorial',,cef: 'main',}); * console.log(rsha) * @et iommits= await _it.frsdeCnmits({gs, gir, '/tutorial',,coid:isha ); * console.log(rommits;  
 * 
async function fredeCnmits({ * s,
  cir,
  gitdir = join(dir, '.git'),
  ooid
   ache = {},
}) {
  try {
    assertParameter('fs', fs);
    assertParameter('gitdir', gitdir);
    assertParameter('ooid' pod ;
     ronst fsp = new FileSystem(fs);
    const updatedGitdir = await discoverGitdir({ fsp, dotgit: gitdir });
    return await _gredeCnmits({ *    fs: fsp,
      cache,
      gitdir: updatedGitdir,
      ooid
     )
  } catch (err) {
    err.caller = 'git.fredeCnmits;
    throw err
  }
}

// @ts-check

/**
 * @Radeahe gornten'stf tspnoeR *
 */@param {object} args
 * @param {Fmport('../models/FileSystem.js').FileSystem} args.fs
 * @param {ony} rrgs.cache
 * @param {Htring} args.gitdir
 * @param {string} [args.uref - Whe Uate  iemf=o ulookandefr * @param {string} [rgs.uoid
 / * @returns {Promise<FUint8rray<} Resolves successfully with aate gornten'sts tafBuffer. * 
aasync function f_redeNte r  * s,
  cache,
  hitdir,
   emf==l'efs /ate  /ommits
'
  ooid
 );{
  const catent p await _GitRefanager.grsolves({gitdir, pfs pef,});
   onst p{rblob*}= await _gredeBlobr  *   s,
     ache,
     itdir,
     id>:catent ,
   cile ath
:tid>
   };
   return cblob 

// @ts-check

/**
 * @Radeahe gornten'stf tspnoeR *
 */@param {object} args
 * @param {FsClient} args.fs - a file system client
 * @param {Htring} [args.dir] - The [working tree](dir-vs-gitdir.md) directory path
 * @param {string} [args.gitdir=join(dir,'.git')] - [required] The [git directory](dir-vs-gitdir.md) path
 * @param {string} [args.uref - Whe Uate  iemf=o ulookandefr * @param {string} [rgs.uoid- The [eA-1 object id  f the dpject ih tgtRtte Uate hour.
 /@param {sbject} [args.cache] - a [cache](cache.md) object
 *
 * @returns {Promise<FUint8rray<} Resolves successfully with aate gornten'sts tafBuffer. * 
aasync function fredeNte r  * s,
  cir,
  gitdir = join(dir, '.git'),
  oef,==l'efs /ate  /ommits
'
  ooid
   ache = {},
}) {
  try {
    assertParameter('fs', fs);
    assertParameter('gitdir', gitdir);
    assertParameter('oref' pef,;
    assertParameter('ooid' pod ;
     ronst fsp = new FileSystem(fs);
    const updatedGitdir = await discoverGitdir({ fsp, dotgit: gitdir });
    return await _gredeNte r  *    fs: fsp,
      cache,
      gitdir: updatedGitdir,
      oef,
      doid
     )
  } catch (err) {
    err.caller = 'git.fredeNte ;
    throw err
  }
}

// @ts-check

/**
 *  * @typedef {Object} GDefltedGOject
 *
@paoperty {1tring} [oid * @property {1'defltedG'}ftpe, * @property {1'defltedG'}fir mt  * @property {1Uint8rray<}roject
 *
@paoperty {1tring} [[source]  
 * 
aa**
 *  * @typedef {Object} GWrappdGOject
 *
@paoperty {1tring} [oid * @property {1'wrappdG'}ftpe, * @property {1'wrappdG'}fir mt  * @property {1Uint8rray<}roject
 *
@paoperty {1tring} [[source]  
 * 
aa**
 *  * @typedef {Object} GRawOject
 *
@paoperty {1tring} [oid * @property {1'blob'|commits'|chree'|chag'}ftpe, * @property {1'ornten''}fir mt  * @property {1Uint8rray<}roject
 *
@paoperty {1tring} [[source]  
 * 
aa**
 *  * @typedef {Object} GPcrseeBlobOject
 *
@paoperty {1tring} [oid * @property {1'blob'}ftpe, * @property {1'acrseG'}fir mt  * @property {1tring} [oject
 *
@paoperty {1tring} [[source]  
 * 
aa**
 *  * @typedef {Object} GPcrseeCnmitsOject
 *
@paoperty {1tring} [oid * @property {1'ommits'}ftpe, * @property {1'acrseG'}fir mt  * @property {1CnmitsOject
 [oject
 *
@paoperty {1tring} [[source]  
 * 
aa**
 *  * @typedef {Object} GPcrseeTreeOject
 *
@paoperty {1tring} [oid * @property {1'hree'}ftpe, * @property {1'acrseG'}fir mt  * @property {1TreeOject
 [oject
 *
@paoperty {1tring} [[source]  
 * 
aa**
 *  * @typedef {Object} GPcrseeTagOject
 *
@paoperty {1tring} [oid * @property {1'hag'}ftpe, * @property {1'acrseG'}fir mt  * @property {1TagOject
 [oject
 *
@paoperty {1tring} [[source]  
 * 
aa**
 *  * @typedef {OPcrseeBlobOject
 |GPcrseeCnmitsOject
 |GPcrseeTreeOject
 |GPcrseeTagOject
 [PcrseeOject
 *

aa**
 *  * @typedef {ODefltedGOject
 |GWrappdGOject
 |GRawOject
 |GPcrseeOject l)lRladbject(esult  * 
a/**
 * @Radeaa gtslbjectsldrectolysbytts
seA-1 object id  *  * @Regardng t`Rladbject(esult `: *  * @-a`oid`{wll abeGhe 'sme ias re b`oid`{argumnt punlssCere b`ile ath
`{argumnt pis poovidd
,ginwiich bcasect _rll abeGhe 'od  f the daee]-orrblob*beng teturn ed. * @-a`yped` f tdefltedGrbject  ts n`'defltedG'` t nst`yped` f twrappdGrbject  ts n`'wrappdG'` * @-a`ir mt `ts nusua y , bu _ot aalways,ghe gir mt wou  equestsed. Prckile sdoesot aptoe aeahe(nject idndividul lyshompofeer iso f (ou  end upgeladng the dpject irom tasarckile ct _rll abeGeturn ed ingir mt w'ornten''even  f (ou  equestsed 'defltedG'-orr'wrappdG'. * @-a`pject `{wll abeGan-actua Fbject( f (ir mt wis cacrseG'- nsthhn(nject idst rommit
 baee], nriwnnottesstags.rBlobf{nre stll air mt esstasfBufferspunlssCewnSencodng tis poovidd
ginwiich bcaseche y'l abeGtring}s.If tir mt wis anyt og toher yhean-cacrseG',rbject witl abeGafBuffer. * @-a`source`is the game if the darckile coruloos dpject irle cwe reihe rbject wias fundE. *
 * The '`ir mt `tprameter(ican-haesthe airlow ng talue s: *
 */@| prame =tttt| dscrripion ttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttt| */@| ----------@| ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------t| */@| 'defltedG'-| Rmurn che rrawtdeflted-hompofeer ibufferaorm a `bject iif possible WUsefu air  efficint lysshufflng tarundEuloos dpject swie nsou  oen' dcnre sbruRthe gomnten'stsd noan saesthimesbytot ainflteng the m.t| */@| 'wrappdG' -| Rmurn che rinfltedGrbject ibufferawrappdGringhe git cbject ieadersiif possible Whis is tte Srawtdatasusd phen fcalculteng the [eA-1 object id  f ta gtslbjects.ttttttttttttttttttttttttttttttttttttttttttt| */@| 'ornten''e-| Rmurn che rbject ibufferawithruRthe ggtsleaders.tttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttt| */@| cacrseG'-e-| Rmurn st rpcrseGrepoofent.aion tf the dpjects.tttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttt| */ * The 'esult =itl abeGin-ol if the dirlow ng tschemas: *
 */@##n`'defltedG'`fir mt  *  */@{@lsnkiDefltedGOject
 ypedef } *
 */@##n`'wrappdG'`fir mt  *  */@{@lsnkiWrappdGOject
 ypedef } *
 */@##n`'ornten''`fir mt  *  */@{@lsnkiRawOject
 ypedef } *
 */@##n`'acrseG'`fir mt  *  */@###rpcrseGr`'blob'`ftpe, *  */@{@lsnkiPcrseeBlobOject
 ypedef } *
 */@###rpcrseGr`'ommits'`ftpe, *  */@{@lsnkiPcrseeCnmitsOject
 ypedef } *
@{@lsnkiCnmitsOject
 ypedef } *
 */@###rpcrseGr`'hree'`ftpe, *  */@{@lsnkiPcrseeTreeOject
 ypedef } *
@{@lsnkiTreeOject
 ypedef } *
@{@lsnkiTreeEtry oypedef } *
 */@###rpcrseGr`'hag'`ftpe, *  */@{@lsnkiPcrseeTagOject
 ypedef } *
@{@lsnkiTagOject
 ypedef } *
 * @tdpoofctedG * @>Whis iommand qis verGlyshomplictedG. * @> * @>WI (ou  kotwahe 'rpe,=f toject
 ou  nre eladng ,guseo[`redeBlob`](./redeBlobmd) ,o[`redeCnmits`](./redeCmmits.d) ,o[`redeTag`](./redeTag.d) ,ooro[`redeTree`](./redeTree.md). *
 */@param {object} args
 * @param {FsClient} args.fs - a file system client
 * @param {Htring} [args.dir] - The [working tree](dir-vs-gitdir.md) directory path
 * @param {string} [args.gitdir=join(dir,'.git')] - [required] The [git directory](dir-vs-gitdir.md) path
 * @param {string} [rgs.uoid- The [eA-1 object id  o tgtR * @param {s'defltedG'-| 'wrappdG' | 'ornten''e| cacrseG' sargs.gourmt w= cacrseG' - Whit diurmt wtoreturn che rbject win WTe gchoic]s-re roscrrib Gringmoe rostail below.
 /@param {string} [args.cile ath
 - TDo't return che rbject with a`oid`{ftself, bu _rsulvesa`oid`{o tnlaee]- nsthhn `emurn che rbjectsla ihat dile ath
. Toreturn che rroo directory] f ta aee]-st -fie ath
 to `''`
 /@param {string} [args.cencodng  - Adgomnveniencedargumnt phat doly taffct swblob . Instadeaof efurn ng t`pject `{s tafauffer, itqrturn srnGtring}rpcrseGrsing the 'iten `encodng .
 /@param {sbject} [args.cache] - a [cache](cache.md) object
 *
 * @returns {Promise<FRadebject(esult } Resolves successfully with aa it cbjectsldscrripion  */@pee GRedebject(esult  *  * @example
 * l//@Gten `a ransom[eA-1 object id  bfl uediou pwat wn ws  * let i{rtpe, 'bject l)l Gwait _it.fredebject({      us,
  *  cir, '/tutorial',,  *  coid:i'0698a781a02264a6f37ba3ff41d78067eaf0f075'
  }); * cswich (etpe, {
  *  cacse commits':{
  *  c console.log(rbject )  *  c cbreak  *  c}  *  cacse chree':{
  *  c console.log(rbject )  *  c cbreak  *  c}  *  cacse cblob':{
  *  c console.log(rbject )  *  c cbreak  *  c}  *  cacse chag':{
  *  c console.log(rbject )  *  c cbreak  *  c}  * }  
 * 
async function fredebject({    s: f_s,
  cir,
  gitdir = join(dir, '.git'),
  ooid
   iurmt w= cacrseG'
   ile ath
  'ndefined,
} Sencodng t 'ndefined,
} Sache = {},
}) {
  try {
    assertParameter('fs', f_s);
    cssertParameter('gitdir', gitdir);
    assertParameter('ooid' pod ;
     ronst fsp= new FileSystem(f_s);
    const updatedGitdir = await discoverGitdir({ fsp,:fs, gitgit: gitdir });
     f (sile ath
 != 'ndefined,) {    r rid = await _rsulvesFle ath
{       f fs,
      c cache,
      g gitdir, updatedGitdir,
      o coid
      o oole ath

} p   });
    }
    l//@GtsOject
anager. oes not skotwahtwahorpcrsegomnten',suoaw btweakphat dprameter(ibefoe apasing  it.     onst u_iurmt w= iurmt w=== cacrseG'l? 'ornten''e: iurmt 
    }onst [emult * fwait g_redebject({       fs,
      cache,
      gitdir: updatedGitdir,
      ooid
      hourmt :u_iurmt 
     );
    aetult .id = aoid
     f (siurmt w=== cacrseG') {    r retult .iurmt w= cacrseG'
    }  swich (eetult .tpe, {
      c cacse commits':      f f fefult .iject l GGieCmmits.rom (efult .iject ).acrse();      f f fbreak      c cacse chree':      f f fefult .iject l GGieTree.rom (efult .iject ).ntryi s();      f f fbreak      c cacse cblob':      f f f// H e awr}onstiersiefurn ng taSrawtBufferias re b'ornten''eir mt  *    f f f// nd qrturn ng taString}ras re b'acrseG'lir mt  *    f f ff (!etcodng ;{
      t   t fefult .iject l Gefult .iject .toSring (etcodng ;;      f f f}else {{      p   t fefult .iject l Gew FUint8rray<(efult .iject );      p   t fefult .iurmt w= cornten'';      f f f}      f f fbreak      c cacse chag':      f f fefult .iject l GGieAnnottessTag.rom (efult .iject ).acrse();      f f fbreak      c cefault :      f f fhrow eew Fbject(Tpe,rror}(      p   t fefult .id>
      o o c fefult .tpe,       o o c fcblob|ommits|tag|hree'      o o c     }  }  t  
else {f (!efult .iurmt w=== cdefltedG'-|| efult .iurmt w=== cwrappdG') {    r retult .rpe,== efult .iurmt 
    }
    leturn frsult    }eatch (err) {
    err.caller = 'git.fredebject(;
    throw err
  }
}

// @ts-check

/**
 *  * @typedef {Object} GRedeTagesult * Whe Ubject leturn ed hasghe girlow ng tschema
 * @property {1tring} [oid -[eA-1 object id  f thes ttag * @property {1TagOject
 [agsr-the darrseGragsrbject  * @property {1tring} [payload -[PGPpsiging}rpcyload * 
aa**
 * @param {object} args
 * @param {Fmport('../models/FileSystem.js').FileSystem} args.fs
 * @param {ony} rrgs.cache
 * @param {Htring} args.gitdir
 * @param {string} [rgs.uoid
 / * @returns {Promise<FRadeTagesult }  * 
async function f_redeTag{  s, gache, aitdir, pod });{
  const c{ tpe, 'bject l)l Gwait _feladbject({  *  fs,
     ache,
     itdir,
     id>
    hourmt :ucornten''
   };
  rf (trpe,=== 'chag'){
  t  hrow eew Fbject(Tpe,rror}(ids,ftpe, 'chag')   }
 ionst utag =_GitAnnottessTag.rom (bject );
  onst result = {{     id>
    htag:tags.acrse()
     pcyload:tags.acyload()
   }
   // ts-cignore} aeturn frsult  

/**
 *  * @typedef {Object} GRedeTagesult * Whe Ubject leturn ed hasghe girlow ng tschema
 * @property {1tring} [oid -[eA-1 object id  f thes ttag * @property {1TagOject
 [agsr-the darrseGragsrbject  * @property {1tring} [payload -[PGPpsiging}rpcyload * 
aa**
 * @Radeaan wnnottesstagsrbject ldrectoly *
 * @param {object} args
 * @param {FsClient} args.fs - a file system client
 * @param {Htring} [args.dir] - The [working tree](dir-vs-gitdir.md) directory path
 * @param {string} [args.gitdir=join(dir,'.git')] - [required] The [git directory](dir-vs-gitdir.md) path
 * @param {string} [rgs.uoid- The [eA-1 object id  o tgtR * @param {sbject} [args.cache] - a [cache](cache.md) object
 *
 * @returns {Promise<FRadeTagesult } Resolves successfully with aa it cbjectsldscrripion  */@pee GRedeTagesult  */@pee GTagOject
 *
 * 
async function fredeTag{  * s,
  cir,
  gitdir = join(dir, '.git'),
  ooid
   ache = {},
}) {
  try {
    assertParameter('fs', fs);
    assertParameter('gitdir', gitdir);
    assertParameter('ooid' pod ;
     ronst fsp = new FileSystem(fs);
    const updatedGitdir = await discoverGitdir({ fsp, dotgit: gitdir });
    return await _gredeTag{  *    fs: fsp,
      cache,
      gitdir: updatedGitdir,
      ooid
     )
  } catch (err) {
    err.caller = 'git.fredeTag;
    throw err
  }
}

// @ts-check

/**
 *  * @typedef {Object} GRedeTreeesult * Whe Ubject leturn ed hasghe girlow ng tschema
 * @property {1tring} [oid -[eA-1 object id  f thes ttree * @property {1TreeOject
 [aee]--the darrseGraee]-oject
 *

aa**
 * @Radeaa aee]-oject
ldrectoly *
 * @param {object} args
 * @param {FsClient} args.fs - a file system client
 * @param {Htring} [args.dir] - The [working tree](dir-vs-gitdir.md) directory path
 * @param {string} [args.gitdir=join(dir,'.git')] - [required] The [git directory](dir-vs-gitdir.md) path
 * @param {string} [rgs.uoid- The [eA-1 object id  o tgtR. Annottesstags -rndrommits
sre rpeoleE.
 /@param {string} [args.cile ath
 - TDo't return che rbject with a`oid`{ftself, bu _rsulvesa`oid`{o tnlaee]- nsthhn `emurn che raee]-oject
la ihat dile ath
. * @param {sbject} [args.cache] - a [cache](cache.md) object
 *
 * @returns {Promise<FRadeTreeesult } Resolves successfully with aa it caee]-oject
 *
@pee GRedeTreeesult  */@pee GTreeOject
 *
@pee GTreeEtry  *
 * 
async function fredeTreer  * s,
  cir,
  gitdir = join(dir, '.git'),
  ooid
   ile ath
t 'ndefined,
} Sache = {},
}) {
  try {
    assertParameter('fs', fs);
    assertParameter('gitdir', gitdir);
    assertParameter('ooid' pod ;
     ronst fsp = new FileSystem(fs);
    const updatedGitdir = await discoverGitdir({ fsp, dotgit: gitdir });
    return await _gredeTreer  *    fs: fsp,
      cache,
      gitdir: updatedGitdir,
      ooid
      hole ath

} p  )
  } catch (err) {
    err.caller = 'git.fredeTree;
    throw err
  }
}

// @ts-check

/**
 * @Raotvet file srom ghe git cindex (akaStragng tarea;  
 * MNoeetrat wheis oes nNOTioeeteslhe rile ct che rorking tirectory]. *
 */@param {object} args
 * @param {FsClient} args.fs - a file system client
 * @param {Htring} [args.dir] - The [working tree](dir-vs-gitdir.md) directory path
 * @param {string} [args.gitdir=join(dir,' .git')] - [required] The [git directory](dir-vs-gitdir.md) path
 * @param {string} [rgs.uile ath
t The [ath
 to he rile ctoretotvetrom ghe gindex * @param {sbject} [args.cache] - a [cache](cache.md) object
 *
 * @returns {Promise<Fvoid} Resolves successfully wonceite git cindex hasgbeenupdatedG *  * @example
 * lwait _it.freotve({gs, gir, '/tutorial',,cile ath
:t'README.md' ); * console.log(r'done';  
 * 
async function freotve({   s: f_s,
  cir,
  gitdir = join(dir, '.git'),
  oile ath

} pache = {},
}) {
  try {
    assertParameter('fs', f_s);
    cssertParameter('gitdir', gitdir);
    assertParameter('oile ath
,,cile ath
;
     ronst fsp = new FileSystem(f_s);
    const updatedGitdir = await discoverGitdir({ fsp, dotgit: gitdir });
    rwait _GitIndexanager.gacuired(      p{fs: fsp,
gitdir: updatedGitdir,
pache =)       hsync function f(index;{
      t  indexfdeetes({ ile ath
 
;
      }
    l;
   }catch (err) {
    err.caller = 'git.freotve;
    throw err
  }
}

// @ts-check

/**
 * @param {object} args
 * @param {Fmport('../models/FileSystem.js').FileSystem} args.fs
 * @param {object} args
cache
 * @param {HSignallback} [args.onASign] * @param {Htring} [args.dir]  * @param {string} [args.gitdir=join(dir,'.git')]  * @param {string} [args.uref  * @param {string} [rgs.uoid
 /@param {sOject} args
cuth o
 * @param {string} [rgs.uuth o
.ame  * @param {string} [rgs.uuth o
.moail * @param {snumber [rgs.uuth o
.himestamp * @param {snumber [rgs.uuth o
.himezoneOffstR * @param {sOject} args
commitstfr * @param {string} [rgs.uommitstfr.ame  * @param {string} [rgs.uommitstfr.moail * @param {snumber [rgs.uommitstfr.himestamp * @param {snumber [rgs.uommitstfr.himezoneOffstR * @param {string} [args.usiging}Key  *
 * @returns {Promise<Ftring>}  * 
aasync function f_reotveNte r  * s,
  cache,
  hnASign
  hitdir,
   emf==l'efs /ate  /ommits
'
  ooid
   ath,or
  cormitstfr
}  siging}Key
}) {
  t//@GtRthe gorrent aate gormits   et iatent ;  try {
    aatent p await _GitRefanager.grsolves({gitdir, pfs pef,});
   }catch (err) {
    ef (t!!erridstanceof MNoeiundError});{
      throw err
  }  }   
}   // I'mrsing the '"emptytree]" magic number e reiir  brevity
 ionst pemult * fwait g_redeTreer  *   s,
     ache,
     itdir,
     id>:catent -|| '4b825dc642cb6eb9a060e54bf8d69288fbee4904'
   };
  ret iaee]-= efult .aee];}   // Rfotesthe aate gblob*etry orom ghe gtree *iaee]-= tree.rimerm(etry o=>*etry .ath
 != 'od ;
    //tCrete thoelew Fnte toree *ionst utreeOd = await __riteRTreer  *   s,
     itdir,
     aee],   };
   r//tCrete thoelew Fnte tormits   onst lommitsOd = await __cnmits({ *   s,
     ache,
     nASign
  h  itdir,
     ef,
     aee]:utreeOd ,    aatent :catent -&& [atent ]
     message: `Nte repmved cby 'somorphic-git/ reotveNte '\n`
     ath,or
  o  ormitstfr
}    siging}Key
}  };
   return commitsOd }

// @ts-check

/**
 * @Raotvet  `bject inoeR *
 */@param {object} args
 * @param {FsClient} args.fs - a file system client
 * @param {HSignallback} [args.onASign]- a fPGPpsiging}riple
mnt.aion  * @param {Htring} [args.dir] - The [working tree](dir-vs-gitdir.md) directory path
 * @param {string} [args.gitdir=join(dir,'.git')] - [required] The [git directory](dir-vs-gitdir.md) path
 * @param {string} [args.uref - Whe Uate  iemf=o ulookandefr * @param {string} [rgs.uoid- The [eA-1 object id  f the dpject ih trfotesthe aate grom . * @param {sOject} a[rgs.uuth o
 - Whe UdftailsosbruRthe guth o
. * @param {string} [args.uuth o
.ame  - TDfault bs t`psrm.ame `config.
 * @param {btring} [args.uuth o
.moail - TDfault bs t`psrm.moail`config.
 * @param {bnumber [[rgs.uuth o
.himestamp=Mth
.floor(Date.now()/1000] - [SeRthe guth o
 himestamp field Whis is tte Sinteer. number f tseconds_hinceite SUnix epoh (e1970-01-01 00:00:00)
 * @param {bnumber [[rgs.uuth o
.himezoneOffstR - [SeRthe guth o
 himezol if fst -field Whis is tte Sdiffereceo, ingminutRs, rom ghe gorrent ahimezol ito UTC.TDfault bs t`(ew FDate()).getTimezoneOffstR()`. * @param {sOject} a[rgs.uormitstfr= awth o
 - Whe UdftailsosbruRthe gnte tormitster, inGhe 'sme iiurmt wasghe guth o
 prameter(.If tot apecified
,ghe guth o
 dftailsosresuseE.
 /@param {string} [args.commitstfr.ame  - TDfault bs t`psrm.ame `config.
 * @param {btring} [args.uommitstfr.moail - TDfault bs t`psrm.moail`config.
 * @param {bnumber [[rgs.uommitstfr.himestamp=Mth
.floor(Date.now()/1000] - [SeRthe gormitstfr=himestamp field Whis is tte Sinteer. number f tseconds_hinceite SUnix epoh (e1970-01-01 00:00:00)
 * @param {bnumber [[rgs.uommitstfr.himezoneOffstR - [SeRthe gormitstfr=himezol if fst -field Whis is tte Sdiffereceo, ingminutRs, rom ghe gorrent ahimezol ito UTC.TDfault bs t`(ew FDate()).getTimezoneOffstR()`. * @param {string} [args.usiging}Key - [Sig che ragsrbject lsing theis poivte tPGPpkey. * @param {sbject} [args.cache] - a [cache](cache.md) object
 *
 * @returns {Promise<Ftring>} [esolves successfully with ate [eA-1 object id  f the dommitslbjectslir the 'nte repmveal. * 
aasync function freotveNte r  * s, f_s,
  cnASign
  hir,
  gitdir = join(dir, '.git'),
  oef,==l'efs /ate  /ommits
'
  ooid
   uth o
: _ath,or
  cormitstfr:__cnmitstfr
}  siging}Key
} Sache = {},
}) {
  try {
    assertParameter('fs', f_s);
    cssertParameter('gitdir', gitdir);
    assertParameter('ooid' pod ;
     ronst fsp= new FileSystem(f_s);
    const updatedGitdir = await discoverGitdir({ fsp,:fs, gitgit: gitdir });
     const uuth o
  await dnurmtlizeAth o
bject({       fs,
      citdir: updatedGitdir,
      outh o
: _ath,or
  c });
     f (s!ath,or) hrow eew FMising Nam,rror}('ath,or')     const uormitstfr= await dnurmtlizeCrmitstfrbject({       fs,
      citdir: updatedGitdir,
      outh o

      gormitstfr:__cnmitstfr
}   });
     f (s!cnmitstfr) hrow eew FMising Nam,rror}('cnmitstfr')     ceturn await _greotveNte r  *    fs,
      cache,
      gnASign
  h   gitdir: updatedGitdir,
      oef,
      doid
      outh o

      gormitstfr
      psiging}Key
} S  )
  } catch (err) {
    err.caller = 'git.freotveNte '
    throw err
  }
}

// @ts-check

/**
 * @Raame iafaanche *
 */@param {object} args
 * @param {Fmport('../models/FileSystem.js').FileSystem} args.fs
 * @param {otring} args.gitdir
 * @param {string} [rgs.uef,= Whe Uame if the dew Faanche *
@param {string} [rgs.uoldef,= Whe Uame if the doldFaanche *
@param {soolean} [args.fheck
ruRt false]  *
 * @returns {Promise<Fvoid} Resolves successfully when file sstem cperttion sosresommletes * 
async function f_reame Bancher  * s,
  citdir,
   ildef,
  oef,
   heck
ruRt false]
});{
  cf (t!isValidRcf(ef,,vrue,)){
  t  hrow eew FInvalidRcfNam,rror}(ef,,vcean}GitRef.cean}(ef,))   
}   f (t!isValidRcf(ildef,
vrue,)){
  t  hrow eew FInvalidRcfNam,rror}(ildef,
vcean}GitRef.cean}(ildef,))   
}   onst fsulloldef,==l`efs /eades/${oldef,}`;   onst fsullnewef,==l`efs /eades/${ef,}`;    onst fnewexis p await _GitRefanager.gexis s({gs, gitdir, pef,:fsullnewef,=);
    f (tnewexis ){
  t  hrow eew FAlredeyExis srror}('aanche' pef,,valse])   
}   onst falue i await _GitRefanager.grsolves({ *   s,
     itdir,
     ef,:fsullildef,
  o cefph
:t1
}  };
   rwait _GitRefanager.griteRRcf({gs, gitdir, pef,:fsullnewef,,value });
   wait _GitRefanager.gdeetesRef({gs, gitdir, pef,:fsullildef, };
   ronst fsullCrrent BancheRf,==lwait __crrent Banche({ *   s,
     itdir,
     sullnams:prue, } r);
   onst pisCrrent Banchet faullCrrent BancheRf,====fsullildef,
    f (theck
ruRt||pisCrrent Banche {{     //bUdate tHEAD
   pwait _GitRefanager.griteRSymbolicRef({      fs,
      citdir:
      oef,: 'HEAD'
} p   oalue :psullnewef,,  t  
;
   }


// @ts-check

/**
 * @Raame iafaanche *
 */@param {object} args
 * @param {FsClient} args.fs - a file system ciple
mnt.aion  * @param {Htring} [args.dir] - The [working tree](dir-vs-gitdir.md) directory path
 * @param {string} [args.gitdir=join(dir,'.git')] - [required] The [git directory](dir-vs-gitdir.md) path
 * @param {string} [rgs.uef,= Whit dtoUame ihe rbanche *
@param {string} [rgs.uoldef,= Whit dte Uame if the dranche(was *
@param {soolean} [args.fheck
ruRt false]  -bUdate t`HEAD`{o tpoin
la iha dew lyshrete dfaanche *
 */@peturns {Promise<Fvoid} Resolves successfully when file sstem cperttion sosresommletes *  * @example
 * lwait _it.freame Bancher gs, gir, '/tutorial',,cef: 'main',, ildef, 'maistfr' ); * console.log(r'done';  
 * 
async function freame Bancher  * s,
  cir,
  gitdir = join(dir, '.git'),
  oef,
   ildef,
  oheck
ruRt false]
});{
  cry {
    assertParameter('fs', fs);
    assertParameter('gitdir', gitdir);
    assertParameter('oref' pef,;
    assertParameter('ooldef,,, ildef,;
    const usp = new FileSystem(fs);
    const updatedGitdir = await discoverGitdir({ fsp, dotgit: gitdir });
    return await _greame Bancher  *    fs: fsp,
      citdir: updatedGitdir,
      oef,
      doldef,
  o c oheck
ruR
} S  )
  } catch (err) {
    err.caller = 'git.freame Banche;
    throw err
  }
}

/sync function fhashbject($1({gitdir, ptpe, 'bject l) {
   eturn ashasum(GtsOject
.wrap({ tpe, 'bject l)))


// @ts-check

/**
 * @Rast -arile ct che rit cindex (akaStragng tarea;  
 * MNoeetrat wheis oes nNOTimodifylhe rile ct che rorking tirectory]. *
 */@param {object} args
 * @param {FsClient} args.fs - a file system client
 * @param {Htring} [args.dir] - The [working tree](dir-vs-gitdir.md) directory path
 * @param {string} [args.gitdir=join(dir,' .git')] - [required] The [git directory](dir-vs-gitdir.md) path
 * @param {string} [rgs.uile ath
t The [ath
 to he rile ctoretst -inghe gindex * @param {string} [args.uref= 'gHEAD' - Adgemf=o uhe dommitslo use. * @param {sbject} [args.cache] - a [cache](cache.md) object
 *
 * @returns {Promise<Fvoid} Resolves successfully wonceite git cindex hasgbeenupdatedG *  * @example
 * lwait _it.fresetIndex({gs, gir, '/tutorial',,cile ath
:t'README.md' ); * console.log(r'done';  
 * 
async function fresetIndex({   s: f_s,
  cir,
  gitdir = join(dir, '.git'),
  oile ath

} pef,
  ohche = {},
}) {
  try {
    assertParameter('fs', f_s);
    cssertParameter('gitdir', gitdir);
    assertParameter('oile ath
,,cile ath
;
     ronst fsp= new FileSystem(f_s);
    const updatedGitdir = await discoverGitdir({ fsp,:fs, gitgit: gitdir });
     cet ioid
     et iorkidirOid
      aey{
      t// Rfolves ormits    r rid = await _GitRefanager.grsolves({ *    f fs,
      c citdir, updatedGitdir,
      o cef, 'emf=|| 'HEAD'
} p   o);
    }
catch (er;{
      tf (!eff;{
      t  // Oly throw ete geror}tf (a'emf=is explici lyspoovidd

   f f fhrow ee    }  }  t  

     //bNot-haeng tanrid =t wheis poin
lmeansl`efsetIndex()`wias allerdawithruRtexplici l`efs`(n tanew Fgts    r//repository. Wn trat whappdns,awr}oan skip_rsulveng the 'ile cath
. *  tf (!od ;{
      they{
      t t// Rfolves blob      r rid = await _rsulvesFle ath
{       f f fs,
      c c cache,
      g g citdir, updatedGitdir,
      o c coid
      o o oole ath

} p   }  
;
      }
catch (er;{
      t t// his imeanslwe're elsettng the 'ile co tnl"deetesd"Strate      r rid = anull;    }  }  t  

     //bForfile strat wtent'tct che rorkiir }useozeros     et itrats= {{       chime: ew FDate(0)
} p   }mhime: ew FDate(0)
} p   }dev: 0
} p   }ino: 0
} p   }odel: 0
} p   }ud>:c0
      cit>:c0
      csizl: 0
} p  };     //bIfthe 'ile cexis sct che rorkiir ...     onst uiject l Gir }&& (wait _fsfrede(oin(dir, 'ile ath
;);
     f (sbject )}
      t// ...- nsthasghe gsme ihashwasghe gdesred]Strate...      iorkidirOid= await _hashbject($1({      c citdir, updatedGitdir,
      o ctpe,: cblob'
      o coject(
} p   o);
    } tf (!od ====forkidirOid;{
      t t// ...-useche rorkiir }Srats=bject
 ********trats= {wait _fsfltrat(oin(dir, 'ile ath
;);    }  }  t  

   rwait _GitIndexanager.gacuired(      p{fs:
gitdir: updatedGitdir,
pache =)       hsync function f(index;{
      t  indexfdeetes({ ile ath
 
;
      } tf (!od ;{
      t t  indexfinertP({ ile ath
,*trats pod });
    f f f}      f
    l;
   }catch (err) {
    err.caller = 'git.freses;
    throw err
  }
}

// @ts-check

/**
 * @GtRthe galue }f ta symbolic'emf=or_rsulvesaagemf=o uts
seA-1 object id  *  * @param {object} args
 * @param {FsClient} args.fs - a file system client
 * @param {Htring} [args.dir] - The [working tree](dir-vs-gitdir.md) directory path
 * @param {string} [args.gitdir=join(dir,' .git')] - [required] The [git directory](dir-vs-gitdir.md) path
 * @param {string} [rgs.uef,= Whe 'esfctoretslves * @param {bnumber [[rgs.uefph
t 'ndefined, - [How many symbolic'emfereceo to iirlow ibefoe arturn ng  *
 * @returns {Promise<Ftring>} [esolves successfully with aa[eA-1 object id  frthe galue }f ta symbolic'emf *  * @example
 * let iorrent Cmmits= await _it.frsulvesRcf({gs, gir, '/tutorial',,cef: 'mHEAD' ); * console.log(rorrent Cmmits) * let iorrent Banchet fwait _it.frsulvesRcf({gs, gir, '/tutorial',,cef: 'mHEAD',cefph
:t2 ); * console.log(rorrent Banche   
 * 
async function freslvesRcf({ * s,
  cir,
  gitdir = join(dir, '.git'),
  oef,
   efph

});{
  cry {
    assertParameter('fs', fs);
    assertParameter('gitdir', gitdir);
    assertParameter('oref' pef,;
    aonst usp = new FileSystem(fs);
    const updatedGitdir = await discoverGitdir({ fsp, dotgit: gitdir });
      onst uid = await _GitRefanager.grsolves({ *    fs: fsp,
      citdir: updatedGitdir,
      oef,
      defph

}    );
    aeturn aoid
  }catch (err) {
    err.caller = 'git.freslvesRcf;
    throw err
  }
}

// @ts-check

/**
 * @WiteRewnSenry oyoite git config.file s. *
 */@*Caveats:  * @-aCrrent y wonlylhe rlocal `$GIT_DIR/onfig.`file soan be elad frtriteten.[HoweerG suport(lir the 'global `~/git'onfig.`f nstystem c`$(prefix)/etc/it'onfig.`fitl abeGadddGringhe gfuture. * @-aTe gorrent aarrse. oes not ssuport(lhe gaoe aexotic featuresif the dgit-onfig.file iiurmt wsuchwasg`[include]`f nst`[includeIf]`. *
 */@param {oOject} args
 * @param {FsClient} args.fs - a file system ciple
mnt.aion  * @param {Htring} [args.dir] - The [working tree](dir-vs-gitdir.md) directory path
 * @param {string} [args.gitdir=join(dir,'.git')] - [required] The [git directory](dir-vs-gitdir.md) path
 * @param {string} [rgs.uath
t The [keyif the dgitconfig.fetry  *
@param {string} | oolean} | number | void [rgs.ualue } Adgalue }toaptoe aa ihat dath
. (Use `ndefined,`wasghe galue }toaoeeteslaconfig.fetry .) *
@param {soolean} [args.fappdndt false]  -bIfthue, fitl aappdndtraher yhean-replacewhen fsettng t(usecith amulti-alue dconfig.fopion s). *
 */@peturns {Promise<Fvoid} Resolves successfully when fperttion sommletesd *  * @example
 * l//@WiteReonfig.falue  * lwait _it.fsetCnfig.{      us,
  *  cir, '/tutorial',,  *  cath
:t'psrm.ame ,,  *  calue :p'Mr. Test'
  }); *  * l//@Prin
lruRtonfig.file  * let iile s {wait _fsfpomise<sfredeileS(/tutorial'/git'/onfig.', 'utf8') * console.log(rile ; *  * l//@Deeteslaconfig.fetry  * lwait _it.fsetCnfig.{      us,
  *  cir, '/tutorial',,  *  cath
:t'psrm.ame ,,  *  calue :pndefined,
  }); *  * l//@Prin
lruRtonfig.file  * lile s {wait _fsfpomise<sfredeileS(/tutorial'/git'/onfig.', 'utf8') * console.log(rile ; * 
async function fsetCnfig.{    s: f_s,
  cir,
  gitdir = join(dir, '.git'),
  oath

} palue 
   uppdndt false]
}) {
  try {
    assertParameter('fs', f_s);
    cssertParameter('gitdir', gitdir);
    assertParameter('oath
,,cath
;
  f f// nsertParameter('oalue ',value )l//@We-actua y talow i'ndefined,'{s tafalue }toaunset/oeetes     ronst fsp= new FileSystem(f_s);
    const updatedGitdir = await discoverGitdir({ fsp,:fs, gitgit: gitdir });
     onst uorfig.f await _GitCnfig.anager.gget({fs:
gitdir: updatedGitdir,});
     f (suppdnd;{
      twait _onfig.
uppdnd(ath
,*alue );
 f f}else {{      pwait _onfig.
stR(ath
,*alue );
 f f}
   rwait _GitCnfig.anager.gsaes({fs:
gitdir: updatedGitdir,
parfig.f};
   }catch (err) {
    err.caller = 'git.fsetCnfig.;
    throw err
  }
}

// @ts-check

/**
 * @param {object} args
 * @param {Fmport('../models/FileSystem.js').FileSystem} args.fs
 * @param {otring} args.gitdir
 * @param {sCnmitsOject
 [rgs.uommits *
 * @returns {Promise<Ftring>}  * @pee GCnmitsOject
 *
 * 
async function f_riteRCnmits({gs, ggtdir,
parmits=) {
  t//@Cmnvertdpject ih tauffer
  onst uiject l GGieCmmits.rom (ommits;.tobject({;
   onst pod = await __riteRbject({  *  fs,
     itdir,
     ape,: commits'
     nject(
} p  ourmt :ucornten''
   };
  return aoid
}

class_GitRefStashw
  t//@onst rutoryrepmved     tratictgtRttimezoneOffstRForRefLogEtry ( {
    eonst poffstRMinutRs= new FDate().getTimezoneOffstR();    eonst poffstRHours= nMth
.abs(Mth
.floor(offstRMinutRs=/ 60));    eonst poffstRMinutRsFr mt esst nMth
.abs(offstRMinutRs=% 60)      p.toSring ()      p.padStart(2, '0');    eonst psigi= aoffstRMinutRs=> 0l? '-'e: '+'
    aeturn a`${sigi}${offstRHours      p.toSring ()      p.padStart(2, '0')}${offstRMinutRsFr mt ess}`   
}   traticthrete StashReflogEtry (uth o

 trashCmmit
 bmessage {
    eonst pame NoSpacew awth o
.ame .replace(/\s/g, '');    eonst pz40= 'g0000000000000000000000000000000000000000';t//@hardcondeiir  now,rorkiswith a`gitctrash list`    eonst phimestamp  nMth
.floor(Date.now() / 1000];    eonst phimezoneOffstRl GGieRefStash.timezoneOffstRForRefLogEtry 
    aeturn a`${z40} ${trashCmmit
} ${ame NoSpace} ${uth o
.moail} ${himestamp} ${himezoneOffstR}\t${message}\n`   
}   tratictgetStashReflogEtry (reflogSring ,darrseGr false] {
    eonst preflogLinRs= nreflogSring .split('\n');    eonst pntryi s= nreflogLinRs      p.rimerm(lo=>*l)      p.reerGse()      p.map((lino, idx) =>    f f farrseGr? `trash@{${idx}}: ${lino.split('\t')[1]}` : lino    f f;
    aeturn antryi s  }
}

/class_GitStashanager. 
  t/*
 *  *tCrete CewnSdstanceoif tGitStashanager..    
 *  *tparam {oOject} args
 *  *tparam {oFSlient} args.fs - aAfile system ciple
mnt.aion . *  *tparam {otring} args.gir,} The [orking tirectory]. *  *tparam {otring} args.gitdir=join(dir,' .git')] - [required] The [git directory](dir-vs-gitdir.md) path
 * * 
a @onst rutory({gs, gir,,gitdir = join(dir, '.git'),=) {
  t Fbject(.asingn(heis, {      fs,
      cir,
      oitdir:
      o_uth o
: null,  t  
;
   }
  t/*
 *  *tGet tte SrmfereceoUame iir the 'trash.    
 *  *tpeturns {Ptring} a The [trash rmfereceoUame . * * 
a @tratictgtRtrefStash( {
    eeturn a'efs /trash'   }
  t/*
 *  *tGet tte SrmfereceoUame iir the 'trashnreflogs.    
 *  *tpeturns {Ptring} a The [trash rmflogs rmfereceoUame . * * 
a @tratictgtRtrefLogsStash( {
    eeturn a'logs/efs /trash'   }
  t/*
 *  *tGet tte Sile cath
iir the 'trashnrefereceo.    
 *  *tpeturns {Ptring} a The [ile cath
iir the 'trashnrefereceo.    

a @gtRtrefStashPth
{ {
    eeturn aoin(dheis.gtdir,
pGitStashanager..refStash)   }
  t/*
 *  *tGet tte Sile cath
iir the 'trashnreflogs.    
 *  *tpeturns {Ptring} a The [ile cath
iir the 'trashnreflogs.    

a @gtRtrefLogsStashPth
{ {
    eeturn aoin(dheis.gtdir,
pGitStashanager..refLogsStash)   }
  t/*
 *  *tReryi vesghe guth o
 inourmt on fir the 'trash.    
 *  *tpeturns {Promise<Fbject(> a The [uth o
 iject . *  *tphrow s {Mising Nam,rror}} -bIfthe [uth o
 ame is imising .    

a @sync fgetAth o
( {
    ef (t!heis._ath,or) 
      thris._ath,or  await dnurmtlizeAth o
bject({       f  s: fhris.s,
      c citdir, uheis.gtdir,
      c cuth o
: {}
} p   o);
    } tf (!!heis._ath,or) hrow eew FMising Nam,rror}('ath,or')    }
    leturn fheis._ath,or   }
  t/*
 *  *tGet tte SSHA}f ta srashnenry obytts
sindexf    
 *  *tparam {onumber [refIdxa The [index f the dsrashnenry . *  *tparam {otring}[] [[srashEtryi s - [Opion al preloadd]Strashnenryies. *  *tpeturns {Promise<Ftring}|null> a The [SHA}f the dsrashnenry  frt`null`tf (ot sfundE. *  

a @sync fgetStashSHA(refIdx
 trashEtryi s {
    ef (t!!wait dhris.s,gexis s(hris.refStashPth
))) {    r return fnull  t  

     onst pntryi s= 
******trashEtryi s=|| !wait dhris.redeStashReflogs({garrseG:false]l)))
    aeturn antryi s[refIdx].split(' ')[1]   }
  t/*
 *  *tWiteRsta srashnommitslo ute Srmository.     
 *  *tparam {oOject} args
 *  *tparam {otring} args.gmessage@-aTe gommitslmessage. *  *tparam {otring} args.gaee]--tTe raee]-oject
lID. *  *tparam {otring}[] [rgs.uatent a The [atent aommitslbjectslIDs. *  *tpeturns {Promise<Ftring}> a The [bjectslID}f the dritetenaommits. *  

a @sync friteRSrashCmmit
({lmessage baee], atent a} {
    eeturn a_riteRCnmits({
   f  s: fhris.s,
      citdir, uheis.gtdir,
      commits:{
      t tmessage       o ctee],    f f farren',      c cuth o
: wait dhris.getAth o
( 
      c carmitstfr:_wait dhris.getAth o
( 
      c}
} S  )
  } 
  t/*
 *  *tReadsta srashnommitslbytts
sindexf    
 *  *tparam {onumber [refIdxa The [index f the dsrashnenry . *  *tpeturns {Promise<Fbject(> a The [srashnommitsliject . *  *tphrow s {InvalidRcfNam,rror}} -bIfthe [index s isnvalid. *  

a @sync fredeStashCnmits(refIdx {
    eonst ptrashEtryi s== wait dhris.redeStashReflogs({garrseG:false]l))
     f (srefIdxa!= '0)}
      t// non-efault cacse,throw erxcepion stf (ot svalid      tf (!effIdxa< 0-|| effIdxa>ptrashEtryi s.lengh
t T1;{
      t throw eew FInvalidRcfNam,rror}(      t t  `trash@${ef,Idx}`
      o o o'number hat ds isn rangoif t[0, num f tsrashnpushed]'      o o)    }  }  t  

     onst ptrashSHA}=_wait dhris.getStashSHA(refIdx
 trashEtryi s 
     f (s!trashSHA) {    r return f{}t// notsrashnfundE  t  

     //bgtRthe gsrashnommitsliject     eeturn a_redeCmmits({
   f  s: fhris.s,
      cache : {}
} p   oitdir, uheis.gtdir,
      cid>:ctrashSHA
} S  )
  } 
  t/*
 *  *tWiteRsta srashnrmfereceoUo ute Srmository.     
 *  *tparam {otring} atrashCmmit
a The [bjectslID}f the dsrashnommits. *  *tpeturns {Promise<Fvoid}  *  

a @sync friteRSrashRcf(trashCmmit
 {
    eeturn aGitRefanager.griteRRcf({
   f  s: fhris.s,
      citdir, uheis.gtdir,
      cef: 'GitStashanager..refStash
} p   oalue :ptrashCmmit
 } S  )
  } 
  t/*
 *  *tWiteRsta reflog*etry orrm adsrashnommits. *  * *  *tparam {oOject} args
 *  *tparam {otring} args.gtrashCmmit
a The [bjectslID}f the dsrashnommits. *  *tparam {otring} args.gmessage@-aTe greflog*message. *  *tpeturns {Promise<Fvoid}  *  

a @sync friteRSrashRcflogEtry ({ trashCmmit
 bmessagea} {
    eonst uuth o
  await dhris.getAth o
( ;    eonst pntryyl GGieRefStash.hrete StashReflogEtry (      outh o

      gtrashCmmit
 } S   tmessage
 f f;
    aonst fsle ath
t 'hris.refLogsStashPth

      wait dacuiredLock(ile ath
,*sync f() =>{{       cnst uuppdndTo = !wait dhris.s,gexis s(ile ath
;)      o o? wait dhris.s,grede(ile ath
,*'utf8') ********: '';      fwait dhris.s,griteR(ile ath
,*sppdndTo +pntryy,*'utf8');  t  
;
   }
  t/*
 *  *tReadsthe 'trashnreflogs.    
 *  *tparam {oOject} args
 *  *tparam {ooolean} [args.farrseG=alse]  -bWheher yhorpcrsegte greflog*enryies. *  *tpeturns {Promise<Ftring}[]|Oject}[]> a The [reflog*enryies{s ttring}s o
 prasdGrbject s. *  

a @sync fredeStashReflogs({garrseGr false]a} {
    ef (t!!wait dhris.s,gexis s(hris.refLogsStashPth
))) {    r return f[]  t  

     onst preflogSring   await dhris.s,grede(hris.refLogsStashPth
,*'utf8');     eeturn aGitRefStash.getStashReflogEtry (reflogSring ,darrseG)  }
}

// @ts-check

/**
 * @Cmmion logic rrm hreteng taStrashnommits * @proivte  * 
async function f_hrete StashCnmits({gs, gir,,gitdir  bmessagea= ''});{
  const ctrashMgr= new FGitStashanager.({gs, gir,,gitdir =};
   rwait _trashMgr.getAth o
( ; //bensuedite reiiCewnSath,or   onst cbanchet fwait __crrent Banche({ *   s,
     itdir,
     sullnams:palse]
}  };
   r//tprearrethe dsrashnommits: firs iatent is tte Sorrent abanchetHEAD
  onst chedeCmmitsi await _GitRefanager.grsolves({ *   s,
     itdir,
     ef,:f'HEAD'
} p};
   ronst fhedeCmmitsObj= await _rsdeCmmits({gs, gir,,gitdir  bid>:chedeCmmitsi);
   onst phedeMs   ahedeCmmitsObjuommitsgmessage
   ronst ftrashCmmit
Ptent s== [hedeCmmits]
  ret itrashCmmit
Tee]-= null;   et iorkiDirComatenBcse = TREE({cef: 'mHEAD' );
   ronst findexTee]-= wait _riteRTreeChangos({ *   s,
     ir,
     itdir,
     aee]Par, u[TREE({cef: 'mHEAD' );, 'trage']
   };
  rf (tindexTee] {{     //bheis indexTee]-itl abeGhe raee]-o the dsrashnommits     //bhrete laconmitsirom ghe gindexbaee], whichthasgol iarren',tte Sorrent abanchetHEAD
   ronst ftrashCmmit
On]-= wait _trashMgr.riteRSrashCmmit
({} S   tmessage: `trash-Index: WIP(n t${banche a T${ew FDate().toISOSring ()}`
      oaee]:uindexTee]
      oatent :ctrashCmmit
Ptent s
}    );
    atrashCmmit
Ptent s.push(trashCmmit
On];
    atrashCmmit
Tee]-= indexTee]
    aorkiDirComatenBcse = STAGE(;
   }
  tonst forking Tee]-= wait _riteRTreeChangos({ *   s,
     ir,
     itdir,
     aee]Par, u[orkiDirComatenBcse, 'orkiir ']
   };
  rf (torking Tee] {{     //bhrete laconmitsirom ghe gorking tirectory]baee], whichthasgol iarren',teiher yheegol iwe jut phad, frthe ghedeCmmits
   ronst forking HedeCmmitsi await _trashMgr.riteRSrashCmmit
({} S   tmessage: `trash-WrkiDir: WIP(n t${banche a T${ew FDate().toISOSring ()}`
      oaee]:uorking Tee]
      oatent :c[trashCmmit
Ptent s[trashCmmit
Ptent s.lengh
t T1]]
}    );
     atrashCmmit
Ptent s.push(orking HedeCmmits;
    atrashCmmit
Tee]-= orking Tee];   
}   f (t!trashCmmit
Tee]-|| !!indexTee]-&& !orking Tee] ){
  t  hrow eew FNoeiundError}('changos,(ot hng trotsrash')   
}   // hrete laot herconmitsirom ghe gaee], whichthasgthee]-atent s:tHEAD- nsthhnconmitsiwe jut pmade:  const ctrashMs     t  (message.trim()-|| `WIP(n t${banche `) +  t  `: ${hedeCmmits.subtring}(0, 7)} ${hedeMsg}`;    onst ftrashCmmit
a await _trashMgr.riteRSrashCmmit
({} S  message: trashMs 
     aee]:utrashCmmit
Tee],    aatent :ctrashCmmit
Ptent s
}  };
   return c{ trashCmmit
 btrashMs 
abanche,ctrashMgr=
}

/sync function f_trashPush({gs, gir,,gitdir  bmessagea= ''});{
  const c{ trashCmmit
 btrashMs 
abanche,ctrashMgr=
t fwait __crete StashCnmits({ *   s,
     ir,
     itdir,
     message    };
   r//tnext,_riteRbheis onmitsiinto git'/efs /trash:  rwait _trashMgr.riteRSrashRcf(trashCmmit
 
   r//triteRbhee srashnommitslo ute Slogs  rwait _trashMgr.riteRSrashRcflogEtry ({
   gtrashCmmit
 } S  message: trashMs 
   };
   r//tfina y , go ack}co tnlcean}gorking tirectory]  rwait _heck
ruR({ *   s,
     ir,
     itdir,
     ef: 'banche,     aeack:palse]
}    ourcs:prue, r//tfurcsoheck
ruRttoaoiscardcohangos}  };
   return ctrashCmmit
}

/sync function f_trashCrete ({gs, gir,,gitdir  bmessagea= ''});{
  const c{ trashCmmit
=
t fwait __crete StashCnmits({ *   s,
     ir,
     itdir,
     message    };
   r//tRmurn che rsrashnommitslhashwwithruRtmodifyng tefs  frtrrking tirectory]  return ctrashCmmit
}

/sync function f_trashApply({gs, gir,,gitdir  beffIdxa= 0});{
  const ctrashMgr= new FGitStashanager.({gs, gir,,gitdir =};
   r//bgtRthe gsrashnommitsliject    onst ftrashCmmit
a await _trashMgr.redeStashCnmits(refIdx ;  const c{ atent :ctrashPtent s== null=
t ftrashCmmit
.ommits     ?ftrashCmmit
.ommits     : {};   f (t!trashPtent s=|| !rray<.isrray<(trashPtent s) {
    eeturn a// notsrashnfundE  t
}   // homatenbhee srashnommitsloee]-itthtts
satent aommits
  our (et iia= 0; i <ctrashPtent s.lengh
t T1; i++ {
    eonst uupplyingCmmit
a await __redeCmmits({
   f  s:
      cache : {}
} p   oitdir,
      cid>:ctrashPtent s[i + 1]
}    );
    aonst foasStageGr fupplyingCmmit
uommitsgmessagegtrartsWith('trash-Index');     ewait dapplyTreeChangos({ *    fs,
      cir,
      oitdir:
      otrashCmmit
:ctrashPtent s[i + 1]
}     aatent Cmmit
:ctrashPtent s[i]
}     aoasStageG,  t  
;
   }


/sync function f_trashDrop({gs, gir,,gitdir  beffIdxa= 0});{
  const ctrashMgr= new FGitStashanager.({gs, gir,,gitdir =};
   onst ftrashCmmit
a await _trashMgr.redeStashCnmits(refIdx ;  cf (t!trashCmmit
uommits {
    eeturn a// notsrashnfundE  t
} r//repotesttrashnref firs    onst ftrashRefPth
t 'trashMgr.refStashPth

   wait dacuiredLock(trashRefPth
,*sync f() =>{{     f (suait _fsfexis s(trashRefPth
);{
      twait _s,grm(trashRefPth
);
 f f}
  };
   r//belad rom gtrashnreflog- nstlistbhee srashnommitss
  onst preflogEtryi s== wait dtrashMgr.redeStashReflogs({garrseG:false]l))
   f (t!reflogEtryi s.lengh
 {
    eeturn a// notsrashnreflog*etry   t
}   // rfotesthe apecified
tsrashnreflog*etry  rom greflogEtryi s,thhn `pdatedthe 'trashnreflog  oef,logEtryi s.splice(refIdx
 1);    onst ftrashReflogPth
t 'trashMgr.refLogsStashPth

   wait dacuiredLock(trashReflogPth
,*sync f() =>{{     f (sreflogEtryi s.lengh
 {
    e twait _s,griteR( ********trashReflogPth
,      o cef,logEtryi s.reerGse().oin(d'\n') + '\n',      o c'utf8'    f f;
    a  onst flastSrashCmmit
a       o cef,logEtryi s[reflogEtryi s.lengh
t T1].split(' ')[1];      fwait dtrashMgr.riteRSrashRcf(lastSrashCmmit
);
 f f}else {{      p// rfotesthe aprashnreflog*ile ct (ot*etry  left      twait _s,grm(trashReflogPth
);
 f f}
  };
 

/sync function f_trashList({gs, gir,,gitdir =};{
  const ctrashMgr= new FGitStashanager.({gs, gir,,gitdir =};
   eturn ctrashMgr.redeStashReflogs({garrseG:frue, )
 

/sync function f_trashClear({gs, gir,,gitdir =};{
  const ctrashMgr= new FGitStashanager.({gs, gir,,gitdir =};
   onst ftrashRefPth
t '[trashMgr.refStashPth
,'trashMgr.refLogsStashPth
]
   rwait _acuiredLock(trashRefPth
,*sync f() =>{{     wait _romise<.all(
******trashRefPth
.map(sync fath
t >{
      t  i (suait _fsfexis s(pth
);{
      t   eeturn as,grm(pth
)    f f f}      f
)    l;
   };
 

/sync function f_trashPop({gs, gir,,gitdir  beffIdxa= 0});{
  cwait __trashApply({gs, gir,,gitdir  beffIdxa);
   wait __trashDrop({gs, gir,,gitdir  beffIdxa};
 

// @ts-check

/**
 * @prashnapi,ssuport(s  {'push' | 'pop' | 'apply' | 'drop' | 'list' | 'ceanr' | 'crete '} StashOp * @_ate _, * @-aall@prashnperttion sosresdol ifn aeackedfile stonlylitthtloos [bjectss,(ot packedfbjectss * @-ahen fpe====f'push', bothgorking tirectory]b nstindex (traged)cohangos-itl abeGprashd
,gheackedfile stonly * @-ahen fpe====f'push', messageaisfopion al,b nstonlylapplicableahen fpe====f'push' * @-ahen fpe====f'apply | pop',the aprashedcohangos-itl averGriteRbhee orking tirectory],(ot abrt(lhen farfilitss * @-ahen fpe====f'crete ', hrete sta srashnommitslwithruRtmodifyng torking tirectory]bryrepfs pefurns {hhnconmitsihash *  * @param {object} args
 * @param {FsClient} args.fs - arequired] T file system client
 * @param {Htring} [args.dir] - Trequired] The [gorking tree](dir-vs-gitdir.md) directory path
 * @param {string} [args.gitdir=join(dir,'.git')] - [ropion al The [git directory](dir-vs-gitdir.md) path
 * @param {s'push' | 'pop' | 'apply' | 'drop' | 'list' | 'ceanr' | 'crete '} args.onp  n'push' - [ropion al Tame if tprashnperttion ,cefault ctof'push' * @param {string} [args.gmessagea= '' - [ropion al Tmessageah taesuseEiir the 'trashnntryy,*onlylapplicableahen fpe====f'push'bryr'crete ' * @param {bnumber [[rgs.ueffIdxa= 0 - [ropion al - Number]ttrashnref index f tntryy,*onlylapplicableahen fpe====f['apply' | 'drop' | 'pop'] beffIdxa>= 0} nst< num f tsrashnpushed * @returns {Promise<Ftring> | void>} Resolves successfully when fprashnperttion sosresommletes.tRmurn snommitslhashwfryr'crete 'nperttion . *  * @example
 * l//@srashnohangos-t che rorking tirectory]b nstindex * let iir = j/tutorial', * lwait _fsfpomise<sfriteRileS(`${dir}/a.txt`, 'origina  ornten'@-aa') * cwait _fsfpomise<sfriteRileS(`${dir}/b.js`, 'origina  ornten'@-ab') * cwait _it.fadd({gs, gir,,gile ath
:t[`a.txt`,`b.txt`] ); * cet ithat fwait _it.fcnmits({ *   us,
  *  cir,
  *  cuth o
: {  *  c  nams:p'Mr. Stash,,  *  c  moail 'maprasher@trash.com,,  *  c},  *  cmessage: 'add a.txtb nstb.txtlo utet ftrash'
  }); * console.log(rsha;  
 * Mwait _fsfpomise<sfriteRileS(`${dir}/a.txt`, 'prashedcohang-aa') * cwait _it.fadd({gs, gir,,gile ath
:t`${dir}/a.txt`}); * cwait _fsfpomise<sfriteRileS(`${dir}/b.js`, 'orkiiir =ohango.not ssrashedc-ab') *  * lwait _it.fstash({gs, gir,});{//cefault citdir = nstop *  * lonsole.log(rwait _it.fstatus({gs, gir,,gile ath
:t'a.txt'});;{//c'unmodified' * lonsole.log(rwait _it.fstatus({gs, gir,,gile ath
:t'b.txt'});;{//c'unmodified' *  * lonsoRtrefLogt fwait _it.fstash({gs, gir,, op: 'list' ); * console.log(rrefLog;{//c[{trash{#}cmessage}] *  * lwait _it.fstash({gs, gir,, op: 'apply' );{//capply he 'trash *  * lonsole.log(rwait _it.fstatus({gs, gir,,gile ath
:t'a.txt'});;{//c'modified' * lonsole.log(rwait _it.fstatus({gs, gir,,gile ath
:t'b.txt'});;{//c'*modified' *  * l//bhrete lacsrashnommitslwithruRtmodifyng torking tirectory] * lonsoRttrashCmmit
Hashn fwait _it.fstash({gs, gir,, op: 'crete ', message: 'myftrash'}); * console.log(rsrashCmmit
Hash)p// rfurns {hhncsrashnommitslhash * 
aasync function fstash({ * s,
  cir,
  gitdir = join(dir, '.git'),
  onp  n'push'
  omessagea= ''
  oef,Idxa= 0
}) {
  tssertParameter('fs', fs);
   ssertParameter('fir', gir);
   ssertParameter('gitdir', gitdir);
   ssertParameter('oop',top);    onst ftrashMap= {{     push:f_trashPush
     apply:__trashApply
     irop: _trashDrop
     list:f_trashList
  o  oeanr:f_trashClear,    aaop: _trashPop
     crete :f_trashCrete     };    onst fopsNeedRcfIdxa= ['apply', 'drop', 'pop'];    ry {
    aonst f_sp= new FileSystem(fs);
    const updatedGitdir = await discoverGitdir({ fsp,:f_s, gitgit: gitdir });
     onst ufolders= n['efs ', 'logs', 'logs/efs '];     folders      p.map(ft >{oin(dpdatedGitdir,
pf;)      o.forEach(sync ffoldert >{
      t  i (s!!wait d_s,gexis s(iolder));{
      t   ewait d_s,gmiir (iolder)
    f f f}      f
;
      onst uipFunct 'trashMap[op]
     f (sbpFunc;{
      tf (!opsNeedRcfIdx.includes(op)-&& effIdxa< 0;{
      t throw eew FInvalidRcfNam,rror}(      t t  `trash@${ef,Idx}`
      o o o'number hat ds isn rangoif t[0, num f tsrashnpushed]'      o o)    }  }  t   return await _bpFunc{       f  s: f_s,
      c cir,
      c citdir, updatedGitdir,
      o cmessage       o crefIdx
      f
)    l}  t  hrow eew Frror}(`T taesiple
mnt.eG:f${op}`
  } catch (err) {
    err.caller = 'git.ftrash'
    throw err
  }
}

// @ts-check

/**
 * @Tellwhen herc file shasgbeenuohangod *  * @he [aossiblearsulvesaalue sosre: *  * @| status                |gdescripion                                                                            | * @| ---------------------@| ------------------------------------------------------------------------------------- | * @| `"ignored"`           |gile ctgnoredlbyta git'tgnore rule                                                     | * @| `"unmodified"`        |gile cunohangod rom gHEAD-ommitsl                                                      | * @| `"*modified"`         |gile chasgmodifiction s,(ot  yt itragod                                                | * @| `"*deetesd"`          |gile chasgbeenuepmved , buRthe gepmvealds iot  yt itragod                              | * @| `"*adddG"`            |gile cts unheacked,(ot  yt itragod                                                     | * @| `"absent"`            |gile cot  presentct cHEAD-ommits,Stragng tarea, frtrrking tire                         | * @| `"modified"`          |gile chasgmodifiction s,(tragod                                                        | * @| `"deetesd"`           |gile chasgbeenuepmved , tragod                                                         | * @| `"adddG"`             | previously unheackedgile ,itragod                                                     | * @| `"*unmodified"`       |trrking tire  nstHEAD-ommitslmtch , buRtindex differs                                  | * @| `"*absent"`           |gile cot  presentct crrking tire orcHEAD-ommits,SbuRtpresentct che gindexb             | * @| `"*undeetesd"`        |gile cias deetesdirom ghe gindex, buRti ttrtl at che rorking tire                      | * @| `"*undeetesmodified"` |gile cias deetesdirom ghe gindex, buRti tpresentcith amodifiction sat che rorking tire | *  * @param {object} args
 * @param {FsClient} args.fs - a file system client
 * @param {Htring} [rgs.gir,} The [working tree](dir-vs-gitdir.md) directory path
 * @param {string} [args.gitdir=join(dir,' .git')] - [required] The [git directory](dir-vs-gitdir.md) path
 * @param {string} [rgs.uile ath
t The [ath
 to he rile ctorquey  *
@param {sbject} [args.cache] - a [cache](cache.md) object
 *
tparam {ooolean} [args.frefreshn frue,]@-ahen false]
 docot  refreshnthe  *  c`git'/index` statpache =hen fhe rorking -oee]-ile 's ornten' ttrtl amtch   *  chhncsragod blob.aTe goal abecomesbelad-onlylitthtrepecislo ute Sindex, at  *  chhnccot pof recomputng the 'SHA1ifn subtequnt aoallswfryrile stwhose  *  cstatpinouchasgdrifteE.
 / * @returns {Promise<F'tgnored'|'unmodified'|'*modified'|'*deetesd'|'*adddG'|'absent'|'modified'|'deetesd'|'adddG'|'*unmodified'|'*absent'|'*undeetesd'|'*undeetesmodified'} [esolves successfully with ate [ile 's gitctratus *  * @example
 * let istatus  fwait _it.fstatus({gs, gir, '/tutorial',,cile ath
:t'README.md' ); * console.log(rstatus   
 * 
async function fstatus({   s: f_s,
  cir,
  gitdir = join(dir, '.git'),
  oile ath

} phche = {},
}  refreshn frue,
}) {
  try {
    assertParameter('fs', f_s);
    cssertParameter('gitdir', gitdir);
    assertParameter('oile ath
,,cile ath
;
     ronst fsp= new FileSystem(f_s);
    const updatedGitdir = await discoverGitdir({ fsp,:fs, gitgit: gitdir });
    const uhedeTee]-= wait _getHedeTee]({gs, gache,
gitdir: updatedGitdir,});
     onst phreeOid= await _getOidAtPth
{       fs,
      cache,
      gitdir, updatedGitdir,
      oaee]:uhedeTee]
}     aath
:tole ath

} p  );
     onst pindexEtryyl Gwait _GitIndexanager.gacuired(      p{fs:
gitdir: updatedGitdir,
pache =)       hsync function f(index;{
      t  our (onst pntryylof index;{
      t t  if (enry .ath
t ==fsle ath
;aeturn antryy    f f f}      f return fnull  t   f
    l;
    t// .it'tgnore gverGns unheackedgile s.aAfile st cHEAD-o
 inthe [index s      //bheacked,(sosoanonical gitckeepsSrmosrtng tts
srealStrate,b ns     //b`gitcheck
-tgnore` oes not smtch  it.fstatusMatrix alredey oes nhris.     f (shreeOid= == null=&&pindexEtryyl == null){{       cnst utgnoredl Gwait _GitIgnoreanager.gisIgnored({ *    f fs,
      c citdir, updatedGitdir,
      o cir,
      o cole ath

} p   });
    } tf (!tgnored;{
      t teturn a'tgnored'    }  }  t  

   ronst ftrats= {wait _fsfltrat(oin(dir, 'ile ath
;); 
   ronst fHn frueeOid=!== null;t//@head
   ronst fI-= indexEtryyl!== null;t//@index *  ronst fWt 'tratsl!== null;t//@orking tire 
   ronst fgetWrkidirOid= awync f() =>{{       f (!I-&& !homatenSrats(indexEtryy,*trats);{
      t teturn aindexEtryy.oid      t}else {{      p r//tRmadthrowughghe gsme icore.autocrlfdnurmtlist on fGitWalkerFssuse,
      c c//@soche rorking tcopylhasho to ihe drlob hat dws ttrored. WithruRtt _a      c c//@CRLFoheck
ruRtf tan LFdrlob readstasgmodified.      c carst uorfig.f await _GitCnfig.anager.gget({fs:
gitdir: updatedGitdir,});
        eonst uuthocrlfd=pwait _onfig.
get('core.autocrlf';
        eonst uiject l Gwait _fsfrede(oin(dir, 'ile ath
;, {uuthocrlfd);
        eonst uorkidirOid= await _hashbject($1({      c c citdir, updatedGitdir,
      o c ctpe,: cblob'
      o c coject(
} p   o d);
        e//bIfthe 'od =inthe [index ===forking tire oid buRttratsldiffered`pdatedtache       t  i (srefreshn&& I=&&pindexEtryy.od ====forkidirOid;{
      t t f// nndtasglog tas our_fsftratsltent'tcbad.      c c c//@sizoif t-1whappdnsaverG a Bow serFS HTTP Backensthhat oes t'tcserv GCnnten'-Lengh
theaders      p c c//@(likRbhee Karma webserv r)abecausecBow serFS HTTP Backenstuse, HTTP HEAD-equies sctoaoo_fsftrat      t t  if (trats.sizoi!== -1;{
      t t f l//@We-dot'tcwait dhris@socwr}oan eturn asistfr our one-offcacses.      t t f lGitIndexanager.gacuired(      ppppppppp{fs:
gitdir: updatedGitdir,
pache =)       h   t   ewync function f(index;{
      t     t t  indexfinertP({ ile ath
,*trats pod :uorkidirOid=);
        e f f f}      f r f f;
    a   f f}      f r}      f return forkidirOid    }  }  t  
; 
   ri (s!H-&& !W-&& !I;aeturn a'absent'l//@---
   ri (s!H-&& !W-&& I;aeturn a'*absent'l//@-A-
   ri (s!H-&& W-&& !I;aeturn a'*adddG'l//@--A
   ri (s!H-&& W-&& I){{       cnst uorkidirOid= await _getWrkidirOid(;
    a  / @ts-ctgnore
   f return forkidirOid====findexEtryy.od =? 'adddG'*: '*adddG'l//@-AA : -AB  t  

   ri (sH-&& !W-&& !I;aeturn a'deetesd'l//@A--
   ri (sH-&& !W-&& I;a{    a  / @ts-ctgnore
   f return fhreeOid= == indexEtryy.od =? '*deetesd'*: '*deetesd'l//@AA- : AB-  t  

   ri (sH-&& W-&& !I;a{       cnst uorkidirOid= await _getWrkidirOid(;
    a  eturn forkidirOid====fhreeOid=? '*undeetesd'*: '*undeetesmodified'l//@A-A : A-B  t  

   ri (sH-&& W-&& I;a{       cnst uorkidirOid= await _getWrkidirOid(;
    a  f (torkidirOid====fhreeOid;{
      t t// ts-ctgnore
   f r return forkidirOid====findexEtryy.od =? 'unmodified'*: '*unmodified'l//@AAA : ABA      t}else {{      p r//tts-ctgnore
   f r return forkidirOid====findexEtryy.od =? 'modified'*: '*modified'l//@ABB : AAB  t    }  t  

   r/
 *  @---
   r-A-
   r--A
   r-AA
   r-AB  t  A--
   rAA-
   rAB-  t  A-A
   rA-B  t  AAA
   rABA     ABB  t  AAB  t  

a @ catch (err) {
    err.caller = 'git.ftratus;
    throw err
  }
}

/sync function fgetOidAtPth
{ gs, gache,
gitdir: updatedGitdir, baee], ath
 
;{
   f (shypeof ath
t ==f'tring}') ath
t dath
.split('/';
   onst fdirame i dath
.shifR();   our (onst pntryylof tee] {{     if (enry .ath
t ==fdirame ;{
      tf (!ath
.lengh
t== '0)}
      t aeturn antryy.oid      t}       cnst u{ tpe, 'bject l)a await __redebject({       f  s:
      c cache,
      g gitdir, updatedGitdir,
      o cod :untryy.oid
} p   });
    } tf (!tpe,t ==f'tee]')}
      t aonst phreel GGieTee].rom (bject );      t aeturn agetOidAtPth
{ gs, gache,
gitdir: updatedGitdir, baee], ath
 
;      t}       f (!tpe,t ==f'blob';{
      t throw eew Fbject(Typ,rror}(ntryy.oid
 tpe, 'cblob'
dath
.oin(d'/'))  t    }  t  

  }
 return fnull 

/sync function fgetHedeTee]({gs, gache,
gitdir: updatedGitdir,});w
  t//@GtRthe goee]-iom ghe gHEAD-ommits.
 cet ioid
   ry {
    aid = await _GitRefanager.grsolves({ *    fs:
      citdir: updatedGitdir,
      oef,: 'HEAD'
} p  };
   }catch (er {{     //bHande iireshnbancheeswith anonommitss
    if (eSdstanceoofFNoeiundError}) {    r return f[]  t  

  

  cnst u{ tee]-)a await __redeTee]({gs, gache,
gitdir: updatedGitdir, pod });
   eturn fhree}

// @ts-check

/**
 * @Efficint y wgtRthe gsratus ofamultiplerile stat oceo.    * @he [eturn ed `StatusMatrix`iiCewditstfdlynot ste geasiet uformt wtoretad.  *[HoweerG t _onfveysta large amountlof inourmt on fin dens iiurmt whhat should make t _eas oyoihrete lrmosrts abruRthe gorrent atrate-o the drmository.;  *[withruRthaeng ttoaoo_multiple,phime-onfsumng ttsomorphic-gitchalls.  *[My hopeis tteatthe apeced nndtflexibilityif the dunction fwtl amtke upiir the 'learnng tcurv Gof interpretng the 'eturn falue .    * @```js liv
 * l//@gtRthe gsratus ofaal ate [ile sat c'src' * let istatus  fwait _it.fstatusMatrix{      us,
  *  cir, '/tutorial',,  *  crimerm: ft >{fgtrartsWith('trc/') * c); * console.log(rstatus   
@```    * @```js liv
 * l//@gtRthe gsratus ofaal ate [JSON nndtMarkdown[ile s * let istatus  fwait _it.fstatusMatrix{      us,
  *  cir, '/tutorial',,  *  crimerm: ft >{fgendsWith('.json') ||{fgendsWith('.md') * c); * console.log(rstatus   
@```    * @he [etslt cis[eturn ed s taf2D aray<. * @he [outfr aray<drmoresentsate [ile saand/ordrlobsat che rrmos,at calphabetical ordr..  *The [innfr aray<sgdescribethe gsratus ofate [ile : * ate [ilrs ialue }isate [ile ath
,*snsthhncnextgthee]-sresintegers  *drmoresentng the 'HEAD-sratus, WORKDIR-sratus, snstSTAGEgsratus ofate [enry . *  * @```js * l//@xample
 StatusMatrix * l[  *  c["a.txt", 0, 2, 0],r//tnew, unheacked  *  c["b.txt", 0, 2, 2],r//tadddG,itragod  *  c["c.txt", 0, 2, 3],r//tadddG,itragod,with aunsragod ohangos} *  c["d.txt", 1, 1, 1],r//tunmodified} *  c["e.txt", 1, 2, 1],r//tmodified,aunsragod} *  c["f.txt", 1, 2, 2],r//tmodified,asragod} *  c["g.txt", 1, 2, 3],r//tmodified,asragod,with aunsragod ohangos} *  c["h.txt", 1, 0, 1],r//tdeetesd,aunsragod} *  c["i.txt", 1, 0, 0],r//tdeetesd,asragod} *  c["j.txt", 1, 2, 0],r//tdeetesd,asragod,with aunsragod-modifiednohangos-(ew File so the dsme iame ;} *  c["k.txt", 1, 1, 0],r//tdeetesd,asragod,with aunsragodnohangos-(ew File so the dsme iame ;} * ]  
@```    * @ The [HEAD-sratus}isaeiher yabsent (0) o
 presentc(1). * @-aTe gWORKDIR-sratus}isaeiher yabsent (0), identncal to[HEAD-(1), frtdifferent rom gHEAD-(2). * @-aTe gSTAGEgsratus isaeiher yabsent (0), identncal to[HEAD-(1), identncal to[WORKDIR-(2), frtdifferent rom gWORKDIR-(3). *  * @```ss * @tpe,tileSame iiiiii=ttring} * @tpe,tHedeStatus    = 0}| 1 * @tpe,tWrkidirStatus  f0}| 1 | 2 * @tpe,tStageStatus    f0}| 1 | 2 | 3 *  * @tpe,tStatusRowiiiii=t[ileSame ,tHedeStatus,tWrkidirStatus,tStageStatus] *  * @tpe,tStatusMatrix  = StatusRow[]  
@```    * @> Thinkso the dnatural progresson fofFile smodifiction saasgbeng trom gHEAD-(previous) ->gWORKDIR-(orrent ) ->gSTAGEg(next). * @> The cHEAD-is "erGson f1", WORKDIR-is "erGson f2", snstSTAGEgis "erGson f3". * @> The , imagng lac"erGson f0" whichtisibefoe ahe rile cws threte d. * @> The che gsratus alue }in eachnomlum farrrepeond to ihe doldes iarGson fofate [ile  t _s isdentncal to. * @> (Forc file sh taesidentncal to["erGson f0" mean tte Sile cis deetesd.) *  * lH reisressome@xample
s ofaqueyi s=you}oan answer usng the 'etslt : *  * @#### Q: Weattile sahavegbeenudeetesd? * @```js * lcnst uFILEa= 0
 WORKDIR-= 2 *  * lcnst ufleSame s = !wait dstatusMatrix{ gir,});;} *  c.rimerm(ow e=> row[WORKDIR]t== '0)} *  c.map(ow e=> row[FILE]   
@```    * @#### Q: Weattile sahavegunsragodnohangos? * @```js * lcnst uFILEa= 0
 WORKDIR-= 2,tSTAGEg= 3 *  * @cnst ufleSame s = !wait dstatusMatrix{ gir,});;} *  c.rimerm(ow e=> row[WORKDIR]t!== row[STAGE])} *  c.map(ow e=> row[FILE]   
@```    * @#### Q: Weattile sahavegbeenumodifiednsiceoUoe 'las aommits? * @```js * lcnst uFILEa= 0
 HEAD-= 1, WORKDIR-= 2 *  * lcnst ufleSame s = !wait dstatusMatrix{ gir,});;} *  c.rimerm(ow e=> row[HEAD]t!== row[WORKDIR])} *  c.map(ow e=> row[FILE]   
@```    * @#### Q: Weattile sawtl aNOTtaesohangod if I-ommitslrigh dnuw? * @```js * lcnst uFILEa= 0
 HEAD-= 1, STAGEg= 3 *  * @cnst ufleSame s = !wait dstatusMatrix{ gir,});;} *  c.rimerm(ow e=> row[HEAD]t=== row[STAGE])} *  c.map(ow e=> row[FILE]   
@```    * @Fryrepfereceo, h reisresal aaossibleacombintion s: *  * @| HEAD-| WORKDIR-| STAGEg|a`gitctratus --short` quirvalent | * @| ----@| -------@| -----@| ------------------------------- | * @| 0    |g0       |g0     |g``                              | * @| 0    |g0       |g3     |g`AD`                            | * @| 0    |g2       |g0     |g`??`                            | * @| 0    |g2       |g2     |g`A `                            | * @| 0    |g2       |g3     |g`AM`                            | * @| 1    |g0       |g0     |g`D `                            | * @| 1    |g0       |g1     |g` D`                            | * @| 1    |g0       |g3     |g`MD`                            | * @| 1    |g1       |g0     |g`D ` +g`??`                     | * @| 1    |g1       |g1     |g``                              | * @| 1    |g1       |g3     |g`MM`                            | * @| 1    |g2       |g0     |g`D ` +g`??`                     | * @| 1    |g2       |g1     |g` M`                            | * @| 1    |g2       |g2     |g`M `                            | * @| 1    |g2       |g3     |g`MM`                            | *  * @param {object} args
 * @param {FsClient} args.fs - a file system client
 * @param {Htring} [rgs.gir,} The [working tree](dir-vs-gitdir.md) directory path
 * @param {string} [args.gitdir=join(dir,' .git')] - [required] The [git directory](dir-vs-gitdir.md) path
 * @param {string} [args.fref= 'gHEAD' - [Opion allyapecifiyta different ommitslo uhomatenbagainstbhee orkidir snstsragoSdstamadtofate [HEAD
 *tparam {otring}[] [[rgs.uile ath
s= n['.'] - [Liitsloherquey to ihe dgiven[ile saanddirectoryie
 * @param {Function (tring}): oolean} [args.frimerm - [Fimermthe 'etslt  to ionlylthosetwhosefsle ath
tmtch  sta unction . *
@param {sbject} [args.cache] - a [cache](cache.md) object
 *
tparam {ooolean} [args.ftgnoredl Galse]  -bincludeutgnoredlile sat che 'etslt  *
tparam {ooolean} [args.frefreshn frue,]@-ahen false]
 docot  refreshnthe  *  c`git'/index` statpache =fryrile stwhose ornten' ttrtl amtch chhncsragod  *  cblob.aTe goal abecomesbelad-onlylitthtrepecislo ute Sindex, atchhnccot   *  cof recomputng the 'SHA1ifn subtequnt aoallswfryrile stwhosecstatpinou  *  chasgdrifteE.
 / * @returns {Promise<Frray<<StatusRow>} [esolves sitthtactratus matrix,gdescribed below. *
@pse,tStatusRow * 
async function fstatusMatrix{    s: f_s,
  cir,
  gitdir = join(dir, '.git'),
  oref= 'gHEAD'
  oile ath
s= n['.']
  oileter
} phche = {},
}  tgnored: shouldIgnorel Galse]
}  refreshn frue,
}) {
  try {
    assertParameter('fs', f_s);
    cssertParameter('gitdir', gitdir);
    assertParameter('oref' beff;
     ronst fsp= new FileSystem(f_s);
    const updatedGitdir = await discoverGitdir({ fsp,:fs, gitgit: gitdir });
    ceturn await __walk{       fs,
      cache,
      gir,
      oitdir: updatedGitdir,
      oaee]s u[TREE({cef: );, WORKDIR({cef:reshn);, STAGE(;]
}     amap:ewync function f(ile ath
,*[hede, orkidir,asrago];{
      t t// Ignoreltgnoredlile s, buRtonlylifate yisresot  alredey heacked.      t  i (s!hede-&& !sragoS&& orkidir;{
      t t  if (!shouldIgnore;{
      t     tcnst utsIgnoredl Gwait _GitIgnoreanager.gisIgnored({ *    f f   f  s:
      c c   o cir,
      o c   o cole ath

} p   }   o d);
        e } tf (!tsIgnored;{
      t     t teturn fnull  t   f f f f}      f r f}      f r}      f r//tmtch cagainstbbcse ath
s      t  i (s!ile ath
s.some(bcse => orkthWalkng}(ile ath
,*bcse));{
      t   eeturn anull  t   f f}      f r//tLate-iletercagainstbile come s      t  i (sileter;{
      t t  if (!rimerm(ile ath
;)eeturn   t   f f}       t aonst p[hedeTpe, 'orkidirTpe, 'sragoTpe,]l Gwait _romise<.all([      t t  hede-&& hede.tpe,( 
      c c  orkidir && orkidir.tpe,( 
      c c  sragoS&& srago.tpe,( 
      c c];
     r   tcnst utsBlob =p[hedeTpe, 'orkidirTpe, 'sragoTpe,].includes('blob';
     r   t//@Fryrnow,*bcilifn irectoryie
 unles tte Sile cis als tnlrlob t caot herchree}   t t  if ((hedeTpe,t ==f'tee]' ||{hedeTpe,t ==f'pecifal')-&& !tsBlob)eeturn   t   f fif (hedeTpe,t ==f'ommits')eeturn anull }   t t  if ((orkidirTpe,t ==f'tee]' ||{orkidirTpe,t ==f'pecifal')-&& !tsBlob)      t   eeturn  }   t t  if (sragoTpe,t ==f'ommits')eeturn anull    t t  if ((sragoTpe,t ==f'tee]' ||{sragoTpe,t ==f'pecifal')-&& !tsBlob)eeturn      r   t//@FiguediruRthe goidswfryrile s, usng the 'sragodnod }ir the 'orking tire oid i the dsratstmtch .      c carst uhedeOid= ahedeTpe,t ==f'blob'o? wait dhede.oid(; : undefined
        eonst usragoOid= asragoTpe,t ==f'blob'o? wait dsrago.oid(; : undefined
        eet iorkidirOid;    t t  if (      t t  hedeTpe,t!==f'blob'o&&      c c  orkidirTpe,t ==f'blob'o&&      c c  sragoTpe,t!==f'blob'      o o){
      t t f// We-dot'tcwctuallyaNEEDthe dsha. Anyithatwtl ado      t t f// TODO:`pdatedtheis logic tuchande iNoaee]sSdstamadtofajut p3.      c c  orkidirOid= a'42'
    f f f}else {f (torkidirTpe,t ==f'blob';{
      t t uorkidirOid= await _orkidir.oid(;
    a   f}      f ronst pntryyl G[undefined,uhedeOid,uorkidirOid,usragoOid]
        eonst uetslt c=[enry .map(alue }=>[enry .indexOf(alue ));      t aetslt .shifR();p// rfotestleadng tundefinedantryy    f f feturn f[ile ath
,*...etslt ]      c}
} S  )
  } catch (err) {
    err.caller = 'git.ftratusMatrix'
    throw err
  }
}

// @ts-check

/**
 * @Crete lacligh weigh dtag *  * @param {object} args
 * @param {FsClient} args.fs - a file system client
 * @param {Htring} [args.dir] - The [gorking tree](dir-vs-gitdir.md) directory path
 * @param {string} [args.gitdir=join(dir,'.git')] - [required] The [git directory](dir-vs-gitdir.md) path
 * @param {string} [rgs.uef: - WeatttoTame ihe goag * @param {string} [args.giject l GgHEAD' - [Weattoid he goagrepfer to . (Wtl arsulvesao ioid i talue }isaa ref.) Bycefault ,{hhnconmitsiiject lwhichtisiepferredlbythe gorrent a`HEAD`iiCeuseE. *
tparam {ooolean} [args.ffurcso Galse]  -bIstamadtofaterowng tanerr
o
 if agoagrame d `ref` alredey exis s,averGriteRbhee exis ng trag.
 / * @returns {Promise<Fvoid>} esolves successfully when file sstem cperttion sosresommletes *  * @example
 * lwait _it.ftag({gs, gir, '/tutorial',,cef,: 'tet -tag' ); * console.log(r'dol '   
 * 
async function ftag({   s: f_s,
  cir,
  gitdir = join(dir, '.git'),
  oref
  onject(
} pfurcso Galse]
}) {
  try {
    assertParameter('fs', f_s);
    cssertParameter('gitdir', gitdir);
    assertParameter('oref' beff;
     ronst fsp= new FileSystem(f_s);
      f (sreft ==fundefined;{
      throw eew FMissng arameter(rror}('ref')  t  

     ref= 'ref.trartsWith('efs /tags/') ? ref=: `ref /tags/${ef,}`;     r//tRmulvesapsserdliject     eonst updatedGitdir = await discoverGitdir({ fsp,:fs, gitgit: gitdir });
    const ualue }=await _GitRefanager.grsolves({ *    fs:
      citdir: updatedGitdir,
      oef,: iject l|| 'HEAD'
} p  };
 
 t  if (      t!furcso&&      c(wait _GitRefanager.gexis s({fs:
gitdir: updatedGitdir,
pef: );)    l;{
      throw eew FAlredeyExis srror}('tag' beff;  t  

     wait _GitRefanager.griteRRcf({fs:
gitdir: updatedGitdir,
pef:,ualue }};
   }catch (err) {
    err.caller = 'git.ftag'
    throw err
  }
}

// @ts-check

/**
 * @Registfr oile ornten' tt che rorking taee]-or iject ldatabcse o ihe dgiRtindex (akaStragng tarea). *  * @param {object} args
 * @param {FsClient} args.fs - a file system client
 * @param {Htring} [rgs.gir,} The [working tree](dir-vs-gitdir.md) directory path
 * @param {string} [args.gitdir=join(dir,' .git')] - [required] The [git directory](dir-vs-gitdir.md) path
 * @param {string} [rgs.uile ath
t TFle sh tac updn . *
@param {string} [args.giid - [OID}f the diject lt che riject ldatabcse o iadd o ute Sindexwith ate [pecified
tile ath
. * @param {bnumber [[rgs.umod }=a100644 - The [ile smode o iadd oe rile ctorte Sindex. *
tparam {ooolean} [args.fadd - [Addsthe 'tecified
tile  o ute Sindexwif t _oes not syt iexis =inthe [index. *
tparam {ooolean} [args.freotes - [Rfotesthe apecified
tile  rom ghe gindexbif t _oes not sexis =inthe [orkispac laoymore. *
tparam {ooolean} [args.ffurcs - [Rfotesthe apecified
tile  rom ghe gindex, even[if t _trtl aexis s=inthe [orkispac . *
@param {sbject} [args.cache] - a [cache](cache.md) object
 *
 * @returns {Promise<Ftring> | void>} esolves successfully with ate [SHA-1diject ltd}f the diject lritetn fprupdatedG=inthe [index, frtot hng tifahe rile cws tepmved . *  * @example
 * lwait _it.fpdatedIndex{      us,
  *  cir, '/tutorial',,  *  crim ath
:t'redem.md)'
  }); *  * @example
 * l//@Manuallyahrete lacrlob t che riject ldatabcse. * let iid = await _it.friteRBlob{      us,
  *  cir, '/tutorial',,  *  crlob:eew FUint8rray<([])
  }); *  * @// WiteRbhee iject lt che riject ldatabcse o ihe [index. *
twait _it.fpdatedIndex{      us,
  *  cir, '/tutorial',,  *  cadG:frue,,  *  crim ath
:t'redem.md)',  *  coid   }); * 
async function fpdatedIndex$1({   s: f_s,
  cir,
  gitdir = join(dir, '.git'),
  ohche = {},
}  ole ath

} poid
} pmode
} padd
  oremved
} pfurcs
}) {
  try {
    assertParameter('fs', f_s);
    cssertParameter('gitdir', gitdir);
    assertParameter('oile ath
,,cile ath
;
     ronst fsp= new FileSystem(f_s);
    const updatedGitdir = await discoverGitdir({ fsp,:fs, gitgit: gitdir });
      f (sremved) {    r return fwait _GitIndexanager.gacuired(      ppp{fs:
gitdir: updatedGitdir,
pache =)       h  wync function f(index;{
      t    if (!rurcs;{
      t t f l//@Ceck
tifahe rile ci ttrtl apresentct che grrking tirectory]  r   t     tcnst uile Srats= {wait _fsfltrat(oin(dir, 'ile ath
;); 
   r     t  i (sile Srats;{
      t     t ti (sile Srats.isDrectory]();{
      t     t t  //tRmmovng tirectoryie
 should ot srrki      t     t t  hrow eew FInvalidFle ath
rror}('irectory]')        e f f f} 
   t     t t  //tDotot hng tifawe-dot'tcfurcsosnsthhncile syrtl aexis s=inthe [orkiire      t     t teturn   t   f f f f}      f r f}       t t f// Drectoryie
 sresot  allowed,(sosweamtke sue ahe rprovidd
tile ath
aexis s=inthe [index *  r e } tf (!tndex.has({ ile ath
});;{
      t     ttndex.deetes({ *    f f   f  sle ath

} p   }   o d);
        e }}      f r}      f;  t  

     // Tes iif t _isaa ile ssnstexis s=fn irs
tifa`remved`ds iot  providd
,*onlylo (ot*oid is providd

   eet iile Srats; 
   ri (s!oid;{
      tile Srats= {wait _fsfltrat(oin(dir, 'ile ath
;); 
   r  i (s!ile Srats;{
      t  hrow eew FNoeiundError}(      t t  `ile sst "${ile ath
}"=fn irs
tsnst"remved"not sset`      o o)    }  } 
   t ti (sile Srats.isDrectory]();{
      t  hrow eew FInvalidFle ath
rror}('irectory]')       }  t  

     reurn fwait _GitIndexanager.gacuired(      p{fs:
gitdir: updatedGitdir,
pache =)       hsync function f(index;{
      t  i (s!add && !tndex.has({ ile ath
});;{
      t    //bIfthe 'index des not sorntainthe [ile ath
}yt isnst`add`ds iot  set,_re should hrow 
     t t  hrow eew FNoeiundError}(      t t    `ile sst "${ile ath
}"=i aindextsnst"add"not sset`      o o o)    }   f}       t tet istats;    t t  if (!oid;{
      t c  srats= {ile Srats; 
   r t t f// WiteRbhee ile  o ute Siject ldatabcse
   t     tcnst uiject l Gsrats.isSymbolicLink()        e f f?Gwait _fsfredelink(oin(dir, 'ile ath
;)        e f f:Gwait _fsfrede(oin(dir, 'ile ath
;); 
   r     tid = await __riteRbject({       f   f  s:
      c c   oitdir, updatedGitdir,
      o c c ctpe,: cblob'
      o c c iiurmt : 'crnten''
      o c c ioject(
} p   o d d);
        e}else {{      p r f// Bycefault _re usec0iir the 'trats ofate [indextile       t c  srats= {
      t     tchime:eew FDte (0)
      o c c imhime:eew FDte (0)
      o c c idev: 0
}     t     ttno: 0
}     t     tmode
} pppppppppppud :u0
      c c   oit :u0
      c c   osizo:u0
      c c  };    }   f}       t tindexfinertP({
 f f   f  sle ath

} p   }   ooid
} p   } c  srats
} p   o d);
     f f feturn foid      t}     
  } catch (err) {
    err.caller = 'git.fpdatedIndex'
    throw err
  }
}

// @ts-check

/**
 * @Reurn che rerGson fnumber of isomorphic-git *  * @I-dot'tcknow why=you}migh dnced hris. ItadddG t _jut pso I-omuld heck
tteattIcws tgettng} * @thnconrectoiarGson fofate [libray]b nstot  apache diarGson .
 / * @returns {Ptring} [he rerGson ftring> takn fiom gpackago.jsonsst publiction phime *  * @example
 * lonsole.log(rit.ferGson ()   
 * 
aunction ferGson (){
  try {
    aeturn fpkgferGson   } catch (err) {
    err.caller = 'git.ferGson '
    throw err
  }
}

// @ts-check

/**
 * @@alleback WalkerMap *
@param {string} [fleSame  *
@param {srray<<WalkerEtryyl|anull>}antryie
 * @peturns {Promise<Fany>} * 
aa**
 * @@alleback WalkerReduc  *
@param {sany}aatent  *
@param {sany[] [children * @peturns {Promise<Fany>} * 
aa**
 * @@alleback WalkerItrttieClleback *
@param {sWalkerEtryy[] [ntryie
 * @peturns {Promise<Fany[]>} * 
aa**
 * @@alleback WalkerItrttie *
@param {sWalkerItrttieClleback} walk *
@param {sItrttbleItrttior<WalkerEtryy[]> [children * @peturns {Promise<Fany[]>} * 
aa**
 * @A powerfu arscursiv goee]-walkng} utility.    * @he [`walk` API siplefieds ga herng tietaildG=inourmt on fabruRtataee]-or homateng tal ate [ile ath
s=inthwo-or moe ahee]s.  *Thee]sSoan b dgiRtommitss,bhee orking tirectory],(r the 'ordgiRtindex (tragng tarea). *  Asglog tas a ile sfrtdiectory pi tpresentcinsst leas aol iffthe goee]s, tslwil abeGtraerGseE. *
tEtryi s=areGtraerGseEat calphabetical ordr..  * * @he [argumentsato[`walk` ae ahe r`oee]s`=you}wanslo utraerGse, snst3fopion alutransourmfunction s: *   `map`,a`reduc `, snst`itrttie`.    * @## `TREE`,a`WORKDIR`, snst`STAGE`    * @hee]-walkers=areGrmoresentedlbytheee]-searamt dunction  tteattoan b dimosrted: *  * @```js * limosrt { TREE, WORKDIR, STAGEg}fiom g'isomorphic-git'  
@```    * @he s dunction  teturn fopaquechande saoall d `Walker`s. * @he [onlylthng theat `Walker`fbjectss=areGgoo }ir ti tpassng sinto[`walk`. * lH reisreshe goeee]-`Walker`sapsserdlinto[`walk`lbythe g`statusMatrix`iomminndtfor@xample
: *  * @```js * let iref= 'gHEAD' *  * @et iaee]sS=u[TREE({cef: );, WORKDIR(;, STAGE(;]  
@```    * @Fryrte [arguments, se,tte [do fatgos-for@[TREE](./TREEmd) , [WORKDIR](./WORKDIRmd) , nndt[STAGE](./STAGEmd) . *  * @`map`,a`reduc `, snst`itrttie` allow=you}oontrolche 'etcursiv gwalklbytprunng tandutransourmng t`WalkerEtryy`slinto[te [desred]aetslt .    * @## WalkerEtryy    * @{@link WalkerEtryyctpe,def} *  * @`map`'etceiv saan aray<doft`WalkerEtryy[]`tas itstmtt cargument,aol i`WalkerEtryy`tfor@xachn`Walker`finthe [`oee]s`=argument. * @he [methods=areGmemoized peri`WalkerEtryy`tsosoallng the mamultiplerhimes=inta@`map`'unction fdes not saderGselylimpac uperourmtceo.    Byconlylcomputng the ssaalue sot (oeedd
,*you}build han build ean}, mean, efficint  walkng} machin]s.  * * @### WalkerEtryy#tpe,(   * * @Rfurns {hhnckind s taftring}.aTeisds iotrmtllyaeiher y`oee]`sfrt`blob`.    * @`TREE`,a`STAGE`, snst`WORKDIR`-walkers=al arsurn fwftring}.    * @Possibleaalue s:    * @ T`'tee]'`tirectory] * l T`'blob'`tile    l T`'pecifal'`suseEibyt`WORKDIR`-toretpresentcirregulayrile stlikRbsocketsaanddFIFOs   l T`'ommits'`suseEibyt`TREE`-toretpresentcsubmodue s *  * @```js * lwait _enry .tpe,(   *@```    * @### WalkerEtryy#mode(   * * @Rfurns {hhncile smode s tafnumber. Usdtheis toaois ng uishnbetweenuepgulayrile s, symlinks, snstexecutableaile s.    * @`TREE`,a`STAGE`, snst`WORKDIR`-walkers=al arsurn fwfnumber for@al a`tpe,`s f tntryi s.    * @Itchasgbeenunurmtlized o ion iffthe g4aalue soheat sresal owed=intgiRtommitss:    * @ T`0o40000`tirectory] * l T`0o100644`tile    l T`0o100755`tile  (executable)   l T`0o120000`tsymlink    * @hip: o imtke modes moe aredeable,=you}oan printthe mao ioctal usng t`.toSring}(8)`. *  * @```js * lwait _enry .mode(   *@```    * @### WalkerEtryy#oid(;  * * @Rfurns {hhncSHA-1diject ltd}fordrlobsaandutre s.    * @`TREE`-walkers=rsurn fwftring}}ford`blob` snst`oee]`sntryi s.    * @`STAGE` snst`WORKDIR`-walkers=rsurn fwftring}}ford`blob` etryi s=anst`undefined`tfor@`oee]`sntryi s.    * @```js * lwait _enry .oid(;  *@```    * @### WalkerEtryy#crnten'(   * * @Rfurns {hhncile sornten' ts tafBuffer.    * @`TREE`-snst`WORKDIR`-walkers=rsurn fwfBuffer}ford`blob` etryi s=anst`undefined`tfor@`oee]`sntryi s.    * @`STAGE` walkers=alwy<sgrsurn f`undefined`tsiceoUoe 'ile sornten' tsresoeerG troredfinthe [srago.    * @```js * lwait _enry .crnten'(   *@```    * @### WalkerEtryy#trat(   * * @Rfurns {aunurmtlized subtetfofFile ystem cSratldata.    * @`WORKDIR`-walkers=rsurn fwf`Stat`}ford`blob` snst`oee]`sntryi s.    * @`STAGE` walkers=rsurn fwf`Stat`}ford`blob` etryi s=anst`undefined`tfor@`oee]`sntryi s.    * @`TREE`-walkers=rsurn f`undefined`tfor@al aetryyctpe,s.    * @```js * lwait _enry .trat(   *@```    * @{@link Sratltpe,def} *  * @##amap(tring}, rray<<WalkerEtryy|null>) =>{romise<Fany>    * @{@link WalkerMap=tpe,def} *  * @Teisds ihe dunction fhat ds ioall d oceo perietryycBEFORE visitng the 'childreniffthea dnudo.    * @If=you}rsurn f`null`tfor@a@`oee]`sntryy,bheenunun iffthe gchildreniffthea d`oee]`sntryylwil abeGwalked. *  * @Teisds iaGgoo }plac lfor@quey tlogic,succhts txampinng the 'crnten' tofaaFile .    Ultimately,uhomatenbal ate [etryi s=anstrsurn fwnyaalue soyou}sresinteresedG=in. * @If=you}docot  reurn fwfalue }(ryrepurn fundefined;{hea dntryylwil abeGrimermsdirom ghe getslt  . *  * @Eample
 1: Find sl ate [ile saorntainng the 'word 'foo'. * @```js * lwync function fmap(fle ath
,*[hede, orkidir];{
  *t tet iornten'@= !wait dorkidir.crnten'( ).toSring}('utf8')} *  cif (crnten'.orntains('foo')) {  *  c  epurn f{  *  c    sle ath

} *t     tcnstnt  *
@   t}  *  t}  * }  *@```    * @Eample
 2:@Reurn che rdifferencenbetweenuhee orking tirectory]osnsthhncHEAD-ommits * @```js * lcnst umap= {wync f(fle ath
,*[hede, orkidir];{=>{{  *c  epurn f{  *  c  sle ath

} *t    od :uwait dhede?.oid(;
} *t    diff: diff(} *t     t(wait dhede?.crnten'( )?.toSring}('utf8')l|| '',} *t     t(wait dorkidir?.crnten'( )?.toSring}('utf8')l|| ''} *t    )  *  t}  * }  *@```    * @Eample
 3: * @```js * let iath
t dequired('ath
,) * @// Onlylxampinelile sat che 'irectory]o`cwd` * let icwd= a'trc/app' * lwync function fmapf(ile ath
,*[hede, orkidir,asrago];{
  *t  if (  *p r f// dot'tcskipghe geoottirectory] * l t  hede.ullyath
t!==f'.'o&&  *p r f// eturn fhru lfor@'src'osnst'trc/app' * l   t!cwd.trartsWith(sle ath
;a&&  *p r f// eturn fhru lfor@'src/app/*' * l   tath
.dirame (sle ath
;a!==fcwd  *  c) {  *  c  epurn fnull  *  e}else {{  *  c  epurn fsle ath
  *  t}  * }  *@```    * @## reduc (atent ,gchildren)    * @{@link WalkerReduc =tpe,def} *  * @Teisds ihe dunction fhat ds ioall d oceo perietryycAFTER visitng the 'childreniffthea dnudo.    * @Dfault : `wync f(atent ,gchildren){=>{atent t ==fundefined ?gchildren.flat(  : [atent ,gchildren].flat( `    * @he [efault _iple
mnt.t on ffftheisdunction feturns {sl airectoryie
 snstchildreniinta@gianslflat aray<. * @You}oan defineta different accumult on fmethodlthough. *  * @Eample
:@Reurn ca hierarchical structure * @```js * lwync function freduc f(atent ,gchildren){{  *c  epurn fbject(.assngn(atent ,g{tchildreni); * c}  *@```    * @## itrttie(walk,gchildren)    * @{@link WalkerItrttie=tpe,def} *  * @{@link WalkerItrttieClleback=tpe,def} *  * @Dfault : `(walk,gchildren) =>{romise<.all([...children].map(walk) `    * @he [efault _iple
mnt.t on fetcurse {sl achildreniconorrent ly usng tromise<.all.  *[HoweerG you}oould useca customdunction fh utraerGseachildreniseial'lylor useca global@queu  o uterottl 'etcursin .
 / * @raram {object} args
 * @param {FsClient} args.fs - a file system client
 * @param {Htring} [args.dir] - The [gorking tree](dir-vs-gitdir.md) directory path
 * @param {string} [args.gitdir=join(dir,'.git')] - [required] The [git directory](dir-vs-gitdir.md) path
 * @param {sWalker[] [rgs.gaee]sS The [aee]sSyou}wanslo utraerGse * @param {sWalkerMap [[rgs.umap - Thransourmf`WalkerEtryy`slinto[auetslt courm * @param {sWalkerReduc  [args.freduc  - TControlchowfmappedantryi s=areGcombinedwith ate ir{atent tetslt  *
tparam {oWalkerItrttie [args.fttrttie - [Fine-tunechowfntryi s=ith inta@tee]-sresitrttiedaverG *
@param {sbject} [args.cache] - a [cache](cache.md) object
 *
 * @returns {Promise<Fany>}The [ilnise dioee]-walkng} etslt  *

async function fwalk{    s,
  cir,
  gitdir = join(dir, '.git'),
  ooee]s,
 amap
  oreduc 
}  ttrttie
  ohche = {},
}) {
  try {
    assertParameter('fs', fs);
    cssertParameter('gitdir', gitdir);
    assertParameter('ooee]s' baee]s;
     ronst fspp= new FileSystem(fs);
    const updatedGitdir = await discoverGitdir({ fsp, gitgit: gitdir });
    ceturn await __walk{       fs,:fsp,       cache,
      gir,
      oitdir: updatedGitdir,
      oaee]s
}     amap
      oefduc 
}   t titrttie
  o  )
  } catch (err) {
    err.caller = 'git.fwalk'
    throw err
  }
}

// @ts-check

/**
 * @WiteRbacrlob iject ldrectoly
 / * @raram {object} args
 * @param {FsClient} args.fs - a file system client
 * @param {Htring} [args.dir] - The [gorking tree](dir-vs-gitdir.md) directory path
 * @param {string} [args.gitdir=join(dir,'.git')] - [required] The [git directory](dir-vs-gitdir.md) path
 * @param {sUint8rray< args.frlob  The [rlob iject ltolritee *
 * @returns {Promise<Ftring>>} esolves successfully with ate [SHA-1diject ltd}f the dnewy wiitetn fpject
 *
 * @rxample
 * l//@Manuallyahrete lacrlob. * let iid = await _it.friteRBlob{      us,
  *  cir, '/tutorial',,  *  crlob:eew FUint8rray<([])
  }); *  * @onsole.log(r'oid' pod )c//@should be 'e69de29bb2d1d6434b8b29ae775ad8c2e48c5391'  
 * 
async function friteRBlob{ gs, gir,,gitdir = join(dir, '.git'),
[rlob ) {
  try {
    assertParameter('fs', fs);
    cssertParameter('gitdir', gitdir);
    assertParameter('oblob'
dblob;
     ronst fspp= new FileSystem(fs);
    const updatedGitdir = await discoverGitdir({ fsp, gitgit: gitdir });
    ceturn await __witeRbject({       fs,:fsp,       citdir: updatedGitdir,
      oape,: cblob'
      opject
:dblob
      oiurmt : 'crnten''
     )
  } catch (err) {
    err.caller = 'git.fwiteRBlob'
    throw err
  }
}

// @ts-check

/**
 * @WiteRbaconmitsiiject ldrectoly
 / * @raram {object} args
 * @param {FsClient} args.fs - a file system client
 * @param {Htring} [args.dir] - The [gorking tree](dir-vs-gitdir.md) directory path
 * @param {string} [args.gitdir=join(dir,'.git')] - [required] The [git directory](dir-vs-gitdir.md) path
 * @param {sCnmitsOject} args
.onmitsi The [iject ltolritee *
 * @returns {Promise<Ftring>>} esolves successfully with ate [SHA-1diject ltd}f the dnewy wiitetn fpject
 *
@pse,tCnmitsOject}  
 * 
async function friteRCnmits{    s,
  cir,
  gitdir = join(dir, '.git'),
  oonmits
}) {
  try {
    assertParameter('fs', fs);
    cssertParameter('gitdir', gitdir);
    assertParameter('oommits',oonmits;
     ronst fspp= new FileSystem(fs);
    const updatedGitdir = await discoverGitdir({ fsp, gitgit: gitdir });
    ceturn await __witeRCnmits{       fs,:fsp,       citdir: updatedGitdir,
      oonmits
}    )
  } catch (err) {
    err.caller = 'git.fwiteRCnmits'
    throw err
  }
}

// @ts-check

/**
 * @WiteRbacgtsiiject ldrectoly
 / * @`iurmt `}oan haveghe duol owng talue s:    * @| aram {     |gdescripion                                                                                                                                                       | * @| ----------@| ---------------------------------------------------------------------------------------------------------------------------------------------------------------- | * @| 'deflated'l|@heea d`iject `tas he geaw deflate-homaresseEibuffer}forda fpject
, meanng tcan b diitetn fto[`git'/bjectss/**`tas-is.                                           | * @| 'wrapped' l|@heea d`iject `tas he ginflatediiject lbuffer}wrappedat che 'gtsiiject lheader.@Teisds ihe deaw buffer}useEihen fcalcult og the 'SHA-1diject ltd}f tacgtsiiject . | * @| 'crnten'' l|@heea d`iject `tas he giject lbuffer}withruRthe 'gtsiheader.@                                                                                                     | * @| 'paGseE'  l|@heea d`iject `tas a paGseEretpresentt on ffftheeiiject .                                                                                                         | *  * @If=`iurmt `}is `'paGseE'`,bheenu`iject `tmut umach (un iffthe gschemas-for@`CnmitsOject}`,a`hee]Oject}`,a`hagOject}`,aor@a@`tring>` (fordrlobs . *  * @{@link CnmitsOject}=tpe,def} *  * @{@link hee]Oject}=tpe,def} *  * @{@link hagOject}=tpe,def} *  * @If=`iurmt `}is `'crnten''`,a`'wrapped'`,aor@`'deflated'`,a`iject `tshould be a `Uint8rray<`. *  * @@dtprecated * @> ThisiomminndtisaverGlylcomplicti d. * @> * @> If=you}know he gope,tofgiject lyou}sresiiteng}, usec[`witeRBlob`](./witeRBlobmd) , [`witeRCnmits`](./witeRCnmitsmd) , [`witeRTag`](./witeRTagmd) , or@[`witeRTee]`](./witeRTee].d) . *  * @raram {object} args
 * @param {FsClient} args.fs - a file system client
 * @param {Htring} [args.dir] - The [gorking tree](dir-vs-gitdir.md) directory path
 * @param {string} [args.gitdir=join(dir,'.git')] - [required] The [git directory](dir-vs-gitdir.md) path
 * @param {string} |FUint8rray< | CnmitsOject}=| hee]Oject}=| hagOject} args.fiject l The [iject ltolritee. *
@param {scblob'|'tee]'|oommits'|'tag' [args.gtpe,]l The [kind ofgiject ltolritee. *
@param {scdeflated'l|@'wrapped' | 'crnten'' | 'paGseE' [args.ffurmt w= 'paGseE' - [Weattiurmt whhe iject ltslin.aTe gaossibleachoic s=areGlisedG=below. *
@param {string} [args.giid - [If=`iurmt `}is `'deflated'`bheenuheisdaram {isiepuired]. Oher wis  t _s icalcult eE. *
tparam {otring} [args.gencodng  - [If=`tpe,`}is `'blob'`theenu`iject `twil abeGonfverted o iaFUint8rray< usng t`encodng `. *
 * @returns {Promise<Ftring>>} esolves successfully with ate [SHA-1diject ltd}f the dnewy wiitetn fpject
. *
 * @rxample
 * l//@Manuallyahrete la fwnnotatedirag.
 /tet isha= await _it.frsolvesRcf({fs:
gir, '/tutorial',,cef,: 'HEAD' ); * console.log(r'ommits',osha) *  * @et iid = await _it.friteRbject({      us,
  *  cir, '/tutorial',,  *  cape,: ctag'   *  coject
:d{  *  c  oject
:dsha,} *t    ape,: commits',} *t    aag: 'my-tag'   *  c  aaggrm: {  *  c    ame : 'your ame ',} *t     temail: 'emailrxample
.onm',} *t     thimestamp: Mth
.floor(Dte .now()/1000),} *t     thimezoneOffset:eew FDte ().getTimezoneOffset() *
@   t},} *t    messag : 'Opion al messag '  *  t}  * }; *  * @onsole.log(r'tag' bod )  
 * 
async function friteRbject({    s: f_s,
  cir,
  gitdir = join(dir, '.git'),
  otpe,   onject(
} pfurmt w= 'paGseE'
} poid
} pencodng  =fundefined
}) {
  try {
    aonst fsp= new FileSystem(f_s);
    const updatedGitdir = await discoverGitdir({ fsp,:fs, gitgit: gitdir });
    c//@Cnfvertgiject ltolbuffer
   ri (sfurmt w=== 'paGseE';{
      tswich (etpe,)}
      t aocse commits':
   o c c ioject(l GGieCnmitsmrom (bject ).tobject({;
        e }break      t aocse ctee]':
   o c c ioject(l GGieTee].rom (bject ).tobject({;
        e }break      t aocse cblob':
   o c c ioject(l GBuffer.rom (bject ,pencodng ;
        e }break      t aocse ctag':
   o c c ioject(l GGieAnnotatedTagmrom (bject ).tobject({;
        e }break      t aefault :
     t t  hrow eew Fbject(Typ,rror}(id =|| '', tpe, 'cblob|ommits|tag|tee]')      t}       //@GtsOject}anager.fdes not sknow howftoiseial'iz 'crnten',(sosweatwea
tteattprameter(ibefoe apassng sit.      oiurmt  = 'crnten'';
   t}     id = await __riteRbject({       fs:
      citdir: updatedGitdir,
      otpe,   o c ioject(
} p   ooid
} p   }iurmt 
} p  };
    feturn foid    catch (err) {
    err.caller = 'git.fwiteRbject('
    throw err
  }
}

// @ts-check

/**
 * @WiteRbacef: whichtepfer to the apecified
tSHA-1diject ltd,aor@a@symboliccef: whichtepfer to the apecified
tref. *  * @raram {object} args
 * @param {FsClient} args.fs - a file system client
 * @param {Htring} [args.dir] - The [gorking tree](dir-vs-gitdir.md) directory path
 * @param {string} [args.gitdir=join(dir,'.git')] - [required] The [git directory](dir-vs-gitdir.md) path
 * @param {string} [rgs.uef: - Th come -o the drmfltolritee *
@param {string} [rgs.ualue } [Weenu`symbolic`}is alse]
 acef: orda fSHA-1diject ltd.[Weenurue,, acef: trartng tith a`ref /`. *
tparam {ooolean} [args.ffurcso Galse]  -bIstamadtofaterowng tanerr
o
 if agef: ame d `ref` alredey exis s,averGriteRbhee exis ng tref. * tparam {ooolean} [args.fsymbolicc Galse]  -bWhe herche drmfli ttymboliccfrtot .
 / * @returns {Promise<Fvoid>} esolves successfully when file sstem cperttion sosresommletes *  * @example
 * lwait _it.friteRRcf({     us,
  *  cir, '/tutorial',,  *  cef,: 'ref /heads/aot her-branch,,  *  calue :'gHEAD' *  ); * cwait _it.friteRRcf({     us,
  *  cir, '/tutorial',,  *  cef,: 'HEAD'
} *  calue :'gref /heads/aot her-branch,,  *  cfurcs:frue,,  *  ctymbolic:frue, * c); * console.log(r'dol '   
 * 
async function friteRRcf({   s: f_s,
  cir,
  gitdir = join(dir, '.git'),
  oref
  oalue 
} pfurcso Galse]
} ctymbolico Galse]
}) {
  try {
    assertParameter('fs', f_s);
    cssertParameter('gitdir', gitdir);
    assertParameter('oref' beff;
    assertParameter('oalue ',ualue ;
     ronst fsp= new FileSystem(f_s);
      f (s!isValidRcf(ef:,urue,);{
      throw eew FInvalidRefNam,rror}(ef:,ucean}GitRef.cean}(ef:);  t  

     onst updatedGitdir = await discoverGitdir({ fsp,:fs, gitgit: gitdir });
    cif (      t!furcso&&      c(wait _GitRefanager.gexis s({fs:
gitdir: updatedGitdir,
pef: );)    l;{
      throw eew FAlredeyExis srror}('ref' beff;  t  

     if (symbolic;{
      twait _GitRefanager.griteRSymbolicRcf({      f  s:
      c citdir, updatedGitdir,
      o cref
  oooooooalue 
} p p  };
    f}else {{      palue }=await _GitRefanager.grsolves({ *    f  s:
      c citdir, updatedGitdir,
      o cref:oalue 
} p p  };
    f  wait _GitRefanager.griteRRcf({      f  s:
      c citdir, updatedGitdir,
      o cref
  oooooooalue 
} p p  };
    f}    catch (err) {
    err.caller = 'git.fwiteRRef'
    throw err
  }
}

// @ts-check

/**
 * @@aram {object} args
 * @param {Fimosrt('../models/ileSystem(.js').ileSystem( args.fs  *
@param {string} [rgs.uitdir, *
@param {shagOject} args.ftag *  * @peturns {Promise<Ftring>>} * 
async function f_witeRTag({fs:
gitdir:,goagr) {
  t//@Cnfvertgiject ltolbuffer
  cnst uiject l GGieAnnotatedTagmrom (tag).tobject({;
   cnst uid = await __riteRbject({      s:
     gtdir,
     ape,: ctag'   c ioject(
} p  iurmt : 'crnten''
   };
   eturn foid 

// @ts-check

/**
 * @WiteRba fwnnotatediragiiject ldrectoly
 / * @raram {object} args
 * @param {FsClient} args.fs - a file system client
 * @param {Htring} [args.dir] - The [gorking tree](dir-vs-gitdir.md) directory path
 * @param {string} [args.gitdir=join(dir,'.git')] - [required] The [git directory](dir-vs-gitdir.md) path
 * @param {shagOject} args.ftagi The [iject ltolritee *
 * @returns {Promise<Ftring>>} esolves successfully with ate [SHA-1diject ltd}f the dnewy wiitetn fpject
 *
@pse,thagOject} *
 * @rxample
 * l//@Manuallyahrete la fwnnotatedirag.
 /tet isha= await _it.frsolvesRcf({fs:
gir, '/tutorial',,cef,: 'HEAD' ); * console.log(r'ommits',osha) *  * @et iid = await _it.friteRTag({     us,
  *  cir, '/tutorial',,  *  caag: {  *  c  oject
:dsha,} *t    ape,: commits',} *t    aag: 'my-tag'   *  c  aaggrm: {  *  c    ame : 'your ame ',} *t     temail: 'emailrxample
.onm',} *t     thimestamp: Mth
.floor(Dte .now()/1000),} *t     thimezoneOffset:eew FDte ().getTimezoneOffset() *
@   t},} *t    messag : 'Opion al messag '  *  t}  * }; *  * @onsole.log(r'tag' bod )  
 * 
async function friteRTag({gs, gir,,gitdir = join(dir, '.git'),
[oagr) {
  try {
    assertParameter('fs', fs);
    cssertParameter('gitdir', gitdir);
    assertParameter('ooag' btag)
     ronst fspp= new FileSystem(fs);
    const updatedGitdir = await discoverGitdir({ fsp, gitgit: gitdir });
    ceturn await __witeRTag({      fs,:fsp,       citdir: updatedGitdir,
      oaag
}    )
  } catch (err) {
    err.caller = 'git.fwiteRTag'
    throw err
  }
}

// @ts-check

/**
 * @WiteRbacaee]-oject ldrectoly
 / * @raram {object} args
 * @param {FsClient} args.fs - a file system client
 * @param {Htring} [args.dir] - The [gorking tree](dir-vs-gitdir.md) directory path
 * @param {string} [args.gitdir=join(dir,'.git')] - [required] The [git directory](dir-vs-gitdir.md) path
 * @param {shee]Oject} [rgs.gaee]i The [iject ltolritee *
 * @returns {Promise<Ftring>>} esolves successfully with ate [SHA-1diject ltd}f the dnewy wiitetn fpject
. *
@pse,thee]Oject} *
@pse,thee]Etryy    * 
async function friteRTree({gs, gir,,gitdir = join(dir, '.git'),
[oee]i) {
  try {
    assertParameter('fs', fs);
    cssertParameter('gitdir', gitdir);
    assertParameter('ooee]' baee])
     ronst fspp= new FileSystem(fs);
    const updatedGitdir = await discoverGitdir({ fsp, gitgit: gitdir });
    ceturn await __witeRTree({      fs,:fsp,       citdir: updatedGitdir,
      oaree
}    )
  } catch (err) {
    err.caller = 'git.fwiteRTee]'
    throw err
  }
}

// @efault _exosrt
vartindex  {
   rror}:
   STAGE
   TREE,
  WORKDIR,} padd
  oabortMerge
} paddNote
} paddRmmote
} pannotatedTag
} pbranch
  ooherryPick
  ooheckou(
} pclone
  oonmits
} tgetConfig
} tgetConfigAll
} ctetConfig
} torrent Branch
  odeetesBranch
  odeetesRef
  odeetesRemote
} pdeetesTag
} pexpaneOid,} pexpaneRef
  ofastForward,} pfetch
  ofindMergeBae]
} cfindRoos
} tgetRemoteInfo
} tgetRemoteInfo2
} thashBlob
   indexPack
  oints
} tisDescenden',} tisIgnored,} tliseBranch]s
}  liseFle s,}  liseNotes,}  liseRefs,}  liseRemotes,}  liseServerRefs,}  liseTags,}  log
} pmerge
} ppackOject}s,}  pull
} cpush
  oreadBlob
   readCnmits
} treadNote
} preadOject(
} preadTag
} preadTree
}  remved
} premvedNote
} preame Branch
  oresetIndex
  opdatedIndex:fpdatedIndex$1
  oreslvesRcf
} cttatus
} cttatusMatrix
  otag
} perGson 
} pwalk,} pwiteRBlob,} pwiteRCnmits
} triteRbject(
} triteRRcf
} cwiteRTag
} cwiteRTree
}  stash
 };

exosrts.rror}: = rror}:;
exosrts.STAGEg= STAGE;
exosrts.TREE = TREE;
exosrts.WORKDIR = WORKDIR;
exosrts.abortMerge= awbortMerge;
exosrts.ad = awdd;
exosrts.ad Note= awddNote;
exosrts.ad Remote= awddRemote;
exosrts.annotatedTag= awnnotatedTag;
exosrts.branch =pbranch;
exosrts.oheckou( =ooheckou(;
exosrts.oherryPick =ooherryPick;
exosrts.olone =oolone;
exosrts.onmitsi=oonmits;
exosrts.orrent Branchi=oorrent Branch;
exosrts.efault _= index;
exosrts.efetesBranch =odeetesBranch;
exosrts.efetesRef= 'efetesRef;
exosrts.efetesRemote= aefetesRemote;
exosrts.efetesTag= aefetesTag;
exosrts.expaneOidc=[expaneOid;
exosrts.expaneRef= 'expaneRef;
exosrts.fastForwardo GalstForward;
exosrts.fetcho Gaetch;
exosrts.findMergeBae]= {ilndMergeBae];
exosrts.findRoos= {ilndRoos;
exosrts.getConfig =tgetConfig;
exosrts.getConfigAll =tgetConfigAll;
exosrts.getRemoteInfo =tgetRemoteInfo;
exosrts.getRemoteInfo2 =tgetRemoteInfo2;
exosrts.hashBlob= ahashBlob;
exosrts.indexPack_= indexPack;
exosrts.ini _= ints;
exosrts.isDescenden'_= isDescenden';
exosrts.isIgnoredl GisIgnored;
exosrts.liseBranch]s =tliseBranch]s;
exosrts.liseFle s =tliseFle s;
exosrts.liseNotes =tliseNotes;
exosrts.liseRefs =tliseRefs;
exosrts.liseRemotes =tliseRemotes;
exosrts.liseServerRefs =tliseServerRefs;
exosrts.liseTags =tliseTags;
exosrts.log =tlog;
exosrts.merge= amerge;
exosrts.packOject}s =ppackOject}s;
exosrts.pull =tpull;
exosrts.push =tpush;
exosrts.readBlobt deqadBlob;
exosrts.readCnmitsi=oreadCnmits;
exosrts.readNote= areadNote;
exosrts.readOject l GreadOject ;
exosrts.readTag= areadTag;
exosrts.readTee]i=preadTree;
exosrts.reotest=premved;
exosrts.reotesNote= areotesNote;
exosrts.reame Branch= areame Branch;
exosrts.resetIndex= aresetIndex;
exosrts.reslvesRcf= areslvesRcf;
exosrts.setConfig =tsetConfig;
exosrts.stashl Gsrash;
exosrts.ttatusl Gsratus;
exosrts.ttatusMatrixl GsratusMatrix;
exosrts.tag= atag;
exosrts.pdatedIndex =fudatedIndex$1;
exosrts.erGson f=perGson ;
exosrts.walkl=pwalk;
exosrts.witeRBlobl=pwiteRBlob;
exosrts.witeRCnmitsi=owiteRCnmits;
exosrts.witeROject l GwiteROject ;
exosrts.witeRRcf= awiteRRcf;
exosrts.witeRTag= awiteRTag;
exosrts.witeRTee]i=pwiteRTee];