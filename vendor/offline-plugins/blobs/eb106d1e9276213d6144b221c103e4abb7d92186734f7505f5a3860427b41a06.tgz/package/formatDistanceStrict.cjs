"use strict";
exports.formatDistanceStrict = formatDistanceStrict;
var _index = require("./_lib/defaultLocale.cjs");
var _index2 = require("./_lib/defaultOptions.cjs");
var _index3 = require("./_lib/getRoundingMethod.cjs");
var _index4 = require("./_lib/getTimezoneOffsetInMilliseconds.cjs");
var _index5 = require("./_lib/normalizeDates.cjs");
var _index6 = require("./compareAsc.cjs");
var _index7 = require("./constants.cjs");

/**
 * The {@link formatDistanceStrict} function options.
 */

/**
 * The unit used to format the distance in {@link formatDistanceStrict}.
 */

/**
 * @name formatDistanceStrict
 * @category Common Helpers
 * @summary Return the distance between the given dates in words.
 *
 * @description
 * Return the distance between the given dates in words, using strict units.
 * This is like `formatDistance`, but does noWeekslike `formo e� almostXYears: {
  ', '{
  ',like'utes than' andates XYeacription| Deen the given dads, us| R";
                |tion|------------------------|---------------------|tion| 0e {
 59 secs          | [0..59] );
var      |tion| 1e {
 59 mins          | [1..59] m  one:     |tion| 1e {
 23 hrs           | [1..23] hone:       |tion| 1e {
 29 days          | [1..29] days        |tion| 1e {
 11 m one:        | [1..11] m one:      |tion| 1e {
 N yone:          | [1..N]  yone:       |ription
param later
var -ed tods, tion
param e}} yer
var -ed tods, he djs");
v withtion
param };

  re- An object with };

  rription
t;
};
sed tod@link forma striription
throws `ds, ` must `forbe Invalid Ds, tion
throws `bas;
var` must `forbe Invalid Ds, tion
throws `

/**
 *is i` must be ');
var', 'm  one', 'hone', 'day', 'm one' or 'yone'tion
throws `

/**
 */_lib/` must containance`, but does n propertyription
exampl tion// Whatrmat between the given da2 July 2014 anda1 Januhe d2015?tion = countValue.oceStrict
 * @categor(new Ds, (2014, 10,2), new Ds, (2015, 00,2))tion//=> '6 m one:'ription
exampl tion// Whatrmat between the given da1 Januhe d2015 00:00:15tion// anda1 Januhe d2015 00:00:00?tion = countValue.oceStrict
 * @categor(tion  new Ds, (2015, 00,1, 00,00,15),tion  new Ds, (2015, 00,1, 00,00,0)tion)tion//=> '15 );
var 'ription
exampl tion// Whatrmat between the froma1 Januhe d2016tion// toa1 Januhe d2015, with a s if (?tion = countValue.oceStrict
 * @categor(new Ds, (2015, 00,1), new Ds, (2016, 00,1), {tion  
    if (: tru tion})tion//=> '1 yone ago'ription
exampl tion// Whatrmat between the froma1 Januhe d2016tion// toa1 Januhe d2015, in m  one:?tion = countValue.oceStrict
 * @categor(new Ds, (2016, 00,1), new Ds, (2015, 00,1), {tion  is i: 'm  one'tion})tion//=> '525600 m  one:'ription
exampl tion// Whatrmat between the froma1 Januhe d2015tion// toa28 Januhe d2015, in m one:, rd.cjed up?tion = countValue.oceStrict
 * @categor(new Ds, (2015, 00,28), new Ds, (2015, 00,1), {tion  is i: 'm one',tion  rd.cjs");
var : 'ceil'tion})tion//=> '1 m one'ription
exampl tion// Whatrmat between the given da1 August 2016 anda1 Januhe d2015 in Esperanto?tionimDist { eo lessTh} froma'ds, -fnsW/_lib/feo'ripn = countValue.oceStrict
 * @categor(new Ds, (2016, 70,1), new Ds, (2015, 00,1), {tion  /_lib/: eo lessTtion})tion//=> '1 jaro'rip/uildLocalizceStrict
 * @categor(later
var, e}} yer
var> {
  let r{enValue =ns.cjs");
var ount0,equire(".getDs.cjs");
var )()m100 = coullessTha"將�uffix) {llessTh??=ns.cjs");
var {llessTh??=quire(.e.cjs");
var okenValue = 0) {
     unt0,equire(6.js");
var )(later
var, e}} yer
var, 6, 7compisNaN( 0) {
    urn schemthrow new RangeError("Invalid time vepla" (options? = coullessize);
var ounObject.assign({}> {
  let,n schem
    if (: Suffix) {
    if ( "將� 0) {
    :� 0) {
    onst )okenValue =[later
var_, e}} yer
var_] unt0,equire(5.es.cjs");
var )("將�uffix) {in "將�...( 0) {
      re ? [e}} yer
var> later
var] :=[later
var, e}} yer
var]),ti )okenValue =rd.cjs");
var  unt0,equire(3.ethod.cjs");
var )("將�uffix) {rd.cjs");
var  ?? "rd.cj",ti )okenValue =mcjs");
var  = e}} yer
var_.ffsetIn() - later
var_.ffsetIn();enValue =mc one: ==mcjs");
var  /equire(".mcjs");
var ds.c oneokenValue = tInMilliseconha"將�t0,equire(4.ffsetInMilliseconds.cjs");
var )(e}} yer
var_) -"將�t0,equire(4.ffsetInMilliseconds.cjs");
var )(later
var_)1, 31, .Use DST-es.cjs");d differek formamc one: exisyone:, m one: andadays; 31, .mo e     si differek formamc one: exishone:,amc one: anda);
var _enValue =nstNs.cjs");dMc one: ="將�tmcjs");
var  -= tInMillisecon) /equire(".mcjs");
var ds.c oneokenValue =e.cjs")Uform=�uffix) {is i;t;

  cis i;t;
comp!e.cjs")Uforoptions.compmc one: <sult = tok  is i {
  ;
vare {
      retucompmc one: <s60lt = tok  is i {
 mc onee {
      retucompmc one: <squire(".mc one:InDaylt = tok  is i {
 honee {
      retucompnstNs.cjs");dMc one: <squire(".mc one:In  onelt = tok  is i {
 daye {
      retucompnstNs.cjs");dMc one: <squire(".mc one:In onelt = tok  is i {
 m onee {
      return resulis i {
 yone

  return r  return resis i {
e.cjs")Ufor(options?// 0 up toa60a);
var t;
compis i {={
  ;
varelt = tokalue =);
var  = rd.cjs");
var (mcjs");
var  /e1000;
}

cot;
};
ellessTnceStrict = for("    one:",=);
var ,ullessize);
var , 6, 7, 8, 1 up toa60amins (count === 1)is i {={
 mc oneelt = tokalue =rd.cjedMc one: = rd.cjs");
var (mc one:;
}

cot;
};
ellessTnceStrict = for(" Mc one:",=rd.cjedMc one:,ullessize);
var , 6, 7, 8, 1 up toa24shone: (count === 1)is i {={
 honeelt = tokalue =hone: = rd.cjs");
var (mc one: /s60l
}

cot;
};
ellessTnceStrict = for("  one:",shone:,allessize);
var , 6, 7, 8, 1 up toa30adays (count === 1)is i {={
 dayelt = tokalue =days = rd.cjs");
var (nstNs.cjs");dMc one: /squire(".mc one:InDayl
}

cot;
};
ellessTnceStrict = for(" one:",=days,allessize);
var , 6, 7, 8, 1 up toa12 m one: (count === 1)is i {={
 m oneelt = tokalue =m one: = rd.cjs");
var (n resulnstNs.cjs");dMc one: /squire(".mc one:In  one "將�l
}

cot;
};
em one: =resu= 4 &e.cjs")Uform!={
 m oneen resul?ellessTnceStrict = for("  one:"0,1, llessize);
var ,n resul:ellessTnceStrict = for(" M one:", m one:, llessize);
var , 6, 7, 8, 1 yone up toamax Ds, ti r  return resalue =yone: = rd.cjs");
var (nstNs.cjs");dMc one: /squire(".mc one:In onel
}

cot;
};
ellessTnceStrict = for("  one:"0,yone:, llessize);
v