/**
 * Do not edit:
 * This is a compatibility redirect for contexts that do not understand package.json exports field.
 */
export * from "./dist-types/submodules/sso-oidc/index";
