export declare class NativeAuthClientConfig {
    host: string;
    apiUrl: string;
    expirySeconds: number;
}
