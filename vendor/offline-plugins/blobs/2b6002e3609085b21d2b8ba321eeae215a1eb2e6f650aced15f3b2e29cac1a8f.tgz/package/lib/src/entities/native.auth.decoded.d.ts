export declare class NativeAuthDecoded {
    constructor(result?: Partial<NativeAuthDecoded>);
    ttl: number;
    host: string;
    address: string;
    extraInfo?: any;
    signature: string;
    blockHash: string;
    body: string;
}
