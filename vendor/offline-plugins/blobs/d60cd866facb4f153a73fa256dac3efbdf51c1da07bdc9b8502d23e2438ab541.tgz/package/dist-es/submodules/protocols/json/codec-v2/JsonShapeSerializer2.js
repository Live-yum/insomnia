import { determineTimestampFormat } from "@smithy/core/protocols";
import { NormalizedSchema } from "@smithy/core/schema";
import { dateToUtcString, generateIdempotencyToken, LazyJsonString, NumericValue, toBase64 } from "@smithy/core/serde";
import { SerdeContextConfig } from "../../ConfigurableSerdeContext";
import { JsonBytesStringAdapter } from "./JsonBytesStringAdapter";
const encoder = new TextEncoder();
const OPEN_BRACE = 0x7b;
const CLOSE_BRACE = 0x7d;
const OPEN_BRACKET = 0x5b;
const CLOSE_BRACKET = 0x5d;
const QUOTE = 0x22;
const COLON = 0x3a;
const COMMA = 0x2c;
const BACKSLASH = 0x5c;
const TRUE = new Uint8Array([0x74, 0x72, 0x75, 0x65]);
const FALSE = new Uint8Array([0x66, 0x61, 0x6c, 0x73, 0x65]);
const NULL = new Uint8Array([0x6e, 0x75, 0x6c, 0x6c]);
const ESCAPE_TABLE = new Array(128).fill(null);
ESCAPE_TABLE[0x08] = "b";
ESCAPE_TABLE[0x09] = "t";
ESCAPE_TABLE[0x0a] = "n";
ESCAPE_TABLE[0x0c] = "f";
ESCAPE_TABLE[0x0d] = "r";
ESCAPE_TABLE[0x22] = '"';
ESCAPE_TABLE[0x5c] = "\\";
for (let i = 0; i < 0x20; i++) {
    if (ESCAPE_TABLE[i] === null) {
        ESCAPE_TABLE[i] = "u00" + i.toString(16).padStart(2, "0");
    }
}
const INITIAL_BUFFER_SIZE = 2048;
function alloc(size) {
    return JsonBytesStringAdapter.allocUnsafe(size);
}
export class JsonShapeSerializer2 extends SerdeContextConfig {
    settings;
    json;
    i = 0;
    rootSchema;
    rawValue;
    passthrough = false;
    constructor(settings) {
        super();
        this.settings = settings;
        this.json = alloc(INITIAL_BUFFER_SIZE);
    }
    write(schema, value) {
        this.i = 0;
        this.rawValue = value;
        this.rootSchema = NormalizedSchema.of(schema);
        this.passthrough = this.rootSchema.isBlobSchema() || this.rootSchema.isStringSchema();
        if (!this.passthrough) {
            this.writeValue(this.rootSchema, value, undefined);
        }
    }
    writeDiscriminatedDocument(schema, value) {
        this.i = 0;
        this.rootSchema = NormalizedSchema.of(schema);
        const ns = this.rootSchema;
        if (ns.isStructSchema() && value != null && typeof value === "object") {
            this.writeValue(ns, value, undefined);
            const prefix = `"__type":"${ns.getName(true) ?? "Unknown"}",`;
            const z = prefix.length;
            this.ensure(z);
            this.json.copyWithin(1 + z, 1, this.i);
            encoder.encodeInto(prefix, this.json.subarray(1));
            this.i += z;
        }
        else {
            this.writeValue(ns, value, undefined);
        }
    }
    flush() {
        this.rootSchema = undefined;
        const finalPosition = this.i;
        this.i = 0;
        const raw = this.rawValue;
        this.rawValue = undefined;
        if (finalPosition === 0) {
            return raw;
        }
        const result = this.json.subarray(0, finalPosition);
        this.json = alloc(INITIAL_BUFFER_SIZE);
        return result;
    }
    ensure(byteCount) {
        const { i, json } = this;
        if (i + byteCount > json.length) {
            let newSize = json.length * 2;
            while (newSize < i + byteCount) {
                newSize *= 2;
            }
            const next = alloc(newSize);
            next.set(this.json);
            this.json = next;
        }
    }
    writeAscii(s) {
        const z = s.length;
        this.ensure(z);
        let { i, json } = this;
        for (let j = 0; j < z; ++j) {
            json[i] = s.charCodeAt(j);
            i += 1;
        }
        this.i = i;
    }
    writeAsciiQuoted(s) {
        const z = s.length;
        this.ensure(z + 4);
        let { json, i } = this;
        json[i++] = QUOTE;
        for (let j = 0; j < z; ++j) {
            json[i++] = s.charCodeAt(j);
        }
        json[i++] = QUOTE;
        this.i = i;
    }
    writeJsonString(s) {
        this.ensure(s.length * 3 + 2);
        this.json[this.i++] = QUOTE;
        const z = s.length;
        for (let j = 0; j < z; ++j) {
            const c = s.charCodeAt(j);
            if (c > 0x22 && c < 0x5c) {
                this.json[this.i++] = c;
            }
            else if (c < 0x80) {
                const esc = ESCAPE_TABLE[c];
                if (esc !== null) {
                    this.ensure(esc.length + 1);
                    this.json[this.i++] = BACKSLASH;
                    for (let k = 0; k < esc.length; k++) {
                        this.json[this.i++] = esc.charCodeAt(k);
                    }
                }
                else {
                    this.json[this.i++] = c;
                }
            }
            else if (c >= 0xd800 && c <= 0xdbff) {
                const next = j + 1 < z ? s.charCodeAt(j + 1) : 0;
                if (next >= 0xdc00 && next <= 0xdfff) {
                    this.ensure(4);
                    const { written } = encoder.encodeInto(s.substring(j, j + 2), this.json.subarray(this.i));
                    this.i += written;
                    ++j;
                }
                else {
                    this.ensure(6);
                    this.writeUnicodeEscape(c);
                }
            }
            else if (c >= 0xdc00 && c <= 0xdfff) {
                this.ensure(6);
                this.writeUnicodeEscape(c);
            }
            else {
                let { i, json } = this;
                if (c < 0x800) {
                    json[i++] = 0xc0 | (c >> 6);
                    json[i++] = 0x80 | (c & 0x3f);
                }
                else {
                    json[i++] = 0xe0 | (c >> 12);
                    json[i++] = 0x80 | ((c >> 6) & 0x3f);
                    json[i++] = 0x80 | (c & 0x3f);
                }
                this.i = i;
            }
        }
        this.json[this.i++] = QUOTE;
    }
    writeUnicodeEscape(code) {
        let { json, i } = this;
        json[i++] = BACKSLASH;
        json[i++] = 0x75;
        const hex = code.toString(16).padStart(4, "0");
        for (let j = 0; j < 4; ++j) {
            json[i++] = hex.charCodeAt(j);
        }
        this.i = i;
    }
    static B64 = (() => {
        const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
        const table = new Uint8Array(64);
        for (let i = 0; i < 64; ++i) {
            table[i] = chars.charCodeAt(i);
        }
        return table;
    })();
    writeBase64(data) {
        const b64Len = Math.ceil(data.length / 3) * 4;
        this.ensure(b64Len + 2);
        const json = this.json;
        const B64 = JsonShapeSerializer2.B64;
        let i = this.i;
        json[i++] = QUOTE;
        const len = data.length;
        const remainder = len % 3;
        const mainLen = len - remainder;
        for (let j = 0; j < mainLen; j += 3) {
            const a = data[j];
            const b = data[j + 1];
            const c = data[j + 2];
            json[i++] = B64[a >> 2];
            json[i++] = B64[((a & 0x03) << 4) | (b >> 4)];
            json[i++] = B64[((b & 0x0f) << 2) | (c >> 6)];
            json[i++] = B64[c & 0x3f];
        }
        if (remainder === 2) {
            const a = data[mainLen];
            const b = data[mainLen + 1];
            json[i++] = B64[a >> 2];
            json[i++] = B64[((a & 0x03) << 4) | (b >> 4)];
            json[i++] = B64[(b & 0x0f) << 2];
            json[i++] = 0x3d;
        }
        else if (remainder === 1) {
            const a = data[mainLen];
            json[i++] = B64[a >> 2];
            json[i++] = B64[(a & 0x03) << 4];
            json[i++] = 0x3d;
            json[i++] = 0x3d;
        }
        json[i++] = QUOTE;
        this.i = i;
    }
    writeValue(schema, value, container) {
        if (value == null) {
            if (container?.isStructSchema()) {
                if (value === undefined) {
                    const ns = NormalizedSchema.of(schema);
                    if (ns.isIdempotencyToken()) {
                        this.writeAsciiQuoted(generateIdempotencyToken());
                        return;
                    }
                }
                return;
            }
            this.ensure(4);
            this.json.set(NULL, this.i);
            this.i += 4;
            return;
        }
        const ns = NormalizedSchema.of(schema);
        const isObject = typeof value === "object";
        if (ns.isStringSchema()) {
            const mediaType = ns.getMergedTraits().mediaType;
            if (mediaType) {
                const isJson = mediaType === "application/json" || mediaType.endsWith("+json");
                if (isJson) {
                    this.writeJsonString(LazyJsonString.from(value).toString());
                    return;
                }
            }
        }
        if (isObject) {
            if (ns.isStructSchema()) {
                this.writeStruct(ns, value);
                return;
            }
            if (Array.isArray(value) && (ns.isListSchema() || ns.isDocumentSchema())) {
                this.writeList(ns, value, ns.isDocumentSchema());
                return;
            }
            if (ns.isMapSchema()) {
                this.writeMap(ns, value, false);
                return;
            }
            if (value instanceof Uint8Array && (ns.isBlobSchema() || ns.isDocumentSchema())) {
                this.writeBase64(value);
                return;
            }
            if (value instanceof Date && (ns.isTimestampSchema() || ns.isDocumentSchema())) {
                this.writeTimestamp(ns, value);
                return;
            }
            if (value instanceof NumericValue) {
                this.writeAscii(value.string);
                return;
            }
            if (ns.isDocumentSchema()) {
                if (Array.isArray(value)) {
                    this.writeList(ns, value, true);
                }
                else {
                    this.writeMap(ns, value, true);
                }
                return;
            }
            const json = JSON.stringify(value);
            this.writeAscii(json);
            return;
        }
        if (typeof value === "string") {
            if (ns.isBlobSchema()) {
                const b64 = (this.serdeContext?.base64Encoder ?? toBase64)(value);
                this.writeAsciiQuoted(b64);
                return;
            }
            this.writeJsonString(value);
            return;
        }
        if (typeof value === "number") {
            if (Math.abs(value) === Infinity || Number.isNaN(value)) {
                this.writeAsciiQuoted(String(value));
                return;
            }
            const numStr = String(value);
            this.writeAscii(numStr);
            return;
        }
        if (typeof value === "boolean") {
            this.ensure(5);
            let { i, json } = this;
            if (value) {
                json.set(TRUE, i);
                i += 4;
            }
            else {
                json.set(FALSE, i);
                i += 5            if (Math.abs(value) =           if (Math.abs(value) = null) di;
        D {
                fSalue)      if (ty ) =           ifui++] = 0xca7[t(j);
   nfig } fronst b64Len = MwroteAnyis.rootSchema, val
        return value;
         _readStruct(ns, record) {
 = MwrensurKeyay(0, finalPosithis._read(memberSchemawrensurKeya this.iSet(sonName && hasType) {
            nameMap = {};
        }
        let unionSerde;
        if (unionst listMealue);
        if (s.isStringSchema() stMea
        t!alue !== undeer?.isStructSchema()) {
                d;
 inlue.length; ++i) {
               wroteAny           this.ensure(6);
     1    if (typeof value ==== 0xca7[t(j);
   ;
cone.length; ++i) {
           wroteAnyis.                   (typeof record.__xtConfig {
  .type === "stalue !== undefined) {
                        let tars.i+    unionSerde = new UnionSewrensurKeya           this.ensuwrensurKeya.adf (union tars;        this.ensuwrensurKeya.adf of record))) {
                const b64 = (thisturn;
      of record))) {
         e ==== 0xca7[t(j);
   ;
LON;  this.json.copyWithin(1 + z,t outCount = 0 stMfor (const [mem       }
     !wroteAnyiInfinity             
        if (unionst l               chema() && value != und }
                }
                if (nsSchema() && outCount === 0) {
           64 = (thisturn;
      k    if (typeof value ===;
     1    if (typeof value ==== 0xca7[t(j);
   ;
LON;  this.json.con.copyWithin(1 + z,targefor (const [memberN}          out[memberName] = this._read(memberSchema, record[fromKey;
            return;
   onSewrensurKeya.has(k             nameMap = {};
  inlue.length; ++i)                this.wwrensurKeya.adf k    }
                }
 (value);
                }
       wroteAny           this.ensuvalue ===;
     1    if (typeof valuvalue ==== 0xca7[t(j);
   ;
cone.length; ++i)                this.wwroteAnyis.                      64 = (thisturn;
      k    if (typeof value ===;
     1    if (typeof value ==== 0xca7[t(j);
   ;
LON;  this.json.con.copyWithin(1 + z,targefo      const ns = this.ro       json[i++] = 0x80 |;
     1    if (type ==== 0xca7[t(j);
   ;rableSerdedi;
        D {
 
               
         ray(64);
        f       }
            if (ns.isMapSchema()) {
      }
 (          m));
                    }
         !
         ray(64);
   (numStr);
         this.rawValue = v    ;
         thiew NumericValue(   ;
         thiB      JSON.stringify(value);
      = MhasSpecialsis.rootSchema, valstatic B64 = (() => {
         }
        if (ns.isDocumentSchema()) {         if (isObject) {
               Str)      this.wrie(   ;         }
      ;     -    }
      (vea
        t!pSchem)) {
                if (valuhasSpecialsis.                     writeKey(break                  if (ns.isIdempotencyToken()) {
         s.i;
ble;
    })() }
         !hasSpecialsure(6);
                this
                else {
               f (!(v instanceof NumericValue)) {
                   
            }
                return value;
        }
        if (ns.isDocumentSchema()) {
            if (isObject) {
                if (Arrvea
        t!pSchem)_k in value) {
              ;
  inlue.length; ++i)            Str)      this.wrie(   ;         }
      ;     -    }
            const v = record[k];
    = !!nsalue) = )_v = value[_k];
                    if (sparse || _v instanceof NumericValue) {
    ];
    = !!nsetKey = jsonName ? (nameMap[k] ?? k) : k;
                        if    this
                e           for (const }  if (typeof value ===;
           return r3    if (typeof value ===(valuharCodeAt(j + 1) :       next >= 0xdc00 && next <= 0.s.ensure(4);
             "number") {
            if (M}ue)      if (ty ) =           ifui++] = 0xca7[t(j);
   nfig } frKETnst b64Len = MwroteFirsuniomis.rootSchema, val return value;
        }
        if (ns.isDocumentSchonst listMealue);
 i(s.isStringSchema()           ?listMea;
    }
     :  stMea
        t!pSchem) {
                d;
 inlue.length; ++i) {
               wroteFirsuniom           this.ensure(6);
     1    if (typeof value ==== 0xca7[t(j);
   ;
cone.length; ++i) {
           opyWithin(1 + z,;
          0 stMfo      const ns = this.rowroteFirsuniomis.          return (this.sx80 |;
     1    if (type ==== 0xca7[t(j);
   ;rableSerdKETnst b6      D {
   if (Array.isA
         ray(64);
        f       }
            if (ns.isMapSchema()) {
      }
 (          m));
                    }
         !
         ray(64);
   (numStr);
         this.rawValue = v    ;
         thiew NumericValue(   ;
         thiB      JSON.stringin()) {
         s.i;modifgSchemas                return (this.serdeContext?.base64Encoder ?? toBase64)(value);
                }
                 this.wrie(   ;         }
      ;     -    }
            const v = record[k(modifgSchemas ??    ));
                    }
     i < value;
   alue) = )                }
                    if (v insta(Arrvea

        t!pSchem) {
                record[k(modifgSchemas ??    ));
                       }
     i < value;
           this.rootSc        if (ns.isIdempotencyToken()) {
                  }
                else {
                   consodifgSchemas) {
                reco      .assign(ray.isAsodifgSchemas)       for (const }  if (typeof value ===;
           return r3    if (typeof value ===(valuharCodeAt(j + 1) :       next >= 0xdc00 && next <= 0.s.ensure(4);
             "number") {
            if (M}ue)      if (ty ) =           ifui++] = 0xca7[t(j);
   nfig } fronst b64Len = Mfirsuis.          retuturn (this.serdeContext?.base64Encodease64)(value);
                }ma()           ?lvea;
    }
     : vea
        t!pSchem) {
                d;
 inlue.length; ++i) {
               !firsu           this.ensure(6);
     1    if (typeof value ==== 0xca7[t(j);
   ;
cone.length; ++i) {
           firsuis.rootSchema, valstat64 = (this.serdeContek)     this.writeValue(ns, v1))) {
         e ==== 0xca7[t(j);
   ;
LON;  this.json.copyWithin(1 + z,;
          0vi);
            encoder.enco = 0x80 |;
     1    if (type ==== 0xca7[t(j);
   ;rableSerdedi;
        D {
             return;
ay(64);
        fer ?? toBase64)(value);
            }
            if (value in Date && (ns.isTimestampSchema.isDocut = typeof value === "objecovalue);
t format = determineTimestampFormat(ns, this.settings)64 = (thisturn;
      isof (typeof value === "number") {
            if (Math.a      String(value);
            return;
                   case 5:
 f (typeof value === "number") {
            if (Math.a    7ut = typeof value === "obj     Secs== Infinity ||                de(ns, this.settings)64 = (thisturn;(     Secsf (typeof value === "number") {
            if (Math.        t = typeof value === "obj     Secs== Infinity ||                de(ns, this.settings)64 = (thisturn;(     Secsf (typeof value === "number") {
            if (M}      return true;
        }
        if (ns.isStringSchema() && ns.getMergedTraits().mediaType) {
            return true;
        }
        return false;
    }
}
