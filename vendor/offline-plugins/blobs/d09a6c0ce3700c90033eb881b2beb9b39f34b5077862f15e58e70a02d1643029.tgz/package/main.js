module.exports.templateTags = [{
    name: "clipboard-value",
    displayName: 'Clipboard Value',
    description: 'Returns the current text from your system clipboard',
    async run(context) {
        try {
          return context.app.clipboard.readText();
        } catch (error) {
          console.error("Error reading clipboard", error);
          throw error;
        }
      }
}];
