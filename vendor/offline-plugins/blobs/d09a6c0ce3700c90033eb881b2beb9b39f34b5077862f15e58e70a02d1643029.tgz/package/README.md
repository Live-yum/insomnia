# insomnia-plugin-clipboard
Insomnia plugin to use current clipboard value
