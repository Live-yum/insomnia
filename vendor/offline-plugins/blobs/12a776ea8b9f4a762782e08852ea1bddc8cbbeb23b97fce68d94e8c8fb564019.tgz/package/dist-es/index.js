export { fromIni } from "./fromIni";
