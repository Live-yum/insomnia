const COLORS = {
  key:     '#79c0ff',
  string:  '#a5d6ff',
  number:  '#ff7b72',
  boolean: '#ff7b72',
  null:    '#8b949e',
  brace:   '#e6edf3',
  error:   '#f85149',
  ok:      '#3fb950',
  label:   '#8b949e',
};

function tryParseJson(str) {
  try {
    const trimmed = str.trim();
    if ((trimmed.startsWith('{') || trimmed.startsWith('[')) && trimmed.length > 2) {
      return JSON.parse(trimmed);
    }
  } catch {}
  return null;
}

function deepExpand(value, depth = 0) {
  if (depth > 10) return value;
  if (typeof value === 'string') {
    const parsed = tryParseJson(value);
    if (parsed !== null) return deepExpand(parsed, depth + 1);
    return value;
  }
  if (Array.isArray(value)) return value.map(v => deepExpand(v, depth + 1));
  if (value !== null && typeof value === 'object') {
    const result = {};
    for (const [k, v] of Object.entries(value)) result[k] = deepExpand(v, depth + 1);
    return result;
  }
  return value;
}

function syntaxHighlight(json) {
  return json
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(
      /("(\\u[a-fA-F0-9]{4}|\\[^u]|[^\\"])*"(\s*:)?|\b(true|false|null)\b|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?)/g,
      (match) => {
        let color = COLORS.number;
        if (/^"/.test(match))              color = /:$/.test(match) ? COLORS.key : COLORS.string;
        else if (/true|false/.test(match)) color = COLORS.boolean;
        else if (/null/.test(match))       color = COLORS.null;
        return `<span style="color:${color}">${match}</span>`;
      }
    );
}

function parseSse(body) {
  const blocks = [];
  for (const rawLine of body.split('\n')) {
    const line = rawLine.trim();
    if (!line) continue;
    if (line.startsWith('event:')) { blocks.push({ event: line.slice(6).trim(), data: null }); continue; }
    if (line.startsWith('data:')) {
      const raw = line.slice(5).trim();
      let parsed; try { parsed = JSON.parse(raw); } catch { parsed = raw; }
      const last = blocks[blocks.length - 1];
      if (last) last.data = parsed; else blocks.push({ event: null, data: parsed });
    }
  }
  return blocks;
}

function renderBlock(block, index) {
  const isError = block.data?.result?.isError === true;
  const border = isError ? COLORS.error : COLORS.ok;
  const badge = isError
    ? `<span style="color:${COLORS.error};font-weight:bold">✗ isError</span>`
    : `<span style="color:${COLORS.ok};font-weight:bold">✓ ok</span>`;
  const eventLabel = block.event
    ? `<span style="color:${COLORS.label}">event: </span><span style="color:${COLORS.string}">${block.event}</span> &nbsp;`
    : '';
  const pretty = typeof block.data === 'object'
    ? JSON.stringify(deepExpand(block.data), null, 2) : String(block.data ?? '');

  return `<div style="border-left:3px solid ${border};margin:8px 0;padding:10px 14px;background:#161b22;border-radius:4px;">
    <div style="margin-bottom:6px;font-size:11px;color:${COLORS.label}">#${index + 1} &nbsp;${eventLabel}${badge}</div>
    <pre style="margin:0;white-space:pre-wrap;word-break:break-all;font-size:12px;line-height:1.5;color:${COLORS.brace}">${syntaxHighlight(pretty)}</pre>
  </div>`;
}

module.exports.responseHooks = [
  async function(context) {
    try {
      const raw = await context.response.getBody();
      if (!raw) return;

      let body;
      if (typeof raw === 'string' && /^\d+(,\d+)*$/.test(raw.slice(0, 20))) {
        body = Buffer.from(raw.split(',').map(Number)).toString('utf8');
      } else {
        body = Buffer.from(raw).toString('utf8');
      }

      if (!body.includes('"jsonrpc"')) return;

      const blocks = parseSse(body);
      if (blocks.length === 0) return;

      const html = `<div style="background:#0d1117;padding:16px;font-family:monospace;max-height:80vh;overflow:auto;">
        <div style="color:#8b949e;font-size:12px;margin-bottom:12px;border-bottom:1px solid #21262d;padding-bottom:8px;">
          MCP — ${blocks.length} message(s)
        </div>
        ${blocks.map(renderBlock).join('')}
      </div>`;

      const win = window.open('', 'mcp-formatter', 'width=800,height=600,scrollbars=yes');
      win.document.open();
      win.document.write(`<!DOCTYPE html><html><head><meta charset="utf-8">
        <title>MCP Response</title>
        <style>body{margin:0;background:#0d1117;}</style>
      </head><body>${html}</body></html>`);
      win.document.close();
    } catch (e) {
      await context.app.alert('error', e.message);
    }
  }
];
