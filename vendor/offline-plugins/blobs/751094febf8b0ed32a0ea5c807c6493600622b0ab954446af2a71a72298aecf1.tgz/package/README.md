# insomnia-plugin-mcp-formatter

An [Insomnia](https://insomnia.rest) plugin that formats SSE/JSON-RPC responses from MCP (Model Context Protocol) servers into readable, syntax-highlighted JSON.

## The problem

MCP servers respond over Server-Sent Events (SSE) with JSON-RPC payloads. In Insomnia, this looks like:

```
event: message
data: {"result":{"content":[{"type":"text","text":"An error occurred invoking 'close_booking': Request failed — CLOSE_BOOKING_FAILED: No Reservation to Commit!"}],"isError":true},"id":1,"jsonrpc":"2.0"}
```

Unreadable, especially when `text` fields themselves contain nested JSON strings.

## What it does

After every request, if the response contains JSON-RPC content, a formatted window opens automatically showing:

- Each SSE message as a separate block
- Full syntax highlighting (keys, strings, numbers, booleans, nulls)
- Nested JSON strings automatically expanded and formatted recursively
- A `✓ ok` / `✗ isError` badge per message
- Dark theme

## Installation

In Insomnia: **Preferences → Plugins** → search for `insomnia-plugin-mcp-formatter` → **Install Plugin**.

Or install manually:

```bash
cd ~/Library/Application\ Support/Insomnia/plugins   # macOS
npm install insomnia-plugin-mcp-formatter
```

## How it works

The plugin registers a `responseHook` that fires after every request. If the response body contains `"jsonrpc"`, it parses the SSE stream, recursively expands any JSON-encoded string values, and opens a formatted window via `window.open`.

It does not modify the original response stored by Insomnia.

## Compatibility

Works with any MCP server using the SSE transport (JSON-RPC 2.0 over `text/event-stream`). Not specific to any MCP implementation.

## License

MIT
