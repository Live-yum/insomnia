// Request hook to set header on every request
module.exports.requestHooks = [
 
    context => {

        let UserPswd = [];
        UserPswd.push("{Username: 'User1', Password: 'Password1'}");
        UserPswd.push("{Username: 'User2', Password: 'Password2'}");
        UserPswd.push("{Username: 'User3', Password: 'Password3'}");
    
        var len = UserPswd.length;
    
        for (var i = 0; i < len; i++) {

        if (context.request.getMethod().toUpperCase() === 'POST') {
            context.request.setUrl("https://httpbin.org/POST");
            context.request.setBodyText(UserPswd[i]);
        };

        const response = await context.network.sendRequest(requests[0]);
        const style =
          response.statusCode !== 200
            ? "padding:5px; color: var(--color-font-danger); background: var(--color-danger)"
            : "padding:5px; color: var(--color-font-success); background: var(--color-success)";
        results.push(
          `<li style="margin: 5px">${request.name}: <span style="${style}")>${response.statusCode}</span><span>${context.response.getTime}</span></li>`
        );
      }
      const html = `<ul style="column-count: ${
        results.length > 10 ? 2 : 1
      };">${results.join("\n")}</ul>`;

      context.app.showGenericModalDialog("Results", { html });
    }
  ];