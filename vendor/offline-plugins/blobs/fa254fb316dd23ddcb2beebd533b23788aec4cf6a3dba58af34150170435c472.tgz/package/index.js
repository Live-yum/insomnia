/*!
 * send
 * Copyright(c) 2012 TJ Holowaychuk
 * Copyright(c) 2014-2022 Douglas Christopher Wilson
 * MIT Licensed
 */

'use strict'

/**
 * Module dependencies.
 * @private
 */

var createError = require('http-errors')
var debug = require('debug')('send')
var encodeUrl = require('encodeurl')
var escapeHtml = require('escape-html')
var etag = require('etag')
var fresh = require('fresh')
var fs = require('fs')
var mime = require('mime-types')
var ms = require('ms')
var onFinished = require('on-finished')
var parseRange = require('range-parser')
var path = require('path')
var statuses = require('statuses')
var Stream = require('stream')
var util = require('util')

/**
 * Path function references.
 * @private
 */

var extname = path.extname
var join = path.join
var normalize = path.normalize
var resolve = path.resolve
var sep = path.sep

/**
 * Regular expression for identifying a bytes Range header.
 * @private
 */

var BYTES_RANGE_REGEXP = /^ *bytes=/

/**
 * Maximum value allowed for the max age.
 * @private
 */

var MAX_MAXAGE = 60 * 60 * 24 * 365 * 1000 // 1 year

/**
 * Regular expression to match a path with a directory up component.
 * @private
 */

var UP_PATH_REGEXP = /(?:^|[\\/])\.\.(?:[\\/]|$)/

/**
 * Module exports.
 * @public
 */

module.exports = send

/**
 * Return a `SendStream` for `req` and `path`.
 *
 * @param {object} req
 * @param {string} path
 * @param {object} [options]
 * @return {SendStream}
 * @public
 */

function send (req, path, options) {
  return new SendStream(req, path, options)
}

/**
 * Initialize a `SendStream` with the given `path`.
 *
 * @param {Request} req
 * @param {String} path
 * @param {object} [options]
 * @private
 */

function SendStream (req, path, options) {
  Stream.call(this)

  var opts = options || {}

  this.options = opts
  this.path = path
  this.req = req

  this._acceptRanges = opts.acceptRanges !== undefined
    ? Boolean(opts.acceptRanges)
    : true

  this._cacheControl = opts.cacheControl !== undefined
    ? Boolean(opts.cacheControl)
    : true

  this._etag = opts.etag !== undefined
    ? Boolean(opts.etag)
    : true

  this._dotfiles = opts.dotfiles !== undefined
    ? opts.dotfiles
    : 'ignore'

  if (this._dotfiles !== 'ignore' && this._dotfiles !== 'allow' && this._dotfiles !== 'deny') {
    throw new TypeError('dotfiles option must be "allow", "deny", or "ignore"')
  }

  this._extensions = opts.extensions !== undefined
    ? normalizeList(opts.extensions, 'extensions option')
    : []

  this._immutable = opts.immutable !== undefined
    ? Boolean(opts.immutable)
    : false

  this._index = opts.index !== undefined
    ? normalizeList(opts.index, 'index option')
    : ['index.html']

  this._lastModified = opts.lastModified !== undefined
    ? Boolean(opts.lastModified)
    : true

  this._maxage = opts.maxAge || opts.maxage
  this._maxage = typeof this._maxage === 'string'
    ? ms(this._maxage)
    : Number(this._maxage)
  this._maxage = !isNaN(this._maxage)
    ? Math.min(Math.max(0, this._maxage), MAX_MAXAGE)
    : 0

  this._root = opts.root
    ? resolve(opts.root)
    : null
}

/**
 * Inherits from `Stream`.
 */

util.inherits(SendStream, Stream)

/**
 * Emit error with `status`.
 *
 * @param {number} status
 * @param {Error} [err]
 * @private
 */

SendStream.prototype.error = function error (status, err) {
  // emit if listeners instead of responding
  if (hasListeners(this, 'error')) {
    return this.emit('error', createHttpError(status, err))
  }

  var res = this.res
  var msg = statuses.message[status] || String(status)
  var doc = createHtmlDocument('Error', escapeHtml(msg))

  // clear existing headers
  clearHeaders(res)

  // add error headers
  if (err && err.headers) {
    setHeaders(res, err.headers)
  }

  // send basic response
  res.statusCode = status
  res.setHeader('Content-Type', 'text/html; charset=UTF-8')
  res.setHeader('Content-Length', Buffer.byteLength(doc))
  res.setHeader('Content-Security-Policy', "default-src 'none'")
  res.setHeader('X-Content-Type-Options', 'nosniff')
  res.end(doc)
}

/**
 * Check if the pathname ends with "/".
 *
 * @return {boolean}
 * @private
 */

SendStream.prototype.hasTrailingSlash = function hasTrailingSlash () {
  return this.path[this.path.length - 1] === '/'
}

/**
 * Check if this is a conditional GET request.
 *
 * @return {Boolean}
 * @api private
 */

SendStream.prototype.isConditionalGET = function isConditionalGET () {
  return this.req.headers['if-match'] ||
    this.req.headers['if-unmodified-since'] ||
    this.req.headers['if-none-match'] ||
    this.req.headers['if-modified-since']
}

/**
 * Check if the request preconditions failed.
 *
 * @return {boolean}
 * @private
 */

SendStream.prototype.isPreconditionFailure = function isPreconditionFailure () {
  var req = this.req
  var res = this.res

  // if-match
  var match = req.headers['if-match']
  if (match) {
    var etag = res.getHeader('ETag')
    return !etag || (match !== '*' && parseTokenList(match).every(function (match) {
      return match !== etag && match !== 'W/' + etag && 'W/' + match !== etag
    }))
  }

  // if-unmodified-since
  var unmodifiedSince = parseHttpDate(req.headers['if-unmodified-since'])
  if (!isNaN(unmodifiedSince)) {
    var lastModified = parseHttpDate(res.getHeader('Last-Modified'))
    return isNaN(lastModified) || lastModified > unmodifiedSince
  }

  return false
}

/**
 * Strip various content header fields for a change in entity.
 *
 * @private
 */

SendStream.prototype.removeContentHeaderFields = function removeContentHeaderFields () {
  var res = this.res

  res.removeHeader('Content-Encoding')
  res.removeHeader('Content-Language')
  res.removeHeader('Content-Length')
  res.removeHeader('Content-Range')
  res.removeHeader('Content-Type')
}

/**
 * Respond with 304 not modified.
 *
 * @api private
 */

SendStream.prototype.notModified = function notModified () {
  var res = this.res
  debug('not modified')
  this.removeContentHeaderFields()
  res.statusCode = 304
  res.end()
}

/**
 * Raise error that headers already sent.
 *
 * @api private
 */

SendStream.prototype.headersAlreadySent = function headersAlreadySent () {
  var err = new Error('Can\'t set headers after they are sent.')
  debug('headers already sent')
  this.error(500, err)
}

/**
 * Check if the request is cacheable, aka
 * responded with 2xx or 304 (see RFC 2616 section 14.2{5,6}).
 *
 * @return {Boolean}
 * @api private
 */

SendStream.prototype.isCachable = function isCachable () {
  var statusCode = this.res.statusCode
  return (statusCode >= 200 && statusCode < 300) ||
    statusCode === 304
}

/**
 * Handle stat() error.
 *
 * @param {Error} error
 * @private
 */

SendStream.prototype.onStatError = function onStatError (error) {
  switch (error.code) {
    case 'ENAMETOOLONG':
    case 'ENOENT':
    case 'ENOTDIR':
      this.error(404, error)
      break
    default:
      this.error(500, error)
      break
  }
}

/**
 * Check if the cache is fresh.
 *
 * @return {Boolean}
 * @api private
 */

SendStream.prototype.isFresh = function isFresh () {
  return fresh(this.req.headers, {
    etag: this.res.getHeader('ETag'),
    'last-modified': this.res.getHeader('Last-Modified')
  })
}

/**
 * Check if the range is fresh.
 *
 * @return {Boolean}
 * @api private
 */

SendStream.prototype.isRangeFresh = function isRangeFresh () {
  var ifRange = this.req.headers['if-range']

  if (!ifRange) {
    return true
  }

  // if-range as etag
  if (ifRange.indexOf('"') !== -1) {
    var etag = this.res.getHeader('ETag')
    return Boolean(etag && ifRange.indexOf(etag) !== -1)
  }

  // if-range as modified date
  var lastModified = this.res.getHeader('Last-Modified')
  return parseHttpDate(lastModified) <= parseHttpDate(ifRange)
}

/**
 * Redirect to path.
 *
 * @param {string} path
 * @private
 */

SendStream.prototype.redirect = function redirect (path) {
  var res = this.res

  if (hasListeners(this, 'directory')) {
    this.emit('directory', res, path)
    return
  }

  if (this.hasTrailingSlash()) {
    this.error(403)
    return
  }

  var loc = encodeUrl(collapseLeadingSlashes(this.path + '/'))
  var doc = createHtmlDocument('Redirecting', 'Redirecting to ' + escapeHtml(loc))

  // redirect
  res.statusCode = 301
  res.setHeader('Content-Type', 'text/html; charset=UTF-8')
  res.setHeader('Content-Length', Buffer.byteLength(doc))
  res.setHeader('Content-Security-Policy', "default-src 'none'")
  res.setHeader('X-Content-Type-Options', 'nosniff')
  res.setHeader('Location', loc)
  res.end(doc)
}

/**
 * Pipe to `res.
 *
 * @param {Stream} res
 * @return {Stream} res
 * @api public
 */

SendStream.prototype.pipe = function pipe (res) {
  // root path
  var root = this._root

  // references
  this.res = res

  // decode the path
  var path = decode(this.path)
  if (path === -1) {
    this.error(400)
    return res
  }

  // null byte(s)
  if (~path.indexOf('\0')) {
    this.error(400)
    return res
  }

  var parts
  if (root !== null) {
    // normalize
    if (path) {
      path = normalize('.' + sep + path)
    }

    // malicious path
    if (UP_PATH_REGEXP.test(path)) {
      debug('malicious path "%s"', path)
      this.error(403)
      return res
    }

    // explode path parts
    parts = path.split(sep)

    // join / normalize from optional root dir
    path = normalize(join(root, path))
  } else {
    // ".." is malicious without "root"
    if (UP_PATH_REGEXP.test(path)) {
      debug('malicious path "%s"', path)
      this.error(403)
      return res
    }

    // explode path parts
    parts = normalize(path).split(sep)

    // resolve the path
    path = resolve(path)
  }

  // dotfile handling
  if (containsDotFile(parts)) {
    debug('%s dotfile "%s"', this._dotfiles, path)
    switch (this._dotfiles) {
      case 'allow':
        break
      case 'deny':
        this.error(403)
        return res
      case 'ignore':
      default:
        this.error(404)
        return res
    }
  }

  // index file support
  if (this._index.length && this.hasTrailingSlash()) {
    this.sendIndex(path)
    return res
  }

  this.sendFile(path)
  return res
}

/**
 * Transfer `path`.
 *
 * @param {String} path
 * @api public
 */

SendStream.prototype.send = function send (path, stat) {
  var len = stat.size
  var options = this.options
  var opts = {}
  var res = this.res
  var req = this.req
  var ranges = req.headers.range
  var offset = options.start || 0

  if (res.headersSent) {
    // impossible to send now
    this.headersAlreadySent()
    return
  }

  debug('pipe "%s"', path)

  // set header fields
  this.setHeader(path, stat)

  // set content-type
  this.type(path)

  // conditional GET support
  if (this.isConditionalGET()) {
    if (this.isPreconditionFailure()) {
      this.error(412)
      return
    }

    if (this.isCachable() && this.isFresh()) {
      this.notModified()
      return
    }
  }

  // adjust len to start/end options
  len = Math.max(0, len - offset)
  if (options.end !== undefined) {
    var bytes = options.end - offset + 1
    if (len > bytes) len = bytes
  }

  // Range support
  if (this._acceptRanges && BYTES_RANGE_REGEXP.test(ranges)) {
    // parse
    ranges = parseRange(len, ranges, {
      combine: true
    })

    // If-Range support
    if (!this.isRangeFresh()) {
      debug('range stale')
      ranges = -2
    }

    // unsatisfiable
    if (ranges === -1) {
      debug('range unsatisfiable')

      // Content-Range
      res.setHeader('Content-Range', contentRange('bytes', len))

      // 416 Requested Range Not Satisfiable
      return this.error(416, {
        headers: { 'Content-Range': res.getHeader('Content-Range') }
      })
    }

    // valid (syntactically invalid/multiple ranges are treated as a regular response)
    if (ranges !== -2 && ranges.length === 1) {
      debug('range %j', ranges)

      // Content-Range
      res.statusCode = 206
      res.setHeader('Content-Range', contentRange('bytes', len, ranges[0]))

      // adjust for requested range
      offset += ranges[0].start
      len = ranges[0].end - ranges[0].start + 1
    }
  }

  // clone options
  for (var prop in options) {
    opts[prop] = options[prop]
  }

  // set read options
  opts.start = offset
  opts.end = Math.max(offset, offset + len - 1)

  // content-length
  res.setHeader('Content-Length', len)

  // HEAD support
  if (req.method === 'HEAD') {
    res.end()
    return
  }

  this.stream(path, opts)
}

/**
 * Transfer file for `path`.
 *
 * @param {String} path
 * @api private
 */
SendStream.prototype.sendFile = function sendFile (path) {
  var i = 0
  var self = this

  debug('stat "%s"', path)
  fs.stat(path, function onstat (err, stat) {
    var pathEndsWithSep = path[path.length - 1] === sep
    if (err && err.code === 'ENOENT' && !extname(path) && !pathEndsWithSep) {
      // not found, check extensions
      return next(err)
    }
    if (err) return self if (err) ri,`len - 1)  res.endithSep = path[path.length - Hb d()
}

/*@return {Booleanig} pa=ep) {
      // - Hb d()
}

        return()
}

tory'path'tions) {/ set turn()
}
path(ons) {/ set tu If-RaotModifiedexturn selthis.isPre()
}
s = opts.ex1] === s<= ireturn match !== erreaders: {?err) ri,`len - 1)  res.endi
}

/*()
}

        returnvalid (dsWitth.leng var path)

}
s = opts.ex[i++]
('%s dotfile, path)
  fs.returnth, funct onstat (er) {
    var pathEn return self if (e    }
    if (dithSep = path[path.length - Hb d    }  if (di()
}

tory'path'tio {/ set turnrn()
}
path(o {/ set turn})*
 * Check if tile for ` suppor
 *
 * @param {String} path
 * @api private
 */
SendStream.prototype.sendFile = funIs.indexendFile (pathIs.ind var i = 0
  var se-1f = this

  debug('staotModifiedexturn selthis.isPre++i sta)

}
sth && this.hr pathEn return self if (err) ri,`len - 1)  res.endi
} - Hb d()
}

        returnvalid (dsWitth. pathons) {/

}
sth &&[i])
('%s dotfile, path)
  fs.returnth, funct onstat (er) {
    var pathEn return self if (e    }
    if (dithSep = path[path.length - Hb d    }  if (di()
}

tory'path'tio {/ set turnrn()
}
path(o {/ set turn})*
 * 
 d    }  Strip variouspath
 * @pend t is c  if (aram {String} path
 * @api privating} paOtions]
opts.starvate
 */

SendStream.prototype.isRangeFresquire('sendFile (p, path,ons) {
  Stream.cal this

  debug('= this.res

  // if-match
 , patusCode =uire('ses.DocumeReaq, path,ons)
}

/**
 * t('directory'ar util,e =uire* t(sotype.iipe/ add error rs(rnupstaotModifiers(rnupr ifRangt(sotype.d, inoy(/ dotfile ha c  if ( 
var par, rs(rnupsta = requireheaderrs(rnupd error ers
  iif (contaisotype.oncreateHttpnstat (err,er) {
  sw parse
    rs(rnent. =uire(early'ENOTDs(rnup(If-Range sprivatenrn()
}
i,`len - 1)  res.en}d error erighisotype.oncrendttpnstat (err,endr ifRangt(s)
}

tory'encode*
 * Check if tS-type
  this.typonsed o *
 * @pif tif itngSln'w", enath picitl thitaram {String} path
 * @api private
 */
SendStreamm.prototype.isRangeFres.typ'sendFile (s.typ var res = this.res

  if (hasListeneder('Content-Range') }
/**
 *th - Hb rts
  ifextu= th) && !pathEts
  ifs.typ's')
v.pe
  th/**
(extodifi'ap picc)
  /octet-ar util'stat "%s"'pe
  this.typ%anges.ty)Header('Content-Type', 'text/htmls.ty)HCheck if tS-ty c  if ( lds
  this.semergstif t a chanmay", "pre-
    vaaram {String} path
 * @api privating} paOtions]
/ searvate
 */

SendStream.prototype.isRangeFresContent-dexendFile (paontent-dt) {
  var len = stat.res

  if (hasLis'directory' 'Conteth)
    retu // set conacceptRanges && BYTES_RANG!der('Content-RaAs && ontents'ebug('%s dotfilees && .start urn Booler('Content-TyAs && ontents', en, ran) (this.hasTrailinrol = opts.cacANG!der('Content-Ra && e-opts.ca'ar lastModifiol = opts.cache'

Send, * @-age=pathffsetflooxage)
  this._ / year)this.isCachable = opts.imcase 'allow' = opts.cac+= ', = opts.im'eturnvalid (t "%s"'p&& e-cpts.cac%angeol)
    : true

  der('Content-Typ&& e-opts.ca'geol)
    : true

his.hasTrailinred = this.resANG!der('Content-Raied'))
    retur lastModifimthis.res.gp = pmt)
v.toUTCtus)
  )lid (t "%s"'mthis.res%angem   : true

  der('Location', ed'))
    retgem   : true

his.hasTrailinrRange.in!der('ETag')
    returr lastModifivaacheRang(/ set turnt "%s"'Range%angevarue

  der('Content-Ty retugevarue

* Check if thing h or ready senal ras c  if (aram {String} paq
 * @paraste
 */

function SendStreamrs(res)

  / // root parop icr, s lds
  ting
  ('ETag')
 Names()s.end()
    er('Content-Tlds
  ue

* Check if thdingSlah or lhes(th ss.path inson  sing
  is.param {string} path
 * @pstate
 */

SendStreaendStreamrdingSlashes(this.pathSep root parop i  var sel; i <psta this.h; i++elthis.isPre(tr[i]+ etag/'case 'allo  case 'de}turn false
}

/i > }

  /?ag/'ath)tr.l porr(ill
}

/*statCheck if tDetnotineisPr
    parts tFile(pry u
     pi private
 */

SendStreamendStreamrdile(parts)) { 
    deot parop i  var sel; i <p    d this.h; i++elthis.i  if (ronge(lets[i]oleanig} part1] === s> 1okenList[0}

/**
.'return match !== )

    // turn false
}

/**
 * Strip variCocume aange
      res* @private
 {string} path
 * @ps.typenumber} status
 * @optionumber} starray} [start]StreamendStreamrdilbytes',  (s.ty, @opt]))

  rn this.req.he.typ+ 'eHtml= -2 &(optOf(et    }
  '-HtmltOf(etendr:rseT) var dath)optiStrip variCocume aaminimal HTMLtion fileate
 {string} path
 * @psitle {string} path
 * @pbodyte
 */

function SendStreamrocument('Redirect (sitle,pbodyrn this.req.h'<!DOCTYPE set=>\n' +-modif<set= lang="en">\n' +-modif<sead>\n' +-modif<metaTF-8')
  "utf-8">\n' +-modif<sitle>dathsitle var</sitle>\n' +-modif</sead>\n' +-modif<body>\n' +-modif<pre>dathbody var</pre>\n' +-modif</body>\n' +-modif</set=>\n'iStrip variCocume aastatus, e q
 * @enal rsim areargirectsaram {number} status
 * @param {Error} [err]
 *|q
 * @paerrea
 */

function SendStreamrocumentatus, e rr) {
  // emit ifisRan sw parse
 s.req.hr = require var doc = n false
}

/.cod resancmaxaErivatenrn?hr = require var do // e, { * @pse this._
    // :hr = require var do // e)HCheck if ts.pathURIC * @private
if tA    s V8end only de

/*mptiocondifnf respondingallif tof(path()aram {String} path
 * @api private
 */
SendStreammendStream path
  var res = tryparse
 s.req.hs.pathURIC * @priv

  // dot ca.code) { parse
 s.req.h-1f =}tCheck if tDetnotineisPrctorre shas instead ofingath`.
 *geFreram {Stcopyway subjeccondinsionsi"%s"niocorge,dif thistywayh in Node.js sta0.10* Copeccondinonsoli lass t im inson  minimal - 1)usingd resancm  'HEADsaram {number} stEventEtorre }rctorre  {string} path
 * @ps.typenums.req.s
 * @private
 */

SendStreamasTrailingSlthis, 'di (ctorre mls.ty)en = statcouion hs._maxactorre .instead Couion etagasTraili(this._mctorre .instead s(s.ty).es.setHea/ :hctorre .instead Couio(s.ty) false
}

/couion> 0tCheck if tNrom optiot ison')
    : [ inson n arrayaram {number} st* @priv|th
 * |array} val {string} path
 * @poin =e
 */

SendStreamasTrailinist(opts.inde i  l,poin len = stat.nde = [].pe
cati  ldifi[])
('%rop i  var sel; i <p.nde this.h; i++elthis.isPres._maxa.nde[i]+ etag  ? ms(this.notModipeError('dotfiles with + 'ellow", "arraytof(p ? msantiahis._')   // turn false
}

/.nde Pipe to `re8')
n n HTTP ge)
 inson  atus
 ate
 {string} path
 * @p lastM
 */

SendStreamasTrailinate(ifRange)
 ( laslen = statt)
vstamtth. lasokenge)
.ate(i( lasl
this.req.he.tyaxag)
vstamtthetagatus
 (this._mg)
vstamtber(thisaN Pipe to `re8')
n  HTTP tatchp.nde ram {string} path
 * @pstate
 */

SendStreamasTrailinate(imatch).evSep root paUrl = d self = thi.nde = []tusCode = ronge0 error gat
 * tatchs('%rop i  var sel,t.size
  a this.h; i <p.en; i++elthis.iis._dotf  a F-8'
   At(i)case 'allow':
 0x20: /*  treaendi
}

thSep =rong  })nd) headers: { e = ronge= d sei
  }

  /if (err) r      case 'deny':
  0x2c: /* ,treaendi
}

thSep =ron!  })nd) headers: { e.nde push()tr.l porr)
  varrt,})nd))

  /if (err) r     = ronge= d sei
  }

  /if (  case 'deny       this.error= d sei
  }

  /if (  case 'de/ clone optifipportatch


thSep =ron!  })nd) header.nde push()tr.l porr)
  varrt,})nd))

 n false
}

/.nde Pipe to `rS-tyan q
 * @eof ready seonras c  if (aram {String} paq
 * @paraste
 */ng} paq
 * @paif (err &
 */

SendStreamasTrailin(res, err. header
    setHeade  vakeyes

Otions.keye( }

  // ('%rop i  var sel; i <pkeye this.h; i++elthis.i  ifkey =pkeye[i]oleander('Content-Tkeyer
    se[ke