/*
 * Copyright (c) Microsoft Corporation. All rights reserved.
 * Licensed under the MIT License.
 */

import {
    ICrypto,
    Logger,
    AuthorizeResponse,
    UrlUtils,
} from "@azure/msal-common/browser";
import {
    BrowserAuthErrorCodes,
    createBrowserAuthError,
} from "../error/BrowserAuthError.js";
import { extractBrowserRequestState } from "../utils/BrowserProtocolUtils.js";
import { InteractionType } from "../utils/BrowserConstants.js";

export function deserializeResponse(
    responseString: string,
    responseLocation: string,
    logger: Logger,
    correlationId: string
): AuthorizeResponse {
    // Deserialize hash fragment response parameters.
    const serverParams = UrlUtils.getDeserializedResponse(responseString);
    if (!serverParams) {
        if (!UrlUtils.stripLeadingHashOrQuery(responseString)) {
            // Hash or Query string is empty
            logger.error(
                `The request has returned to the redirectUri but a '${responseLocation}' is not present. It's likely that the '${responseLocation}' has been removed or the page has been redirected by code running on the redirectUri page.`,
                correlationId
            );
            throw createBrowserAuthError(
                BrowserAuthErrorCodes.hashEmptyError,
                correlationId
            );
        } else {
            logger.error(
                `A '${responseLocation}' is present in the iframe but it does not contain known properties. It's likely that the '${responseLocation}' has been replaced by code running on the redirectUri page.`,
                correlationId
            );
            logger.errorPii(
                `The '${responseLocation}' detected is: '${responseString}'`,
                correlationId
            );
            throw createBrowserAuthError(
                BrowserAuthErrorCodes.hashDoesNotContainKnownProperties,
                correlationId
            );
        }
    }
    return serverParams;
}

/**
 * Returns the interaction type that the response object belongs to
 */
export function validateInteractionType(
    response: AuthorizeResponse,
    browserCrypto: ICrypto,
    interactionType: InteractionType,
    correlationId: string
): void {
    if (!response.state) {
        throw createBrowserAuthError(
            BrowserAuthErrorCodes.noStateInHash,
            correlationId
        );
    }

    const platformStateObj = extractBrowserRequestState(
        browserCrypto,
        response.state,
        correlationId
    );
    if (!platformStateObj) {
        throw createBrowserAuthError(
            BrowserAuthErrorCodes.unableToParseState,
            correlationId
        );
    }

    if (platformStateObj.interactionType !== interactionType) {
        throw createBrowserAuthError(
            BrowserAuthErrorCodes.stateInteractionTypeMismatch,
            correlationId
        );
    }
}
