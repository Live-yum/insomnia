/*
 * Copyright (c) Microsoft Corporation. All rights reserved.
 * Licensed under the MIT License.
 */

import {
    AADServerParamKeys,
    AccessTokenEntity,
    AccountEntity,
    AccountEntityUtils,
    AccountInfo,
    AuthError,
    AuthToken,
    AuthorityType,
    CacheHelpers,
    ClientAuthErrorCodes,
    CommonSilentFlowRequest,
    Constants,
    ICrypto,
    IPerformanceClient,
    IdTokenEntity,
    InProgressPerformanceEvent,
    Logger,
    PerformanceEvents,
    PopTokenGenerator,
    RequestParameterBuilder,
    ScopeSet,
    ServerTelemetryManager,
    SignedHttpRequestParameters,
    StoreInCache,
    TimeUtils,
    TokenClaims,
    ITokenBindingKeyManager,
    UrlString,
    buildAccountToCache,
    createClientAuthError,
    invokeAsync,
    updateAccountTenantProfileData,
} from "@azure/msal-common/browser";
import { IPlatformAuthHandler } from "../broker/nativeBroker/IPlatformAuthHandler.js";
import {
    createPlatformAuthExtraParametersNoCache,
    isProofOfPossessionTokenType,
    PlatformAuthExtraParametersNoCache,
    PlatformAuthRequest,
} from "../broker/nativeBroker/PlatformAuthRequest.js";
import {
    MATS,
    PlatformAuthResponse,
} from "../broker/nativeBroker/PlatformAuthResponse.js";
import { BrowserCacheManager } from "../cache/BrowserCacheManager.js";
import { BrowserConfiguration } from "../config/Configuration.js";
import { base64Decode } from "../encode/Base64Decode.js";
import {
    BrowserAuthErrorCodes,
    createBrowserAuthError,
} from "../error/BrowserAuthError.js";
import {
    NativeAuthError,
    NativeAuthErrorCodes,
    createNativeAuthError,
    isFatalNativeAuthError,
} from "../error/NativeAuthError.js";
import { EventHandler } from "../event/EventHandler.js";
import { INavigationClient } from "../navigation/INavigationClient.js";
import { NavigationOptions } from "../navigation/NavigationOptions.js";
import { version } from "../packageMetadata.js";
import { HandleRedirectPromiseOptions } from "../request/HandleRedirectPromiseOptions.js";
import { PopupRequest } from "../request/PopupRequest.js";
import { RedirectRequest } from "../request/RedirectRequest.js";
import { SilentRequest } from "../request/SilentRequest.js";
import { SsoSilentRequest } from "../request/SsoSilentRequest.js";
import { AuthenticationResult } from "../response/AuthenticationResult.js";
import * as BrowserPerformanceEvents from "../telemetry/BrowserPerformanceEvents.js";
import {
    ApiId,
    BrowserConstants,
    CacheLookupPolicy,
    PlatformAuthConstants,
    TemporaryCacheKeys,
} from "../utils/BrowserConstants.js";
import { getCurrentUri } from "../utils/BrowserUtils.js";
import {
    BaseInteractionClient,
    getDiscoveredAuthority,
    getRedirectUri,
    initializeServerTelemetryManager,
} from "./BaseInteractionClient.js";
import { SilentCacheClient } from "./SilentCacheClient.js";

export class PlatformAuthInteractionClient extends BaseInteractionClient {
    protected apiId: ApiId;
    protected accountId: string;
    protected platformAuthProvider: IPlatformAuthHandler;
    protected silentCacheClient: SilentCacheClient;
    protected nativeStorageManager: BrowserCacheManager;
    protected skus: string;

    constructor(
        config: BrowserConfiguration,
        browserStorage: BrowserCacheManager,
        browserCrypto: ICrypto,
        logger: Logger,
        eventHandler: EventHandler,
        navigationClient: INavigationClient,
        apiId: ApiId,
        performanceClient: IPerformanceClient,
        provider: IPlatformAuthHandler,
        accountId: string,
        nativeStorageImpl: BrowserCacheManager,
        correlationId: string,
        tokenBindingKeyManager?: ITokenBindingKeyManager
    ) {
        super(
            config,
            browserStorage,
            browserCrypto,
            logger,
            eventHandler,
            navigationClient,
            performanceClient,
            correlationId,
            provider,
            tokenBindingKeyManager
        );
        this.apiId = apiId;
        this.accountId = accountId;
        this.platformAuthProvider = provider;
        this.nativeStorageManager = nativeStorageImpl;
        this.silentCacheClient = new SilentCacheClient(
            config,
            this.nativeStorageManager,
            browserCrypto,
            logger,
            eventHandler,
            navigationClient,
            performanceClient,
            correlationId,
            provider,
            this.tokenBindingKeyManager
        );

        const extensionName = this.platformAuthProvider.getExtensionName();

        this.skus = ServerTelemetryManager.makeExtraSkuString({
            libraryName: BrowserConstants.MSAL_SKU,
            libraryVersion: version,
            extensionName: extensionName,
            extensionVersion: this.platformAuthProvider.getExtensionVersion(),
        });
    }

    /**
     * Adds SKUs to request extra query parameters
     * @param request {PlatformAuthRequest}
     * @private
     */
    private addRequestSKUs(request: PlatformAuthRequest): void {
        request.extraParameters = {
            ...request.extraParameters,
            [AADServerParamKeys.X_CLIENT_EXTRA_SKU]: this.skus,
        };
    }

    /**
     * Acquire token from native platform via browser extension
     * @param request
     */
    async acquireToken(
        request: PopupRequest | SilentRequest | SsoSilentRequest,
        cacheLookupPolicy?: CacheLookupPolicy
    ): Promise<AuthenticationResult> {
        this.logger.trace(
            "NativeInteractionClient - acquireToken called.",
            this.correlationId
        );

        // start the perf measurement
        const nativeATMeasurement = this.performanceClient.startMeasurement(
            BrowserPerformanceEvents.NativeInteractionClientAcquireToken,
            this.correlationId
        );
        const reqTimestamp = TimeUtils.nowSeconds();

        const serverTelemetryManager = initializeServerTelemetryManager(
            this.apiId,
            this.config.auth.clientId,
            this.correlationId,
            this.browserStorage,
            this.logger,
            undefined,
            this.config.system.serverTelemetryEnabled
        );

        // initialize native request (statically builds the request; does not contact the broker)
        let nativeRequest: PlatformAuthRequest;
        try {
            nativeRequest = await this.initializePlatformRequest(request);
        } catch (e) {
            /*
             * Request initialization (e.g. PoP token generation or authority
             * resolution) failed before the broker was contacted, so end the
             * measurement here to avoid an orphaned sub-measurement.
             * Broker was never engaged, so this was not a native broker outcome.
             */
            nativeATMeasurement.add({
                isNativeBroker: false,
            });
            nativeATMeasurement.end(
                {
                    success: false,
                },
                e
            );
            throw e;
        }

        // check if the tokens can be retrieved from internal cache
        try {
            const result = await this.acquireTokensFromCache(
                this.accountId,
                nativeRequest
            );
            // Served from the native internal cache; token did not come directly from the broker
            nativeATMeasurement.add({
                isNativeBroker: false,
            });
            nativeATMeasurement.end({
                success: true,
                fromCache: true,
            });
            return result;
        } catch (e) {
            if (cacheLookupPolicy === CacheLookupPolicy.AccessToken) {
                this.logger.info(
                    "MSAL internal Cache does not contain tokens, return error as per cache policy",
                    this.correlationId
                );
                nativeATMeasurement.add({
                    isNativeBroker: false,
                });
                nativeATMeasurement.end({
                    success: false,
                });
                throw e;
            }
            // continue with a native call for any and all errors
            this.logger.info(
                "MSAL internal Cache does not contain tokens, proceed to make a native call",
                this.correlationId
            );
        }

        // dispatch the request to the broker
        try {
            const validatedResponse: PlatformAuthResponse =
                await this.platformAuthProvider.sendMessage(nativeRequest);

            const result = await this.handleNativeResponse(
                validatedResponse,
                nativeRequest,
                reqTimestamp,
                request.storeInCache
            );
            nativeATMeasurement.end({
                success: true,
                requestId: result.requestId,
            });
            serverTelemetryManager.clearNativeBrokerErrorCode();
            return result;
        } catch (e) {
            if (e instanceof NativeAuthError) {
                serverTelemetryManager.setNativeBrokerErrorCode(e.errorCode);
            }
            nativeATMeasurement.end(
                {
                    success: false,
                },
                e
            );
            this.setBrokerErrorTelemetry(e);
            throw e;
        }
    }

    /**
     * Records platform-broker error telemetry on the root event for the current
     * correlationId. `isNativeBroker` is set optimistically to true because the
     * broker was engaged; when the caller subsequently falls back to a web flow
     * that succeeds, the root success measurement overrides it to false via
     * `result.fromPlatformBroker`. Terminal broker errors (no fallback) retain
     * true. `brokerErrorName`/`brokerErrorCode` are recorded when the error is an `AuthError`.
     * @param error error thrown by the broker interaction
     */
    private setBrokerErrorTelemetry(error: unknown): void {
        if (error instanceof AuthError) {
            this.performanceClient.addFields(
                {
                    isNativeBroker: true,
                    brokerErrorName: error.name,
                    brokerErrorCode: error.errorCode,
                },
                this.correlationId
            );
        }
    }

    /**
     * Creates silent flow request
     * @param request
     * @param cachedAccount
     * @returns CommonSilentFlowRequest
     */
    private createSilentCacheRequest(
        request: PlatformAuthRequest,
        cachedAccount: AccountInfo
    ): CommonSilentFlowRequest {
        const silentRequest: CommonSilentFlowRequest = {
            authority: request.authority,
            correlationId: this.correlationId,
            scopes: ScopeSet.fromString(
                request.scope,
                this.correlationId
            ).asArray(),
            account: cachedAccount,
            forceRefresh: false,
            resource: request.extraParameters?.resource,
        };

        // Preserve FMI partition semantics for silent cache filtering.
        if (request.attributeTokens) {
            silentRequest.attributeTokens = request.attributeTokens.split(" ");
        }

        return silentRequest;
    }

    /**
     * Fetches the tokens from the cache if un-expired
     * @param nativeAccountId
     * @param request
     * @returns authenticationResult
     */
    protected async acquireTokensFromCache(
        nativeAccountId: string,
        request: PlatformAuthRequest
    ): Promise<AuthenticationResult> {
        if (!nativeAccountId) {
            this.logger.warning(
                "NativeInteractionClient:acquireTokensFromCache - No nativeAccountId provided",
                this.correlationId
            );
            throw createClientAuthError(
                ClientAuthErrorCodes.noAccountFound,
                this.correlationId
            );
        }
        // fetch the account from browser cache
        const account = this.browserStorage.getBaseAccountInfo(
            {
                nativeAccountId,
            },
            this.correlationId
        );

        if (!account) {
            throw createClientAuthError(
                ClientAuthErrorCodes.noAccountFound,
                this.correlationId
            );
        }

        // leverage silent flow for cached tokens retrieval
        try {
            const silentRequest = this.createSilentCacheRequest(
                request,
                account
            );
            const result = await this.silentCacheClient.acquireToken(
                silentRequest
            );

            const idToken = this.browserStorage.getIdToken(
                account,
                this.correlationId,
                this.browserStorage.getTokenKeys(),
                account.tenantId
            );

            const idTokenClaims = AuthToken.extractTokenClaims(
                idToken?.secret || "",
                base64Decode,
                this.correlationId
            );

            const fullAccount = updateAccountTenantProfileData(
                account,
                undefined, // tenantProfile optional
                idTokenClaims,
                idToken?.secret
            );

            return {
                ...result,
                idToken: idToken?.secret || "",
                idTokenClaims: idTokenClaims as TokenClaims,
                account: fullAccount,
            };
        } catch (e) {
            throw e;
        }
    }

    /**
     * Acquires a token from native platform then redirects to the redirectUri instead of returning the response
     * @param {RedirectRequest} request
     * @param {InProgressPerformanceEvent} rootMeasurement
     * @param {HandleRedirectPromiseOptions} options
     */
    async acquireTokenRedirect(
        request: RedirectRequest,
        rootMeasurement: InProgressPerformanceEvent,
        options?: HandleRedirectPromiseOptions
    ): Promise<void> {
        this.logger.trace(
            "NativeInteractionClient - acquireTokenRedirect called.",
            this.correlationId
        );

        const nativeRequest = await this.initializePlatformRequest(request);
        const navigateToLoginRequestUrl =
            options?.navigateToLoginRequestUrl ?? true;

        try {
            await this.platformAuthProvider.sendMessage(nativeRequest);
        } catch (e) {
            // Only throw fatal errors here to allow application to fallback to regular redirect. Otherwise proceed and the error will be thrown in handleRedirectPromise
            if (e instanceof NativeAuthError) {
                const serverTelemetryManager = initializeServerTelemetryManager(
                    this.apiId,
                    this.config.auth.clientId,
                    this.correlationId,
                    this.browserStorage,
                    this.logger,
                    undefined,
                    this.config.system.serverTelemetryEnabled
                );
                serverTelemetryManager.setNativeBrokerErrorCode(e.errorCode);
                if (isFatalNativeAuthError(e)) {
                    /*
                     * Fatal error on redirect initiate always falls back to a
                     * regular web redirect, so this request did not complete
                     * natively. Token telemetry for the eventual outcome lands
                     * in handleRedirectPromise (phase 2).
                     */
                    this.setBrokerErrorTelemetry(e);
                    throw e;
                }
            }
        }
        this.browserStorage.setTemporaryCache(
            TemporaryCacheKeys.NATIVE_REQUEST,
            JSON.stringify({
                ...nativeRequest,
                storeInCache: request.storeInCache,
            }),
            true
        );

        const navigationOptions: NavigationOptions = {
            apiId: ApiId.acquireTokenRedirect,
            timeout: this.config.system.redirectNavigationTimeout,
            noHistory: false,
        };
        const redirectUri = navigateToLoginRequestUrl
            ? UrlString.getAbsoluteUrl(
                  request.redirectStartPage || window.location.href,
                  getCurrentUri(),
                  this.correlationId
              )
            : getRedirectUri(
                  request.redirectUri,
                  this.config.auth.redirectUri,
                  this.logger,
                  this.correlationId
              );
        rootMeasurement.end({ success: true });
        await this.navigationClient.navigateExternal(
            redirectUri,
            navigationOptions
        ); // Need to treat this as external to ensure handleRedirectPromise is run again
    }

    /**
     * If the previous page called native platform for a token using redirect APIs, send the same request again and return the response
     * @param performanceClient {IPerformanceClient?}
     * @param correlationId {string?} correlation identifier
     */
    async handleRedirectPromise(): Promise<AuthenticationResult | null> {
        this.logger.trace(
            "NativeInteractionClient - handleRedirectPromise called.",
            this.correlationId
        );
        if (!this.browserStorage.isInteractionInProgress(true)) {
            this.logger.info(
                "handleRedirectPromise called but there is no interaction in progress, returning null.",
                this.correlationId
            );
            return null;
        }

        // remove prompt from the request to prevent WAM from prompting twice
        const cachedRequest = this.browserStorage.getCachedNativeRequest();
        if (!cachedRequest) {
            this.logger.verbose(
                "NativeInteractionClient - handleRedirectPromise called but there is no cached request, returning null.",
                this.correlationId
            );
            this.performanceClient?.addFields(
                { errorCode: "no_cached_request" },
                this.correlationId
            );
            return null;
        }

        /*
         * storeInCache is a client-side cache directive persisted alongside the cached
         * request (not a broker-contract parameter), so extract it here before resending.
         */
        const { prompt, storeInCache, ...request } =
            cachedRequest as PlatformAuthRequest & {
                storeInCache?: StoreInCache;
            };
        if (prompt) {
            this.logger.verbose(
                "NativeInteractionClient - handleRedirectPromise called and prompt was included in the original request, removing prompt from cached request to prevent second interaction with native broker window.",
                this.correlationId
            );
        }

        this.browserStorage.removeItem(
            this.browserStorage.generateCacheKey(
                TemporaryCacheKeys.NATIVE_REQUEST
            )
        );

        const reqTimestamp = TimeUtils.nowSeconds();

        try {
            this.logger.verbose(
                "NativeInteractionClient - handleRedirectPromise sending message to native broker.",
                this.correlationId
            );
            const response: PlatformAuthResponse =
                await this.platformAuthProvider.sendMessage(request);
            const authResult = await this.handleNativeResponse(
                response,
                request,
                reqTimestamp,
                storeInCache
            );

            const serverTelemetryManager = initializeServerTelemetryManager(
                this.apiId,
                this.config.auth.clientId,
                this.correlationId,
                this.browserStorage,
                this.logger,
                undefined,
                this.config.system.serverTelemetryEnabled
            );
            serverTelemetryManager.clearNativeBrokerErrorCode();
            return authResult;
        } catch (e) {
            this.setBrokerErrorTelemetry(e);
            throw e;
        }
    }

    /**
     * Logout from native platform via browser extension
     * @param request
     */
    logout(): Promise<void> {
        this.logger.trace(
            "NativeInteractionClient - logout called.",
            this.correlationId
        );
        return Promise.reject("Logout not implemented yet");
    }

    /**
     * Transform response from native platform into AuthenticationResult object which will be returned to the end user
     * @param response
     * @param request
     * @param reqTimestamp
     */
    protected async handleNativeResponse(
        response: PlatformAuthResponse,
        request: PlatformAuthRequest,
        reqTimestamp: number,
        storeInCache?: StoreInCache
    ): Promise<AuthenticationResult> {
        this.logger.trace(
            "NativeInteractionClient - handleNativeResponse called.",
            this.correlationId
        );

        // generate identifiers
        const idTokenClaims = AuthToken.extractTokenClaims(
            response.id_token,
            base64Decode,
            this.correlationId
        );

        const homeAccountIdentifier = this.createHomeAccountIdentifier(
            response,
            idTokenClaims
        );

        const cachedhomeAccountId =
            this.browserStorage.getAccountInfoFilteredBy(
                {
                    nativeAccountId: request.accountId,
                },
                this.correlationId
            )?.homeAccountId;

        // add exception for double brokering, please note this is temporary and will be fortified in future
        if (
            request.extraParameters?.child_client_id &&
            response.account.id !== request.accountId
        ) {
            this.logger.info(
                "handleNativeServerResponse: Double broker flow detected, ignoring accountId mismatch",
                this.correlationId
            );
        } else if (
            homeAccountIdentifier !== cachedhomeAccountId &&
            response.account.id !== request.accountId
        ) {
            // User switch in native broker prompt is not supported. All users must first sign in through web flow to ensure server state is in sync
            throw createNativeAuthError(
                NativeAuthErrorCodes.userSwitch,
                this.correlationId
            );
        }

        // Get the preferred_cache domain for the given authority
        const authority = await getDiscoveredAuthority(
            this.config,
            this.correlationId,
            this.performanceClient,
            this.browserStorage,
            this.logger,
            request.authority
        );

        const baseAccount = buildAccountToCache(
            this.browserStorage,
            authority,
            homeAccountIdentifier,
            base64Decode,
            this.correlationId,
            idTokenClaims,
            response.client_info,
            authority.getPreferredCache(), // environment
            idTokenClaims.tid,
            undefined, // auth code payload
            response.account.id,
            this.logger,
            this.performanceClient
        );

        // Ensure expires_in is in number format
        response.expires_in = Number(response.expires_in);

        // generate authenticationResult
        const result = await this.generateAuthenticationResult(
            response,
            request,
            idTokenClaims,
            baseAccount,
            authority.canonicalAuthority,
            reqTimestamp
        );

        // cache accounts and tokens in the appropriate storage
        await this.cacheAccount(baseAccount, AuthToken.isKmsi(idTokenClaims));
        await this.cacheNativeTokens(
            response,
            request,
            homeAccountIdentifier,
            idTokenClaims,
            result.tenantId,
            reqTimestamp,
            authority.getPreferredCache(), // environment
            storeInCache
        );

        return result;
    }

    /**
     * creates an homeAccountIdentifier for the account
     * @param response
     * @param idTokenObj
     * @returns
     */
    protected createHomeAccountIdentifier(
        response: PlatformAuthResponse,
        idTokenClaims: TokenClaims
    ): string {
        // Save account in browser storage
        const homeAccountIdentifier = AccountEntityUtils.generateHomeAccountId(
            response.client_info || "",
            AuthorityType.Default,
            this.logger,
            this.browserCrypto,
            this.correlationId,
            idTokenClaims
        );

        return homeAccountIdentifier;
    }

    /**
     * Helper to generate scopes
     * @param response
     * @param request
     * @returns
     */
    generateScopes(requestScopes: string, responseScopes?: string): ScopeSet {
        return responseScopes
            ? ScopeSet.fromString(responseScopes, this.correlationId)
            : ScopeSet.fromString(requestScopes, this.correlationId);
    }

    /**
     * If PoP token is requesred, records the PoP token if returned from the WAM, else generates one in the browser
     * @param request
     * @param response
     */
    async generatePopAccessToken(
        response: PlatformAuthResponse,
        request: PlatformAuthRequest
    ): Promise<string> {
        if (
            request.tokenType === Constants.AuthenticationScheme.POP &&
            request.signPopToken
        ) {
            /**
             * This code prioritizes SHR returned from the native layer. In case of error/SHR not calculated from WAM and the AT
             * is still received, SHR is calculated locally
             */

            // Check if native layer returned an SHR token
            if (response.shr) {
                this.logger.trace(
                    "handleNativeServerResponse: SHR is enabled in native layer",
                    this.correlationId
                );
                return response.shr;
            }

            // Generate SHR in msal js if WAM does not compute it when POP is enabled
            const popTokenGenerator: PopTokenGenerator = new PopTokenGenerator(
                this.browserCrypto,
                this.tokenBindingKeyManager,
                this.performanceClient
            );
            const shrParameters: SignedHttpRequestParameters = {
                resourceRequestMethod: request.resourceRequestMethod,
                resourceRequestUri: request.resourceRequestUri,
                shrClaims: request.shrClaims,
                shrNonce: request.shrNonce,
                correlationId: this.correlationId,
            };

            /**
             * KeyID must be present in the native request from when the PoP key was generated in order for
             * PopTokenGenerator to query the full key for signing
             */
            if (!request.keyId) {
                throw createClientAuthError(
                    ClientAuthErrorCodes.keyIdMissing,
                    this.correlationId
                );
            }
            return popTokenGenerator.signPopToken(
                response.access_token,
                request.keyId,
                shrParameters
            );
        } else {
            return response.access_token;
        }
    }

    /**
     * Generates authentication result
     * @param response
     * @param request
     * @param idTokenObj
     * @param accountEntity
     * @param authority
     * @param reqTimestamp
     * @returns
     */
    protected async generateAuthenticationResult(
        response: PlatformAuthResponse,
        request: PlatformAuthRequest,
        idTokenClaims: TokenClaims,
        accountEntity: AccountEntity,
        authority: string,
        reqTimestamp: number
    ): Promise<AuthenticationResult> {
        // Add Native Broker fields to Telemetry
        const mats = this.addTelemetryFromNativeResponse(
            response.properties.MATS
        );

        // If scopes not returned in server response, use request scopes
        const responseScopes = this.generateScopes(
            request.scope,
            response.scope
        );

        const accountProperties = response.account.properties || {};
        const uid =
            accountProperties["UID"] ||
            idTokenClaims.oid ||
            idTokenClaims.sub ||
            "";
        const tid = accountProperties["TenantId"] || idTokenClaims.tid || "";

        const accountInfo: AccountInfo | null = updateAccountTenantProfileData(
            AccountEntityUtils.getAccountInfo(accountEntity),
            undefined, // tenantProfile optional
            idTokenClaims,
            response.id_token
        );

        /**
         * In pairwise broker flows, this check prevents the broker's native account id
         * from being returned over the embedded app's account id.
         */
        if (accountInfo.nativeAccountId !== response.account.id) {
            accountInfo.nativeAccountId = response.account.id;
            // Also update the matching tenant profile (source of truth)
            const targetTenantId = tid || accountInfo.tenantId;
            const tenantProfile =
                accountInfo.tenantProfiles?.get(targetTenantId);
            if (tenantProfile) {
                tenantProfile.nativeAccountId = response.account.id;
            }
        }

        // generate PoP token as needed
        const responseAccessToken = await this.generatePopAccessToken(
            response,
            request
        );
        const tokenType =
            request.tokenType === Constants.AuthenticationScheme.POP
                ? Constants.AuthenticationScheme.POP
                : Constants.AuthenticationScheme.BEARER;

        const result: AuthenticationResult = {
            authority: authority,
            uniqueId: uid,
            tenantId: tid,
            scopes: responseScopes.asArray(),
            account: accountInfo,
            idToken: response.id_token,
            idTokenClaims: idTokenClaims,
            accessToken: responseAccessToken,
            fromCache: mats ? this.isResponseFromCache(mats) : false,
            // Request timestamp and NativeResponse expires_in are in seconds, converting to Date for AuthenticationResult
            expiresOn: TimeUtils.toDateFromSeconds(
                reqTimestamp + response.expires_in
            ),
            tokenType: tokenType,
            correlationId: this.correlationId,
            state: response.state,
            fromPlatformBroker: true,
            ...(request.extraParameters?.resource && {
                resource: request.extraParameters.resource,
            }),
        };

        return result;
    }

    /**
     * cache the account entity in browser storage
     * @param accountEntity
     */
    async cacheAccount(
        accountEntity: AccountEntity,
        kmsi: boolean
    ): Promise<void> {
        // Store the account info and hence `nativeAccountId` in browser cache
        await this.browserStorage.setAccount(
            accountEntity,
            this.correlationId,
            kmsi,
            this.apiId
        );
        // Remove any existing cached tokens for this account in browser storage
        this.browserStorage.removeAccountContext(
            AccountEntityUtils.getAccountInfo(accountEntity),
            this.correlationId
        );
    }

    /**
     * Stores the access_token and id_token in inmemory storage
     * @param response
     * @param request
     * @param homeAccountIdentifier
     * @param idTokenObj
     * @param responseAccessToken
     * @param tenantId
     * @param reqTimestamp
     */
    async cacheNativeTokens(
        response: PlatformAuthResponse,
        request: PlatformAuthRequest,
        homeAccountIdentifier: string,
        idTokenClaims: TokenClaims,
        tenantId: string,
        reqTimestamp: number,
        environment: string,
        storeInCache?: StoreInCache
    ): Promise<void> {
        const cachedIdToken: IdTokenEntity | null =
            CacheHelpers.createIdTokenEntity(
                homeAccountIdentifier,
                environment,
                response.id_token || "",
                request.clientId,
                idTokenClaims.tid || ""
            );

        // cache accessToken in inmemory storage
        const expiresIn: number =
            request.tokenType === Constants.AuthenticationScheme.POP
                ? Constants.SHR_NONCE_VALIDITY
                : (typeof response.expires_in === "string"
                      ? parseInt(response.expires_in, 10)
                      : response.expires_in) || 0;
        const tokenExpirationSeconds = reqTimestamp + expiresIn;
        const responseScopes = this.generateScopes(
            response.scope,
            request.scope
        );

        const additionalCacheKeyComponents = request.attributeTokens
            ? {
                  attribute_tokens: request.attributeTokens,
              }
            : undefined;

        const cachedAccessToken: AccessTokenEntity | null =
            CacheHelpers.createAccessTokenEntity(
                homeAccountIdentifier,
                environment,
                response.access_token,
                request.clientId,
                idTokenClaims.tid || tenantId,
                responseScopes.printScopes(),
                tokenExpirationSeconds,
                0,
                base64Decode,
                request.correlationId,
                undefined,
                request.tokenType as Constants.AuthenticationScheme,
                undefined,
                request.keyId,
                additionalCacheKeyComponents
            );

        if (request.extraParameters?.resource) {
            cachedAccessToken.resource = request.extraParameters.resource;
        }

        // save idtoken credential in configured browser storage
        if (!!cachedIdToken && storeInCache?.idToken !== false) {
            await this.browserStorage.setIdTokenCredential(
                cachedIdToken,
                this.correlationId,
                AuthToken.isKmsi(idTokenClaims)
            );
        }

        // save access token credential in memory storage
        const nativeCacheRecord = {
            accessToken: cachedAccessToken,
        };

        return this.nativeStorageManager.saveCacheRecord(
            nativeCacheRecord,
            this.correlationId,
            AuthToken.isKmsi(idTokenClaims),
            this.apiId,
            storeInCache
        );
    }

    getExpiresInValue(
        tokenType: string,
        expiresIn: string | number | undefined
    ): number {
        return tokenType === Constants.AuthenticationScheme.POP
            ? Constants.SHR_NONCE_VALIDITY
            : (typeof expiresIn === "string"
                  ? parseInt(expiresIn, 10)
                  : expiresIn) || 0;
    }

    protected addTelemetryFromNativeResponse(
        matsResponse?: string
    ): MATS | null {
        const mats = this.getMATSFromResponse(matsResponse);

        if (!mats) {
            return null;
        }

        this.performanceClient.addFields(
            {
                extensionId: this.platformAuthProvider.getExtensionId(),
                extensionVersion:
                    this.platformAuthProvider.getExtensionVersion(),
                matsBrokerVersion: mats.broker_version,
                matsAccountJoinOnStart: mats.account_join_on_start,
                matsAccountJoinOnEnd: mats.account_join_on_end,
                matsDeviceJoin: mats.device_join,
                matsPromptBehavior: mats.prompt_behavior,
                matsApiErrorCode: mats.api_error_code,
                matsUiVisible: mats.ui_visible,
                matsSilentCode: mats.silent_code,
                matsSilentBiSubCode: mats.silent_bi_sub_code,
                matsSilentMessage: mats.silent_message,
                matsSilentStatus: mats.silent_status,
                matsHttpStatus: mats.http_status,
                matsHttpEventCount: mats.http_event_count,
            },
            this.correlationId
        );

        return mats;
    }

    /**
     * Gets MATS telemetry from native response
     * @param response
     * @returns
     */
    private getMATSFromResponse(matsResponse: string | undefined): MATS | null {
        if (matsResponse) {
            try {
                return JSON.parse(matsResponse);
            } catch (e) {
                this.logger.error(
                    "NativeInteractionClient - Error parsing MATS telemetry, returning null instead",
                    this.correlationId
                );
            }
        }

        return null;
    }

    /**
     * Returns whether or not response came from native cache
     * @param response
     * @returns
     */
    protected isResponseFromCache(mats: MATS): boolean {
        if (typeof mats.is_cached === "undefined") {
            this.logger.verbose(
                "NativeInteractionClient - MATS telemetry does not contain field indicating if response was served from cache. Returning false.",
                this.correlationId
            );
            return false;
        }

        return !!mats.is_cached;
    }

    /**
     * Translates developer provided request object into NativeRequest object
     * @param request
     */
    protected async initializePlatformRequest(
        request: PopupRequest | SsoSilentRequest
    ): Promise<PlatformAuthRequest> {
        this.logger.trace(
            "NativeInteractionClient - initializePlatformRequest called",
            this.correlationId
        );

        const canonicalAuthority = await this.getCanonicalAuthority(request);

        // ignore config claims if skipBrokerClaims is set to true and this is a brokered authentication flow
        const configClaims =
            request.skipBrokerClaims && !!request.embeddedClientId
                ? undefined
                : this.config.auth.clientCapabilities;

        /*
         * scopes are expected to be received by the native broker as "scope" and will be added to the request below. Other properties that should be dropped from the request to the native broker can be included in the object destructuring here.
         * attributeTokens is destructured out because PlatformAuthRequest represents it as a pre-serialized string, not the caller-provided Array<string>.
         */
        const { scopes, claims, extraParametersNoCache, dpopNonce } =
            request as (PopupRequest | SsoSilentRequest) & {
                extraParametersNoCache?: PlatformAuthExtraParametersNoCache;
                dpopNonce?: string;
            };
        const scopeSet = new ScopeSet(scopes || [], this.correlationId);
        scopeSet.appendScopes(Constants.OIDC_DEFAULT_SCOPES);

        const mergedClaims = RequestParameterBuilder.buildMergedClaims(
            claims,
            configClaims?.length ? configClaims : undefined
        );

        const hasAttributeTokens = !!request.attributeTokens?.length;
        this.performanceClient?.addFields(
            {
                hasAttributeTokens,
            },
            this.correlationId
        );

        const validatedRequest: PlatformAuthRequest = {
            claims: mergedClaims,
            accountId: this.accountId,
            clientId: this.config.auth.clientId,
            authority: canonicalAuthority.urlString,
            scope: scopeSet.printScopes(),
            redirectUri: getRedirectUri(
                request.redirectUri,
                this.config.auth.redirectUri,
                this.logger,
                this.correlationId
            ),
            prompt: this.getPrompt(request.prompt),
            correlationId: this.correlationId,
            isSts: false,
            tokenType: request.authenticationScheme,
            windowTitleSubstring: document.title,
            nonce: request.nonce,
            state: request.state,
            loginHint: request.loginHint,
            extraParameters: {
                ...request.extraParameters,
                ...(request.resource && { resource: request.resource }), // resource is set for MCP scenarios
            },
            extendedExpiryToken: false, // Make this configurable?
            keyId: request.popKid,
            resourceRequestMethod: request.resourceRequestMethod,
            resourceRequestUri: request.resourceRequestUri,
            shrClaims: request.shrClaims,
            shrNonce: request.shrNonce,
            extraParametersNoCache: createPlatformAuthExtraParametersNoCache(
                extraParametersNoCache,
                isProofOfPossessionTokenType(request.authenticationScheme),
                request.resourceRequestMethod,
                request.resourceRequestUri,
                dpopNonce
            ),
        };

        if (hasAttributeTokens) {
            validatedRequest.attributeTokens =
                CacheHelpers.serializeAttributeTokens(
                    request.attributeTokens as Array<string>
                );
        }

        // Check for PoP token requests: signPopToken should only be set to true if popKid is not set
        if (validatedRequest.signPopToken && !!request.popKid) {
            throw createBrowserAuthError(
                BrowserAuthErrorCodes.invalidPopTokenRequest,
                this.correlationId
            );
        }

        this.handleExtraBrokerParams(
            validatedRequest,
            request.embeddedClientId
        );
        validatedRequest.extraParameters =
            validatedRequest.extraParameters || {};
        validatedRequest.extraParameters.telemetry =
            PlatformAuthConstants.MATS_TELEMETRY;

        if (
            request.authenticationScheme === Constants.AuthenticationScheme.POP
        ) {
            // add POP request type
            const shrParameters: SignedHttpRequestParameters = {
                resourceRequestUri: request.resourceRequestUri,
                resourceRequestMethod: request.resourceRequestMethod,
                shrClaims: request.shrClaims,
                shrNonce: request.shrNonce,
                correlationId: this.correlationId,
            };

            const popTokenGenerator = new PopTokenGenerator(
                this.browserCrypto,
                this.tokenBindingKeyManager,
                this.performanceClient
            );

            // generate reqCnf if not provided in the request
            let reqCnfData;
            if (!validatedRequest.keyId) {
                const generatedReqCnfData = await invokeAsync(
                    popTokenGenerator.generateCnf.bind(popTokenGenerator),
                    PerformanceEvents.PopTokenGenerateCnf,
                    this.logger,
                    this.performanceClient,
                    this.correlationId
                )(shrParameters, this.logger);
                reqCnfData = generatedReqCnfData.reqCnfString;
                validatedRequest.keyId = generatedReqCnfData.kid;
                validatedRequest.signPopToken = true;
            } else {
                reqCnfData = this.browserCrypto.base64UrlEncode(
                    JSON.stringify({ kid: validatedRequest.keyId })
                );
                validatedRequest.signPopToken = false;
            }

            // SPAs require whole string to be passed to broker
            validatedRequest.reqCnf = reqCnfData;
        }
        this.addRequestSKUs(validatedRequest);

        return validatedRequest;
    }

    private async getCanonicalAuthority(
        request: PopupRequest | SsoSilentRequest
    ): Promise<UrlString> {
        const requestAuthority =
            request.authority || this.config.auth.authority;

        const { azureCloudOptions, account } = request;

        if (account) {
            // validate authority
            await getDiscoveredAuthority(
                this.config,
                this.correlationId,
                this.performanceClient,
                this.browserStorage,
                this.logger,
                requestAuthority,
                azureCloudOptions,
                undefined, // requestExtraQueryParameters
                account
            );
        }

        const canonicalAuthority = new UrlString(
            requestAuthority,
            this.correlationId
        );
        canonicalAuthority.validateAsUri();
        return canonicalAuthority;
    }

    private getPrompt(prompt?: string): string | undefined {
        // If request is silent, prompt is always none
        switch (this.apiId) {
            case ApiId.ssoSilent:
            case ApiId.acquireTokenSilent_silentFlow:
                this.logger.trace(
                    "initializePlatformRequest: silent request sets prompt to none",
                    this.correlationId
                );
                return Constants.PromptValue.NONE;
            default:
                break;
        }

        // Prompt not provided, request may proceed and native broker decides if it needs to prompt
        if (!prompt) {
            this.logger.trace(
                "initializePlatformRequest: prompt was not provided",
                this.correlationId
            );
            return undefined;
        }

        // If request is interactive, check if prompt provided is allowed to go directly to native broker
        switch (prompt) {
            case Constants.PromptValue.NONE:
            case Constants.PromptValue.CONSENT:
            case Constants.PromptValue.LOGIN:
                this.logger.trace(
                    "initializePlatformRequest: prompt is compatible with native flow",
                    this.correlationId
                );
                return prompt;
            default:
                this.logger.trace(
                    `initializePlatformRequest: prompt = '${prompt}' is not compatible with native flow`,
                    this.correlationId
                );
                throw createBrowserAuthError(
                    BrowserAuthErrorCodes.nativePromptNotSupported,
                    this.correlationId
                );
        }
    }

    /**
     * Handles extra broker request parameters
     * @param request {PlatformAuthRequest}
     * @private
     */
    private handleExtraBrokerParams(
        request: PlatformAuthRequest,
        embeddedClientId?: string
    ): void {
        const hasExtraBrokerParams =
            request.extraParameters &&
            request.extraParameters.hasOwnProperty(
                AADServerParamKeys.BROKER_CLIENT_ID
            ) &&
            request.extraParameters.hasOwnProperty(
                AADServerParamKeys.BROKER_REDIRECT_URI
            ) &&
            request.extraParameters.hasOwnProperty(
                AADServerParamKeys.CLIENT_ID
            );

        if (!embeddedClientId && !hasExtraBrokerParams) {
            return;
        }

        let child_client_id: string = "";
        const child_redirect_uri = request.redirectUri;

        if (embeddedClientId) {
            request.redirectUri = this.config.auth.redirectUri;
            child_client_id = embeddedClientId;
        } else if (request.extraParameters) {
            request.redirectUri =
                request.extraParameters[AADServerParamKeys.BROKER_REDIRECT_URI];
            child_client_id =
                request.extraParameters[AADServerParamKeys.CLIENT_ID];
        }

        const {
            // eslint-disable-next-line @typescript-eslint/no-unused-vars
            [AADServerParamKeys.BROKER_CLIENT_ID]: _brkClientId,
            // eslint-disable-next-line @typescript-eslint/no-unused-vars
            [AADServerParamKeys.BROKER_REDIRECT_URI]: _brkRedirectUri,
            // eslint-disable-next-line @typescript-eslint/no-unused-vars
            [AADServerParamKeys.CLIENT_ID]: _clientId,
            ...remainingExtraParameters
        } = request.extraParameters || {};

        request.extraParameters = {
            ...remainingExtraParameters,
            child_client_id,
            child_redirect_uri,
        };

        this.performanceClient?.addFields(
            {
                embeddedClientId: child_client_id,
                embeddedRedirectUri: child_redirect_uri,
            },
            this.correlationId
        );
    }
}
