export declare const name = "@azure/msal-browser";
export declare const version = "5.23.0";
//# sourceMappingURL=packageMetadata.d.ts.map