import { PopupWindowAttributes } from "../request/PopupWindowAttributes.js";
/** Options for {@link runPopupRelay}. */
export type PopupRelayOptions = {
    /**
     * Sizing/positioning for the IdP child popup the relay page opens. Same
     * shape as `PopupRequest.popupWindowAttributes` (`popupSize` with width and
     * height, `popupPosition` with top and left). Defaults to a 520x640 window.
     */
    popupWindowAttributes?: PopupWindowAttributes;
    /**
     * How long (ms) to wait for the IdP child popup to deliver a response
     * before giving up. Defaults to 300000 (5 minutes).
     */
    timeoutMs?: number;
    /**
     * Origins the relay is allowed to navigate its IdP child popup to, e.g.
     * `["https://login.microsoftonline.com"]`. Strongly recommended: set this
     * to the origin(s) of the authority your app signs in against, so the relay
     * page can only ever be used to reach your identity provider.
     *
     * Entries are compared by origin, so passing the full configured authority
     * (`"https://login.microsoftonline.com/common"`), a trailing slash, mixed
     * case, or an explicit `:443` all work.
     *
     * **Optional — omitting it does not disable the relay.** The relay page
     * always rejects non-`https:` navigation targets; this option additionally
     * pins *which* https origins are acceptable. When omitted, any https origin
     * is allowed, which is how every existing relay page already behaves.
     * Passing an explicitly empty array means "allow nothing" and will reject
     * every navigation.
     */
    allowedAuthorityOrigins?: string[];
};
/**
 * Entry point for the top-level "popup-relay" page referenced by
 * `auth.popupRelayUri`. Call this from the relay page (which MSAL opens as a
 * top-level popup from inside an embedded, cross-origin iframe). It:
 *
 *   1. Reads the IdP navigation MSAL passed in this page's hash (a GET URL, or a
 *      POST form for the form_post / EAR response modes), then scrubs the hash.
 *   2. Validates that navigation. The relay page is directly reachable, so the
 *      hash is untrusted input: the request shape is checked exactly and the
 *      navigation target must be an absolute `https:` URL (optionally pinned to
 *      {@link PopupRelayOptions.allowedAuthorityOrigins}). Anything else — in
 *      particular active schemes such as `javascript:` — is rejected before it
 *      can reach `window.open` or a form `action`.
 *   3. Opens the IdP child popup and performs that navigation (the relay page
 *      stays put, so its `window.opener` link back to the embedded frame
 *      survives COOP).
 *   4. Waits for the child's redirect URI page (which must run the redirect
 *      bridge, `broadcastResponseToMainFrame`) to broadcast the raw auth
 *      response over a same-origin `BroadcastChannel`.
 *   5. Relays that raw response back to the embedded frame via
 *      `opener.postMessage`, posting only to its own (same) origin, then closes.
 *
 * The embedded frame keeps the PKCE verifier (and EAR private key) and exchanges
 * the relayed response itself — no token, verifier, or private key ever crosses
 * a window boundary.
 *
 * Note: the child popup is opened when this function runs, so call it from a
 * user gesture (e.g. a "Continue" button click) to avoid popup blockers.
 *
 * @param options - {@link PopupRelayOptions}
 */
export declare function runPopupRelay(options?: PopupRelayOptions): void;
//# sourceMappingURL=index.d.ts.map