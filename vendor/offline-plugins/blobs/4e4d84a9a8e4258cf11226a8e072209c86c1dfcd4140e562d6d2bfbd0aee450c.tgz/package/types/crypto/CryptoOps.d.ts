import { ICrypto, IPerformanceClient, JoseHeader, Logger } from "@azure/msal-common/browser";
/**
 * This class implements MSAL's crypto interface, which allows it to perform base64 encoding and decoding, generating cryptographically random GUIDs and
 * implementing Proof Key for Code Exchange specs for the OAuth Authorization Code Flow using PKCE (rfc here: https://tools.ietf.org/html/rfc7636).
 */
export declare class CryptoOps implements ICrypto {
    private logger;
    /**
     * CryptoOps can be used in contexts outside a PCA instance,
     * meaning there won't be a performance manager available.
     */
    private performanceClient;
    private tokenBindingKeyManager;
    constructor(logger: Logger, performanceClient?: IPerformanceClient, skipValidateSubtleCrypto?: boolean);
    /**
     * Creates a new random GUID - used to populate state and nonce.
     * @returns string (GUID)
     */
    createNewGuid(): string;
    /**
     * Encodes input string to base64.
     * @param input
     */
    base64Encode(input: string): string;
    /**
     * Decodes input string from base64.
     * @param input
     */
    base64Decode(input: string): string;
    /**
     * Encodes input string to base64 URL safe string.
     * @param input
     */
    base64UrlEncode(input: string): string;
    /**
     * Stringifies and base64Url encodes input public key
     * @param inputKid
     * @returns Base64Url encoded public key
     */
    encodeKid(inputKid: string): string;
    /**
     * Removes cryptographic keypair from key store matching the keyId passed in
     * @param kid
     * @param correlationId
     */
    removeTokenBindingKey(kid: string, correlationId: string): Promise<void>;
    /**
     * Removes all cryptographic keys from IndexedDB storage
     * @param correlationId
     */
    clearKeystore(correlationId: string): Promise<boolean>;
    /** @internal */
    signTokenBindingJwt(header: JoseHeader, payload: object, kid: string, correlationId: string): Promise<string>;
    /**
     * Returns the SHA-256 hash of an input string
     * @param plainText
     */
    hashString(plainText: string): Promise<string>;
    private signInput;
    private getTokenBindingKeySigningAlgorithm;
    private validateTokenBindingJwtHeaderKey;
}
//# sourceMappingURL=CryptoOps.d.ts.map