import { NativeExtensionMethod } from "../../utils/BrowserConstants.js";
import { Constants, StringDict } from "@azure/msal-common/browser";
/**
 * Key storage enclaves supported by the platform broker.
 */
export declare const PlatformAuthEnclave: {
    /**
     * Persisted software key using MS_KEY_STORAGE_PROVIDER.
     */
    readonly SOFTWARE: "sw";
    /**
     * TPM-backed key using MS_PLATFORM_KEY_STORAGE_PROVIDER.
     */
    readonly HARDWARE: "hw";
    /**
     * KeyGuard-protected key using MS_KEY_STORAGE_PROVIDER.
     */
    readonly KEY_GUARD: "kg";
};
/**
 * Supported platform broker key storage enclave.
 */
export type PlatformAuthEnclave = (typeof PlatformAuthEnclave)[keyof typeof PlatformAuthEnclave];
/**
 * Token types supported by the platform broker request contract.
 */
export declare const PlatformAuthTokenType: {
    readonly DPOP_WITH_PROOF: "dpop+proof";
};
/**
 * Supported platform broker request token type. Authentication schemes are
 * internal request intent; the additional values are WAM DPoP wire contracts.
 */
export type PlatformAuthTokenType = Constants.AuthenticationScheme | (typeof PlatformAuthTokenType)[keyof typeof PlatformAuthTokenType];
/**
 * Token binding preferences supported by the platform broker.
 */
export declare const PlatformAuthBindingPreference: {
    readonly ATTESTED: "attested";
};
/**
 * Supported platform broker token binding preference.
 */
export type PlatformAuthBindingPreference = (typeof PlatformAuthBindingPreference)[keyof typeof PlatformAuthBindingPreference];
/**
 * Returns whether a platform broker token type requires proof request metadata.
 */
export declare function isProofOfPossessionTokenType(tokenType: PlatformAuthTokenType | undefined): boolean;
/**
 * No-cache parameters sent to the platform broker. This bag is constructed
 * internally and is not inherited from BaseAuthRequest.
 */
export type PlatformAuthExtraParametersNoCache = StringDict & {
    pop_method?: string;
    pop_url?: string;
    pop_nonce?: string;
};
/**
 * Token request which native broker will use to acquire tokens
 */
export type PlatformAuthRequest = {
    accountId: string;
    clientId: string;
    authority: string;
    redirectUri: string;
    scope: string;
    correlationId: string;
    windowTitleSubstring: string;
    isSts?: boolean;
    prompt?: string;
    nonce?: string;
    claims?: string;
    state?: string;
    loginHint?: string;
    preferBinding?: PlatformAuthBindingPreference;
    enclave?: PlatformAuthEnclave;
    reqCnf?: string;
    keyId?: string;
    tokenType?: PlatformAuthTokenType;
    shrClaims?: string;
    shrNonce?: string;
    resourceRequestMethod?: string;
    resourceRequestUri?: string;
    extendedExpiryToken?: boolean;
    extraParameters?: StringDict;
    extraParametersNoCache?: PlatformAuthExtraParametersNoCache;
    signPopToken?: boolean;
    attributeTokens?: string;
};
/**
 * Adds canonical proof request fields to the broker no-cache property bag.
 */
export declare function createPlatformAuthExtraParametersNoCache(extraParametersNoCache: PlatformAuthExtraParametersNoCache | undefined, isProofOfPossessionRequest: boolean, resourceRequestMethod?: string, resourceRequestUri?: string, dpopNonce?: string): PlatformAuthExtraParametersNoCache | undefined;
/**
 * Request which will be forwarded to native broker by the browser extension
 */
export type NativeExtensionRequestBody = {
    method: NativeExtensionMethod;
    request?: PlatformAuthRequest;
};
/**
 * Browser extension request
 */
export type NativeExtensionRequest = {
    channel: string;
    responseId: string;
    extensionId?: string;
    body: NativeExtensionRequestBody;
};
export type PlatformDOMTokenRequest = {
    brokerId: string;
    accountId?: string;
    clientId: string;
    authority: string;
    scope: string;
    redirectUri: string;
    correlationId: string;
    isSecurityTokenService: boolean;
    state?: string;
    preferBinding?: PlatformAuthBindingPreference;
    enclave?: PlatformAuthEnclave;
    requestConfirmation?: string;
    extraParametersNoCache?: PlatformAuthExtraParametersNoCache;
    extraParameters?: DOMExtraParameters;
};
export type DOMExtraParameters = StringDict & {
    prompt?: string;
    nonce?: string;
    claims?: string;
    loginHint?: string;
    instanceAware?: string;
    windowTitleSubstring?: string;
    extendedExpiryToken?: string;
    keyId?: string;
    tokenType?: string;
    shrClaims?: string;
    shrNonce?: string;
    signPopToken?: string;
};
//# sourceMappingURL=PlatformAuthRequest.d.ts.map