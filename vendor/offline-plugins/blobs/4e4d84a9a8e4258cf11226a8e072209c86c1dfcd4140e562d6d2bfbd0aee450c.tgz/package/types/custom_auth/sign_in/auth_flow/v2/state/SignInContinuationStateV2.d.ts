import { AuthFlowActionRequiredStateBase } from "../../../../core/auth_flow/AuthFlowState.js";
import type { SignInContinuationStateParametersV2 } from "./SignInStateParametersV2.js";
import type { SignInContinuationResultV2 } from "../result/SignInContinuationResultV2.js";
import type { SignInContinuationInputsV2 } from "../../../../CustomAuthActionInputs.js";
/**
 * Shared state returned when a completed V2 flow can sign the user in by
 * redeeming its continuation. Password reset and sign-up can both surface this
 * state without duplicating the token-acquisition behavior.
 */
export declare class SignInContinuationStateV2 extends AuthFlowActionRequiredStateBase<SignInContinuationStateParametersV2> {
    readonly stateType = "signInContinuation";
    /**
     * Signs the user in using the continuation established by the completed V2
     * flow. On success the returned result reaches the completed state
     * carrying the signed-in account data; on failure the result's error reports
     * why the follow-up sign-in could not complete.
     * @param inputs - Optional scopes requested for the issued token. Claims
     * are accepted for API alignment but are not sent until the V2 service
     * supports them on authorize-challenge.
     * @returns The result of signing in after the password reset.
     */
    signIn(inputs?: SignInContinuationInputsV2): Promise<SignInContinuationResultV2>;
}
//# sourceMappingURL=SignInContinuationStateV2.d.ts.map