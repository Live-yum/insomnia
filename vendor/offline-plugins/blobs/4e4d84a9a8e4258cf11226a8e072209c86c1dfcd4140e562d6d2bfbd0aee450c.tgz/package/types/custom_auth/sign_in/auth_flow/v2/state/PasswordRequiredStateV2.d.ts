import { AuthFlowActionRequiredStateBase } from "../../../../core/auth_flow/AuthFlowState.js";
import type { PasswordRequiredStateParametersV2 } from "./SignInStateParametersV2.js";
import type { SubmitPasswordResultV2 } from "../result/SubmitPasswordResultV2.js";
/**
 * State returned when the selected sign-in method requires the user's
 * password.
 */
export declare class PasswordRequiredStateV2 extends AuthFlowActionRequiredStateBase<PasswordRequiredStateParametersV2> {
    readonly stateType = "passwordRequired";
    /**
     * Submits the password and advances sign-in.
     * @param password - The account password.
     * @returns A completed sign-in, MFA selection, or password submission error.
     */
    submitPassword(password: string): Promise<SubmitPasswordResultV2>;
}
//# sourceMappingURL=PasswordRequiredStateV2.d.ts.map