import { GetAccountResult } from "../get_account/auth_flow/result/GetAccountResult.js";
import { SignInResult } from "../sign_in/auth_flow/result/SignInResult.js";
import { SignUpResult } from "../sign_up/auth_flow/result/SignUpResult.js";
import { AccountRetrievalInputs, SignInInputs, SignUpInputs, ResetPasswordInputs, ResetPasswordInputsV2, SignInInputsV2, SignUpInputsV2 } from "../CustomAuthActionInputs.js";
import { CustomAuthOperatingContext } from "../operating_context/CustomAuthOperatingContext.js";
import { ICustomAuthStandardController } from "./ICustomAuthStandardController.js";
import { ResetPasswordStartResult } from "../reset_password/auth_flow/result/ResetPasswordStartResult.js";
import { ResetPasswordStartResultV2 } from "../core/auth_flow/v2/result/ResetPasswordStartResultV2.js";
import { CustomAuthApiClientV2 } from "../core/network_client/custom_auth_api/v2/CustomAuthApiClientV2.js";
import { SignInStartResultV2 } from "../sign_in/auth_flow/v2/result/SignInStartResultV2.js";
import { SignUpStartResultV2 } from "../sign_up/auth_flow/v2/result/SignUpStartResultV2.js";
import { ICustomAuthApiClient } from "../core/network_client/custom_auth_api/ICustomAuthApiClient.js";
import { StandardController } from "../../controllers/StandardController.js";
export declare class CustomAuthStandardController extends StandardController implements ICustomAuthStandardController {
    private readonly signInClient;
    private readonly signUpClient;
    private readonly resetPasswordClient;
    private readonly jitClient;
    private readonly mfaClient;
    private readonly cacheClient;
    private readonly customAuthConfig;
    private readonly authority;
    private readonly flowClientV2;
    private readonly signUpStateTransitionHandlerV2;
    constructor(operatingContext: CustomAuthOperatingContext, customAuthApiClient?: ICustomAuthApiClient, customAuthApiClientV2?: CustomAuthApiClientV2);
    getCurrentAccount(accountRetrievalInputs?: AccountRetrievalInputs): GetAccountResult;
    signIn(signInInputs: SignInInputs): Promise<SignInResult>;
    signUp(signUpInputs: SignUpInputs): Promise<SignUpResult>;
    resetPassword(resetPasswordInputs: ResetPasswordInputs): Promise<ResetPasswordStartResult>;
    resetPasswordV2(inputs: ResetPasswordInputsV2): Promise<ResetPasswordStartResultV2>;
    signInV2(inputs: SignInInputsV2): Promise<SignInStartResultV2>;
    signUpV2(inputs: SignUpInputsV2): Promise<SignUpStartResultV2>;
    private getCorrelationId;
    private ensureUserNotSignedIn;
}
//# sourceMappingURL=CustomAuthStandardController.d.ts.map