import { GetAccountResult } from "../get_account/auth_flow/result/GetAccountResult.js";
import { SignInResult } from "../sign_in/auth_flow/result/SignInResult.js";
import { SignUpResult } from "../sign_up/auth_flow/result/SignUpResult.js";
import { AccountRetrievalInputs, ResetPasswordInputs, SignInInputs, SignUpInputs, ResetPasswordInputsV2, SignInInputsV2, SignUpInputsV2 } from "../CustomAuthActionInputs.js";
import { ResetPasswordStartResult } from "../reset_password/auth_flow/result/ResetPasswordStartResult.js";
import { IController } from "../../controllers/IController.js";
import { ResetPasswordStartResultV2 } from "../core/auth_flow/v2/result/ResetPasswordStartResultV2.js";
import { SignInStartResultV2 } from "../sign_in/auth_flow/v2/result/SignInStartResultV2.js";
import { SignUpStartResultV2 } from "../sign_up/auth_flow/v2/result/SignUpStartResultV2.js";
export interface ICustomAuthStandardController extends IController {
    getCurrentAccount(accountRetrievalInputs?: AccountRetrievalInputs): GetAccountResult;
    signIn(signInInputs: SignInInputs): Promise<SignInResult>;
    signUp(signUpInputs: SignUpInputs): Promise<SignUpResult>;
    resetPassword(resetPasswordInputs: ResetPasswordInputs): Promise<ResetPasswordStartResult>;
    signInV2(inputs: SignInInputsV2): Promise<SignInStartResultV2>;
    signUpV2(inputs: SignUpInputsV2): Promise<SignUpStartResultV2>;
    resetPasswordV2(inputs: ResetPasswordInputsV2): Promise<ResetPasswordStartResultV2>;
}
//# sourceMappingURL=ICustomAuthStandardController.d.ts.map