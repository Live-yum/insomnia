import { AuthFlowActionRequiredStateBase } from "../../../../core/auth_flow/AuthFlowState.js";
import type { NewPasswordRequiredStateParametersV2 } from "./ResetPasswordStateParametersV2.js";
import type { SubmitNewPasswordResultV2 } from "../result/SubmitNewPasswordResultV2.js";
/**
 * State returned when the user must supply a new password to complete the flow.
 * A successful submission returns `SignInContinuationStateV2` so the app can
 * sign the user in.
 */
export declare class NewPasswordRequiredStateV2 extends AuthFlowActionRequiredStateBase<NewPasswordRequiredStateParametersV2> {
    readonly stateType = "newPasswordRequired";
    /**
     * Submits the new password to complete the reset. The result either allows
     * sign-in or reports that the password was rejected.
     * @param password - The new password to set.
     * @returns The result of submitting the new password.
     */
    submitNewPassword(password: string): Promise<SubmitNewPasswordResultV2>;
}
//# sourceMappingURL=NewPasswordRequiredStateV2.d.ts.map