import type { CustomAuthActionRequiredStateParametersV2 } from "../../../../core/auth_flow/v2/state/CustomAuthStateParametersV2.js";
export type NewPasswordRequiredStateParametersV2 = CustomAuthActionRequiredStateParametersV2;
//# sourceMappingURL=ResetPasswordStateParametersV2.d.ts.map