import { GetAccountResult } from "./get_account/auth_flow/result/GetAccountResult.js";
import { SignInResult } from "./sign_in/auth_flow/result/SignInResult.js";
import { SignUpResult } from "./sign_up/auth_flow/result/SignUpResult.js";
import { ICustomAuthPublicClientApplicationV2 } from "./ICustomAuthPublicClientApplicationV2.js";
import { AccountRetrievalInputs, SignInInputs, SignUpInputs, ResetPasswordInputs, ResetPasswordInputsV2, SignInInputsV2, SignUpInputsV2 } from "./CustomAuthActionInputs.js";
import { ResetPasswordStartResultV2 } from "./core/auth_flow/v2/result/ResetPasswordStartResultV2.js";
import { SignInStartResultV2 } from "./sign_in/auth_flow/v2/result/SignInStartResultV2.js";
import { SignUpStartResultV2 } from "./sign_up/auth_flow/v2/result/SignUpStartResultV2.js";
import { CustomAuthConfiguration } from "./configuration/CustomAuthConfiguration.js";
import { ResetPasswordStartResult } from "./reset_password/auth_flow/result/ResetPasswordStartResult.js";
import { PublicClientApplication } from "../app/PublicClientApplication.js";
export declare class CustomAuthPublicClientApplication extends PublicClientApplication implements ICustomAuthPublicClientApplicationV2 {
    private readonly customAuthController;
    /**
     * Creates a new instance of a PublicClientApplication with the given configuration and controller to start Native authentication flows
     * @param {CustomAuthConfiguration} config - A configuration object for the PublicClientApplication instance
     * @returns {Promise<ICustomAuthPublicClientApplicationV2>} - A promise that resolves to a CustomAuthPublicClientApplication instance
     */
    static create(config: CustomAuthConfiguration): Promise<ICustomAuthPublicClientApplicationV2>;
    private constructor();
    /**
     * Gets the current account from the browser cache.
     * @param {AccountRetrievalInputs} accountRetrievalInputs?:AccountRetrievalInputs
     * @returns {GetAccountResult} - The result of the get account operation
     */
    getCurrentAccount(accountRetrievalInputs?: AccountRetrievalInputs): GetAccountResult;
    /**
     * Initiates the sign-in flow.
     * This method results in sign-in completion, or extra actions (password, code, etc.) required to complete the sign-in.
     * Create result with error details if any exception thrown.
     * @param {SignInInputs} signInInputs - Inputs for the sign-in flow
     * @returns {Promise<SignInResult>} - A promise that resolves to SignInResult
     */
    signIn(signInInputs: SignInInputs): Promise<SignInResult>;
    /**
     * Initiates the sign-up flow.
     * This method results in sign-up completion, or extra actions (password, code, etc.) required to complete the sign-up.
     * Create result with error details if any exception thrown.
     * @param {SignUpInputs} signUpInputs
     * @returns {Promise<SignUpResult>} - A promise that resolves to SignUpResult
     */
    signUp(signUpInputs: SignUpInputs): Promise<SignUpResult>;
    /**
     * Initiates the reset password flow.
     * This method results in triggering extra action (submit code) to complete the reset password.
     * Create result with error details if any exception thrown.
     * @param {ResetPasswordInputs} resetPasswordInputs - Inputs for the reset password flow
     * @returns {Promise<ResetPasswordStartResult>} - A promise that resolves to ResetPasswordStartResult
     */
    resetPassword(resetPasswordInputs: ResetPasswordInputs): Promise<ResetPasswordStartResult>;
    /**
     * Starts native auth V2 sign-in and returns the authentication methods
     * offered for the first factor.
     * @param inputs - Inputs for the sign-in V2 flow.
     * @returns A promise that resolves to the sign-in start result.
     */
    signInV2(inputs: SignInInputsV2): Promise<SignInStartResultV2>;
    /**
     * Starts native auth V2 sign-up.
     * @param inputs - Inputs for the sign-up V2 flow.
     * @returns A promise that resolves to the sign-up start result.
     */
    signUpV2(inputs: SignUpInputsV2): Promise<SignUpStartResultV2>;
    /**
     * Initiates the native auth V2 self-service password reset flow.
     * @param {ResetPasswordInputsV2} inputs - Inputs for the reset-password V2 flow
     * @returns {Promise<ResetPasswordStartResultV2>} - A promise that resolves to ResetPasswordStartResultV2
     */
    resetPasswordV2(inputs: ResetPasswordInputsV2): Promise<ResetPasswordStartResultV2>;
    /**
     * Validates the configuration to ensure it is a valid CustomAuthConfiguration object.
     * @param {CustomAuthConfiguration} config - The configuration object for the PublicClientApplication.
     * @returns {void}
     */
    private static validateConfig;
}
//# sourceMappingURL=CustomAuthPublicClientApplication.d.ts.map