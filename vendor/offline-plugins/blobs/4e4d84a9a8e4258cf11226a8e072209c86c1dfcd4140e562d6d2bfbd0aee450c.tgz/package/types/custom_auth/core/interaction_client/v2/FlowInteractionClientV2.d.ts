import { ICrypto, IPerformanceClient, Logger } from "@azure/msal-common/browser";
import { InteractionClientBaseV2 } from "./InteractionClientBaseV2.js";
import { FlowStartParamsV2, FlowSignInStartParamsV2, FlowSignUpStartParamsV2, FlowChallengeParamsV2, FlowSubmitCodeParamsV2, FlowSubmitNewPasswordParamsV2, FlowSubmitSignInPasswordParamsV2, FlowSubmitSignUpAttributesParamsV2, FlowSignInWithContinuationParamsV2 } from "./parameter/FlowParamsV2.js";
import type { FlowMethodSelectionRequiredResultV2, FlowCodeRequiredResultV2, FlowSignInCodeRequiredResultV2, FlowResetPasswordCodeRequiredResultV2, FlowPasswordRequiredResultV2, FlowSignUpPasswordRequiredResultV2, FlowMFARequiredResultV2, FlowAttributesRequiredResultV2, FlowSignInContinuationRequiredResultV2, FlowCompletedResultV2, FlowSignUpActionResultV2, FlowSubmitCodeResultV2 } from "./result/FlowActionResultV2.js";
import { BrowserConfiguration } from "../../../../config/Configuration.js";
import { BrowserCacheManager } from "../../../../cache/BrowserCacheManager.js";
import { EventHandler } from "../../../../event/EventHandler.js";
import { INavigationClient } from "../../../../navigation/INavigationClient.js";
import { CustomAuthAuthority } from "../../CustomAuthAuthority.js";
import { CustomAuthApiClientV2 } from "../../network_client/custom_auth_api/v2/CustomAuthApiClientV2.js";
export declare class FlowInteractionClientV2 extends InteractionClientBaseV2 {
    protected apiClient: CustomAuthApiClientV2;
    constructor(config: BrowserConfiguration, storageImpl: BrowserCacheManager, browserCrypto: ICrypto, logger: Logger, eventHandler: EventHandler, navigationClient: INavigationClient, performanceClient: IPerformanceClient, customAuthAuthority: CustomAuthAuthority, apiClient: CustomAuthApiClientV2);
    signIn(parameters: FlowSignInStartParamsV2): Promise<FlowPasswordRequiredResultV2 | FlowSignInCodeRequiredResultV2 | FlowMFARequiredResultV2 | FlowCompletedResultV2>;
    signUp(parameters: FlowSignUpStartParamsV2): Promise<FlowCodeRequiredResultV2 | FlowSignUpPasswordRequiredResultV2 | FlowAttributesRequiredResultV2>;
    resetPassword(parameters: FlowStartParamsV2): Promise<FlowMethodSelectionRequiredResultV2 | FlowResetPasswordCodeRequiredResultV2>;
    requestChallenge(parameters: FlowChallengeParamsV2): Promise<FlowCodeRequiredResultV2 | FlowPasswordRequiredResultV2>;
    submitCode(parameters: FlowSubmitCodeParamsV2): Promise<FlowSubmitCodeResultV2>;
    resendCode(parameters: FlowChallengeParamsV2): Promise<FlowCodeRequiredResultV2>;
    submitSignUpAttributes(parameters: FlowSubmitSignUpAttributesParamsV2): Promise<FlowSignUpActionResultV2>;
    submitNewPassword(parameters: FlowSubmitNewPasswordParamsV2): Promise<FlowSignInContinuationRequiredResultV2>;
    submitSignInPassword(parameters: FlowSubmitSignInPasswordParamsV2): Promise<FlowMFARequiredResultV2 | FlowCompletedResultV2>;
    signInWithContinuation(parameters: FlowSignInWithContinuationParamsV2): Promise<FlowCompletedResultV2>;
    private handleSignInVerification;
    private selectSignInMethod;
    private toSignUpActionResult;
    private ensureAuthenticationFactor;
    private verifySignInPassword;
    private completeSignInAfterVerification;
    private sendMethodChallenge;
    private createChallengeContinuationState;
    private resolveStepApiId;
    private requireLink;
}
//# sourceMappingURL=FlowInteractionClientV2.d.ts.map