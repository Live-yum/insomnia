import { ServerErrorV2 } from "./ErrorResponsesV2.js";
export declare function normalizeServerErrorV2(body: Record<string, unknown>): ServerErrorV2 | undefined;
//# sourceMappingURL=ErrorNormalizerV2.d.ts.map