import { CustomAuthFlowScenarioV2 } from "../auth_flow/v2/CustomAuthFlowScenarioV2.js";
export type FlowStepV2 = "requestChallenge" | "submitCode" | "resendCode" | "submitNewPassword" | "submitPassword" | "submitAttributes" | "signInWithContinuation";
export declare function getPublicApiIdV2(scenario: CustomAuthFlowScenarioV2, step: FlowStepV2): number | undefined;
//# sourceMappingURL=FlowApiIdHelperV2.d.ts.map