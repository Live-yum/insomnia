import { AuthFlowStateBase } from "../AuthFlowState.js";
import { CustomAuthError } from "../../error/CustomAuthError.js";
import { FailedStateV2 } from "./state/FailedStateV2.js";
import { AuthFlowErrorBaseV2 } from "./error/AuthFlowErrorBaseV2.js";
import { CustomAuthFlowScenarioV2 } from "./CustomAuthFlowScenarioV2.js";
type CreateWithErrorOptions<TError extends AuthFlowErrorBaseV2> = {
    errorType: new (errorData: CustomAuthError, scenario?: CustomAuthFlowScenarioV2) => TError;
    scenario?: CustomAuthFlowScenarioV2;
    correlationId?: string;
};
/**
 * Result of a native auth V2 operation. Use {@link CustomAuthResultV2.isState}
 * to narrow the state before accessing its members.
 */
export declare class CustomAuthResultV2<TState extends AuthFlowStateBase, TError extends AuthFlowErrorBaseV2, TData = void> {
    readonly state: TState;
    readonly data?: TData | undefined;
    readonly scenario: CustomAuthFlowScenarioV2;
    constructor(state: TState, data?: TData | undefined, scenario?: CustomAuthFlowScenarioV2);
    error?: TError;
    /**
     * Narrows the result to a specific state by its `stateType` discriminator.
     * A successful match makes the state's properties available without a cast.
     * @param stateType - The state type to test for.
     * @returns True (and narrows `state`) when the current state matches `stateType`.
     */
    isState<TType extends TState["stateType"]>(stateType: TType): this is this & {
        state: Extract<TState, {
            stateType: TType;
        }>;
    };
    /**
     * Checks whether the result is in the terminal failed state. A failed result
     * contains the flow-specific error.
     * @returns True (and narrows `state`) when the operation failed.
     */
    isFailed(): this is this & {
        state: Extract<TState, {
            stateType: "failed";
        }>;
    };
    /**
     * Creates a failed result from the supplied error. The result uses the
     * shared {@link FailedStateV2} terminal state.
     * @param error - The error that occurred.
     * @param options - The flow-error type and error context.
     * @returns A failed result carrying the flow-specific error.
     */
    static createWithError<TState extends AuthFlowStateBase, TError extends AuthFlowErrorBaseV2, TData = void>(error: unknown, options: CreateWithErrorOptions<TError>): CustomAuthResultV2<TState | FailedStateV2, TError, TData>;
    private static createErrorData;
}
export {};
//# sourceMappingURL=CustomAuthResultV2.d.ts.map