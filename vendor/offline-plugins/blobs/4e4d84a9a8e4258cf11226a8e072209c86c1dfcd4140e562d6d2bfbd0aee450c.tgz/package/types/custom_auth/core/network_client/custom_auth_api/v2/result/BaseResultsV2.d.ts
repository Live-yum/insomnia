import type { SignUpAttributeV2 } from "./SignUpResultsV2.js";
export interface AuthorizeChallengeEntryResultV2 {
    continuationToken: string;
    resetPasswordHref?: string;
    signInHref?: string;
    signUpHref?: string;
}
export interface StartMethodV2 {
    id: string;
    type?: string;
    hint?: string;
    challengeHref: string;
}
export declare const AuthenticationFactorV2: {
    readonly SINGLE_FACTOR: "singleFactor";
    readonly MULTI_FACTOR: "multiFactor";
};
export type AuthenticationFactorV2 = (typeof AuthenticationFactorV2)[keyof typeof AuthenticationFactorV2];
export interface StartResultV2 {
    continuationToken: string;
    methods: StartMethodV2[];
    authenticationFactor: AuthenticationFactorV2;
    scenario?: string;
}
export type ResetPasswordStartApiResultV2 = StartResultV2;
export type SignInStartApiResultV2 = StartResultV2;
export declare const ChallengeNextActionV2: {
    readonly VERIFY: "verify";
    readonly RISK_VERIFY: "riskVerify";
};
export interface ChallengeVerificationResultV2 {
    nextAction: typeof ChallengeNextActionV2.VERIFY;
    continuationToken: string;
    verifyHref: string;
    resendHref?: string;
    codeLength?: number;
    hint?: string;
    type?: string;
}
export interface RiskVerificationRequiredResultV2 {
    nextAction: typeof ChallengeNextActionV2.RISK_VERIFY;
    continuationToken: string;
    riskVerifyHref: string;
}
export type ChallengeResultV2 = ChallengeVerificationResultV2 | RiskVerificationRequiredResultV2;
export declare const VerifyNextActionV2: {
    readonly UPDATE: "update";
    readonly CONTINUE: "continue";
    readonly CHALLENGE: "challenge";
    readonly COLLECT_ATTRIBUTES: "collectAttributes";
};
export type VerifyResultV2 = {
    nextAction: typeof VerifyNextActionV2.UPDATE;
    continuationToken: string;
    updateHref: string;
} | {
    nextAction: typeof VerifyNextActionV2.CONTINUE;
    continuationToken: string;
} | {
    nextAction: typeof VerifyNextActionV2.CHALLENGE;
    continuationToken: string;
    authenticationFactor: AuthenticationFactorV2;
    methods: StartMethodV2[];
} | {
    nextAction: typeof VerifyNextActionV2.COLLECT_ATTRIBUTES;
    continuationToken: string;
    attributes: SignUpAttributeV2[];
    submitAttributesHref: string;
};
//# sourceMappingURL=BaseResultsV2.d.ts.map