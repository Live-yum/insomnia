/**
 * The native auth V2 flow that a result or error originates from (sign-in,
 * sign-up, or password reset). It lets a shared result or error type report
 * which entry flow produced it; `Unknown` is used when the flow cannot be
 * determined.
 */
export declare const CustomAuthFlowScenarioV2: {
    readonly SignIn: "signIn";
    readonly SignUp: "signUp";
    readonly PasswordReset: "passwordReset";
    readonly Unknown: "unknown";
};
export type CustomAuthFlowScenarioV2 = (typeof CustomAuthFlowScenarioV2)[keyof typeof CustomAuthFlowScenarioV2];
//# sourceMappingURL=CustomAuthFlowScenarioV2.d.ts.map