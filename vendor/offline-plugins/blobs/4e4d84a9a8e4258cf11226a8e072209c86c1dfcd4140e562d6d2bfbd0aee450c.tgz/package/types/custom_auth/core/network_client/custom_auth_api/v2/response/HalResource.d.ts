export interface HalLink {
    href: string;
    templated?: boolean;
    name?: string;
}
export type HalLinks = Record<string, HalLink | HalLink[]>;
export type HalEmbedded = Record<string, HalResource | HalResource[]>;
export interface HalResource {
    _links?: HalLinks;
    _embedded?: HalEmbedded;
}
//# sourceMappingURL=HalResource.d.ts.map