import { FlowContinuationStateV2 } from "../FlowContinuationStateV2.js";
import { UserAccountAttributes } from "../../../../UserAccountAttributes.js";
interface FlowParamsBaseV2 {
    correlationId: string;
}
export interface FlowStartParamsV2 extends FlowParamsBaseV2 {
    username: string;
}
export interface FlowSignInStartParamsV2 extends FlowStartParamsV2 {
    password?: string;
    scopes?: string[];
}
export interface FlowSignUpStartParamsV2 extends FlowStartParamsV2 {
    password?: string;
    attributes?: UserAccountAttributes;
    scopes?: string[];
    claims?: string;
}
export interface FlowChallengeParamsV2 extends FlowParamsBaseV2 {
    continuationState: FlowContinuationStateV2;
}
export interface FlowSubmitCodeParamsV2 extends FlowParamsBaseV2 {
    continuationState: FlowContinuationStateV2;
    code: string;
}
export interface FlowSubmitNewPasswordParamsV2 extends FlowParamsBaseV2 {
    continuationState: FlowContinuationStateV2;
    newPassword: string;
}
export interface FlowSubmitSignInPasswordParamsV2 extends FlowParamsBaseV2 {
    continuationState: FlowContinuationStateV2;
    password: string;
}
export interface FlowSubmitSignUpAttributesParamsV2 extends FlowParamsBaseV2 {
    continuationState: FlowContinuationStateV2;
    attributes: UserAccountAttributes;
}
export interface FlowSignInWithContinuationParamsV2 extends FlowParamsBaseV2 {
    continuationState: FlowContinuationStateV2;
    scopes?: string[];
}
export {};
//# sourceMappingURL=FlowParamsV2.d.ts.map