export declare const INVALID_ONE_TIME_CODE = "invalidOneTimeCode";
export declare const INVALID_USERNAME_OR_PASSWORD = "invalidUserNameOrPassword";
export declare const PASSWORD_TOO_WEAK = "passwordTooWeak";
//# sourceMappingURL=AuthFlowErrorSubcodesV2.d.ts.map