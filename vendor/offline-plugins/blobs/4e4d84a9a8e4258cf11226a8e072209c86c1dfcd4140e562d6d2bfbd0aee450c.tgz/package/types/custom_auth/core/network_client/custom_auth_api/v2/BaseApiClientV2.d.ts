import { Logger } from "@azure/msal-common/browser";
import { IHttpClient, HttpMethod } from "../../http_client/IHttpClient.js";
import { CustomAuthRequestInterceptor } from "../../../../configuration/CustomAuthRequestInterceptor.js";
import { ResponseHandlerV2 } from "./ResponseHandlerV2.js";
import { ParsedResponseV2, TokenResponseV2 } from "./response/ResponsesV2.js";
import { RequestContextV2, ActionRequestBaseV2, CompleteWithTokensRequestV2 } from "./request/RequestsV2.js";
import { AuthorizeChallengeEntryResultV2 } from "./result/BaseResultsV2.js";
export declare abstract class BaseApiClientV2 {
    protected readonly clientId: string;
    private readonly httpClient;
    private readonly customAuthApiQueryParams?;
    private readonly requestInterceptor?;
    protected readonly logger?: Logger | undefined;
    private readonly baseRequestUrl;
    protected readonly handler: ResponseHandlerV2;
    constructor(baseUrl: string, clientId: string, httpClient: IHttpClient, customAuthApiQueryParams?: Record<string, string> | undefined, requestInterceptor?: CustomAuthRequestInterceptor | undefined, logger?: Logger | undefined);
    authorizeChallengeStart(context: RequestContextV2, scopes?: string[]): Promise<AuthorizeChallengeEntryResultV2>;
    completeWithTokens(request: CompleteWithTokensRequestV2, context: RequestContextV2): Promise<TokenResponseV2>;
    protected authorizeChallengeContinue(continuationToken: string, context: RequestContextV2): Promise<string>;
    protected token(code: string, scopes: string[], context: RequestContextV2): Promise<TokenResponseV2>;
    protected sendActionRequest<T>(href: string, method: (typeof HttpMethod)[keyof typeof HttpMethod], body: ActionRequestBaseV2, context: RequestContextV2): Promise<ParsedResponseV2<T>>;
    protected throwOnApiError(parsedResponse: ParsedResponseV2<unknown>): void;
    private postOAuthForm;
    private sendRequest;
    private toApiError;
    private throwOnWebFallback;
    private ensureTokenResponseIsValid;
    private getCommonHeaders;
    private getAdditionalHeaders;
}
//# sourceMappingURL=BaseApiClientV2.d.ts.map