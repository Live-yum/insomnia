import { AuthenticationMethodV2 } from "../AuthenticationMethodV2.js";
import type { MFARequiredStateParametersV2 } from "./CustomAuthStateParametersV2.js";
import type { MFARequestChallengeResultV2 } from "../result/MFARequestChallengeResultV2.js";
import { AuthenticationMethodSelectionStateBaseV2 } from "./AuthenticationMethodSelectionStateBaseV2.js";
/**
 * State returned when sign-in requires a registered multi-factor
 * authentication method.
 */
export declare class MFARequiredStateV2 extends AuthenticationMethodSelectionStateBaseV2<MFARequiredStateParametersV2> {
    readonly stateType = "mfaRequired";
    /**
     * Requests a challenge for a registered MFA method.
     * @param method - A method from {@link methods}.
     * @returns A result requiring challenge verification or describing failure.
     */
    requestChallenge(method: AuthenticationMethodV2): Promise<MFARequestChallengeResultV2>;
}
//# sourceMappingURL=MFARequiredStateV2.d.ts.map