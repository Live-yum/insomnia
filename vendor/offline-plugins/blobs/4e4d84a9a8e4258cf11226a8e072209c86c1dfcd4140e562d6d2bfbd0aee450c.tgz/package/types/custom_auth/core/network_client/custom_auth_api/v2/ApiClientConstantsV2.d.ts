export declare const JSON_CONTENT_TYPE = "application/json";
export declare const UPDATE_RELATION = "update";
export declare const CHALLENGE_RELATION = "challenge";
export declare const VERIFY_RELATION = "verify";
export declare const RISK_VERIFY_RELATION = "riskverify";
export declare const COLLECT_ATTRIBUTES_RELATION = "collectAttributes";
export declare const AuthenticationMethodTypeV2: {
    readonly EMAIL: "email";
    readonly PASSWORD: "password";
    readonly SMS: "sms";
};
export declare const ResponseStateV2: {
    readonly INTERACTION_REQUIRED: "interactionRequired";
    readonly CONTINUE: "continue";
    readonly WEB_FALLBACK_REQUIRED: "webFallbackRequired";
};
//# sourceMappingURL=ApiClientConstantsV2.d.ts.map