export interface ResetPasswordUpdateResultV2 {
    continuationToken: string;
    pollHref: string;
}
export interface ResetPasswordPollResultV2 {
    continuationToken: string;
    isCompleted: boolean;
    pollHref?: string;
}
//# sourceMappingURL=ResetPasswordResultsV2.d.ts.map