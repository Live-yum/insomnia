import { ApiRequestBase } from "../../types/ApiTypesBase.js";
import { UserAccountAttributes } from "../../../../../UserAccountAttributes.js";
export type RequestContextV2 = ApiRequestBase;
export interface OAuthFormRequestV2 {
    client_id: string;
}
export interface AuthorizeChallengeEntryRequestV2 extends OAuthFormRequestV2 {
    scope?: string;
}
export interface AuthorizeChallengeContinueRequestV2 {
    continuation_token: string;
}
export interface TokenRequestV2 extends OAuthFormRequestV2 {
    grant_type: string;
    code: string;
    client_info: string;
    scope?: string;
}
export interface CompleteWithTokensRequestV2 {
    continuationToken: string;
    scopes: string[];
}
export interface ActionRequestBaseV2 {
    continuationToken: string;
}
interface StartRequestV2 extends ActionRequestBaseV2 {
    username: string;
}
export type PasswordResetStartRequestV2 = StartRequestV2;
export type SignInStartRequestV2 = StartRequestV2;
export type SignUpStartRequestV2 = ActionRequestBaseV2;
export interface SignUpSubmitAttributesRequestV2 extends ActionRequestBaseV2 {
    attributes: UserAccountAttributes & {
        email?: string;
        password?: string;
    };
}
export type ChallengeRequestV2 = ActionRequestBaseV2;
type VerifyRequestBaseV2 = ActionRequestBaseV2;
interface VerifyOtpRequestV2 extends VerifyRequestBaseV2 {
    otp: string;
}
interface VerifyPasswordRequestV2 extends VerifyRequestBaseV2 {
    password: string;
}
export type VerifyRequestV2 = VerifyOtpRequestV2 | VerifyPasswordRequestV2;
export interface UpdatePasswordRequestV2 extends ActionRequestBaseV2 {
    newPassword: string;
}
export type PollRequestV2 = ActionRequestBaseV2;
export {};
//# sourceMappingURL=RequestsV2.d.ts.map