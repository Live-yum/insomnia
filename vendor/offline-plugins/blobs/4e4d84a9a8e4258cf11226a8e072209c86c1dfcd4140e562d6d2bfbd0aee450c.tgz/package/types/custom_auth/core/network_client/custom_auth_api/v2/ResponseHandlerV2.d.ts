import { Logger } from "@azure/msal-common/browser";
import { EmbeddedMethodV2, ParsedResponseV2 } from "./response/ResponsesV2.js";
export declare class ResponseHandlerV2 {
    private readonly logger?;
    constructor(logger?: Logger | undefined);
    parseResponse<T>(response: Response, requestCorrelationId: string): Promise<ParsedResponseV2<T>>;
    requireHref(href: string | undefined, relation: string, correlationId: string, missingHrefError?: {
        code: string;
        message: string;
    }): string;
    requireContinuationToken(continuationToken: string | undefined, correlationId: string): string;
    requireMethods(methods: EmbeddedMethodV2[] | undefined, correlationId: string): EmbeddedMethodV2[];
    private parseBody;
}
//# sourceMappingURL=ResponseHandlerV2.d.ts.map