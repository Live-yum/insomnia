import { AuthenticationMethodV2 } from "../AuthenticationMethodV2.js";
import type { AuthMethodSelectionRequiredStateParametersV2 } from "./CustomAuthStateParametersV2.js";
import type { RequestChallengeResultV2 } from "../result/RequestChallengeResultV2.js";
import { AuthenticationMethodSelectionStateBaseV2 } from "./AuthenticationMethodSelectionStateBaseV2.js";
/**
 * State returned when the user must select one of several authentication
 * methods before a challenge can be issued. It exposes the list of offered
 * methods and lets the app request a challenge for the chosen one. The flow
 * stays on this state until a challenge is successfully requested.
 */
export declare class AuthMethodSelectionRequiredStateV2 extends AuthenticationMethodSelectionStateBaseV2<AuthMethodSelectionRequiredStateParametersV2> {
    readonly stateType = "authMethodSelectionRequired";
    /**
     * Requests a challenge for the selected authentication method. The returned
     * state identifies the credential the application must collect.
     * @param method - The method to challenge, from {@link methods}.
     * @returns The result of requesting the challenge.
     */
    requestChallenge(method: AuthenticationMethodV2): Promise<RequestChallengeResultV2>;
}
//# sourceMappingURL=AuthMethodSelectionRequiredStateV2.d.ts.map