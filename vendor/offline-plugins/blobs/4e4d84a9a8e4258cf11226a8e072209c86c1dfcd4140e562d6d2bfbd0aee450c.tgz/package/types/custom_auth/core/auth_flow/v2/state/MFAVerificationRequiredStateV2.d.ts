import type { MFAVerificationRequiredStateParametersV2 } from "./CustomAuthStateParametersV2.js";
import type { MFASubmitChallengeResultV2 } from "../result/MFASubmitChallengeResultV2.js";
import type { MFAResendChallengeResultV2 } from "../result/MFAResendChallengeResultV2.js";
import { ChallengeVerificationStateBaseV2 } from "./ChallengeVerificationStateBaseV2.js";
/**
 * State returned when sign-in requires verification of an email or SMS MFA
 * challenge. It allows the app to submit the challenge or request a replacement.
 */
export declare class MFAVerificationRequiredStateV2 extends ChallengeVerificationStateBaseV2<MFAVerificationRequiredStateParametersV2> {
    readonly stateType = "mfaVerificationRequired";
    /**
     * Submits the email or SMS challenge as the second authentication factor.
     * Successful verification completes sign-in.
     * @param challenge - The challenge value to submit.
     * @returns The result of submitting the MFA challenge.
     */
    submitChallenge(challenge: string): Promise<MFASubmitChallengeResultV2>;
    /**
     * Requests a replacement challenge for the selected MFA method. The
     * returned state contains the refreshed email or SMS challenge metadata.
     * @returns The result of requesting a replacement MFA challenge.
     */
    resendChallenge(): Promise<MFAResendChallengeResultV2>;
}
//# sourceMappingURL=MFAVerificationRequiredStateV2.d.ts.map