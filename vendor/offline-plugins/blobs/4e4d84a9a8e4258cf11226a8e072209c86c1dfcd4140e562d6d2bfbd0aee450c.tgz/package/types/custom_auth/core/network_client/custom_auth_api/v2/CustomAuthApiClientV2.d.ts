import { BaseApiClientV2 } from "./BaseApiClientV2.js";
import { ResetPasswordUpdateResultV2, ResetPasswordPollResultV2 } from "./result/ResetPasswordResultsV2.js";
import { ResetPasswordStartApiResultV2, SignInStartApiResultV2, ChallengeResultV2, ChallengeVerificationResultV2, VerifyResultV2 } from "./result/BaseResultsV2.js";
import { SignUpStartApiResultV2, SignUpSubmitAttributesApiResultV2 } from "./result/SignUpResultsV2.js";
import { RequestContextV2, PasswordResetStartRequestV2, SignInStartRequestV2, SignUpStartRequestV2, SignUpSubmitAttributesRequestV2, ChallengeRequestV2, VerifyRequestV2, UpdatePasswordRequestV2, PollRequestV2 } from "./request/RequestsV2.js";
export declare class CustomAuthApiClientV2 extends BaseApiClientV2 {
    resetPasswordStart(resetPasswordHref: string, request: PasswordResetStartRequestV2, context: RequestContextV2): Promise<ResetPasswordStartApiResultV2>;
    signInStart(signInHref: string, request: SignInStartRequestV2, context: RequestContextV2): Promise<SignInStartApiResultV2>;
    signUpStart(signUpHref: string, request: SignUpStartRequestV2, context: RequestContextV2): Promise<SignUpStartApiResultV2>;
    submitSignUpAttributes(submitAttributesHref: string, request: SignUpSubmitAttributesRequestV2, context: RequestContextV2): Promise<SignUpSubmitAttributesApiResultV2>;
    requestChallenge(challengeHref: string, request: ChallengeRequestV2, context: RequestContextV2): Promise<ChallengeResultV2>;
    verifyRisk(riskVerifyHref: string, request: ChallengeRequestV2, context: RequestContextV2): Promise<ChallengeVerificationResultV2>;
    verifyChallenge(verifyHref: string, request: VerifyRequestV2, context: RequestContextV2): Promise<VerifyResultV2>;
    submitNewPassword(updateHref: string, request: UpdatePasswordRequestV2, context: RequestContextV2): Promise<ResetPasswordUpdateResultV2>;
    poll(pollHref: string, request: PollRequestV2, context: RequestContextV2): Promise<ResetPasswordPollResultV2>;
    private sendStartRequest;
    private toVerifyResult;
    private resolveAuthenticationFactor;
    private toChallengeResult;
    private toChallengeVerificationResult;
    private resolveMethods;
}
//# sourceMappingURL=CustomAuthApiClientV2.d.ts.map