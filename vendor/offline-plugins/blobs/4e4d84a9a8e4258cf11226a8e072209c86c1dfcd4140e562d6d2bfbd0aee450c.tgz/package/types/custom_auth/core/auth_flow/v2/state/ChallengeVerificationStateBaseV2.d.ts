import { AuthFlowActionRequiredStateBase } from "../../AuthFlowState.js";
import type { AuthenticationMethodV2 } from "../AuthenticationMethodV2.js";
import type { CodeVerificationStateParametersV2 } from "./CustomAuthStateParametersV2.js";
import type { FlowCodeRequiredResultV2, FlowSubmitCodeResultV2 } from "../../../interaction_client/v2/result/FlowActionResultV2.js";
export declare abstract class ChallengeVerificationStateBaseV2<TParameters extends CodeVerificationStateParametersV2 = CodeVerificationStateParametersV2> extends AuthFlowActionRequiredStateBase<TParameters> {
    readonly method?: AuthenticationMethodV2;
    readonly sentTo?: string;
    readonly channel?: string;
    readonly codeLength?: number;
    constructor(stateParameters: TParameters);
    protected submitCodeCore(code: string): Promise<FlowSubmitCodeResultV2>;
    protected resendCodeCore(): Promise<FlowCodeRequiredResultV2>;
}
//# sourceMappingURL=ChallengeVerificationStateBaseV2.d.ts.map