export declare function resolveHrefV2(base: URL, href: string): URL;
//# sourceMappingURL=HrefResolverV2.d.ts.map