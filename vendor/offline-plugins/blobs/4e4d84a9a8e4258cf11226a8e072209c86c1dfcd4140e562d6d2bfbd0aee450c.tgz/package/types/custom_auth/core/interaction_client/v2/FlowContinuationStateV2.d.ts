import { CustomAuthFlowScenarioV2 } from "../../auth_flow/v2/CustomAuthFlowScenarioV2.js";
export interface FlowLinksV2 {
    challenge?: string;
    verify?: string;
    resend?: string;
    update?: string;
    poll?: string;
    submitAttributes?: string;
}
export interface FlowContinuationStateV2 {
    continuationToken: string;
    scenario: CustomAuthFlowScenarioV2;
    links: FlowLinksV2;
    tokenRequest?: {
        scopes?: string[];
    };
    signUp?: {
        passwordWasSupplied: boolean;
    };
}
//# sourceMappingURL=FlowContinuationStateV2.d.ts.map