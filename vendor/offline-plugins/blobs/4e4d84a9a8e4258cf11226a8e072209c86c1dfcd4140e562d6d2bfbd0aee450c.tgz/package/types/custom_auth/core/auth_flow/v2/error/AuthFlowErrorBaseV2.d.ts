import type { CustomAuthError } from "../../../error/CustomAuthError.js";
import { CustomAuthFlowScenarioV2 } from "../CustomAuthFlowScenarioV2.js";
import type { AttributeValidationDetailV2 } from "../../../network_client/custom_auth_api/v2/response/ErrorResponsesV2.js";
export declare abstract class AuthFlowErrorBaseV2 {
    errorData: CustomAuthError;
    readonly scenario: CustomAuthFlowScenarioV2;
    constructor(errorData: CustomAuthError, scenario?: CustomAuthFlowScenarioV2);
    get correlationId(): string | undefined;
    get errorCodes(): number[] | undefined;
    get errorDescription(): string | undefined;
    /**
     * Checks if the error requires the flow to continue in the browser. The
     * server surfaces this as a `redirect_to_web` failure, so a browser hand-off
     * always arrives as a `FailedStateV2` on which this detector returns true.
     * @returns True if the browser is required, false otherwise.
     */
    isBrowserRequired(): boolean;
    /**
     * Checks if the error is due to a caller-supplied argument failing
     * client-side validation before the request was issued (for example an empty
     * username, code, or password, or an unknown method id). Use it to prompt the
     * user to correct the input rather than treating it as a server failure.
     * @returns True if the input was invalid, false otherwise.
     */
    isInvalidInput(): boolean;
    /**
     * Checks whether an account already exists for the supplied identifier.
     * This can occur at different stages while completing sign-up.
     * @returns True if the account already exists, otherwise false.
     */
    isUserAlreadyExists(): boolean;
    protected isUserNotFoundError(): boolean;
    protected isUserInvalidError(): boolean;
    protected isInvalidCodeError(): boolean;
    protected isInvalidPasswordError(): boolean;
    protected isPasswordPolicyViolationError(): boolean;
    protected isPasswordIncorrectError(): boolean;
    protected getAttributeValidationDetails(): AttributeValidationDetailV2[];
}
//# sourceMappingURL=AuthFlowErrorBaseV2.d.ts.map