import { AuthFlowStateBase } from "../../AuthFlowState.js";
/**
 * Terminal state indicating the operation failed.
 *
 * The error is carried by the result's `error` payload, not by this state.
 */
export declare class FailedStateV2 extends AuthFlowStateBase {
    readonly stateType = "failed";
}
//# sourceMappingURL=FailedStateV2.d.ts.map