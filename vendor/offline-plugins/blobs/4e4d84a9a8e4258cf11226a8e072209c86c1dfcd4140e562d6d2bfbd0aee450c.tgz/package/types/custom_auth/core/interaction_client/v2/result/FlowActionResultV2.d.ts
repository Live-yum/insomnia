import { AuthenticationResult } from "../../../../../response/AuthenticationResult.js";
import { AuthenticationMethodV2 } from "../../../auth_flow/v2/AuthenticationMethodV2.js";
import { FlowContinuationStateV2 } from "../FlowContinuationStateV2.js";
import { SignUpAttributeV2 } from "../../../network_client/custom_auth_api/v2/result/SignUpResultsV2.js";
interface FlowActionResultBaseV2 {
    type: string;
    correlationId: string;
}
export interface FlowMethodSelectionRequiredResultV2 extends FlowActionResultBaseV2 {
    type: typeof FLOW_METHOD_SELECTION_REQUIRED_V2;
    continuationState: FlowContinuationStateV2;
    methods: AuthenticationMethodV2[];
}
export interface FlowCodeRequiredResultV2 extends FlowActionResultBaseV2 {
    type: typeof FLOW_CODE_REQUIRED_V2;
    continuationState: FlowContinuationStateV2;
    channel?: string;
    sentTo?: string;
    codeLength?: number;
}
export interface FlowSignInCodeRequiredResultV2 extends FlowCodeRequiredResultV2 {
    method: AuthenticationMethodV2;
}
export interface FlowResetPasswordCodeRequiredResultV2 extends FlowCodeRequiredResultV2 {
    method: AuthenticationMethodV2;
}
export interface FlowPasswordRequiredResultV2 extends FlowActionResultBaseV2 {
    type: typeof FLOW_PASSWORD_REQUIRED_V2;
    continuationState: FlowContinuationStateV2;
}
export interface FlowSignUpPasswordRequiredResultV2 extends FlowActionResultBaseV2 {
    type: typeof FLOW_SIGN_UP_PASSWORD_REQUIRED_V2;
    continuationState: FlowContinuationStateV2;
    attributes: SignUpAttributeV2[];
    requiredPasswordAttribute: SignUpAttributeV2;
}
export interface FlowMFARequiredResultV2 extends FlowActionResultBaseV2 {
    type: typeof FLOW_MFA_REQUIRED_V2;
    continuationState: FlowContinuationStateV2;
    methods: AuthenticationMethodV2[];
}
export interface FlowNewPasswordRequiredResultV2 extends FlowActionResultBaseV2 {
    type: typeof FLOW_NEW_PASSWORD_REQUIRED_V2;
    continuationState: FlowContinuationStateV2;
}
export interface FlowAttributesRequiredResultV2 extends FlowActionResultBaseV2 {
    type: typeof FLOW_ATTRIBUTES_REQUIRED_V2;
    continuationState: FlowContinuationStateV2;
    attributes: SignUpAttributeV2[];
}
export interface FlowSignInContinuationRequiredResultV2 extends FlowActionResultBaseV2 {
    type: typeof FLOW_SIGN_IN_CONTINUATION_REQUIRED_V2;
    continuationState: FlowContinuationStateV2;
}
export interface FlowCompletedResultV2 extends FlowActionResultBaseV2 {
    type: typeof FLOW_COMPLETED_V2;
    authenticationResult: AuthenticationResult;
}
export type FlowSubmitCodeResultV2 = FlowNewPasswordRequiredResultV2 | FlowSignUpPasswordRequiredResultV2 | FlowAttributesRequiredResultV2 | FlowSignInContinuationRequiredResultV2 | FlowMFARequiredResultV2 | FlowCompletedResultV2;
export type FlowSignUpActionResultV2 = FlowCodeRequiredResultV2 | FlowSignUpPasswordRequiredResultV2 | FlowAttributesRequiredResultV2 | FlowSignInContinuationRequiredResultV2;
export declare const FLOW_METHOD_SELECTION_REQUIRED_V2 = "FlowMethodSelectionRequiredResultV2";
export declare const FLOW_CODE_REQUIRED_V2 = "FlowCodeRequiredResultV2";
export declare const FLOW_PASSWORD_REQUIRED_V2 = "FlowPasswordRequiredResultV2";
export declare const FLOW_SIGN_UP_PASSWORD_REQUIRED_V2 = "FlowSignUpPasswordRequiredResultV2";
export declare const FLOW_MFA_REQUIRED_V2 = "FlowMFARequiredResultV2";
export declare const FLOW_NEW_PASSWORD_REQUIRED_V2 = "FlowNewPasswordRequiredResultV2";
export declare const FLOW_ATTRIBUTES_REQUIRED_V2 = "FlowAttributesRequiredResultV2";
export declare const FLOW_SIGN_IN_CONTINUATION_REQUIRED_V2 = "FlowSignInContinuationRequiredResultV2";
export declare const FLOW_COMPLETED_V2 = "FlowCompletedResultV2";
export declare function createFlowMethodSelectionRequiredResultV2(input: Omit<FlowMethodSelectionRequiredResultV2, "type">): FlowMethodSelectionRequiredResultV2;
export declare function createFlowCodeRequiredResultV2(input: Omit<FlowCodeRequiredResultV2, "type">): FlowCodeRequiredResultV2;
export declare function createFlowPasswordRequiredResultV2(input: Omit<FlowPasswordRequiredResultV2, "type">): FlowPasswordRequiredResultV2;
export declare function createFlowSignUpPasswordRequiredResultV2(input: Omit<FlowSignUpPasswordRequiredResultV2, "type">): FlowSignUpPasswordRequiredResultV2;
export declare function createFlowMFARequiredResultV2(input: Omit<FlowMFARequiredResultV2, "type">): FlowMFARequiredResultV2;
export declare function createFlowNewPasswordRequiredResultV2(input: Omit<FlowNewPasswordRequiredResultV2, "type">): FlowNewPasswordRequiredResultV2;
export declare function createFlowAttributesRequiredResultV2(input: Omit<FlowAttributesRequiredResultV2, "type">): FlowAttributesRequiredResultV2;
export declare function createFlowSignInContinuationRequiredResultV2(input: Omit<FlowSignInContinuationRequiredResultV2, "type">): FlowSignInContinuationRequiredResultV2;
export declare function createFlowCompletedResultV2(input: Omit<FlowCompletedResultV2, "type">): FlowCompletedResultV2;
export {};
//# sourceMappingURL=FlowActionResultV2.d.ts.map