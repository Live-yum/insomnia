import { AuthFlowActionRequiredStateBase } from "../../AuthFlowState.js";
import { AuthenticationMethodV2 } from "../AuthenticationMethodV2.js";
import type { CustomAuthActionRequiredStateParametersV2 } from "./CustomAuthStateParametersV2.js";
import type { FlowCodeRequiredResultV2, FlowPasswordRequiredResultV2 } from "../../../interaction_client/v2/result/FlowActionResultV2.js";
interface AuthenticationMethodSelectionStateParametersV2 extends CustomAuthActionRequiredStateParametersV2 {
    methods: readonly AuthenticationMethodV2[];
}
export declare abstract class AuthenticationMethodSelectionStateBaseV2<TParameters extends AuthenticationMethodSelectionStateParametersV2> extends AuthFlowActionRequiredStateBase<TParameters> {
    readonly methods: readonly AuthenticationMethodV2[];
    constructor(stateParameters: TParameters);
    protected requestSelectedMethodChallenge(method: AuthenticationMethodV2): Promise<{
        result: FlowCodeRequiredResultV2 | FlowPasswordRequiredResultV2;
        selectedMethod: AuthenticationMethodV2;
    }>;
}
export {};
//# sourceMappingURL=AuthenticationMethodSelectionStateBaseV2.d.ts.map