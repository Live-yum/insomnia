import { ICrypto, IPerformanceClient, Logger } from "@azure/msal-common/browser";
import { StandardInteractionClient } from "../../../../interaction_client/StandardInteractionClient.js";
import { BrowserConfiguration } from "../../../../config/Configuration.js";
import { BrowserCacheManager } from "../../../../cache/BrowserCacheManager.js";
import { EventHandler } from "../../../../event/EventHandler.js";
import { INavigationClient } from "../../../../navigation/INavigationClient.js";
import { RedirectRequest } from "../../../../request/RedirectRequest.js";
import { PopupRequest } from "../../../../request/PopupRequest.js";
import { SsoSilentRequest } from "../../../../request/SsoSilentRequest.js";
import { EndSessionRequest } from "../../../../request/EndSessionRequest.js";
import { ClearCacheRequest } from "../../../../request/ClearCacheRequest.js";
import { AuthenticationResult } from "../../../../response/AuthenticationResult.js";
import { CustomAuthAuthority } from "../../CustomAuthAuthority.js";
import { RequestContextV2 } from "../../network_client/custom_auth_api/v2/request/RequestsV2.js";
import { TokenResponseV2 } from "../../network_client/custom_auth_api/v2/response/ResponsesV2.js";
export declare abstract class InteractionClientBaseV2 extends StandardInteractionClient {
    protected customAuthAuthority: CustomAuthAuthority;
    private readonly tokenResponseHandler;
    constructor(config: BrowserConfiguration, storageImpl: BrowserCacheManager, browserCrypto: ICrypto, logger: Logger, eventHandler: EventHandler, navigationClient: INavigationClient, performanceClient: IPerformanceClient, customAuthAuthority: CustomAuthAuthority);
    acquireToken(request: RedirectRequest | PopupRequest | SsoSilentRequest): Promise<AuthenticationResult | void>;
    logout(request: EndSessionRequest | ClearCacheRequest | undefined): Promise<void>;
    protected getScopes(scopes: string[] | undefined): string[];
    protected handleTokenResponse(tokenResponse: TokenResponseV2, requestScopes: string[], correlationId: string, apiId: number): Promise<AuthenticationResult>;
    protected createRequestContext(apiId: number, correlationId: string): RequestContextV2;
}
//# sourceMappingURL=InteractionClientBaseV2.d.ts.map