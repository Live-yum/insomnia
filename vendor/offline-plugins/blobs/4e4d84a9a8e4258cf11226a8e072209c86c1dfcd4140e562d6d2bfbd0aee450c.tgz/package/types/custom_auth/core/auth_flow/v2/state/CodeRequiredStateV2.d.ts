import type { CodeRequiredStateParametersV2 } from "./CustomAuthStateParametersV2.js";
import type { VerifyChallengeResultV2 } from "../result/VerifyChallengeResultV2.js";
import type { RequestChallengeResultV2 } from "../result/RequestChallengeResultV2.js";
import { ChallengeVerificationStateBaseV2 } from "./ChallengeVerificationStateBaseV2.js";
/**
 * State returned when first-factor email authentication requires a one-time
 * code. It allows the app to submit the code or request a replacement.
 */
export declare class CodeRequiredStateV2 extends ChallengeVerificationStateBaseV2<CodeRequiredStateParametersV2> {
    readonly stateType = "codeRequired";
    /**
     * Submits the first-factor email code and advances the active flow. The
     * result may complete the operation or require another flow-specific step.
     * @param code - The code to submit.
     * @returns The result of submitting the first-factor code.
     */
    submitCode(code: string): Promise<VerifyChallengeResultV2>;
    /**
     * Requests a replacement first-factor email code. The returned state
     * contains the refreshed challenge metadata.
     * @returns The result of requesting a replacement code.
     */
    resendCode(): Promise<RequestChallengeResultV2>;
}
//# sourceMappingURL=CodeRequiredStateV2.d.ts.map