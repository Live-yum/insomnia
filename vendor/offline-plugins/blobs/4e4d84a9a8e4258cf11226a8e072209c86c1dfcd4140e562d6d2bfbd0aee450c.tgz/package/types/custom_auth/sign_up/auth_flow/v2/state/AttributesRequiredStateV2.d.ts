import type { UserAccountAttributes } from "../../../../UserAccountAttributes.js";
import type { SubmitAttributesResultV2 } from "../result/SubmitAttributesResultV2.js";
import { SignUpAttributesRequiredStateBaseV2 } from "./SignUpAttributesRequiredStateBaseV2.js";
import type { AttributesRequiredStateParametersV2 } from "./SignUpStateParametersV2.js";
/**
 * State returned when sign-up requires profile or custom attributes.
 */
export declare class AttributesRequiredStateV2 extends SignUpAttributesRequiredStateBaseV2<AttributesRequiredStateParametersV2> {
    readonly stateType = "attributesRequired";
    /**
     * Submits the attributes requested by the latest server response.
     */
    submitAttributes(attributes: UserAccountAttributes): Promise<SubmitAttributesResultV2>;
}
//# sourceMappingURL=AttributesRequiredStateV2.d.ts.map