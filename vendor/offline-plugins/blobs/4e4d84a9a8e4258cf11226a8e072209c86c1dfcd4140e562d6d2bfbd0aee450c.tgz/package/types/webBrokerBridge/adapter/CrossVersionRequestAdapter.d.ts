import { StringDict } from "@azure/msal-common/browser";
/**
 * Current request fields used by cross-version transformations.
 */
export interface CrossVersionRequestFields {
    extraQueryParameters?: StringDict;
    extraParameters?: StringDict;
    resource?: string;
}
/**
 * Deprecated request field names absent from the current request type.
 */
export interface LegacyRequestFields {
    tokenQueryParameters?: StringDict;
    tokenBodyParameters?: StringDict;
    authorizePostBodyParameters?: StringDict;
}
/**
 * Current request extended with all known legacy fields.
 */
export type CrossVersionRequest<TRequest extends CrossVersionRequestFields = CrossVersionRequestFields> = TRequest & LegacyRequestFields;
/**
 * Promotes `extraParameters.resource` to the top-level `resource` field.
 *
 * Pre-5.5.0 embedded apps do not have a top-level `resource` field.
 *
 * @param request - The request to transform.
 * @returns A new request with `resource` promoted if applicable.
 */
export declare function normalizeResourceField<TRequest extends CrossVersionRequestFields>(request: TRequest): TRequest;
/**
 * Demotes the top-level `resource` field into `extraParameters.resource`.
 *
 * Pre-5.5.0 embedded apps do not have a top-level `resource` field.
 *
 * @param request - The request to transform.
 * @returns A new request with `resource` demoted if applicable.
 */
export declare function addResourceField<TRequest extends CrossVersionRequestFields>(request: TRequest): TRequest;
/**
 * Normalize an incoming request from any embedded-app version so that
 * the broker PCA methods can consume it correctly.
 *
 * - Folds legacy field values into their current equivalents.
 * - Strips legacy field names from the returned object.
 * - Is idempotent: safe to call on requests that already use current names.
 *
 * @param request - The request from a broker auth request.
 * @returns A new request with current field names only.
 */
export declare function normalizeIncomingRequest<TRequest extends CrossVersionRequestFields>(request: CrossVersionRequest<TRequest>): TRequest;
/**
 * Add legacy field aliases to an outgoing request so that an older broker
 * can still consume the parameters.
 *
 * - Copies current field values into all known legacy field names.
 * - Merges extraParameters into extraQueryParameters (extraParameters wins)
 *   so the v4 broker sees them on the /authorize query string.
 * - Deliberately omits authorizePostBodyParameters.
 * - Is idempotent: safe to call multiple times.
 *
 * @param request - The request about to be wrapped in a broker auth request.
 * @returns A new request carrying both current and legacy field names.
 */
export declare function addLegacyRequestFields<TRequest extends CrossVersionRequestFields>(request: TRequest): CrossVersionRequest<TRequest>;
//# sourceMappingURL=CrossVersionRequestAdapter.d.ts.map