import { IWebBrokerBridgeMessage } from "./IWebBrokerBridgeMessage.js";
export type WebBrokerBridgeSendFn<TReq extends IWebBrokerBridgeMessage> = (message: TReq) => void;
/**
 * Correlates outbound requests with inbound responses by `requestId`.
 */
export declare class PendingRequestRegistry<TResp> {
    private readonly pending;
    /**
     * Register a pending request. Returns a promise that resolves when a
     * response with the matching `requestId` arrives, or rejects if the
     * caller invokes `reject` for that id.
     */
    register(requestId: string): Promise<TResp>;
    /** Resolve a pending request. No-op if `requestId` isn't registered. */
    resolve(requestId: string, response: TResp): void;
    /** Reject a pending request. No-op if `requestId` isn't registered. */
    reject(requestId: string, reason: unknown): void;
    /** True if `requestId` has an in-flight registration. */
    has(requestId: string): boolean;
    /**
     * Register, then invoke `send` synchronously. If `send` throws, the
     * pending entry is cleared and the promise rejects with the thrown
     * error.
     */
    sendAndAwait<TReq extends IWebBrokerBridgeMessage>(message: TReq, send: WebBrokerBridgeSendFn<TReq>): Promise<TResp>;
}
//# sourceMappingURL=PendingRequestRegistry.d.ts.map