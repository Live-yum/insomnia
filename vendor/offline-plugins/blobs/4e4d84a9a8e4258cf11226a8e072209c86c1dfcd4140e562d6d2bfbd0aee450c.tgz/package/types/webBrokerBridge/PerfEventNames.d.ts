/**
 * Shared performance event names for web broker bridge operations.
 *
 * @internal
 */
export declare const PairwiseBrokerApplicationInitializeBrokering = "pairwiseBrokerApplicationInitializeBrokering";
export declare const BrokerClientApplicationHandleBrokerHandshake = "brokerClientApplicationHandleBrokerHandshake";
export declare const BrokerClientApplicationBrokeredSSOSilentRequest = "brokerClientApplicationBrokeredSSOSilentRequest";
export declare const BrokerClientApplicationBrokeredSilentRequest = "brokerClientApplicationBrokeredSilentRequest";
export declare const EmbeddedClientApplicationSendSSOSilentRequest = "embeddedSSOSilent";
export declare const EmbeddedClientApplicationSendPopupRequest = "embeddedPopup";
export declare const EmbeddedClientApplicationHandleRedirectRequest = "embeddedHandleRedirect";
export declare const EmbeddedClientApplicationSendSilentRefreshRequest = "embeddedSilentRefresh";
export declare const EmbeddedSendSilentRefreshRequestInternal = "embeddedSilentRefreshInternal";
export declare const SendHandshakeRequest = "sendHandshakeRequest";
export declare const SendMessageToBroker = "sendMessageToBroker";
export declare const SendRequest = "sendRequest";
export declare const HandleResponse = "handleBrokerResponse";
export declare const GetFrameDepth = "getFrameDepth";
export declare const OnHandshakeResponse = "onHandshakeResponse";
export declare const HandleBrokerMessage = "handleBrokerMessage";
export declare const PostMessageToAllDescendantFrames = "postMessageToAllDescendantFrames";
export declare const HandleBrokerAuthRequest = "handleBrokerAuthRequest";
export declare const BrokeredSilentRequest = "brokeredSilentRequest";
export declare const BrokeredSsoSilentRequest = "brokeredSsoSilentRequest";
export declare const BrokeredRedirectRequest = "brokeredRedirectRequest";
export declare const BrokeredPopupRequest = "brokeredPopupRequest";
export declare const InteractiveBrokerRequest = "interactiveBrokerRequest";
export declare const AcquireTokenByBroker = "acquireTokenByBroker";
//# sourceMappingURL=PerfEventNames.d.ts.map