import { AccountInfo } from "@azure/msal-common/browser";
/**
 * ClearCacheRequest
 */
export type ClearCacheRequest = {
    /**
     * Unique GUID set per request to trace a request end-to-end for telemetry purposes.
     */
    correlationId?: string;
    /**
     * Account object that will be logged out of. All tokens tied to this account will be cleared.
     */
    account?: AccountInfo | null;
};
//# sourceMappingURL=ClearCacheRequest.d.ts.map