import { AccountInfo, Constants, BaseAuthRequest, CommonAuthorizationUrlRequest, CommonSilentFlowRequest, IPerformanceClient, ITokenBindingKeyManager, Logger, ProtocolMode } from "@azure/msal-common/browser";
import { BrowserConfiguration } from "../config/Configuration.js";
import { SilentRequest } from "./SilentRequest.js";
import { PopupRequest } from "./PopupRequest.js";
import { RedirectRequest } from "./RedirectRequest.js";
/**
 * Resolves the token-binding parameters needed before building authorize or token requests.
 * Public PCA DPoP requests use a dpopJkt thumbprint, while platform broker PoP requests use
 * a reqCnf confirmation claim. Requests that do not require request-time token binding return
 * no additional parameters.
 */
export declare function getTokenBindingRequestParams(request: Partial<BaseAuthRequest> & {
    correlationId: string;
    platformBroker?: boolean;
}, tokenBindingKeyManager: ITokenBindingKeyManager, logger: Logger, performanceClient: IPerformanceClient): Promise<Pick<CommonAuthorizationUrlRequest, "dpopJkt" | "reqCnf">>;
/**
 * Initializer function for all request APIs
 * @param request
 * @param config
 * @param performanceClient
 * @param logger
 * @param correlationId
 */
export declare function initializeBaseRequest(request: Partial<BaseAuthRequest> & {
    correlationId: string;
}, config: BrowserConfiguration, performanceClient: IPerformanceClient, logger: Logger, correlationId: string): Promise<BaseAuthRequest>;
export declare function initializeSilentRequest(request: SilentRequest & {
    correlationId: string;
}, account: AccountInfo, config: BrowserConfiguration, performanceClient: IPerformanceClient, logger: Logger): Promise<CommonSilentFlowRequest>;
/**
 * Validates that the combination of request method, protocol mode and authorize body parameters is correct.
 * Returns the validated or defaulted HTTP method or throws if the configured combination is invalid.
 * @param interactionRequest
 * @param protocolMode
 * @returns
 */
export declare function validateRequestMethod(interactionRequest: BaseAuthRequest | PopupRequest | RedirectRequest, protocolMode: ProtocolMode): Constants.HttpMethod;
//# sourceMappingURL=RequestHelpers.d.ts.map