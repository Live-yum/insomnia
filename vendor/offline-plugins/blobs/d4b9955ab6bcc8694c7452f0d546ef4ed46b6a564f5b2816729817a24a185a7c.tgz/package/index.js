"use strict";
module.exports.requestHooks = [
    require('./src/coinbase-apikey-auth')
];
