"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const crypto_1 = require("crypto");
function unixTimestamp() {
    return Math.floor(new Date().getTime() / 1000);
}
function getPathUrl(string_url) {
    return new URL(string_url).pathname;
}
function JSONStringifyIfNotEmpty(obj) {
    const json_string = JSON.stringify(obj);
    if (json_string === "{}") {
        return "";
    }
    return json_string;
}
function coinbaseApikeyAuthRequestHook(context) {
    console.log('coinbase-apikey-auth plugin executing ...');
    const apiKey = context.request.getEnvironmentVariable('COINBASE_API_KEY');
    const secretKey = context.request.getEnvironmentVariable('COINBASE_SECRET_KEY');
    const timestamp = unixTimestamp();
    const requestMethod = context.request.getMethod().toUpperCase();
    const requestUrl = context.request.getUrl();
    // We have to use an empty string if the body is an empty json object
    const body = JSONStringifyIfNotEmpty(context.request.getBody());
    if (!apiKey || !secretKey) {
        throw Error('COINBASE_API_KEY or COINBASE_SECRET_KEY variable is missing from the environment.');
    }
    else {
        const message = `${timestamp}${requestMethod}${getPathUrl(requestUrl)}${body}`;
        const cb_access_sign = crypto_1.createHmac('sha256', secretKey)
            .update(message)
            .digest('hex');
        context.request.setHeader('CB-ACCESS-SIGN', cb_access_sign);
        console.log(`[header] Set CB-ACCESS-SIGN header: ${cb_access_sign}`);
        context.request.setHeader('CB-ACCESS-TIMESTAMP', `${timestamp}`);
        console.log(`[header] Set CB-ACCESS-TIMESTAMP header: ${timestamp}`);
        context.request.setHeader('CB-ACCESS-KEY', apiKey);
        console.log(`[header] Set CB-ACCESS-KEY header: ${apiKey}`);
    }
}
module.exports = coinbaseApikeyAuthRequestHook;
