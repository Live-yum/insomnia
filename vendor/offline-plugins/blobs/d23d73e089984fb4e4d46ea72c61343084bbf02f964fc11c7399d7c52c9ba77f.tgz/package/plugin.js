const userAgent = require('random-useragent');

module.exports.requestHooks = [
	ctx => {
		console.log(ctx);
		ctx.request.setHeader('User-Agent', userAgent.getRandom());
	}
];
