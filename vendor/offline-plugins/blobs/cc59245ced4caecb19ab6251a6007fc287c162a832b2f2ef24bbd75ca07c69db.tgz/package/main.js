const CryptoJS = require('crypto-js');

module.exports.templateTags = [{
  name: 'calculateChecksum',
  displayName: 'Calculate Checksum',
  description: 'Calculates SHA-256 checksum by nirza',
  args: [
    { displayName: 'var1', type: 'string' },
    { displayName: 'var2', type: 'string' },
    { displayName: 'var3', type: 'string' },
    { displayName: 'var4', type: 'string' },
    { displayName: 'var5', type: 'string' },
    { displayName: 'var6', type: 'string' },
    { displayName: 'var7', type: 'string' },
    { displayName: 'var8', type: 'string' },
    { displayName: 'var9', type: 'string' },
    { displayName: 'var10', type: 'string' },
    { displayName: 'var11', type: 'string' },
    { displayName: 'var12', type: 'string' },
    { displayName: 'var13', type: 'string' },
  ],
  run(context, var1, var2, var3, var4, var5, var6, var7) {
    const combinedString = var1 + var2 + var3 + var4 + var5 + var6 + var7;
    const checksum = CryptoJS.SHA256(combinedString).toString(CryptoJS.enc.Hex);
    return checksum;
  }
}];
