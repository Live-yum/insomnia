# The checksum plugin

Helps creating checksums automatically :)