# Insomnia Plugin: JSON5 Request Body

## Overview

Parse JSON request body as JSON5 and return JSON back to Insomnia.

Allows for trailing commas on objects and arrays, comments and more (see https://npmjs.com/package/json5 for more details - this is the library used to parse the request body).
