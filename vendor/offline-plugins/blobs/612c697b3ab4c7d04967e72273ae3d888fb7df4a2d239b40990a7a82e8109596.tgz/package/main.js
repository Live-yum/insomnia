const JSON5 = require('json5');

module.exports.requestHooks = [
  (context) => {
    try {
      const body = context.request.getBody();

      context.request.setBody({
        ...body,
        text: JSON.stringify(JSON5.parse(body.text)),
      });
    } catch (err) {
      console.error('JSON5 plugin error:', err);
    }
  }
];
