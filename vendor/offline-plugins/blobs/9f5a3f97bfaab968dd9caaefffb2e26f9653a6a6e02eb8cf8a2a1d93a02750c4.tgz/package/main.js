const fs = require('fs');

module.exports.workspaceActions = [{
  label: 'Export Workspace',
  icon: 'fa-arrow-right',
  action: async (context, models) => {
    const syncPathAvailable = await context.store.hasItem(`sync-path:${models.workspace._id}`)
    let syncPath
    if (syncPathAvailable) {
        syncPath = await context.store.getItem(`sync-path:${models.workspace._id}`)
    } else {
      syncPath = await setSyncPath(context, models.workspace._id)
      if (syncPath == null) return
    }

    const ex = await context.data.export.insomnia({
      includePrivate: false,
      format: 'yaml',
      workspace: models.workspace,
    });

    fs.writeFileSync(syncPath, ex);
  },
},
{
  label: 'Import Workspace',
  icon: 'fa-arrow-left',
  action: async (context, models) => {
    const syncPathAvailable = await context.store.hasItem(`sync-path:${models.workspace._id}`)
    let syncPath
    if (syncPathAvailable) {
        syncPath = await context.store.getItem(`sync-path:${models.workspace._id}`)
    } else {
      syncPath = await setSyncPath(context, models.workspace._id)
      if (syncPath == null) return
    }

    const data = fs.readFileSync(syncPath, 'utf-8')
    await context.data.import.raw(data, { workspaceId: models.workspace._id });
  },
},
{
  label: 'Set sync path',
  icon: 'fa-file',
  action: async (context, models) => {
    await setSyncPath(context, models.workspace._id)
  },
}];

async function setSyncPath(context, workspaceId) {
  const path = await context.app.showSaveDialog({})
  if (path == null) return null
  await context.store.setItem(`sync-path:${workspaceId}`, path)
  return path
}