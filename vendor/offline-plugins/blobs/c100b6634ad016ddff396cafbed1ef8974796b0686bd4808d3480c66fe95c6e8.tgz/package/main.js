"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.requestActions = exports.requestHooks = void 0;
var credential_providers_1 = require("@aws-sdk/credential-providers");
exports.requestHooks = [
    function (context) { return __awaiter(void 0, void 0, void 0, function () {
        var awsProfile, credsStr, creds;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, context.store.getItem("awsProfile")];
                case 1:
                    awsProfile = _a.sent();
                    if (!awsProfile) {
                        return [2 /*return*/, null];
                    }
                    return [4 /*yield*/, context.store.getItem("awsCreds")];
                case 2:
                    credsStr = _a.sent();
                    creds = JSON.parse(credsStr);
                    if (!(creds.expiration &&
                        creds.expiration.valueOf() <= new Date().valueOf())) return [3 /*break*/, 4];
                    return [4 /*yield*/, updateCreds(context, awsProfile)];
                case 3:
                    creds = _a.sent();
                    _a.label = 4;
                case 4:
                    console.log(credsStr);
                    context.request.setAuthenticationParameter("type", "iam");
                    context.request.setAuthenticationParameter("accessKeyId", creds.accessKeyId);
                    context.request.setAuthenticationParameter("secretAccessKey", creds.secretAccessKey);
                    context.request.setAuthenticationParameter("sessionToken", creds.sessionToken);
                    return [2 /*return*/];
            }
        });
    }); },
];
exports.requestActions = [
    {
        label: "Set AWS profile",
        action: function (context) { return __awaiter(void 0, void 0, void 0, function () {
            var profile;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, context.app.prompt("Please enter AWS profile to use for ALL requests")];
                    case 1:
                        profile = _a.sent();
                        return [4 /*yield*/, context.store.setItem("awsProfile", profile)];
                    case 2:
                        _a.sent();
                        return [4 /*yield*/, updateCreds(context, profile)];
                    case 3:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        }); },
    },
    {
        label: "Clear AWS profile",
        action: function (context) { return __awaiter(void 0, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, context.store.removeItem("awsProfile")];
                    case 1:
                        _a.sent();
                        return [4 /*yield*/, context.app.alert("AWS profile removed. Future requests will not use plugin")];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        }); },
    },
];
function updateCreds(context, profile) {
    return __awaiter(this, void 0, void 0, function () {
        var credsProvider, creds;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, (0, credential_providers_1.fromNodeProviderChain)({ profile: profile })];
                case 1:
                    credsProvider = _a.sent();
                    return [4 /*yield*/, credsProvider()];
                case 2:
                    creds = _a.sent();
                    return [4 /*yield*/, context.store.setItem("awsCreds", JSON.stringify(creds))];
                case 3:
                    _a.sent();
                    return [2 /*return*/, creds];
            }
        });
    });
}
