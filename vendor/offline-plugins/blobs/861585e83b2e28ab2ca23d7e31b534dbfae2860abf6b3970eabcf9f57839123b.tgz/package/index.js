module.exports.requestHooks =
[
    (context) =>
    {
        const req = context.request;
        if (!req.getUrl().startsWith("https://sandbox.api.visa.com/cybersource/payments/flex/v1/keys"))
        {
            console.log("Not Generate Keys Endpoint.");
            return;
        }

        const sharedSecret = req.getEnvironmentVariable('sharedSecret');
        if (sharedSecret == null)
        {
            throw new Error("Cannot find environment variable 'sharedSecret'");
        }

        var queryParams = req.getParameters();
        if (queryParams.length <= 0)
        {
            throw new Error("At least one query parameter needed: apikey");
        }
        var paramsArray = [];
        var param;
        for(param of queryParams)
        {
            paramsArray.push(param.name + '=' + param.value);
        }

        var queryString = paramsArray.join("&");
        var postBody = req.getBodyText();
        var timestamp = Math.floor(Date.now() / 1000);
        var resourcePath = "payments/flex/v1/keys";
        var preHashString = timestamp + resourcePath + queryString + postBody;

        console.log(preHashString);

        var crypto = require('crypto');
        var hashString = crypto.createHmac('SHA256', sharedSecret).update(preHashString).digest('hex');
        var xPayToken = 'xv2:' + timestamp + ':' + hashString;
        req.setHeader('x-pay-token', xPayToken);
    }
]

module.exports.responseHooks =
[
    (context) =>
    {
        const req = context.request;
        const res = context.response;
        const store = context.store;

        if (!req.getUrl().startsWith("https://sandbox.api.visa.com/cybersource/payments/flex/v1/keys"))
        {
            console.log("Not Generate Keys Endpoint.");
            return;
        }

        if(res.getStatusCode() != 200)
        {
            return;
        }

        let body = res.getBody();
        if(body == null)
        {
            return;
        }

        body = JSON.parse(body);
        if (body.keyId)
        {
            store.setItem("keyId", body.keyId).then(function ()
            {
                console.log("keyId saved");
            }, function (err)
            {
                console.error(error);
            });
        }

        if (body.der && body.der.publicKey)
        {
            store.setItem("publicKey", body.der.publicKey).then(function ()
            {
                console.log("publicKey saved");
            }, function (err)
            {
                console.error(error);
            });
        }
    }
]
