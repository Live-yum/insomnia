const crypto = require('crypto');


function createSHA256Digest(str) {
  const hash = crypto.createHash('sha256');
  hash.update(str);
  return hash.digest('hex');
}

function createHmacSignature(str, secret) {
  const hmac = crypto.createHmac('sha256', secret);
  hmac.update(str);
  return hmac.digest('hex');
}

function computeRequestSignature(req, secret) {
  const { method, pathWithQuery, body, contentType, date } = req;
  const contentDigest = createSHA256Digest(body);
  const payload = `${method.toLowerCase()}\n${contentType}\n${date}\n${pathWithQuery}\n${contentDigest}`;
  return createHmacSignature(payload, secret);
}

// https://docs.insomnia.rest/insomnia/context-object-reference
module.exports.templateTags = [{
    name: 'hmac-header',
    displayName: 'Hmac generated based on request information',
    description: 'Generated hmac for a request',
    args: [
        /*
        {
            displayName: '',
            description: '',
            type: '',
            defaultValue: 0
        }
        */
    ],
    async run (context) {
        const ACCESS_KEY_SECRET_EXAMPLE = context.getEnvironmentVariable('accessKeySecret');

        const req = {
          method: context.getMethod().toUpperCase(),
          pathWithQuery: context.getUrl(),
          body: context.getBody().text /*JSON.stringify() */,
          contentType: context.getHeader('Content-Type'),
          date: context.getHeader('Date'),
        };

        let hmac = computeRequestSignature(req, ACCESS_KEY_SECRET_EXAMPLE);

        console.log(
          'hmac_signature: ',
          hmac,
        );

        return hmac;
    }
}];