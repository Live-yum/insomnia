##Insomnia Plugin Stephen Strange

This is a plugin for [Insomnia](https://insomnia.rest) that allows users sync workspaces with gist of GitHub.
with custom Insomnia app done by Massive Infinity Team.

- Addition functions

## Installation

Install the `@massiveinfinity/insomnia-plugin-stephen-strange` plugin from Preferences > Plugins.

## Configure

1. Create a [personal access token](https://help.github.com/en/github/authenticating-to-github/creating-a-personal-access-token-for-the-command-line) to your GitHub account, with `gist` scope/permission.

2. Go to Insomnia, click on Insomnia Main Menu, and click on "Github - Settings":

![Plugin Screenshot](docs/plugin.png)

3. Filling with GitHub API Key (generated on step 1), select a existent Gist or select "Create new..." to create a new Gist.

![Configuration Plugin Screenshot](docs/config.png)

## Usage

- Click on "Push to Github" to send your workspaces to Github Repository.
- Click on "Pull from Github" to get your workspaces from Github Repository by mixing.
- Click on "FORCE Pull from Github" to get your workspaces freshly from Github Repository.
