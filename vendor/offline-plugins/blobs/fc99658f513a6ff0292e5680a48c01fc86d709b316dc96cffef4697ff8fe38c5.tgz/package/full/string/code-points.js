'use strict';
require('../../modules/es.object.to-string');
require('../../modules/esnext.string.code-points');

module.exports = require('../../internals/entry-unbind')('String', 'codePoints');
