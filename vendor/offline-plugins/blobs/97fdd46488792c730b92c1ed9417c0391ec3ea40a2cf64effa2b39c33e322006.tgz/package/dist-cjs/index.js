const { awsEndpointFunctions, emitWarningIfUnsupportedVersion: emitWarningIfUnsupportedVersion$1, createDefaultUserAgentProvider, NODE_APP_ID_CONFIG_OPTIONS, getAwsRegionExtensionConfiguration, resolveAwsRegionExtensionConfiguration, resolveUserAgentConfig, resolveHostHeaderConfig, getUserAgentPlugin, getHostHeaderPlugin, getLoggerPlugin, getRecursionDetectionPlugin } = require("@aws-sdk/core/client");
const { getHttpAuthSchemeEndpointRuleSetPlugin, DefaultIdentityProviderConfig, getHttpSigningPlugin, createPaginator } = require("@smithy/core");
const { normalizeProvider, getSmithyContext, ServiceException, NoOpLogger, emitWarningIfUnsupportedVersion, loadConfigsForDefaultMode, getDefaultExtensionConfiguration, resolveDefaultRuntimeConfig, Client, makeBuilder, createWaiter, checkExceptions, WaiterState, createAggregatedClient } = require("@smithy/core/client");
const { Command: $Command } = require("@smithy/core/client");
exports.$Command = $Command;
exports.__Client = Client;
const { resolveDefaultsModeConfig, loadConfig, NODE_USE_FIPS_ENDPOINT_CONFIG_OPTIONS, NODE_USE_DUALSTACK_ENDPOINT_CONFIG_OPTIONS, NODE_REGION_CONFIG_OPTIONS, NODE_REGION_CONFIG_FILE_OPTIONS, resolveRegionConfig } = require("@smithy/core/config");
const { BinaryDecisionDiagram, EndpointCache, decideEndpoint, customEndpointFunctions, resolveEndpointConfig, getEndpointPlugin } = require("@smithy/core/endpoints");
const { parseUrl, getHttpHandlerExtensionConfiguration, resolveHttpHandlerRuntimeConfig, getContentLengthPlugin } = require("@smithy/core/protocols");
const { DEFAULT_RETRY_MODE, NODE_RETRY_MODE_CONFIG_OPTIONS, NODE_MAX_ATTEMPT_CONFIG_OPTIONS, resolveRetryConfig, getRetryPlugin } = require("@smithy/core/retry");
const { TypeRegistry, getSchemaSerdePlugin } = require("@smithy/core/schema");
const { resolveAwsSdkSigV4Config, AwsSdkSigV4Signer, NODE_AUTH_SCHEME_PREFERENCE_OPTIONS } = require("@aws-sdk/core/httpAuthSchemes");
const { defaultProvider } = require("@aws-sdk/credential-provider-node");
const { toUtf8, fromUtf8, toBase64, fromBase64, calculateBodyLength } = require("@smithy/core/serde");
const { streamCollector, NodeHttpHandler } = require("@smithy/node-http-handler");
const { AwsJson1_1Protocol } = require("@aws-sdk/core/protocols");
const { Sha256 } = require("@smithy/core/checksum");

const defaultSSMHttpAuthSchemeParametersProvider = async (config, context, input) => {
    return {
        operation: getSmithyContext(context).operation,
        region: await normalizeProvider(config.region)() || (() => {
            throw new Error("expected `region` to be configured for `aws.auth#sigv4`");
        })(),
    };
};
function createAwsAuthSigv4HttpAuthOption(authParameters) {
    return {
        schemeId: "aws.auth#sigv4",
        signingProperties: {
            name: "ssm",
            region: authParameters.region,
        },
        propertiesExtractor: (config, context) => ({
            signingProperties: {
                config,
                context,
            },
        }),
    };
}
const defaultSSMHttpAuthSchemeProvider = (authParameters) => {
    const options = [];
    switch (authParameters.operation) {
        default: {
            options.push(createAwsAuthSigv4HttpAuthOption(authParameters));
        }
    }
    return options;
};
const resolveHttpAuthSchemeConfig = (config) => {
    const config_0 = resolveAwsSdkSigV4Config(config);
    return Object.assign(config_0, {
        authSchemePreference: normalizeProvider(config.authSchemePreference ?? []),
    });
};

const resolveClientEndpointParameters = (options) => {
    return Object.assign(options, {
        useDualstackEndpoint: options.useDualstackEndpoint ?? false,
        useFipsEndpoint: options.useFipsEndpoint ?? false,
        defaultSigningName: "ssm",
    });
};
const commonParams = {
    UseFIPS: { type: "builtInParams", name: "useFipsEndpoint" },
    Endpoint: { type: "builtInParams", name: "endpoint" },
    Region: { type: "builtInParams", name: "region" },
    UseDualStack: { type: "builtInParams", name: "useDualstackEndpoint" },
};

var version = "3.1139.0";
var packageInfo = {
	version: version};

const k = "ref";
const a = -1, b = true, c = "isSet", d = "PartitionResult", e = "booleanEquals", f = "getAttr", g = { [k]: "Endpoint" }, h = { [k]: d }, i = {}, j = [{ [k]: "Region" }];
const _data = {
    conditions: [
        [c, [g]],
        [c, j],
        ["aws.partition", j, d],
        [e, [{ [k]: "UseFIPS" }, b]],
        [e, [{ [k]: "UseDualStack" }, b]],
        [e, [{ fn: f, argv: [h, "supportsDualStack"] }, b]],
        [e, [{ fn: f, argv: [h, "supportsFIPS"] }, b]],
        ["stringEquals", [{ fn: f, argv: [h, "name"] }, "aws-us-gov"]]
    ],
    results: [
        [a],
        [a, "Invalid Configuration: FIPS and custom endpoint are not supported"],
        [a, "Invalid Configuration: Dualstack and custom endpoint are not supported"],
        [g, i],
        ["https://ssm-fips.{Region}.{PartitionResult#dualStackDnsSuffix}", i],
        [a, "FIPS and DualStack are enabled, but this partition does not support one or both"],
        ["https://ssm.{Region}.amazonaws.com", i],
        ["https://ssm-fips.{Region}.{PartitionResult#dnsSuffix}", i],
        [a, "FIPS is enabled but this partition does not support FIPS"],
        ["https://ssm.{Region}.{PartitionResult#dualStackDnsSuffix}", i],
        [a, "DualStack is enabled but this partition does not support DualStack"],
        ["https://ssm.{Region}.{PartitionResult#dnsSuffix}", i],
        [a, "Invalid Configuration: Missing Region"]
    ]
};
const root = 2;
const r = 100_000_000;
const nodes = new Int32Array([
    -1, 1, -1,
    0, 13, 3,
    1, 4, r + 12,
    2, 5, r + 12,
    3, 8, 6,
    4, 7, r + 11,
    5, r + 9, r + 10,
    4, 11, 9,
    6, 10, r + 8,
    7, r + 6, r + 7,
    5, 12, r + 5,
    6, r + 4, r + 5,
    3, r + 1, 14,
    4, r + 2, r + 3,
]);
const bdd = BinaryDecisionDiagram.from(nodes, root, _data.conditions, _data.results);

const cache = new EndpointCache({
    size: 50,
    params: ["Endpoint", "Region", "UseDualStack", "UseFIPS"],
});
const defaultEndpointResolver = (endpointParams, context = {}) => {
    return cache.get(endpointParams, () => decideEndpoint(bdd, {
        endpointParams: endpointParams,
        logger: context.logger,
    }));
};
customEndpointFunctions.aws = awsEndpointFunctions;

class SSMServiceException extends ServiceException {
    constructor(options) {
        super(options);
        Object.setPrototypeOf(this, SSMServiceException.prototype);
    }
}

class AccessDeniedException extends SSMServiceException {
    name = "AccessDeniedException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "AccessDeniedException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, AccessDeniedException.prototype);
        this.Message = opts.Message;
    }
}
class InternalServerError extends SSMServiceException {
    name = "InternalServerError";
    $fault = "server";
    Message;
    constructor(opts) {
        super({
            name: "InternalServerError",
            $fault: "server",
            ...opts,
        });
        Object.setPrototypeOf(this, InternalServerError.prototype);
        this.Message = opts.Message;
    }
}
class InvalidResourceId extends SSMServiceException {
    name = "InvalidResourceId";
    $fault = "client";
    constructor(opts) {
        super({
            name: "InvalidResourceId",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidResourceId.prototype);
    }
}
class InvalidResourceType extends SSMServiceException {
    name = "InvalidResourceType";
    $fault = "client";
    constructor(opts) {
        super({
            name: "InvalidResourceType",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidResourceType.prototype);
    }
}
class TooManyTagsError extends SSMServiceException {
    name = "TooManyTagsError";
    $fault = "client";
    constructor(opts) {
        super({
            name: "TooManyTagsError",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, TooManyTagsError.prototype);
    }
}
class TooManyUpdates extends SSMServiceException {
    name = "TooManyUpdates";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "TooManyUpdates",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, TooManyUpdates.prototype);
        this.Message = opts.Message;
    }
}
class AlreadyExistsException extends SSMServiceException {
    name = "AlreadyExistsException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "AlreadyExistsException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, AlreadyExistsException.prototype);
        this.Message = opts.Message;
    }
}
class OpsItemConflictException extends SSMServiceException {
    name = "OpsItemConflictException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "OpsItemConflictException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, OpsItemConflictException.prototype);
        this.Message = opts.Message;
    }
}
class OpsItemInvalidParameterException extends SSMServiceException {
    name = "OpsItemInvalidParameterException";
    $fault = "client";
    ParameterNames;
    Message;
    constructor(opts) {
        super({
            name: "OpsItemInvalidParameterException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, OpsItemInvalidParameterException.prototype);
        this.ParameterNames = opts.ParameterNames;
        this.Message = opts.Message;
    }
}
class OpsItemLimitExceededException extends SSMServiceException {
    name = "OpsItemLimitExceededException";
    $fault = "client";
    ResourceTypes;
    Limit;
    LimitType;
    Message;
    constructor(opts) {
        super({
            name: "OpsItemLimitExceededException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, OpsItemLimitExceededException.prototype);
        this.ResourceTypes = opts.ResourceTypes;
        this.Limit = opts.Limit;
        this.LimitType = opts.LimitType;
        this.Message = opts.Message;
    }
}
class OpsItemNotFoundException extends SSMServiceException {
    name = "OpsItemNotFoundException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "OpsItemNotFoundException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, OpsItemNotFoundException.prototype);
        this.Message = opts.Message;
    }
}
class OpsItemRelatedItemAlreadyExistsException extends SSMServiceException {
    name = "OpsItemRelatedItemAlreadyExistsException";
    $fault = "client";
    Message;
    ResourceUri;
    OpsItemId;
    constructor(opts) {
        super({
            name: "OpsItemRelatedItemAlreadyExistsException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, OpsItemRelatedItemAlreadyExistsException.prototype);
        this.Message = opts.Message;
        this.ResourceUri = opts.ResourceUri;
        this.OpsItemId = opts.OpsItemId;
    }
}
class DuplicateInstanceId extends SSMServiceException {
    name = "DuplicateInstanceId";
    $fault = "client";
    constructor(opts) {
        super({
            name: "DuplicateInstanceId",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, DuplicateInstanceId.prototype);
    }
}
class InvalidCommandId extends SSMServiceException {
    name = "InvalidCommandId";
    $fault = "client";
    constructor(opts) {
        super({
            name: "InvalidCommandId",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidCommandId.prototype);
    }
}
class InvalidInstanceId extends SSMServiceException {
    name = "InvalidInstanceId";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "InvalidInstanceId",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidInstanceId.prototype);
        this.Message = opts.Message;
    }
}
class DoesNotExistException extends SSMServiceException {
    name = "DoesNotExistException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "DoesNotExistException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, DoesNotExistException.prototype);
        this.Message = opts.Message;
    }
}
class InvalidParameters extends SSMServiceException {
    name = "InvalidParameters";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "InvalidParameters",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidParameters.prototype);
        this.Message = opts.Message;
    }
}
class AssociationAlreadyExists extends SSMServiceException {
    name = "AssociationAlreadyExists";
    $fault = "client";
    constructor(opts) {
        super({
            name: "AssociationAlreadyExists",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, AssociationAlreadyExists.prototype);
    }
}
class AssociationLimitExceeded extends SSMServiceException {
    name = "AssociationLimitExceeded";
    $fault = "client";
    constructor(opts) {
        super({
            name: "AssociationLimitExceeded",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, AssociationLimitExceeded.prototype);
    }
}
class InvalidDocument extends SSMServiceException {
    name = "InvalidDocument";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "InvalidDocument",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidDocument.prototype);
        this.Message = opts.Message;
    }
}
class InvalidDocumentVersion extends SSMServiceException {
    name = "InvalidDocumentVersion";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "InvalidDocumentVersion",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidDocumentVersion.prototype);
        this.Message = opts.Message;
    }
}
class InvalidOutputLocation extends SSMServiceException {
    name = "InvalidOutputLocation";
    $fault = "client";
    constructor(opts) {
        super({
            name: "InvalidOutputLocation",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidOutputLocation.prototype);
    }
}
class InvalidSchedule extends SSMServiceException {
    name = "InvalidSchedule";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "InvalidSchedule",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidSchedule.prototype);
        this.Message = opts.Message;
    }
}
class InvalidTag extends SSMServiceException {
    name = "InvalidTag";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "InvalidTag",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidTag.prototype);
        this.Message = opts.Message;
    }
}
class InvalidTarget extends SSMServiceException {
    name = "InvalidTarget";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "InvalidTarget",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidTarget.prototype);
        this.Message = opts.Message;
    }
}
class InvalidTargetMaps extends SSMServiceException {
    name = "InvalidTargetMaps";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "InvalidTargetMaps",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidTargetMaps.prototype);
        this.Message = opts.Message;
    }
}
class UnsupportedPlatformType extends SSMServiceException {
    name = "UnsupportedPlatformType";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "UnsupportedPlatformType",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, UnsupportedPlatformType.prototype);
        this.Message = opts.Message;
    }
}
class ConflictException extends SSMServiceException {
    name = "ConflictException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "ConflictException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ConflictException.prototype);
        this.Message = opts.Message;
    }
}
class ServiceQuotaExceededException extends SSMServiceException {
    name = "ServiceQuotaExceededException";
    $fault = "client";
    Message;
    ResourceId;
    ResourceType;
    QuotaCode;
    ServiceCode;
    constructor(opts) {
        super({
            name: "ServiceQuotaExceededException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ServiceQuotaExceededException.prototype);
        this.Message = opts.Message;
        this.ResourceId = opts.ResourceId;
        this.ResourceType = opts.ResourceType;
        this.QuotaCode = opts.QuotaCode;
        this.ServiceCode = opts.ServiceCode;
    }
}
class DocumentAlreadyExists extends SSMServiceException {
    name = "DocumentAlreadyExists";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "DocumentAlreadyExists",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, DocumentAlreadyExists.prototype);
        this.Message = opts.Message;
    }
}
class DocumentLimitExceeded extends SSMServiceException {
    name = "DocumentLimitExceeded";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "DocumentLimitExceeded",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, DocumentLimitExceeded.prototype);
        this.Message = opts.Message;
    }
}
class InvalidDocumentContent extends SSMServiceException {
    name = "InvalidDocumentContent";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "InvalidDocumentContent",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidDocumentContent.prototype);
        this.Message = opts.Message;
    }
}
class InvalidDocumentSchemaVersion extends SSMServiceException {
    name = "InvalidDocumentSchemaVersion";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "InvalidDocumentSchemaVersion",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidDocumentSchemaVersion.prototype);
        this.Message = opts.Message;
    }
}
class MaxDocumentSizeExceeded extends SSMServiceException {
    name = "MaxDocumentSizeExceeded";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "MaxDocumentSizeExceeded",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, MaxDocumentSizeExceeded.prototype);
        this.Message = opts.Message;
    }
}
class NoLongerSupportedException extends SSMServiceException {
    name = "NoLongerSupportedException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "NoLongerSupportedException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, NoLongerSupportedException.prototype);
        this.Message = opts.Message;
    }
}
class IdempotentParameterMismatch extends SSMServiceException {
    name = "IdempotentParameterMismatch";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "IdempotentParameterMismatch",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, IdempotentParameterMismatch.prototype);
        this.Message = opts.Message;
    }
}
class ResourceLimitExceededException extends SSMServiceException {
    name = "ResourceLimitExceededException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "ResourceLimitExceededException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ResourceLimitExceededException.prototype);
        this.Message = opts.Message;
    }
}
class OpsItemAccessDeniedException extends SSMServiceException {
    name = "OpsItemAccessDeniedException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "OpsItemAccessDeniedException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, OpsItemAccessDeniedException.prototype);
        this.Message = opts.Message;
    }
}
class OpsItemAlreadyExistsException extends SSMServiceException {
    name = "OpsItemAlreadyExistsException";
    $fault = "client";
    Message;
    OpsItemId;
    constructor(opts) {
        super({
            name: "OpsItemAlreadyExistsException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, OpsItemAlreadyExistsException.prototype);
        this.Message = opts.Message;
        this.OpsItemId = opts.OpsItemId;
    }
}
class OpsMetadataAlreadyExistsException extends SSMServiceException {
    name = "OpsMetadataAlreadyExistsException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "OpsMetadataAlreadyExistsException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, OpsMetadataAlreadyExistsException.prototype);
    }
}
class OpsMetadataInvalidArgumentException extends SSMServiceException {
    name = "OpsMetadataInvalidArgumentException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "OpsMetadataInvalidArgumentException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, OpsMetadataInvalidArgumentException.prototype);
    }
}
class OpsMetadataLimitExceededException extends SSMServiceException {
    name = "OpsMetadataLimitExceededException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "OpsMetadataLimitExceededException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, OpsMetadataLimitExceededException.prototype);
    }
}
class OpsMetadataTooManyUpdatesException extends SSMServiceException {
    name = "OpsMetadataTooManyUpdatesException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "OpsMetadataTooManyUpdatesException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, OpsMetadataTooManyUpdatesException.prototype);
    }
}
class ResourceDataSyncAlreadyExistsException extends SSMServiceException {
    name = "ResourceDataSyncAlreadyExistsException";
    $fault = "client";
    SyncName;
    constructor(opts) {
        super({
            name: "ResourceDataSyncAlreadyExistsException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ResourceDataSyncAlreadyExistsException.prototype);
        this.SyncName = opts.SyncName;
    }
}
class ResourceDataSyncCountExceededException extends SSMServiceException {
    name = "ResourceDataSyncCountExceededException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "ResourceDataSyncCountExceededException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ResourceDataSyncCountExceededException.prototype);
        this.Message = opts.Message;
    }
}
class ResourceDataSyncInvalidConfigurationException extends SSMServiceException {
    name = "ResourceDataSyncInvalidConfigurationException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "ResourceDataSyncInvalidConfigurationException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ResourceDataSyncInvalidConfigurationException.prototype);
        this.Message = opts.Message;
    }
}
class InvalidActivation extends SSMServiceException {
    name = "InvalidActivation";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "InvalidActivation",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidActivation.prototype);
        this.Message = opts.Message;
    }
}
class InvalidActivationId extends SSMServiceException {
    name = "InvalidActivationId";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "InvalidActivationId",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidActivationId.prototype);
        this.Message = opts.Message;
    }
}
class AssociationDoesNotExist extends SSMServiceException {
    name = "AssociationDoesNotExist";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "AssociationDoesNotExist",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, AssociationDoesNotExist.prototype);
        this.Message = opts.Message;
    }
}
class ResourceNotFoundException extends SSMServiceException {
    name = "ResourceNotFoundException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "ResourceNotFoundException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ResourceNotFoundException.prototype);
        this.Message = opts.Message;
    }
}
class AssociatedInstances extends SSMServiceException {
    name = "AssociatedInstances";
    $fault = "client";
    constructor(opts) {
        super({
            name: "AssociatedInstances",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, AssociatedInstances.prototype);
    }
}
class InvalidDocumentOperation extends SSMServiceException {
    name = "InvalidDocumentOperation";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "InvalidDocumentOperation",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidDocumentOperation.prototype);
        this.Message = opts.Message;
    }
}
class InvalidDeleteInventoryParametersException extends SSMServiceException {
    name = "InvalidDeleteInventoryParametersException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "InvalidDeleteInventoryParametersException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidDeleteInventoryParametersException.prototype);
        this.Message = opts.Message;
    }
}
class InvalidInventoryRequestException extends SSMServiceException {
    name = "InvalidInventoryRequestException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "InvalidInventoryRequestException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidInventoryRequestException.prototype);
        this.Message = opts.Message;
    }
}
class InvalidOptionException extends SSMServiceException {
    name = "InvalidOptionException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "InvalidOptionException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidOptionException.prototype);
        this.Message = opts.Message;
    }
}
class InvalidTypeNameException extends SSMServiceException {
    name = "InvalidTypeNameException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "InvalidTypeNameException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidTypeNameException.prototype);
        this.Message = opts.Message;
    }
}
class OpsMetadataNotFoundException extends SSMServiceException {
    name = "OpsMetadataNotFoundException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "OpsMetadataNotFoundException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, OpsMetadataNotFoundException.prototype);
    }
}
class ParameterNotFound extends SSMServiceException {
    name = "ParameterNotFound";
    $fault = "client";
    constructor(opts) {
        super({
            name: "ParameterNotFound",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ParameterNotFound.prototype);
    }
}
class ResourceInUseException extends SSMServiceException {
    name = "ResourceInUseException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "ResourceInUseException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ResourceInUseException.prototype);
        this.Message = opts.Message;
    }
}
class ResourceDataSyncNotFoundException extends SSMServiceException {
    name = "ResourceDataSyncNotFoundException";
    $fault = "client";
    SyncName;
    SyncType;
    Message;
    constructor(opts) {
        super({
            name: "ResourceDataSyncNotFoundException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ResourceDataSyncNotFoundException.prototype);
        this.SyncName = opts.SyncName;
        this.SyncType = opts.SyncType;
        this.Message = opts.Message;
    }
}
class MalformedResourcePolicyDocumentException extends SSMServiceException {
    name = "MalformedResourcePolicyDocumentException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "MalformedResourcePolicyDocumentException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, MalformedResourcePolicyDocumentException.prototype);
        this.Message = opts.Message;
    }
}
class ResourcePolicyConflictException extends SSMServiceException {
    name = "ResourcePolicyConflictException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "ResourcePolicyConflictException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ResourcePolicyConflictException.prototype);
        this.Message = opts.Message;
    }
}
class ResourcePolicyInvalidParameterException extends SSMServiceException {
    name = "ResourcePolicyInvalidParameterException";
    $fault = "client";
    ParameterNames;
    Message;
    constructor(opts) {
        super({
            name: "ResourcePolicyInvalidParameterException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ResourcePolicyInvalidParameterException.prototype);
        this.ParameterNames = opts.ParameterNames;
        this.Message = opts.Message;
    }
}
class ResourcePolicyNotFoundException extends SSMServiceException {
    name = "ResourcePolicyNotFoundException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "ResourcePolicyNotFoundException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ResourcePolicyNotFoundException.prototype);
        this.Message = opts.Message;
    }
}
class TargetInUseException extends SSMServiceException {
    name = "TargetInUseException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "TargetInUseException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, TargetInUseException.prototype);
        this.Message = opts.Message;
    }
}
class InvalidFilter extends SSMServiceException {
    name = "InvalidFilter";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "InvalidFilter",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidFilter.prototype);
        this.Message = opts.Message;
    }
}
class InvalidNextToken extends SSMServiceException {
    name = "InvalidNextToken";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "InvalidNextToken",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidNextToken.prototype);
        this.Message = opts.Message;
    }
}
class InvalidAssociationVersion extends SSMServiceException {
    name = "InvalidAssociationVersion";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "InvalidAssociationVersion",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidAssociationVersion.prototype);
        this.Message = opts.Message;
    }
}
class AssociationExecutionDoesNotExist extends SSMServiceException {
    name = "AssociationExecutionDoesNotExist";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "AssociationExecutionDoesNotExist",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, AssociationExecutionDoesNotExist.prototype);
        this.Message = opts.Message;
    }
}
class InvalidFilterKey extends SSMServiceException {
    name = "InvalidFilterKey";
    $fault = "client";
    constructor(opts) {
        super({
            name: "InvalidFilterKey",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidFilterKey.prototype);
    }
}
class InvalidFilterValue extends SSMServiceException {
    name = "InvalidFilterValue";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "InvalidFilterValue",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidFilterValue.prototype);
        this.Message = opts.Message;
    }
}
class AutomationExecutionNotFoundException extends SSMServiceException {
    name = "AutomationExecutionNotFoundException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "AutomationExecutionNotFoundException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, AutomationExecutionNotFoundException.prototype);
        this.Message = opts.Message;
    }
}
class InvalidPermissionType extends SSMServiceException {
    name = "InvalidPermissionType";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "InvalidPermissionType",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidPermissionType.prototype);
        this.Message = opts.Message;
    }
}
class UnsupportedOperatingSystem extends SSMServiceException {
    name = "UnsupportedOperatingSystem";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "UnsupportedOperatingSystem",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, UnsupportedOperatingSystem.prototype);
        this.Message = opts.Message;
    }
}
class InvalidInstanceInformationFilterValue extends SSMServiceException {
    name = "InvalidInstanceInformationFilterValue";
    $fault = "client";
    constructor(opts) {
        super({
            name: "InvalidInstanceInformationFilterValue",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidInstanceInformationFilterValue.prototype);
    }
}
class InvalidInstancePropertyFilterValue extends SSMServiceException {
    name = "InvalidInstancePropertyFilterValue";
    $fault = "client";
    constructor(opts) {
        super({
            name: "InvalidInstancePropertyFilterValue",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidInstancePropertyFilterValue.prototype);
    }
}
class InvalidDeletionIdException extends SSMServiceException {
    name = "InvalidDeletionIdException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "InvalidDeletionIdException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidDeletionIdException.prototype);
        this.Message = opts.Message;
    }
}
class InvalidFilterOption extends SSMServiceException {
    name = "InvalidFilterOption";
    $fault = "client";
    constructor(opts) {
        super({
            name: "InvalidFilterOption",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidFilterOption.prototype);
    }
}
class OpsItemRelatedItemAssociationNotFoundException extends SSMServiceException {
    name = "OpsItemRelatedItemAssociationNotFoundException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "OpsItemRelatedItemAssociationNotFoundException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, OpsItemRelatedItemAssociationNotFoundException.prototype);
        this.Message = opts.Message;
    }
}
class ThrottlingException extends SSMServiceException {
    name = "ThrottlingException";
    $fault = "client";
    Message;
    QuotaCode;
    ServiceCode;
    constructor(opts) {
        super({
            name: "ThrottlingException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ThrottlingException.prototype);
        this.Message = opts.Message;
        this.QuotaCode = opts.QuotaCode;
        this.ServiceCode = opts.ServiceCode;
    }
}
class ValidationException extends SSMServiceException {
    name = "ValidationException";
    $fault = "client";
    Message;
    ReasonCode;
    constructor(opts) {
        super({
            name: "ValidationException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ValidationException.prototype);
        this.Message = opts.Message;
        this.ReasonCode = opts.ReasonCode;
    }
}
class InvalidDocumentType extends SSMServiceException {
    name = "InvalidDocumentType";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "InvalidDocumentType",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidDocumentType.prototype);
        this.Message = opts.Message;
    }
}
class UnsupportedCalendarException extends SSMServiceException {
    name = "UnsupportedCalendarException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "UnsupportedCalendarException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, UnsupportedCalendarException.prototype);
        this.Message = opts.Message;
    }
}
class InvalidPluginName extends SSMServiceException {
    name = "InvalidPluginName";
    $fault = "client";
    constructor(opts) {
        super({
            name: "InvalidPluginName",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidPluginName.prototype);
    }
}
class InvocationDoesNotExist extends SSMServiceException {
    name = "InvocationDoesNotExist";
    $fault = "client";
    constructor(opts) {
        super({
            name: "InvocationDoesNotExist",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvocationDoesNotExist.prototype);
    }
}
class UnsupportedFeatureRequiredException extends SSMServiceException {
    name = "UnsupportedFeatureRequiredException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "UnsupportedFeatureRequiredException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, UnsupportedFeatureRequiredException.prototype);
        this.Message = opts.Message;
    }
}
class InvalidAggregatorException extends SSMServiceException {
    name = "InvalidAggregatorException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "InvalidAggregatorException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidAggregatorException.prototype);
        this.Message = opts.Message;
    }
}
class InvalidInventoryGroupException extends SSMServiceException {
    name = "InvalidInventoryGroupException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "InvalidInventoryGroupException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidInventoryGroupException.prototype);
        this.Message = opts.Message;
    }
}
class InvalidResultAttributeException extends SSMServiceException {
    name = "InvalidResultAttributeException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "InvalidResultAttributeException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidResultAttributeException.prototype);
        this.Message = opts.Message;
    }
}
class InvalidKeyId extends SSMServiceException {
    name = "InvalidKeyId";
    $fault = "client";
    constructor(opts) {
        super({
            name: "InvalidKeyId",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidKeyId.prototype);
    }
}
class ParameterVersionNotFound extends SSMServiceException {
    name = "ParameterVersionNotFound";
    $fault = "client";
    constructor(opts) {
        super({
            name: "ParameterVersionNotFound",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ParameterVersionNotFound.prototype);
    }
}
class ServiceSettingNotFound extends SSMServiceException {
    name = "ServiceSettingNotFound";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "ServiceSettingNotFound",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ServiceSettingNotFound.prototype);
        this.Message = opts.Message;
    }
}
class ParameterVersionLabelLimitExceeded extends SSMServiceException {
    name = "ParameterVersionLabelLimitExceeded";
    $fault = "client";
    constructor(opts) {
        super({
            name: "ParameterVersionLabelLimitExceeded",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ParameterVersionLabelLimitExceeded.prototype);
    }
}
class UnsupportedOperationException extends SSMServiceException {
    name = "UnsupportedOperationException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "UnsupportedOperationException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, UnsupportedOperationException.prototype);
        this.Message = opts.Message;
    }
}
class DocumentPermissionLimit extends SSMServiceException {
    name = "DocumentPermissionLimit";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "DocumentPermissionLimit",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, DocumentPermissionLimit.prototype);
        this.Message = opts.Message;
    }
}
class ComplianceTypeCountLimitExceededException extends SSMServiceException {
    name = "ComplianceTypeCountLimitExceededException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "ComplianceTypeCountLimitExceededException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ComplianceTypeCountLimitExceededException.prototype);
        this.Message = opts.Message;
    }
}
class InvalidItemContentException extends SSMServiceException {
    name = "InvalidItemContentException";
    $fault = "client";
    TypeName;
    Message;
    constructor(opts) {
        super({
            name: "InvalidItemContentException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidItemContentException.prototype);
        this.TypeName = opts.TypeName;
        this.Message = opts.Message;
    }
}
class ItemSizeLimitExceededException extends SSMServiceException {
    name = "ItemSizeLimitExceededException";
    $fault = "client";
    TypeName;
    Message;
    constructor(opts) {
        super({
            name: "ItemSizeLimitExceededException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ItemSizeLimitExceededException.prototype);
        this.TypeName = opts.TypeName;
        this.Message = opts.Message;
    }
}
class TotalSizeLimitExceededException extends SSMServiceException {
    name = "TotalSizeLimitExceededException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "TotalSizeLimitExceededException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, TotalSizeLimitExceededException.prototype);
        this.Message = opts.Message;
    }
}
class CustomSchemaCountLimitExceededException extends SSMServiceException {
    name = "CustomSchemaCountLimitExceededException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "CustomSchemaCountLimitExceededException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, CustomSchemaCountLimitExceededException.prototype);
        this.Message = opts.Message;
    }
}
class InvalidInventoryItemContextException extends SSMServiceException {
    name = "InvalidInventoryItemContextException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "InvalidInventoryItemContextException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidInventoryItemContextException.prototype);
        this.Message = opts.Message;
    }
}
class ItemContentMismatchException extends SSMServiceException {
    name = "ItemContentMismatchException";
    $fault = "client";
    TypeName;
    Message;
    constructor(opts) {
        super({
            name: "ItemContentMismatchException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ItemContentMismatchException.prototype);
        this.TypeName = opts.TypeName;
        this.Message = opts.Message;
    }
}
class SubTypeCountLimitExceededException extends SSMServiceException {
    name = "SubTypeCountLimitExceededException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "SubTypeCountLimitExceededException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, SubTypeCountLimitExceededException.prototype);
        this.Message = opts.Message;
    }
}
class UnsupportedInventoryItemContextException extends SSMServiceException {
    name = "UnsupportedInventoryItemContextException";
    $fault = "client";
    TypeName;
    Message;
    constructor(opts) {
        super({
            name: "UnsupportedInventoryItemContextException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, UnsupportedInventoryItemContextException.prototype);
        this.TypeName = opts.TypeName;
        this.Message = opts.Message;
    }
}
class UnsupportedInventorySchemaVersionException extends SSMServiceException {
    name = "UnsupportedInventorySchemaVersionException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "UnsupportedInventorySchemaVersionException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, UnsupportedInventorySchemaVersionException.prototype);
        this.Message = opts.Message;
    }
}
class HierarchyLevelLimitExceededException extends SSMServiceException {
    name = "HierarchyLevelLimitExceededException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "HierarchyLevelLimitExceededException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, HierarchyLevelLimitExceededException.prototype);
    }
}
class HierarchyTypeMismatchException extends SSMServiceException {
    name = "HierarchyTypeMismatchException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "HierarchyTypeMismatchException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, HierarchyTypeMismatchException.prototype);
    }
}
class IncompatiblePolicyException extends SSMServiceException {
    name = "IncompatiblePolicyException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "IncompatiblePolicyException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, IncompatiblePolicyException.prototype);
    }
}
class InvalidAllowedPatternException extends SSMServiceException {
    name = "InvalidAllowedPatternException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "InvalidAllowedPatternException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidAllowedPatternException.prototype);
    }
}
class InvalidPolicyAttributeException extends SSMServiceException {
    name = "InvalidPolicyAttributeException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "InvalidPolicyAttributeException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidPolicyAttributeException.prototype);
    }
}
class InvalidPolicyTypeException extends SSMServiceException {
    name = "InvalidPolicyTypeException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "InvalidPolicyTypeException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidPolicyTypeException.prototype);
    }
}
class ParameterAlreadyExists extends SSMServiceException {
    name = "ParameterAlreadyExists";
    $fault = "client";
    constructor(opts) {
        super({
            name: "ParameterAlreadyExists",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ParameterAlreadyExists.prototype);
    }
}
class ParameterLimitExceeded extends SSMServiceException {
    name = "ParameterLimitExceeded";
    $fault = "client";
    constructor(opts) {
        super({
            name: "ParameterLimitExceeded",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ParameterLimitExceeded.prototype);
    }
}
class ParameterMaxVersionLimitExceeded extends SSMServiceException {
    name = "ParameterMaxVersionLimitExceeded";
    $fault = "client";
    constructor(opts) {
        super({
            name: "ParameterMaxVersionLimitExceeded",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ParameterMaxVersionLimitExceeded.prototype);
    }
}
class ParameterPatternMismatchException extends SSMServiceException {
    name = "ParameterPatternMismatchException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "ParameterPatternMismatchException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ParameterPatternMismatchException.prototype);
    }
}
class PoliciesLimitExceededException extends SSMServiceException {
    name = "PoliciesLimitExceededException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "PoliciesLimitExceededException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, PoliciesLimitExceededException.prototype);
    }
}
class UnsupportedParameterType extends SSMServiceException {
    name = "UnsupportedParameterType";
    $fault = "client";
    constructor(opts) {
        super({
            name: "UnsupportedParameterType",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, UnsupportedParameterType.prototype);
    }
}
class ResourcePolicyLimitExceededException extends SSMServiceException {
    name = "ResourcePolicyLimitExceededException";
    $fault = "client";
    Limit;
    LimitType;
    Message;
    constructor(opts) {
        super({
            name: "ResourcePolicyLimitExceededException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ResourcePolicyLimitExceededException.prototype);
        this.Limit = opts.Limit;
        this.LimitType = opts.LimitType;
        this.Message = opts.Message;
    }
}
class FeatureNotAvailableException extends SSMServiceException {
    name = "FeatureNotAvailableException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "FeatureNotAvailableException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, FeatureNotAvailableException.prototype);
        this.Message = opts.Message;
    }
}
class AutomationStepNotFoundException extends SSMServiceException {
    name = "AutomationStepNotFoundException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "AutomationStepNotFoundException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, AutomationStepNotFoundException.prototype);
        this.Message = opts.Message;
    }
}
class InvalidAutomationSignalException extends SSMServiceException {
    name = "InvalidAutomationSignalException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "InvalidAutomationSignalException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidAutomationSignalException.prototype);
        this.Message = opts.Message;
    }
}
class InvalidNotificationConfig extends SSMServiceException {
    name = "InvalidNotificationConfig";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "InvalidNotificationConfig",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidNotificationConfig.prototype);
        this.Message = opts.Message;
    }
}
class InvalidOutputFolder extends SSMServiceException {
    name = "InvalidOutputFolder";
    $fault = "client";
    constructor(opts) {
        super({
            name: "InvalidOutputFolder",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidOutputFolder.prototype);
    }
}
class InvalidRole extends SSMServiceException {
    name = "InvalidRole";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "InvalidRole",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidRole.prototype);
        this.Message = opts.Message;
    }
}
class InvalidAssociation extends SSMServiceException {
    name = "InvalidAssociation";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "InvalidAssociation",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidAssociation.prototype);
        this.Message = opts.Message;
    }
}
class AutomationDefinitionNotFoundException extends SSMServiceException {
    name = "AutomationDefinitionNotFoundException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "AutomationDefinitionNotFoundException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, AutomationDefinitionNotFoundException.prototype);
        this.Message = opts.Message;
    }
}
class AutomationDefinitionVersionNotFoundException extends SSMServiceException {
    name = "AutomationDefinitionVersionNotFoundException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "AutomationDefinitionVersionNotFoundException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, AutomationDefinitionVersionNotFoundException.prototype);
        this.Message = opts.Message;
    }
}
class AutomationExecutionLimitExceededException extends SSMServiceException {
    name = "AutomationExecutionLimitExceededException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "AutomationExecutionLimitExceededException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, AutomationExecutionLimitExceededException.prototype);
        this.Message = opts.Message;
    }
}
class InvalidAutomationExecutionParametersException extends SSMServiceException {
    name = "InvalidAutomationExecutionParametersException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "InvalidAutomationExecutionParametersException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidAutomationExecutionParametersException.prototype);
        this.Message = opts.Message;
    }
}
class AutomationDefinitionNotApprovedException extends SSMServiceException {
    name = "AutomationDefinitionNotApprovedException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "AutomationDefinitionNotApprovedException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, AutomationDefinitionNotApprovedException.prototype);
        this.Message = opts.Message;
    }
}
class TargetNotConnected extends SSMServiceException {
    name = "TargetNotConnected";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "TargetNotConnected",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, TargetNotConnected.prototype);
        this.Message = opts.Message;
    }
}
class InvalidAutomationStatusUpdateException extends SSMServiceException {
    name = "InvalidAutomationStatusUpdateException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "InvalidAutomationStatusUpdateException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidAutomationStatusUpdateException.prototype);
        this.Message = opts.Message;
    }
}
class AssociationVersionLimitExceeded extends SSMServiceException {
    name = "AssociationVersionLimitExceeded";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "AssociationVersionLimitExceeded",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, AssociationVersionLimitExceeded.prototype);
        this.Message = opts.Message;
    }
}
class InvalidUpdate extends SSMServiceException {
    name = "InvalidUpdate";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "InvalidUpdate",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidUpdate.prototype);
        this.Message = opts.Message;
    }
}
class StatusUnchanged extends SSMServiceException {
    name = "StatusUnchanged";
    $fault = "client";
    constructor(opts) {
        super({
            name: "StatusUnchanged",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, StatusUnchanged.prototype);
    }
}
class DocumentVersionLimitExceeded extends SSMServiceException {
    name = "DocumentVersionLimitExceeded";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "DocumentVersionLimitExceeded",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, DocumentVersionLimitExceeded.prototype);
        this.Message = opts.Message;
    }
}
class DuplicateDocumentContent extends SSMServiceException {
    name = "DuplicateDocumentContent";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "DuplicateDocumentContent",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, DuplicateDocumentContent.prototype);
        this.Message = opts.Message;
    }
}
class DuplicateDocumentVersionName extends SSMServiceException {
    name = "DuplicateDocumentVersionName";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "DuplicateDocumentVersionName",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, DuplicateDocumentVersionName.prototype);
        this.Message = opts.Message;
    }
}
class OpsMetadataKeyLimitExceededException extends SSMServiceException {
    name = "OpsMetadataKeyLimitExceededException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "OpsMetadataKeyLimitExceededException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, OpsMetadataKeyLimitExceededException.prototype);
    }
}
class ResourceDataSyncConflictException extends SSMServiceException {
    name = "ResourceDataSyncConflictException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "ResourceDataSyncConflictException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ResourceDataSyncConflictException.prototype);
        this.Message = opts.Message;
    }
}

const _A = "Activation";
const _AA = "AutoApprove";
const _AAD = "ApproveAfterDays";
const _AAE = "AssociationAlreadyExists";
const _AC = "AlarmConfiguration";
const _ACL = "AttachmentContentList";
const _ACc = "ActivationCode";
const _ACt = "AttachmentContent";
const _ACtt = "AttachmentsContent";
const _ACz = "AzureConfiguration";
const _AD = "AssociationDescription";
const _ADAR = "AssociationDispatchAssumeRole";
const _ADE = "AccessDeniedException";
const _ADL = "AssociationDescriptionList";
const _ADN = "ApplicationDisplayName";
const _ADNAE = "AutomationDefinitionNotApprovedException";
const _ADNE = "AssociationDoesNotExist";
const _ADNFE = "AutomationDefinitionNotFoundException";
const _ADVNFE = "AutomationDefinitionVersionNotFoundException";
const _ADp = "ApprovalDate";
const _AE = "AssociationExecution";
const _AEDNE = "AssociationExecutionDoesNotExist";
const _AEE = "AlreadyExistsException";
const _AEF = "AssociationExecutionFilter";
const _AEFL = "AssociationExecutionFilterList";
const _AEFLu = "AutomationExecutionFilterList";
const _AEFu = "AutomationExecutionFilter";
const _AEI = "AutomationExecutionId";
const _AEIu = "AutomationExecutionInputs";
const _AEL = "AssociationExecutionsList";
const _AELEE = "AutomationExecutionLimitExceededException";
const _AEM = "AutomationExecutionMetadata";
const _AEML = "AutomationExecutionMetadataList";
const _AENFE = "AutomationExecutionNotFoundException";
const _AEP = "AutomationExecutionPreview";
const _AES = "AutomationExecutionStatus";
const _AET = "AssociationExecutionTarget";
const _AETF = "AssociationExecutionTargetsFilter";
const _AETFL = "AssociationExecutionTargetsFilterList";
const _AETL = "AssociationExecutionTargetsList";
const _AETc = "ActualEndTime";
const _AETs = "AssociationExecutionTargets";
const _AEs = "AssociationExecutions";
const _AEu = "AutomationExecution";
const _AF = "AssociationFilter";
const _AFL = "AssociationFilterList";
const _AI = "AssociatedInstances";
const _AIL = "AccountIdList";
const _AILt = "AttachmentInformationList";
const _AITA = "AccountIdsToAdd";
const _AITR = "AccountIdsToRemove";
const _AIc = "AccountId";
const _AIcc = "AccountIds";
const _AIct = "ActivationId";
const _AId = "AdditionalInfo";
const _AIdv = "AdvisoryIds";
const _AIp = "ApplicationId";
const _AIs = "AssociationId";
const _AIss = "AssociationIds";
const _AIt = "AttachmentInformation";
const _AItt = "AttachmentsInformation";
const _AKI = "AccessKeyId";
const _AKST = "AccessKeySecretType";
const _AL = "ActivationList";
const _ALE = "AssociationLimitExceeded";
const _ALl = "AlarmList";
const _ALs = "AssociationList";
const _AN = "AssociationName";
const _ANt = "AttributeName";
const _AO = "AssociationOverview";
const _AOACI = "ApplyOnlyAtCronInterval";
const _AOIRI = "AssociateOpsItemRelatedItem";
const _AOIRIR = "AssociateOpsItemRelatedItemRequest";
const _AOIRIRs = "AssociateOpsItemRelatedItemResponse";
const _AOS = "AwsOrganizationsSource";
const _AP = "ApprovedPatches";
const _APCL = "ApprovedPatchesComplianceLevel";
const _APENS = "ApprovedPatchesEnableNonSecurity";
const _APM = "AutomationParameterMap";
const _APl = "AllowedPattern";
const _AR = "ApprovalRules";
const _ARI = "AccessRequestId";
const _ARN = "ARN";
const _ARS = "AccessRequestStatus";
const _AS = "AssociationStatus";
const _ASAC = "AssociationStatusAggregatedCount";
const _ASI = "AccountSharingInfo";
const _ASIL = "AccountSharingInfoList";
const _ASILl = "AlarmStateInformationList";
const _ASIl = "AlarmStateInformation";
const _ASL = "AttachmentsSourceList";
const _ASLz = "AzureSubscriptionList";
const _ASNFE = "AutomationStepNotFoundException";
const _AST = "ActualStartTime";
const _ASUC = "AvailableSecurityUpdateCount";
const _ASUCS = "AvailableSecurityUpdatesComplianceStatus";
const _ASt = "AttachmentsSource";
const _ASu = "AutomationSubtype";
const _ASz = "AzureSubscription";
const _AT = "AssociationType";
const _ATPN = "AutomationTargetParameterName";
const _ATTR = "AddTagsToResource";
const _ATTRR = "AddTagsToResourceRequest";
const _ATTRRd = "AddTagsToResourceResult";
const _ATc = "AccessType";
const _ATg = "AgentType";
const _ATgg = "AggregatorType";
const _ATt = "AtTime";
const _ATu = "AutomationType";
const _ATut = "AutomationTargets";
const _AUD = "ApproveUntilDate";
const _AUT = "AllowUnassociatedTargets";
const _AV = "AssociationVersion";
const _AVI = "AssociationVersionInfo";
const _AVL = "AssociationVersionList";
const _AVLE = "AssociationVersionLimitExceeded";
const _AVg = "AgentVersion";
const _AVp = "ApprovedVersion";
const _AVs = "AssociationVersions";
const _AWSKMSKARN = "AWSKMSKeyARN";
const _AZ = "AvailabilityZone";
const _AZI = "AvailabilityZoneId";
const _Ac = "Action";
const _Acc = "Accounts";
const _Ag = "Aggregators";
const _Agg = "Aggregator";
const _Al = "Alarm";
const _Ala = "Alarms";
const _Ar = "Architecture";
const _Arc = "Arch";
const _Arn = "Arn";
const _As = "Association";
const _Ass = "Associations";
const _At = "Attachments";
const _Att = "Attributes";
const _Attr = "Attribute";
const _Au = "Author";
const _Aut = "Automation";
const _BD = "BaselineDescription";
const _BI = "BaselineId";
const _BIa = "BaselineIdentities";
const _BIas = "BaselineIdentity";
const _BIu = "BugzillaIds";
const _BN = "BaselineName";
const _BNu = "BucketName";
const _BO = "BaselineOverride";
const _C = "Command";
const _CA = "CurrentAction";
const _CAB = "CreateAssociationBatch";
const _CABR = "CreateAssociationBatchRequest";
const _CABRE = "CreateAssociationBatchRequestEntry";
const _CABREr = "CreateAssociationBatchRequestEntries";
const _CABRr = "CreateAssociationBatchResult";
const _CAR = "CreateActivationRequest";
const _CARr = "CreateActivationResult";
const _CARre = "CreateAssociationRequest";
const _CARrea = "CreateAssociationResult";
const _CAr = "CreatedAt";
const _CAre = "CreateActivation";
const _CArea = "CreateAssociation";
const _CB = "CutoffBehavior";
const _CBr = "CreatedBy";
const _CC = "CompletedCount";
const _CCA = "ConfigConnectorArn";
const _CCAl = "CloudConnectorArn";
const _CCC = "CloudConnectorConfiguration";
const _CCCR = "CreateCloudConnectorRequest";
const _CCCRr = "CreateCloudConnectorResult";
const _CCCr = "CreateCloudConnector";
const _CCF = "CloudConnectorFilter";
const _CCFL = "CloudConnectorFilterList";
const _CCI = "CloudConnectorId";
const _CCR = "CancelCommandRequest";
const _CCRa = "CancelCommandResult";
const _CCS = "CloudConnectorSummary";
const _CCSL = "CloudConnectorSummaryList";
const _CCa = "CancelCommand";
const _CCl = "CloudConnectors";
const _CCli = "ClientContext";
const _CCo = "CompliantCount";
const _CCr = "CriticalCount";
const _CD = "CreatedDate";
const _CDR = "CreateDocumentRequest";
const _CDRr = "CreateDocumentResult";
const _CDh = "ChangeDetails";
const _CDr = "CreationDate";
const _CDre = "CreateDocument";
const _CE = "ConflictException";
const _CES = "ComplianceExecutionSummary";
const _CEa = "CategoryEnum";
const _CF = "CommandFilter";
const _CFL = "CommandFilterList";
const _CFo = "ComplianceFilter";
const _CH = "ContentHash";
const _CI = "CommandId";
const _CIE = "ComplianceItemEntry";
const _CIEL = "ComplianceItemEntryList";
const _CIL = "CommandInvocationList";
const _CILo = "ComplianceItemList";
const _CIo = "CommandInvocation";
const _CIom = "ComplianceItem";
const _CIomm = "CommandInvocations";
const _CIomp = "ComplianceItems";
const _CL = "ComplianceLevel";
const _CLo = "CommandList";
const _CMW = "CreateMaintenanceWindow";
const _CMWE = "CancelMaintenanceWindowExecution";
const _CMWER = "CancelMaintenanceWindowExecutionRequest";
const _CMWERa = "CancelMaintenanceWindowExecutionResult";
const _CMWR = "CreateMaintenanceWindowRequest";
const _CMWRr = "CreateMaintenanceWindowResult";
const _CN = "CalendarNames";
const _CNCC = "CriticalNonCompliantCount";
const _CNo = "ComputerName";
const _COI = "CreateOpsItem";
const _COIR = "CreateOpsItemRequest";
const _COIRr = "CreateOpsItemResponse";
const _COM = "CreateOpsMetadata";
const _COMR = "CreateOpsMetadataRequest";
const _COMRr = "CreateOpsMetadataResult";
const _CP = "CommandPlugins";
const _CPB = "CreatePatchBaseline";
const _CPBR = "CreatePatchBaselineRequest";
const _CPBRr = "CreatePatchBaselineResult";
const _CPL = "CommandPluginList";
const _CPo = "CommandPlugin";
const _CRDS = "CreateResourceDataSync";
const _CRDSR = "CreateResourceDataSyncRequest";
const _CRDSRr = "CreateResourceDataSyncResult";
const _CRN = "ChangeRequestName";
const _CS = "ComplianceSeverity";
const _CSCLEE = "CustomSchemaCountLimitExceededException";
const _CSF = "ComplianceStringFilter";
const _CSFL = "ComplianceStringFilterList";
const _CSFVL = "ComplianceStringFilterValueList";
const _CSI = "ComplianceSummaryItem";
const _CSIL = "ComplianceSummaryItemList";
const _CSIo = "ComplianceSummaryItems";
const _CSN = "CurrentStepName";
const _CSa = "CancelledSteps";
const _CSo = "CompliantSummary";
const _CT = "CreatedTime";
const _CTCLEE = "ComplianceTypeCountLimitExceededException";
const _CTa = "CaptureTime";
const _CTl = "ClientToken";
const _CTo = "ComplianceType";
const _CTon = "ConfigurationTargets";
const _CTr = "CreateTime";
const _CU = "ContentUrl";
const _CVEI = "CVEIds";
const _CWLGN = "CloudWatchLogGroupName";
const _CWOC = "CloudWatchOutputConfig";
const _CWOE = "CloudWatchOutputEnabled";
const _CWOU = "CloudWatchOutputUrl";
const _Ca = "Category";
const _Cl = "Classification";
const _Co = "Comment";
const _Cod = "Code";
const _Com = "Commands";
const _Con = "Configuration";
const _Cont = "Content";
const _Conte = "Context";
const _Cou = "Count";
const _Cr = "Credentials";
const _Cu = "Cutoff";
const _D = "Description";
const _DA = "DeleteActivation";
const _DAE = "DocumentAlreadyExists";
const _DAER = "DescribeAssociationExecutionsRequest";
const _DAERe = "DescribeAssociationExecutionsResult";
const _DAERes = "DescribeAutomationExecutionsRequest";
const _DAEResc = "DescribeAutomationExecutionsResult";
const _DAET = "DescribeAssociationExecutionTargets";
const _DAETR = "DescribeAssociationExecutionTargetsRequest";
const _DAETRe = "DescribeAssociationExecutionTargetsResult";
const _DAEe = "DescribeAssociationExecutions";
const _DAEes = "DescribeAutomationExecutions";
const _DAF = "DescribeActivationsFilter";
const _DAFL = "DescribeActivationsFilterList";
const _DAP = "DescribeAvailablePatches";
const _DAPR = "DescribeAvailablePatchesRequest";
const _DAPRe = "DescribeAvailablePatchesResult";
const _DAR = "DeleteActivationRequest";
const _DARe = "DeleteActivationResult";
const _DARel = "DeleteAssociationRequest";
const _DARele = "DeleteAssociationResult";
const _DARes = "DescribeActivationsRequest";
const _DAResc = "DescribeActivationsResult";
const _DARescr = "DescribeAssociationRequest";
const _DARescri = "DescribeAssociationResult";
const _DASE = "DescribeAutomationStepExecutions";
const _DASER = "DescribeAutomationStepExecutionsRequest";
const _DASERe = "DescribeAutomationStepExecutionsResult";
const _DAe = "DeleteAssociation";
const _DAes = "DescribeActivations";
const _DAesc = "DescribeAssociation";
const _DB = "DefaultBaseline";
const _DCC = "DeleteCloudConnector";
const _DCCR = "DeleteCloudConnectorRequest";
const _DCCRe = "DeleteCloudConnectorResult";
const _DD = "DocumentDescription";
const _DDC = "DuplicateDocumentContent";
const _DDP = "DescribeDocumentPermission";
const _DDPR = "DescribeDocumentPermissionRequest";
const _DDPRe = "DescribeDocumentPermissionResponse";
const _DDR = "DeleteDocumentRequest";
const _DDRe = "DeleteDocumentResult";
const _DDRes = "DescribeDocumentRequest";
const _DDResc = "DescribeDocumentResult";
const _DDS = "DestinationDataSharing";
const _DDST = "DestinationDataSharingType";
const _DDVD = "DocumentDefaultVersionDescription";
const _DDVN = "DuplicateDocumentVersionName";
const _DDe = "DeleteDocument";
const _DDes = "DescribeDocument";
const _DEIA = "DescribeEffectiveInstanceAssociations";
const _DEIAR = "DescribeEffectiveInstanceAssociationsRequest";
const _DEIARe = "DescribeEffectiveInstanceAssociationsResult";
const _DEPFPB = "DescribeEffectivePatchesForPatchBaseline";
const _DEPFPBR = "DescribeEffectivePatchesForPatchBaselineRequest";
const _DEPFPBRe = "DescribeEffectivePatchesForPatchBaselineResult";
const _DF = "DocumentFormat";
const _DFL = "DocumentFilterList";
const _DFo = "DocumentFilter";
const _DH = "DocumentHash";
const _DHT = "DocumentHashType";
const _DI = "DeletionId";
const _DIAS = "DescribeInstanceAssociationsStatus";
const _DIASR = "DescribeInstanceAssociationsStatusRequest";
const _DIASRe = "DescribeInstanceAssociationsStatusResult";
const _DID = "DescribeInventoryDeletions";
const _DIDR = "DescribeInventoryDeletionsRequest";
const _DIDRe = "DescribeInventoryDeletionsResult";
const _DII = "DuplicateInstanceId";
const _DIIR = "DescribeInstanceInformationRequest";
const _DIIRe = "DescribeInstanceInformationResult";
const _DIIe = "DescribeInstanceInformation";
const _DIL = "DocumentIdentifierList";
const _DIN = "DefaultInstanceName";
const _DIP = "DescribeInstancePatches";
const _DIPR = "DescribeInstancePatchesRequest";
const _DIPRe = "DescribeInstancePatchesResult";
const _DIPRes = "DescribeInstancePropertiesRequest";
const _DIPResc = "DescribeInstancePropertiesResult";
const _DIPS = "DescribeInstancePatchStates";
const _DIPSFPG = "DescribeInstancePatchStatesForPatchGroup";
const _DIPSFPGR = "DescribeInstancePatchStatesForPatchGroupRequest";
const _DIPSFPGRe = "DescribeInstancePatchStatesForPatchGroupResult";
const _DIPSR = "DescribeInstancePatchStatesRequest";
const _DIPSRe = "DescribeInstancePatchStatesResult";
const _DIPe = "DescribeInstanceProperties";
const _DIR = "DeleteInventoryRequest";
const _DIRe = "DeleteInventoryResult";
const _DIe = "DeleteInventory";
const _DIo = "DocumentIdentifier";
const _DIoc = "DocumentIdentifiers";
const _DKVF = "DocumentKeyValuesFilter";
const _DKVFL = "DocumentKeyValuesFilterList";
const _DLE = "DocumentLimitExceeded";
const _DMI = "DeregisterManagedInstance";
const _DMIR = "DeregisterManagedInstanceRequest";
const _DMIRe = "DeregisterManagedInstanceResult";
const _DMRI = "DocumentMetadataResponseInfo";
const _DMW = "DeleteMaintenanceWindow";
const _DMWE = "DescribeMaintenanceWindowExecutions";
const _DMWER = "DescribeMaintenanceWindowExecutionsRequest";
const _DMWERe = "DescribeMaintenanceWindowExecutionsResult";
const _DMWET = "DescribeMaintenanceWindowExecutionTasks";
const _DMWETI = "DescribeMaintenanceWindowExecutionTaskInvocations";
const _DMWETIR = "DescribeMaintenanceWindowExecutionTaskInvocationsRequest";
const _DMWETIRe = "DescribeMaintenanceWindowExecutionTaskInvocationsResult";
const _DMWETR = "DescribeMaintenanceWindowExecutionTasksRequest";
const _DMWETRe = "DescribeMaintenanceWindowExecutionTasksResult";
const _DMWFT = "DescribeMaintenanceWindowsForTarget";
const _DMWFTR = "DescribeMaintenanceWindowsForTargetRequest";
const _DMWFTRe = "DescribeMaintenanceWindowsForTargetResult";
const _DMWR = "DeleteMaintenanceWindowRequest";
const _DMWRe = "DeleteMaintenanceWindowResult";
const _DMWRes = "DescribeMaintenanceWindowsRequest";
const _DMWResc = "DescribeMaintenanceWindowsResult";
const _DMWS = "DescribeMaintenanceWindowSchedule";
const _DMWSR = "DescribeMaintenanceWindowScheduleRequest";
const _DMWSRe = "DescribeMaintenanceWindowScheduleResult";
const _DMWT = "DescribeMaintenanceWindowTargets";
const _DMWTR = "DescribeMaintenanceWindowTargetsRequest";
const _DMWTRe = "DescribeMaintenanceWindowTargetsResult";
const _DMWTRes = "DescribeMaintenanceWindowTasksRequest";
const _DMWTResc = "DescribeMaintenanceWindowTasksResult";
const _DMWTe = "DescribeMaintenanceWindowTasks";
const _DMWe = "DescribeMaintenanceWindows";
const _DN = "DocumentName";
const _DNEE = "DoesNotExistException";
const _DNi = "DisplayName";
const _DOI = "DeleteOpsItem";
const _DOIR = "DeleteOpsItemRequest";
const _DOIRI = "DisassociateOpsItemRelatedItem";
const _DOIRIR = "DisassociateOpsItemRelatedItemRequest";
const _DOIRIRi = "DisassociateOpsItemRelatedItemResponse";
const _DOIRe = "DeleteOpsItemResponse";
const _DOIRes = "DescribeOpsItemsRequest";
const _DOIResc = "DescribeOpsItemsResponse";
const _DOIe = "DescribeOpsItems";
const _DOM = "DeleteOpsMetadata";
const _DOMR = "DeleteOpsMetadataRequest";
const _DOMRe = "DeleteOpsMetadataResult";
const _DP = "DeletedParameters";
const _DPB = "DeletePatchBaseline";
const _DPBFPG = "DeregisterPatchBaselineForPatchGroup";
const _DPBFPGR = "DeregisterPatchBaselineForPatchGroupRequest";
const _DPBFPGRe = "DeregisterPatchBaselineForPatchGroupResult";
const _DPBR = "DeletePatchBaselineRequest";
const _DPBRe = "DeletePatchBaselineResult";
const _DPBRes = "DescribePatchBaselinesRequest";
const _DPBResc = "DescribePatchBaselinesResult";
const _DPBe = "DescribePatchBaselines";
const _DPG = "DescribePatchGroups";
const _DPGR = "DescribePatchGroupsRequest";
const _DPGRe = "DescribePatchGroupsResult";
const _DPGS = "DescribePatchGroupState";
const _DPGSR = "DescribePatchGroupStateRequest";
const _DPGSRe = "DescribePatchGroupStateResult";
const _DPL = "DocumentPermissionLimit";
const _DPLo = "DocumentParameterList";
const _DPP = "DescribePatchProperties";
const _DPPR = "DescribePatchPropertiesRequest";
const _DPPRe = "DescribePatchPropertiesResult";
const _DPR = "DeleteParameterRequest";
const _DPRe = "DeleteParameterResult";
const _DPRel = "DeleteParametersRequest";
const _DPRele = "DeleteParametersResult";
const _DPRes = "DescribeParametersRequest";
const _DPResc = "DescribeParametersResult";
const _DPe = "DeleteParameter";
const _DPel = "DeleteParameters";
const _DPes = "DescribeParameters";
const _DPo = "DocumentParameter";
const _DR = "DryRun";
const _DRCL = "DocumentReviewCommentList";
const _DRCS = "DocumentReviewCommentSource";
const _DRDS = "DeleteResourceDataSync";
const _DRDSR = "DeleteResourceDataSyncRequest";
const _DRDSRe = "DeleteResourceDataSyncResult";
const _DRL = "DocumentRequiresList";
const _DRP = "DeleteResourcePolicy";
const _DRPR = "DeleteResourcePolicyRequest";
const _DRPRe = "DeleteResourcePolicyResponse";
const _DRRL = "DocumentReviewerResponseList";
const _DRRS = "DocumentReviewerResponseSource";
const _DRo = "DocumentRequires";
const _DRoc = "DocumentReviews";
const _DS = "DetailedStatus";
const _DSR = "DescribeSessionsRequest";
const _DSRe = "DescribeSessionsResponse";
const _DST = "DeletionStartTime";
const _DSe = "DeletionSummary";
const _DSep = "DeploymentStatus";
const _DSes = "DescribeSessions";
const _DT = "DocumentType";
const _DTFMW = "DeregisterTargetFromMaintenanceWindow";
const _DTFMWR = "DeregisterTargetFromMaintenanceWindowRequest";
const _DTFMWRe = "DeregisterTargetFromMaintenanceWindowResult";
const _DTFMWRer = "DeregisterTaskFromMaintenanceWindowRequest";
const _DTFMWRere = "DeregisterTaskFromMaintenanceWindowResult";
const _DTFMWe = "DeregisterTaskFromMaintenanceWindow";
const _DTOC = "DeliveryTimedOutCount";
const _DTa = "DataType";
const _DTe = "DetailType";
const _DV = "DocumentVersion";
const _DVI = "DocumentVersionInfo";
const _DVL = "DocumentVersionList";
const _DVLE = "DocumentVersionLimitExceeded";
const _DVN = "DefaultVersionName";
const _DVe = "DefaultVersion";
const _DVef = "DefaultValue";
const _DVo = "DocumentVersions";
const _Da = "Date";
const _Dat = "Data";
const _De = "Details";
const _Det = "Detail";
const _Do = "Document";
const _Du = "Duration";
const _E = "Expired";
const _EA = "ExpiresAfter";
const _EAODS = "EnableAllOpsDataSources";
const _EAn = "EndedAt";
const _EAx = "ExcludeAccounts";
const _EB = "ExecutedBy";
const _EC = "ErrorCount";
const _ECr = "ErrorCode";
const _ED = "ExpirationDate";
const _EDn = "EndDate";
const _EDx = "ExecutionDate";
const _EEDT = "ExecutionEndDateTime";
const _EET = "ExecutionEndTime";
const _EETx = "ExecutionElapsedTime";
const _EI = "ExecutionId";
const _EIv = "EventId";
const _EIx = "ExecutionInputs";
const _ENS = "EnableNonSecurity";
const _EP = "EffectivePatches";
const _EPI = "ExecutionPreviewId";
const _EPL = "EffectivePatchList";
const _EPf = "EffectivePatch";
const _EPx = "ExecutionPreview";
const _ERN = "ExecutionRoleName";
const _ES = "ExecutionSummary";
const _ESDT = "ExecutionStartDateTime";
const _EST = "ExecutionStartTime";
const _ET = "ExecutionTime";
const _ETn = "EndTime";
const _ETx = "ExecutionType";
const _ETxp = "ExpirationTime";
const _En = "Entries";
const _Ena = "Enabled";
const _Ent = "Entry";
const _Enti = "Entities";
const _Entit = "Entity";
const _Ep = "Epoch";
const _Ex = "Expression";
const _F = "Failed";
const _FC = "FailedCount";
const _FCA = "FailedCreateAssociation";
const _FCAE = "FailedCreateAssociationEntry";
const _FCAL = "FailedCreateAssociationList";
const _FD = "FailureDetails";
const _FK = "FilterKey";
const _FM = "FailureMessage";
const _FNAE = "FeatureNotAvailableException";
const _FS = "FailureStage";
const _FSa = "FailedSteps";
const _FT = "FailureType";
const _FV = "FilterValues";
const _FVi = "FilterValue";
const _FWO = "FiltersWithOperator";
const _Fa = "Fault";
const _Fi = "Filters";
const _Fo = "Force";
const _G = "Groups";
const _GAE = "GetAutomationExecution";
const _GAER = "GetAutomationExecutionRequest";
const _GAERe = "GetAutomationExecutionResult";
const _GAT = "GetAccessToken";
const _GATR = "GetAccessTokenRequest";
const _GATRe = "GetAccessTokenResponse";
const _GCC = "GetCloudConnector";
const _GCCR = "GetCloudConnectorRequest";
const _GCCRe = "GetCloudConnectorResult";
const _GCI = "GetCommandInvocation";
const _GCIR = "GetCommandInvocationRequest";
const _GCIRe = "GetCommandInvocationResult";
const _GCS = "GetCalendarState";
const _GCSR = "GetCalendarStateRequest";
const _GCSRe = "GetCalendarStateResponse";
const _GCSRet = "GetConnectionStatusRequest";
const _GCSReto = "GetConnectionStatusResponse";
const _GCSe = "GetConnectionStatus";
const _GD = "GetDocument";
const _GDPB = "GetDefaultPatchBaseline";
const _GDPBR = "GetDefaultPatchBaselineRequest";
const _GDPBRe = "GetDefaultPatchBaselineResult";
const _GDPSFI = "GetDeployablePatchSnapshotForInstance";
const _GDPSFIR = "GetDeployablePatchSnapshotForInstanceRequest";
const _GDPSFIRe = "GetDeployablePatchSnapshotForInstanceResult";
const _GDR = "GetDocumentRequest";
const _GDRe = "GetDocumentResult";
const _GEP = "GetExecutionPreview";
const _GEPR = "GetExecutionPreviewRequest";
const _GEPRe = "GetExecutionPreviewResponse";
const _GF = "GlobalFilters";
const _GI = "GetInventory";
const _GIR = "GetInventoryRequest";
const _GIRe = "GetInventoryResult";
const _GIS = "GetInventorySchema";
const _GISR = "GetInventorySchemaRequest";
const _GISRe = "GetInventorySchemaResult";
const _GMW = "GetMaintenanceWindow";
const _GMWE = "GetMaintenanceWindowExecution";
const _GMWER = "GetMaintenanceWindowExecutionRequest";
const _GMWERe = "GetMaintenanceWindowExecutionResult";
const _GMWET = "GetMaintenanceWindowExecutionTask";
const _GMWETI = "GetMaintenanceWindowExecutionTaskInvocation";
const _GMWETIR = "GetMaintenanceWindowExecutionTaskInvocationRequest";
const _GMWETIRe = "GetMaintenanceWindowExecutionTaskInvocationResult";
const _GMWETR = "GetMaintenanceWindowExecutionTaskRequest";
const _GMWETRe = "GetMaintenanceWindowExecutionTaskResult";
const _GMWR = "GetMaintenanceWindowRequest";
const _GMWRe = "GetMaintenanceWindowResult";
const _GMWT = "GetMaintenanceWindowTask";
const _GMWTR = "GetMaintenanceWindowTaskRequest";
const _GMWTRe = "GetMaintenanceWindowTaskResult";
const _GOI = "GetOpsItem";
const _GOIR = "GetOpsItemRequest";
const _GOIRe = "GetOpsItemResponse";
const _GOM = "GetOpsMetadata";
const _GOMR = "GetOpsMetadataRequest";
const _GOMRe = "GetOpsMetadataResult";
const _GOS = "GetOpsSummary";
const _GOSR = "GetOpsSummaryRequest";
const _GOSRe = "GetOpsSummaryResult";
const _GP = "GetParameter";
const _GPB = "GetPatchBaseline";
const _GPBFPG = "GetPatchBaselineForPatchGroup";
const _GPBFPGR = "GetPatchBaselineForPatchGroupRequest";
const _GPBFPGRe = "GetPatchBaselineForPatchGroupResult";
const _GPBP = "GetParametersByPath";
const _GPBPR = "GetParametersByPathRequest";
const _GPBPRe = "GetParametersByPathResult";
const _GPBR = "GetPatchBaselineRequest";
const _GPBRe = "GetPatchBaselineResult";
const _GPH = "GetParameterHistory";
const _GPHR = "GetParameterHistoryRequest";
const _GPHRe = "GetParameterHistoryResult";
const _GPR = "GetParameterRequest";
const _GPRe = "GetParameterResult";
const _GPRet = "GetParametersRequest";
const _GPReta = "GetParametersResult";
const _GPe = "GetParameters";
const _GRP = "GetResourcePolicies";
const _GRPR = "GetResourcePoliciesRequest";
const _GRPRE = "GetResourcePoliciesResponseEntry";
const _GRPREe = "GetResourcePoliciesResponseEntries";
const _GRPRe = "GetResourcePoliciesResponse";
const _GSS = "GetServiceSetting";
const _GSSR = "GetServiceSettingRequest";
const _GSSRe = "GetServiceSettingResult";
const _H = "Hash";
const _HC = "HighCount";
const _HLLEE = "HierarchyLevelLimitExceededException";
const _HT = "HashType";
const _HTME = "HierarchyTypeMismatchException";
const _I = "Id";
const _IA = "InvalidActivation";
const _IAAO = "InstanceAggregatedAssociationOverview";
const _IAE = "InvalidAggregatorException";
const _IAEPE = "InvalidAutomationExecutionParametersException";
const _IAI = "InvalidActivationId";
const _IAL = "InstanceAssociationList";
const _IALn = "InventoryAggregatorList";
const _IAOL = "InstanceAssociationOutputLocation";
const _IAOU = "InstanceAssociationOutputUrl";
const _IAPE = "InvalidAllowedPatternException";
const _IASAC = "InstanceAssociationStatusAggregatedCount";
const _IASE = "InvalidAutomationSignalException";
const _IASI = "InstanceAssociationStatusInfos";
const _IASIn = "InstanceAssociationStatusInfo";
const _IASUE = "InvalidAutomationStatusUpdateException";
const _IAV = "InvalidAssociationVersion";
const _IAn = "InvalidAssociation";
const _IAns = "InstanceAssociation";
const _IAnv = "InventoryAggregator";
const _IAp = "IpAddress";
const _IC = "InstalledCount";
const _ICH = "ItemContentHash";
const _ICI = "InvalidCommandId";
const _ICME = "ItemContentMismatchException";
const _ICOU = "IncludeChildOrganizationUnits";
const _ICn = "InformationalCount";
const _ICs = "IsCritical";
const _ID = "InvalidDocument";
const _IDC = "InvalidDocumentContent";
const _IDIE = "InvalidDeletionIdException";
const _IDIPE = "InvalidDeleteInventoryParametersException";
const _IDL = "InventoryDeletionsList";
const _IDNE = "InvocationDoesNotExist";
const _IDO = "InvalidDocumentOperation";
const _IDS = "InventoryDeletionSummary";
const _IDSI = "InventoryDeletionStatusItem";
const _IDSIn = "InventoryDeletionSummaryItem";
const _IDSInv = "InventoryDeletionSummaryItems";
const _IDSV = "InvalidDocumentSchemaVersion";
const _IDT = "InvalidDocumentType";
const _IDV = "InvalidDocumentVersion";
const _IDVs = "IsDefaultVersion";
const _IDn = "InventoryDeletions";
const _IE = "IsEnd";
const _IF = "InvalidFilter";
const _IFK = "InvalidFilterKey";
const _IFL = "InventoryFilterList";
const _IFO = "InvalidFilterOption";
const _IFR = "IncludeFutureRegions";
const _IFV = "InvalidFilterValue";
const _IFVL = "InventoryFilterValueList";
const _IFn = "InventoryFilter";
const _IG = "InventoryGroup";
const _IGL = "InventoryGroupList";
const _II = "InstanceId";
const _IIA = "InventoryItemAttribute";
const _IIAL = "InventoryItemAttributeList";
const _IICE = "InvalidItemContentException";
const _IIEL = "InventoryItemEntryList";
const _IIF = "InstanceInformationFilter";
const _IIFL = "InstanceInformationFilterList";
const _IIFV = "InstanceInformationFilterValue";
const _IIFVS = "InstanceInformationFilterValueSet";
const _IIGE = "InvalidInventoryGroupException";
const _III = "InvalidInstanceId";
const _IIICE = "InvalidInventoryItemContextException";
const _IIIFV = "InvalidInstanceInformationFilterValue";
const _IIL = "InstanceInformationList";
const _IILn = "InventoryItemList";
const _IIPFV = "InvalidInstancePropertyFilterValue";
const _IIRE = "InvalidInventoryRequestException";
const _IIS = "InventoryItemSchema";
const _IISF = "InstanceInformationStringFilter";
const _IISFL = "InstanceInformationStringFilterList";
const _IISRL = "InventoryItemSchemaResultList";
const _IIn = "InstanceIds";
const _IIns = "InstanceInfo";
const _IInst = "InstanceInformation";
const _IInv = "InvocationId";
const _IInve = "InventoryItem";
const _IKI = "InvalidKeyId";
const _IL = "InvalidLabels";
const _ILV = "IsLatestVersion";
const _IN = "InstanceName";
const _INC = "InvalidNotificationConfig";
const _INT = "InvalidNextToken";
const _IOC = "InstalledOtherCount";
const _IOE = "InvalidOptionException";
const _IOF = "InvalidOutputFolder";
const _IOL = "InvalidOutputLocation";
const _IOLn = "InstallOverrideList";
const _IP = "InvalidParameters";
const _IPA = "IPAddress";
const _IPAE = "InvalidPolicyAttributeException";
const _IPAF = "IgnorePollAlarmFailure";
const _IPE = "IncompatiblePolicyException";
const _IPF = "InstancePropertyFilter";
const _IPFL = "InstancePropertyFilterList";
const _IPFV = "InstancePropertyFilterValue";
const _IPFVS = "InstancePropertyFilterValueSet";
const _IPM = "IdempotentParameterMismatch";
const _IPN = "InvalidPluginName";
const _IPRC = "InstalledPendingRebootCount";
const _IPS = "InstancePatchStates";
const _IPSF = "InstancePatchStateFilter";
const _IPSFL = "InstancePatchStateFilterList";
const _IPSFLn = "InstancePropertyStringFilterList";
const _IPSFn = "InstancePropertyStringFilter";
const _IPSL = "InstancePatchStateList";
const _IPSLn = "InstancePatchStatesList";
const _IPSn = "InstancePatchState";
const _IPT = "InvalidPermissionType";
const _IPTE = "InvalidPolicyTypeException";
const _IPn = "InstanceProperties";
const _IPns = "InstanceProperty";
const _IR = "InvalidRole";
const _IRAE = "InvalidResultAttributeException";
const _IRC = "InstalledRejectedCount";
const _IRE = "InventoryResultEntity";
const _IREL = "InventoryResultEntityList";
const _IRI = "InvalidResourceId";
const _IRIM = "InventoryResultItemMap";
const _IRIn = "InventoryResultItem";
const _IRT = "InvalidResourceType";
const _IRa = "IamRole";
const _IRn = "InstanceRole";
const _IS = "InvalidSchedule";
const _ISE = "InternalServerError";
const _ISLEE = "ItemSizeLimitExceededException";
const _ISn = "InstanceStatus";
const _ISns = "InstanceState";
const _IT = "InvalidTag";
const _ITM = "InvalidTargetMaps";
const _ITNE = "InvalidTypeNameException";
const _ITn = "InvalidTarget";
const _ITns = "InstanceType";
const _ITnst = "InstalledTime";
const _IU = "InvalidUpdate";
const _IV = "IteratorValue";
const _IWASU = "InstancesWithAvailableSecurityUpdates";
const _IWCNCP = "InstancesWithCriticalNonCompliantPatches";
const _IWFP = "InstancesWithFailedPatches";
const _IWIOP = "InstancesWithInstalledOtherPatches";
const _IWIP = "InstancesWithInstalledPatches";
const _IWIPRP = "InstancesWithInstalledPendingRebootPatches";
const _IWIRP = "InstancesWithInstalledRejectedPatches";
const _IWMP = "InstancesWithMissingPatches";
const _IWNAP = "InstancesWithNotApplicablePatches";
const _IWONCP = "InstancesWithOtherNonCompliantPatches";
const _IWSNCP = "InstancesWithSecurityNonCompliantPatches";
const _IWUNAP = "InstancesWithUnreportedNotApplicablePatches";
const _In = "Instances";
const _Inp = "Input";
const _Inpu = "Inputs";
const _Ins = "Instance";
const _It = "Iteration";
const _Ite = "Items";
const _Item = "Item";
const _K = "Key";
const _KBI = "KBId";
const _KI = "KeyId";
const _KN = "KeyName";
const _KNb = "KbNumber";
const _KTD = "KeysToDelete";
const _L = "Limit";
const _LA = "ListAssociations";
const _LAED = "LastAssociationExecutionDate";
const _LAR = "ListAssociationsRequest";
const _LARi = "ListAssociationsResult";
const _LAV = "ListAssociationVersions";
const _LAVR = "ListAssociationVersionsRequest";
const _LAVRi = "ListAssociationVersionsResult";
const _LC = "LowCount";
const _LCC = "ListCloudConnectors";
const _LCCR = "ListCloudConnectorsRequest";
const _LCCRi = "ListCloudConnectorsResult";
const _LCI = "ListCommandInvocations";
const _LCIR = "ListCommandInvocationsRequest";
const _LCIRi = "ListCommandInvocationsResult";
const _LCIRis = "ListComplianceItemsRequest";
const _LCIRist = "ListComplianceItemsResult";
const _LCIi = "ListComplianceItems";
const _LCR = "ListCommandsRequest";
const _LCRi = "ListCommandsResult";
const _LCS = "ListComplianceSummaries";
const _LCSR = "ListComplianceSummariesRequest";
const _LCSRi = "ListComplianceSummariesResult";
const _LCi = "ListCommands";
const _LD = "ListDocuments";
const _LDMH = "ListDocumentMetadataHistory";
const _LDMHR = "ListDocumentMetadataHistoryRequest";
const _LDMHRi = "ListDocumentMetadataHistoryResponse";
const _LDR = "ListDocumentsRequest";
const _LDRi = "ListDocumentsResult";
const _LDV = "ListDocumentVersions";
const _LDVR = "ListDocumentVersionsRequest";
const _LDVRi = "ListDocumentVersionsResult";
const _LED = "LastExecutionDate";
const _LF = "LogFile";
const _LI = "LoggingInfo";
const _LIE = "ListInventoryEntries";
const _LIER = "ListInventoryEntriesRequest";
const _LIERi = "ListInventoryEntriesResult";
const _LMB = "LastModifiedBy";
const _LMD = "LastModifiedDate";
const _LMT = "LastModifiedTime";
const _LMU = "LastModifiedUser";
const _LN = "ListNodes";
const _LNR = "ListNodesRequest";
const _LNRIOT = "LastNoRebootInstallOperationTime";
const _LNRi = "ListNodesResult";
const _LNS = "ListNodesSummary";
const _LNSR = "ListNodesSummaryRequest";
const _LNSRi = "ListNodesSummaryResult";
const _LOIE = "ListOpsItemEvents";
const _LOIER = "ListOpsItemEventsRequest";
const _LOIERi = "ListOpsItemEventsResponse";
const _LOIRI = "ListOpsItemRelatedItems";
const _LOIRIR = "ListOpsItemRelatedItemsRequest";
const _LOIRIRi = "ListOpsItemRelatedItemsResponse";
const _LOM = "ListOpsMetadata";
const _LOMR = "ListOpsMetadataRequest";
const _LOMRi = "ListOpsMetadataResult";
const _LPDT = "LastPingDateTime";
const _LPV = "LabelParameterVersion";
const _LPVR = "LabelParameterVersionRequest";
const _LPVRa = "LabelParameterVersionResult";
const _LRCS = "ListResourceComplianceSummaries";
const _LRCSR = "ListResourceComplianceSummariesRequest";
const _LRCSRi = "ListResourceComplianceSummariesResult";
const _LRDS = "ListResourceDataSync";
const _LRDSR = "ListResourceDataSyncRequest";
const _LRDSRi = "ListResourceDataSyncResult";
const _LS = "LastStatus";
const _LSAED = "LastSuccessfulAssociationExecutionDate";
const _LSED = "LastSuccessfulExecutionDate";
const _LSM = "LastStatusMessage";
const _LSSM = "LastSyncStatusMessage";
const _LSST = "LastSuccessfulSyncTime";
const _LST = "LastSyncTime";
const _LSUT = "LastStatusUpdateTime";
const _LT = "LimitType";
const _LTFR = "ListTagsForResource";
const _LTFRR = "ListTagsForResourceRequest";
const _LTFRRi = "ListTagsForResourceResult";
const _LTa = "LaunchTime";
const _LUAD = "LastUpdateAssociationDate";
const _LV = "LatestVersion";
const _La = "Labels";
const _Lam = "Lambda";
const _Lan = "Language";
const _M = "Message";
const _MA = "MaxAttempts";
const _MC = "MaxConcurrency";
const _MCe = "MediumCount";
const _MCi = "MissingCount";
const _MD = "ModifiedDate";
const _MDP = "ModifyDocumentPermission";
const _MDPR = "ModifyDocumentPermissionRequest";
const _MDPRo = "ModifyDocumentPermissionResponse";
const _MDSE = "MaxDocumentSizeExceeded";
const _ME = "MaxErrors";
const _MM = "MetadataMap";
const _MN = "MsrcNumber";
const _MR = "MaxResults";
const _MRPDE = "MalformedResourcePolicyDocumentException";
const _MS = "ManagedStatus";
const _MSD = "MaxSessionDuration";
const _MSs = "MsrcSeverity";
const _MTU = "MetadataToUpdate";
const _MV = "MetadataValue";
const _MWAP = "MaintenanceWindowAutomationParameters";
const _MWD = "MaintenanceWindowDescription";
const _MWE = "MaintenanceWindowExecution";
const _MWEL = "MaintenanceWindowExecutionList";
const _MWETI = "MaintenanceWindowExecutionTaskIdentity";
const _MWETII = "MaintenanceWindowExecutionTaskInvocationIdentity";
const _MWETIIL = "MaintenanceWindowExecutionTaskInvocationIdentityList";
const _MWETIL = "MaintenanceWindowExecutionTaskIdentityList";
const _MWETIP = "MaintenanceWindowExecutionTaskInvocationParameters";
const _MWF = "MaintenanceWindowFilter";
const _MWFL = "MaintenanceWindowFilterList";
const _MWFTL = "MaintenanceWindowsForTargetList";
const _MWI = "MaintenanceWindowIdentity";
const _MWIFT = "MaintenanceWindowIdentityForTarget";
const _MWIL = "MaintenanceWindowIdentityList";
const _MWLP = "MaintenanceWindowLambdaPayload";
const _MWLPa = "MaintenanceWindowLambdaParameters";
const _MWRCP = "MaintenanceWindowRunCommandParameters";
const _MWSFI = "MaintenanceWindowStepFunctionsInput";
const _MWSFP = "MaintenanceWindowStepFunctionsParameters";
const _MWT = "MaintenanceWindowTarget";
const _MWTIP = "MaintenanceWindowTaskInvocationParameters";
const _MWTL = "MaintenanceWindowTargetList";
const _MWTLa = "MaintenanceWindowTaskList";
const _MWTP = "MaintenanceWindowTaskParameters";
const _MWTPL = "MaintenanceWindowTaskParametersList";
const _MWTPV = "MaintenanceWindowTaskParameterValue";
const _MWTPVE = "MaintenanceWindowTaskParameterValueExpression";
const _MWTPVL = "MaintenanceWindowTaskParameterValueList";
const _MWTa = "MaintenanceWindowTask";
const _Ma = "Mappings";
const _Me = "Metadata";
const _Mo = "Mode";
const _N = "Name";
const _NA = "NodeAggregator";
const _NAC = "NotApplicableCount";
const _NAL = "NodeAggregatorList";
const _NAo = "NotificationArn";
const _NC = "NotificationConfig";
const _NCC = "NonCompliantCount";
const _NCS = "NonCompliantSummary";
const _NE = "NotificationEvents";
const _NET = "NextExecutionTime";
const _NF = "NodeFilter";
const _NFL = "NodeFilterList";
const _NFVL = "NodeFilterValueList";
const _NL = "NodeList";
const _NLSE = "NoLongerSupportedException";
const _NOI = "NodeOwnerInfo";
const _NS = "NextStep";
const _NSL = "NodeSummaryList";
const _NT = "NextToken";
const _NTT = "NextTransitionTime";
const _NTo = "NodeType";
const _NTot = "NotificationType";
const _Na = "Names";
const _No = "Notifications";
const _Nod = "Nodes";
const _Node = "Node";
const _O = "Overview";
const _OA = "OpsAggregator";
const _OAL = "OpsAggregatorList";
const _OD = "OperationalData";
const _ODTD = "OperationalDataToDelete";
const _OE = "OpsEntity";
const _OEI = "OpsEntityItem";
const _OEIEL = "OpsEntityItemEntryList";
const _OEIM = "OpsEntityItemMap";
const _OEL = "OpsEntityList";
const _OET = "OperationEndTime";
const _OF = "OpsFilter";
const _OFL = "OpsFilterList";
const _OFVL = "OpsFilterValueList";
const _OFn = "OnFailure";
const _OI = "OwnerInformation";
const _OIA = "OpsItemArn";
const _OIADE = "OpsItemAccessDeniedException";
const _OIAEE = "OpsItemAlreadyExistsException";
const _OICE = "OpsItemConflictException";
const _OIDV = "OpsItemDataValue";
const _OIEF = "OpsItemEventFilter";
const _OIEFp = "OpsItemEventFilters";
const _OIES = "OpsItemEventSummary";
const _OIESp = "OpsItemEventSummaries";
const _OIF = "OpsItemFilters";
const _OIFp = "OpsItemFilter";
const _OII = "OpsItemId";
const _OIIPE = "OpsItemInvalidParameterException";
const _OIIp = "OpsItemIdentity";
const _OILEE = "OpsItemLimitExceededException";
const _OIN = "OpsItemNotification";
const _OINFE = "OpsItemNotFoundException";
const _OINp = "OpsItemNotifications";
const _OIOD = "OpsItemOperationalData";
const _OIRIAEE = "OpsItemRelatedItemAlreadyExistsException";
const _OIRIANFE = "OpsItemRelatedItemAssociationNotFoundException";
const _OIRIF = "OpsItemRelatedItemsFilter";
const _OIRIFp = "OpsItemRelatedItemsFilters";
const _OIRIS = "OpsItemRelatedItemSummary";
const _OIRISp = "OpsItemRelatedItemSummaries";
const _OIS = "OpsItemSummaries";
const _OISp = "OpsItemSummary";
const _OIT = "OpsItemType";
const _OIp = "OpsItem";
const _OL = "OutputLocation";
const _OM = "OpsMetadata";
const _OMA = "OpsMetadataArn";
const _OMAEE = "OpsMetadataAlreadyExistsException";
const _OMF = "OpsMetadataFilter";
const _OMFL = "OpsMetadataFilterList";
const _OMIAE = "OpsMetadataInvalidArgumentException";
const _OMKLEE = "OpsMetadataKeyLimitExceededException";
const _OML = "OpsMetadataList";
const _OMLEE = "OpsMetadataLimitExceededException";
const _OMNFE = "OpsMetadataNotFoundException";
const _OMTMUE = "OpsMetadataTooManyUpdatesException";
const _ONCC = "OtherNonCompliantCount";
const _OP = "OverriddenParameters";
const _ORA = "OpsResultAttribute";
const _ORAL = "OpsResultAttributeList";
const _OS = "OutputSource";
const _OSBN = "OutputS3BucketName";
const _OSI = "OutputSourceId";
const _OSKP = "OutputS3KeyPrefix";
const _OSR = "OutputS3Region";
const _OST = "OperationStartTime";
const _OSTr = "OrganizationSourceType";
const _OSTu = "OutputSourceType";
const _OSp = "OperatingSystem";
const _OSv = "OverallSeverity";
const _OU = "OutputUrl";
const _OUI = "OrganizationalUnitId";
const _OUP = "OrganizationalUnitPath";
const _OUr = "OrganizationalUnits";
const _Op = "Operation";
const _Ope = "Operator";
const _Opt = "Option";
const _Ou = "Outputs";
const _Out = "Output";
const _Ov = "Overwrite";
const _Ow = "Owner";
const _P = "Parameters";
const _PAE = "ParameterAlreadyExists";
const _PAEI = "ParentAutomationExecutionId";
const _PBI = "PatchBaselineIdentity";
const _PBIL = "PatchBaselineIdentityList";
const _PC = "ProgressCounters";
const _PCD = "PatchComplianceData";
const _PCDL = "PatchComplianceDataList";
const _PCI = "PutComplianceItems";
const _PCIR = "PutComplianceItemsRequest";
const _PCIRu = "PutComplianceItemsResult";
const _PET = "PlannedEndTime";
const _PF = "ParameterFilters";
const _PFG = "PatchFilterGroup";
const _PFL = "ParametersFilterList";
const _PFLa = "PatchFilterList";
const _PFa = "ParametersFilter";
const _PFat = "PatchFilter";
const _PFatc = "PatchFilters";
const _PFr = "ProductFamily";
const _PG = "PatchGroup";
const _PGPBM = "PatchGroupPatchBaselineMapping";
const _PGPBML = "PatchGroupPatchBaselineMappingList";
const _PGa = "PatchGroups";
const _PH = "PolicyHash";
const _PHL = "ParameterHistoryList";
const _PHa = "ParameterHistory";
const _PI = "PolicyId";
const _PIP = "ParameterInlinePolicy";
const _PIR = "PutInventoryRequest";
const _PIRu = "PutInventoryResult";
const _PIu = "PutInventory";
const _PL = "ParameterList";
const _PLE = "ParameterLimitExceeded";
const _PLEE = "PoliciesLimitExceededException";
const _PLa = "PatchList";
const _PM = "ParameterMetadata";
const _PML = "ParameterMetadataList";
const _PMVLE = "ParameterMaxVersionLimitExceeded";
const _PMr = "ProviderMessage";
const _PN = "ParameterNames";
const _PNF = "ParameterNotFound";
const _PNl = "PluginName";
const _PNla = "PlatformName";
const _POF = "PatchOrchestratorFilter";
const _POFL = "PatchOrchestratorFilterList";
const _PP = "PutParameter";
const _PPL = "PatchPropertiesList";
const _PPLa = "ParameterPolicyList";
const _PPME = "ParameterPatternMismatchException";
const _PPR = "PutParameterRequest";
const _PPRu = "PutParameterResult";
const _PR = "PatchRule";
const _PRG = "PatchRuleGroup";
const _PRL = "PatchRuleList";
const _PRP = "PutResourcePolicy";
const _PRPR = "PutResourcePolicyRequest";
const _PRPRu = "PutResourcePolicyResponse";
const _PRV = "PendingReviewVersion";
const _PRa = "PatchRules";
const _PS = "PatchSet";
const _PSC = "PatchSourceConfiguration";
const _PSD = "ParentStepDetails";
const _PSF = "ParameterStringFilter";
const _PSFL = "ParameterStringFilterList";
const _PSL = "PatchSourceList";
const _PSPV = "PSParameterValue";
const _PST = "PlannedStartTime";
const _PSa = "PatchStatus";
const _PSat = "PatchSource";
const _PSi = "PingStatus";
const _PSo = "PolicyStatus";
const _PT = "PermissionType";
const _PTL = "PlatformTypeList";
const _PTl = "PlatformTypes";
const _PTla = "PlatformType";
const _PTo = "PolicyText";
const _PTol = "PolicyType";
const _PV = "PlatformVersion";
const _PVLLE = "ParameterVersionLabelLimitExceeded";
const _PVNF = "ParameterVersionNotFound";
const _PVa = "ParameterVersion";
const _PVar = "ParameterValues";
const _Pa = "Patches";
const _Par = "Parameter";
const _Pat = "Patch";
const _Path = "Path";
const _Pay = "Payload";
const _Po = "Policies";
const _Pol = "Policy";
const _Pr = "Priority";
const _Pre = "Prefix";
const _Pro = "Property";
const _Prod = "Product";
const _Produ = "Products";
const _Prop = "Properties";
const _Q = "Qualifier";
const _QC = "QuotaCode";
const _R = "Runbooks";
const _RA = "RoleArn";
const _RAL = "ResultAttributeList";
const _RAe = "ResourceArn";
const _RAes = "ResultAttributes";
const _RAesu = "ResultAttribute";
const _RC = "ReasonCode";
const _RCBS = "ResourceCountByStatus";
const _RCSI = "ResourceComplianceSummaryItems";
const _RCSIL = "ResourceComplianceSummaryItemList";
const _RCSIe = "ResourceComplianceSummaryItem";
const _RCe = "RegistrationsCount";
const _RCem = "RemainingCount";
const _RCes = "ResponseCode";
const _RCu = "RunCommand";
const _RD = "RegistrationDate";
const _RDPB = "RegisterDefaultPatchBaseline";
const _RDPBR = "RegisterDefaultPatchBaselineRequest";
const _RDPBRe = "RegisterDefaultPatchBaselineResult";
const _RDSAEE = "ResourceDataSyncAlreadyExistsException";
const _RDSAOS = "ResourceDataSyncAwsOrganizationsSource";
const _RDSCE = "ResourceDataSyncConflictException";
const _RDSCEE = "ResourceDataSyncCountExceededException";
const _RDSDDS = "ResourceDataSyncDestinationDataSharing";
const _RDSI = "ResourceDataSyncItems";
const _RDSICE = "ResourceDataSyncInvalidConfigurationException";
const _RDSIL = "ResourceDataSyncItemList";
const _RDSIe = "ResourceDataSyncItem";
const _RDSNFE = "ResourceDataSyncNotFoundException";
const _RDSOU = "ResourceDataSyncOrganizationalUnit";
const _RDSOUL = "ResourceDataSyncOrganizationalUnitList";
const _RDSS = "ResourceDataSyncSource";
const _RDSSD = "ResourceDataSyncS3Destination";
const _RDSSWS = "ResourceDataSyncSourceWithState";
const _RDT = "RequestedDateTime";
const _RDe = "ReleaseDate";
const _RFDT = "ResponseFinishDateTime";
const _RI = "ResourceId";
const _RIL = "ReviewInformationList";
const _RIUE = "ResourceInUseException";
const _RIe = "ReviewInformation";
const _RIes = "ResourceIds";
const _RL = "RegistrationLimit";
const _RLEE = "ResourceLimitExceededException";
const _RLe = "RemovedLabels";
const _RM = "RegistrationMetadata";
const _RMI = "RegistrationMetadataItem";
const _RML = "RegistrationMetadataList";
const _RNFE = "ResourceNotFoundException";
const _RO = "ReverseOrder";
const _ROI = "RelatedOpsItems";
const _ROIe = "RelatedOpsItem";
const _ROe = "RebootOption";
const _RP = "RejectedPatches";
const _RPA = "RejectedPatchesAction";
const _RPBFPG = "RegisterPatchBaselineForPatchGroup";
const _RPBFPGR = "RegisterPatchBaselineForPatchGroupRequest";
const _RPBFPGRe = "RegisterPatchBaselineForPatchGroupResult";
const _RPCE = "ResourcePolicyConflictException";
const _RPIPE = "ResourcePolicyInvalidParameterException";
const _RPLEE = "ResourcePolicyLimitExceededException";
const _RPNFE = "ResourcePolicyNotFoundException";
const _RR = "ReviewerResponse";
const _RS = "ReviewStatus";
const _RSDT = "ResponseStartDateTime";
const _RSR = "ResumeSessionRequest";
const _RSRe = "ResumeSessionResponse";
const _RSS = "ResetServiceSetting";
const _RSSR = "ResetServiceSettingRequest";
const _RSSRe = "ResetServiceSettingResult";
const _RSe = "ResumeSession";
const _RT = "ResourceTypes";
const _RTFR = "RemoveTagsFromResource";
const _RTFRR = "RemoveTagsFromResourceRequest";
const _RTFRRe = "RemoveTagsFromResourceResult";
const _RTWMW = "RegisterTargetWithMaintenanceWindow";
const _RTWMWR = "RegisterTargetWithMaintenanceWindowRequest";
const _RTWMWRe = "RegisterTargetWithMaintenanceWindowResult";
const _RTWMWReg = "RegisterTaskWithMaintenanceWindowRequest";
const _RTWMWRegi = "RegisterTaskWithMaintenanceWindowResult";
const _RTWMWe = "RegisterTaskWithMaintenanceWindow";
const _RTe = "ResourceType";
const _RTeq = "RequireType";
const _RTes = "ResolvedTargets";
const _RTev = "ReviewedTime";
const _RU = "ResourceUri";
const _Re = "Regions";
const _Rea = "Reason";
const _Rec = "Recursive";
const _Reg = "Region";
const _Rel = "Release";
const _Rep = "Repository";
const _Repl = "Replace";
const _Req = "Requires";
const _Res = "Response";
const _Rev = "Reviewer";
const _Ru = "Runbook";
const _S = "State";
const _SAE = "StartAutomationExecution";
const _SAER = "StartAutomationExecutionRequest";
const _SAERt = "StartAutomationExecutionResult";
const _SAERto = "StopAutomationExecutionRequest";
const _SAERtop = "StopAutomationExecutionResult";
const _SAEt = "StopAutomationExecution";
const _SAK = "SecretAccessKey";
const _SAO = "StartAssociationsOnce";
const _SAOR = "StartAssociationsOnceRequest";
const _SAORt = "StartAssociationsOnceResult";
const _SAR = "StartAccessRequest";
const _SARR = "StartAccessRequestRequest";
const _SARRt = "StartAccessRequestResponse";
const _SAS = "SendAutomationSignal";
const _SASR = "SendAutomationSignalRequest";
const _SASRe = "SendAutomationSignalResult";
const _SBN = "S3BucketName";
const _SC = "ServiceCode";
const _SCR = "SendCommandRequest";
const _SCRE = "StartChangeRequestExecution";
const _SCRER = "StartChangeRequestExecutionRequest";
const _SCRERt = "StartChangeRequestExecutionResult";
const _SCRe = "SendCommandResult";
const _SCT = "SyncCreatedTime";
const _SCe = "SendCommand";
const _SCy = "SyncCompliance";
const _SD = "StatusDetails";
const _SDO = "SchemaDeleteOption";
const _SDU = "SnapshotDownloadUrl";
const _SDV = "SharedDocumentVersion";
const _SDe = "S3Destination";
const _SDt = "StartDate";
const _SE = "ScheduleExpression";
const _SEC = "StandardErrorContent";
const _SEF = "StepExecutionFilter";
const _SEFL = "StepExecutionFilterList";
const _SEI = "StepExecutionId";
const _SEL = "StepExecutionList";
const _SEP = "StartExecutionPreview";
const _SEPR = "StartExecutionPreviewRequest";
const _SEPRt = "StartExecutionPreviewResponse";
const _SET = "StepExecutionsTruncated";
const _SETc = "ScheduledEndTime";
const _SEU = "StandardErrorUrl";
const _SEt = "StepExecutions";
const _SEte = "StepExecution";
const _SF = "StepFunctions";
const _SFL = "SessionFilterList";
const _SFe = "SessionFilter";
const _SFy = "SyncFormat";
const _SI = "StatusInformation";
const _SIe = "SettingId";
const _SIes = "SessionId";
const _SIn = "SnapshotId";
const _SIo = "SourceId";
const _SIu = "SummaryItems";
const _SKP = "S3KeyPrefix";
const _SL = "S3Location";
const _SLMT = "SyncLastModifiedTime";
const _SLe = "SessionList";
const _SLo = "SourceLocation";
const _SM = "StatusMessage";
const _SMOU = "SessionManagerOutputUrl";
const _SMP = "SessionManagerParameters";
const _SN = "SyncName";
const _SNCC = "SecurityNonCompliantCount";
const _SNt = "StepName";
const _SO = "ScheduleOffset";
const _SOC = "StandardOutputContent";
const _SOL = "S3OutputLocation";
const _SOU = "StandardOutputUrl";
const _SOUu = "S3OutputUrl";
const _SP = "StepPreviews";
const _SQEE = "ServiceQuotaExceededException";
const _SR = "ServiceRole";
const _SRA = "ServiceRoleArn";
const _SRe = "S3Region";
const _SRo = "SourceResult";
const _SRou = "SourceRegions";
const _SS = "SeveritySummary";
const _SSNF = "ServiceSettingNotFound";
const _SSR = "StartSessionRequest";
const _SSRt = "StartSessionResponse";
const _SSe = "ServiceSetting";
const _SSt = "StepStatus";
const _SSta = "StartSession";
const _SSu = "SuccessSteps";
const _SSy = "SyncSource";
const _ST = "SyncType";
const _STCLEE = "SubTypeCountLimitExceededException";
const _STT = "SessionTokenType";
const _STc = "ScheduledTime";
const _STch = "ScheduleTimezone";
const _STe = "SessionToken";
const _STi = "SignalType";
const _STo = "SourceType";
const _STt = "StartTime";
const _STu = "SubType";
const _SU = "StatusUnchanged";
const _SUt = "StreamUrl";
const _SV = "SchemaVersion";
const _SVe = "SettingValue";
const _SWE = "ScheduledWindowExecutions";
const _SWEL = "ScheduledWindowExecutionList";
const _SWEc = "ScheduledWindowExecution";
const _Sa = "Safe";
const _Sc = "Schedule";
const _Sch = "Schemas";
const _Sco = "Scope";
const _Se = "Severity";
const _Sel = "Selector";
const _Ses = "Sessions";
const _Sess = "Session";
const _Sh = "Shared";
const _Sha = "Sha1";
const _Si = "Size";
const _So = "Sources";
const _Sou = "Source";
const _St = "Status";
const _Su = "Successful";
const _Sub = "Subscriptions";
const _Sum = "Summary";
const _Summ = "Summaries";
const _T = "Tags";
const _TA = "TriggeredAlarms";
const _TAa = "TaskArn";
const _TAo = "TotalAccounts";
const _TC = "TargetCount";
const _TCo = "TotalCount";
const _TDN = "TenantDisplayName";
const _TE = "ThrottlingException";
const _TEI = "TaskExecutionId";
const _TI = "TenantId";
const _TIP = "TaskInvocationParameters";
const _TIUE = "TargetInUseException";
const _TIa = "TaskId";
const _TIas = "TaskIds";
const _TK = "TagKeys";
const _TL = "TargetLocations";
const _TLAC = "TargetLocationAlarmConfiguration";
const _TLMC = "TargetLocationMaxConcurrency";
const _TLME = "TargetLocationMaxErrors";
const _TLURL = "TargetLocationsURL";
const _TLa = "TagList";
const _TLar = "TargetLocation";
const _TM = "TargetMaps";
const _TMC = "TargetsMaxConcurrency";
const _TME = "TargetsMaxErrors";
const _TMTE = "TooManyTagsError";
const _TMU = "TooManyUpdates";
const _TMa = "TargetMap";
const _TN = "TypeName";
const _TNC = "TargetNotConnected";
const _TO = "TraceOutput";
const _TOS = "TimedOutSteps";
const _TP = "TargetPreviews";
const _TPL = "TargetPreviewList";
const _TPN = "TargetParameterName";
const _TPa = "TaskParameters";
const _TPar = "TargetPreview";
const _TS = "TimeoutSeconds";
const _TSLEE = "TotalSizeLimitExceededException";
const _TSR = "TerminateSessionRequest";
const _TSRe = "TerminateSessionResponse";
const _TSe = "TerminateSession";
const _TSo = "TotalSteps";
const _TT = "TargetType";
const _TTa = "TaskType";
const _TV = "TokenValue";
const _Ta = "Targets";
const _Tag = "Tag";
const _Tar = "Target";
const _Tas = "Tasks";
const _Ti = "Title";
const _Tie = "Tier";
const _Tr = "Truncated";
const _Ty = "Type";
const _U = "Url";
const _UA = "UpdatedAt";
const _UAR = "UpdateAssociationRequest";
const _UARp = "UpdateAssociationResult";
const _UAS = "UpdateAssociationStatus";
const _UASR = "UpdateAssociationStatusRequest";
const _UASRp = "UpdateAssociationStatusResult";
const _UAp = "UpdateAssociation";
const _UC = "UnspecifiedCount";
const _UCC = "UpdateCloudConnector";
const _UCCR = "UpdateCloudConnectorRequest";
const _UCCRp = "UpdateCloudConnectorResult";
const _UCE = "UnsupportedCalendarException";
const _UD = "UpdateDocument";
const _UDDV = "UpdateDocumentDefaultVersion";
const _UDDVR = "UpdateDocumentDefaultVersionRequest";
const _UDDVRp = "UpdateDocumentDefaultVersionResult";
const _UDM = "UpdateDocumentMetadata";
const _UDMR = "UpdateDocumentMetadataRequest";
const _UDMRp = "UpdateDocumentMetadataResponse";
const _UDR = "UpdateDocumentRequest";
const _UDRp = "UpdateDocumentResult";
const _UFRE = "UnsupportedFeatureRequiredException";
const _UIICE = "UnsupportedInventoryItemContextException";
const _UISVE = "UnsupportedInventorySchemaVersionException";
const _UMIR = "UpdateManagedInstanceRole";
const _UMIRR = "UpdateManagedInstanceRoleRequest";
const _UMIRRp = "UpdateManagedInstanceRoleResult";
const _UMW = "UpdateMaintenanceWindow";
const _UMWR = "UpdateMaintenanceWindowRequest";
const _UMWRp = "UpdateMaintenanceWindowResult";
const _UMWT = "UpdateMaintenanceWindowTarget";
const _UMWTR = "UpdateMaintenanceWindowTargetRequest";
const _UMWTRp = "UpdateMaintenanceWindowTargetResult";
const _UMWTRpd = "UpdateMaintenanceWindowTaskRequest";
const _UMWTRpda = "UpdateMaintenanceWindowTaskResult";
const _UMWTp = "UpdateMaintenanceWindowTask";
const _UNAC = "UnreportedNotApplicableCount";
const _UOE = "UnsupportedOperationException";
const _UOI = "UpdateOpsItem";
const _UOIR = "UpdateOpsItemRequest";
const _UOIRp = "UpdateOpsItemResponse";
const _UOM = "UpdateOpsMetadata";
const _UOMR = "UpdateOpsMetadataRequest";
const _UOMRp = "UpdateOpsMetadataResult";
const _UOS = "UnsupportedOperatingSystem";
const _UPB = "UpdatePatchBaseline";
const _UPBR = "UpdatePatchBaselineRequest";
const _UPBRp = "UpdatePatchBaselineResult";
const _UPT = "UnsupportedParameterType";
const _UPTn = "UnsupportedPlatformType";
const _UPV = "UnlabelParameterVersion";
const _UPVR = "UnlabelParameterVersionRequest";
const _UPVRn = "UnlabelParameterVersionResult";
const _URDS = "UpdateResourceDataSync";
const _URDSR = "UpdateResourceDataSyncRequest";
const _URDSRp = "UpdateResourceDataSyncResult";
const _USDSE = "UseS3DualStackEndpoint";
const _USS = "UpdateServiceSetting";
const _USSR = "UpdateServiceSettingRequest";
const _USSRp = "UpdateServiceSettingResult";
const _UT = "UpdatedTime";
const _UTp = "UploadType";
const _V = "Value";
const _VCC = "ValidateCloudConnector";
const _VCCR = "ValidateCloudConnectorRequest";
const _VCCRa = "ValidateCloudConnectorResult";
const _VE = "ValidationException";
const _VF = "ValidationFindings";
const _VFL = "ValidationFindingList";
const _VFS = "ValidationFindingScope";
const _VFa = "ValidationFinding";
const _VN = "VersionName";
const _VNS = "ValidNextSteps";
const _Va = "Values";
const _Var = "Variables";
const _Ve = "Version";
const _Ven = "Vendor";
const _WD = "WithDecryption";
const _WE = "WindowExecutions";
const _WEI = "WindowExecutionId";
const _WETI = "WindowExecutionTaskIdentities";
const _WETII = "WindowExecutionTaskInvocationIdentities";
const _WI = "WindowId";
const _WIi = "WindowIdentities";
const _WM = "WarningMessage";
const _WTI = "WindowTargetId";
const _WTIi = "WindowTaskId";
const _aQE = "awsQueryError";
const _c = "client";
const _e = "error";
const _en = "entries";
const _k = "key";
const _m = "message";
const _s = "smithy.ts.sdk.synthetic.com.amazonaws.ssm";
const _se = "server";
const _v = "value";
const _vS = "valueSet";
const _xN = "xmlName";
const n0 = "com.amazonaws.ssm";
const _s_registry = new TypeRegistry(_s);
var SSMServiceException$ = [-3, _s, "SSMServiceException", 0, [], []];
_s_registry.registerError(SSMServiceException$, SSMServiceException);
const n0_registry = new TypeRegistry(n0);
var AccessDeniedException$ = [-3, n0, _ADE,
    { [_e]: _c },
    [_M],
    [0], 1
];
n0_registry.registerError(AccessDeniedException$, AccessDeniedException);
var AlreadyExistsException$ = [-3, n0, _AEE,
    { [_aQE]: [`AlreadyExistsException`, 400], [_e]: _c },
    [_M],
    [0]
];
n0_registry.registerError(AlreadyExistsException$, AlreadyExistsException);
var AssociatedInstances$ = [-3, n0, _AI,
    { [_aQE]: [`AssociatedInstances`, 400], [_e]: _c },
    [],
    []
];
n0_registry.registerError(AssociatedInstances$, AssociatedInstances);
var AssociationAlreadyExists$ = [-3, n0, _AAE,
    { [_aQE]: [`AssociationAlreadyExists`, 400], [_e]: _c },
    [],
    []
];
n0_registry.registerError(AssociationAlreadyExists$, AssociationAlreadyExists);
var AssociationDoesNotExist$ = [-3, n0, _ADNE,
    { [_aQE]: [`AssociationDoesNotExist`, 404], [_e]: _c },
    [_M],
    [0]
];
n0_registry.registerError(AssociationDoesNotExist$, AssociationDoesNotExist);
var AssociationExecutionDoesNotExist$ = [-3, n0, _AEDNE,
    { [_aQE]: [`AssociationExecutionDoesNotExist`, 404], [_e]: _c },
    [_M],
    [0]
];
n0_registry.registerError(AssociationExecutionDoesNotExist$, AssociationExecutionDoesNotExist);
var AssociationLimitExceeded$ = [-3, n0, _ALE,
    { [_aQE]: [`AssociationLimitExceeded`, 400], [_e]: _c },
    [],
    []
];
n0_registry.registerError(AssociationLimitExceeded$, AssociationLimitExceeded);
var AssociationVersionLimitExceeded$ = [-3, n0, _AVLE,
    { [_aQE]: [`AssociationVersionLimitExceeded`, 400], [_e]: _c },
    [_M],
    [0]
];
n0_registry.registerError(AssociationVersionLimitExceeded$, AssociationVersionLimitExceeded);
var AutomationDefinitionNotApprovedException$ = [-3, n0, _ADNAE,
    { [_aQE]: [`AutomationDefinitionNotApproved`, 400], [_e]: _c },
    [_M],
    [0]
];
n0_registry.registerError(AutomationDefinitionNotApprovedException$, AutomationDefinitionNotApprovedException);
var AutomationDefinitionNotFoundException$ = [-3, n0, _ADNFE,
    { [_aQE]: [`AutomationDefinitionNotFound`, 404], [_e]: _c },
    [_M],
    [0]
];
n0_registry.registerError(AutomationDefinitionNotFoundException$, AutomationDefinitionNotFoundException);
var AutomationDefinitionVersionNotFoundException$ = [-3, n0, _ADVNFE,
    { [_aQE]: [`AutomationDefinitionVersionNotFound`, 404], [_e]: _c },
    [_M],
    [0]
];
n0_registry.registerError(AutomationDefinitionVersionNotFoundException$, AutomationDefinitionVersionNotFoundException);
var AutomationExecutionLimitExceededException$ = [-3, n0, _AELEE,
    { [_aQE]: [`AutomationExecutionLimitExceeded`, 429], [_e]: _c },
    [_M],
    [0]
];
n0_registry.registerError(AutomationExecutionLimitExceededException$, AutomationExecutionLimitExceededException);
var AutomationExecutionNotFoundException$ = [-3, n0, _AENFE,
    { [_aQE]: [`AutomationExecutionNotFound`, 404], [_e]: _c },
    [_M],
    [0]
];
n0_registry.registerError(AutomationExecutionNotFoundException$, AutomationExecutionNotFoundException);
var AutomationStepNotFoundException$ = [-3, n0, _ASNFE,
    { [_aQE]: [`AutomationStepNotFoundException`, 404], [_e]: _c },
    [_M],
    [0]
];
n0_registry.registerError(AutomationStepNotFoundException$, AutomationStepNotFoundException);
var ComplianceTypeCountLimitExceededException$ = [-3, n0, _CTCLEE,
    { [_aQE]: [`ComplianceTypeCountLimitExceeded`, 400], [_e]: _c },
    [_M],
    [0]
];
n0_registry.registerError(ComplianceTypeCountLimitExceededException$, ComplianceTypeCountLimitExceededException);
var ConflictException$ = [-3, n0, _CE,
    { [_aQE]: [`ConflictException`, 409], [_e]: _c },
    [_M],
    [0]
];
n0_registry.registerError(ConflictException$, ConflictException);
var CustomSchemaCountLimitExceededException$ = [-3, n0, _CSCLEE,
    { [_aQE]: [`CustomSchemaCountLimitExceeded`, 400], [_e]: _c },
    [_M],
    [0]
];
n0_registry.registerError(CustomSchemaCountLimitExceededException$, CustomSchemaCountLimitExceededException);
var DocumentAlreadyExists$ = [-3, n0, _DAE,
    { [_aQE]: [`DocumentAlreadyExists`, 400], [_e]: _c },
    [_M],
    [0]
];
n0_registry.registerError(DocumentAlreadyExists$, DocumentAlreadyExists);
var DocumentLimitExceeded$ = [-3, n0, _DLE,
    { [_aQE]: [`DocumentLimitExceeded`, 400], [_e]: _c },
    [_M],
    [0]
];
n0_registry.registerError(DocumentLimitExceeded$, DocumentLimitExceeded);
var DocumentPermissionLimit$ = [-3, n0, _DPL,
    { [_aQE]: [`DocumentPermissionLimit`, 400], [_e]: _c },
    [_M],
    [0]
];
n0_registry.registerError(DocumentPermissionLimit$, DocumentPermissionLimit);
var DocumentVersionLimitExceeded$ = [-3, n0, _DVLE,
    { [_aQE]: [`DocumentVersionLimitExceeded`, 400], [_e]: _c },
    [_M],
    [0]
];
n0_registry.registerError(DocumentVersionLimitExceeded$, DocumentVersionLimitExceeded);
var DoesNotExistException$ = [-3, n0, _DNEE,
    { [_aQE]: [`DoesNotExistException`, 404], [_e]: _c },
    [_M],
    [0]
];
n0_registry.registerError(DoesNotExistException$, DoesNotExistException);
var DuplicateDocumentContent$ = [-3, n0, _DDC,
    { [_aQE]: [`DuplicateDocumentContent`, 400], [_e]: _c },
    [_M],
    [0]
];
n0_registry.registerError(DuplicateDocumentContent$, DuplicateDocumentContent);
var DuplicateDocumentVersionName$ = [-3, n0, _DDVN,
    { [_aQE]: [`DuplicateDocumentVersionName`, 400], [_e]: _c },
    [_M],
    [0]
];
n0_registry.registerError(DuplicateDocumentVersionName$, DuplicateDocumentVersionName);
var DuplicateInstanceId$ = [-3, n0, _DII,
    { [_aQE]: [`DuplicateInstanceId`, 404], [_e]: _c },
    [],
    []
];
n0_registry.registerError(DuplicateInstanceId$, DuplicateInstanceId);
var FeatureNotAvailableException$ = [-3, n0, _FNAE,
    { [_aQE]: [`FeatureNotAvailableException`, 400], [_e]: _c },
    [_M],
    [0]
];
n0_registry.registerError(FeatureNotAvailableException$, FeatureNotAvailableException);
var HierarchyLevelLimitExceededException$ = [-3, n0, _HLLEE,
    { [_aQE]: [`HierarchyLevelLimitExceededException`, 400], [_e]: _c },
    [_m],
    [0]
];
n0_registry.registerError(HierarchyLevelLimitExceededException$, HierarchyLevelLimitExceededException);
var HierarchyTypeMismatchException$ = [-3, n0, _HTME,
    { [_aQE]: [`HierarchyTypeMismatchException`, 400], [_e]: _c },
    [_m],
    [0]
];
n0_registry.registerError(HierarchyTypeMismatchException$, HierarchyTypeMismatchException);
var IdempotentParameterMismatch$ = [-3, n0, _IPM,
    { [_aQE]: [`IdempotentParameterMismatch`, 400], [_e]: _c },
    [_M],
    [0]
];
n0_registry.registerError(IdempotentParameterMismatch$, IdempotentParameterMismatch);
var IncompatiblePolicyException$ = [-3, n0, _IPE,
    { [_aQE]: [`IncompatiblePolicyException`, 400], [_e]: _c },
    [_m],
    [0]
];
n0_registry.registerError(IncompatiblePolicyException$, IncompatiblePolicyException);
var InternalServerError$ = [-3, n0, _ISE,
    { [_aQE]: [`InternalServerError`, 500], [_e]: _se },
    [_M],
    [0]
];
n0_registry.registerError(InternalServerError$, InternalServerError);
var InvalidActivation$ = [-3, n0, _IA,
    { [_aQE]: [`InvalidActivation`, 404], [_e]: _c },
    [_M],
    [0]
];
n0_registry.registerError(InvalidActivation$, InvalidActivation);
var InvalidActivationId$ = [-3, n0, _IAI,
    { [_aQE]: [`InvalidActivationId`, 404], [_e]: _c },
    [_M],
    [0]
];
n0_registry.registerError(InvalidActivationId$, InvalidActivationId);
var InvalidAggregatorException$ = [-3, n0, _IAE,
    { [_aQE]: [`InvalidAggregator`, 400], [_e]: _c },
    [_M],
    [0]
];
n0_registry.registerError(InvalidAggregatorException$, InvalidAggregatorException);
var InvalidAllowedPatternException$ = [-3, n0, _IAPE,
    { [_aQE]: [`InvalidAllowedPatternException`, 400], [_e]: _c },
    [_m],
    [0]
];
n0_registry.registerError(InvalidAllowedPatternException$, InvalidAllowedPatternException);
var InvalidAssociation$ = [-3, n0, _IAn,
    { [_aQE]: [`InvalidAssociation`, 400], [_e]: _c },
    [_M],
    [0]
];
n0_registry.registerError(InvalidAssociation$, InvalidAssociation);
var InvalidAssociationVersion$ = [-3, n0, _IAV,
    { [_aQE]: [`InvalidAssociationVersion`, 400], [_e]: _c },
    [_M],
    [0]
];
n0_registry.registerError(InvalidAssociationVersion$, InvalidAssociationVersion);
var InvalidAutomationExecutionParametersException$ = [-3, n0, _IAEPE,
    { [_aQE]: [`InvalidAutomationExecutionParameters`, 400], [_e]: _c },
    [_M],
    [0]
];
n0_registry.registerError(InvalidAutomationExecutionParametersException$, InvalidAutomationExecutionParametersException);
var InvalidAutomationSignalException$ = [-3, n0, _IASE,
    { [_aQE]: [`InvalidAutomationSignalException`, 400], [_e]: _c },
    [_M],
    [0]
];
n0_registry.registerError(InvalidAutomationSignalException$, InvalidAutomationSignalException);
var InvalidAutomationStatusUpdateException$ = [-3, n0, _IASUE,
    { [_aQE]: [`InvalidAutomationStatusUpdateException`, 400], [_e]: _c },
    [_M],
    [0]
];
n0_registry.registerError(InvalidAutomationStatusUpdateException$, InvalidAutomationStatusUpdateException);
var InvalidCommandId$ = [-3, n0, _ICI,
    { [_aQE]: [`InvalidCommandId`, 404], [_e]: _c },
    [],
    []
];
n0_registry.registerError(InvalidCommandId$, InvalidCommandId);
var InvalidDeleteInventoryParametersException$ = [-3, n0, _IDIPE,
    { [_aQE]: [`InvalidDeleteInventoryParameters`, 400], [_e]: _c },
    [_M],
    [0]
];
n0_registry.registerError(InvalidDeleteInventoryParametersException$, InvalidDeleteInventoryParametersException);
var InvalidDeletionIdException$ = [-3, n0, _IDIE,
    { [_aQE]: [`InvalidDeletionId`, 400], [_e]: _c },
    [_M],
    [0]
];
n0_registry.registerError(InvalidDeletionIdException$, InvalidDeletionIdException);
var InvalidDocument$ = [-3, n0, _ID,
    { [_aQE]: [`InvalidDocument`, 404], [_e]: _c },
    [_M],
    [0]
];
n0_registry.registerError(InvalidDocument$, InvalidDocument);
var InvalidDocumentContent$ = [-3, n0, _IDC,
    { [_aQE]: [`InvalidDocumentContent`, 400], [_e]: _c },
    [_M],
    [0]
];
n0_registry.registerError(InvalidDocumentContent$, InvalidDocumentContent);
var InvalidDocumentOperation$ = [-3, n0, _IDO,
    { [_aQE]: [`InvalidDocumentOperation`, 403], [_e]: _c },
    [_M],
    [0]
];
n0_registry.registerError(InvalidDocumentOperation$, InvalidDocumentOperation);
var InvalidDocumentSchemaVersion$ = [-3, n0, _IDSV,
    { [_aQE]: [`InvalidDocumentSchemaVersion`, 400], [_e]: _c },
    [_M],
    [0]
];
n0_registry.registerError(InvalidDocumentSchemaVersion$, InvalidDocumentSchemaVersion);
var InvalidDocumentType$ = [-3, n0, _IDT,
    { [_aQE]: [`InvalidDocumentType`, 400], [_e]: _c },
    [_M],
    [0]
];
n0_registry.registerError(InvalidDocumentType$, InvalidDocumentType);
var InvalidDocumentVersion$ = [-3, n0, _IDV,
    { [_aQE]: [`InvalidDocumentVersion`, 400], [_e]: _c },
    [_M],
    [0]
];
n0_registry.registerError(InvalidDocumentVersion$, InvalidDocumentVersion);
var InvalidFilter$ = [-3, n0, _IF,
    { [_aQE]: [`InvalidFilter`, 441], [_e]: _c },
    [_M],
    [0]
];
n0_registry.registerError(InvalidFilter$, InvalidFilter);
var InvalidFilterKey$ = [-3, n0, _IFK,
    { [_aQE]: [`InvalidFilterKey`, 400], [_e]: _c },
    [],
    []
];
n0_registry.registerError(InvalidFilterKey$, InvalidFilterKey);
var InvalidFilterOption$ = [-3, n0, _IFO,
    { [_aQE]: [`InvalidFilterOption`, 400], [_e]: _c },
    [_m],
    [0]
];
n0_registry.registerError(InvalidFilterOption$, InvalidFilterOption);
var InvalidFilterValue$ = [-3, n0, _IFV,
    { [_aQE]: [`InvalidFilterValue`, 400], [_e]: _c },
    [_M],
    [0]
];
n0_registry.registerError(InvalidFilterValue$, InvalidFilterValue);
var InvalidInstanceId$ = [-3, n0, _III,
    { [_aQE]: [`InvalidInstanceId`, 404], [_e]: _c },
    [_M],
    [0]
];
n0_registry.registerError(InvalidInstanceId$, InvalidInstanceId);
var InvalidInstanceInformationFilterValue$ = [-3, n0, _IIIFV,
    { [_aQE]: [`InvalidInstanceInformationFilterValue`, 400], [_e]: _c },
    [_m],
    [0]
];
n0_registry.registerError(InvalidInstanceInformationFilterValue$, InvalidInstanceInformationFilterValue);
var InvalidInstancePropertyFilterValue$ = [-3, n0, _IIPFV,
    { [_aQE]: [`InvalidInstancePropertyFilterValue`, 400], [_e]: _c },
    [_m],
    [0]
];
n0_registry.registerError(InvalidInstancePropertyFilterValue$, InvalidInstancePropertyFilterValue);
var InvalidInventoryGroupException$ = [-3, n0, _IIGE,
    { [_aQE]: [`InvalidInventoryGroup`, 400], [_e]: _c },
    [_M],
    [0]
];
n0_registry.registerError(InvalidInventoryGroupException$, InvalidInventoryGroupException);
var InvalidInventoryItemContextException$ = [-3, n0, _IIICE,
    { [_aQE]: [`InvalidInventoryItemContext`, 400], [_e]: _c },
    [_M],
    [0]
];
n0_registry.registerError(InvalidInventoryItemContextException$, InvalidInventoryItemContextException);
var InvalidInventoryRequestException$ = [-3, n0, _IIRE,
    { [_aQE]: [`InvalidInventoryRequest`, 400], [_e]: _c },
    [_M],
    [0]
];
n0_registry.registerError(InvalidInventoryRequestException$, InvalidInventoryRequestException);
var InvalidItemContentException$ = [-3, n0, _IICE,
    { [_aQE]: [`InvalidItemContent`, 400], [_e]: _c },
    [_TN, _M],
    [0, 0]
];
n0_registry.registerError(InvalidItemContentException$, InvalidItemContentException);
var InvalidKeyId$ = [-3, n0, _IKI,
    { [_aQE]: [`InvalidKeyId`, 400], [_e]: _c },
    [_m],
    [0]
];
n0_registry.registerError(InvalidKeyId$, InvalidKeyId);
var InvalidNextToken$ = [-3, n0, _INT,
    { [_aQE]: [`InvalidNextToken`, 400], [_e]: _c },
    [_M],
    [0]
];
n0_registry.registerError(InvalidNextToken$, InvalidNextToken);
var InvalidNotificationConfig$ = [-3, n0, _INC,
    { [_aQE]: [`InvalidNotificationConfig`, 400], [_e]: _c },
    [_M],
    [0]
];
n0_registry.registerError(InvalidNotificationConfig$, InvalidNotificationConfig);
var InvalidOptionException$ = [-3, n0, _IOE,
    { [_aQE]: [`InvalidOption`, 400], [_e]: _c },
    [_M],
    [0]
];
n0_registry.registerError(InvalidOptionException$, InvalidOptionException);
var InvalidOutputFolder$ = [-3, n0, _IOF,
    { [_aQE]: [`InvalidOutputFolder`, 400], [_e]: _c },
    [],
    []
];
n0_registry.registerError(InvalidOutputFolder$, InvalidOutputFolder);
var InvalidOutputLocation$ = [-3, n0, _IOL,
    { [_aQE]: [`InvalidOutputLocation`, 400], [_e]: _c },
    [],
    []
];
n0_registry.registerError(InvalidOutputLocation$, InvalidOutputLocation);
var InvalidParameters$ = [-3, n0, _IP,
    { [_aQE]: [`InvalidParameters`, 400], [_e]: _c },
    [_M],
    [0]
];
n0_registry.registerError(InvalidParameters$, InvalidParameters);
var InvalidPermissionType$ = [-3, n0, _IPT,
    { [_aQE]: [`InvalidPermissionType`, 400], [_e]: _c },
    [_M],
    [0]
];
n0_registry.registerError(InvalidPermissionType$, InvalidPermissionType);
var InvalidPluginName$ = [-3, n0, _IPN,
    { [_aQE]: [`InvalidPluginName`, 404], [_e]: _c },
    [],
    []
];
n0_registry.registerError(InvalidPluginName$, InvalidPluginName);
var InvalidPolicyAttributeException$ = [-3, n0, _IPAE,
    { [_aQE]: [`InvalidPolicyAttributeException`, 400], [_e]: _c },
    [_m],
    [0]
];
n0_registry.registerError(InvalidPolicyAttributeException$, InvalidPolicyAttributeException);
var InvalidPolicyTypeException$ = [-3, n0, _IPTE,
    { [_aQE]: [`InvalidPolicyTypeException`, 400], [_e]: _c },
    [_m],
    [0]
];
n0_registry.registerError(InvalidPolicyTypeException$, InvalidPolicyTypeException);
var InvalidResourceId$ = [-3, n0, _IRI,
    { [_aQE]: [`InvalidResourceId`, 400], [_e]: _c },
    [],
    []
];
n0_registry.registerError(InvalidResourceId$, InvalidResourceId);
var InvalidResourceType$ = [-3, n0, _IRT,
    { [_aQE]: [`InvalidResourceType`, 400], [_e]: _c },
    [],
    []
];
n0_registry.registerError(InvalidResourceType$, InvalidResourceType);
var InvalidResultAttributeException$ = [-3, n0, _IRAE,
    { [_aQE]: [`InvalidResultAttribute`, 400], [_e]: _c },
    [_M],
    [0]
];
n0_registry.registerError(InvalidResultAttributeException$, InvalidResultAttributeException);
var InvalidRole$ = [-3, n0, _IR,
    { [_aQE]: [`InvalidRole`, 400], [_e]: _c },
    [_M],
    [0]
];
n0_registry.registerError(InvalidRole$, InvalidRole);
var InvalidSchedule$ = [-3, n0, _IS,
    { [_aQE]: [`InvalidSchedule`, 400], [_e]: _c },
    [_M],
    [0]
];
n0_registry.registerError(InvalidSchedule$, InvalidSchedule);
var InvalidTag$ = [-3, n0, _IT,
    { [_aQE]: [`InvalidTag`, 400], [_e]: _c },
    [_M],
    [0]
];
n0_registry.registerError(InvalidTag$, InvalidTag);
var InvalidTarget$ = [-3, n0, _ITn,
    { [_aQE]: [`InvalidTarget`, 400], [_e]: _c },
    [_M],
    [0]
];
n0_registry.registerError(InvalidTarget$, InvalidTarget);
var InvalidTargetMaps$ = [-3, n0, _ITM,
    { [_aQE]: [`InvalidTargetMaps`, 400], [_e]: _c },
    [_M],
    [0]
];
n0_registry.registerError(InvalidTargetMaps$, InvalidTargetMaps);
var InvalidTypeNameException$ = [-3, n0, _ITNE,
    { [_aQE]: [`InvalidTypeName`, 400], [_e]: _c },
    [_M],
    [0]
];
n0_registry.registerError(InvalidTypeNameException$, InvalidTypeNameException);
var InvalidUpdate$ = [-3, n0, _IU,
    { [_aQE]: [`InvalidUpdate`, 400], [_e]: _c },
    [_M],
    [0]
];
n0_registry.registerError(InvalidUpdate$, InvalidUpdate);
var InvocationDoesNotExist$ = [-3, n0, _IDNE,
    { [_aQE]: [`InvocationDoesNotExist`, 400], [_e]: _c },
    [],
    []
];
n0_registry.registerError(InvocationDoesNotExist$, InvocationDoesNotExist);
var ItemContentMismatchException$ = [-3, n0, _ICME,
    { [_aQE]: [`ItemContentMismatch`, 400], [_e]: _c },
    [_TN, _M],
    [0, 0]
];
n0_registry.registerError(ItemContentMismatchException$, ItemContentMismatchException);
var ItemSizeLimitExceededException$ = [-3, n0, _ISLEE,
    { [_aQE]: [`ItemSizeLimitExceeded`, 400], [_e]: _c },
    [_TN, _M],
    [0, 0]
];
n0_registry.registerError(ItemSizeLimitExceededException$, ItemSizeLimitExceededException);
var MalformedResourcePolicyDocumentException$ = [-3, n0, _MRPDE,
    { [_aQE]: [`MalformedResourcePolicyDocumentException`, 400], [_e]: _c },
    [_M],
    [0]
];
n0_registry.registerError(MalformedResourcePolicyDocumentException$, MalformedResourcePolicyDocumentException);
var MaxDocumentSizeExceeded$ = [-3, n0, _MDSE,
    { [_aQE]: [`MaxDocumentSizeExceeded`, 400], [_e]: _c },
    [_M],
    [0]
];
n0_registry.registerError(MaxDocumentSizeExceeded$, MaxDocumentSizeExceeded);
var NoLongerSupportedException$ = [-3, n0, _NLSE,
    { [_aQE]: [`NoLongerSupported`, 400], [_e]: _c },
    [_M],
    [0]
];
n0_registry.registerError(NoLongerSupportedException$, NoLongerSupportedException);
var OpsItemAccessDeniedException$ = [-3, n0, _OIADE,
    { [_aQE]: [`OpsItemAccessDeniedException`, 403], [_e]: _c },
    [_M],
    [0]
];
n0_registry.registerError(OpsItemAccessDeniedException$, OpsItemAccessDeniedException);
var OpsItemAlreadyExistsException$ = [-3, n0, _OIAEE,
    { [_aQE]: [`OpsItemAlreadyExistsException`, 400], [_e]: _c },
    [_M, _OII],
    [0, 0]
];
n0_registry.registerError(OpsItemAlreadyExistsException$, OpsItemAlreadyExistsException);
var OpsItemConflictException$ = [-3, n0, _OICE,
    { [_aQE]: [`OpsItemConflictException`, 409], [_e]: _c },
    [_M],
    [0]
];
n0_registry.registerError(OpsItemConflictException$, OpsItemConflictException);
var OpsItemInvalidParameterException$ = [-3, n0, _OIIPE,
    { [_aQE]: [`OpsItemInvalidParameterException`, 400], [_e]: _c },
    [_PN, _M],
    [64 | 0, 0]
];
n0_registry.registerError(OpsItemInvalidParameterException$, OpsItemInvalidParameterException);
var OpsItemLimitExceededException$ = [-3, n0, _OILEE,
    { [_aQE]: [`OpsItemLimitExceededException`, 400], [_e]: _c },
    [_RT, _L, _LT, _M],
    [64 | 0, 1, 0, 0]
];
n0_registry.registerError(OpsItemLimitExceededException$, OpsItemLimitExceededException);
var OpsItemNotFoundException$ = [-3, n0, _OINFE,
    { [_aQE]: [`OpsItemNotFoundException`, 400], [_e]: _c },
    [_M],
    [0]
];
n0_registry.registerError(OpsItemNotFoundException$, OpsItemNotFoundException);
var OpsItemRelatedItemAlreadyExistsException$ = [-3, n0, _OIRIAEE,
    { [_aQE]: [`OpsItemRelatedItemAlreadyExistsException`, 400], [_e]: _c },
    [_M, _RU, _OII],
    [0, 0, 0]
];
n0_registry.registerError(OpsItemRelatedItemAlreadyExistsException$, OpsItemRelatedItemAlreadyExistsException);
var OpsItemRelatedItemAssociationNotFoundException$ = [-3, n0, _OIRIANFE,
    { [_aQE]: [`OpsItemRelatedItemAssociationNotFoundException`, 400], [_e]: _c },
    [_M],
    [0]
];
n0_registry.registerError(OpsItemRelatedItemAssociationNotFoundException$, OpsItemRelatedItemAssociationNotFoundException);
var OpsMetadataAlreadyExistsException$ = [-3, n0, _OMAEE,
    { [_aQE]: [`OpsMetadataAlreadyExistsException`, 400], [_e]: _c },
    [_m],
    [0]
];
n0_registry.registerError(OpsMetadataAlreadyExistsException$, OpsMetadataAlreadyExistsException);
var OpsMetadataInvalidArgumentException$ = [-3, n0, _OMIAE,
    { [_aQE]: [`OpsMetadataInvalidArgumentException`, 400], [_e]: _c },
    [_m],
    [0]
];
n0_registry.registerError(OpsMetadataInvalidArgumentException$, OpsMetadataInvalidArgumentException);
var OpsMetadataKeyLimitExceededException$ = [-3, n0, _OMKLEE,
    { [_aQE]: [`OpsMetadataKeyLimitExceededException`, 429], [_e]: _c },
    [_m],
    [0]
];
n0_registry.registerError(OpsMetadataKeyLimitExceededException$, OpsMetadataKeyLimitExceededException);
var OpsMetadataLimitExceededException$ = [-3, n0, _OMLEE,
    { [_aQE]: [`OpsMetadataLimitExceededException`, 429], [_e]: _c },
    [_m],
    [0]
];
n0_registry.registerError(OpsMetadataLimitExceededException$, OpsMetadataLimitExceededException);
var OpsMetadataNotFoundException$ = [-3, n0, _OMNFE,
    { [_aQE]: [`OpsMetadataNotFoundException`, 404], [_e]: _c },
    [_m],
    [0]
];
n0_registry.registerError(OpsMetadataNotFoundException$, OpsMetadataNotFoundException);
var OpsMetadataTooManyUpdatesException$ = [-3, n0, _OMTMUE,
    { [_aQE]: [`OpsMetadataTooManyUpdatesException`, 429], [_e]: _c },
    [_m],
    [0]
];
n0_registry.registerError(OpsMetadataTooManyUpdatesException$, OpsMetadataTooManyUpdatesException);
var ParameterAlreadyExists$ = [-3, n0, _PAE,
    { [_aQE]: [`ParameterAlreadyExists`, 400], [_e]: _c },
    [_m],
    [0]
];
n0_registry.registerError(ParameterAlreadyExists$, ParameterAlreadyExists);
var ParameterLimitExceeded$ = [-3, n0, _PLE,
    { [_aQE]: [`ParameterLimitExceeded`, 429], [_e]: _c },
    [_m],
    [0]
];
n0_registry.registerError(ParameterLimitExceeded$, ParameterLimitExceeded);
var ParameterMaxVersionLimitExceeded$ = [-3, n0, _PMVLE,
    { [_aQE]: [`ParameterMaxVersionLimitExceeded`, 400], [_e]: _c },
    [_m],
    [0]
];
n0_registry.registerError(ParameterMaxVersionLimitExceeded$, ParameterMaxVersionLimitExceeded);
var ParameterNotFound$ = [-3, n0, _PNF,
    { [_aQE]: [`ParameterNotFound`, 404], [_e]: _c },
    [_m],
    [0]
];
n0_registry.registerError(ParameterNotFound$, ParameterNotFound);
var ParameterPatternMismatchException$ = [-3, n0, _PPME,
    { [_aQE]: [`ParameterPatternMismatchException`, 400], [_e]: _c },
    [_m],
    [0]
];
n0_registry.registerError(ParameterPatternMismatchException$, ParameterPatternMismatchException);
var ParameterVersionLabelLimitExceeded$ = [-3, n0, _PVLLE,
    { [_aQE]: [`ParameterVersionLabelLimitExceeded`, 400], [_e]: _c },
    [_m],
    [0]
];
n0_registry.registerError(ParameterVersionLabelLimitExceeded$, ParameterVersionLabelLimitExceeded);
var ParameterVersionNotFound$ = [-3, n0, _PVNF,
    { [_aQE]: [`ParameterVersionNotFound`, 400], [_e]: _c },
    [_m],
    [0]
];
n0_registry.registerError(ParameterVersionNotFound$, ParameterVersionNotFound);
var PoliciesLimitExceededException$ = [-3, n0, _PLEE,
    { [_aQE]: [`PoliciesLimitExceededException`, 400], [_e]: _c },
    [_m],
    [0]
];
n0_registry.registerError(PoliciesLimitExceededException$, PoliciesLimitExceededException);
var ResourceDataSyncAlreadyExistsException$ = [-3, n0, _RDSAEE,
    { [_aQE]: [`ResourceDataSyncAlreadyExists`, 400], [_e]: _c },
    [_SN],
    [0]
];
n0_registry.registerError(ResourceDataSyncAlreadyExistsException$, ResourceDataSyncAlreadyExistsException);
var ResourceDataSyncConflictException$ = [-3, n0, _RDSCE,
    { [_aQE]: [`ResourceDataSyncConflictException`, 409], [_e]: _c },
    [_M],
    [0]
];
n0_registry.registerError(ResourceDataSyncConflictException$, ResourceDataSyncConflictException);
var ResourceDataSyncCountExceededException$ = [-3, n0, _RDSCEE,
    { [_aQE]: [`ResourceDataSyncCountExceeded`, 400], [_e]: _c },
    [_M],
    [0]
];
n0_registry.registerError(ResourceDataSyncCountExceededException$, ResourceDataSyncCountExceededException);
var ResourceDataSyncInvalidConfigurationException$ = [-3, n0, _RDSICE,
    { [_aQE]: [`ResourceDataSyncInvalidConfiguration`, 400], [_e]: _c },
    [_M],
    [0]
];
n0_registry.registerError(ResourceDataSyncInvalidConfigurationException$, ResourceDataSyncInvalidConfigurationException);
var ResourceDataSyncNotFoundException$ = [-3, n0, _RDSNFE,
    { [_aQE]: [`ResourceDataSyncNotFound`, 404], [_e]: _c },
    [_SN, _ST, _M],
    [0, 0, 0]
];
n0_registry.registerError(ResourceDataSyncNotFoundException$, ResourceDataSyncNotFoundException);
var ResourceInUseException$ = [-3, n0, _RIUE,
    { [_aQE]: [`ResourceInUseException`, 400], [_e]: _c },
    [_M],
    [0]
];
n0_registry.registerError(ResourceInUseException$, ResourceInUseException);
var ResourceLimitExceededException$ = [-3, n0, _RLEE,
    { [_aQE]: [`ResourceLimitExceededException`, 400], [_e]: _c },
    [_M],
    [0]
];
n0_registry.registerError(ResourceLimitExceededException$, ResourceLimitExceededException);
var ResourceNotFoundException$ = [-3, n0, _RNFE,
    { [_aQE]: [`ResourceNotFoundException`, 404], [_e]: _c },
    [_M],
    [0]
];
n0_registry.registerError(ResourceNotFoundException$, ResourceNotFoundException);
var ResourcePolicyConflictException$ = [-3, n0, _RPCE,
    { [_aQE]: [`ResourcePolicyConflictException`, 400], [_e]: _c },
    [_M],
    [0]
];
n0_registry.registerError(ResourcePolicyConflictException$, ResourcePolicyConflictException);
var ResourcePolicyInvalidParameterException$ = [-3, n0, _RPIPE,
    { [_aQE]: [`ResourcePolicyInvalidParameterException`, 400], [_e]: _c },
    [_PN, _M],
    [64 | 0, 0]
];
n0_registry.registerError(ResourcePolicyInvalidParameterException$, ResourcePolicyInvalidParameterException);
var ResourcePolicyLimitExceededException$ = [-3, n0, _RPLEE,
    { [_aQE]: [`ResourcePolicyLimitExceededException`, 400], [_e]: _c },
    [_L, _LT, _M],
    [1, 0, 0]
];
n0_registry.registerError(ResourcePolicyLimitExceededException$, ResourcePolicyLimitExceededException);
var ResourcePolicyNotFoundException$ = [-3, n0, _RPNFE,
    { [_aQE]: [`ResourcePolicyNotFoundException`, 404], [_e]: _c },
    [_M],
    [0]
];
n0_registry.registerError(ResourcePolicyNotFoundException$, ResourcePolicyNotFoundException);
var ServiceQuotaExceededException$ = [-3, n0, _SQEE,
    { [_e]: _c },
    [_M, _QC, _SC, _RI, _RTe],
    [0, 0, 0, 0, 0], 3
];
n0_registry.registerError(ServiceQuotaExceededException$, ServiceQuotaExceededException);
var ServiceSettingNotFound$ = [-3, n0, _SSNF,
    { [_aQE]: [`ServiceSettingNotFound`, 400], [_e]: _c },
    [_M],
    [0]
];
n0_registry.registerError(ServiceSettingNotFound$, ServiceSettingNotFound);
var StatusUnchanged$ = [-3, n0, _SU,
    { [_aQE]: [`StatusUnchanged`, 400], [_e]: _c },
    [],
    []
];
n0_registry.registerError(StatusUnchanged$, StatusUnchanged);
var SubTypeCountLimitExceededException$ = [-3, n0, _STCLEE,
    { [_aQE]: [`SubTypeCountLimitExceeded`, 400], [_e]: _c },
    [_M],
    [0]
];
n0_registry.registerError(SubTypeCountLimitExceededException$, SubTypeCountLimitExceededException);
var TargetInUseException$ = [-3, n0, _TIUE,
    { [_aQE]: [`TargetInUseException`, 400], [_e]: _c },
    [_M],
    [0]
];
n0_registry.registerError(TargetInUseException$, TargetInUseException);
var TargetNotConnected$ = [-3, n0, _TNC,
    { [_aQE]: [`TargetNotConnected`, 430], [_e]: _c },
    [_M],
    [0]
];
n0_registry.registerError(TargetNotConnected$, TargetNotConnected);
var ThrottlingException$ = [-3, n0, _TE,
    { [_e]: _c },
    [_M, _QC, _SC],
    [0, 0, 0], 1
];
n0_registry.registerError(ThrottlingException$, ThrottlingException);
var TooManyTagsError$ = [-3, n0, _TMTE,
    { [_aQE]: [`TooManyTagsError`, 400], [_e]: _c },
    [],
    []
];
n0_registry.registerError(TooManyTagsError$, TooManyTagsError);
var TooManyUpdates$ = [-3, n0, _TMU,
    { [_aQE]: [`TooManyUpdates`, 429], [_e]: _c },
    [_M],
    [0]
];
n0_registry.registerError(TooManyUpdates$, TooManyUpdates);
var TotalSizeLimitExceededException$ = [-3, n0, _TSLEE,
    { [_aQE]: [`TotalSizeLimitExceeded`, 400], [_e]: _c },
    [_M],
    [0]
];
n0_registry.registerError(TotalSizeLimitExceededException$, TotalSizeLimitExceededException);
var UnsupportedCalendarException$ = [-3, n0, _UCE,
    { [_aQE]: [`UnsupportedCalendarException`, 400], [_e]: _c },
    [_M],
    [0]
];
n0_registry.registerError(UnsupportedCalendarException$, UnsupportedCalendarException);
var UnsupportedFeatureRequiredException$ = [-3, n0, _UFRE,
    { [_aQE]: [`UnsupportedFeatureRequiredException`, 400], [_e]: _c },
    [_M],
    [0]
];
n0_registry.registerError(UnsupportedFeatureRequiredException$, UnsupportedFeatureRequiredException);
var UnsupportedInventoryItemContextException$ = [-3, n0, _UIICE,
    { [_aQE]: [`UnsupportedInventoryItemContext`, 400], [_e]: _c },
    [_TN, _M],
    [0, 0]
];
n0_registry.registerError(UnsupportedInventoryItemContextException$, UnsupportedInventoryItemContextException);
var UnsupportedInventorySchemaVersionException$ = [-3, n0, _UISVE,
    { [_aQE]: [`UnsupportedInventorySchemaVersion`, 400], [_e]: _c },
    [_M],
    [0]
];
n0_registry.registerError(UnsupportedInventorySchemaVersionException$, UnsupportedInventorySchemaVersionException);
var UnsupportedOperatingSystem$ = [-3, n0, _UOS,
    { [_aQE]: [`UnsupportedOperatingSystem`, 400], [_e]: _c },
    [_M],
    [0]
];
n0_registry.registerError(UnsupportedOperatingSystem$, UnsupportedOperatingSystem);
var UnsupportedOperationException$ = [-3, n0, _UOE,
    { [_aQE]: [`UnsupportedOperation`, 400], [_e]: _c },
    [_M],
    [0]
];
n0_registry.registerError(UnsupportedOperationException$, UnsupportedOperationException);
var UnsupportedParameterType$ = [-3, n0, _UPT,
    { [_aQE]: [`UnsupportedParameterType`, 400], [_e]: _c },
    [_m],
    [0]
];
n0_registry.registerError(UnsupportedParameterType$, UnsupportedParameterType);
var UnsupportedPlatformType$ = [-3, n0, _UPTn,
    { [_aQE]: [`UnsupportedPlatformType`, 400], [_e]: _c },
    [_M],
    [0]
];
n0_registry.registerError(UnsupportedPlatformType$, UnsupportedPlatformType);
var ValidationException$ = [-3, n0, _VE,
    { [_aQE]: [`ValidationException`, 400], [_e]: _c },
    [_M, _RC],
    [0, 0]
];
n0_registry.registerError(ValidationException$, ValidationException);
const errorTypeRegistries = [
    _s_registry,
    n0_registry,
];
var AccessKeySecretType = [0, n0, _AKST, 8, 0];
var IPAddress = [0, n0, _IPA, 8, 0];
var MaintenanceWindowDescription = [0, n0, _MWD, 8, 0];
var MaintenanceWindowExecutionTaskInvocationParameters = [0, n0, _MWETIP, 8, 0];
var MaintenanceWindowLambdaPayload = [0, n0, _MWLP, 8, 21];
var MaintenanceWindowStepFunctionsInput = [0, n0, _MWSFI, 8, 0];
var MaintenanceWindowTaskParameterValue = [0, n0, _MWTPV, 8, 0];
var OwnerInformation = [0, n0, _OI, 8, 0];
var PatchSourceConfiguration = [0, n0, _PSC, 8, 0];
var PSParameterValue = [0, n0, _PSPV, 8, 0];
var SessionTokenType = [0, n0, _STT, 8, 0];
var AccountSharingInfo$ = [3, n0, _ASI,
    0,
    [_AIc, _SDV],
    [0, 0]
];
var Activation$ = [3, n0, _A,
    0,
    [_AIct, _D, _DIN, _IRa, _RL, _RCe, _ED, _E, _CD, _T],
    [0, 0, 0, 0, 1, 1, 4, 2, 4, () => TagList]
];
var AddTagsToResourceRequest$ = [3, n0, _ATTRR,
    0,
    [_RTe, _RI, _T],
    [0, 0, () => TagList], 3
];
var AddTagsToResourceResult$ = [3, n0, _ATTRRd,
    0,
    [],
    []
];
var Alarm$ = [3, n0, _Al,
    0,
    [_N],
    [0], 1
];
var AlarmConfiguration$ = [3, n0, _AC,
    0,
    [_Ala, _IPAF],
    [() => AlarmList, 2], 1
];
var AlarmStateInformation$ = [3, n0, _ASIl,
    0,
    [_N, _S],
    [0, 0], 2
];
var AssociateOpsItemRelatedItemRequest$ = [3, n0, _AOIRIR,
    0,
    [_OII, _AT, _RTe, _RU],
    [0, 0, 0, 0], 4
];
var AssociateOpsItemRelatedItemResponse$ = [3, n0, _AOIRIRs,
    0,
    [_AIs],
    [0]
];
var Association$ = [3, n0, _As,
    0,
    [_N, _II, _AIs, _AV, _DV, _Ta, _LED, _O, _SE, _AN, _SO, _Du, _TM],
    [0, 0, 0, 0, 0, () => Targets, 4, () => AssociationOverview$, 0, 0, 1, 1, [1, n0, _TM, 0, [2, n0, _TMa, 0, 0, 64 | 0]]]
];
var AssociationDescription$ = [3, n0, _AD,
    0,
    [_N, _II, _AV, _Da, _LUAD, _St, _O, _DV, _ATPN, _P, _AIs, _Ta, _SE, _OL, _LED, _LSED, _AN, _ME, _MC, _CS, _SCy, _AOACI, _CN, _TL, _SO, _Du, _TM, _AC, _TA, _ADAR],
    [0, 0, 0, 4, 4, () => AssociationStatus$, () => AssociationOverview$, 0, 0, [() => _Parameters, 0], 0, () => Targets, 0, () => InstanceAssociationOutputLocation$, 4, 4, 0, 0, 0, 0, 0, 2, 64 | 0, () => TargetLocations, 1, 1, [1, n0, _TM, 0, [2, n0, _TMa, 0, 0, 64 | 0]], () => AlarmConfiguration$, () => AlarmStateInformationList, 0]
];
var AssociationExecution$ = [3, n0, _AE,
    0,
    [_AIs, _AV, _EI, _St, _DS, _CT, _LED, _RCBS, _AC, _TA],
    [0, 0, 0, 0, 0, 4, 4, 0, () => AlarmConfiguration$, () => AlarmStateInformationList]
];
var AssociationExecutionFilter$ = [3, n0, _AEF,
    0,
    [_K, _V, _Ty],
    [0, 0, 0], 3
];
var AssociationExecutionTarget$ = [3, n0, _AET,
    0,
    [_AIs, _AV, _EI, _RI, _RTe, _St, _DS, _LED, _OS],
    [0, 0, 0, 0, 0, 0, 0, 4, () => OutputSource$]
];
var AssociationExecutionTargetsFilter$ = [3, n0, _AETF,
    0,
    [_K, _V],
    [0, 0], 2
];
var AssociationFilter$ = [3, n0, _AF,
    0,
    [_k, _v],
    [0, 0], 2
];
var AssociationOverview$ = [3, n0, _AO,
    0,
    [_St, _DS, _ASAC],
    [0, 0, 128 | 1]
];
var AssociationStatus$ = [3, n0, _AS,
    0,
    [_Da, _N, _M, _AId],
    [4, 0, 0, 0], 3
];
var AssociationVersionInfo$ = [3, n0, _AVI,
    0,
    [_AIs, _AV, _CD, _N, _DV, _P, _Ta, _SE, _OL, _AN, _ME, _MC, _CS, _SCy, _AOACI, _CN, _TL, _SO, _Du, _TM, _ADAR],
    [0, 0, 4, 0, 0, [() => _Parameters, 0], () => Targets, 0, () => InstanceAssociationOutputLocation$, 0, 0, 0, 0, 0, 2, 64 | 0, () => TargetLocations, 1, 1, [1, n0, _TM, 0, [2, n0, _TMa, 0, 0, 64 | 0]], 0]
];
var AttachmentContent$ = [3, n0, _ACt,
    0,
    [_N, _Si, _H, _HT, _U],
    [0, 1, 0, 0, 0]
];
var AttachmentInformation$ = [3, n0, _AIt,
    0,
    [_N],
    [0]
];
var AttachmentsSource$ = [3, n0, _ASt,
    0,
    [_K, _Va, _N],
    [0, 64 | 0, 0]
];
var AutomationExecution$ = [3, n0, _AEu,
    0,
    [_AEI, _DN, _DV, _EST, _EET, _AES, _SEt, _SET, _P, _Ou, _FM, _WM, _Mo, _PAEI, _EB, _CSN, _CA, _TPN, _Ta, _TM, _RTes, _MC, _ME, _Tar, _TL, _PC, _AC, _TA, _TLURL, _ASu, _STc, _R, _OII, _AIs, _CRN, _Var],
    [0, 0, 0, 4, 4, 0, () => StepExecutionList, 2, [2, n0, _APM, 0, 0, 64 | 0], [2, n0, _APM, 0, 0, 64 | 0], 0, 0, 0, 0, 0, 0, 0, 0, () => Targets, [1, n0, _TM, 0, [2, n0, _TMa, 0, 0, 64 | 0]], () => ResolvedTargets$, 0, 0, 0, () => TargetLocations, () => ProgressCounters$, () => AlarmConfiguration$, () => AlarmStateInformationList, 0, 0, 4, () => Runbooks, 0, 0, 0, [2, n0, _APM, 0, 0, 64 | 0]]
];
var AutomationExecutionFilter$ = [3, n0, _AEFu,
    0,
    [_K, _Va],
    [0, 64 | 0], 2
];
var AutomationExecutionInputs$ = [3, n0, _AEIu,
    0,
    [_P, _TPN, _Ta, _TM, _TL, _TLURL],
    [[2, n0, _APM, 0, 0, 64 | 0], 0, () => AutomationTargets, [1, n0, _TM, 0, [2, n0, _TMa, 0, 0, 64 | 0]], () => TargetLocations, 0]
];
var AutomationExecutionMetadata$ = [3, n0, _AEM,
    0,
    [_AEI, _DN, _DV, _AES, _EST, _EET, _EB, _LF, _Ou, _Mo, _PAEI, _CSN, _CA, _FM, _WM, _TPN, _Ta, _TM, _RTes, _MC, _ME, _Tar, _ATu, _AC, _TA, _TLURL, _ASu, _STc, _R, _OII, _AIs, _CRN],
    [0, 0, 0, 0, 4, 4, 0, 0, [2, n0, _APM, 0, 0, 64 | 0], 0, 0, 0, 0, 0, 0, 0, () => Targets, [1, n0, _TM, 0, [2, n0, _TMa, 0, 0, 64 | 0]], () => ResolvedTargets$, 0, 0, 0, 0, () => AlarmConfiguration$, () => AlarmStateInformationList, 0, 0, 4, () => Runbooks, 0, 0, 0]
];
var AutomationExecutionPreview$ = [3, n0, _AEP,
    0,
    [_SP, _Re, _TP, _TAo],
    [128 | 1, 64 | 0, () => TargetPreviewList, 1]
];
var AzureConfiguration$ = [3, n0, _ACz,
    0,
    [_TI, _AIp, _TDN, _ADN, _Ta],
    [0, 0, 0, 0, () => ConfigurationTargets$], 2
];
var AzureSubscription$ = [3, n0, _ASz,
    0,
    [_I, _DNi],
    [0, 0], 1
];
var BaselineOverride$ = [3, n0, _BO,
    0,
    [_OSp, _GF, _AR, _AP, _APCL, _RP, _RPA, _APENS, _So, _ASUCS],
    [0, () => PatchFilterGroup$, () => PatchRuleGroup$, 64 | 0, 0, 64 | 0, 0, 2, [() => PatchSourceList, 0], 0]
];
var CancelCommandRequest$ = [3, n0, _CCR,
    0,
    [_CI, _IIn],
    [0, 64 | 0], 1
];
var CancelCommandResult$ = [3, n0, _CCRa,
    0,
    [],
    []
];
var CancelMaintenanceWindowExecutionRequest$ = [3, n0, _CMWER,
    0,
    [_WEI],
    [0], 1
];
var CancelMaintenanceWindowExecutionResult$ = [3, n0, _CMWERa,
    0,
    [_WEI],
    [0]
];
var CloudConnectorFilter$ = [3, n0, _CCF,
    0,
    [_FK, _FV],
    [0, 64 | 0]
];
var CloudConnectorSummary$ = [3, n0, _CCS,
    0,
    [_CCI, _DNi, _D, _RA, _CAr, _UA],
    [0, 0, 0, 0, 4, 4]
];
var CloudWatchOutputConfig$ = [3, n0, _CWOC,
    0,
    [_CWLGN, _CWOE],
    [0, 2]
];
var Command$ = [3, n0, _C,
    0,
    [_CI, _DN, _DV, _Co, _EA, _P, _IIn, _Ta, _RDT, _St, _SD, _OSR, _OSBN, _OSKP, _MC, _ME, _TC, _CC, _EC, _DTOC, _SR, _NC, _CWOC, _TS, _AC, _TA],
    [0, 0, 0, 0, 4, [() => _Parameters, 0], 64 | 0, () => Targets, 4, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, () => NotificationConfig$, () => CloudWatchOutputConfig$, 1, () => AlarmConfiguration$, () => AlarmStateInformationList]
];
var CommandFilter$ = [3, n0, _CF,
    0,
    [_k, _v],
    [0, 0], 2
];
var CommandInvocation$ = [3, n0, _CIo,
    0,
    [_CI, _II, _IN, _Co, _DN, _DV, _RDT, _St, _SD, _TO, _SOU, _SEU, _CP, _SR, _NC, _CWOC],
    [0, 0, 0, 0, 0, 0, 4, 0, 0, 0, 0, 0, () => CommandPluginList, 0, () => NotificationConfig$, () => CloudWatchOutputConfig$]
];
var CommandPlugin$ = [3, n0, _CPo,
    0,
    [_N, _St, _SD, _RCes, _RSDT, _RFDT, _Out, _SOU, _SEU, _OSR, _OSBN, _OSKP],
    [0, 0, 0, 1, 4, 4, 0, 0, 0, 0, 0, 0]
];
var ComplianceExecutionSummary$ = [3, n0, _CES,
    0,
    [_ET, _EI, _ETx],
    [4, 0, 0], 1
];
var ComplianceItem$ = [3, n0, _CIom,
    0,
    [_CTo, _RTe, _RI, _I, _Ti, _St, _Se, _ES, _De],
    [0, 0, 0, 0, 0, 0, 0, () => ComplianceExecutionSummary$, 128 | 0]
];
var ComplianceItemEntry$ = [3, n0, _CIE,
    0,
    [_Se, _St, _I, _Ti, _De],
    [0, 0, 0, 0, 128 | 0], 2
];
var ComplianceStringFilter$ = [3, n0, _CSF,
    0,
    [_K, _Va, _Ty],
    [0, [() => ComplianceStringFilterValueList, 0], 0]
];
var ComplianceSummaryItem$ = [3, n0, _CSI,
    0,
    [_CTo, _CSo, _NCS],
    [0, () => CompliantSummary$, () => NonCompliantSummary$]
];
var CompliantSummary$ = [3, n0, _CSo,
    0,
    [_CCo, _SS],
    [1, () => SeveritySummary$]
];
var CreateActivationRequest$ = [3, n0, _CAR,
    0,
    [_IRa, _D, _DIN, _RL, _ED, _T, _RM],
    [0, 0, 0, 1, 4, () => TagList, () => RegistrationMetadataList], 1
];
var CreateActivationResult$ = [3, n0, _CARr,
    0,
    [_AIct, _ACc],
    [0, 0]
];
var CreateAssociationBatchRequest$ = [3, n0, _CABR,
    0,
    [_En, _ADAR],
    [[() => CreateAssociationBatchRequestEntries, 0], 0], 1
];
var CreateAssociationBatchRequestEntry$ = [3, n0, _CABRE,
    0,
    [_N, _II, _P, _ATPN, _DV, _Ta, _SE, _OL, _AN, _ME, _MC, _CS, _SCy, _AOACI, _CN, _TL, _SO, _Du, _TM, _AC],
    [0, 0, [() => _Parameters, 0], 0, 0, () => Targets, 0, () => InstanceAssociationOutputLocation$, 0, 0, 0, 0, 0, 2, 64 | 0, () => TargetLocations, 1, 1, [1, n0, _TM, 0, [2, n0, _TMa, 0, 0, 64 | 0]], () => AlarmConfiguration$], 1
];
var CreateAssociationBatchResult$ = [3, n0, _CABRr,
    0,
    [_Su, _F],
    [[() => AssociationDescriptionList, 0], [() => FailedCreateAssociationList, 0]]
];
var CreateAssociationRequest$ = [3, n0, _CARre,
    0,
    [_N, _DV, _II, _P, _Ta, _SE, _OL, _AN, _ATPN, _ME, _MC, _CS, _SCy, _AOACI, _CN, _TL, _SO, _Du, _TM, _T, _AC, _ADAR],
    [0, 0, 0, [() => _Parameters, 0], () => Targets, 0, () => InstanceAssociationOutputLocation$, 0, 0, 0, 0, 0, 0, 2, 64 | 0, () => TargetLocations, 1, 1, [1, n0, _TM, 0, [2, n0, _TMa, 0, 0, 64 | 0]], () => TagList, () => AlarmConfiguration$, 0], 1
];
var CreateAssociationResult$ = [3, n0, _CARrea,
    0,
    [_AD],
    [[() => AssociationDescription$, 0]]
];
var CreateCloudConnectorRequest$ = [3, n0, _CCCR,
    0,
    [_DNi, _RA, _Con, _CCA, _D, _T],
    [0, 0, () => CloudConnectorConfiguration$, 0, 0, () => TagList], 4
];
var CreateCloudConnectorResult$ = [3, n0, _CCCRr,
    0,
    [_CCI],
    [0]
];
var CreateDocumentRequest$ = [3, n0, _CDR,
    0,
    [_Cont, _N, _Req, _At, _DNi, _VN, _DT, _DF, _TT, _T],
    [0, 0, () => DocumentRequiresList, () => AttachmentsSourceList, 0, 0, 0, 0, 0, () => TagList], 2
];
var CreateDocumentResult$ = [3, n0, _CDRr,
    0,
    [_DD],
    [[() => DocumentDescription$, 0]]
];
var CreateMaintenanceWindowRequest$ = [3, n0, _CMWR,
    0,
    [_N, _Sc, _Du, _Cu, _AUT, _D, _SDt, _EDn, _STch, _SO, _CTl, _T],
    [0, 0, 1, 1, 2, [() => MaintenanceWindowDescription, 0], 0, 0, 0, 1, [0, 4], () => TagList], 5
];
var CreateMaintenanceWindowResult$ = [3, n0, _CMWRr,
    0,
    [_WI],
    [0]
];
var CreateOpsItemRequest$ = [3, n0, _COIR,
    0,
    [_D, _Sou, _Ti, _OIT, _OD, _No, _Pr, _ROI, _T, _Ca, _Se, _AST, _AETc, _PST, _PET, _AIc],
    [0, 0, 0, 0, () => OpsItemOperationalData, () => OpsItemNotifications, 1, () => RelatedOpsItems, () => TagList, 0, 0, 4, 4, 4, 4, 0], 3
];
var CreateOpsItemResponse$ = [3, n0, _COIRr,
    0,
    [_OII, _OIA],
    [0, 0]
];
var CreateOpsMetadataRequest$ = [3, n0, _COMR,
    0,
    [_RI, _Me, _T],
    [0, () => MetadataMap, () => TagList], 1
];
var CreateOpsMetadataResult$ = [3, n0, _COMRr,
    0,
    [_OMA],
    [0]
];
var CreatePatchBaselineRequest$ = [3, n0, _CPBR,
    0,
    [_N, _OSp, _GF, _AR, _AP, _APCL, _APENS, _RP, _RPA, _D, _So, _ASUCS, _CTl, _T],
    [0, 0, () => PatchFilterGroup$, () => PatchRuleGroup$, 64 | 0, 0, 2, 64 | 0, 0, 0, [() => PatchSourceList, 0], 0, [0, 4], () => TagList], 1
];
var CreatePatchBaselineResult$ = [3, n0, _CPBRr,
    0,
    [_BI],
    [0]
];
var CreateResourceDataSyncRequest$ = [3, n0, _CRDSR,
    0,
    [_SN, _SDe, _ST, _SSy],
    [0, () => ResourceDataSyncS3Destination$, 0, () => ResourceDataSyncSource$], 1
];
var CreateResourceDataSyncResult$ = [3, n0, _CRDSRr,
    0,
    [],
    []
];
var Credentials$ = [3, n0, _Cr,
    0,
    [_AKI, _SAK, _STe, _ETxp],
    [0, [() => AccessKeySecretType, 0], [() => SessionTokenType, 0], 4], 4
];
var DeleteActivationRequest$ = [3, n0, _DAR,
    0,
    [_AIct],
    [0], 1
];
var DeleteActivationResult$ = [3, n0, _DARe,
    0,
    [],
    []
];
var DeleteAssociationRequest$ = [3, n0, _DARel,
    0,
    [_N, _II, _AIs],
    [0, 0, 0]
];
var DeleteAssociationResult$ = [3, n0, _DARele,
    0,
    [],
    []
];
var DeleteCloudConnectorRequest$ = [3, n0, _DCCR,
    0,
    [_CCI],
    [0], 1
];
var DeleteCloudConnectorResult$ = [3, n0, _DCCRe,
    0,
    [_CCI],
    [0]
];
var DeleteDocumentRequest$ = [3, n0, _DDR,
    0,
    [_N, _DV, _VN, _Fo],
    [0, 0, 0, 2], 1
];
var DeleteDocumentResult$ = [3, n0, _DDRe,
    0,
    [],
    []
];
var DeleteInventoryRequest$ = [3, n0, _DIR,
    0,
    [_TN, _SDO, _DR, _CTl],
    [0, 0, 2, [0, 4]], 1
];
var DeleteInventoryResult$ = [3, n0, _DIRe,
    0,
    [_DI, _TN, _DSe],
    [0, 0, () => InventoryDeletionSummary$]
];
var DeleteMaintenanceWindowRequest$ = [3, n0, _DMWR,
    0,
    [_WI],
    [0], 1
];
var DeleteMaintenanceWindowResult$ = [3, n0, _DMWRe,
    0,
    [_WI],
    [0]
];
var DeleteOpsItemRequest$ = [3, n0, _DOIR,
    0,
    [_OII],
    [0], 1
];
var DeleteOpsItemResponse$ = [3, n0, _DOIRe,
    0,
    [],
    []
];
var DeleteOpsMetadataRequest$ = [3, n0, _DOMR,
    0,
    [_OMA],
    [0], 1
];
var DeleteOpsMetadataResult$ = [3, n0, _DOMRe,
    0,
    [],
    []
];
var DeleteParameterRequest$ = [3, n0, _DPR,
    0,
    [_N],
    [0], 1
];
var DeleteParameterResult$ = [3, n0, _DPRe,
    0,
    [],
    []
];
var DeleteParametersRequest$ = [3, n0, _DPRel,
    0,
    [_Na],
    [64 | 0], 1
];
var DeleteParametersResult$ = [3, n0, _DPRele,
    0,
    [_DP, _IP],
    [64 | 0, 64 | 0]
];
var DeletePatchBaselineRequest$ = [3, n0, _DPBR,
    0,
    [_BI],
    [0], 1
];
var DeletePatchBaselineResult$ = [3, n0, _DPBRe,
    0,
    [_BI],
    [0]
];
var DeleteResourceDataSyncRequest$ = [3, n0, _DRDSR,
    0,
    [_SN, _ST],
    [0, 0], 1
];
var DeleteResourceDataSyncResult$ = [3, n0, _DRDSRe,
    0,
    [],
    []
];
var DeleteResourcePolicyRequest$ = [3, n0, _DRPR,
    0,
    [_RAe, _PI, _PH],
    [0, 0, 0], 3
];
var DeleteResourcePolicyResponse$ = [3, n0, _DRPRe,
    0,
    [],
    []
];
var DeregisterManagedInstanceRequest$ = [3, n0, _DMIR,
    0,
    [_II],
    [0], 1
];
var DeregisterManagedInstanceResult$ = [3, n0, _DMIRe,
    0,
    [],
    []
];
var DeregisterPatchBaselineForPatchGroupRequest$ = [3, n0, _DPBFPGR,
    0,
    [_BI, _PG],
    [0, 0], 2
];
var DeregisterPatchBaselineForPatchGroupResult$ = [3, n0, _DPBFPGRe,
    0,
    [_BI, _PG],
    [0, 0]
];
var DeregisterTargetFromMaintenanceWindowRequest$ = [3, n0, _DTFMWR,
    0,
    [_WI, _WTI, _Sa],
    [0, 0, 2], 2
];
var DeregisterTargetFromMaintenanceWindowResult$ = [3, n0, _DTFMWRe,
    0,
    [_WI, _WTI],
    [0, 0]
];
var DeregisterTaskFromMaintenanceWindowRequest$ = [3, n0, _DTFMWRer,
    0,
    [_WI, _WTIi],
    [0, 0], 2
];
var DeregisterTaskFromMaintenanceWindowResult$ = [3, n0, _DTFMWRere,
    0,
    [_WI, _WTIi],
    [0, 0]
];
var DescribeActivationsFilter$ = [3, n0, _DAF,
    0,
    [_FK, _FV],
    [0, 64 | 0]
];
var DescribeActivationsRequest$ = [3, n0, _DARes,
    0,
    [_Fi, _MR, _NT],
    [() => DescribeActivationsFilterList, 1, 0]
];
var DescribeActivationsResult$ = [3, n0, _DAResc,
    0,
    [_AL, _NT],
    [() => ActivationList, 0]
];
var DescribeAssociationExecutionsRequest$ = [3, n0, _DAER,
    0,
    [_AIs, _Fi, _MR, _NT],
    [0, [() => AssociationExecutionFilterList, 0], 1, 0], 1
];
var DescribeAssociationExecutionsResult$ = [3, n0, _DAERe,
    0,
    [_AEs, _NT],
    [[() => AssociationExecutionsList, 0], 0]
];
var DescribeAssociationExecutionTargetsRequest$ = [3, n0, _DAETR,
    0,
    [_AIs, _EI, _Fi, _MR, _NT],
    [0, 0, [() => AssociationExecutionTargetsFilterList, 0], 1, 0], 2
];
var DescribeAssociationExecutionTargetsResult$ = [3, n0, _DAETRe,
    0,
    [_AETs, _NT],
    [[() => AssociationExecutionTargetsList, 0], 0]
];
var DescribeAssociationRequest$ = [3, n0, _DARescr,
    0,
    [_N, _II, _AIs, _AV],
    [0, 0, 0, 0]
];
var DescribeAssociationResult$ = [3, n0, _DARescri,
    0,
    [_AD],
    [[() => AssociationDescription$, 0]]
];
var DescribeAutomationExecutionsRequest$ = [3, n0, _DAERes,
    0,
    [_Fi, _MR, _NT],
    [() => AutomationExecutionFilterList, 1, 0]
];
var DescribeAutomationExecutionsResult$ = [3, n0, _DAEResc,
    0,
    [_AEML, _NT],
    [() => AutomationExecutionMetadataList, 0]
];
var DescribeAutomationStepExecutionsRequest$ = [3, n0, _DASER,
    0,
    [_AEI, _Fi, _NT, _MR, _RO],
    [0, () => StepExecutionFilterList, 0, 1, 2], 1
];
var DescribeAutomationStepExecutionsResult$ = [3, n0, _DASERe,
    0,
    [_SEt, _NT],
    [() => StepExecutionList, 0]
];
var DescribeAvailablePatchesRequest$ = [3, n0, _DAPR,
    0,
    [_Fi, _MR, _NT],
    [() => PatchOrchestratorFilterList, 1, 0]
];
var DescribeAvailablePatchesResult$ = [3, n0, _DAPRe,
    0,
    [_Pa, _NT],
    [() => PatchList, 0]
];
var DescribeDocumentPermissionRequest$ = [3, n0, _DDPR,
    0,
    [_N, _PT, _MR, _NT],
    [0, 0, 1, 0], 2
];
var DescribeDocumentPermissionResponse$ = [3, n0, _DDPRe,
    0,
    [_AIcc, _ASIL, _NT],
    [[() => AccountIdList, 0], [() => AccountSharingInfoList, 0], 0]
];
var DescribeDocumentRequest$ = [3, n0, _DDRes,
    0,
    [_N, _DV, _VN],
    [0, 0, 0], 1
];
var DescribeDocumentResult$ = [3, n0, _DDResc,
    0,
    [_Do],
    [[() => DocumentDescription$, 0]]
];
var DescribeEffectiveInstanceAssociationsRequest$ = [3, n0, _DEIAR,
    0,
    [_II, _MR, _NT],
    [0, 1, 0], 1
];
var DescribeEffectiveInstanceAssociationsResult$ = [3, n0, _DEIARe,
    0,
    [_Ass, _NT],
    [() => InstanceAssociationList, 0]
];
var DescribeEffectivePatchesForPatchBaselineRequest$ = [3, n0, _DEPFPBR,
    0,
    [_BI, _MR, _NT],
    [0, 1, 0], 1
];
var DescribeEffectivePatchesForPatchBaselineResult$ = [3, n0, _DEPFPBRe,
    0,
    [_EP, _NT],
    [() => EffectivePatchList, 0]
];
var DescribeInstanceAssociationsStatusRequest$ = [3, n0, _DIASR,
    0,
    [_II, _MR, _NT],
    [0, 1, 0], 1
];
var DescribeInstanceAssociationsStatusResult$ = [3, n0, _DIASRe,
    0,
    [_IASI, _NT],
    [() => InstanceAssociationStatusInfos, 0]
];
var DescribeInstanceInformationRequest$ = [3, n0, _DIIR,
    0,
    [_IIFL, _Fi, _MR, _NT],
    [[() => InstanceInformationFilterList, 0], [() => InstanceInformationStringFilterList, 0], 1, 0]
];
var DescribeInstanceInformationResult$ = [3, n0, _DIIRe,
    0,
    [_IIL, _NT],
    [[() => InstanceInformationList, 0], 0]
];
var DescribeInstancePatchesRequest$ = [3, n0, _DIPR,
    0,
    [_II, _Fi, _NT, _MR],
    [0, () => PatchOrchestratorFilterList, 0, 1], 1
];
var DescribeInstancePatchesResult$ = [3, n0, _DIPRe,
    0,
    [_Pa, _NT],
    [() => PatchComplianceDataList, 0]
];
var DescribeInstancePatchStatesForPatchGroupRequest$ = [3, n0, _DIPSFPGR,
    0,
    [_PG, _Fi, _NT, _MR],
    [0, () => InstancePatchStateFilterList, 0, 1], 1
];
var DescribeInstancePatchStatesForPatchGroupResult$ = [3, n0, _DIPSFPGRe,
    0,
    [_IPS, _NT],
    [[() => InstancePatchStatesList, 0], 0]
];
var DescribeInstancePatchStatesRequest$ = [3, n0, _DIPSR,
    0,
    [_IIn, _NT, _MR],
    [64 | 0, 0, 1], 1
];
var DescribeInstancePatchStatesResult$ = [3, n0, _DIPSRe,
    0,
    [_IPS, _NT],
    [[() => InstancePatchStateList, 0], 0]
];
var DescribeInstancePropertiesRequest$ = [3, n0, _DIPRes,
    0,
    [_IPFL, _FWO, _MR, _NT],
    [[() => InstancePropertyFilterList, 0], [() => InstancePropertyStringFilterList, 0], 1, 0]
];
var DescribeInstancePropertiesResult$ = [3, n0, _DIPResc,
    0,
    [_IPn, _NT],
    [[() => InstanceProperties, 0], 0]
];
var DescribeInventoryDeletionsRequest$ = [3, n0, _DIDR,
    0,
    [_DI, _NT, _MR],
    [0, 0, 1]
];
var DescribeInventoryDeletionsResult$ = [3, n0, _DIDRe,
    0,
    [_IDn, _NT],
    [() => InventoryDeletionsList, 0]
];
var DescribeMaintenanceWindowExecutionsRequest$ = [3, n0, _DMWER,
    0,
    [_WI, _Fi, _MR, _NT],
    [0, () => MaintenanceWindowFilterList, 1, 0], 1
];
var DescribeMaintenanceWindowExecutionsResult$ = [3, n0, _DMWERe,
    0,
    [_WE, _NT],
    [() => MaintenanceWindowExecutionList, 0]
];
var DescribeMaintenanceWindowExecutionTaskInvocationsRequest$ = [3, n0, _DMWETIR,
    0,
    [_WEI, _TIa, _Fi, _MR, _NT],
    [0, 0, () => MaintenanceWindowFilterList, 1, 0], 2
];
var DescribeMaintenanceWindowExecutionTaskInvocationsResult$ = [3, n0, _DMWETIRe,
    0,
    [_WETII, _NT],
    [[() => MaintenanceWindowExecutionTaskInvocationIdentityList, 0], 0]
];
var DescribeMaintenanceWindowExecutionTasksRequest$ = [3, n0, _DMWETR,
    0,
    [_WEI, _Fi, _MR, _NT],
    [0, () => MaintenanceWindowFilterList, 1, 0], 1
];
var DescribeMaintenanceWindowExecutionTasksResult$ = [3, n0, _DMWETRe,
    0,
    [_WETI, _NT],
    [() => MaintenanceWindowExecutionTaskIdentityList, 0]
];
var DescribeMaintenanceWindowScheduleRequest$ = [3, n0, _DMWSR,
    0,
    [_WI, _Ta, _RTe, _Fi, _MR, _NT],
    [0, () => Targets, 0, () => PatchOrchestratorFilterList, 1, 0]
];
var DescribeMaintenanceWindowScheduleResult$ = [3, n0, _DMWSRe,
    0,
    [_SWE, _NT],
    [() => ScheduledWindowExecutionList, 0]
];
var DescribeMaintenanceWindowsForTargetRequest$ = [3, n0, _DMWFTR,
    0,
    [_Ta, _RTe, _MR, _NT],
    [() => Targets, 0, 1, 0], 2
];
var DescribeMaintenanceWindowsForTargetResult$ = [3, n0, _DMWFTRe,
    0,
    [_WIi, _NT],
    [() => MaintenanceWindowsForTargetList, 0]
];
var DescribeMaintenanceWindowsRequest$ = [3, n0, _DMWRes,
    0,
    [_Fi, _MR, _NT],
    [() => MaintenanceWindowFilterList, 1, 0]
];
var DescribeMaintenanceWindowsResult$ = [3, n0, _DMWResc,
    0,
    [_WIi, _NT],
    [[() => MaintenanceWindowIdentityList, 0], 0]
];
var DescribeMaintenanceWindowTargetsRequest$ = [3, n0, _DMWTR,
    0,
    [_WI, _Fi, _MR, _NT],
    [0, () => MaintenanceWindowFilterList, 1, 0], 1
];
var DescribeMaintenanceWindowTargetsResult$ = [3, n0, _DMWTRe,
    0,
    [_Ta, _NT],
    [[() => MaintenanceWindowTargetList, 0], 0]
];
var DescribeMaintenanceWindowTasksRequest$ = [3, n0, _DMWTRes,
    0,
    [_WI, _Fi, _MR, _NT],
    [0, () => MaintenanceWindowFilterList, 1, 0], 1
];
var DescribeMaintenanceWindowTasksResult$ = [3, n0, _DMWTResc,
    0,
    [_Tas, _NT],
    [[() => MaintenanceWindowTaskList, 0], 0]
];
var DescribeOpsItemsRequest$ = [3, n0, _DOIRes,
    0,
    [_OIF, _MR, _NT],
    [() => OpsItemFilters, 1, 0]
];
var DescribeOpsItemsResponse$ = [3, n0, _DOIResc,
    0,
    [_NT, _OIS],
    [0, () => OpsItemSummaries]
];
var DescribeParametersRequest$ = [3, n0, _DPRes,
    0,
    [_Fi, _PF, _MR, _NT, _Sh],
    [() => ParametersFilterList, () => ParameterStringFilterList, 1, 0, 2]
];
var DescribeParametersResult$ = [3, n0, _DPResc,
    0,
    [_P, _NT],
    [() => ParameterMetadataList, 0]
];
var DescribePatchBaselinesRequest$ = [3, n0, _DPBRes,
    0,
    [_Fi, _MR, _NT],
    [() => PatchOrchestratorFilterList, 1, 0]
];
var DescribePatchBaselinesResult$ = [3, n0, _DPBResc,
    0,
    [_BIa, _NT],
    [() => PatchBaselineIdentityList, 0]
];
var DescribePatchGroupsRequest$ = [3, n0, _DPGR,
    0,
    [_MR, _Fi, _NT],
    [1, () => PatchOrchestratorFilterList, 0]
];
var DescribePatchGroupsResult$ = [3, n0, _DPGRe,
    0,
    [_Ma, _NT],
    [() => PatchGroupPatchBaselineMappingList, 0]
];
var DescribePatchGroupStateRequest$ = [3, n0, _DPGSR,
    0,
    [_PG],
    [0], 1
];
var DescribePatchGroupStateResult$ = [3, n0, _DPGSRe,
    0,
    [_In, _IWIP, _IWIOP, _IWIPRP, _IWIRP, _IWMP, _IWFP, _IWNAP, _IWUNAP, _IWCNCP, _IWSNCP, _IWONCP, _IWASU],
    [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]
];
var DescribePatchPropertiesRequest$ = [3, n0, _DPPR,
    0,
    [_OSp, _Pro, _PS, _MR, _NT],
    [0, 0, 0, 1, 0], 2
];
var DescribePatchPropertiesResult$ = [3, n0, _DPPRe,
    0,
    [_Prop, _NT],
    [[1, n0, _PPL, 0, 128 | 0], 0]
];
var DescribeSessionsRequest$ = [3, n0, _DSR,
    0,
    [_S, _MR, _NT, _Fi],
    [0, 1, 0, () => SessionFilterList], 1
];
var DescribeSessionsResponse$ = [3, n0, _DSRe,
    0,
    [_Ses, _NT],
    [() => SessionList, 0]
];
var DisassociateOpsItemRelatedItemRequest$ = [3, n0, _DOIRIR,
    0,
    [_OII, _AIs],
    [0, 0], 2
];
var DisassociateOpsItemRelatedItemResponse$ = [3, n0, _DOIRIRi,
    0,
    [],
    []
];
var DocumentDefaultVersionDescription$ = [3, n0, _DDVD,
    0,
    [_N, _DVe, _DVN],
    [0, 0, 0]
];
var DocumentDescription$ = [3, n0, _DD,
    0,
    [_Sha, _H, _HT, _N, _DNi, _VN, _Ow, _CD, _St, _SI, _DV, _D, _P, _PTl, _DT, _SV, _LV, _DVe, _DF, _TT, _T, _AItt, _Req, _Au, _RIe, _AVp, _PRV, _RS, _Ca, _CEa],
    [0, 0, 0, 0, 0, 0, 0, 4, 0, 0, 0, 0, [() => DocumentParameterList, 0], [() => PlatformTypeList, 0], 0, 0, 0, 0, 0, 0, () => TagList, [() => AttachmentInformationList, 0], () => DocumentRequiresList, 0, [() => ReviewInformationList, 0], 0, 0, 0, 64 | 0, 64 | 0]
];
var DocumentFilter$ = [3, n0, _DFo,
    0,
    [_k, _v],
    [0, 0], 2
];
var DocumentIdentifier$ = [3, n0, _DIo,
    0,
    [_N, _CD, _DNi, _Ow, _VN, _PTl, _DV, _DT, _SV, _DF, _TT, _T, _Req, _RS, _Au],
    [0, 4, 0, 0, 0, [() => PlatformTypeList, 0], 0, 0, 0, 0, 0, () => TagList, () => DocumentRequiresList, 0, 0]
];
var DocumentKeyValuesFilter$ = [3, n0, _DKVF,
    0,
    [_K, _Va],
    [0, 64 | 0]
];
var DocumentMetadataResponseInfo$ = [3, n0, _DMRI,
    0,
    [_RR],
    [() => DocumentReviewerResponseList]
];
var DocumentParameter$ = [3, n0, _DPo,
    0,
    [_N, _Ty, _D, _DVef],
    [0, 0, 0, 0]
];
var DocumentRequires$ = [3, n0, _DRo,
    0,
    [_N, _Ve, _RTeq, _VN],
    [0, 0, 0, 0], 1
];
var DocumentReviewCommentSource$ = [3, n0, _DRCS,
    0,
    [_Ty, _Cont],
    [0, 0]
];
var DocumentReviewerResponseSource$ = [3, n0, _DRRS,
    0,
    [_CTr, _UT, _RS, _Co, _Rev],
    [4, 4, 0, () => DocumentReviewCommentList, 0]
];
var DocumentReviews$ = [3, n0, _DRoc,
    0,
    [_Ac, _Co],
    [0, () => DocumentReviewCommentList], 1
];
var DocumentVersionInfo$ = [3, n0, _DVI,
    0,
    [_N, _DNi, _DV, _VN, _CD, _IDVs, _DF, _St, _SI, _RS],
    [0, 0, 0, 0, 4, 2, 0, 0, 0, 0]
];
var EffectivePatch$ = [3, n0, _EPf,
    0,
    [_Pat, _PSa],
    [() => Patch$, () => PatchStatus$]
];
var FailedCreateAssociation$ = [3, n0, _FCA,
    0,
    [_Ent, _M, _Fa],
    [[() => CreateAssociationBatchRequestEntry$, 0], 0, 0]
];
var FailureDetails$ = [3, n0, _FD,
    0,
    [_FS, _FT, _De],
    [0, 0, [2, n0, _APM, 0, 0, 64 | 0]]
];
var GetAccessTokenRequest$ = [3, n0, _GATR,
    0,
    [_ARI],
    [0], 1
];
var GetAccessTokenResponse$ = [3, n0, _GATRe,
    0,
    [_Cr, _ARS],
    [[() => Credentials$, 0], 0]
];
var GetAutomationExecutionRequest$ = [3, n0, _GAER,
    0,
    [_AEI],
    [0], 1
];
var GetAutomationExecutionResult$ = [3, n0, _GAERe,
    0,
    [_AEu],
    [() => AutomationExecution$]
];
var GetCalendarStateRequest$ = [3, n0, _GCSR,
    0,
    [_CN, _ATt],
    [64 | 0, 0], 1
];
var GetCalendarStateResponse$ = [3, n0, _GCSRe,
    0,
    [_S, _ATt, _NTT],
    [0, 0, 0]
];
var GetCloudConnectorRequest$ = [3, n0, _GCCR,
    0,
    [_CCI],
    [0], 1
];
var GetCloudConnectorResult$ = [3, n0, _GCCRe,
    0,
    [_CCAl, _DNi, _D, _RA, _Con, _CCA, _CAr, _UA],
    [0, 0, 0, 0, () => CloudConnectorConfiguration$, 0, 4, 4]
];
var GetCommandInvocationRequest$ = [3, n0, _GCIR,
    0,
    [_CI, _II, _PNl],
    [0, 0, 0], 2
];
var GetCommandInvocationResult$ = [3, n0, _GCIRe,
    0,
    [_CI, _II, _Co, _DN, _DV, _PNl, _RCes, _ESDT, _EETx, _EEDT, _St, _SD, _SOC, _SOU, _SEC, _SEU, _CWOC],
    [0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, () => CloudWatchOutputConfig$]
];
var GetConnectionStatusRequest$ = [3, n0, _GCSRet,
    0,
    [_Tar],
    [0], 1
];
var GetConnectionStatusResponse$ = [3, n0, _GCSReto,
    0,
    [_Tar, _St],
    [0, 0]
];
var GetDefaultPatchBaselineRequest$ = [3, n0, _GDPBR,
    0,
    [_OSp],
    [0]
];
var GetDefaultPatchBaselineResult$ = [3, n0, _GDPBRe,
    0,
    [_BI, _OSp],
    [0, 0]
];
var GetDeployablePatchSnapshotForInstanceRequest$ = [3, n0, _GDPSFIR,
    0,
    [_II, _SIn, _BO, _USDSE],
    [0, 0, [() => BaselineOverride$, 0], 2], 2
];
var GetDeployablePatchSnapshotForInstanceResult$ = [3, n0, _GDPSFIRe,
    0,
    [_II, _SIn, _SDU, _Prod],
    [0, 0, 0, 0]
];
var GetDocumentRequest$ = [3, n0, _GDR,
    0,
    [_N, _VN, _DV, _DF],
    [0, 0, 0, 0], 1
];
var GetDocumentResult$ = [3, n0, _GDRe,
    0,
    [_N, _CD, _DNi, _VN, _DV, _St, _SI, _Cont, _DT, _DF, _Req, _ACtt, _RS],
    [0, 4, 0, 0, 0, 0, 0, 0, 0, 0, () => DocumentRequiresList, [() => AttachmentContentList, 0], 0]
];
var GetExecutionPreviewRequest$ = [3, n0, _GEPR,
    0,
    [_EPI],
    [0], 1
];
var GetExecutionPreviewResponse$ = [3, n0, _GEPRe,
    0,
    [_EPI, _EAn, _St, _SM, _EPx],
    [0, 4, 0, 0, () => ExecutionPreview$]
];
var GetInventoryRequest$ = [3, n0, _GIR,
    0,
    [_Fi, _Ag, _RAes, _NT, _MR],
    [[() => InventoryFilterList, 0], [() => InventoryAggregatorList, 0], [() => ResultAttributeList, 0], 0, 1]
];
var GetInventoryResult$ = [3, n0, _GIRe,
    0,
    [_Enti, _NT],
    [[() => InventoryResultEntityList, 0], 0]
];
var GetInventorySchemaRequest$ = [3, n0, _GISR,
    0,
    [_TN, _NT, _MR, _Agg, _STu],
    [0, 0, 1, 2, 2]
];
var GetInventorySchemaResult$ = [3, n0, _GISRe,
    0,
    [_Sch, _NT],
    [[() => InventoryItemSchemaResultList, 0], 0]
];
var GetMaintenanceWindowExecutionRequest$ = [3, n0, _GMWER,
    0,
    [_WEI],
    [0], 1
];
var GetMaintenanceWindowExecutionResult$ = [3, n0, _GMWERe,
    0,
    [_WEI, _TIas, _St, _SD, _STt, _ETn],
    [0, 64 | 0, 0, 0, 4, 4]
];
var GetMaintenanceWindowExecutionTaskInvocationRequest$ = [3, n0, _GMWETIR,
    0,
    [_WEI, _TIa, _IInv],
    [0, 0, 0], 3
];
var GetMaintenanceWindowExecutionTaskInvocationResult$ = [3, n0, _GMWETIRe,
    0,
    [_WEI, _TEI, _IInv, _EI, _TTa, _P, _St, _SD, _STt, _ETn, _OI, _WTI],
    [0, 0, 0, 0, 0, [() => MaintenanceWindowExecutionTaskInvocationParameters, 0], 0, 0, 4, 4, [() => OwnerInformation, 0], 0]
];
var GetMaintenanceWindowExecutionTaskRequest$ = [3, n0, _GMWETR,
    0,
    [_WEI, _TIa],
    [0, 0], 2
];
var GetMaintenanceWindowExecutionTaskResult$ = [3, n0, _GMWETRe,
    0,
    [_WEI, _TEI, _TAa, _SR, _Ty, _TPa, _Pr, _MC, _ME, _St, _SD, _STt, _ETn, _AC, _TA],
    [0, 0, 0, 0, 0, [() => MaintenanceWindowTaskParametersList, 0], 1, 0, 0, 0, 0, 4, 4, () => AlarmConfiguration$, () => AlarmStateInformationList]
];
var GetMaintenanceWindowRequest$ = [3, n0, _GMWR,
    0,
    [_WI],
    [0], 1
];
var GetMaintenanceWindowResult$ = [3, n0, _GMWRe,
    0,
    [_WI, _N, _D, _SDt, _EDn, _Sc, _STch, _SO, _NET, _Du, _Cu, _AUT, _Ena, _CD, _MD],
    [0, 0, [() => MaintenanceWindowDescription, 0], 0, 0, 0, 0, 1, 0, 1, 1, 2, 2, 4, 4]
];
var GetMaintenanceWindowTaskRequest$ = [3, n0, _GMWTR,
    0,
    [_WI, _WTIi],
    [0, 0], 2
];
var GetMaintenanceWindowTaskResult$ = [3, n0, _GMWTRe,
    0,
    [_WI, _WTIi, _Ta, _TAa, _SRA, _TTa, _TPa, _TIP, _Pr, _MC, _ME, _LI, _N, _D, _CB, _AC],
    [0, 0, () => Targets, 0, 0, 0, [() => MaintenanceWindowTaskParameters, 0], [() => MaintenanceWindowTaskInvocationParameters$, 0], 1, 0, 0, () => LoggingInfo$, 0, [() => MaintenanceWindowDescription, 0], 0, () => AlarmConfiguration$]
];
var GetOpsItemRequest$ = [3, n0, _GOIR,
    0,
    [_OII, _OIA],
    [0, 0], 1
];
var GetOpsItemResponse$ = [3, n0, _GOIRe,
    0,
    [_OIp],
    [() => OpsItem$]
];
var GetOpsMetadataRequest$ = [3, n0, _GOMR,
    0,
    [_OMA, _MR, _NT],
    [0, 1, 0], 1
];
var GetOpsMetadataResult$ = [3, n0, _GOMRe,
    0,
    [_RI, _Me, _NT],
    [0, () => MetadataMap, 0]
];
var GetOpsSummaryRequest$ = [3, n0, _GOSR,
    0,
    [_SN, _Fi, _Ag, _RAes, _NT, _MR],
    [0, [() => OpsFilterList, 0], [() => OpsAggregatorList, 0], [() => OpsResultAttributeList, 0], 0, 1]
];
var GetOpsSummaryResult$ = [3, n0, _GOSRe,
    0,
    [_Enti, _NT],
    [[() => OpsEntityList, 0], 0]
];
var GetParameterHistoryRequest$ = [3, n0, _GPHR,
    0,
    [_N, _WD, _MR, _NT],
    [0, 2, 1, 0], 1
];
var GetParameterHistoryResult$ = [3, n0, _GPHRe,
    0,
    [_P, _NT],
    [[() => ParameterHistoryList, 0], 0]
];
var GetParameterRequest$ = [3, n0, _GPR,
    0,
    [_N, _WD],
    [0, 2], 1
];
var GetParameterResult$ = [3, n0, _GPRe,
    0,
    [_Par],
    [[() => Parameter$, 0]]
];
var GetParametersByPathRequest$ = [3, n0, _GPBPR,
    0,
    [_Path, _Rec, _PF, _WD, _MR, _NT],
    [0, 2, () => ParameterStringFilterList, 2, 1, 0], 1
];
var GetParametersByPathResult$ = [3, n0, _GPBPRe,
    0,
    [_P, _NT],
    [[() => ParameterList, 0], 0]
];
var GetParametersRequest$ = [3, n0, _GPRet,
    0,
    [_Na, _WD],
    [64 | 0, 2], 1
];
var GetParametersResult$ = [3, n0, _GPReta,
    0,
    [_P, _IP],
    [[() => ParameterList, 0], 64 | 0]
];
var GetPatchBaselineForPatchGroupRequest$ = [3, n0, _GPBFPGR,
    0,
    [_PG, _OSp],
    [0, 0], 1
];
var GetPatchBaselineForPatchGroupResult$ = [3, n0, _GPBFPGRe,
    0,
    [_BI, _PG, _OSp],
    [0, 0, 0]
];
var GetPatchBaselineRequest$ = [3, n0, _GPBR,
    0,
    [_BI],
    [0], 1
];
var GetPatchBaselineResult$ = [3, n0, _GPBRe,
    0,
    [_BI, _N, _OSp, _GF, _AR, _AP, _APCL, _APENS, _RP, _RPA, _PGa, _CD, _MD, _D, _So, _ASUCS],
    [0, 0, 0, () => PatchFilterGroup$, () => PatchRuleGroup$, 64 | 0, 0, 2, 64 | 0, 0, 64 | 0, 4, 4, 0, [() => PatchSourceList, 0], 0]
];
var GetResourcePoliciesRequest$ = [3, n0, _GRPR,
    0,
    [_RAe, _NT, _MR],
    [0, 0, 1], 1
];
var GetResourcePoliciesResponse$ = [3, n0, _GRPRe,
    0,
    [_NT, _Po],
    [0, () => GetResourcePoliciesResponseEntries]
];
var GetResourcePoliciesResponseEntry$ = [3, n0, _GRPRE,
    0,
    [_PI, _PH, _Pol],
    [0, 0, 0]
];
var GetServiceSettingRequest$ = [3, n0, _GSSR,
    0,
    [_SIe],
    [0], 1
];
var GetServiceSettingResult$ = [3, n0, _GSSRe,
    0,
    [_SSe],
    [() => ServiceSetting$]
];
var InstanceAggregatedAssociationOverview$ = [3, n0, _IAAO,
    0,
    [_DS, _IASAC],
    [0, 128 | 1]
];
var InstanceAssociation$ = [3, n0, _IAns,
    0,
    [_AIs, _II, _Cont, _AV],
    [0, 0, 0, 0]
];
var InstanceAssociationOutputLocation$ = [3, n0, _IAOL,
    0,
    [_SL],
    [() => S3OutputLocation$]
];
var InstanceAssociationOutputUrl$ = [3, n0, _IAOU,
    0,
    [_SOUu],
    [() => S3OutputUrl$]
];
var InstanceAssociationStatusInfo$ = [3, n0, _IASIn,
    0,
    [_AIs, _N, _DV, _AV, _II, _EDx, _St, _DS, _ES, _ECr, _OU, _AN],
    [0, 0, 0, 0, 0, 4, 0, 0, 0, 0, () => InstanceAssociationOutputUrl$, 0]
];
var InstanceInfo$ = [3, n0, _IIns,
    0,
    [_ATg, _AVg, _CNo, _ISn, _IAp, _MS, _N, _PTla, _PNla, _PV, _RTe, _STo, _SIo, _SLo, _AZ, _AZI],
    [0, 0, 0, 0, [() => IPAddress, 0], 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
];
var InstanceInformation$ = [3, n0, _IInst,
    0,
    [_II, _PSi, _LPDT, _AVg, _ILV, _PTla, _PNla, _PV, _AIct, _IRa, _RD, _RTe, _N, _IPA, _CNo, _AS, _LAED, _LSAED, _AO, _SIo, _STo, _SLo],
    [0, 0, 4, 0, 2, 0, 0, 0, 0, 0, 4, 0, 0, [() => IPAddress, 0], 0, 0, 4, 4, () => InstanceAggregatedAssociationOverview$, 0, 0, 0]
];
var InstanceInformationFilter$ = [3, n0, _IIF,
    0,
    [_k, _vS],
    [0, [() => InstanceInformationFilterValueSet, 0]], 2
];
var InstanceInformationStringFilter$ = [3, n0, _IISF,
    0,
    [_K, _Va],
    [0, [() => InstanceInformationFilterValueSet, 0]], 2
];
var InstancePatchState$ = [3, n0, _IPSn,
    0,
    [_II, _PG, _BI, _OST, _OET, _Op, _SIn, _IOLn, _OI, _IC, _IOC, _IPRC, _IRC, _MCi, _FC, _UNAC, _NAC, _ASUC, _LNRIOT, _ROe, _CNCC, _SNCC, _ONCC],
    [0, 0, 0, 4, 4, 0, 0, 0, [() => OwnerInformation, 0], 1, 1, 1, 1, 1, 1, 1, 1, 1, 4, 0, 1, 1, 1], 6
];
var InstancePatchStateFilter$ = [3, n0, _IPSF,
    0,
    [_K, _Va, _Ty],
    [0, 64 | 0, 0], 3
];
var InstanceProperty$ = [3, n0, _IPns,
    0,
    [_N, _II, _ITns, _IRn, _KN, _ISns, _Ar, _IPA, _LTa, _PSi, _LPDT, _AVg, _PTla, _PNla, _PV, _AIct, _IRa, _RD, _RTe, _CNo, _AS, _LAED, _LSAED, _AO, _SIo, _STo, _SLo, _AZ],
    [0, 0, 0, 0, 0, 0, 0, [() => IPAddress, 0], 4, 0, 4, 0, 0, 0, 0, 0, 0, 4, 0, 0, 0, 4, 4, () => InstanceAggregatedAssociationOverview$, 0, 0, 0, 0]
];
var InstancePropertyFilter$ = [3, n0, _IPF,
    0,
    [_k, _vS],
    [0, [() => InstancePropertyFilterValueSet, 0]], 2
];
var InstancePropertyStringFilter$ = [3, n0, _IPSFn,
    0,
    [_K, _Va, _Ope],
    [0, [() => InstancePropertyFilterValueSet, 0], 0], 2
];
var InventoryAggregator$ = [3, n0, _IAnv,
    0,
    [_Ex, _Ag, _G],
    [0, [() => InventoryAggregatorList, 0], [() => InventoryGroupList, 0]]
];
var InventoryDeletionStatusItem$ = [3, n0, _IDSI,
    0,
    [_DI, _TN, _DST, _LS, _LSM, _DSe, _LSUT],
    [0, 0, 4, 0, 0, () => InventoryDeletionSummary$, 4]
];
var InventoryDeletionSummary$ = [3, n0, _IDS,
    0,
    [_TCo, _RCem, _SIu],
    [1, 1, () => InventoryDeletionSummaryItems]
];
var InventoryDeletionSummaryItem$ = [3, n0, _IDSIn,
    0,
    [_Ve, _Cou, _RCem],
    [0, 1, 1]
];
var InventoryFilter$ = [3, n0, _IFn,
    0,
    [_K, _Va, _Ty],
    [0, [() => InventoryFilterValueList, 0], 0], 2
];
var InventoryGroup$ = [3, n0, _IG,
    0,
    [_N, _Fi],
    [0, [() => InventoryFilterList, 0]], 2
];
var InventoryItem$ = [3, n0, _IInve,
    0,
    [_TN, _SV, _CTa, _CH, _Cont, _Conte],
    [0, 0, 0, 0, [1, n0, _IIEL, 0, 128 | 0], 128 | 0], 3
];
var InventoryItemAttribute$ = [3, n0, _IIA,
    0,
    [_N, _DTa],
    [0, 0], 2
];
var InventoryItemSchema$ = [3, n0, _IIS,
    0,
    [_TN, _Att, _Ve, _DNi],
    [0, [() => InventoryItemAttributeList, 0], 0, 0], 2
];
var InventoryResultEntity$ = [3, n0, _IRE,
    0,
    [_I, _Dat],
    [0, () => InventoryResultItemMap]
];
var InventoryResultItem$ = [3, n0, _IRIn,
    0,
    [_TN, _SV, _Cont, _CTa, _CH],
    [0, 0, [1, n0, _IIEL, 0, 128 | 0], 0, 0], 3
];
var LabelParameterVersionRequest$ = [3, n0, _LPVR,
    0,
    [_N, _La, _PVa],
    [0, 64 | 0, 1], 2
];
var LabelParameterVersionResult$ = [3, n0, _LPVRa,
    0,
    [_IL, _PVa],
    [64 | 0, 1]
];
var ListAssociationsRequest$ = [3, n0, _LAR,
    0,
    [_AFL, _MR, _NT],
    [[() => AssociationFilterList, 0], 1, 0]
];
var ListAssociationsResult$ = [3, n0, _LARi,
    0,
    [_Ass, _NT],
    [[() => AssociationList, 0], 0]
];
var ListAssociationVersionsRequest$ = [3, n0, _LAVR,
    0,
    [_AIs, _MR, _NT],
    [0, 1, 0], 1
];
var ListAssociationVersionsResult$ = [3, n0, _LAVRi,
    0,
    [_AVs, _NT],
    [[() => AssociationVersionList, 0], 0]
];
var ListCloudConnectorsRequest$ = [3, n0, _LCCR,
    0,
    [_MR, _NT, _Fi],
    [1, 0, () => CloudConnectorFilterList]
];
var ListCloudConnectorsResult$ = [3, n0, _LCCRi,
    0,
    [_CCl, _NT],
    [() => CloudConnectorSummaryList, 0]
];
var ListCommandInvocationsRequest$ = [3, n0, _LCIR,
    0,
    [_CI, _II, _MR, _NT, _Fi, _De],
    [0, 0, 1, 0, () => CommandFilterList, 2]
];
var ListCommandInvocationsResult$ = [3, n0, _LCIRi,
    0,
    [_CIomm, _NT],
    [() => CommandInvocationList, 0]
];
var ListCommandsRequest$ = [3, n0, _LCR,
    0,
    [_CI, _II, _MR, _NT, _Fi],
    [0, 0, 1, 0, () => CommandFilterList]
];
var ListCommandsResult$ = [3, n0, _LCRi,
    0,
    [_Com, _NT],
    [[() => CommandList, 0], 0]
];
var ListComplianceItemsRequest$ = [3, n0, _LCIRis,
    0,
    [_Fi, _RIes, _RT, _NT, _MR],
    [[() => ComplianceStringFilterList, 0], 64 | 0, 64 | 0, 0, 1]
];
var ListComplianceItemsResult$ = [3, n0, _LCIRist,
    0,
    [_CIomp, _NT],
    [[() => ComplianceItemList, 0], 0]
];
var ListComplianceSummariesRequest$ = [3, n0, _LCSR,
    0,
    [_Fi, _NT, _MR],
    [[() => ComplianceStringFilterList, 0], 0, 1]
];
var ListComplianceSummariesResult$ = [3, n0, _LCSRi,
    0,
    [_CSIo, _NT],
    [[() => ComplianceSummaryItemList, 0], 0]
];
var ListDocumentMetadataHistoryRequest$ = [3, n0, _LDMHR,
    0,
    [_N, _Me, _DV, _NT, _MR],
    [0, 0, 0, 0, 1], 2
];
var ListDocumentMetadataHistoryResponse$ = [3, n0, _LDMHRi,
    0,
    [_N, _DV, _Au, _Me, _NT],
    [0, 0, 0, () => DocumentMetadataResponseInfo$, 0]
];
var ListDocumentsRequest$ = [3, n0, _LDR,
    0,
    [_DFL, _Fi, _MR, _NT],
    [[() => DocumentFilterList, 0], () => DocumentKeyValuesFilterList, 1, 0]
];
var ListDocumentsResult$ = [3, n0, _LDRi,
    0,
    [_DIoc, _NT],
    [[() => DocumentIdentifierList, 0], 0]
];
var ListDocumentVersionsRequest$ = [3, n0, _LDVR,
    0,
    [_N, _MR, _NT],
    [0, 1, 0], 1
];
var ListDocumentVersionsResult$ = [3, n0, _LDVRi,
    0,
    [_DVo, _NT],
    [() => DocumentVersionList, 0]
];
var ListInventoryEntriesRequest$ = [3, n0, _LIER,
    0,
    [_II, _TN, _Fi, _NT, _MR],
    [0, 0, [() => InventoryFilterList, 0], 0, 1], 2
];
var ListInventoryEntriesResult$ = [3, n0, _LIERi,
    0,
    [_TN, _II, _SV, _CTa, _En, _NT],
    [0, 0, 0, 0, [1, n0, _IIEL, 0, 128 | 0], 0]
];
var ListNodesRequest$ = [3, n0, _LNR,
    0,
    [_SN, _Fi, _NT, _MR],
    [0, [() => NodeFilterList, 0], 0, 1]
];
var ListNodesResult$ = [3, n0, _LNRi,
    0,
    [_Nod, _NT],
    [[() => NodeList, 0], 0]
];
var ListNodesSummaryRequest$ = [3, n0, _LNSR,
    0,
    [_Ag, _SN, _Fi, _NT, _MR],
    [[() => NodeAggregatorList, 0], 0, [() => NodeFilterList, 0], 0, 1], 1
];
var ListNodesSummaryResult$ = [3, n0, _LNSRi,
    0,
    [_Sum, _NT],
    [[1, n0, _NSL, 0, 128 | 0], 0]
];
var ListOpsItemEventsRequest$ = [3, n0, _LOIER,
    0,
    [_Fi, _MR, _NT],
    [() => OpsItemEventFilters, 1, 0]
];
var ListOpsItemEventsResponse$ = [3, n0, _LOIERi,
    0,
    [_NT, _Summ],
    [0, () => OpsItemEventSummaries]
];
var ListOpsItemRelatedItemsRequest$ = [3, n0, _LOIRIR,
    0,
    [_OII, _Fi, _MR, _NT],
    [0, () => OpsItemRelatedItemsFilters, 1, 0]
];
var ListOpsItemRelatedItemsResponse$ = [3, n0, _LOIRIRi,
    0,
    [_NT, _Summ],
    [0, () => OpsItemRelatedItemSummaries]
];
var ListOpsMetadataRequest$ = [3, n0, _LOMR,
    0,
    [_Fi, _MR, _NT],
    [() => OpsMetadataFilterList, 1, 0]
];
var ListOpsMetadataResult$ = [3, n0, _LOMRi,
    0,
    [_OML, _NT],
    [() => OpsMetadataList, 0]
];
var ListResourceComplianceSummariesRequest$ = [3, n0, _LRCSR,
    0,
    [_Fi, _NT, _MR],
    [[() => ComplianceStringFilterList, 0], 0, 1]
];
var ListResourceComplianceSummariesResult$ = [3, n0, _LRCSRi,
    0,
    [_RCSI, _NT],
    [[() => ResourceComplianceSummaryItemList, 0], 0]
];
var ListResourceDataSyncRequest$ = [3, n0, _LRDSR,
    0,
    [_ST, _NT, _MR],
    [0, 0, 1]
];
var ListResourceDataSyncResult$ = [3, n0, _LRDSRi,
    0,
    [_RDSI, _NT],
    [() => ResourceDataSyncItemList, 0]
];
var ListTagsForResourceRequest$ = [3, n0, _LTFRR,
    0,
    [_RTe, _RI],
    [0, 0], 2
];
var ListTagsForResourceResult$ = [3, n0, _LTFRRi,
    0,
    [_TLa],
    [() => TagList]
];
var LoggingInfo$ = [3, n0, _LI,
    0,
    [_SBN, _SRe, _SKP],
    [0, 0, 0], 2
];
var MaintenanceWindowAutomationParameters$ = [3, n0, _MWAP,
    0,
    [_DV, _P],
    [0, [2, n0, _APM, 0, 0, 64 | 0]]
];
var MaintenanceWindowExecution$ = [3, n0, _MWE,
    0,
    [_WI, _WEI, _St, _SD, _STt, _ETn],
    [0, 0, 0, 0, 4, 4]
];
var MaintenanceWindowExecutionTaskIdentity$ = [3, n0, _MWETI,
    0,
    [_WEI, _TEI, _St, _SD, _STt, _ETn, _TAa, _TTa, _AC, _TA],
    [0, 0, 0, 0, 4, 4, 0, 0, () => AlarmConfiguration$, () => AlarmStateInformationList]
];
var MaintenanceWindowExecutionTaskInvocationIdentity$ = [3, n0, _MWETII,
    0,
    [_WEI, _TEI, _IInv, _EI, _TTa, _P, _St, _SD, _STt, _ETn, _OI, _WTI],
    [0, 0, 0, 0, 0, [() => MaintenanceWindowExecutionTaskInvocationParameters, 0], 0, 0, 4, 4, [() => OwnerInformation, 0], 0]
];
var MaintenanceWindowFilter$ = [3, n0, _MWF,
    0,
    [_K, _Va],
    [0, 64 | 0]
];
var MaintenanceWindowIdentity$ = [3, n0, _MWI,
    0,
    [_WI, _N, _D, _Ena, _Du, _Cu, _Sc, _STch, _SO, _EDn, _SDt, _NET],
    [0, 0, [() => MaintenanceWindowDescription, 0], 2, 1, 1, 0, 0, 1, 0, 0, 0]
];
var MaintenanceWindowIdentityForTarget$ = [3, n0, _MWIFT,
    0,
    [_WI, _N],
    [0, 0]
];
var MaintenanceWindowLambdaParameters$ = [3, n0, _MWLPa,
    0,
    [_CCli, _Q, _Pay],
    [0, 0, [() => MaintenanceWindowLambdaPayload, 0]]
];
var MaintenanceWindowRunCommandParameters$ = [3, n0, _MWRCP,
    0,
    [_Co, _CWOC, _DH, _DHT, _DV, _NC, _OSBN, _OSKP, _P, _SRA, _TS],
    [0, () => CloudWatchOutputConfig$, 0, 0, 0, () => NotificationConfig$, 0, 0, [() => _Parameters, 0], 0, 1]
];
var MaintenanceWindowStepFunctionsParameters$ = [3, n0, _MWSFP,
    0,
    [_Inp, _N],
    [[() => MaintenanceWindowStepFunctionsInput, 0], 0]
];
var MaintenanceWindowTarget$ = [3, n0, _MWT,
    0,
    [_WI, _WTI, _RTe, _Ta, _OI, _N, _D],
    [0, 0, 0, () => Targets, [() => OwnerInformation, 0], 0, [() => MaintenanceWindowDescription, 0]]
];
var MaintenanceWindowTask$ = [3, n0, _MWTa,
    0,
    [_WI, _WTIi, _TAa, _Ty, _Ta, _TPa, _Pr, _LI, _SRA, _MC, _ME, _N, _D, _CB, _AC],
    [0, 0, 0, 0, () => Targets, [() => MaintenanceWindowTaskParameters, 0], 1, () => LoggingInfo$, 0, 0, 0, 0, [() => MaintenanceWindowDescription, 0], 0, () => AlarmConfiguration$]
];
var MaintenanceWindowTaskInvocationParameters$ = [3, n0, _MWTIP,
    0,
    [_RCu, _Aut, _SF, _Lam],
    [[() => MaintenanceWindowRunCommandParameters$, 0], () => MaintenanceWindowAutomationParameters$, [() => MaintenanceWindowStepFunctionsParameters$, 0], [() => MaintenanceWindowLambdaParameters$, 0]]
];
var MaintenanceWindowTaskParameterValueExpression$ = [3, n0, _MWTPVE,
    8,
    [_Va],
    [[() => MaintenanceWindowTaskParameterValueList, 0]]
];
var MetadataValue$ = [3, n0, _MV,
    0,
    [_V],
    [0]
];
var ModifyDocumentPermissionRequest$ = [3, n0, _MDPR,
    0,
    [_N, _PT, _AITA, _AITR, _SDV],
    [0, 0, [() => AccountIdList, 0], [() => AccountIdList, 0], 0], 2
];
var ModifyDocumentPermissionResponse$ = [3, n0, _MDPRo,
    0,
    [],
    []
];
var Node$ = [3, n0, _Node,
    0,
    [_CTa, _I, _Ow, _Reg, _NTo],
    [4, 0, () => NodeOwnerInfo$, 0, [() => NodeType$, 0]]
];
var NodeAggregator$ = [3, n0, _NA,
    0,
    [_ATgg, _TN, _ANt, _Ag],
    [0, 0, 0, [() => NodeAggregatorList, 0]], 3
];
var NodeFilter$ = [3, n0, _NF,
    0,
    [_K, _Va, _Ty],
    [0, [() => NodeFilterValueList, 0], 0], 2
];
var NodeOwnerInfo$ = [3, n0, _NOI,
    0,
    [_AIc, _OUI, _OUP],
    [0, 0, 0]
];
var NonCompliantSummary$ = [3, n0, _NCS,
    0,
    [_NCC, _SS],
    [1, () => SeveritySummary$]
];
var NotificationConfig$ = [3, n0, _NC,
    0,
    [_NAo, _NE, _NTot],
    [0, 64 | 0, 0]
];
var OpsAggregator$ = [3, n0, _OA,
    0,
    [_ATgg, _TN, _ANt, _Va, _Fi, _Ag],
    [0, 0, 0, 128 | 0, [() => OpsFilterList, 0], [() => OpsAggregatorList, 0]]
];
var OpsEntity$ = [3, n0, _OE,
    0,
    [_I, _Dat],
    [0, () => OpsEntityItemMap]
];
var OpsEntityItem$ = [3, n0, _OEI,
    0,
    [_CTa, _Cont],
    [0, [1, n0, _OEIEL, 0, 128 | 0]]
];
var OpsFilter$ = [3, n0, _OF,
    0,
    [_K, _Va, _Ty],
    [0, [() => OpsFilterValueList, 0], 0], 2
];
var OpsItem$ = [3, n0, _OIp,
    0,
    [_CBr, _OIT, _CT, _D, _LMB, _LMT, _No, _Pr, _ROI, _St, _OII, _Ve, _Ti, _Sou, _OD, _Ca, _Se, _AST, _AETc, _PST, _PET, _OIA],
    [0, 0, 4, 0, 0, 4, () => OpsItemNotifications, 1, () => RelatedOpsItems, 0, 0, 0, 0, 0, () => OpsItemOperationalData, 0, 0, 4, 4, 4, 4, 0]
];
var OpsItemDataValue$ = [3, n0, _OIDV,
    0,
    [_V, _Ty],
    [0, 0]
];
var OpsItemEventFilter$ = [3, n0, _OIEF,
    0,
    [_K, _Va, _Ope],
    [0, 64 | 0, 0], 3
];
var OpsItemEventSummary$ = [3, n0, _OIES,
    0,
    [_OII, _EIv, _Sou, _DTe, _Det, _CBr, _CT],
    [0, 0, 0, 0, 0, () => OpsItemIdentity$, 4]
];
var OpsItemFilter$ = [3, n0, _OIFp,
    0,
    [_K, _Va, _Ope],
    [0, 64 | 0, 0], 3
];
var OpsItemIdentity$ = [3, n0, _OIIp,
    0,
    [_Arn],
    [0]
];
var OpsItemNotification$ = [3, n0, _OIN,
    0,
    [_Arn],
    [0]
];
var OpsItemRelatedItemsFilter$ = [3, n0, _OIRIF,
    0,
    [_K, _Va, _Ope],
    [0, 64 | 0, 0], 3
];
var OpsItemRelatedItemSummary$ = [3, n0, _OIRIS,
    0,
    [_OII, _AIs, _RTe, _AT, _RU, _CBr, _CT, _LMB, _LMT],
    [0, 0, 0, 0, 0, () => OpsItemIdentity$, 4, () => OpsItemIdentity$, 4]
];
var OpsItemSummary$ = [3, n0, _OISp,
    0,
    [_CBr, _CT, _LMB, _LMT, _Pr, _Sou, _St, _OII, _Ti, _OD, _Ca, _Se, _OIT, _AST, _AETc, _PST, _PET],
    [0, 4, 0, 4, 1, 0, 0, 0, 0, () => OpsItemOperationalData, 0, 0, 0, 4, 4, 4, 4]
];
var OpsMetadata$ = [3, n0, _OM,
    0,
    [_RI, _OMA, _LMD, _LMU, _CDr],
    [0, 0, 4, 0, 4]
];
var OpsMetadataFilter$ = [3, n0, _OMF,
    0,
    [_K, _Va],
    [0, 64 | 0], 2
];
var OpsResultAttribute$ = [3, n0, _ORA,
    0,
    [_TN],
    [0], 1
];
var OutputSource$ = [3, n0, _OS,
    0,
    [_OSI, _OSTu],
    [0, 0]
];
var Parameter$ = [3, n0, _Par,
    0,
    [_N, _Ty, _V, _Ve, _Sel, _SRo, _LMD, _ARN, _DTa],
    [0, 0, [() => PSParameterValue, 0], 1, 0, 0, 4, 0, 0]
];
var ParameterHistory$ = [3, n0, _PHa,
    0,
    [_N, _Ty, _KI, _LMD, _LMU, _D, _V, _APl, _Ve, _La, _Tie, _Po, _DTa],
    [0, 0, 0, 4, 0, 0, [() => PSParameterValue, 0], 0, 1, 64 | 0, 0, () => ParameterPolicyList, 0]
];
var ParameterInlinePolicy$ = [3, n0, _PIP,
    0,
    [_PTo, _PTol, _PSo],
    [0, 0, 0]
];
var ParameterMetadata$ = [3, n0, _PM,
    0,
    [_N, _ARN, _Ty, _KI, _LMD, _LMU, _D, _APl, _Ve, _Tie, _Po, _DTa],
    [0, 0, 0, 0, 4, 0, 0, 0, 1, 0, () => ParameterPolicyList, 0]
];
var ParametersFilter$ = [3, n0, _PFa,
    0,
    [_K, _Va],
    [0, 64 | 0], 2
];
var ParameterStringFilter$ = [3, n0, _PSF,
    0,
    [_K, _Opt, _Va],
    [0, 0, 64 | 0], 1
];
var ParentStepDetails$ = [3, n0, _PSD,
    0,
    [_SEI, _SNt, _Ac, _It, _IV],
    [0, 0, 0, 1, 0]
];
var Patch$ = [3, n0, _Pat,
    0,
    [_I, _RDe, _Ti, _D, _CU, _Ven, _PFr, _Prod, _Cl, _MSs, _KNb, _MN, _Lan, _AIdv, _BIu, _CVEI, _N, _Ep, _Ve, _Rel, _Arc, _Se, _Rep],
    [0, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 64 | 0, 64 | 0, 64 | 0, 0, 1, 0, 0, 0, 0, 0]
];
var PatchBaselineIdentity$ = [3, n0, _PBI,
    0,
    [_BI, _BN, _OSp, _BD, _DB],
    [0, 0, 0, 0, 2]
];
var PatchComplianceData$ = [3, n0, _PCD,
    0,
    [_Ti, _KBI, _Cl, _Se, _S, _ITnst, _CVEI],
    [0, 0, 0, 0, 0, 4, 0], 6
];
var PatchFilter$ = [3, n0, _PFat,
    0,
    [_K, _Va],
    [0, 64 | 0], 2
];
var PatchFilterGroup$ = [3, n0, _PFG,
    0,
    [_PFatc],
    [() => PatchFilterList], 1
];
var PatchGroupPatchBaselineMapping$ = [3, n0, _PGPBM,
    0,
    [_PG, _BIas],
    [0, () => PatchBaselineIdentity$]
];
var PatchOrchestratorFilter$ = [3, n0, _POF,
    0,
    [_K, _Va],
    [0, 64 | 0]
];
var PatchRule$ = [3, n0, _PR,
    0,
    [_PFG, _CL, _AAD, _AUD, _ENS],
    [() => PatchFilterGroup$, 0, 1, 0, 2], 1
];
var PatchRuleGroup$ = [3, n0, _PRG,
    0,
    [_PRa],
    [() => PatchRuleList], 1
];
var PatchSource$ = [3, n0, _PSat,
    0,
    [_N, _Produ, _Con],
    [0, 64 | 0, [() => PatchSourceConfiguration, 0]], 3
];
var PatchStatus$ = [3, n0, _PSa,
    0,
    [_DSep, _CL, _ADp],
    [0, 0, 4]
];
var ProgressCounters$ = [3, n0, _PC,
    0,
    [_TSo, _SSu, _FSa, _CSa, _TOS],
    [1, 1, 1, 1, 1]
];
var PutComplianceItemsRequest$ = [3, n0, _PCIR,
    0,
    [_RI, _RTe, _CTo, _ES, _Ite, _ICH, _UTp],
    [0, 0, 0, () => ComplianceExecutionSummary$, () => ComplianceItemEntryList, 0, 0], 5
];
var PutComplianceItemsResult$ = [3, n0, _PCIRu,
    0,
    [],
    []
];
var PutInventoryRequest$ = [3, n0, _PIR,
    0,
    [_II, _Ite],
    [0, [() => InventoryItemList, 0]], 2
];
var PutInventoryResult$ = [3, n0, _PIRu,
    0,
    [_M],
    [0]
];
var PutParameterRequest$ = [3, n0, _PPR,
    0,
    [_N, _V, _D, _Ty, _KI, _Ov, _APl, _T, _Tie, _Po, _DTa],
    [0, [() => PSParameterValue, 0], 0, 0, 0, 2, 0, () => TagList, 0, 0, 0], 2
];
var PutParameterResult$ = [3, n0, _PPRu,
    0,
    [_Ve, _Tie],
    [1, 0]
];
var PutResourcePolicyRequest$ = [3, n0, _PRPR,
    0,
    [_RAe, _Pol, _PI, _PH],
    [0, 0, 0, 0], 2
];
var PutResourcePolicyResponse$ = [3, n0, _PRPRu,
    0,
    [_PI, _PH],
    [0, 0]
];
var RegisterDefaultPatchBaselineRequest$ = [3, n0, _RDPBR,
    0,
    [_BI],
    [0], 1
];
var RegisterDefaultPatchBaselineResult$ = [3, n0, _RDPBRe,
    0,
    [_BI],
    [0]
];
var RegisterPatchBaselineForPatchGroupRequest$ = [3, n0, _RPBFPGR,
    0,
    [_BI, _PG],
    [0, 0], 2
];
var RegisterPatchBaselineForPatchGroupResult$ = [3, n0, _RPBFPGRe,
    0,
    [_BI, _PG],
    [0, 0]
];
var RegisterTargetWithMaintenanceWindowRequest$ = [3, n0, _RTWMWR,
    0,
    [_WI, _RTe, _Ta, _OI, _N, _D, _CTl],
    [0, 0, () => Targets, [() => OwnerInformation, 0], 0, [() => MaintenanceWindowDescription, 0], [0, 4]], 3
];
var RegisterTargetWithMaintenanceWindowResult$ = [3, n0, _RTWMWRe,
    0,
    [_WTI],
    [0]
];
var RegisterTaskWithMaintenanceWindowRequest$ = [3, n0, _RTWMWReg,
    0,
    [_WI, _TAa, _TTa, _Ta, _SRA, _TPa, _TIP, _Pr, _MC, _ME, _LI, _N, _D, _CTl, _CB, _AC],
    [0, 0, 0, () => Targets, 0, [() => MaintenanceWindowTaskParameters, 0], [() => MaintenanceWindowTaskInvocationParameters$, 0], 1, 0, 0, () => LoggingInfo$, 0, [() => MaintenanceWindowDescription, 0], [0, 4], 0, () => AlarmConfiguration$], 3
];
var RegisterTaskWithMaintenanceWindowResult$ = [3, n0, _RTWMWRegi,
    0,
    [_WTIi],
    [0]
];
var RegistrationMetadataItem$ = [3, n0, _RMI,
    0,
    [_K, _V],
    [0, 0], 2
];
var RelatedOpsItem$ = [3, n0, _ROIe,
    0,
    [_OII],
    [0], 1
];
var RemoveTagsFromResourceRequest$ = [3, n0, _RTFRR,
    0,
    [_RTe, _RI, _TK],
    [0, 0, 64 | 0], 3
];
var RemoveTagsFromResourceResult$ = [3, n0, _RTFRRe,
    0,
    [],
    []
];
var ResetServiceSettingRequest$ = [3, n0, _RSSR,
    0,
    [_SIe],
    [0], 1
];
var ResetServiceSettingResult$ = [3, n0, _RSSRe,
    0,
    [_SSe],
    [() => ServiceSetting$]
];
var ResolvedTargets$ = [3, n0, _RTes,
    0,
    [_PVar, _Tr],
    [64 | 0, 2]
];
var ResourceComplianceSummaryItem$ = [3, n0, _RCSIe,
    0,
    [_CTo, _RTe, _RI, _St, _OSv, _ES, _CSo, _NCS],
    [0, 0, 0, 0, 0, () => ComplianceExecutionSummary$, () => CompliantSummary$, () => NonCompliantSummary$]
];
var ResourceDataSyncAwsOrganizationsSource$ = [3, n0, _RDSAOS,
    0,
    [_OSTr, _OUr],
    [0, () => ResourceDataSyncOrganizationalUnitList], 1
];
var ResourceDataSyncDestinationDataSharing$ = [3, n0, _RDSDDS,
    0,
    [_DDST],
    [0]
];
var ResourceDataSyncItem$ = [3, n0, _RDSIe,
    0,
    [_SN, _ST, _SSy, _SDe, _LST, _LSST, _SLMT, _LS, _SCT, _LSSM],
    [0, 0, () => ResourceDataSyncSourceWithState$, () => ResourceDataSyncS3Destination$, 4, 4, 4, 0, 4, 0]
];
var ResourceDataSyncOrganizationalUnit$ = [3, n0, _RDSOU,
    0,
    [_OUI],
    [0]
];
var ResourceDataSyncS3Destination$ = [3, n0, _RDSSD,
    0,
    [_BNu, _SFy, _Reg, _Pre, _AWSKMSKARN, _DDS],
    [0, 0, 0, 0, 0, () => ResourceDataSyncDestinationDataSharing$], 3
];
var ResourceDataSyncSource$ = [3, n0, _RDSS,
    0,
    [_STo, _SRou, _AOS, _IFR, _EAODS],
    [0, 64 | 0, () => ResourceDataSyncAwsOrganizationsSource$, 2, 2], 2
];
var ResourceDataSyncSourceWithState$ = [3, n0, _RDSSWS,
    0,
    [_STo, _AOS, _SRou, _IFR, _S, _EAODS],
    [0, () => ResourceDataSyncAwsOrganizationsSource$, 64 | 0, 2, 0, 2]
];
var ResultAttribute$ = [3, n0, _RAesu,
    0,
    [_TN],
    [0], 1
];
var ResumeSessionRequest$ = [3, n0, _RSR,
    0,
    [_SIes],
    [0], 1
];
var ResumeSessionResponse$ = [3, n0, _RSRe,
    0,
    [_SIes, _TV, _SUt],
    [0, 0, 0]
];
var ReviewInformation$ = [3, n0, _RIe,
    0,
    [_RTev, _St, _Rev],
    [4, 0, 0]
];
var Runbook$ = [3, n0, _Ru,
    0,
    [_DN, _DV, _P, _TPN, _Ta, _TM, _MC, _ME, _TL],
    [0, 0, [2, n0, _APM, 0, 0, 64 | 0], 0, () => Targets, [1, n0, _TM, 0, [2, n0, _TMa, 0, 0, 64 | 0]], 0, 0, () => TargetLocations], 1
];
var S3OutputLocation$ = [3, n0, _SOL,
    0,
    [_OSR, _OSBN, _OSKP],
    [0, 0, 0]
];
var S3OutputUrl$ = [3, n0, _SOUu,
    0,
    [_OU],
    [0]
];
var ScheduledWindowExecution$ = [3, n0, _SWEc,
    0,
    [_WI, _N, _ET],
    [0, 0, 0]
];
var SendAutomationSignalRequest$ = [3, n0, _SASR,
    0,
    [_AEI, _STi, _Pay],
    [0, 0, [2, n0, _APM, 0, 0, 64 | 0]], 2
];
var SendAutomationSignalResult$ = [3, n0, _SASRe,
    0,
    [],
    []
];
var SendCommandRequest$ = [3, n0, _SCR,
    0,
    [_DN, _IIn, _Ta, _DV, _DH, _DHT, _TS, _Co, _P, _OSR, _OSBN, _OSKP, _MC, _ME, _SRA, _NC, _CWOC, _AC],
    [0, 64 | 0, () => Targets, 0, 0, 0, 1, 0, [() => _Parameters, 0], 0, 0, 0, 0, 0, 0, () => NotificationConfig$, () => CloudWatchOutputConfig$, () => AlarmConfiguration$], 1
];
var SendCommandResult$ = [3, n0, _SCRe,
    0,
    [_C],
    [[() => Command$, 0]]
];
var ServiceSetting$ = [3, n0, _SSe,
    0,
    [_SIe, _SVe, _LMD, _LMU, _ARN, _St],
    [0, 0, 4, 0, 0, 0]
];
var Session$ = [3, n0, _Sess,
    0,
    [_SIes, _Tar, _St, _SDt, _EDn, _DN, _Ow, _Rea, _De, _OU, _MSD, _ATc],
    [0, 0, 0, 4, 4, 0, 0, 0, 0, () => SessionManagerOutputUrl$, 0, 0]
];
var SessionFilter$ = [3, n0, _SFe,
    0,
    [_k, _v],
    [0, 0], 2
];
var SessionManagerOutputUrl$ = [3, n0, _SMOU,
    0,
    [_SOUu, _CWOU],
    [0, 0]
];
var SeveritySummary$ = [3, n0, _SS,
    0,
    [_CCr, _HC, _MCe, _LC, _ICn, _UC],
    [1, 1, 1, 1, 1, 1]
];
var StartAccessRequestRequest$ = [3, n0, _SARR,
    0,
    [_Rea, _Ta, _T],
    [0, () => Targets, () => TagList], 2
];
var StartAccessRequestResponse$ = [3, n0, _SARRt,
    0,
    [_ARI],
    [0]
];
var StartAssociationsOnceRequest$ = [3, n0, _SAOR,
    0,
    [_AIss],
    [64 | 0], 1
];
var StartAssociationsOnceResult$ = [3, n0, _SAORt,
    0,
    [],
    []
];
var StartAutomationExecutionRequest$ = [3, n0, _SAER,
    0,
    [_DN, _DV, _P, _CTl, _Mo, _TPN, _Ta, _TM, _MC, _ME, _TL, _T, _AC, _TLURL],
    [0, 0, [2, n0, _APM, 0, 0, 64 | 0], 0, 0, 0, () => AutomationTargets, [1, n0, _TM, 0, [2, n0, _TMa, 0, 0, 64 | 0]], 0, 0, () => TargetLocations, () => TagList, () => AlarmConfiguration$, 0], 1
];
var StartAutomationExecutionResult$ = [3, n0, _SAERt,
    0,
    [_AEI],
    [0]
];
var StartChangeRequestExecutionRequest$ = [3, n0, _SCRER,
    0,
    [_DN, _R, _STc, _DV, _P, _CRN, _CTl, _AA, _T, _SETc, _CDh],
    [0, () => Runbooks, 4, 0, [2, n0, _APM, 0, 0, 64 | 0], 0, 0, 2, () => TagList, 4, 0], 2
];
var StartChangeRequestExecutionResult$ = [3, n0, _SCRERt,
    0,
    [_AEI],
    [0]
];
var StartExecutionPreviewRequest$ = [3, n0, _SEPR,
    0,
    [_DN, _DV, _EIx],
    [0, 0, () => ExecutionInputs$], 1
];
var StartExecutionPreviewResponse$ = [3, n0, _SEPRt,
    0,
    [_EPI],
    [0]
];
var StartSessionRequest$ = [3, n0, _SSR,
    0,
    [_Tar, _DN, _Rea, _P],
    [0, 0, 0, [2, n0, _SMP, 0, 0, 64 | 0]], 1
];
var StartSessionResponse$ = [3, n0, _SSRt,
    0,
    [_SIes, _TV, _SUt],
    [0, 0, 0]
];
var StepExecution$ = [3, n0, _SEte,
    0,
    [_SNt, _Ac, _TS, _OFn, _MA, _EST, _EET, _SSt, _RCes, _Inpu, _Ou, _Res, _FM, _WM, _FD, _SEI, _OP, _IE, _NS, _ICs, _VNS, _Ta, _TLar, _TA, _PSD],
    [0, 0, 1, 0, 1, 4, 4, 0, 0, 128 | 0, [2, n0, _APM, 0, 0, 64 | 0], 0, 0, 0, () => FailureDetails$, 0, [2, n0, _APM, 0, 0, 64 | 0], 2, 0, 2, 64 | 0, () => Targets, () => TargetLocation$, () => AlarmStateInformationList, () => ParentStepDetails$]
];
var StepExecutionFilter$ = [3, n0, _SEF,
    0,
    [_K, _Va],
    [0, 64 | 0], 2
];
var StopAutomationExecutionRequest$ = [3, n0, _SAERto,
    0,
    [_AEI, _Ty],
    [0, 0], 1
];
var StopAutomationExecutionResult$ = [3, n0, _SAERtop,
    0,
    [],
    []
];
var Tag$ = [3, n0, _Tag,
    0,
    [_K, _V],
    [0, 0], 2
];
var Target$ = [3, n0, _Tar,
    0,
    [_K, _Va],
    [0, 64 | 0]
];
var TargetLocation$ = [3, n0, _TLar,
    0,
    [_Acc, _Re, _TLMC, _TLME, _ERN, _TLAC, _ICOU, _EAx, _Ta, _TMC, _TME],
    [64 | 0, 64 | 0, 0, 0, 0, () => AlarmConfiguration$, 2, 64 | 0, () => AutomationTargets, 0, 0]
];
var TargetPreview$ = [3, n0, _TPar,
    0,
    [_Cou, _TT],
    [1, 0]
];
var TerminateSessionRequest$ = [3, n0, _TSR,
    0,
    [_SIes],
    [0], 1
];
var TerminateSessionResponse$ = [3, n0, _TSRe,
    0,
    [_SIes],
    [0]
];
var UnlabelParameterVersionRequest$ = [3, n0, _UPVR,
    0,
    [_N, _PVa, _La],
    [0, 1, 64 | 0], 3
];
var UnlabelParameterVersionResult$ = [3, n0, _UPVRn,
    0,
    [_RLe, _IL],
    [64 | 0, 64 | 0]
];
var UpdateAssociationRequest$ = [3, n0, _UAR,
    0,
    [_AIs, _P, _DV, _SE, _OL, _N, _Ta, _AN, _AV, _ATPN, _ME, _MC, _CS, _SCy, _AOACI, _CN, _TL, _SO, _Du, _TM, _AC, _ADAR],
    [0, [() => _Parameters, 0], 0, 0, () => InstanceAssociationOutputLocation$, 0, () => Targets, 0, 0, 0, 0, 0, 0, 0, 2, 64 | 0, () => TargetLocations, 1, 1, [1, n0, _TM, 0, [2, n0, _TMa, 0, 0, 64 | 0]], () => AlarmConfiguration$, 0], 1
];
var UpdateAssociationResult$ = [3, n0, _UARp,
    0,
    [_AD],
    [[() => AssociationDescription$, 0]]
];
var UpdateAssociationStatusRequest$ = [3, n0, _UASR,
    0,
    [_N, _II, _AS],
    [0, 0, () => AssociationStatus$], 3
];
var UpdateAssociationStatusResult$ = [3, n0, _UASRp,
    0,
    [_AD],
    [[() => AssociationDescription$, 0]]
];
var UpdateCloudConnectorRequest$ = [3, n0, _UCCR,
    0,
    [_CCI, _DNi, _Con, _D],
    [0, 0, () => CloudConnectorConfiguration$, 0], 1
];
var UpdateCloudConnectorResult$ = [3, n0, _UCCRp,
    0,
    [_CCI],
    [0]
];
var UpdateDocumentDefaultVersionRequest$ = [3, n0, _UDDVR,
    0,
    [_N, _DV],
    [0, 0], 2
];
var UpdateDocumentDefaultVersionResult$ = [3, n0, _UDDVRp,
    0,
    [_D],
    [() => DocumentDefaultVersionDescription$]
];
var UpdateDocumentMetadataRequest$ = [3, n0, _UDMR,
    0,
    [_N, _DRoc, _DV],
    [0, () => DocumentReviews$, 0], 2
];
var UpdateDocumentMetadataResponse$ = [3, n0, _UDMRp,
    0,
    [],
    []
];
var UpdateDocumentRequest$ = [3, n0, _UDR,
    0,
    [_Cont, _N, _At, _DNi, _VN, _DV, _DF, _TT],
    [0, 0, () => AttachmentsSourceList, 0, 0, 0, 0, 0], 2
];
var UpdateDocumentResult$ = [3, n0, _UDRp,
    0,
    [_DD],
    [[() => DocumentDescription$, 0]]
];
var UpdateMaintenanceWindowRequest$ = [3, n0, _UMWR,
    0,
    [_WI, _N, _D, _SDt, _EDn, _Sc, _STch, _SO, _Du, _Cu, _AUT, _Ena, _Repl],
    [0, 0, [() => MaintenanceWindowDescription, 0], 0, 0, 0, 0, 1, 1, 1, 2, 2, 2], 1
];
var UpdateMaintenanceWindowResult$ = [3, n0, _UMWRp,
    0,
    [_WI, _N, _D, _SDt, _EDn, _Sc, _STch, _SO, _Du, _Cu, _AUT, _Ena],
    [0, 0, [() => MaintenanceWindowDescription, 0], 0, 0, 0, 0, 1, 1, 1, 2, 2]
];
var UpdateMaintenanceWindowTargetRequest$ = [3, n0, _UMWTR,
    0,
    [_WI, _WTI, _Ta, _OI, _N, _D, _Repl],
    [0, 0, () => Targets, [() => OwnerInformation, 0], 0, [() => MaintenanceWindowDescription, 0], 2], 2
];
var UpdateMaintenanceWindowTargetResult$ = [3, n0, _UMWTRp,
    0,
    [_WI, _WTI, _Ta, _OI, _N, _D],
    [0, 0, () => Targets, [() => OwnerInformation, 0], 0, [() => MaintenanceWindowDescription, 0]]
];
var UpdateMaintenanceWindowTaskRequest$ = [3, n0, _UMWTRpd,
    0,
    [_WI, _WTIi, _Ta, _TAa, _SRA, _TPa, _TIP, _Pr, _MC, _ME, _LI, _N, _D, _Repl, _CB, _AC],
    [0, 0, () => Targets, 0, 0, [() => MaintenanceWindowTaskParameters, 0], [() => MaintenanceWindowTaskInvocationParameters$, 0], 1, 0, 0, () => LoggingInfo$, 0, [() => MaintenanceWindowDescription, 0], 2, 0, () => AlarmConfiguration$], 2
];
var UpdateMaintenanceWindowTaskResult$ = [3, n0, _UMWTRpda,
    0,
    [_WI, _WTIi, _Ta, _TAa, _SRA, _TPa, _TIP, _Pr, _MC, _ME, _LI, _N, _D, _CB, _AC],
    [0, 0, () => Targets, 0, 0, [() => MaintenanceWindowTaskParameters, 0], [() => MaintenanceWindowTaskInvocationParameters$, 0], 1, 0, 0, () => LoggingInfo$, 0, [() => MaintenanceWindowDescription, 0], 0, () => AlarmConfiguration$]
];
var UpdateManagedInstanceRoleRequest$ = [3, n0, _UMIRR,
    0,
    [_II, _IRa],
    [0, 0], 2
];
var UpdateManagedInstanceRoleResult$ = [3, n0, _UMIRRp,
    0,
    [],
    []
];
var UpdateOpsItemRequest$ = [3, n0, _UOIR,
    0,
    [_OII, _D, _OD, _ODTD, _No, _Pr, _ROI, _St, _Ti, _Ca, _Se, _AST, _AETc, _PST, _PET, _OIA],
    [0, 0, () => OpsItemOperationalData, 64 | 0, () => OpsItemNotifications, 1, () => RelatedOpsItems, 0, 0, 0, 0, 4, 4, 4, 4, 0], 1
];
var UpdateOpsItemResponse$ = [3, n0, _UOIRp,
    0,
    [],
    []
];
var UpdateOpsMetadataRequest$ = [3, n0, _UOMR,
    0,
    [_OMA, _MTU, _KTD],
    [0, () => MetadataMap, 64 | 0], 1
];
var UpdateOpsMetadataResult$ = [3, n0, _UOMRp,
    0,
    [_OMA],
    [0]
];
var UpdatePatchBaselineRequest$ = [3, n0, _UPBR,
    0,
    [_BI, _N, _GF, _AR, _AP, _APCL, _APENS, _RP, _RPA, _D, _So, _ASUCS, _Repl],
    [0, 0, () => PatchFilterGroup$, () => PatchRuleGroup$, 64 | 0, 0, 2, 64 | 0, 0, 0, [() => PatchSourceList, 0], 0, 2], 1
];
var UpdatePatchBaselineResult$ = [3, n0, _UPBRp,
    0,
    [_BI, _N, _OSp, _GF, _AR, _AP, _APCL, _APENS, _RP, _RPA, _CD, _MD, _D, _So, _ASUCS],
    [0, 0, 0, () => PatchFilterGroup$, () => PatchRuleGroup$, 64 | 0, 0, 2, 64 | 0, 0, 4, 4, 0, [() => PatchSourceList, 0], 0]
];
var UpdateResourceDataSyncRequest$ = [3, n0, _URDSR,
    0,
    [_SN, _ST, _SSy],
    [0, 0, () => ResourceDataSyncSource$], 3
];
var UpdateResourceDataSyncResult$ = [3, n0, _URDSRp,
    0,
    [],
    []
];
var UpdateServiceSettingRequest$ = [3, n0, _USSR,
    0,
    [_SIe, _SVe],
    [0, 0], 2
];
var UpdateServiceSettingResult$ = [3, n0, _USSRp,
    0,
    [],
    []
];
var ValidateCloudConnectorRequest$ = [3, n0, _VCCR,
    0,
    [_CCI, _MR, _NT],
    [0, 1, 0], 1
];
var ValidateCloudConnectorResult$ = [3, n0, _VCCRa,
    0,
    [_VF, _NT],
    [() => ValidationFindingList, 0]
];
var ValidationFinding$ = [3, n0, _VFa,
    0,
    [_Ty, _Cod, _M, _PMr, _Sco],
    [0, 0, 0, 0, () => ValidationFindingScope$]
];
var ValidationFindingScope$ = [3, n0, _VFS,
    0,
    [_Ty, _I],
    [0, 0]
];
var AccountIdList = [1, n0, _AIL,
    0, [0,
        { [_xN]: _AIc }]
];
var AccountSharingInfoList = [1, n0, _ASIL,
    0, [() => AccountSharingInfo$,
        { [_xN]: _ASI }]
];
var ActivationList = [1, n0, _AL,
    0, () => Activation$
];
var AlarmList = [1, n0, _ALl,
    0, () => Alarm$
];
var AlarmStateInformationList = [1, n0, _ASILl,
    0, () => AlarmStateInformation$
];
var AssociationDescriptionList = [1, n0, _ADL,
    0, [() => AssociationDescription$,
        { [_xN]: _AD }]
];
var AssociationExecutionFilterList = [1, n0, _AEFL,
    0, [() => AssociationExecutionFilter$,
        { [_xN]: _AEF }]
];
var AssociationExecutionsList = [1, n0, _AEL,
    0, [() => AssociationExecution$,
        { [_xN]: _AE }]
];
var AssociationExecutionTargetsFilterList = [1, n0, _AETFL,
    0, [() => AssociationExecutionTargetsFilter$,
        { [_xN]: _AETF }]
];
var AssociationExecutionTargetsList = [1, n0, _AETL,
    0, [() => AssociationExecutionTarget$,
        { [_xN]: _AET }]
];
var AssociationFilterList = [1, n0, _AFL,
    0, [() => AssociationFilter$,
        { [_xN]: _AF }]
];
var AssociationList = [1, n0, _ALs,
    0, [() => Association$,
        { [_xN]: _As }]
];
var AssociationVersionList = [1, n0, _AVL,
    0, [() => AssociationVersionInfo$,
        0]
];
var AttachmentContentList = [1, n0, _ACL,
    0, [() => AttachmentContent$,
        { [_xN]: _ACt }]
];
var AttachmentInformationList = [1, n0, _AILt,
    0, [() => AttachmentInformation$,
        { [_xN]: _AIt }]
];
var AttachmentsSourceList = [1, n0, _ASL,
    0, () => AttachmentsSource$
];
var AutomationExecutionFilterList = [1, n0, _AEFLu,
    0, () => AutomationExecutionFilter$
];
var AutomationExecutionMetadataList = [1, n0, _AEML,
    0, () => AutomationExecutionMetadata$
];
var AutomationTargets = [1, n0, _ATut,
    0, () => Target$
];
var AzureSubscriptionList = [1, n0, _ASLz,
    0, () => AzureSubscription$
];
var CloudConnectorFilterList = [1, n0, _CCFL,
    0, () => CloudConnectorFilter$
];
var CloudConnectorSummaryList = [1, n0, _CCSL,
    0, () => CloudConnectorSummary$
];
var CommandFilterList = [1, n0, _CFL,
    0, () => CommandFilter$
];
var CommandInvocationList = [1, n0, _CIL,
    0, () => CommandInvocation$
];
var CommandList = [1, n0, _CLo,
    0, [() => Command$,
        0]
];
var CommandPluginList = [1, n0, _CPL,
    0, () => CommandPlugin$
];
var ComplianceItemEntryList = [1, n0, _CIEL,
    0, () => ComplianceItemEntry$
];
var ComplianceItemList = [1, n0, _CILo,
    0, [() => ComplianceItem$,
        { [_xN]: _Item }]
];
var ComplianceStringFilterList = [1, n0, _CSFL,
    0, [() => ComplianceStringFilter$,
        { [_xN]: _CFo }]
];
var ComplianceStringFilterValueList = [1, n0, _CSFVL,
    0, [0,
        { [_xN]: _FVi }]
];
var ComplianceSummaryItemList = [1, n0, _CSIL,
    0, [() => ComplianceSummaryItem$,
        { [_xN]: _Item }]
];
var CreateAssociationBatchRequestEntries = [1, n0, _CABREr,
    0, [() => CreateAssociationBatchRequestEntry$,
        { [_xN]: _en }]
];
var DescribeActivationsFilterList = [1, n0, _DAFL,
    0, () => DescribeActivationsFilter$
];
var DocumentFilterList = [1, n0, _DFL,
    0, [() => DocumentFilter$,
        { [_xN]: _DFo }]
];
var DocumentIdentifierList = [1, n0, _DIL,
    0, [() => DocumentIdentifier$,
        { [_xN]: _DIo }]
];
var DocumentKeyValuesFilterList = [1, n0, _DKVFL,
    0, () => DocumentKeyValuesFilter$
];
var DocumentParameterList = [1, n0, _DPLo,
    0, [() => DocumentParameter$,
        { [_xN]: _DPo }]
];
var DocumentRequiresList = [1, n0, _DRL,
    0, () => DocumentRequires$
];
var DocumentReviewCommentList = [1, n0, _DRCL,
    0, () => DocumentReviewCommentSource$
];
var DocumentReviewerResponseList = [1, n0, _DRRL,
    0, () => DocumentReviewerResponseSource$
];
var DocumentVersionList = [1, n0, _DVL,
    0, () => DocumentVersionInfo$
];
var EffectivePatchList = [1, n0, _EPL,
    0, () => EffectivePatch$
];
var FailedCreateAssociationList = [1, n0, _FCAL,
    0, [() => FailedCreateAssociation$,
        { [_xN]: _FCAE }]
];
var GetResourcePoliciesResponseEntries = [1, n0, _GRPREe,
    0, () => GetResourcePoliciesResponseEntry$
];
var InstanceAssociationList = [1, n0, _IAL,
    0, () => InstanceAssociation$
];
var InstanceAssociationStatusInfos = [1, n0, _IASI,
    0, () => InstanceAssociationStatusInfo$
];
var InstanceInformationFilterList = [1, n0, _IIFL,
    0, [() => InstanceInformationFilter$,
        { [_xN]: _IIF }]
];
var InstanceInformationFilterValueSet = [1, n0, _IIFVS,
    0, [0,
        { [_xN]: _IIFV }]
];
var InstanceInformationList = [1, n0, _IIL,
    0, [() => InstanceInformation$,
        { [_xN]: _IInst }]
];
var InstanceInformationStringFilterList = [1, n0, _IISFL,
    0, [() => InstanceInformationStringFilter$,
        { [_xN]: _IISF }]
];
var InstancePatchStateFilterList = [1, n0, _IPSFL,
    0, () => InstancePatchStateFilter$
];
var InstancePatchStateList = [1, n0, _IPSL,
    0, [() => InstancePatchState$,
        0]
];
var InstancePatchStatesList = [1, n0, _IPSLn,
    0, [() => InstancePatchState$,
        0]
];
var InstanceProperties = [1, n0, _IPn,
    0, [() => InstanceProperty$,
        { [_xN]: _IPns }]
];
var InstancePropertyFilterList = [1, n0, _IPFL,
    0, [() => InstancePropertyFilter$,
        { [_xN]: _IPF }]
];
var InstancePropertyFilterValueSet = [1, n0, _IPFVS,
    0, [0,
        { [_xN]: _IPFV }]
];
var InstancePropertyStringFilterList = [1, n0, _IPSFLn,
    0, [() => InstancePropertyStringFilter$,
        { [_xN]: _IPSFn }]
];
var InventoryAggregatorList = [1, n0, _IALn,
    0, [() => InventoryAggregator$,
        { [_xN]: _Agg }]
];
var InventoryDeletionsList = [1, n0, _IDL,
    0, () => InventoryDeletionStatusItem$
];
var InventoryDeletionSummaryItems = [1, n0, _IDSInv,
    0, () => InventoryDeletionSummaryItem$
];
var InventoryFilterList = [1, n0, _IFL,
    0, [() => InventoryFilter$,
        { [_xN]: _IFn }]
];
var InventoryFilterValueList = [1, n0, _IFVL,
    0, [0,
        { [_xN]: _FVi }]
];
var InventoryGroupList = [1, n0, _IGL,
    0, [() => InventoryGroup$,
        { [_xN]: _IG }]
];
var InventoryItemAttributeList = [1, n0, _IIAL,
    0, [() => InventoryItemAttribute$,
        { [_xN]: _Attr }]
];
var InventoryItemList = [1, n0, _IILn,
    0, [() => InventoryItem$,
        { [_xN]: _Item }]
];
var InventoryItemSchemaResultList = [1, n0, _IISRL,
    0, [() => InventoryItemSchema$,
        0]
];
var InventoryResultEntityList = [1, n0, _IREL,
    0, [() => InventoryResultEntity$,
        { [_xN]: _Entit }]
];
var MaintenanceWindowExecutionList = [1, n0, _MWEL,
    0, () => MaintenanceWindowExecution$
];
var MaintenanceWindowExecutionTaskIdentityList = [1, n0, _MWETIL,
    0, () => MaintenanceWindowExecutionTaskIdentity$
];
var MaintenanceWindowExecutionTaskInvocationIdentityList = [1, n0, _MWETIIL,
    0, [() => MaintenanceWindowExecutionTaskInvocationIdentity$,
        0]
];
var MaintenanceWindowFilterList = [1, n0, _MWFL,
    0, () => MaintenanceWindowFilter$
];
var MaintenanceWindowIdentityList = [1, n0, _MWIL,
    0, [() => MaintenanceWindowIdentity$,
        0]
];
var MaintenanceWindowsForTargetList = [1, n0, _MWFTL,
    0, () => MaintenanceWindowIdentityForTarget$
];
var MaintenanceWindowTargetList = [1, n0, _MWTL,
    0, [() => MaintenanceWindowTarget$,
        0]
];
var MaintenanceWindowTaskList = [1, n0, _MWTLa,
    0, [() => MaintenanceWindowTask$,
        0]
];
var MaintenanceWindowTaskParametersList = [1, n0, _MWTPL,
    8, [() => MaintenanceWindowTaskParameters,
        0]
];
var MaintenanceWindowTaskParameterValueList = [1, n0, _MWTPVL,
    8, [() => MaintenanceWindowTaskParameterValue,
        0]
];
var NodeAggregatorList = [1, n0, _NAL,
    0, [() => NodeAggregator$,
        { [_xN]: _NA }]
];
var NodeFilterList = [1, n0, _NFL,
    0, [() => NodeFilter$,
        { [_xN]: _NF }]
];
var NodeFilterValueList = [1, n0, _NFVL,
    0, [0,
        { [_xN]: _FVi }]
];
var NodeList = [1, n0, _NL,
    0, [() => Node$,
        0]
];
var OpsAggregatorList = [1, n0, _OAL,
    0, [() => OpsAggregator$,
        { [_xN]: _Agg }]
];
var OpsEntityList = [1, n0, _OEL,
    0, [() => OpsEntity$,
        { [_xN]: _Entit }]
];
var OpsFilterList = [1, n0, _OFL,
    0, [() => OpsFilter$,
        { [_xN]: _OF }]
];
var OpsFilterValueList = [1, n0, _OFVL,
    0, [0,
        { [_xN]: _FVi }]
];
var OpsItemEventFilters = [1, n0, _OIEFp,
    0, () => OpsItemEventFilter$
];
var OpsItemEventSummaries = [1, n0, _OIESp,
    0, () => OpsItemEventSummary$
];
var OpsItemFilters = [1, n0, _OIF,
    0, () => OpsItemFilter$
];
var OpsItemNotifications = [1, n0, _OINp,
    0, () => OpsItemNotification$
];
var OpsItemRelatedItemsFilters = [1, n0, _OIRIFp,
    0, () => OpsItemRelatedItemsFilter$
];
var OpsItemRelatedItemSummaries = [1, n0, _OIRISp,
    0, () => OpsItemRelatedItemSummary$
];
var OpsItemSummaries = [1, n0, _OIS,
    0, () => OpsItemSummary$
];
var OpsMetadataFilterList = [1, n0, _OMFL,
    0, () => OpsMetadataFilter$
];
var OpsMetadataList = [1, n0, _OML,
    0, () => OpsMetadata$
];
var OpsResultAttributeList = [1, n0, _ORAL,
    0, [() => OpsResultAttribute$,
        { [_xN]: _ORA }]
];
var ParameterHistoryList = [1, n0, _PHL,
    0, [() => ParameterHistory$,
        0]
];
var ParameterList = [1, n0, _PL,
    0, [() => Parameter$,
        0]
];
var ParameterMetadataList = [1, n0, _PML,
    0, () => ParameterMetadata$
];
var ParameterPolicyList = [1, n0, _PPLa,
    0, () => ParameterInlinePolicy$
];
var ParametersFilterList = [1, n0, _PFL,
    0, () => ParametersFilter$
];
var ParameterStringFilterList = [1, n0, _PSFL,
    0, () => ParameterStringFilter$
];
var PatchBaselineIdentityList = [1, n0, _PBIL,
    0, () => PatchBaselineIdentity$
];
var PatchComplianceDataList = [1, n0, _PCDL,
    0, () => PatchComplianceData$
];
var PatchFilterList = [1, n0, _PFLa,
    0, () => PatchFilter$
];
var PatchGroupPatchBaselineMappingList = [1, n0, _PGPBML,
    0, () => PatchGroupPatchBaselineMapping$
];
var PatchList = [1, n0, _PLa,
    0, () => Patch$
];
var PatchOrchestratorFilterList = [1, n0, _POFL,
    0, () => PatchOrchestratorFilter$
];
var PatchRuleList = [1, n0, _PRL,
    0, () => PatchRule$
];
var PatchSourceList = [1, n0, _PSL,
    0, [() => PatchSource$,
        0]
];
var PlatformTypeList = [1, n0, _PTL,
    0, [0,
        { [_xN]: _PTla }]
];
var RegistrationMetadataList = [1, n0, _RML,
    0, () => RegistrationMetadataItem$
];
var RelatedOpsItems = [1, n0, _ROI,
    0, () => RelatedOpsItem$
];
var ResourceComplianceSummaryItemList = [1, n0, _RCSIL,
    0, [() => ResourceComplianceSummaryItem$,
        { [_xN]: _Item }]
];
var ResourceDataSyncItemList = [1, n0, _RDSIL,
    0, () => ResourceDataSyncItem$
];
var ResourceDataSyncOrganizationalUnitList = [1, n0, _RDSOUL,
    0, () => ResourceDataSyncOrganizationalUnit$
];
var ResultAttributeList = [1, n0, _RAL,
    0, [() => ResultAttribute$,
        { [_xN]: _RAesu }]
];
var ReviewInformationList = [1, n0, _RIL,
    0, [() => ReviewInformation$,
        { [_xN]: _RIe }]
];
var Runbooks = [1, n0, _R,
    0, () => Runbook$
];
var ScheduledWindowExecutionList = [1, n0, _SWEL,
    0, () => ScheduledWindowExecution$
];
var SessionFilterList = [1, n0, _SFL,
    0, () => SessionFilter$
];
var SessionList = [1, n0, _SLe,
    0, () => Session$
];
var StepExecutionFilterList = [1, n0, _SEFL,
    0, () => StepExecutionFilter$
];
var StepExecutionList = [1, n0, _SEL,
    0, () => StepExecution$
];
var TagList = [1, n0, _TLa,
    0, () => Tag$
];
var TargetLocations = [1, n0, _TL,
    0, () => TargetLocation$
];
var TargetPreviewList = [1, n0, _TPL,
    0, () => TargetPreview$
];
var Targets = [1, n0, _Ta,
    0, () => Target$
];
var ValidationFindingList = [1, n0, _VFL,
    0, () => ValidationFinding$
];
var InventoryResultItemMap = [2, n0, _IRIM,
    0, 0, () => InventoryResultItem$
];
var MaintenanceWindowTaskParameters = [2, n0, _MWTP,
    8, [0,
        0],
    [() => MaintenanceWindowTaskParameterValueExpression$,
        0]
];
var MetadataMap = [2, n0, _MM,
    0, 0, () => MetadataValue$
];
var OpsEntityItemMap = [2, n0, _OEIM,
    0, 0, () => OpsEntityItem$
];
var OpsItemOperationalData = [2, n0, _OIOD,
    0, 0, () => OpsItemDataValue$
];
var _Parameters = [2, n0, _P,
    8, 0, 64 | 0
];
var CloudConnectorConfiguration$ = [4, n0, _CCC,
    0,
    [_ACz],
    [() => AzureConfiguration$]
];
var ConfigurationTargets$ = [4, n0, _CTon,
    0,
    [_Sub],
    [() => AzureSubscriptionList]
];
var ExecutionInputs$ = [4, n0, _EIx,
    0,
    [_Aut],
    [() => AutomationExecutionInputs$]
];
var ExecutionPreview$ = [4, n0, _EPx,
    0,
    [_Aut],
    [() => AutomationExecutionPreview$]
];
var NodeType$ = [4, n0, _NTo,
    0,
    [_Ins],
    [[() => InstanceInfo$, 0]]
];
var AddTagsToResource$ = [9, n0, _ATTR,
    0, () => AddTagsToResourceRequest$, () => AddTagsToResourceResult$
];
var AssociateOpsItemRelatedItem$ = [9, n0, _AOIRI,
    0, () => AssociateOpsItemRelatedItemRequest$, () => AssociateOpsItemRelatedItemResponse$
];
var CancelCommand$ = [9, n0, _CCa,
    0, () => CancelCommandRequest$, () => CancelCommandResult$
];
var CancelMaintenanceWindowExecution$ = [9, n0, _CMWE,
    0, () => CancelMaintenanceWindowExecutionRequest$, () => CancelMaintenanceWindowExecutionResult$
];
var CreateActivation$ = [9, n0, _CAre,
    0, () => CreateActivationRequest$, () => CreateActivationResult$
];
var CreateAssociation$ = [9, n0, _CArea,
    0, () => CreateAssociationRequest$, () => CreateAssociationResult$
];
var CreateAssociationBatch$ = [9, n0, _CAB,
    0, () => CreateAssociationBatchRequest$, () => CreateAssociationBatchResult$
];
var CreateCloudConnector$ = [9, n0, _CCCr,
    0, () => CreateCloudConnectorRequest$, () => CreateCloudConnectorResult$
];
var CreateDocument$ = [9, n0, _CDre,
    0, () => CreateDocumentRequest$, () => CreateDocumentResult$
];
var CreateMaintenanceWindow$ = [9, n0, _CMW,
    0, () => CreateMaintenanceWindowRequest$, () => CreateMaintenanceWindowResult$
];
var CreateOpsItem$ = [9, n0, _COI,
    0, () => CreateOpsItemRequest$, () => CreateOpsItemResponse$
];
var CreateOpsMetadata$ = [9, n0, _COM,
    0, () => CreateOpsMetadataRequest$, () => CreateOpsMetadataResult$
];
var CreatePatchBaseline$ = [9, n0, _CPB,
    0, () => CreatePatchBaselineRequest$, () => CreatePatchBaselineResult$
];
var CreateResourceDataSync$ = [9, n0, _CRDS,
    0, () => CreateResourceDataSyncRequest$, () => CreateResourceDataSyncResult$
];
var DeleteActivation$ = [9, n0, _DA,
    0, () => DeleteActivationRequest$, () => DeleteActivationResult$
];
var DeleteAssociation$ = [9, n0, _DAe,
    0, () => DeleteAssociationRequest$, () => DeleteAssociationResult$
];
var DeleteCloudConnector$ = [9, n0, _DCC,
    0, () => DeleteCloudConnectorRequest$, () => DeleteCloudConnectorResult$
];
var DeleteDocument$ = [9, n0, _DDe,
    0, () => DeleteDocumentRequest$, () => DeleteDocumentResult$
];
var DeleteInventory$ = [9, n0, _DIe,
    0, () => DeleteInventoryRequest$, () => DeleteInventoryResult$
];
var DeleteMaintenanceWindow$ = [9, n0, _DMW,
    0, () => DeleteMaintenanceWindowRequest$, () => DeleteMaintenanceWindowResult$
];
var DeleteOpsItem$ = [9, n0, _DOI,
    0, () => DeleteOpsItemRequest$, () => DeleteOpsItemResponse$
];
var DeleteOpsMetadata$ = [9, n0, _DOM,
    0, () => DeleteOpsMetadataRequest$, () => DeleteOpsMetadataResult$
];
var DeleteParameter$ = [9, n0, _DPe,
    0, () => DeleteParameterRequest$, () => DeleteParameterResult$
];
var DeleteParameters$ = [9, n0, _DPel,
    0, () => DeleteParametersRequest$, () => DeleteParametersResult$
];
var DeletePatchBaseline$ = [9, n0, _DPB,
    0, () => DeletePatchBaselineRequest$, () => DeletePatchBaselineResult$
];
var DeleteResourceDataSync$ = [9, n0, _DRDS,
    0, () => DeleteResourceDataSyncRequest$, () => DeleteResourceDataSyncResult$
];
var DeleteResourcePolicy$ = [9, n0, _DRP,
    0, () => DeleteResourcePolicyRequest$, () => DeleteResourcePolicyResponse$
];
var DeregisterManagedInstance$ = [9, n0, _DMI,
    0, () => DeregisterManagedInstanceRequest$, () => DeregisterManagedInstanceResult$
];
var DeregisterPatchBaselineForPatchGroup$ = [9, n0, _DPBFPG,
    0, () => DeregisterPatchBaselineForPatchGroupRequest$, () => DeregisterPatchBaselineForPatchGroupResult$
];
var DeregisterTargetFromMaintenanceWindow$ = [9, n0, _DTFMW,
    0, () => DeregisterTargetFromMaintenanceWindowRequest$, () => DeregisterTargetFromMaintenanceWindowResult$
];
var DeregisterTaskFromMaintenanceWindow$ = [9, n0, _DTFMWe,
    0, () => DeregisterTaskFromMaintenanceWindowRequest$, () => DeregisterTaskFromMaintenanceWindowResult$
];
var DescribeActivations$ = [9, n0, _DAes,
    0, () => DescribeActivationsRequest$, () => DescribeActivationsResult$
];
var DescribeAssociation$ = [9, n0, _DAesc,
    0, () => DescribeAssociationRequest$, () => DescribeAssociationResult$
];
var DescribeAssociationExecutions$ = [9, n0, _DAEe,
    0, () => DescribeAssociationExecutionsRequest$, () => DescribeAssociationExecutionsResult$
];
var DescribeAssociationExecutionTargets$ = [9, n0, _DAET,
    0, () => DescribeAssociationExecutionTargetsRequest$, () => DescribeAssociationExecutionTargetsResult$
];
var DescribeAutomationExecutions$ = [9, n0, _DAEes,
    0, () => DescribeAutomationExecutionsRequest$, () => DescribeAutomationExecutionsResult$
];
var DescribeAutomationStepExecutions$ = [9, n0, _DASE,
    0, () => DescribeAutomationStepExecutionsRequest$, () => DescribeAutomationStepExecutionsResult$
];
var DescribeAvailablePatches$ = [9, n0, _DAP,
    0, () => DescribeAvailablePatchesRequest$, () => DescribeAvailablePatchesResult$
];
var DescribeDocument$ = [9, n0, _DDes,
    0, () => DescribeDocumentRequest$, () => DescribeDocumentResult$
];
var DescribeDocumentPermission$ = [9, n0, _DDP,
    0, () => DescribeDocumentPermissionRequest$, () => DescribeDocumentPermissionResponse$
];
var DescribeEffectiveInstanceAssociations$ = [9, n0, _DEIA,
    0, () => DescribeEffectiveInstanceAssociationsRequest$, () => DescribeEffectiveInstanceAssociationsResult$
];
var DescribeEffectivePatchesForPatchBaseline$ = [9, n0, _DEPFPB,
    0, () => DescribeEffectivePatchesForPatchBaselineRequest$, () => DescribeEffectivePatchesForPatchBaselineResult$
];
var DescribeInstanceAssociationsStatus$ = [9, n0, _DIAS,
    0, () => DescribeInstanceAssociationsStatusRequest$, () => DescribeInstanceAssociationsStatusResult$
];
var DescribeInstanceInformation$ = [9, n0, _DIIe,
    0, () => DescribeInstanceInformationRequest$, () => DescribeInstanceInformationResult$
];
var DescribeInstancePatches$ = [9, n0, _DIP,
    0, () => DescribeInstancePatchesRequest$, () => DescribeInstancePatchesResult$
];
var DescribeInstancePatchStates$ = [9, n0, _DIPS,
    0, () => DescribeInstancePatchStatesRequest$, () => DescribeInstancePatchStatesResult$
];
var DescribeInstancePatchStatesForPatchGroup$ = [9, n0, _DIPSFPG,
    0, () => DescribeInstancePatchStatesForPatchGroupRequest$, () => DescribeInstancePatchStatesForPatchGroupResult$
];
var DescribeInstanceProperties$ = [9, n0, _DIPe,
    0, () => DescribeInstancePropertiesRequest$, () => DescribeInstancePropertiesResult$
];
var DescribeInventoryDeletions$ = [9, n0, _DID,
    0, () => DescribeInventoryDeletionsRequest$, () => DescribeInventoryDeletionsResult$
];
var DescribeMaintenanceWindowExecutions$ = [9, n0, _DMWE,
    0, () => DescribeMaintenanceWindowExecutionsRequest$, () => DescribeMaintenanceWindowExecutionsResult$
];
var DescribeMaintenanceWindowExecutionTaskInvocations$ = [9, n0, _DMWETI,
    0, () => DescribeMaintenanceWindowExecutionTaskInvocationsRequest$, () => DescribeMaintenanceWindowExecutionTaskInvocationsResult$
];
var DescribeMaintenanceWindowExecutionTasks$ = [9, n0, _DMWET,
    0, () => DescribeMaintenanceWindowExecutionTasksRequest$, () => DescribeMaintenanceWindowExecutionTasksResult$
];
var DescribeMaintenanceWindows$ = [9, n0, _DMWe,
    0, () => DescribeMaintenanceWindowsRequest$, () => DescribeMaintenanceWindowsResult$
];
var DescribeMaintenanceWindowSchedule$ = [9, n0, _DMWS,
    0, () => DescribeMaintenanceWindowScheduleRequest$, () => DescribeMaintenanceWindowScheduleResult$
];
var DescribeMaintenanceWindowsForTarget$ = [9, n0, _DMWFT,
    0, () => DescribeMaintenanceWindowsForTargetRequest$, () => DescribeMaintenanceWindowsForTargetResult$
];
var DescribeMaintenanceWindowTargets$ = [9, n0, _DMWT,
    0, () => DescribeMaintenanceWindowTargetsRequest$, () => DescribeMaintenanceWindowTargetsResult$
];
var DescribeMaintenanceWindowTasks$ = [9, n0, _DMWTe,
    0, () => DescribeMaintenanceWindowTasksRequest$, () => DescribeMaintenanceWindowTasksResult$
];
var DescribeOpsItems$ = [9, n0, _DOIe,
    0, () => DescribeOpsItemsRequest$, () => DescribeOpsItemsResponse$
];
var DescribeParameters$ = [9, n0, _DPes,
    0, () => DescribeParametersRequest$, () => DescribeParametersResult$
];
var DescribePatchBaselines$ = [9, n0, _DPBe,
    0, () => DescribePatchBaselinesRequest$, () => DescribePatchBaselinesResult$
];
var DescribePatchGroups$ = [9, n0, _DPG,
    0, () => DescribePatchGroupsRequest$, () => DescribePatchGroupsResult$
];
var DescribePatchGroupState$ = [9, n0, _DPGS,
    0, () => DescribePatchGroupStateRequest$, () => DescribePatchGroupStateResult$
];
var DescribePatchProperties$ = [9, n0, _DPP,
    0, () => DescribePatchPropertiesRequest$, () => DescribePatchPropertiesResult$
];
var DescribeSessions$ = [9, n0, _DSes,
    0, () => DescribeSessionsRequest$, () => DescribeSessionsResponse$
];
var DisassociateOpsItemRelatedItem$ = [9, n0, _DOIRI,
    0, () => DisassociateOpsItemRelatedItemRequest$, () => DisassociateOpsItemRelatedItemResponse$
];
var GetAccessToken$ = [9, n0, _GAT,
    0, () => GetAccessTokenRequest$, () => GetAccessTokenResponse$
];
var GetAutomationExecution$ = [9, n0, _GAE,
    0, () => GetAutomationExecutionRequest$, () => GetAutomationExecutionResult$
];
var GetCalendarState$ = [9, n0, _GCS,
    0, () => GetCalendarStateRequest$, () => GetCalendarStateResponse$
];
var GetCloudConnector$ = [9, n0, _GCC,
    0, () => GetCloudConnectorRequest$, () => GetCloudConnectorResult$
];
var GetCommandInvocation$ = [9, n0, _GCI,
    0, () => GetCommandInvocationRequest$, () => GetCommandInvocationResult$
];
var GetConnectionStatus$ = [9, n0, _GCSe,
    0, () => GetConnectionStatusRequest$, () => GetConnectionStatusResponse$
];
var GetDefaultPatchBaseline$ = [9, n0, _GDPB,
    0, () => GetDefaultPatchBaselineRequest$, () => GetDefaultPatchBaselineResult$
];
var GetDeployablePatchSnapshotForInstance$ = [9, n0, _GDPSFI,
    0, () => GetDeployablePatchSnapshotForInstanceRequest$, () => GetDeployablePatchSnapshotForInstanceResult$
];
var GetDocument$ = [9, n0, _GD,
    0, () => GetDocumentRequest$, () => GetDocumentResult$
];
var GetExecutionPreview$ = [9, n0, _GEP,
    0, () => GetExecutionPreviewRequest$, () => GetExecutionPreviewResponse$
];
var GetInventory$ = [9, n0, _GI,
    0, () => GetInventoryRequest$, () => GetInventoryResult$
];
var GetInventorySchema$ = [9, n0, _GIS,
    0, () => GetInventorySchemaRequest$, () => GetInventorySchemaResult$
];
var GetMaintenanceWindow$ = [9, n0, _GMW,
    0, () => GetMaintenanceWindowRequest$, () => GetMaintenanceWindowResult$
];
var GetMaintenanceWindowExecution$ = [9, n0, _GMWE,
    0, () => GetMaintenanceWindowExecutionRequest$, () => GetMaintenanceWindowExecutionResult$
];
var GetMaintenanceWindowExecutionTask$ = [9, n0, _GMWET,
    0, () => GetMaintenanceWindowExecutionTaskRequest$, () => GetMaintenanceWindowExecutionTaskResult$
];
var GetMaintenanceWindowExecutionTaskInvocation$ = [9, n0, _GMWETI,
    0, () => GetMaintenanceWindowExecutionTaskInvocationRequest$, () => GetMaintenanceWindowExecutionTaskInvocationResult$
];
var GetMaintenanceWindowTask$ = [9, n0, _GMWT,
    0, () => GetMaintenanceWindowTaskRequest$, () => GetMaintenanceWindowTaskResult$
];
var GetOpsItem$ = [9, n0, _GOI,
    0, () => GetOpsItemRequest$, () => GetOpsItemResponse$
];
var GetOpsMetadata$ = [9, n0, _GOM,
    0, () => GetOpsMetadataRequest$, () => GetOpsMetadataResult$
];
var GetOpsSummary$ = [9, n0, _GOS,
    0, () => GetOpsSummaryRequest$, () => GetOpsSummaryResult$
];
var GetParameter$ = [9, n0, _GP,
    0, () => GetParameterRequest$, () => GetParameterResult$
];
var GetParameterHistory$ = [9, n0, _GPH,
    0, () => GetParameterHistoryRequest$, () => GetParameterHistoryResult$
];
var GetParameters$ = [9, n0, _GPe,
    0, () => GetParametersRequest$, () => GetParametersResult$
];
var GetParametersByPath$ = [9, n0, _GPBP,
    0, () => GetParametersByPathRequest$, () => GetParametersByPathResult$
];
var GetPatchBaseline$ = [9, n0, _GPB,
    0, () => GetPatchBaselineRequest$, () => GetPatchBaselineResult$
];
var GetPatchBaselineForPatchGroup$ = [9, n0, _GPBFPG,
    0, () => GetPatchBaselineForPatchGroupRequest$, () => GetPatchBaselineForPatchGroupResult$
];
var GetResourcePolicies$ = [9, n0, _GRP,
    0, () => GetResourcePoliciesRequest$, () => GetResourcePoliciesResponse$
];
var GetServiceSetting$ = [9, n0, _GSS,
    0, () => GetServiceSettingRequest$, () => GetServiceSettingResult$
];
var LabelParameterVersion$ = [9, n0, _LPV,
    0, () => LabelParameterVersionRequest$, () => LabelParameterVersionResult$
];
var ListAssociations$ = [9, n0, _LA,
    0, () => ListAssociationsRequest$, () => ListAssociationsResult$
];
var ListAssociationVersions$ = [9, n0, _LAV,
    0, () => ListAssociationVersionsRequest$, () => ListAssociationVersionsResult$
];
var ListCloudConnectors$ = [9, n0, _LCC,
    0, () => ListCloudConnectorsRequest$, () => ListCloudConnectorsResult$
];
var ListCommandInvocations$ = [9, n0, _LCI,
    0, () => ListCommandInvocationsRequest$, () => ListCommandInvocationsResult$
];
var ListCommands$ = [9, n0, _LCi,
    0, () => ListCommandsRequest$, () => ListCommandsResult$
];
var ListComplianceItems$ = [9, n0, _LCIi,
    0, () => ListComplianceItemsRequest$, () => ListComplianceItemsResult$
];
var ListComplianceSummaries$ = [9, n0, _LCS,
    0, () => ListComplianceSummariesRequest$, () => ListComplianceSummariesResult$
];
var ListDocumentMetadataHistory$ = [9, n0, _LDMH,
    0, () => ListDocumentMetadataHistoryRequest$, () => ListDocumentMetadataHistoryResponse$
];
var ListDocuments$ = [9, n0, _LD,
    0, () => ListDocumentsRequest$, () => ListDocumentsResult$
];
var ListDocumentVersions$ = [9, n0, _LDV,
    0, () => ListDocumentVersionsRequest$, () => ListDocumentVersionsResult$
];
var ListInventoryEntries$ = [9, n0, _LIE,
    0, () => ListInventoryEntriesRequest$, () => ListInventoryEntriesResult$
];
var ListNodes$ = [9, n0, _LN,
    0, () => ListNodesRequest$, () => ListNodesResult$
];
var ListNodesSummary$ = [9, n0, _LNS,
    0, () => ListNodesSummaryRequest$, () => ListNodesSummaryResult$
];
var ListOpsItemEvents$ = [9, n0, _LOIE,
    0, () => ListOpsItemEventsRequest$, () => ListOpsItemEventsResponse$
];
var ListOpsItemRelatedItems$ = [9, n0, _LOIRI,
    0, () => ListOpsItemRelatedItemsRequest$, () => ListOpsItemRelatedItemsResponse$
];
var ListOpsMetadata$ = [9, n0, _LOM,
    0, () => ListOpsMetadataRequest$, () => ListOpsMetadataResult$
];
var ListResourceComplianceSummaries$ = [9, n0, _LRCS,
    0, () => ListResourceComplianceSummariesRequest$, () => ListResourceComplianceSummariesResult$
];
var ListResourceDataSync$ = [9, n0, _LRDS,
    0, () => ListResourceDataSyncRequest$, () => ListResourceDataSyncResult$
];
var ListTagsForResource$ = [9, n0, _LTFR,
    0, () => ListTagsForResourceRequest$, () => ListTagsForResourceResult$
];
var ModifyDocumentPermission$ = [9, n0, _MDP,
    0, () => ModifyDocumentPermissionRequest$, () => ModifyDocumentPermissionResponse$
];
var PutComplianceItems$ = [9, n0, _PCI,
    0, () => PutComplianceItemsRequest$, () => PutComplianceItemsResult$
];
var PutInventory$ = [9, n0, _PIu,
    0, () => PutInventoryRequest$, () => PutInventoryResult$
];
var PutParameter$ = [9, n0, _PP,
    0, () => PutParameterRequest$, () => PutParameterResult$
];
var PutResourcePolicy$ = [9, n0, _PRP,
    0, () => PutResourcePolicyRequest$, () => PutResourcePolicyResponse$
];
var RegisterDefaultPatchBaseline$ = [9, n0, _RDPB,
    0, () => RegisterDefaultPatchBaselineRequest$, () => RegisterDefaultPatchBaselineResult$
];
var RegisterPatchBaselineForPatchGroup$ = [9, n0, _RPBFPG,
    0, () => RegisterPatchBaselineForPatchGroupRequest$, () => RegisterPatchBaselineForPatchGroupResult$
];
var RegisterTargetWithMaintenanceWindow$ = [9, n0, _RTWMW,
    0, () => RegisterTargetWithMaintenanceWindowRequest$, () => RegisterTargetWithMaintenanceWindowResult$
];
var RegisterTaskWithMaintenanceWindow$ = [9, n0, _RTWMWe,
    0, () => RegisterTaskWithMaintenanceWindowRequest$, () => RegisterTaskWithMaintenanceWindowResult$
];
var RemoveTagsFromResource$ = [9, n0, _RTFR,
    0, () => RemoveTagsFromResourceRequest$, () => RemoveTagsFromResourceResult$
];
var ResetServiceSetting$ = [9, n0, _RSS,
    0, () => ResetServiceSettingRequest$, () => ResetServiceSettingResult$
];
var ResumeSession$ = [9, n0, _RSe,
    0, () => ResumeSessionRequest$, () => ResumeSessionResponse$
];
var SendAutomationSignal$ = [9, n0, _SAS,
    0, () => SendAutomationSignalRequest$, () => SendAutomationSignalResult$
];
var SendCommand$ = [9, n0, _SCe,
    0, () => SendCommandRequest$, () => SendCommandResult$
];
var StartAccessRequest$ = [9, n0, _SAR,
    0, () => StartAccessRequestRequest$, () => StartAccessRequestResponse$
];
var StartAssociationsOnce$ = [9, n0, _SAO,
    0, () => StartAssociationsOnceRequest$, () => StartAssociationsOnceResult$
];
var StartAutomationExecution$ = [9, n0, _SAE,
    0, () => StartAutomationExecutionRequest$, () => StartAutomationExecutionResult$
];
var StartChangeRequestExecution$ = [9, n0, _SCRE,
    0, () => StartChangeRequestExecutionRequest$, () => StartChangeRequestExecutionResult$
];
var StartExecutionPreview$ = [9, n0, _SEP,
    0, () => StartExecutionPreviewRequest$, () => StartExecutionPreviewResponse$
];
var StartSession$ = [9, n0, _SSta,
    0, () => StartSessionRequest$, () => StartSessionResponse$
];
var StopAutomationExecution$ = [9, n0, _SAEt,
    0, () => StopAutomationExecutionRequest$, () => StopAutomationExecutionResult$
];
var TerminateSession$ = [9, n0, _TSe,
    0, () => TerminateSessionRequest$, () => TerminateSessionResponse$
];
var UnlabelParameterVersion$ = [9, n0, _UPV,
    0, () => UnlabelParameterVersionRequest$, () => UnlabelParameterVersionResult$
];
var UpdateAssociation$ = [9, n0, _UAp,
    0, () => UpdateAssociationRequest$, () => UpdateAssociationResult$
];
var UpdateAssociationStatus$ = [9, n0, _UAS,
    0, () => UpdateAssociationStatusRequest$, () => UpdateAssociationStatusResult$
];
var UpdateCloudConnector$ = [9, n0, _UCC,
    0, () => UpdateCloudConnectorRequest$, () => UpdateCloudConnectorResult$
];
var UpdateDocument$ = [9, n0, _UD,
    0, () => UpdateDocumentRequest$, () => UpdateDocumentResult$
];
var UpdateDocumentDefaultVersion$ = [9, n0, _UDDV,
    0, () => UpdateDocumentDefaultVersionRequest$, () => UpdateDocumentDefaultVersionResult$
];
var UpdateDocumentMetadata$ = [9, n0, _UDM,
    0, () => UpdateDocumentMetadataRequest$, () => UpdateDocumentMetadataResponse$
];
var UpdateMaintenanceWindow$ = [9, n0, _UMW,
    0, () => UpdateMaintenanceWindowRequest$, () => UpdateMaintenanceWindowResult$
];
var UpdateMaintenanceWindowTarget$ = [9, n0, _UMWT,
    0, () => UpdateMaintenanceWindowTargetRequest$, () => UpdateMaintenanceWindowTargetResult$
];
var UpdateMaintenanceWindowTask$ = [9, n0, _UMWTp,
    0, () => UpdateMaintenanceWindowTaskRequest$, () => UpdateMaintenanceWindowTaskResult$
];
var UpdateManagedInstanceRole$ = [9, n0, _UMIR,
    0, () => UpdateManagedInstanceRoleRequest$, () => UpdateManagedInstanceRoleResult$
];
var UpdateOpsItem$ = [9, n0, _UOI,
    0, () => UpdateOpsItemRequest$, () => UpdateOpsItemResponse$
];
var UpdateOpsMetadata$ = [9, n0, _UOM,
    0, () => UpdateOpsMetadataRequest$, () => UpdateOpsMetadataResult$
];
var UpdatePatchBaseline$ = [9, n0, _UPB,
    0, () => UpdatePatchBaselineRequest$, () => UpdatePatchBaselineResult$
];
var UpdateResourceDataSync$ = [9, n0, _URDS,
    0, () => UpdateResourceDataSyncRequest$, () => UpdateResourceDataSyncResult$
];
var UpdateServiceSetting$ = [9, n0, _USS,
    0, () => UpdateServiceSettingRequest$, () => UpdateServiceSettingResult$
];
var ValidateCloudConnector$ = [9, n0, _VCC,
    0, () => ValidateCloudConnectorRequest$, () => ValidateCloudConnectorResult$
];

const getRuntimeConfig$1 = (config) => {
    return {
        apiVersion: "2014-11-06",
        base64Decoder: config?.base64Decoder ?? fromBase64,
        base64Encoder: config?.base64Encoder ?? toBase64,
        disableHostPrefix: config?.disableHostPrefix ?? false,
        endpointProvider: config?.endpointProvider ?? defaultEndpointResolver,
        extensions: config?.extensions ?? [],
        httpAuthSchemeProvider: config?.httpAuthSchemeProvider ?? defaultSSMHttpAuthSchemeProvider,
        httpAuthSchemes: config?.httpAuthSchemes ?? [
            {
                schemeId: "aws.auth#sigv4",
                identityProvider: (ipc) => ipc.getIdentityProvider("aws.auth#sigv4"),
                signer: new AwsSdkSigV4Signer(),
            },
        ],
        logger: config?.logger ?? new NoOpLogger(),
        protocol: config?.protocol ?? AwsJson1_1Protocol,
        protocolSettings: config?.protocolSettings ?? {
            defaultNamespace: "com.amazonaws.ssm",
            errorTypeRegistries,
            xmlNamespace: "http://ssm.amazonaws.com/doc/2014-11-06/",
            version: "2014-11-06",
            serviceTarget: "AmazonSSM",
        },
        serviceId: config?.serviceId ?? "SSM",
        sha256: config?.sha256 ?? Sha256,
        urlParser: config?.urlParser ?? parseUrl,
        utf8Decoder: config?.utf8Decoder ?? fromUtf8,
        utf8Encoder: config?.utf8Encoder ?? toUtf8,
    };
};

const getRuntimeConfig = (config) => {
    emitWarningIfUnsupportedVersion(process.version);
    const defaultsMode = resolveDefaultsModeConfig(config);
    const defaultConfigProvider = () => defaultsMode().then(loadConfigsForDefaultMode);
    const clientSharedValues = getRuntimeConfig$1(config);
    emitWarningIfUnsupportedVersion$1(process.version);
    const loaderConfig = {
        profile: config?.profile,
        logger: clientSharedValues.logger,
    };
    return {
        ...clientSharedValues,
        ...config,
        runtime: "node",
        defaultsMode,
        authSchemePreference: config?.authSchemePreference ?? loadConfig(NODE_AUTH_SCHEME_PREFERENCE_OPTIONS, loaderConfig),
        bodyLengthChecker: config?.bodyLengthChecker ?? calculateBodyLength,
        credentialDefaultProvider: config?.credentialDefaultProvider ?? defaultProvider,
        defaultUserAgentProvider: config?.defaultUserAgentProvider ?? createDefaultUserAgentProvider({ serviceId: clientSharedValues.serviceId, clientVersion: packageInfo.version }),
        maxAttempts: config?.maxAttempts ?? loadConfig(NODE_MAX_ATTEMPT_CONFIG_OPTIONS, config),
        region: config?.region ?? loadConfig(NODE_REGION_CONFIG_OPTIONS, { ...NODE_REGION_CONFIG_FILE_OPTIONS, ...loaderConfig }),
        requestHandler: NodeHttpHandler.create(config?.requestHandler ?? defaultConfigProvider),
        retryMode: config?.retryMode ??
            loadConfig({
                ...NODE_RETRY_MODE_CONFIG_OPTIONS,
                default: async () => (await defaultConfigProvider()).retryMode || DEFAULT_RETRY_MODE,
            }, config),
        streamCollector: config?.streamCollector ?? streamCollector,
        useDualstackEndpoint: config?.useDualstackEndpoint ?? loadConfig(NODE_USE_DUALSTACK_ENDPOINT_CONFIG_OPTIONS, loaderConfig),
        useFipsEndpoint: config?.useFipsEndpoint ?? loadConfig(NODE_USE_FIPS_ENDPOINT_CONFIG_OPTIONS, loaderConfig),
        userAgentAppId: config?.userAgentAppId ?? loadConfig(NODE_APP_ID_CONFIG_OPTIONS, loaderConfig),
    };
};

const getHttpAuthExtensionConfiguration = (runtimeConfig) => {
    const _httpAuthSchemes = runtimeConfig.httpAuthSchemes;
    let _httpAuthSchemeProvider = runtimeConfig.httpAuthSchemeProvider;
    let _credentials = runtimeConfig.credentials;
    return {
        setHttpAuthScheme(httpAuthScheme) {
            const index = _httpAuthSchemes.findIndex((scheme) => scheme.schemeId === httpAuthScheme.schemeId);
            if (index === -1) {
                _httpAuthSchemes.push(httpAuthScheme);
            }
            else {
                _httpAuthSchemes.splice(index, 1, httpAuthScheme);
            }
        },
        httpAuthSchemes() {
            return _httpAuthSchemes;
        },
        setHttpAuthSchemeProvider(httpAuthSchemeProvider) {
            _httpAuthSchemeProvider = httpAuthSchemeProvider;
        },
        httpAuthSchemeProvider() {
            return _httpAuthSchemeProvider;
        },
        setCredentials(credentials) {
            _credentials = credentials;
        },
        credentials() {
            return _credentials;
        },
    };
};
const resolveHttpAuthRuntimeConfig = (config) => {
    return {
        httpAuthSchemes: config.httpAuthSchemes(),
        httpAuthSchemeProvider: config.httpAuthSchemeProvider(),
        credentials: config.credentials(),
    };
};

const resolveRuntimeExtensions = (runtimeConfig, extensions) => {
    const extensionConfiguration = Object.assign(getAwsRegionExtensionConfiguration(runtimeConfig), getDefaultExtensionConfiguration(runtimeConfig), getHttpHandlerExtensionConfiguration(runtimeConfig), getHttpAuthExtensionConfiguration(runtimeConfig));
    extensions.forEach((extension) => extension.configure(extensionConfiguration));
    return Object.assign(runtimeConfig, resolveAwsRegionExtensionConfiguration(extensionConfiguration), resolveDefaultRuntimeConfig(extensionConfiguration), resolveHttpHandlerRuntimeConfig(extensionConfiguration), resolveHttpAuthRuntimeConfig(extensionConfiguration));
};

class SSMClient extends Client {
    config;
    constructor(...[configuration]) {
        const _config_0 = getRuntimeConfig(configuration || {});
        super(_config_0);
        this.initConfig = _config_0;
        const _config_1 = resolveClientEndpointParameters(_config_0);
        const _config_2 = resolveUserAgentConfig(_config_1);
        const _config_3 = resolveRetryConfig(_config_2);
        const _config_4 = resolveRegionConfig(_config_3);
        const _config_5 = resolveHostHeaderConfig(_config_4);
        const _config_6 = resolveEndpointConfig(_config_5);
        const _config_7 = resolveHttpAuthSchemeConfig(_config_6);
        const _config_8 = resolveRuntimeExtensions(_config_7, configuration?.extensions || []);
        this.config = _config_8;
        this.middlewareStack.use(getSchemaSerdePlugin(this.config));
        this.middlewareStack.use(getUserAgentPlugin(this.config));
        this.middlewareStack.use(getRetryPlugin(this.config));
        this.middlewareStack.use(getContentLengthPlugin(this.config));
        this.middlewareStack.use(getHostHeaderPlugin(this.config));
        this.middlewareStack.use(getLoggerPlugin(this.config));
        this.middlewareStack.use(getRecursionDetectionPlugin(this.config));
        this.middlewareStack.use(getHttpAuthSchemeEndpointRuleSetPlugin(this.config, {
            httpAuthSchemeParametersProvider: defaultSSMHttpAuthSchemeParametersProvider,
            identityProviderConfigProvider: async (config) => new DefaultIdentityProviderConfig({
                "aws.auth#sigv4": config.credentials,
            }),
        }));
        this.middlewareStack.use(getHttpSigningPlugin(this.config));
    }
    destroy() {
        super.destroy();
    }
}

const command = makeBuilder(commonParams, "AmazonSSM", "SSMClient", getEndpointPlugin);
const _ep0 = {};
const _mw0 = (Command, cs, config, o) => [];

class AddTagsToResourceCommand extends command(_ep0, _mw0, "AddTagsToResource", AddTagsToResource$) {
}

class AssociateOpsItemRelatedItemCommand extends command(_ep0, _mw0, "AssociateOpsItemRelatedItem", AssociateOpsItemRelatedItem$) {
}

class CancelCommandCommand extends command(_ep0, _mw0, "CancelCommand", CancelCommand$) {
}

class CancelMaintenanceWindowExecutionCommand extends command(_ep0, _mw0, "CancelMaintenanceWindowExecution", CancelMaintenanceWindowExecution$) {
}

class CreateActivationCommand extends command(_ep0, _mw0, "CreateActivation", CreateActivation$) {
}

class CreateAssociationBatchCommand extends command(_ep0, _mw0, "CreateAssociationBatch", CreateAssociationBatch$) {
}

class CreateAssociationCommand extends command(_ep0, _mw0, "CreateAssociation", CreateAssociation$) {
}

class CreateCloudConnectorCommand extends command(_ep0, _mw0, "CreateCloudConnector", CreateCloudConnector$) {
}

class CreateDocumentCommand extends command(_ep0, _mw0, "CreateDocument", CreateDocument$) {
}

class CreateMaintenanceWindowCommand extends command(_ep0, _mw0, "CreateMaintenanceWindow", CreateMaintenanceWindow$) {
}

class CreateOpsItemCommand extends command(_ep0, _mw0, "CreateOpsItem", CreateOpsItem$) {
}

class CreateOpsMetadataCommand extends command(_ep0, _mw0, "CreateOpsMetadata", CreateOpsMetadata$) {
}

class CreatePatchBaselineCommand extends command(_ep0, _mw0, "CreatePatchBaseline", CreatePatchBaseline$) {
}

class CreateResourceDataSyncCommand extends command(_ep0, _mw0, "CreateResourceDataSync", CreateResourceDataSync$) {
}

class DeleteActivationCommand extends command(_ep0, _mw0, "DeleteActivation", DeleteActivation$) {
}

class DeleteAssociationCommand extends command(_ep0, _mw0, "DeleteAssociation", DeleteAssociation$) {
}

class DeleteCloudConnectorCommand extends command(_ep0, _mw0, "DeleteCloudConnector", DeleteCloudConnector$) {
}

class DeleteDocumentCommand extends command(_ep0, _mw0, "DeleteDocument", DeleteDocument$) {
}

class DeleteInventoryCommand extends command(_ep0, _mw0, "DeleteInventory", DeleteInventory$) {
}

class DeleteMaintenanceWindowCommand extends command(_ep0, _mw0, "DeleteMaintenanceWindow", DeleteMaintenanceWindow$) {
}

class DeleteOpsItemCommand extends command(_ep0, _mw0, "DeleteOpsItem", DeleteOpsItem$) {
}

class DeleteOpsMetadataCommand extends command(_ep0, _mw0, "DeleteOpsMetadata", DeleteOpsMetadata$) {
}

class DeleteParameterCommand extends command(_ep0, _mw0, "DeleteParameter", DeleteParameter$) {
}

class DeleteParametersCommand extends command(_ep0, _mw0, "DeleteParameters", DeleteParameters$) {
}

class DeletePatchBaselineCommand extends command(_ep0, _mw0, "DeletePatchBaseline", DeletePatchBaseline$) {
}

class DeleteResourceDataSyncCommand extends command(_ep0, _mw0, "DeleteResourceDataSync", DeleteResourceDataSync$) {
}

class DeleteResourcePolicyCommand extends command(_ep0, _mw0, "DeleteResourcePolicy", DeleteResourcePolicy$) {
}

class DeregisterManagedInstanceCommand extends command(_ep0, _mw0, "DeregisterManagedInstance", DeregisterManagedInstance$) {
}

class DeregisterPatchBaselineForPatchGroupCommand extends command(_ep0, _mw0, "DeregisterPatchBaselineForPatchGroup", DeregisterPatchBaselineForPatchGroup$) {
}

class DeregisterTargetFromMaintenanceWindowCommand extends command(_ep0, _mw0, "DeregisterTargetFromMaintenanceWindow", DeregisterTargetFromMaintenanceWindow$) {
}

class DeregisterTaskFromMaintenanceWindowCommand extends command(_ep0, _mw0, "DeregisterTaskFromMaintenanceWindow", DeregisterTaskFromMaintenanceWindow$) {
}

class DescribeActivationsCommand extends command(_ep0, _mw0, "DescribeActivations", DescribeActivations$) {
}

class DescribeAssociationCommand extends command(_ep0, _mw0, "DescribeAssociation", DescribeAssociation$) {
}

class DescribeAssociationExecutionsCommand extends command(_ep0, _mw0, "DescribeAssociationExecutions", DescribeAssociationExecutions$) {
}

class DescribeAssociationExecutionTargetsCommand extends command(_ep0, _mw0, "DescribeAssociationExecutionTargets", DescribeAssociationExecutionTargets$) {
}

class DescribeAutomationExecutionsCommand extends command(_ep0, _mw0, "DescribeAutomationExecutions", DescribeAutomationExecutions$) {
}

class DescribeAutomationStepExecutionsCommand extends command(_ep0, _mw0, "DescribeAutomationStepExecutions", DescribeAutomationStepExecutions$) {
}

class DescribeAvailablePatchesCommand extends command(_ep0, _mw0, "DescribeAvailablePatches", DescribeAvailablePatches$) {
}

class DescribeDocumentCommand extends command(_ep0, _mw0, "DescribeDocument", DescribeDocument$) {
}

class DescribeDocumentPermissionCommand extends command(_ep0, _mw0, "DescribeDocumentPermission", DescribeDocumentPermission$) {
}

class DescribeEffectiveInstanceAssociationsCommand extends command(_ep0, _mw0, "DescribeEffectiveInstanceAssociations", DescribeEffectiveInstanceAssociations$) {
}

class DescribeEffectivePatchesForPatchBaselineCommand extends command(_ep0, _mw0, "DescribeEffectivePatchesForPatchBaseline", DescribeEffectivePatchesForPatchBaseline$) {
}

class DescribeInstanceAssociationsStatusCommand extends command(_ep0, _mw0, "DescribeInstanceAssociationsStatus", DescribeInstanceAssociationsStatus$) {
}

class DescribeInstanceInformationCommand extends command(_ep0, _mw0, "DescribeInstanceInformation", DescribeInstanceInformation$) {
}

class DescribeInstancePatchesCommand extends command(_ep0, _mw0, "DescribeInstancePatches", DescribeInstancePatches$) {
}

class DescribeInstancePatchStatesCommand extends command(_ep0, _mw0, "DescribeInstancePatchStates", DescribeInstancePatchStates$) {
}

class DescribeInstancePatchStatesForPatchGroupCommand extends command(_ep0, _mw0, "DescribeInstancePatchStatesForPatchGroup", DescribeInstancePatchStatesForPatchGroup$) {
}

class DescribeInstancePropertiesCommand extends command(_ep0, _mw0, "DescribeInstanceProperties", DescribeInstanceProperties$) {
}

class DescribeInventoryDeletionsCommand extends command(_ep0, _mw0, "DescribeInventoryDeletions", DescribeInventoryDeletions$) {
}

class DescribeMaintenanceWindowExecutionsCommand extends command(_ep0, _mw0, "DescribeMaintenanceWindowExecutions", DescribeMaintenanceWindowExecutions$) {
}

class DescribeMaintenanceWindowExecutionTaskInvocationsCommand extends command(_ep0, _mw0, "DescribeMaintenanceWindowExecutionTaskInvocations", DescribeMaintenanceWindowExecutionTaskInvocations$) {
}

class DescribeMaintenanceWindowExecutionTasksCommand extends command(_ep0, _mw0, "DescribeMaintenanceWindowExecutionTasks", DescribeMaintenanceWindowExecutionTasks$) {
}

class DescribeMaintenanceWindowScheduleCommand extends command(_ep0, _mw0, "DescribeMaintenanceWindowSchedule", DescribeMaintenanceWindowSchedule$) {
}

class DescribeMaintenanceWindowsCommand extends command(_ep0, _mw0, "DescribeMaintenanceWindows", DescribeMaintenanceWindows$) {
}

class DescribeMaintenanceWindowsForTargetCommand extends command(_ep0, _mw0, "DescribeMaintenanceWindowsForTarget", DescribeMaintenanceWindowsForTarget$) {
}

class DescribeMaintenanceWindowTargetsCommand extends command(_ep0, _mw0, "DescribeMaintenanceWindowTargets", DescribeMaintenanceWindowTargets$) {
}

class DescribeMaintenanceWindowTasksCommand extends command(_ep0, _mw0, "DescribeMaintenanceWindowTasks", DescribeMaintenanceWindowTasks$) {
}

class DescribeOpsItemsCommand extends command(_ep0, _mw0, "DescribeOpsItems", DescribeOpsItems$) {
}

class DescribeParametersCommand extends command(_ep0, _mw0, "DescribeParameters", DescribeParameters$) {
}

class DescribePatchBaselinesCommand extends command(_ep0, _mw0, "DescribePatchBaselines", DescribePatchBaselines$) {
}

class DescribePatchGroupsCommand extends command(_ep0, _mw0, "DescribePatchGroups", DescribePatchGroups$) {
}

class DescribePatchGroupStateCommand extends command(_ep0, _mw0, "DescribePatchGroupState", DescribePatchGroupState$) {
}

class DescribePatchPropertiesCommand extends command(_ep0, _mw0, "DescribePatchProperties", DescribePatchProperties$) {
}

class DescribeSessionsCommand extends command(_ep0, _mw0, "DescribeSessions", DescribeSessions$) {
}

class DisassociateOpsItemRelatedItemCommand extends command(_ep0, _mw0, "DisassociateOpsItemRelatedItem", DisassociateOpsItemRelatedItem$) {
}

class GetAccessTokenCommand extends command(_ep0, _mw0, "GetAccessToken", GetAccessToken$) {
}

class GetAutomationExecutionCommand extends command(_ep0, _mw0, "GetAutomationExecution", GetAutomationExecution$) {
}

class GetCalendarStateCommand extends command(_ep0, _mw0, "GetCalendarState", GetCalendarState$) {
}

class GetCloudConnectorCommand extends command(_ep0, _mw0, "GetCloudConnector", GetCloudConnector$) {
}

class GetCommandInvocationCommand extends command(_ep0, _mw0, "GetCommandInvocation", GetCommandInvocation$) {
}

class GetConnectionStatusCommand extends command(_ep0, _mw0, "GetConnectionStatus", GetConnectionStatus$) {
}

class GetDefaultPatchBaselineCommand extends command(_ep0, _mw0, "GetDefaultPatchBaseline", GetDefaultPatchBaseline$) {
}

class GetDeployablePatchSnapshotForInstanceCommand extends command(_ep0, _mw0, "GetDeployablePatchSnapshotForInstance", GetDeployablePatchSnapshotForInstance$) {
}

class GetDocumentCommand extends command(_ep0, _mw0, "GetDocument", GetDocument$) {
}

class GetExecutionPreviewCommand extends command(_ep0, _mw0, "GetExecutionPreview", GetExecutionPreview$) {
}

class GetInventoryCommand extends command(_ep0, _mw0, "GetInventory", GetInventory$) {
}

class GetInventorySchemaCommand extends command(_ep0, _mw0, "GetInventorySchema", GetInventorySchema$) {
}

class GetMaintenanceWindowCommand extends command(_ep0, _mw0, "GetMaintenanceWindow", GetMaintenanceWindow$) {
}

class GetMaintenanceWindowExecutionCommand extends command(_ep0, _mw0, "GetMaintenanceWindowExecution", GetMaintenanceWindowExecution$) {
}

class GetMaintenanceWindowExecutionTaskCommand extends command(_ep0, _mw0, "GetMaintenanceWindowExecutionTask", GetMaintenanceWindowExecutionTask$) {
}

class GetMaintenanceWindowExecutionTaskInvocationCommand extends command(_ep0, _mw0, "GetMaintenanceWindowExecutionTaskInvocation", GetMaintenanceWindowExecutionTaskInvocation$) {
}

class GetMaintenanceWindowTaskCommand extends command(_ep0, _mw0, "GetMaintenanceWindowTask", GetMaintenanceWindowTask$) {
}

class GetOpsItemCommand extends command(_ep0, _mw0, "GetOpsItem", GetOpsItem$) {
}

class GetOpsMetadataCommand extends command(_ep0, _mw0, "GetOpsMetadata", GetOpsMetadata$) {
}

class GetOpsSummaryCommand extends command(_ep0, _mw0, "GetOpsSummary", GetOpsSummary$) {
}

class GetParameterCommand extends command(_ep0, _mw0, "GetParameter", GetParameter$) {
}

class GetParameterHistoryCommand extends command(_ep0, _mw0, "GetParameterHistory", GetParameterHistory$) {
}

class GetParametersByPathCommand extends command(_ep0, _mw0, "GetParametersByPath", GetParametersByPath$) {
}

class GetParametersCommand extends command(_ep0, _mw0, "GetParameters", GetParameters$) {
}

class GetPatchBaselineCommand extends command(_ep0, _mw0, "GetPatchBaseline", GetPatchBaseline$) {
}

class GetPatchBaselineForPatchGroupCommand extends command(_ep0, _mw0, "GetPatchBaselineForPatchGroup", GetPatchBaselineForPatchGroup$) {
}

class GetResourcePoliciesCommand extends command(_ep0, _mw0, "GetResourcePolicies", GetResourcePolicies$) {
}

class GetServiceSettingCommand extends command(_ep0, _mw0, "GetServiceSetting", GetServiceSetting$) {
}

class LabelParameterVersionCommand extends command(_ep0, _mw0, "LabelParameterVersion", LabelParameterVersion$) {
}

class ListAssociationsCommand extends command(_ep0, _mw0, "ListAssociations", ListAssociations$) {
}

class ListAssociationVersionsCommand extends command(_ep0, _mw0, "ListAssociationVersions", ListAssociationVersions$) {
}

class ListCloudConnectorsCommand extends command(_ep0, _mw0, "ListCloudConnectors", ListCloudConnectors$) {
}

class ListCommandInvocationsCommand extends command(_ep0, _mw0, "ListCommandInvocations", ListCommandInvocations$) {
}

class ListCommandsCommand extends command(_ep0, _mw0, "ListCommands", ListCommands$) {
}

class ListComplianceItemsCommand extends command(_ep0, _mw0, "ListComplianceItems", ListComplianceItems$) {
}

class ListComplianceSummariesCommand extends command(_ep0, _mw0, "ListComplianceSummaries", ListComplianceSummaries$) {
}

class ListDocumentMetadataHistoryCommand extends command(_ep0, _mw0, "ListDocumentMetadataHistory", ListDocumentMetadataHistory$) {
}

class ListDocumentsCommand extends command(_ep0, _mw0, "ListDocuments", ListDocuments$) {
}

class ListDocumentVersionsCommand extends command(_ep0, _mw0, "ListDocumentVersions", ListDocumentVersions$) {
}

class ListInventoryEntriesCommand extends command(_ep0, _mw0, "ListInventoryEntries", ListInventoryEntries$) {
}

class ListNodesCommand extends command(_ep0, _mw0, "ListNodes", ListNodes$) {
}

class ListNodesSummaryCommand extends command(_ep0, _mw0, "ListNodesSummary", ListNodesSummary$) {
}

class ListOpsItemEventsCommand extends command(_ep0, _mw0, "ListOpsItemEvents", ListOpsItemEvents$) {
}

class ListOpsItemRelatedItemsCommand extends command(_ep0, _mw0, "ListOpsItemRelatedItems", ListOpsItemRelatedItems$) {
}

class ListOpsMetadataCommand extends command(_ep0, _mw0, "ListOpsMetadata", ListOpsMetadata$) {
}

class ListResourceComplianceSummariesCommand extends command(_ep0, _mw0, "ListResourceComplianceSummaries", ListResourceComplianceSummaries$) {
}

class ListResourceDataSyncCommand extends command(_ep0, _mw0, "ListResourceDataSync", ListResourceDataSync$) {
}

class ListTagsForResourceCommand extends command(_ep0, _mw0, "ListTagsForResource", ListTagsForResource$) {
}

class ModifyDocumentPermissionCommand extends command(_ep0, _mw0, "ModifyDocumentPermission", ModifyDocumentPermission$) {
}

class PutComplianceItemsCommand extends command(_ep0, _mw0, "PutComplianceItems", PutComplianceItems$) {
}

class PutInventoryCommand extends command(_ep0, _mw0, "PutInventory", PutInventory$) {
}

class PutParameterCommand extends command(_ep0, _mw0, "PutParameter", PutParameter$) {
}

class PutResourcePolicyCommand extends command(_ep0, _mw0, "PutResourcePolicy", PutResourcePolicy$) {
}

class RegisterDefaultPatchBaselineCommand extends command(_ep0, _mw0, "RegisterDefaultPatchBaseline", RegisterDefaultPatchBaseline$) {
}

class RegisterPatchBaselineForPatchGroupCommand extends command(_ep0, _mw0, "RegisterPatchBaselineForPatchGroup", RegisterPatchBaselineForPatchGroup$) {
}

class RegisterTargetWithMaintenanceWindowCommand extends command(_ep0, _mw0, "RegisterTargetWithMaintenanceWindow", RegisterTargetWithMaintenanceWindow$) {
}

class RegisterTaskWithMaintenanceWindowCommand extends command(_ep0, _mw0, "RegisterTaskWithMaintenanceWindow", RegisterTaskWithMaintenanceWindow$) {
}

class RemoveTagsFromResourceCommand extends command(_ep0, _mw0, "RemoveTagsFromResource", RemoveTagsFromResource$) {
}

class ResetServiceSettingCommand extends command(_ep0, _mw0, "ResetServiceSetting", ResetServiceSetting$) {
}

class ResumeSessionCommand extends command(_ep0, _mw0, "ResumeSession", ResumeSession$) {
}

class SendAutomationSignalCommand extends command(_ep0, _mw0, "SendAutomationSignal", SendAutomationSignal$) {
}

class SendCommandCommand extends command(_ep0, _mw0, "SendCommand", SendCommand$) {
}

class StartAccessRequestCommand extends command(_ep0, _mw0, "StartAccessRequest", StartAccessRequest$) {
}

class StartAssociationsOnceCommand extends command(_ep0, _mw0, "StartAssociationsOnce", StartAssociationsOnce$) {
}

class StartAutomationExecutionCommand extends command(_ep0, _mw0, "StartAutomationExecution", StartAutomationExecution$) {
}

class StartChangeRequestExecutionCommand extends command(_ep0, _mw0, "StartChangeRequestExecution", StartChangeRequestExecution$) {
}

class StartExecutionPreviewCommand extends command(_ep0, _mw0, "StartExecutionPreview", StartExecutionPreview$) {
}

class StartSessionCommand extends command(_ep0, _mw0, "StartSession", StartSession$) {
}

class StopAutomationExecutionCommand extends command(_ep0, _mw0, "StopAutomationExecution", StopAutomationExecution$) {
}

class TerminateSessionCommand extends command(_ep0, _mw0, "TerminateSession", TerminateSession$) {
}

class UnlabelParameterVersionCommand extends command(_ep0, _mw0, "UnlabelParameterVersion", UnlabelParameterVersion$) {
}

class UpdateAssociationCommand extends command(_ep0, _mw0, "UpdateAssociation", UpdateAssociation$) {
}

class UpdateAssociationStatusCommand extends command(_ep0, _mw0, "UpdateAssociationStatus", UpdateAssociationStatus$) {
}

class UpdateCloudConnectorCommand extends command(_ep0, _mw0, "UpdateCloudConnector", UpdateCloudConnector$) {
}

class UpdateDocumentCommand extends command(_ep0, _mw0, "UpdateDocument", UpdateDocument$) {
}

class UpdateDocumentDefaultVersionCommand extends command(_ep0, _mw0, "UpdateDocumentDefaultVersion", UpdateDocumentDefaultVersion$) {
}

class UpdateDocumentMetadataCommand extends command(_ep0, _mw0, "UpdateDocumentMetadata", UpdateDocumentMetadata$) {
}

class UpdateMaintenanceWindowCommand extends command(_ep0, _mw0, "UpdateMaintenanceWindow", UpdateMaintenanceWindow$) {
}

class UpdateMaintenanceWindowTargetCommand extends command(_ep0, _mw0, "UpdateMaintenanceWindowTarget", UpdateMaintenanceWindowTarget$) {
}

class UpdateMaintenanceWindowTaskCommand extends command(_ep0, _mw0, "UpdateMaintenanceWindowTask", UpdateMaintenanceWindowTask$) {
}

class UpdateManagedInstanceRoleCommand extends command(_ep0, _mw0, "UpdateManagedInstanceRole", UpdateManagedInstanceRole$) {
}

class UpdateOpsItemCommand extends command(_ep0, _mw0, "UpdateOpsItem", UpdateOpsItem$) {
}

class UpdateOpsMetadataCommand extends command(_ep0, _mw0, "UpdateOpsMetadata", UpdateOpsMetadata$) {
}

class UpdatePatchBaselineCommand extends command(_ep0, _mw0, "UpdatePatchBaseline", UpdatePatchBaseline$) {
}

class UpdateResourceDataSyncCommand extends command(_ep0, _mw0, "UpdateResourceDataSync", UpdateResourceDataSync$) {
}

class UpdateServiceSettingCommand extends command(_ep0, _mw0, "UpdateServiceSetting", UpdateServiceSetting$) {
}

class ValidateCloudConnectorCommand extends command(_ep0, _mw0, "ValidateCloudConnector", ValidateCloudConnector$) {
}

const paginateDescribeActivations = createPaginator(SSMClient, DescribeActivationsCommand, "NextToken", "NextToken", "MaxResults");

const paginateDescribeAssociationExecutions = createPaginator(SSMClient, DescribeAssociationExecutionsCommand, "NextToken", "NextToken", "MaxResults");

const paginateDescribeAssociationExecutionTargets = createPaginator(SSMClient, DescribeAssociationExecutionTargetsCommand, "NextToken", "NextToken", "MaxResults");

const paginateDescribeAutomationExecutions = createPaginator(SSMClient, DescribeAutomationExecutionsCommand, "NextToken", "NextToken", "MaxResults");

const paginateDescribeAutomationStepExecutions = createPaginator(SSMClient, DescribeAutomationStepExecutionsCommand, "NextToken", "NextToken", "MaxResults");

const paginateDescribeAvailablePatches = createPaginator(SSMClient, DescribeAvailablePatchesCommand, "NextToken", "NextToken", "MaxResults");

const paginateDescribeEffectiveInstanceAssociations = createPaginator(SSMClient, DescribeEffectiveInstanceAssociationsCommand, "NextToken", "NextToken", "MaxResults");

const paginateDescribeEffectivePatchesForPatchBaseline = createPaginator(SSMClient, DescribeEffectivePatchesForPatchBaselineCommand, "NextToken", "NextToken", "MaxResults");

const paginateDescribeInstanceAssociationsStatus = createPaginator(SSMClient, DescribeInstanceAssociationsStatusCommand, "NextToken", "NextToken", "MaxResults");

const paginateDescribeInstanceInformation = createPaginator(SSMClient, DescribeInstanceInformationCommand, "NextToken", "NextToken", "MaxResults");

const paginateDescribeInstancePatches = createPaginator(SSMClient, DescribeInstancePatchesCommand, "NextToken", "NextToken", "MaxResults");

const paginateDescribeInstancePatchStatesForPatchGroup = createPaginator(SSMClient, DescribeInstancePatchStatesForPatchGroupCommand, "NextToken", "NextToken", "MaxResults");

const paginateDescribeInstancePatchStates = createPaginator(SSMClient, DescribeInstancePatchStatesCommand, "NextToken", "NextToken", "MaxResults");

const paginateDescribeInstanceProperties = createPaginator(SSMClient, DescribeInstancePropertiesCommand, "NextToken", "NextToken", "MaxResults");

const paginateDescribeInventoryDeletions = createPaginator(SSMClient, DescribeInventoryDeletionsCommand, "NextToken", "NextToken", "MaxResults");

const paginateDescribeMaintenanceWindowExecutions = createPaginator(SSMClient, DescribeMaintenanceWindowExecutionsCommand, "NextToken", "NextToken", "MaxResults");

const paginateDescribeMaintenanceWindowExecutionTaskInvocations = createPaginator(SSMClient, DescribeMaintenanceWindowExecutionTaskInvocationsCommand, "NextToken", "NextToken", "MaxResults");

const paginateDescribeMaintenanceWindowExecutionTasks = createPaginator(SSMClient, DescribeMaintenanceWindowExecutionTasksCommand, "NextToken", "NextToken", "MaxResults");

const paginateDescribeMaintenanceWindowSchedule = createPaginator(SSMClient, DescribeMaintenanceWindowScheduleCommand, "NextToken", "NextToken", "MaxResults");

const paginateDescribeMaintenanceWindowsForTarget = createPaginator(SSMClient, DescribeMaintenanceWindowsForTargetCommand, "NextToken", "NextToken", "MaxResults");

const paginateDescribeMaintenanceWindows = createPaginator(SSMClient, DescribeMaintenanceWindowsCommand, "NextToken", "NextToken", "MaxResults");

const paginateDescribeMaintenanceWindowTargets = createPaginator(SSMClient, DescribeMaintenanceWindowTargetsCommand, "NextToken", "NextToken", "MaxResults");

const paginateDescribeMaintenanceWindowTasks = createPaginator(SSMClient, DescribeMaintenanceWindowTasksCommand, "NextToken", "NextToken", "MaxResults");

const paginateDescribeOpsItems = createPaginator(SSMClient, DescribeOpsItemsCommand, "NextToken", "NextToken", "MaxResults");

const paginateDescribeParameters = createPaginator(SSMClient, DescribeParametersCommand, "NextToken", "NextToken", "MaxResults");

const paginateDescribePatchBaselines = createPaginator(SSMClient, DescribePatchBaselinesCommand, "NextToken", "NextToken", "MaxResults");

const paginateDescribePatchGroups = createPaginator(SSMClient, DescribePatchGroupsCommand, "NextToken", "NextToken", "MaxResults");

const paginateDescribePatchProperties = createPaginator(SSMClient, DescribePatchPropertiesCommand, "NextToken", "NextToken", "MaxResults");

const paginateDescribeSessions = createPaginator(SSMClient, DescribeSessionsCommand, "NextToken", "NextToken", "MaxResults");

const paginateGetInventory = createPaginator(SSMClient, GetInventoryCommand, "NextToken", "NextToken", "MaxResults");

const paginateGetInventorySchema = createPaginator(SSMClient, GetInventorySchemaCommand, "NextToken", "NextToken", "MaxResults");

const paginateGetOpsSummary = createPaginator(SSMClient, GetOpsSummaryCommand, "NextToken", "NextToken", "MaxResults");

const paginateGetParameterHistory = createPaginator(SSMClient, GetParameterHistoryCommand, "NextToken", "NextToken", "MaxResults");

const paginateGetParametersByPath = createPaginator(SSMClient, GetParametersByPathCommand, "NextToken", "NextToken", "MaxResults");

const paginateGetResourcePolicies = createPaginator(SSMClient, GetResourcePoliciesCommand, "NextToken", "NextToken", "MaxResults");

const paginateListAssociations = createPaginator(SSMClient, ListAssociationsCommand, "NextToken", "NextToken", "MaxResults");

const paginateListAssociationVersions = createPaginator(SSMClient, ListAssociationVersionsCommand, "NextToken", "NextToken", "MaxResults");

const paginateListCloudConnectors = createPaginator(SSMClient, ListCloudConnectorsCommand, "NextToken", "NextToken", "MaxResults");

const paginateListCommandInvocations = createPaginator(SSMClient, ListCommandInvocationsCommand, "NextToken", "NextToken", "MaxResults");

const paginateListCommands = createPaginator(SSMClient, ListCommandsCommand, "NextToken", "NextToken", "MaxResults");

const paginateListComplianceItems = createPaginator(SSMClient, ListComplianceItemsCommand, "NextToken", "NextToken", "MaxResults");

const paginateListComplianceSummaries = createPaginator(SSMClient, ListComplianceSummariesCommand, "NextToken", "NextToken", "MaxResults");

const paginateListDocuments = createPaginator(SSMClient, ListDocumentsCommand, "NextToken", "NextToken", "MaxResults");

const paginateListDocumentVersions = createPaginator(SSMClient, ListDocumentVersionsCommand, "NextToken", "NextToken", "MaxResults");

const paginateListNodes = createPaginator(SSMClient, ListNodesCommand, "NextToken", "NextToken", "MaxResults");

const paginateListNodesSummary = createPaginator(SSMClient, ListNodesSummaryCommand, "NextToken", "NextToken", "MaxResults");

const paginateListOpsItemEvents = createPaginator(SSMClient, ListOpsItemEventsCommand, "NextToken", "NextToken", "MaxResults");

const paginateListOpsItemRelatedItems = createPaginator(SSMClient, ListOpsItemRelatedItemsCommand, "NextToken", "NextToken", "MaxResults");

const paginateListOpsMetadata = createPaginator(SSMClient, ListOpsMetadataCommand, "NextToken", "NextToken", "MaxResults");

const paginateListResourceComplianceSummaries = createPaginator(SSMClient, ListResourceComplianceSummariesCommand, "NextToken", "NextToken", "MaxResults");

const paginateListResourceDataSync = createPaginator(SSMClient, ListResourceDataSyncCommand, "NextToken", "NextToken", "MaxResults");

const paginateValidateCloudConnector = createPaginator(SSMClient, ValidateCloudConnectorCommand, "NextToken", "NextToken", "MaxResults");

const checkState = async (client, input) => {
    let reason;
    try {
        let result = await client.send(new GetCommandInvocationCommand(input));
        reason = result;
        try {
            const returnComparator = () => {
                return result.Status;
            };
            if (returnComparator() === "Pending") {
                return { state: WaiterState.RETRY, reason };
            }
        }
        catch (e) { }
        try {
            const returnComparator = () => {
                return result.Status;
            };
            if (returnComparator() === "InProgress") {
                return { state: WaiterState.RETRY, reason };
            }
        }
        catch (e) { }
        try {
            const returnComparator = () => {
                return result.Status;
            };
            if (returnComparator() === "Delayed") {
                return { state: WaiterState.RETRY, reason };
            }
        }
        catch (e) { }
        try {
            const returnComparator = () => {
                return result.Status;
            };
            if (returnComparator() === "Success") {
                return { state: WaiterState.SUCCESS, reason };
            }
        }
        catch (e) { }
        try {
            const returnComparator = () => {
                return result.Status;
            };
            if (returnComparator() === "Cancelled") {
                return { state: WaiterState.FAILURE, reason };
            }
        }
        catch (e) { }
        try {
            const returnComparator = () => {
                return result.Status;
            };
            if (returnComparator() === "TimedOut") {
                return { state: WaiterState.FAILURE, reason };
            }
        }
        catch (e) { }
        try {
            const returnComparator = () => {
                return result.Status;
            };
            if (returnComparator() === "Failed") {
                return { state: WaiterState.FAILURE, reason };
            }
        }
        catch (e) { }
        try {
            const returnComparator = () => {
                return result.Status;
            };
            if (returnComparator() === "Cancelling") {
                return { state: WaiterState.FAILURE, reason };
            }
        }
        catch (e) { }
    }
    catch (exception) {
        reason = exception;
        if (exception.name === "InvocationDoesNotExist") {
            return { state: WaiterState.RETRY, reason };
        }
    }
    return { state: WaiterState.RETRY, reason };
};
const waitForCommandExecuted = async (params, input) => {
    const serviceDefaults = { minDelay: 5, maxDelay: 120 };
    return createWaiter({ ...serviceDefaults, ...params }, input, checkState);
};
const waitUntilCommandExecuted = async (params, input) => {
    const serviceDefaults = { minDelay: 5, maxDelay: 120 };
    const result = await createWaiter({ ...serviceDefaults, ...params }, input, checkState);
    return checkExceptions(result);
};

const commands = {
    AddTagsToResourceCommand,
    AssociateOpsItemRelatedItemCommand,
    CancelCommandCommand,
    CancelMaintenanceWindowExecutionCommand,
    CreateActivationCommand,
    CreateAssociationCommand,
    CreateAssociationBatchCommand,
    CreateCloudConnectorCommand,
    CreateDocumentCommand,
    CreateMaintenanceWindowCommand,
    CreateOpsItemCommand,
    CreateOpsMetadataCommand,
    CreatePatchBaselineCommand,
    CreateResourceDataSyncCommand,
    DeleteActivationCommand,
    DeleteAssociationCommand,
    DeleteCloudConnectorCommand,
    DeleteDocumentCommand,
    DeleteInventoryCommand,
    DeleteMaintenanceWindowCommand,
    DeleteOpsItemCommand,
    DeleteOpsMetadataCommand,
    DeleteParameterCommand,
    DeleteParametersCommand,
    DeletePatchBaselineCommand,
    DeleteResourceDataSyncCommand,
    DeleteResourcePolicyCommand,
    DeregisterManagedInstanceCommand,
    DeregisterPatchBaselineForPatchGroupCommand,
    DeregisterTargetFromMaintenanceWindowCommand,
    DeregisterTaskFromMaintenanceWindowCommand,
    DescribeActivationsCommand,
    DescribeAssociationCommand,
    DescribeAssociationExecutionsCommand,
    DescribeAssociationExecutionTargetsCommand,
    DescribeAutomationExecutionsCommand,
    DescribeAutomationStepExecutionsCommand,
    DescribeAvailablePatchesCommand,
    DescribeDocumentCommand,
    DescribeDocumentPermissionCommand,
    DescribeEffectiveInstanceAssociationsCommand,
    DescribeEffectivePatchesForPatchBaselineCommand,
    DescribeInstanceAssociationsStatusCommand,
    DescribeInstanceInformationCommand,
    DescribeInstancePatchesCommand,
    DescribeInstancePatchStatesCommand,
    DescribeInstancePatchStatesForPatchGroupCommand,
    DescribeInstancePropertiesCommand,
    DescribeInventoryDeletionsCommand,
    DescribeMaintenanceWindowExecutionsCommand,
    DescribeMaintenanceWindowExecutionTaskInvocationsCommand,
    DescribeMaintenanceWindowExecutionTasksCommand,
    DescribeMaintenanceWindowsCommand,
    DescribeMaintenanceWindowScheduleCommand,
    DescribeMaintenanceWindowsForTargetCommand,
    DescribeMaintenanceWindowTargetsCommand,
    DescribeMaintenanceWindowTasksCommand,
    DescribeOpsItemsCommand,
    DescribeParametersCommand,
    DescribePatchBaselinesCommand,
    DescribePatchGroupsCommand,
    DescribePatchGroupStateCommand,
    DescribePatchPropertiesCommand,
    DescribeSessionsCommand,
    DisassociateOpsItemRelatedItemCommand,
    GetAccessTokenCommand,
    GetAutomationExecutionCommand,
    GetCalendarStateCommand,
    GetCloudConnectorCommand,
    GetCommandInvocationCommand,
    GetConnectionStatusCommand,
    GetDefaultPatchBaselineCommand,
    GetDeployablePatchSnapshotForInstanceCommand,
    GetDocumentCommand,
    GetExecutionPreviewCommand,
    GetInventoryCommand,
    GetInventorySchemaCommand,
    GetMaintenanceWindowCommand,
    GetMaintenanceWindowExecutionCommand,
    GetMaintenanceWindowExecutionTaskCommand,
    GetMaintenanceWindowExecutionTaskInvocationCommand,
    GetMaintenanceWindowTaskCommand,
    GetOpsItemCommand,
    GetOpsMetadataCommand,
    GetOpsSummaryCommand,
    GetParameterCommand,
    GetParameterHistoryCommand,
    GetParametersCommand,
    GetParametersByPathCommand,
    GetPatchBaselineCommand,
    GetPatchBaselineForPatchGroupCommand,
    GetResourcePoliciesCommand,
    GetServiceSettingCommand,
    LabelParameterVersionCommand,
    ListAssociationsCommand,
    ListAssociationVersionsCommand,
    ListCloudConnectorsCommand,
    ListCommandInvocationsCommand,
    ListCommandsCommand,
    ListComplianceItemsCommand,
    ListComplianceSummariesCommand,
    ListDocumentMetadataHistoryCommand,
    ListDocumentsCommand,
    ListDocumentVersionsCommand,
    ListInventoryEntriesCommand,
    ListNodesCommand,
    ListNodesSummaryCommand,
    ListOpsItemEventsCommand,
    ListOpsItemRelatedItemsCommand,
    ListOpsMetadataCommand,
    ListResourceComplianceSummariesCommand,
    ListResourceDataSyncCommand,
    ListTagsForResourceCommand,
    ModifyDocumentPermissionCommand,
    PutComplianceItemsCommand,
    PutInventoryCommand,
    PutParameterCommand,
    PutResourcePolicyCommand,
    RegisterDefaultPatchBaselineCommand,
    RegisterPatchBaselineForPatchGroupCommand,
    RegisterTargetWithMaintenanceWindowCommand,
    RegisterTaskWithMaintenanceWindowCommand,
    RemoveTagsFromResourceCommand,
    ResetServiceSettingCommand,
    ResumeSessionCommand,
    SendAutomationSignalCommand,
    SendCommandCommand,
    StartAccessRequestCommand,
    StartAssociationsOnceCommand,
    StartAutomationExecutionCommand,
    StartChangeRequestExecutionCommand,
    StartExecutionPreviewCommand,
    StartSessionCommand,
    StopAutomationExecutionCommand,
    TerminateSessionCommand,
    UnlabelParameterVersionCommand,
    UpdateAssociationCommand,
    UpdateAssociationStatusCommand,
    UpdateCloudConnectorCommand,
    UpdateDocumentCommand,
    UpdateDocumentDefaultVersionCommand,
    UpdateDocumentMetadataCommand,
    UpdateMaintenanceWindowCommand,
    UpdateMaintenanceWindowTargetCommand,
    UpdateMaintenanceWindowTaskCommand,
    UpdateManagedInstanceRoleCommand,
    UpdateOpsItemCommand,
    UpdateOpsMetadataCommand,
    UpdatePatchBaselineCommand,
    UpdateResourceDataSyncCommand,
    UpdateServiceSettingCommand,
    ValidateCloudConnectorCommand,
};
const paginators = {
    paginateDescribeActivations,
    paginateDescribeAssociationExecutions,
    paginateDescribeAssociationExecutionTargets,
    paginateDescribeAutomationExecutions,
    paginateDescribeAutomationStepExecutions,
    paginateDescribeAvailablePatches,
    paginateDescribeEffectiveInstanceAssociations,
    paginateDescribeEffectivePatchesForPatchBaseline,
    paginateDescribeInstanceAssociationsStatus,
    paginateDescribeInstanceInformation,
    paginateDescribeInstancePatches,
    paginateDescribeInstancePatchStates,
    paginateDescribeInstancePatchStatesForPatchGroup,
    paginateDescribeInstanceProperties,
    paginateDescribeInventoryDeletions,
    paginateDescribeMaintenanceWindowExecutions,
    paginateDescribeMaintenanceWindowExecutionTaskInvocations,
    paginateDescribeMaintenanceWindowExecutionTasks,
    paginateDescribeMaintenanceWindows,
    paginateDescribeMaintenanceWindowSchedule,
    paginateDescribeMaintenanceWindowsForTarget,
    paginateDescribeMaintenanceWindowTargets,
    paginateDescribeMaintenanceWindowTasks,
    paginateDescribeOpsItems,
    paginateDescribeParameters,
    paginateDescribePatchBaselines,
    paginateDescribePatchGroups,
    paginateDescribePatchProperties,
    paginateDescribeSessions,
    paginateGetInventory,
    paginateGetInventorySchema,
    paginateGetOpsSummary,
    paginateGetParameterHistory,
    paginateGetParametersByPath,
    paginateGetResourcePolicies,
    paginateListAssociations,
    paginateListAssociationVersions,
    paginateListCloudConnectors,
    paginateListCommandInvocations,
    paginateListCommands,
    paginateListComplianceItems,
    paginateListComplianceSummaries,
    paginateListDocuments,
    paginateListDocumentVersions,
    paginateListNodes,
    paginateListNodesSummary,
    paginateListOpsItemEvents,
    paginateListOpsItemRelatedItems,
    paginateListOpsMetadata,
    paginateListResourceComplianceSummaries,
    paginateListResourceDataSync,
    paginateValidateCloudConnector,
};
const waiters = {
    waitUntilCommandExecuted,
};
class SSM extends SSMClient {
}
createAggregatedClient(commands, SSM, { paginators, waiters });

const AccessRequestStatus = {
    APPROVED: "Approved",
    EXPIRED: "Expired",
    PENDING: "Pending",
    REJECTED: "Rejected",
    REVOKED: "Revoked",
};
const AccessType = {
    JUSTINTIME: "JustInTime",
    STANDARD: "Standard",
};
const ResourceTypeForTagging = {
    ASSOCIATION: "Association",
    AUTOMATION: "Automation",
    CLOUD_CONNECTOR: "CloudConnector",
    DOCUMENT: "Document",
    MAINTENANCE_WINDOW: "MaintenanceWindow",
    MANAGED_INSTANCE: "ManagedInstance",
    OPSMETADATA: "OpsMetadata",
    OPS_ITEM: "OpsItem",
    PARAMETER: "Parameter",
    PATCH_BASELINE: "PatchBaseline",
};
const ExternalAlarmState = {
    ALARM: "ALARM",
    UNKNOWN: "UNKNOWN",
};
const AssociationComplianceSeverity = {
    Critical: "CRITICAL",
    High: "HIGH",
    Low: "LOW",
    Medium: "MEDIUM",
    Unspecified: "UNSPECIFIED",
};
const AssociationSyncCompliance = {
    Auto: "AUTO",
    Manual: "MANUAL",
};
const AssociationStatusName = {
    Failed: "Failed",
    Pending: "Pending",
    Success: "Success",
};
const Fault = {
    Client: "Client",
    Server: "Server",
    Unknown: "Unknown",
};
const AttachmentsSourceKey = {
    AttachmentReference: "AttachmentReference",
    S3FileUrl: "S3FileUrl",
    SourceUrl: "SourceUrl",
};
const DocumentFormat = {
    JSON: "JSON",
    TEXT: "TEXT",
    YAML: "YAML",
};
const DocumentType = {
    ApplicationConfiguration: "ApplicationConfiguration",
    ApplicationConfigurationSchema: "ApplicationConfigurationSchema",
    AutoApprovalPolicy: "AutoApprovalPolicy",
    Automation: "Automation",
    ChangeCalendar: "ChangeCalendar",
    ChangeTemplate: "Automation.ChangeTemplate",
    CloudFormation: "CloudFormation",
    Command: "Command",
    ConformancePackTemplate: "ConformancePackTemplate",
    DeploymentStrategy: "DeploymentStrategy",
    ManualApprovalPolicy: "ManualApprovalPolicy",
    Package: "Package",
    Policy: "Policy",
    ProblemAnalysis: "ProblemAnalysis",
    ProblemAnalysisTemplate: "ProblemAnalysisTemplate",
    QuickSetup: "QuickSetup",
    Session: "Session",
};
const DocumentHashType = {
    SHA1: "Sha1",
    SHA256: "Sha256",
};
const DocumentParameterType = {
    String: "String",
    StringList: "StringList",
};
const PlatformType = {
    LINUX: "Linux",
    MACOS: "MacOS",
    WINDOWS: "Windows",
};
const ReviewStatus = {
    APPROVED: "APPROVED",
    NOT_REVIEWED: "NOT_REVIEWED",
    PENDING: "PENDING",
    REJECTED: "REJECTED",
};
const DocumentStatus = {
    Active: "Active",
    Creating: "Creating",
    Deleting: "Deleting",
    Failed: "Failed",
    Updating: "Updating",
};
const OpsItemDataType = {
    SEARCHABLE_STRING: "SearchableString",
    STRING: "String",
};
const PatchComplianceLevel = {
    Critical: "CRITICAL",
    High: "HIGH",
    Informational: "INFORMATIONAL",
    Low: "LOW",
    Medium: "MEDIUM",
    Unspecified: "UNSPECIFIED",
};
const PatchFilterKey = {
    AdvisoryId: "ADVISORY_ID",
    Arch: "ARCH",
    BugzillaId: "BUGZILLA_ID",
    CVEId: "CVE_ID",
    Classification: "CLASSIFICATION",
    Epoch: "EPOCH",
    MsrcSeverity: "MSRC_SEVERITY",
    Name: "NAME",
    PatchId: "PATCH_ID",
    PatchSet: "PATCH_SET",
    Priority: "PRIORITY",
    Product: "PRODUCT",
    ProductFamily: "PRODUCT_FAMILY",
    Release: "RELEASE",
    Repository: "REPOSITORY",
    Section: "SECTION",
    Security: "SECURITY",
    Severity: "SEVERITY",
    Version: "VERSION",
};
const PatchComplianceStatus = {
    Compliant: "COMPLIANT",
    NonCompliant: "NON_COMPLIANT",
};
const OperatingSystem = {
    AlmaLinux: "ALMA_LINUX",
    AmazonLinux: "AMAZON_LINUX",
    AmazonLinux2: "AMAZON_LINUX_2",
    AmazonLinux2022: "AMAZON_LINUX_2022",
    AmazonLinux2023: "AMAZON_LINUX_2023",
    CentOS: "CENTOS",
    Debian: "DEBIAN",
    MacOS: "MACOS",
    OracleLinux: "ORACLE_LINUX",
    Raspbian: "RASPBIAN",
    RedhatEnterpriseLinux: "REDHAT_ENTERPRISE_LINUX",
    Rocky_Linux: "ROCKY_LINUX",
    Suse: "SUSE",
    Ubuntu: "UBUNTU",
    Windows: "WINDOWS",
};
const PatchAction = {
    AllowAsDependency: "ALLOW_AS_DEPENDENCY",
    Block: "BLOCK",
};
const ResourceDataSyncS3Format = {
    JSON_SERDE: "JsonSerDe",
};
const InventorySchemaDeleteOption = {
    DELETE_SCHEMA: "DeleteSchema",
    DISABLE_SCHEMA: "DisableSchema",
};
const DescribeActivationsFilterKeys = {
    ACTIVATION_IDS: "ActivationIds",
    DEFAULT_INSTANCE_NAME: "DefaultInstanceName",
    IAM_ROLE: "IamRole",
};
const AssociationExecutionFilterKey = {
    CreatedTime: "CreatedTime",
    ExecutionId: "ExecutionId",
    Status: "Status",
};
const AssociationFilterOperatorType = {
    Equal: "EQUAL",
    GreaterThan: "GREATER_THAN",
    LessThan: "LESS_THAN",
};
const AssociationExecutionTargetsFilterKey = {
    ResourceId: "ResourceId",
    ResourceType: "ResourceType",
    Status: "Status",
};
const AutomationExecutionFilterKey = {
    AUTOMATION_SUBTYPE: "AutomationSubtype",
    AUTOMATION_TYPE: "AutomationType",
    CURRENT_ACTION: "CurrentAction",
    DOCUMENT_NAME_PREFIX: "DocumentNamePrefix",
    EXECUTION_ID: "ExecutionId",
    EXECUTION_STATUS: "ExecutionStatus",
    OPS_ITEM_ID: "OpsItemId",
    PARENT_EXECUTION_ID: "ParentExecutionId",
    START_TIME_AFTER: "StartTimeAfter",
    START_TIME_BEFORE: "StartTimeBefore",
    TAG_KEY: "TagKey",
    TARGET_RESOURCE_GROUP: "TargetResourceGroup",
};
const AutomationExecutionStatus = {
    APPROVED: "Approved",
    CANCELLED: "Cancelled",
    CANCELLING: "Cancelling",
    CHANGE_CALENDAR_OVERRIDE_APPROVED: "ChangeCalendarOverrideApproved",
    CHANGE_CALENDAR_OVERRIDE_REJECTED: "ChangeCalendarOverrideRejected",
    COMPLETED_WITH_FAILURE: "CompletedWithFailure",
    COMPLETED_WITH_SUCCESS: "CompletedWithSuccess",
    EXITED: "Exited",
    FAILED: "Failed",
    INPROGRESS: "InProgress",
    PENDING: "Pending",
    PENDING_APPROVAL: "PendingApproval",
    PENDING_CHANGE_CALENDAR_OVERRIDE: "PendingChangeCalendarOverride",
    REJECTED: "Rejected",
    RUNBOOK_INPROGRESS: "RunbookInProgress",
    SCHEDULED: "Scheduled",
    SUCCESS: "Success",
    TIMEDOUT: "TimedOut",
    WAITING: "Waiting",
};
const AutomationSubtype = {
    AccessRequest: "AccessRequest",
    ChangeRequest: "ChangeRequest",
};
const AutomationType = {
    CrossAccount: "CrossAccount",
    Local: "Local",
};
const ExecutionMode = {
    Auto: "Auto",
    Interactive: "Interactive",
};
const StepExecutionFilterKey = {
    ACTION: "Action",
    PARENT_STEP_EXECUTION_ID: "ParentStepExecutionId",
    PARENT_STEP_ITERATION: "ParentStepIteration",
    PARENT_STEP_ITERATOR_VALUE: "ParentStepIteratorValue",
    START_TIME_AFTER: "StartTimeAfter",
    START_TIME_BEFORE: "StartTimeBefore",
    STEP_EXECUTION_ID: "StepExecutionId",
    STEP_EXECUTION_STATUS: "StepExecutionStatus",
    STEP_NAME: "StepName",
};
const DocumentPermissionType = {
    SHARE: "Share",
};
const PatchDeploymentStatus = {
    Approved: "APPROVED",
    ExplicitApproved: "EXPLICIT_APPROVED",
    ExplicitRejected: "EXPLICIT_REJECTED",
    PendingApproval: "PENDING_APPROVAL",
};
const InstanceInformationFilterKey = {
    ACTIVATION_IDS: "ActivationIds",
    AGENT_VERSION: "AgentVersion",
    ASSOCIATION_STATUS: "AssociationStatus",
    IAM_ROLE: "IamRole",
    INSTANCE_IDS: "InstanceIds",
    PING_STATUS: "PingStatus",
    PLATFORM_TYPES: "PlatformTypes",
    RESOURCE_TYPE: "ResourceType",
};
const PingStatus = {
    CONNECTION_LOST: "ConnectionLost",
    INACTIVE: "Inactive",
    ONLINE: "Online",
};
const ResourceType = {
    EC2_INSTANCE: "EC2Instance",
    MANAGED_INSTANCE: "ManagedInstance",
};
const SourceType = {
    AWS_EC2_INSTANCE: "AWS::EC2::Instance",
    AWS_IOT_THING: "AWS::IoT::Thing",
    AWS_SSM_MANAGEDINSTANCE: "AWS::SSM::ManagedInstance",
    AZURE_INSTANCE: "Microsoft.Compute/virtualMachines",
};
const PatchComplianceDataState = {
    AvailableSecurityUpdate: "AVAILABLE_SECURITY_UPDATE",
    Failed: "FAILED",
    Installed: "INSTALLED",
    InstalledOther: "INSTALLED_OTHER",
    InstalledPendingReboot: "INSTALLED_PENDING_REBOOT",
    InstalledRejected: "INSTALLED_REJECTED",
    Missing: "MISSING",
    NotApplicable: "NOT_APPLICABLE",
};
const PatchOperationType = {
    INSTALL: "Install",
    SCAN: "Scan",
};
const RebootOption = {
    NO_REBOOT: "NoReboot",
    REBOOT_IF_NEEDED: "RebootIfNeeded",
};
const InstancePatchStateOperatorType = {
    EQUAL: "Equal",
    GREATER_THAN: "GreaterThan",
    LESS_THAN: "LessThan",
    NOT_EQUAL: "NotEqual",
};
const InstancePropertyFilterOperator = {
    BEGIN_WITH: "BeginWith",
    EQUAL: "Equal",
    GREATER_THAN: "GreaterThan",
    LESS_THAN: "LessThan",
    NOT_EQUAL: "NotEqual",
};
const InstancePropertyFilterKey = {
    ACTIVATION_IDS: "ActivationIds",
    AGENT_VERSION: "AgentVersion",
    ASSOCIATION_STATUS: "AssociationStatus",
    DOCUMENT_NAME: "DocumentName",
    IAM_ROLE: "IamRole",
    INSTANCE_IDS: "InstanceIds",
    PING_STATUS: "PingStatus",
    PLATFORM_TYPES: "PlatformTypes",
    RESOURCE_TYPE: "ResourceType",
};
const InventoryDeletionStatus = {
    COMPLETE: "Complete",
    IN_PROGRESS: "InProgress",
};
const MaintenanceWindowExecutionStatus = {
    Cancelled: "CANCELLED",
    Cancelling: "CANCELLING",
    Failed: "FAILED",
    InProgress: "IN_PROGRESS",
    Pending: "PENDING",
    SkippedOverlapping: "SKIPPED_OVERLAPPING",
    Success: "SUCCESS",
    TimedOut: "TIMED_OUT",
};
const MaintenanceWindowTaskType = {
    Automation: "AUTOMATION",
    Lambda: "LAMBDA",
    RunCommand: "RUN_COMMAND",
    StepFunctions: "STEP_FUNCTIONS",
};
const MaintenanceWindowResourceType = {
    Instance: "INSTANCE",
    ResourceGroup: "RESOURCE_GROUP",
};
const MaintenanceWindowTaskCutoffBehavior = {
    CancelTask: "CANCEL_TASK",
    ContinueTask: "CONTINUE_TASK",
};
const OpsItemFilterKey = {
    ACCESS_REQUEST_APPROVER_ARN: "AccessRequestByApproverArn",
    ACCESS_REQUEST_APPROVER_ID: "AccessRequestByApproverId",
    ACCESS_REQUEST_IS_REPLICA: "AccessRequestByIsReplica",
    ACCESS_REQUEST_REQUESTER_ARN: "AccessRequestByRequesterArn",
    ACCESS_REQUEST_REQUESTER_ID: "AccessRequestByRequesterId",
    ACCESS_REQUEST_SOURCE_ACCOUNT_ID: "AccessRequestBySourceAccountId",
    ACCESS_REQUEST_SOURCE_OPS_ITEM_ID: "AccessRequestBySourceOpsItemId",
    ACCESS_REQUEST_SOURCE_REGION: "AccessRequestBySourceRegion",
    ACCESS_REQUEST_TARGET_RESOURCE_ID: "AccessRequestByTargetResourceId",
    ACCOUNT_ID: "AccountId",
    ACTUAL_END_TIME: "ActualEndTime",
    ACTUAL_START_TIME: "ActualStartTime",
    AUTOMATION_ID: "AutomationId",
    CATEGORY: "Category",
    CHANGE_REQUEST_APPROVER_ARN: "ChangeRequestByApproverArn",
    CHANGE_REQUEST_APPROVER_NAME: "ChangeRequestByApproverName",
    CHANGE_REQUEST_REQUESTER_ARN: "ChangeRequestByRequesterArn",
    CHANGE_REQUEST_REQUESTER_NAME: "ChangeRequestByRequesterName",
    CHANGE_REQUEST_TARGETS_RESOURCE_GROUP: "ChangeRequestByTargetsResourceGroup",
    CHANGE_REQUEST_TEMPLATE: "ChangeRequestByTemplate",
    CREATED_BY: "CreatedBy",
    CREATED_TIME: "CreatedTime",
    INSIGHT_TYPE: "InsightByType",
    LAST_MODIFIED_TIME: "LastModifiedTime",
    OPERATIONAL_DATA: "OperationalData",
    OPERATIONAL_DATA_KEY: "OperationalDataKey",
    OPERATIONAL_DATA_VALUE: "OperationalDataValue",
    OPSITEM_ID: "OpsItemId",
    OPSITEM_TYPE: "OpsItemType",
    PLANNED_END_TIME: "PlannedEndTime",
    PLANNED_START_TIME: "PlannedStartTime",
    PRIORITY: "Priority",
    RESOURCE_ID: "ResourceId",
    SEVERITY: "Severity",
    SOURCE: "Source",
    STATUS: "Status",
    TITLE: "Title",
};
const OpsItemFilterOperator = {
    CONTAINS: "Contains",
    EQUAL: "Equal",
    GREATER_THAN: "GreaterThan",
    LESS_THAN: "LessThan",
};
const OpsItemStatus = {
    APPROVED: "Approved",
    CANCELLED: "Cancelled",
    CANCELLING: "Cancelling",
    CHANGE_CALENDAR_OVERRIDE_APPROVED: "ChangeCalendarOverrideApproved",
    CHANGE_CALENDAR_OVERRIDE_REJECTED: "ChangeCalendarOverrideRejected",
    CLOSED: "Closed",
    COMPLETED_WITH_FAILURE: "CompletedWithFailure",
    COMPLETED_WITH_SUCCESS: "CompletedWithSuccess",
    FAILED: "Failed",
    IN_PROGRESS: "InProgress",
    OPEN: "Open",
    PENDING: "Pending",
    PENDING_APPROVAL: "PendingApproval",
    PENDING_CHANGE_CALENDAR_OVERRIDE: "PendingChangeCalendarOverride",
    REJECTED: "Rejected",
    RESOLVED: "Resolved",
    REVOKED: "Revoked",
    RUNBOOK_IN_PROGRESS: "RunbookInProgress",
    SCHEDULED: "Scheduled",
    TIMED_OUT: "TimedOut",
};
const ParametersFilterKey = {
    KEY_ID: "KeyId",
    NAME: "Name",
    TYPE: "Type",
};
const ParameterTier = {
    ADVANCED: "Advanced",
    INTELLIGENT_TIERING: "Intelligent-Tiering",
    STANDARD: "Standard",
};
const ParameterType = {
    SECURE_STRING: "SecureString",
    STRING: "String",
    STRING_LIST: "StringList",
};
const PatchSet = {
    Application: "APPLICATION",
    Os: "OS",
};
const PatchProperty = {
    PatchClassification: "CLASSIFICATION",
    PatchMsrcSeverity: "MSRC_SEVERITY",
    PatchPriority: "PRIORITY",
    PatchProductFamily: "PRODUCT_FAMILY",
    PatchSeverity: "SEVERITY",
    Product: "PRODUCT",
};
const SessionFilterKey = {
    ACCESS_TYPE: "AccessType",
    INVOKED_AFTER: "InvokedAfter",
    INVOKED_BEFORE: "InvokedBefore",
    OWNER: "Owner",
    SESSION_ID: "SessionId",
    STATUS: "Status",
    TARGET_ID: "Target",
};
const SessionState = {
    ACTIVE: "Active",
    HISTORY: "History",
};
const SessionStatus = {
    CONNECTED: "Connected",
    CONNECTING: "Connecting",
    DISCONNECTED: "Disconnected",
    FAILED: "Failed",
    TERMINATED: "Terminated",
    TERMINATING: "Terminating",
};
const CalendarState = {
    CLOSED: "CLOSED",
    OPEN: "OPEN",
};
const CommandInvocationStatus = {
    CANCELLED: "Cancelled",
    CANCELLING: "Cancelling",
    DELAYED: "Delayed",
    FAILED: "Failed",
    IN_PROGRESS: "InProgress",
    PENDING: "Pending",
    SUCCESS: "Success",
    TIMED_OUT: "TimedOut",
};
const ConnectionStatus = {
    CONNECTED: "connected",
    NOT_CONNECTED: "notconnected",
};
const AttachmentHashType = {
    SHA256: "Sha256",
};
const ImpactType = {
    MUTATING: "Mutating",
    NON_MUTATING: "NonMutating",
    UNDETERMINED: "Undetermined",
};
const ExecutionPreviewStatus = {
    FAILED: "Failed",
    IN_PROGRESS: "InProgress",
    PENDING: "Pending",
    SUCCESS: "Success",
};
const InventoryQueryOperatorType = {
    BEGIN_WITH: "BeginWith",
    EQUAL: "Equal",
    EXISTS: "Exists",
    GREATER_THAN: "GreaterThan",
    LESS_THAN: "LessThan",
    NOT_EQUAL: "NotEqual",
};
const InventoryAttributeDataType = {
    NUMBER: "number",
    STRING: "string",
};
const NotificationEvent = {
    ALL: "All",
    CANCELLED: "Cancelled",
    FAILED: "Failed",
    IN_PROGRESS: "InProgress",
    SUCCESS: "Success",
    TIMED_OUT: "TimedOut",
};
const NotificationType = {
    Command: "Command",
    Invocation: "Invocation",
};
const OpsFilterOperatorType = {
    BEGIN_WITH: "BeginWith",
    EQUAL: "Equal",
    EXISTS: "Exists",
    GREATER_THAN: "GreaterThan",
    LESS_THAN: "LessThan",
    NOT_EQUAL: "NotEqual",
};
const AssociationFilterKey = {
    AssociationId: "AssociationId",
    AssociationName: "AssociationName",
    CloudConnectorId: "CloudConnectorId",
    InstanceId: "InstanceId",
    LastExecutedAfter: "LastExecutedAfter",
    LastExecutedBefore: "LastExecutedBefore",
    Name: "Name",
    ResourceGroupName: "ResourceGroupName",
    Status: "AssociationStatusName",
};
const CloudConnectorFilterKey = {
    SubscriptionId: "SubscriptionId",
    TenantId: "TenantId",
};
const CommandFilterKey = {
    DOCUMENT_NAME: "DocumentName",
    EXECUTION_STAGE: "ExecutionStage",
    INVOKED_AFTER: "InvokedAfter",
    INVOKED_BEFORE: "InvokedBefore",
    STATUS: "Status",
};
const CommandPluginStatus = {
    CANCELLED: "Cancelled",
    FAILED: "Failed",
    IN_PROGRESS: "InProgress",
    PENDING: "Pending",
    SUCCESS: "Success",
    TIMED_OUT: "TimedOut",
};
const CommandStatus = {
    CANCELLED: "Cancelled",
    CANCELLING: "Cancelling",
    FAILED: "Failed",
    IN_PROGRESS: "InProgress",
    PENDING: "Pending",
    SUCCESS: "Success",
    TIMED_OUT: "TimedOut",
};
const ComplianceQueryOperatorType = {
    BeginWith: "BEGIN_WITH",
    Equal: "EQUAL",
    GreaterThan: "GREATER_THAN",
    LessThan: "LESS_THAN",
    NotEqual: "NOT_EQUAL",
};
const ComplianceSeverity = {
    Critical: "CRITICAL",
    High: "HIGH",
    Informational: "INFORMATIONAL",
    Low: "LOW",
    Medium: "MEDIUM",
    Unspecified: "UNSPECIFIED",
};
const ComplianceStatus = {
    Compliant: "COMPLIANT",
    NonCompliant: "NON_COMPLIANT",
};
const DocumentMetadataEnum = {
    DocumentReviews: "DocumentReviews",
};
const DocumentReviewCommentType = {
    Comment: "Comment",
};
const DocumentFilterKey = {
    DocumentType: "DocumentType",
    Name: "Name",
    Owner: "Owner",
    PlatformTypes: "PlatformTypes",
};
const NodeFilterKey = {
    ACCOUNT_ID: "AccountId",
    AGENT_TYPE: "AgentType",
    AGENT_VERSION: "AgentVersion",
    AVAILABILITY_ZONE: "AvailabilityZone",
    AVAILABILITY_ZONE_ID: "AvailabilityZoneId",
    COMPUTER_NAME: "ComputerName",
    INSTANCE_ID: "InstanceId",
    INSTANCE_STATUS: "InstanceStatus",
    IP_ADDRESS: "IpAddress",
    MANAGED_STATUS: "ManagedStatus",
    ORGANIZATIONAL_UNIT_ID: "OrganizationalUnitId",
    ORGANIZATIONAL_UNIT_PATH: "OrganizationalUnitPath",
    PLATFORM_NAME: "PlatformName",
    PLATFORM_TYPE: "PlatformType",
    PLATFORM_VERSION: "PlatformVersion",
    REGION: "Region",
    RESOURCE_TYPE: "ResourceType",
    SOURCE_ID: "SourceId",
    SOURCE_LOCATION: "SourceLocation",
    SOURCE_TYPE: "SourceType",
};
const NodeFilterOperatorType = {
    BEGIN_WITH: "BeginWith",
    EQUAL: "Equal",
    NOT_EQUAL: "NotEqual",
};
const ManagedStatus = {
    ALL: "All",
    MANAGED: "Managed",
    UNMANAGED: "Unmanaged",
};
const NodeAggregatorType = {
    COUNT: "Count",
};
const NodeAttributeName = {
    AGENT_VERSION: "AgentVersion",
    AVAILABILITY_ZONE: "AvailabilityZone",
    PLATFORM_NAME: "PlatformName",
    PLATFORM_TYPE: "PlatformType",
    PLATFORM_VERSION: "PlatformVersion",
    REGION: "Region",
    RESOURCE_TYPE: "ResourceType",
    SOURCE_TYPE: "SourceType",
};
const NodeTypeName = {
    INSTANCE: "Instance",
};
const OpsItemEventFilterKey = {
    OPSITEM_ID: "OpsItemId",
};
const OpsItemEventFilterOperator = {
    EQUAL: "Equal",
};
const OpsItemRelatedItemsFilterKey = {
    ASSOCIATION_ID: "AssociationId",
    RESOURCE_TYPE: "ResourceType",
    RESOURCE_URI: "ResourceUri",
};
const OpsItemRelatedItemsFilterOperator = {
    EQUAL: "Equal",
};
const LastResourceDataSyncStatus = {
    FAILED: "Failed",
    INPROGRESS: "InProgress",
    SUCCESSFUL: "Successful",
};
const ComplianceUploadType = {
    Complete: "COMPLETE",
    Partial: "PARTIAL",
};
const SignalType = {
    APPROVE: "Approve",
    REJECT: "Reject",
    RESUME: "Resume",
    REVOKE: "Revoke",
    START_STEP: "StartStep",
    STOP_STEP: "StopStep",
};
const StopType = {
    CANCEL: "Cancel",
    COMPLETE: "Complete",
};
const DocumentReviewAction = {
    Approve: "Approve",
    Reject: "Reject",
    SendForReview: "SendForReview",
    UpdateReview: "UpdateReview",
};
const ValidationFindingCode = {
    AWS_ROLE_ASSUMPTION_FAILED: "AwsRoleAssumptionFailed",
    OUTBOUND_WEB_IDENTITY_FEDERATION_DISABLED: "OutboundWebIdentityFederationDisabled",
    PROVIDER_CREDENTIAL_CREATION_FAILED: "ProviderCredentialCreationFailed",
    SUBSCRIPTION_ACCESSIBLE: "SubscriptionAccessible",
    TARGET_INACCESSIBLE: "TargetInaccessible",
    TARGET_STATE_WARNING: "TargetStateWarning",
    TARGET_UNUSABLE: "TargetUnusable",
    TENANT_SUMMARY: "TenantSummary",
    WEB_IDENTITY_TOKEN_FAILED: "WebIdentityTokenFailed",
};
const ValidationFindingScopeType = {
    AZURE_SUBSCRIPTION: "azure:subscription",
    AZURE_TENANT: "azure:tenant",
};
const ValidationFindingType = {
    ERROR: "ERROR",
    INFO: "INFO",
    WARN: "WARN",
};

exports.AccessDeniedException = AccessDeniedException;
exports.AccessDeniedException$ = AccessDeniedException$;
exports.AccessRequestStatus = AccessRequestStatus;
exports.AccessType = AccessType;
exports.AccountSharingInfo$ = AccountSharingInfo$;
exports.Activation$ = Activation$;
exports.AddTagsToResource$ = AddTagsToResource$;
exports.AddTagsToResourceCommand = AddTagsToResourceCommand;
exports.AddTagsToResourceRequest$ = AddTagsToResourceRequest$;
exports.AddTagsToResourceResult$ = AddTagsToResourceResult$;
exports.Alarm$ = Alarm$;
exports.AlarmConfiguration$ = AlarmConfiguration$;
exports.AlarmStateInformation$ = AlarmStateInformation$;
exports.AlreadyExistsException = AlreadyExistsException;
exports.AlreadyExistsException$ = AlreadyExistsException$;
exports.AssociateOpsItemRelatedItem$ = AssociateOpsItemRelatedItem$;
exports.AssociateOpsItemRelatedItemCommand = AssociateOpsItemRelatedItemCommand;
exports.AssociateOpsItemRelatedItemRequest$ = AssociateOpsItemRelatedItemRequest$;
exports.AssociateOpsItemRelatedItemResponse$ = AssociateOpsItemRelatedItemResponse$;
exports.AssociatedInstances = AssociatedInstances;
exports.AssociatedInstances$ = AssociatedInstances$;
exports.Association$ = Association$;
exports.AssociationAlreadyExists = AssociationAlreadyExists;
exports.AssociationAlreadyExists$ = AssociationAlreadyExists$;
exports.AssociationComplianceSeverity = AssociationComplianceSeverity;
exports.AssociationDescription$ = AssociationDescription$;
exports.AssociationDoesNotExist = AssociationDoesNotExist;
exports.AssociationDoesNotExist$ = AssociationDoesNotExist$;
exports.AssociationExecution$ = AssociationExecution$;
exports.AssociationExecutionDoesNotExist = AssociationExecutionDoesNotExist;
exports.AssociationExecutionDoesNotExist$ = AssociationExecutionDoesNotExist$;
exports.AssociationExecutionFilter$ = AssociationExecutionFilter$;
exports.AssociationExecutionFilterKey = AssociationExecutionFilterKey;
exports.AssociationExecutionTarget$ = AssociationExecutionTarget$;
exports.AssociationExecutionTargetsFilter$ = AssociationExecutionTargetsFilter$;
exports.AssociationExecutionTargetsFilterKey = AssociationExecutionTargetsFilterKey;
exports.AssociationFilter$ = AssociationFilter$;
exports.AssociationFilterKey = AssociationFilterKey;
exports.AssociationFilterOperatorType = AssociationFilterOperatorType;
exports.AssociationLimitExceeded = AssociationLimitExceeded;
exports.AssociationLimitExceeded$ = AssociationLimitExceeded$;
exports.AssociationOverview$ = AssociationOverview$;
exports.AssociationStatus$ = AssociationStatus$;
exports.AssociationStatusName = AssociationStatusName;
exports.AssociationSyncCompliance = AssociationSyncCompliance;
exports.AssociationVersionInfo$ = AssociationVersionInfo$;
exports.AssociationVersionLimitExceeded = AssociationVersionLimitExceeded;
exports.AssociationVersionLimitExceeded$ = AssociationVersionLimitExceeded$;
exports.AttachmentContent$ = AttachmentContent$;
exports.AttachmentHashType = AttachmentHashType;
exports.AttachmentInformation$ = AttachmentInformation$;
exports.AttachmentsSource$ = AttachmentsSource$;
exports.AttachmentsSourceKey = AttachmentsSourceKey;
exports.AutomationDefinitionNotApprovedException = AutomationDefinitionNotApprovedException;
exports.AutomationDefinitionNotApprovedException$ = AutomationDefinitionNotApprovedException$;
exports.AutomationDefinitionNotFoundException = AutomationDefinitionNotFoundException;
exports.AutomationDefinitionNotFoundException$ = AutomationDefinitionNotFoundException$;
exports.AutomationDefinitionVersionNotFoundException = AutomationDefinitionVersionNotFoundException;
exports.AutomationDefinitionVersionNotFoundException$ = AutomationDefinitionVersionNotFoundException$;
exports.AutomationExecution$ = AutomationExecution$;
exports.AutomationExecutionFilter$ = AutomationExecutionFilter$;
exports.AutomationExecutionFilterKey = AutomationExecutionFilterKey;
exports.AutomationExecutionInputs$ = AutomationExecutionInputs$;
exports.AutomationExecutionLimitExceededException = AutomationExecutionLimitExceededException;
exports.AutomationExecutionLimitExceededException$ = AutomationExecutionLimitExceededException$;
exports.AutomationExecutionMetadata$ = AutomationExecutionMetadata$;
exports.AutomationExecutionNotFoundException = AutomationExecutionNotFoundException;
exports.AutomationExecutionNotFoundException$ = AutomationExecutionNotFoundException$;
exports.AutomationExecutionPreview$ = AutomationExecutionPreview$;
exports.AutomationExecutionStatus = AutomationExecutionStatus;
exports.AutomationStepNotFoundException = AutomationStepNotFoundException;
exports.AutomationStepNotFoundException$ = AutomationStepNotFoundException$;
exports.AutomationSubtype = AutomationSubtype;
exports.AutomationType = AutomationType;
exports.AzureConfiguration$ = AzureConfiguration$;
exports.AzureSubscription$ = AzureSubscription$;
exports.BaselineOverride$ = BaselineOverride$;
exports.CalendarState = CalendarState;
exports.CancelCommand$ = CancelCommand$;
exports.CancelCommandCommand = CancelCommandCommand;
exports.CancelCommandRequest$ = CancelCommandRequest$;
exports.CancelCommandResult$ = CancelCommandResult$;
exports.CancelMaintenanceWindowExecution$ = CancelMaintenanceWindowExecution$;
exports.CancelMaintenanceWindowExecutionCommand = CancelMaintenanceWindowExecutionCommand;
exports.CancelMaintenanceWindowExecutionRequest$ = CancelMaintenanceWindowExecutionRequest$;
exports.CancelMaintenanceWindowExecutionResult$ = CancelMaintenanceWindowExecutionResult$;
exports.CloudConnectorConfiguration$ = CloudConnectorConfiguration$;
exports.CloudConnectorFilter$ = CloudConnectorFilter$;
exports.CloudConnectorFilterKey = CloudConnectorFilterKey;
exports.CloudConnectorSummary$ = CloudConnectorSummary$;
exports.CloudWatchOutputConfig$ = CloudWatchOutputConfig$;
exports.Command$ = Command$;
exports.CommandFilter$ = CommandFilter$;
exports.CommandFilterKey = CommandFilterKey;
exports.CommandInvocation$ = CommandInvocation$;
exports.CommandInvocationStatus = CommandInvocationStatus;
exports.CommandPlugin$ = CommandPlugin$;
exports.CommandPluginStatus = CommandPluginStatus;
exports.CommandStatus = CommandStatus;
exports.ComplianceExecutionSummary$ = ComplianceExecutionSummary$;
exports.ComplianceItem$ = ComplianceItem$;
exports.ComplianceItemEntry$ = ComplianceItemEntry$;
exports.ComplianceQueryOperatorType = ComplianceQueryOperatorType;
exports.ComplianceSeverity = ComplianceSeverity;
exports.ComplianceStatus = ComplianceStatus;
exports.ComplianceStringFilter$ = ComplianceStringFilter$;
exports.ComplianceSummaryItem$ = ComplianceSummaryItem$;
exports.ComplianceTypeCountLimitExceededException = ComplianceTypeCountLimitExceededException;
exports.ComplianceTypeCountLimitExceededException$ = ComplianceTypeCountLimitExceededException$;
exports.ComplianceUploadType = ComplianceUploadType;
exports.CompliantSummary$ = CompliantSummary$;
exports.ConfigurationTargets$ = ConfigurationTargets$;
exports.ConflictException = ConflictException;
exports.ConflictException$ = ConflictException$;
exports.ConnectionStatus = ConnectionStatus;
exports.CreateActivation$ = CreateActivation$;
exports.CreateActivationCommand = CreateActivationCommand;
exports.CreateActivationRequest$ = CreateActivationRequest$;
exports.CreateActivationResult$ = CreateActivationResult$;
exports.CreateAssociation$ = CreateAssociation$;
exports.CreateAssociationBatch$ = CreateAssociationBatch$;
exports.CreateAssociationBatchCommand = CreateAssociationBatchCommand;
exports.CreateAssociationBatchRequest$ = CreateAssociationBatchRequest$;
exports.CreateAssociationBatchRequestEntry$ = CreateAssociationBatchRequestEntry$;
exports.CreateAssociationBatchResult$ = CreateAssociationBatchResult$;
exports.CreateAssociationCommand = CreateAssociationCommand;
exports.CreateAssociationRequest$ = CreateAssociationRequest$;
exports.CreateAssociationResult$ = CreateAssociationResult$;
exports.CreateCloudConnector$ = CreateCloudConnector$;
exports.CreateCloudConnectorCommand = CreateCloudConnectorCommand;
exports.CreateCloudConnectorRequest$ = CreateCloudConnectorRequest$;
exports.CreateCloudConnectorResult$ = CreateCloudConnectorResult$;
exports.CreateDocument$ = CreateDocument$;
exports.CreateDocumentCommand = CreateDocumentCommand;
exports.CreateDocumentRequest$ = CreateDocumentRequest$;
exports.CreateDocumentResult$ = CreateDocumentResult$;
exports.CreateMaintenanceWindow$ = CreateMaintenanceWindow$;
exports.CreateMaintenanceWindowCommand = CreateMaintenanceWindowCommand;
exports.CreateMaintenanceWindowRequest$ = CreateMaintenanceWindowRequest$;
exports.CreateMaintenanceWindowResult$ = CreateMaintenanceWindowResult$;
exports.CreateOpsItem$ = CreateOpsItem$;
exports.CreateOpsItemCommand = CreateOpsItemCommand;
exports.CreateOpsItemRequest$ = CreateOpsItemRequest$;
exports.CreateOpsItemResponse$ = CreateOpsItemResponse$;
exports.CreateOpsMetadata$ = CreateOpsMetadata$;
exports.CreateOpsMetadataCommand = CreateOpsMetadataCommand;
exports.CreateOpsMetadataRequest$ = CreateOpsMetadataRequest$;
exports.CreateOpsMetadataResult$ = CreateOpsMetadataResult$;
exports.CreatePatchBaseline$ = CreatePatchBaseline$;
exports.CreatePatchBaselineCommand = CreatePatchBaselineCommand;
exports.CreatePatchBaselineRequest$ = CreatePatchBaselineRequest$;
exports.CreatePatchBaselineResult$ = CreatePatchBaselineResult$;
exports.CreateResourceDataSync$ = CreateResourceDataSync$;
exports.CreateResourceDataSyncCommand = CreateResourceDataSyncCommand;
exports.CreateResourceDataSyncRequest$ = CreateResourceDataSyncRequest$;
exports.CreateResourceDataSyncResult$ = CreateResourceDataSyncResult$;
exports.Credentials$ = Credentials$;
exports.CustomSchemaCountLimitExceededException = CustomSchemaCountLimitExceededException;
exports.CustomSchemaCountLimitExceededException$ = CustomSchemaCountLimitExceededException$;
exports.DeleteActivation$ = DeleteActivation$;
exports.DeleteActivationCommand = DeleteActivationCommand;
exports.DeleteActivationRequest$ = DeleteActivationRequest$;
exports.DeleteActivationResult$ = DeleteActivationResult$;
exports.DeleteAssociation$ = DeleteAssociation$;
exports.DeleteAssociationCommand = DeleteAssociationCommand;
exports.DeleteAssociationRequest$ = DeleteAssociationRequest$;
exports.DeleteAssociationResult$ = DeleteAssociationResult$;
exports.DeleteCloudConnector$ = DeleteCloudConnector$;
exports.DeleteCloudConnectorCommand = DeleteCloudConnectorCommand;
exports.DeleteCloudConnectorRequest$ = DeleteCloudConnectorRequest$;
exports.DeleteCloudConnectorResult$ = DeleteCloudConnectorResult$;
exports.DeleteDocument$ = DeleteDocument$;
exports.DeleteDocumentCommand = DeleteDocumentCommand;
exports.DeleteDocumentRequest$ = DeleteDocumentRequest$;
exports.DeleteDocumentResult$ = DeleteDocumentResult$;
exports.DeleteInventory$ = DeleteInventory$;
exports.DeleteInventoryCommand = DeleteInventoryCommand;
exports.DeleteInventoryRequest$ = DeleteInventoryRequest$;
exports.DeleteInventoryResult$ = DeleteInventoryResult$;
exports.DeleteMaintenanceWindow$ = DeleteMaintenanceWindow$;
exports.DeleteMaintenanceWindowCommand = DeleteMaintenanceWindowCommand;
exports.DeleteMaintenanceWindowRequest$ = DeleteMaintenanceWindowRequest$;
exports.DeleteMaintenanceWindowResult$ = DeleteMaintenanceWindowResult$;
exports.DeleteOpsItem$ = DeleteOpsItem$;
exports.DeleteOpsItemCommand = DeleteOpsItemCommand;
exports.DeleteOpsItemRequest$ = DeleteOpsItemRequest$;
exports.DeleteOpsItemResponse$ = DeleteOpsItemResponse$;
exports.DeleteOpsMetadata$ = DeleteOpsMetadata$;
exports.DeleteOpsMetadataCommand = DeleteOpsMetadataCommand;
exports.DeleteOpsMetadataRequest$ = DeleteOpsMetadataRequest$;
exports.DeleteOpsMetadataResult$ = DeleteOpsMetadataResult$;
exports.DeleteParameter$ = DeleteParameter$;
exports.DeleteParameterCommand = DeleteParameterCommand;
exports.DeleteParameterRequest$ = DeleteParameterRequest$;
exports.DeleteParameterResult$ = DeleteParameterResult$;
exports.DeleteParameters$ = DeleteParameters$;
exports.DeleteParametersCommand = DeleteParametersCommand;
exports.DeleteParametersRequest$ = DeleteParametersRequest$;
exports.DeleteParametersResult$ = DeleteParametersResult$;
exports.DeletePatchBaseline$ = DeletePatchBaseline$;
exports.DeletePatchBaselineCommand = DeletePatchBaselineCommand;
exports.DeletePatchBaselineRequest$ = DeletePatchBaselineRequest$;
exports.DeletePatchBaselineResult$ = DeletePatchBaselineResult$;
exports.DeleteResourceDataSync$ = DeleteResourceDataSync$;
exports.DeleteResourceDataSyncCommand = DeleteResourceDataSyncCommand;
exports.DeleteResourceDataSyncRequest$ = DeleteResourceDataSyncRequest$;
exports.DeleteResourceDataSyncResult$ = DeleteResourceDataSyncResult$;
exports.DeleteResourcePolicy$ = DeleteResourcePolicy$;
exports.DeleteResourcePolicyCommand = DeleteResourcePolicyCommand;
exports.DeleteResourcePolicyRequest$ = DeleteResourcePolicyRequest$;
exports.DeleteResourcePolicyResponse$ = DeleteResourcePolicyResponse$;
exports.DeregisterManagedInstance$ = DeregisterManagedInstance$;
exports.DeregisterManagedInstanceCommand = DeregisterManagedInstanceCommand;
exports.DeregisterManagedInstanceRequest$ = DeregisterManagedInstanceRequest$;
exports.DeregisterManagedInstanceResult$ = DeregisterManagedInstanceResult$;
exports.DeregisterPatchBaselineForPatchGroup$ = DeregisterPatchBaselineForPatchGroup$;
exports.DeregisterPatchBaselineForPatchGroupCommand = DeregisterPatchBaselineForPatchGroupCommand;
exports.DeregisterPatchBaselineForPatchGroupRequest$ = DeregisterPatchBaselineForPatchGroupRequest$;
exports.DeregisterPatchBaselineForPatchGroupResult$ = DeregisterPatchBaselineForPatchGroupResult$;
exports.DeregisterTargetFromMaintenanceWindow$ = DeregisterTargetFromMaintenanceWindow$;
exports.DeregisterTargetFromMaintenanceWindowCommand = DeregisterTargetFromMaintenanceWindowCommand;
exports.DeregisterTargetFromMaintenanceWindowRequest$ = DeregisterTargetFromMaintenanceWindowRequest$;
exports.DeregisterTargetFromMaintenanceWindowResult$ = DeregisterTargetFromMaintenanceWindowResult$;
exports.DeregisterTaskFromMaintenanceWindow$ = DeregisterTaskFromMaintenanceWindow$;
exports.DeregisterTaskFromMaintenanceWindowCommand = DeregisterTaskFromMaintenanceWindowCommand;
exports.DeregisterTaskFromMaintenanceWindowRequest$ = DeregisterTaskFromMaintenanceWindowRequest$;
exports.DeregisterTaskFromMaintenanceWindowResult$ = DeregisterTaskFromMaintenanceWindowResult$;
exports.DescribeActivations$ = DescribeActivations$;
exports.DescribeActivationsCommand = DescribeActivationsCommand;
exports.DescribeActivationsFilter$ = DescribeActivationsFilter$;
exports.DescribeActivationsFilterKeys = DescribeActivationsFilterKeys;
exports.DescribeActivationsRequest$ = DescribeActivationsRequest$;
exports.DescribeActivationsResult$ = DescribeActivationsResult$;
exports.DescribeAssociation$ = DescribeAssociation$;
exports.DescribeAssociationCommand = DescribeAssociationCommand;
exports.DescribeAssociationExecutionTargets$ = DescribeAssociationExecutionTargets$;
exports.DescribeAssociationExecutionTargetsCommand = DescribeAssociationExecutionTargetsCommand;
exports.DescribeAssociationExecutionTargetsRequest$ = DescribeAssociationExecutionTargetsRequest$;
exports.DescribeAssociationExecutionTargetsResult$ = DescribeAssociationExecutionTargetsResult$;
exports.DescribeAssociationExecutions$ = DescribeAssociationExecutions$;
exports.DescribeAssociationExecutionsCommand = DescribeAssociationExecutionsCommand;
exports.DescribeAssociationExecutionsRequest$ = DescribeAssociationExecutionsRequest$;
exports.DescribeAssociationExecutionsResult$ = DescribeAssociationExecutionsResult$;
exports.DescribeAssociationRequest$ = DescribeAssociationRequest$;
exports.DescribeAssociationResult$ = DescribeAssociationResult$;
exports.DescribeAutomationExecutions$ = DescribeAutomationExecutions$;
exports.DescribeAutomationExecutionsCommand = DescribeAutomationExecutionsCommand;
exports.DescribeAutomationExecutionsRequest$ = DescribeAutomationExecutionsRequest$;
exports.DescribeAutomationExecutionsResult$ = DescribeAutomationExecutionsResult$;
exports.DescribeAutomationStepExecutions$ = DescribeAutomationStepExecutions$;
exports.DescribeAutomationStepExecutionsCommand = DescribeAutomationStepExecutionsCommand;
exports.DescribeAutomationStepExecutionsRequest$ = DescribeAutomationStepExecutionsRequest$;
exports.DescribeAutomationStepExecutionsResult$ = DescribeAutomationStepExecutionsResult$;
exports.DescribeAvailablePatches$ = DescribeAvailablePatches$;
exports.DescribeAvailablePatchesCommand = DescribeAvailablePatchesCommand;
exports.DescribeAvailablePatchesRequest$ = DescribeAvailablePatchesRequest$;
exports.DescribeAvailablePatchesResult$ = DescribeAvailablePatchesResult$;
exports.DescribeDocument$ = DescribeDocument$;
exports.DescribeDocumentCommand = DescribeDocumentCommand;
exports.DescribeDocumentPermission$ = DescribeDocumentPermission$;
exports.DescribeDocumentPermissionCommand = DescribeDocumentPermissionCommand;
exports.DescribeDocumentPermissionRequest$ = DescribeDocumentPermissionRequest$;
exports.DescribeDocumentPermissionResponse$ = DescribeDocumentPermissionResponse$;
exports.DescribeDocumentRequest$ = DescribeDocumentRequest$;
exports.DescribeDocumentResult$ = DescribeDocumentResult$;
exports.DescribeEffectiveInstanceAssociations$ = DescribeEffectiveInstanceAssociations$;
exports.DescribeEffectiveInstanceAssociationsCommand = DescribeEffectiveInstanceAssociationsCommand;
exports.DescribeEffectiveInstanceAssociationsRequest$ = DescribeEffectiveInstanceAssociationsRequest$;
exports.DescribeEffectiveInstanceAssociationsResult$ = DescribeEffectiveInstanceAssociationsResult$;
exports.DescribeEffectivePatchesForPatchBaseline$ = DescribeEffectivePatchesForPatchBaseline$;
exports.DescribeEffectivePatchesForPatchBaselineCommand = DescribeEffectivePatchesForPatchBaselineCommand;
exports.DescribeEffectivePatchesForPatchBaselineRequest$ = DescribeEffectivePatchesForPatchBaselineRequest$;
exports.DescribeEffectivePatchesForPatchBaselineResult$ = DescribeEffectivePatchesForPatchBaselineResult$;
exports.DescribeInstanceAssociationsStatus$ = DescribeInstanceAssociationsStatus$;
exports.DescribeInstanceAssociationsStatusCommand = DescribeInstanceAssociationsStatusCommand;
exports.DescribeInstanceAssociationsStatusRequest$ = DescribeInstanceAssociationsStatusRequest$;
exports.DescribeInstanceAssociationsStatusResult$ = DescribeInstanceAssociationsStatusResult$;
exports.DescribeInstanceInformation$ = DescribeInstanceInformation$;
exports.DescribeInstanceInformationCommand = DescribeInstanceInformationCommand;
exports.DescribeInstanceInformationRequest$ = DescribeInstanceInformationRequest$;
exports.DescribeInstanceInformationResult$ = DescribeInstanceInformationResult$;
exports.DescribeInstancePatchStates$ = DescribeInstancePatchStates$;
exports.DescribeInstancePatchStatesCommand = DescribeInstancePatchStatesCommand;
exports.DescribeInstancePatchStatesForPatchGroup$ = DescribeInstancePatchStatesForPatchGroup$;
exports.DescribeInstancePatchStatesForPatchGroupCommand = DescribeInstancePatchStatesForPatchGroupCommand;
exports.DescribeInstancePatchStatesForPatchGroupRequest$ = DescribeInstancePatchStatesForPatchGroupRequest$;
exports.DescribeInstancePatchStatesForPatchGroupResult$ = DescribeInstancePatchStatesForPatchGroupResult$;
exports.DescribeInstancePatchStatesRequest$ = DescribeInstancePatchStatesRequest$;
exports.DescribeInstancePatchStatesResult$ = DescribeInstancePatchStatesResult$;
exports.DescribeInstancePatches$ = DescribeInstancePatches$;
exports.DescribeInstancePatchesCommand = DescribeInstancePatchesCommand;
exports.DescribeInstancePatchesRequest$ = DescribeInstancePatchesRequest$;
exports.DescribeInstancePatchesResult$ = DescribeInstancePatchesResult$;
exports.DescribeInstanceProperties$ = DescribeInstanceProperties$;
exports.DescribeInstancePropertiesCommand = DescribeInstancePropertiesCommand;
exports.DescribeInstancePropertiesRequest$ = DescribeInstancePropertiesRequest$;
exports.DescribeInstancePropertiesResult$ = DescribeInstancePropertiesResult$;
exports.DescribeInventoryDeletions$ = DescribeInventoryDeletions$;
exports.DescribeInventoryDeletionsCommand = DescribeInventoryDeletionsCommand;
exports.DescribeInventoryDeletionsRequest$ = DescribeInventoryDeletionsRequest$;
exports.DescribeInventoryDeletionsResult$ = DescribeInventoryDeletionsResult$;
exports.DescribeMaintenanceWindowExecutionTaskInvocations$ = DescribeMaintenanceWindowExecutionTaskInvocations$;
exports.DescribeMaintenanceWindowExecutionTaskInvocationsCommand = DescribeMaintenanceWindowExecutionTaskInvocationsCommand;
exports.DescribeMaintenanceWindowExecutionTaskInvocationsRequest$ = DescribeMaintenanceWindowExecutionTaskInvocationsRequest$;
exports.DescribeMaintenanceWindowExecutionTaskInvocationsResult$ = DescribeMaintenanceWindowExecutionTaskInvocationsResult$;
exports.DescribeMaintenanceWindowExecutionTasks$ = DescribeMaintenanceWindowExecutionTasks$;
exports.DescribeMaintenanceWindowExecutionTasksCommand = DescribeMaintenanceWindowExecutionTasksCommand;
exports.DescribeMaintenanceWindowExecutionTasksRequest$ = DescribeMaintenanceWindowExecutionTasksRequest$;
exports.DescribeMaintenanceWindowExecutionTasksResult$ = DescribeMaintenanceWindowExecutionTasksResult$;
exports.DescribeMaintenanceWindowExecutions$ = DescribeMaintenanceWindowExecutions$;
exports.DescribeMaintenanceWindowExecutionsCommand = DescribeMaintenanceWindowExecutionsCommand;
exports.DescribeMaintenanceWindowExecutionsRequest$ = DescribeMaintenanceWindowExecutionsRequest$;
exports.DescribeMaintenanceWindowExecutionsResult$ = DescribeMaintenanceWindowExecutionsResult$;
exports.DescribeMaintenanceWindowSchedule$ = DescribeMaintenanceWindowSchedule$;
exports.DescribeMaintenanceWindowScheduleCommand = DescribeMaintenanceWindowScheduleCommand;
exports.DescribeMaintenanceWindowScheduleRequest$ = DescribeMaintenanceWindowScheduleRequest$;
exports.DescribeMaintenanceWindowScheduleResult$ = DescribeMaintenanceWindowScheduleResult$;
exports.DescribeMaintenanceWindowTargets$ = DescribeMaintenanceWindowTargets$;
exports.DescribeMaintenanceWindowTargetsCommand = DescribeMaintenanceWindowTargetsCommand;
exports.DescribeMaintenanceWindowTargetsRequest$ = DescribeMaintenanceWindowTargetsRequest$;
exports.DescribeMaintenanceWindowTargetsResult$ = DescribeMaintenanceWindowTargetsResult$;
exports.DescribeMaintenanceWindowTasks$ = DescribeMaintenanceWindowTasks$;
exports.DescribeMaintenanceWindowTasksCommand = DescribeMaintenanceWindowTasksCommand;
exports.DescribeMaintenanceWindowTasksRequest$ = DescribeMaintenanceWindowTasksRequest$;
exports.DescribeMaintenanceWindowTasksResult$ = DescribeMaintenanceWindowTasksResult$;
exports.DescribeMaintenanceWindows$ = DescribeMaintenanceWindows$;
exports.DescribeMaintenanceWindowsCommand = DescribeMaintenanceWindowsCommand;
exports.DescribeMaintenanceWindowsForTarget$ = DescribeMaintenanceWindowsForTarget$;
exports.DescribeMaintenanceWindowsForTargetCommand = DescribeMaintenanceWindowsForTargetCommand;
exports.DescribeMaintenanceWindowsForTargetRequest$ = DescribeMaintenanceWindowsForTargetRequest$;
exports.DescribeMaintenanceWindowsForTargetResult$ = DescribeMaintenanceWindowsForTargetResult$;
exports.DescribeMaintenanceWindowsRequest$ = DescribeMaintenanceWindowsRequest$;
exports.DescribeMaintenanceWindowsResult$ = DescribeMaintenanceWindowsResult$;
exports.DescribeOpsItems$ = DescribeOpsItems$;
exports.DescribeOpsItemsCommand = DescribeOpsItemsCommand;
exports.DescribeOpsItemsRequest$ = DescribeOpsItemsRequest$;
exports.DescribeOpsItemsResponse$ = DescribeOpsItemsResponse$;
exports.DescribeParameters$ = DescribeParameters$;
exports.DescribeParametersCommand = DescribeParametersCommand;
exports.DescribeParametersRequest$ = DescribeParametersRequest$;
exports.DescribeParametersResult$ = DescribeParametersResult$;
exports.DescribePatchBaselines$ = DescribePatchBaselines$;
exports.DescribePatchBaselinesCommand = DescribePatchBaselinesCommand;
exports.DescribePatchBaselinesRequest$ = DescribePatchBaselinesRequest$;
exports.DescribePatchBaselinesResult$ = DescribePatchBaselinesResult$;
exports.DescribePatchGroupState$ = DescribePatchGroupState$;
exports.DescribePatchGroupStateCommand = DescribePatchGroupStateCommand;
exports.DescribePatchGroupStateRequest$ = DescribePatchGroupStateRequest$;
exports.DescribePatchGroupStateResult$ = DescribePatchGroupStateResult$;
exports.DescribePatchGroups$ = DescribePatchGroups$;
exports.DescribePatchGroupsCommand = DescribePatchGroupsCommand;
exports.DescribePatchGroupsRequest$ = DescribePatchGroupsRequest$;
exports.DescribePatchGroupsResult$ = DescribePatchGroupsResult$;
exports.DescribePatchProperties$ = DescribePatchProperties$;
exports.DescribePatchPropertiesCommand = DescribePatchPropertiesCommand;
exports.DescribePatchPropertiesRequest$ = DescribePatchPropertiesRequest$;
exports.DescribePatchPropertiesResult$ = DescribePatchPropertiesResult$;
exports.DescribeSessions$ = DescribeSessions$;
exports.DescribeSessionsCommand = DescribeSessionsCommand;
exports.DescribeSessionsRequest$ = DescribeSessionsRequest$;
exports.DescribeSessionsResponse$ = DescribeSessionsResponse$;
exports.DisassociateOpsItemRelatedItem$ = DisassociateOpsItemRelatedItem$;
exports.DisassociateOpsItemRelatedItemCommand = DisassociateOpsItemRelatedItemCommand;
exports.DisassociateOpsItemRelatedItemRequest$ = DisassociateOpsItemRelatedItemRequest$;
exports.DisassociateOpsItemRelatedItemResponse$ = DisassociateOpsItemRelatedItemResponse$;
exports.DocumentAlreadyExists = DocumentAlreadyExists;
exports.DocumentAlreadyExists$ = DocumentAlreadyExists$;
exports.DocumentDefaultVersionDescription$ = DocumentDefaultVersionDescription$;
exports.DocumentDescription$ = DocumentDescription$;
exports.DocumentFilter$ = DocumentFilter$;
exports.DocumentFilterKey = DocumentFilterKey;
exports.DocumentFormat = DocumentFormat;
exports.DocumentHashType = DocumentHashType;
exports.DocumentIdentifier$ = DocumentIdentifier$;
exports.DocumentKeyValuesFilter$ = DocumentKeyValuesFilter$;
exports.DocumentLimitExceeded = DocumentLimitExceeded;
exports.DocumentLimitExceeded$ = DocumentLimitExceeded$;
exports.DocumentMetadataEnum = DocumentMetadataEnum;
exports.DocumentMetadataResponseInfo$ = DocumentMetadataResponseInfo$;
exports.DocumentParameter$ = DocumentParameter$;
exports.DocumentParameterType = DocumentParameterType;
exports.DocumentPermissionLimit = DocumentPermissionLimit;
exports.DocumentPermissionLimit$ = DocumentPermissionLimit$;
exports.DocumentPermissionType = DocumentPermissionType;
exports.DocumentRequires$ = DocumentRequires$;
exports.DocumentReviewAction = DocumentReviewAction;
exports.DocumentReviewCommentSource$ = DocumentReviewCommentSource$;
exports.DocumentReviewCommentType = DocumentReviewCommentType;
exports.DocumentReviewerResponseSource$ = DocumentReviewerResponseSource$;
exports.DocumentReviews$ = DocumentReviews$;
exports.DocumentStatus = DocumentStatus;
exports.DocumentType = DocumentType;
exports.DocumentVersionInfo$ = DocumentVersionInfo$;
exports.DocumentVersionLimitExceeded = DocumentVersionLimitExceeded;
exports.DocumentVersionLimitExceeded$ = DocumentVersionLimitExceeded$;
exports.DoesNotExistException = DoesNotExistException;
exports.DoesNotExistException$ = DoesNotExistException$;
exports.DuplicateDocumentContent = DuplicateDocumentContent;
exports.DuplicateDocumentContent$ = DuplicateDocumentContent$;
exports.DuplicateDocumentVersionName = DuplicateDocumentVersionName;
exports.DuplicateDocumentVersionName$ = DuplicateDocumentVersionName$;
exports.DuplicateInstanceId = DuplicateInstanceId;
exports.DuplicateInstanceId$ = DuplicateInstanceId$;
exports.EffectivePatch$ = EffectivePatch$;
exports.ExecutionInputs$ = ExecutionInputs$;
exports.ExecutionMode = ExecutionMode;
exports.ExecutionPreview$ = ExecutionPreview$;
exports.ExecutionPreviewStatus = ExecutionPreviewStatus;
exports.ExternalAlarmState = ExternalAlarmState;
exports.FailedCreateAssociation$ = FailedCreateAssociation$;
exports.FailureDetails$ = FailureDetails$;
exports.Fault = Fault;
exports.FeatureNotAvailableException = FeatureNotAvailableException;
exports.FeatureNotAvailableException$ = FeatureNotAvailableException$;
exports.GetAccessToken$ = GetAccessToken$;
exports.GetAccessTokenCommand = GetAccessTokenCommand;
exports.GetAccessTokenRequest$ = GetAccessTokenRequest$;
exports.GetAccessTokenResponse$ = GetAccessTokenResponse$;
exports.GetAutomationExecution$ = GetAutomationExecution$;
exports.GetAutomationExecutionCommand = GetAutomationExecutionCommand;
exports.GetAutomationExecutionRequest$ = GetAutomationExecutionRequest$;
exports.GetAutomationExecutionResult$ = GetAutomationExecutionResult$;
exports.GetCalendarState$ = GetCalendarState$;
exports.GetCalendarStateCommand = GetCalendarStateCommand;
exports.GetCalendarStateRequest$ = GetCalendarStateRequest$;
exports.GetCalendarStateResponse$ = GetCalendarStateResponse$;
exports.GetCloudConnector$ = GetCloudConnector$;
exports.GetCloudConnectorCommand = GetCloudConnectorCommand;
exports.GetCloudConnectorRequest$ = GetCloudConnectorRequest$;
exports.GetCloudConnectorResult$ = GetCloudConnectorResult$;
exports.GetCommandInvocation$ = GetCommandInvocation$;
exports.GetCommandInvocationCommand = GetCommandInvocationCommand;
exports.GetCommandInvocationRequest$ = GetCommandInvocationRequest$;
exports.GetCommandInvocationResult$ = GetCommandInvocationResult$;
exports.GetConnectionStatus$ = GetConnectionStatus$;
exports.GetConnectionStatusCommand = GetConnectionStatusCommand;
exports.GetConnectionStatusRequest$ = GetConnectionStatusRequest$;
exports.GetConnectionStatusResponse$ = GetConnectionStatusResponse$;
exports.GetDefaultPatchBaseline$ = GetDefaultPatchBaseline$;
exports.GetDefaultPatchBaselineCommand = GetDefaultPatchBaselineCommand;
exports.GetDefaultPatchBaselineRequest$ = GetDefaultPatchBaselineRequest$;
exports.GetDefaultPatchBaselineResult$ = GetDefaultPatchBaselineResult$;
exports.GetDeployablePatchSnapshotForInstance$ = GetDeployablePatchSnapshotForInstance$;
exports.GetDeployablePatchSnapshotForInstanceCommand = GetDeployablePatchSnapshotForInstanceCommand;
exports.GetDeployablePatchSnapshotForInstanceRequest$ = GetDeployablePatchSnapshotForInstanceRequest$;
exports.GetDeployablePatchSnapshotForInstanceResult$ = GetDeployablePatchSnapshotForInstanceResult$;
exports.GetDocument$ = GetDocument$;
exports.GetDocumentCommand = GetDocumentCommand;
exports.GetDocumentRequest$ = GetDocumentRequest$;
exports.GetDocumentResult$ = GetDocumentResult$;
exports.GetExecutionPreview$ = GetExecutionPreview$;
exports.GetExecutionPreviewCommand = GetExecutionPreviewCommand;
exports.GetExecutionPreviewRequest$ = GetExecutionPreviewRequest$;
exports.GetExecutionPreviewResponse$ = GetExecutionPreviewResponse$;
exports.GetInventory$ = GetInventory$;
exports.GetInventoryCommand = GetInventoryCommand;
exports.GetInventoryRequest$ = GetInventoryRequest$;
exports.GetInventoryResult$ = GetInventoryResult$;
exports.GetInventorySchema$ = GetInventorySchema$;
exports.GetInventorySchemaCommand = GetInventorySchemaCommand;
exports.GetInventorySchemaRequest$ = GetInventorySchemaRequest$;
exports.GetInventorySchemaResult$ = GetInventorySchemaResult$;
exports.GetMaintenanceWindow$ = GetMaintenanceWindow$;
exports.GetMaintenanceWindowCommand = GetMaintenanceWindowCommand;
exports.GetMaintenanceWindowExecution$ = GetMaintenanceWindowExecution$;
exports.GetMaintenanceWindowExecutionCommand = GetMaintenanceWindowExecutionCommand;
exports.GetMaintenanceWindowExecutionRequest$ = GetMaintenanceWindowExecutionRequest$;
exports.GetMaintenanceWindowExecutionResult$ = GetMaintenanceWindowExecutionResult$;
exports.GetMaintenanceWindowExecutionTask$ = GetMaintenanceWindowExecutionTask$;
exports.GetMaintenanceWindowExecutionTaskCommand = GetMaintenanceWindowExecutionTaskCommand;
exports.GetMaintenanceWindowExecutionTaskInvocation$ = GetMaintenanceWindowExecutionTaskInvocation$;
exports.GetMaintenanceWindowExecutionTaskInvocationCommand = GetMaintenanceWindowExecutionTaskInvocationCommand;
exports.GetMaintenanceWindowExecutionTaskInvocationRequest$ = GetMaintenanceWindowExecutionTaskInvocationRequest$;
exports.GetMaintenanceWindowExecutionTaskInvocationResult$ = GetMaintenanceWindowExecutionTaskInvocationResult$;
exports.GetMaintenanceWindowExecutionTaskRequest$ = GetMaintenanceWindowExecutionTaskRequest$;
exports.GetMaintenanceWindowExecutionTaskResult$ = GetMaintenanceWindowExecutionTaskResult$;
exports.GetMaintenanceWindowRequest$ = GetMaintenanceWindowRequest$;
exports.GetMaintenanceWindowResult$ = GetMaintenanceWindowResult$;
exports.GetMaintenanceWindowTask$ = GetMaintenanceWindowTask$;
exports.GetMaintenanceWindowTaskCommand = GetMaintenanceWindowTaskCommand;
exports.GetMaintenanceWindowTaskRequest$ = GetMaintenanceWindowTaskRequest$;
exports.GetMaintenanceWindowTaskResult$ = GetMaintenanceWindowTaskResult$;
exports.GetOpsItem$ = GetOpsItem$;
exports.GetOpsItemCommand = GetOpsItemCommand;
exports.GetOpsItemRequest$ = GetOpsItemRequest$;
exports.GetOpsItemResponse$ = GetOpsItemResponse$;
exports.GetOpsMetadata$ = GetOpsMetadata$;
exports.GetOpsMetadataCommand = GetOpsMetadataCommand;
exports.GetOpsMetadataRequest$ = GetOpsMetadataRequest$;
exports.GetOpsMetadataResult$ = GetOpsMetadataResult$;
exports.GetOpsSummary$ = GetOpsSummary$;
exports.GetOpsSummaryCommand = GetOpsSummaryCommand;
exports.GetOpsSummaryRequest$ = GetOpsSummaryRequest$;
exports.GetOpsSummaryResult$ = GetOpsSummaryResult$;
exports.GetParameter$ = GetParameter$;
exports.GetParameterCommand = GetParameterCommand;
exports.GetParameterHistory$ = GetParameterHistory$;
exports.GetParameterHistoryCommand = GetParameterHistoryCommand;
exports.GetParameterHistoryRequest$ = GetParameterHistoryRequest$;
exports.GetParameterHistoryResult$ = GetParameterHistoryResult$;
exports.GetParameterRequest$ = GetParameterRequest$;
exports.GetParameterResult$ = GetParameterResult$;
exports.GetParameters$ = GetParameters$;
exports.GetParametersByPath$ = GetParametersByPath$;
exports.GetParametersByPathCommand = GetParametersByPathCommand;
exports.GetParametersByPathRequest$ = GetParametersByPathRequest$;
exports.GetParametersByPathResult$ = GetParametersByPathResult$;
exports.GetParametersCommand = GetParametersCommand;
exports.GetParametersRequest$ = GetParametersRequest$;
exports.GetParametersResult$ = GetParametersResult$;
exports.GetPatchBaseline$ = GetPatchBaseline$;
exports.GetPatchBaselineCommand = GetPatchBaselineCommand;
exports.GetPatchBaselineForPatchGroup$ = GetPatchBaselineForPatchGroup$;
exports.GetPatchBaselineForPatchGroupCommand = GetPatchBaselineForPatchGroupCommand;
exports.GetPatchBaselineForPatchGroupRequest$ = GetPatchBaselineForPatchGroupRequest$;
exports.GetPatchBaselineForPatchGroupResult$ = GetPatchBaselineForPatchGroupResult$;
exports.GetPatchBaselineRequest$ = GetPatchBaselineRequest$;
exports.GetPatchBaselineResult$ = GetPatchBaselineResult$;
exports.GetResourcePolicies$ = GetResourcePolicies$;
exports.GetResourcePoliciesCommand = GetResourcePoliciesCommand;
exports.GetResourcePoliciesRequest$ = GetResourcePoliciesRequest$;
exports.GetResourcePoliciesResponse$ = GetResourcePoliciesResponse$;
exports.GetResourcePoliciesResponseEntry$ = GetResourcePoliciesResponseEntry$;
exports.GetServiceSetting$ = GetServiceSetting$;
exports.GetServiceSettingCommand = GetServiceSettingCommand;
exports.GetServiceSettingRequest$ = GetServiceSettingRequest$;
exports.GetServiceSettingResult$ = GetServiceSettingResult$;
exports.HierarchyLevelLimitExceededException = HierarchyLevelLimitExceededException;
exports.HierarchyLevelLimitExceededException$ = HierarchyLevelLimitExceededException$;
exports.HierarchyTypeMismatchException = HierarchyTypeMismatchException;
exports.HierarchyTypeMismatchException$ = HierarchyTypeMismatchException$;
exports.IdempotentParameterMismatch = IdempotentParameterMismatch;
exports.IdempotentParameterMismatch$ = IdempotentParameterMismatch$;
exports.ImpactType = ImpactType;
exports.IncompatiblePolicyException = IncompatiblePolicyException;
exports.IncompatiblePolicyException$ = IncompatiblePolicyException$;
exports.InstanceAggregatedAssociationOverview$ = InstanceAggregatedAssociationOverview$;
exports.InstanceAssociation$ = InstanceAssociation$;
exports.InstanceAssociationOutputLocation$ = InstanceAssociationOutputLocation$;
exports.InstanceAssociationOutputUrl$ = InstanceAssociationOutputUrl$;
exports.InstanceAssociationStatusInfo$ = InstanceAssociationStatusInfo$;
exports.InstanceInfo$ = InstanceInfo$;
exports.InstanceInformation$ = InstanceInformation$;
exports.InstanceInformationFilter$ = InstanceInformationFilter$;
exports.InstanceInformationFilterKey = InstanceInformationFilterKey;
exports.InstanceInformationStringFilter$ = InstanceInformationStringFilter$;
exports.InstancePatchState$ = InstancePatchState$;
exports.InstancePatchStateFilter$ = InstancePatchStateFilter$;
exports.InstancePatchStateOperatorType = InstancePatchStateOperatorType;
exports.InstanceProperty$ = InstanceProperty$;
exports.InstancePropertyFilter$ = InstancePropertyFilter$;
exports.InstancePropertyFilterKey = InstancePropertyFilterKey;
exports.InstancePropertyFilterOperator = InstancePropertyFilterOperator;
exports.InstancePropertyStringFilter$ = InstancePropertyStringFilter$;
exports.InternalServerError = InternalServerError;
exports.InternalServerError$ = InternalServerError$;
exports.InvalidActivation = InvalidActivation;
exports.InvalidActivation$ = InvalidActivation$;
exports.InvalidActivationId = InvalidActivationId;
exports.InvalidActivationId$ = InvalidActivationId$;
exports.InvalidAggregatorException = InvalidAggregatorException;
exports.InvalidAggregatorException$ = InvalidAggregatorException$;
exports.InvalidAllowedPatternException = InvalidAllowedPatternException;
exports.InvalidAllowedPatternException$ = InvalidAllowedPatternException$;
exports.InvalidAssociation = InvalidAssociation;
exports.InvalidAssociation$ = InvalidAssociation$;
exports.InvalidAssociationVersion = InvalidAssociationVersion;
exports.InvalidAssociationVersion$ = InvalidAssociationVersion$;
exports.InvalidAutomationExecutionParametersException = InvalidAutomationExecutionParametersException;
exports.InvalidAutomationExecutionParametersException$ = InvalidAutomationExecutionParametersException$;
exports.InvalidAutomationSignalException = InvalidAutomationSignalException;
exports.InvalidAutomationSignalException$ = InvalidAutomationSignalException$;
exports.InvalidAutomationStatusUpdateException = InvalidAutomationStatusUpdateException;
exports.InvalidAutomationStatusUpdateException$ = InvalidAutomationStatusUpdateException$;
exports.InvalidCommandId = InvalidCommandId;
exports.InvalidCommandId$ = InvalidCommandId$;
exports.InvalidDeleteInventoryParametersException = InvalidDeleteInventoryParametersException;
exports.InvalidDeleteInventoryParametersException$ = InvalidDeleteInventoryParametersException$;
exports.InvalidDeletionIdException = InvalidDeletionIdException;
exports.InvalidDeletionIdException$ = InvalidDeletionIdException$;
exports.InvalidDocument = InvalidDocument;
exports.InvalidDocument$ = InvalidDocument$;
exports.InvalidDocumentContent = InvalidDocumentContent;
exports.InvalidDocumentContent$ = InvalidDocumentContent$;
exports.InvalidDocumentOperation = InvalidDocumentOperation;
exports.InvalidDocumentOperation$ = InvalidDocumentOperation$;
exports.InvalidDocumentSchemaVersion = InvalidDocumentSchemaVersion;
exports.InvalidDocumentSchemaVersion$ = InvalidDocumentSchemaVersion$;
exports.InvalidDocumentType = InvalidDocumentType;
exports.InvalidDocumentType$ = InvalidDocumentType$;
exports.InvalidDocumentVersion = InvalidDocumentVersion;
exports.InvalidDocumentVersion$ = InvalidDocumentVersion$;
exports.InvalidFilter = InvalidFilter;
exports.InvalidFilter$ = InvalidFilter$;
exports.InvalidFilterKey = InvalidFilterKey;
exports.InvalidFilterKey$ = InvalidFilterKey$;
exports.InvalidFilterOption = InvalidFilterOption;
exports.InvalidFilterOption$ = InvalidFilterOption$;
exports.InvalidFilterValue = InvalidFilterValue;
exports.InvalidFilterValue$ = InvalidFilterValue$;
exports.InvalidInstanceId = InvalidInstanceId;
exports.InvalidInstanceId$ = InvalidInstanceId$;
exports.InvalidInstanceInformationFilterValue = InvalidInstanceInformationFilterValue;
exports.InvalidInstanceInformationFilterValue$ = InvalidInstanceInformationFilterValue$;
exports.InvalidInstancePropertyFilterValue = InvalidInstancePropertyFilterValue;
exports.InvalidInstancePropertyFilterValue$ = InvalidInstancePropertyFilterValue$;
exports.InvalidInventoryGroupException = InvalidInventoryGroupException;
exports.InvalidInventoryGroupException$ = InvalidInventoryGroupException$;
exports.InvalidInventoryItemContextException = InvalidInventoryItemContextException;
exports.InvalidInventoryItemContextException$ = InvalidInventoryItemContextException$;
exports.InvalidInventoryRequestException = InvalidInventoryRequestException;
exports.InvalidInventoryRequestException$ = InvalidInventoryRequestException$;
exports.InvalidItemContentException = InvalidItemContentException;
exports.InvalidItemContentException$ = InvalidItemContentException$;
exports.InvalidKeyId = InvalidKeyId;
exports.InvalidKeyId$ = InvalidKeyId$;
exports.InvalidNextToken = InvalidNextToken;
exports.InvalidNextToken$ = InvalidNextToken$;
exports.InvalidNotificationConfig = InvalidNotificationConfig;
exports.InvalidNotificationConfig$ = InvalidNotificationConfig$;
exports.InvalidOptionException = InvalidOptionException;
exports.InvalidOptionException$ = InvalidOptionException$;
exports.InvalidOutputFolder = InvalidOutputFolder;
exports.InvalidOutputFolder$ = InvalidOutputFolder$;
exports.InvalidOutputLocation = InvalidOutputLocation;
exports.InvalidOutputLocation$ = InvalidOutputLocation$;
exports.InvalidParameters = InvalidParameters;
exports.InvalidParameters$ = InvalidParameters$;
exports.InvalidPermissionType = InvalidPermissionType;
exports.InvalidPermissionType$ = InvalidPermissionType$;
exports.InvalidPluginName = InvalidPluginName;
exports.InvalidPluginName$ = InvalidPluginName$;
exports.InvalidPolicyAttributeException = InvalidPolicyAttributeException;
exports.InvalidPolicyAttributeException$ = InvalidPolicyAttributeException$;
exports.InvalidPolicyTypeException = InvalidPolicyTypeException;
exports.InvalidPolicyTypeException$ = InvalidPolicyTypeException$;
exports.InvalidResourceId = InvalidResourceId;
exports.InvalidResourceId$ = InvalidResourceId$;
exports.InvalidResourceType = InvalidResourceType;
exports.InvalidResourceType$ = InvalidResourceType$;
exports.InvalidResultAttributeException = InvalidResultAttributeException;
exports.InvalidResultAttributeException$ = InvalidResultAttributeException$;
exports.InvalidRole = InvalidRole;
exports.InvalidRole$ = InvalidRole$;
exports.InvalidSchedule = InvalidSchedule;
exports.InvalidSchedule$ = InvalidSchedule$;
exports.InvalidTag = InvalidTag;
exports.InvalidTag$ = InvalidTag$;
exports.InvalidTarget = InvalidTarget;
exports.InvalidTarget$ = InvalidTarget$;
exports.InvalidTargetMaps = InvalidTargetMaps;
exports.InvalidTargetMaps$ = InvalidTargetMaps$;
exports.InvalidTypeNameException = InvalidTypeNameException;
exports.InvalidTypeNameException$ = InvalidTypeNameException$;
exports.InvalidUpdate = InvalidUpdate;
exports.InvalidUpdate$ = InvalidUpdate$;
exports.InventoryAggregator$ = InventoryAggregator$;
exports.InventoryAttributeDataType = InventoryAttributeDataType;
exports.InventoryDeletionStatus = InventoryDeletionStatus;
exports.InventoryDeletionStatusItem$ = InventoryDeletionStatusItem$;
exports.InventoryDeletionSummary$ = InventoryDeletionSummary$;
exports.InventoryDeletionSummaryItem$ = InventoryDeletionSummaryItem$;
exports.InventoryFilter$ = InventoryFilter$;
exports.InventoryGroup$ = InventoryGroup$;
exports.InventoryItem$ = InventoryItem$;
exports.InventoryItemAttribute$ = InventoryItemAttribute$;
exports.InventoryItemSchema$ = InventoryItemSchema$;
exports.InventoryQueryOperatorType = InventoryQueryOperatorType;
exports.InventoryResultEntity$ = InventoryResultEntity$;
exports.InventoryResultItem$ = InventoryResultItem$;
exports.InventorySchemaDeleteOption = InventorySchemaDeleteOption;
exports.InvocationDoesNotExist = InvocationDoesNotExist;
exports.InvocationDoesNotExist$ = InvocationDoesNotExist$;
exports.ItemContentMismatchException = ItemContentMismatchException;
exports.ItemContentMismatchException$ = ItemContentMismatchException$;
exports.ItemSizeLimitExceededException = ItemSizeLimitExceededException;
exports.ItemSizeLimitExceededException$ = ItemSizeLimitExceededException$;
exports.LabelParameterVersion$ = LabelParameterVersion$;
exports.LabelParameterVersionCommand = LabelParameterVersionCommand;
exports.LabelParameterVersionRequest$ = LabelParameterVersionRequest$;
exports.LabelParameterVersionResult$ = LabelParameterVersionResult$;
exports.LastResourceDataSyncStatus = LastResourceDataSyncStatus;
exports.ListAssociationVersions$ = ListAssociationVersions$;
exports.ListAssociationVersionsCommand = ListAssociationVersionsCommand;
exports.ListAssociationVersionsRequest$ = ListAssociationVersionsRequest$;
exports.ListAssociationVersionsResult$ = ListAssociationVersionsResult$;
exports.ListAssociations$ = ListAssociations$;
exports.ListAssociationsCommand = ListAssociationsCommand;
exports.ListAssociationsRequest$ = ListAssociationsRequest$;
exports.ListAssociationsResult$ = ListAssociationsResult$;
exports.ListCloudConnectors$ = ListCloudConnectors$;
exports.ListCloudConnectorsCommand = ListCloudConnectorsCommand;
exports.ListCloudConnectorsRequest$ = ListCloudConnectorsRequest$;
exports.ListCloudConnectorsResult$ = ListCloudConnectorsResult$;
exports.ListCommandInvocations$ = ListCommandInvocations$;
exports.ListCommandInvocationsCommand = ListCommandInvocationsCommand;
exports.ListCommandInvocationsRequest$ = ListCommandInvocationsRequest$;
exports.ListCommandInvocationsResult$ = ListCommandInvocationsResult$;
exports.ListCommands$ = ListCommands$;
exports.ListCommandsCommand = ListCommandsCommand;
exports.ListCommandsRequest$ = ListCommandsRequest$;
exports.ListCommandsResult$ = ListCommandsResult$;
exports.ListComplianceItems$ = ListComplianceItems$;
exports.ListComplianceItemsCommand = ListComplianceItemsCommand;
exports.ListComplianceItemsRequest$ = ListComplianceItemsRequest$;
exports.ListComplianceItemsResult$ = ListComplianceItemsResult$;
exports.ListComplianceSummaries$ = ListComplianceSummaries$;
exports.ListComplianceSummariesCommand = ListComplianceSummariesCommand;
exports.ListComplianceSummariesRequest$ = ListComplianceSummariesRequest$;
exports.ListComplianceSummariesResult$ = ListComplianceSummariesResult$;
exports.ListDocumentMetadataHistory$ = ListDocumentMetadataHistory$;
exports.ListDocumentMetadataHistoryCommand = ListDocumentMetadataHistoryCommand;
exports.ListDocumentMetadataHistoryRequest$ = ListDocumentMetadataHistoryRequest$;
exports.ListDocumentMetadataHistoryResponse$ = ListDocumentMetadataHistoryResponse$;
exports.ListDocumentVersions$ = ListDocumentVersions$;
exports.ListDocumentVersionsCommand = ListDocumentVersionsCommand;
exports.ListDocumentVersionsRequest$ = ListDocumentVersionsRequest$;
exports.ListDocumentVersionsResult$ = ListDocumentVersionsResult$;
exports.ListDocuments$ = ListDocuments$;
exports.ListDocumentsCommand = ListDocumentsCommand;
exports.ListDocumentsRequest$ = ListDocumentsRequest$;
exports.ListDocumentsResult$ = ListDocumentsResult$;
exports.ListInventoryEntries$ = ListInventoryEntries$;
exports.ListInventoryEntriesCommand = ListInventoryEntriesCommand;
exports.ListInventoryEntriesRequest$ = ListInventoryEntriesRequest$;
exports.ListInventoryEntriesResult$ = ListInventoryEntriesResult$;
exports.ListNodes$ = ListNodes$;
exports.ListNodesCommand = ListNodesCommand;
exports.ListNodesRequest$ = ListNodesRequest$;
exports.ListNodesResult$ = ListNodesResult$;
exports.ListNodesSummary$ = ListNodesSummary$;
exports.ListNodesSummaryCommand = ListNodesSummaryCommand;
exports.ListNodesSummaryRequest$ = ListNodesSummaryRequest$;
exports.ListNodesSummaryResult$ = ListNodesSummaryResult$;
exports.ListOpsItemEvents$ = ListOpsItemEvents$;
exports.ListOpsItemEventsCommand = ListOpsItemEventsCommand;
exports.ListOpsItemEventsRequest$ = ListOpsItemEventsRequest$;
exports.ListOpsItemEventsResponse$ = ListOpsItemEventsResponse$;
exports.ListOpsItemRelatedItems$ = ListOpsItemRelatedItems$;
exports.ListOpsItemRelatedItemsCommand = ListOpsItemRelatedItemsCommand;
exports.ListOpsItemRelatedItemsRequest$ = ListOpsItemRelatedItemsRequest$;
exports.ListOpsItemRelatedItemsResponse$ = ListOpsItemRelatedItemsResponse$;
exports.ListOpsMetadata$ = ListOpsMetadata$;
exports.ListOpsMetadataCommand = ListOpsMetadataCommand;
exports.ListOpsMetadataRequest$ = ListOpsMetadataRequest$;
exports.ListOpsMetadataResult$ = ListOpsMetadataResult$;
exports.ListResourceComplianceSummaries$ = ListResourceComplianceSummaries$;
exports.ListResourceComplianceSummariesCommand = ListResourceComplianceSummariesCommand;
exports.ListResourceComplianceSummariesRequest$ = ListResourceComplianceSummariesRequest$;
exports.ListResourceComplianceSummariesResult$ = ListResourceComplianceSummariesResult$;
exports.ListResourceDataSync$ = ListResourceDataSync$;
exports.ListResourceDataSyncCommand = ListResourceDataSyncCommand;
exports.ListResourceDataSyncRequest$ = ListResourceDataSyncRequest$;
exports.ListResourceDataSyncResult$ = ListResourceDataSyncResult$;
exports.ListTagsForResource$ = ListTagsForResource$;
exports.ListTagsForResourceCommand = ListTagsForResourceCommand;
exports.ListTagsForResourceRequest$ = ListTagsForResourceRequest$;
exports.ListTagsForResourceResult$ = ListTagsForResourceResult$;
exports.LoggingInfo$ = LoggingInfo$;
exports.MaintenanceWindowAutomationParameters$ = MaintenanceWindowAutomationParameters$;
exports.MaintenanceWindowExecution$ = MaintenanceWindowExecution$;
exports.MaintenanceWindowExecutionStatus = MaintenanceWindowExecutionStatus;
exports.MaintenanceWindowExecutionTaskIdentity$ = MaintenanceWindowExecutionTaskIdentity$;
exports.MaintenanceWindowExecutionTaskInvocationIdentity$ = MaintenanceWindowExecutionTaskInvocationIdentity$;
exports.MaintenanceWindowFilter$ = MaintenanceWindowFilter$;
exports.MaintenanceWindowIdentity$ = MaintenanceWindowIdentity$;
exports.MaintenanceWindowIdentityForTarget$ = MaintenanceWindowIdentityForTarget$;
exports.MaintenanceWindowLambdaParameters$ = MaintenanceWindowLambdaParameters$;
exports.MaintenanceWindowResourceType = MaintenanceWindowResourceType;
exports.MaintenanceWindowRunCommandParameters$ = MaintenanceWindowRunCommandParameters$;
exports.MaintenanceWindowStepFunctionsParameters$ = MaintenanceWindowStepFunctionsParameters$;
exports.MaintenanceWindowTarget$ = MaintenanceWindowTarget$;
exports.MaintenanceWindowTask$ = MaintenanceWindowTask$;
exports.MaintenanceWindowTaskCutoffBehavior = MaintenanceWindowTaskCutoffBehavior;
exports.MaintenanceWindowTaskInvocationParameters$ = MaintenanceWindowTaskInvocationParameters$;
exports.MaintenanceWindowTaskParameterValueExpression$ = MaintenanceWindowTaskParameterValueExpression$;
exports.MaintenanceWindowTaskType = MaintenanceWindowTaskType;
exports.MalformedResourcePolicyDocumentException = MalformedResourcePolicyDocumentException;
exports.MalformedResourcePolicyDocumentException$ = MalformedResourcePolicyDocumentException$;
exports.ManagedStatus = ManagedStatus;
exports.MaxDocumentSizeExceeded = MaxDocumentSizeExceeded;
exports.MaxDocumentSizeExceeded$ = MaxDocumentSizeExceeded$;
exports.MetadataValue$ = MetadataValue$;
exports.ModifyDocumentPermission$ = ModifyDocumentPermission$;
exports.ModifyDocumentPermissionCommand = ModifyDocumentPermissionCommand;
exports.ModifyDocumentPermissionRequest$ = ModifyDocumentPermissionRequest$;
exports.ModifyDocumentPermissionResponse$ = ModifyDocumentPermissionResponse$;
exports.NoLongerSupportedException = NoLongerSupportedException;
exports.NoLongerSupportedException$ = NoLongerSupportedException$;
exports.Node$ = Node$;
exports.NodeAggregator$ = NodeAggregator$;
exports.NodeAggregatorType = NodeAggregatorType;
exports.NodeAttributeName = NodeAttributeName;
exports.NodeFilter$ = NodeFilter$;
exports.NodeFilterKey = NodeFilterKey;
exports.NodeFilterOperatorType = NodeFilterOperatorType;
exports.NodeOwnerInfo$ = NodeOwnerInfo$;
exports.NodeType$ = NodeType$;
exports.NodeTypeName = NodeTypeName;
exports.NonCompliantSummary$ = NonCompliantSummary$;
exports.NotificationConfig$ = NotificationConfig$;
exports.NotificationEvent = NotificationEvent;
exports.NotificationType = NotificationType;
exports.OperatingSystem = OperatingSystem;
exports.OpsAggregator$ = OpsAggregator$;
exports.OpsEntity$ = OpsEntity$;
exports.OpsEntityItem$ = OpsEntityItem$;
exports.OpsFilter$ = OpsFilter$;
exports.OpsFilterOperatorType = OpsFilterOperatorType;
exports.OpsItem$ = OpsItem$;
exports.OpsItemAccessDeniedException = OpsItemAccessDeniedException;
exports.OpsItemAccessDeniedException$ = OpsItemAccessDeniedException$;
exports.OpsItemAlreadyExistsException = OpsItemAlreadyExistsException;
exports.OpsItemAlreadyExistsException$ = OpsItemAlreadyExistsException$;
exports.OpsItemConflictException = OpsItemConflictException;
exports.OpsItemConflictException$ = OpsItemConflictException$;
exports.OpsItemDataType = OpsItemDataType;
exports.OpsItemDataValue$ = OpsItemDataValue$;
exports.OpsItemEventFilter$ = OpsItemEventFilter$;
exports.OpsItemEventFilterKey = OpsItemEventFilterKey;
exports.OpsItemEventFilterOperator = OpsItemEventFilterOperator;
exports.OpsItemEventSummary$ = OpsItemEventSummary$;
exports.OpsItemFilter$ = OpsItemFilter$;
exports.OpsItemFilterKey = OpsItemFilterKey;
exports.OpsItemFilterOperator = OpsItemFilterOperator;
exports.OpsItemIdentity$ = OpsItemIdentity$;
exports.OpsItemInvalidParameterException = OpsItemInvalidParameterException;
exports.OpsItemInvalidParameterException$ = OpsItemInvalidParameterException$;
exports.OpsItemLimitExceededException = OpsItemLimitExceededException;
exports.OpsItemLimitExceededException$ = OpsItemLimitExceededException$;
exports.OpsItemNotFoundException = OpsItemNotFoundException;
exports.OpsItemNotFoundException$ = OpsItemNotFoundException$;
exports.OpsItemNotification$ = OpsItemNotification$;
exports.OpsItemRelatedItemAlreadyExistsException = OpsItemRelatedItemAlreadyExistsException;
exports.OpsItemRelatedItemAlreadyExistsException$ = OpsItemRelatedItemAlreadyExistsException$;
exports.OpsItemRelatedItemAssociationNotFoundException = OpsItemRelatedItemAssociationNotFoundException;
exports.OpsItemRelatedItemAssociationNotFoundException$ = OpsItemRelatedItemAssociationNotFoundException$;
exports.OpsItemRelatedItemSummary$ = OpsItemRelatedItemSummary$;
exports.OpsItemRelatedItemsFilter$ = OpsItemRelatedItemsFilter$;
exports.OpsItemRelatedItemsFilterKey = OpsItemRelatedItemsFilterKey;
exports.OpsItemRelatedItemsFilterOperator = OpsItemRelatedItemsFilterOperator;
exports.OpsItemStatus = OpsItemStatus;
exports.OpsItemSummary$ = OpsItemSummary$;
exports.OpsMetadata$ = OpsMetadata$;
exports.OpsMetadataAlreadyExistsException = OpsMetadataAlreadyExistsException;
exports.OpsMetadataAlreadyExistsException$ = OpsMetadataAlreadyExistsException$;
exports.OpsMetadataFilter$ = OpsMetadataFilter$;
exports.OpsMetadataInvalidArgumentException = OpsMetadataInvalidArgumentException;
exports.OpsMetadataInvalidArgumentException$ = OpsMetadataInvalidArgumentException$;
exports.OpsMetadataKeyLimitExceededException = OpsMetadataKeyLimitExceededException;
exports.OpsMetadataKeyLimitExceededException$ = OpsMetadataKeyLimitExceededException$;
exports.OpsMetadataLimitExceededException = OpsMetadataLimitExceededException;
exports.OpsMetadataLimitExceededException$ = OpsMetadataLimitExceededException$;
exports.OpsMetadataNotFoundException = OpsMetadataNotFoundException;
exports.OpsMetadataNotFoundException$ = OpsMetadataNotFoundException$;
exports.OpsMetadataTooManyUpdatesException = OpsMetadataTooManyUpdatesException;
exports.OpsMetadataTooManyUpdatesException$ = OpsMetadataTooManyUpdatesException$;
exports.OpsResultAttribute$ = OpsResultAttribute$;
exports.OutputSource$ = OutputSource$;
exports.Parameter$ = Parameter$;
exports.ParameterAlreadyExists = ParameterAlreadyExists;
exports.ParameterAlreadyExists$ = ParameterAlreadyExists$;
exports.ParameterHistory$ = ParameterHistory$;
exports.ParameterInlinePolicy$ = ParameterInlinePolicy$;
exports.ParameterLimitExceeded = ParameterLimitExceeded;
exports.ParameterLimitExceeded$ = ParameterLimitExceeded$;
exports.ParameterMaxVersionLimitExceeded = ParameterMaxVersionLimitExceeded;
exports.ParameterMaxVersionLimitExceeded$ = ParameterMaxVersionLimitExceeded$;
exports.ParameterMetadata$ = ParameterMetadata$;
exports.ParameterNotFound = ParameterNotFound;
exports.ParameterNotFound$ = ParameterNotFound$;
exports.ParameterPatternMismatchException = ParameterPatternMismatchException;
exports.ParameterPatternMismatchException$ = ParameterPatternMismatchException$;
exports.ParameterStringFilter$ = ParameterStringFilter$;
exports.ParameterTier = ParameterTier;
exports.ParameterType = ParameterType;
exports.ParameterVersionLabelLimitExceeded = ParameterVersionLabelLimitExceeded;
exports.ParameterVersionLabelLimitExceeded$ = ParameterVersionLabelLimitExceeded$;
exports.ParameterVersionNotFound = ParameterVersionNotFound;
exports.ParameterVersionNotFound$ = ParameterVersionNotFound$;
exports.ParametersFilter$ = ParametersFilter$;
exports.ParametersFilterKey = ParametersFilterKey;
exports.ParentStepDetails$ = ParentStepDetails$;
exports.Patch$ = Patch$;
exports.PatchAction = PatchAction;
exports.PatchBaselineIdentity$ = PatchBaselineIdentity$;
exports.PatchComplianceData$ = PatchComplianceData$;
exports.PatchComplianceDataState = PatchComplianceDataState;
exports.PatchComplianceLevel = PatchComplianceLevel;
exports.PatchComplianceStatus = PatchComplianceStatus;
exports.PatchDeploymentStatus = PatchDeploymentStatus;
exports.PatchFilter$ = PatchFilter$;
exports.PatchFilterGroup$ = PatchFilterGroup$;
exports.PatchFilterKey = PatchFilterKey;
exports.PatchGroupPatchBaselineMapping$ = PatchGroupPatchBaselineMapping$;
exports.PatchOperationType = PatchOperationType;
exports.PatchOrchestratorFilter$ = PatchOrchestratorFilter$;
exports.PatchProperty = PatchProperty;
exports.PatchRule$ = PatchRule$;
exports.PatchRuleGroup$ = PatchRuleGroup$;
exports.PatchSet = PatchSet;
exports.PatchSource$ = PatchSource$;
exports.PatchStatus$ = PatchStatus$;
exports.PingStatus = PingStatus;
exports.PlatformType = PlatformType;
exports.PoliciesLimitExceededException = PoliciesLimitExceededException;
exports.PoliciesLimitExceededException$ = PoliciesLimitExceededException$;
exports.ProgressCounters$ = ProgressCounters$;
exports.PutComplianceItems$ = PutComplianceItems$;
exports.PutComplianceItemsCommand = PutComplianceItemsCommand;
exports.PutComplianceItemsRequest$ = PutComplianceItemsRequest$;
exports.PutComplianceItemsResult$ = PutComplianceItemsResult$;
exports.PutInventory$ = PutInventory$;
exports.PutInventoryCommand = PutInventoryCommand;
exports.PutInventoryRequest$ = PutInventoryRequest$;
exports.PutInventoryResult$ = PutInventoryResult$;
exports.PutParameter$ = PutParameter$;
exports.PutParameterCommand = PutParameterCommand;
exports.PutParameterRequest$ = PutParameterRequest$;
exports.PutParameterResult$ = PutParameterResult$;
exports.PutResourcePolicy$ = PutResourcePolicy$;
exports.PutResourcePolicyCommand = PutResourcePolicyCommand;
exports.PutResourcePolicyRequest$ = PutResourcePolicyRequest$;
exports.PutResourcePolicyResponse$ = PutResourcePolicyResponse$;
exports.RebootOption = RebootOption;
exports.RegisterDefaultPatchBaseline$ = RegisterDefaultPatchBaseline$;
exports.RegisterDefaultPatchBaselineCommand = RegisterDefaultPatchBaselineCommand;
exports.RegisterDefaultPatchBaselineRequest$ = RegisterDefaultPatchBaselineRequest$;
exports.RegisterDefaultPatchBaselineResult$ = RegisterDefaultPatchBaselineResult$;
exports.RegisterPatchBaselineForPatchGroup$ = RegisterPatchBaselineForPatchGroup$;
exports.RegisterPatchBaselineForPatchGroupCommand = RegisterPatchBaselineForPatchGroupCommand;
exports.RegisterPatchBaselineForPatchGroupRequest$ = RegisterPatchBaselineForPatchGroupRequest$;
exports.RegisterPatchBaselineForPatchGroupResult$ = RegisterPatchBaselineForPatchGroupResult$;
exports.RegisterTargetWithMaintenanceWindow$ = RegisterTargetWithMaintenanceWindow$;
exports.RegisterTargetWithMaintenanceWindowCommand = RegisterTargetWithMaintenanceWindowCommand;
exports.RegisterTargetWithMaintenanceWindowRequest$ = RegisterTargetWithMaintenanceWindowRequest$;
exports.RegisterTargetWithMaintenanceWindowResult$ = RegisterTargetWithMaintenanceWindowResult$;
exports.RegisterTaskWithMaintenanceWindow$ = RegisterTaskWithMaintenanceWindow$;
exports.RegisterTaskWithMaintenanceWindowCommand = RegisterTaskWithMaintenanceWindowCommand;
exports.RegisterTaskWithMaintenanceWindowRequest$ = RegisterTaskWithMaintenanceWindowRequest$;
exports.RegisterTaskWithMaintenanceWindowResult$ = RegisterTaskWithMaintenanceWindowResult$;
exports.RegistrationMetadataItem$ = RegistrationMetadataItem$;
exports.RelatedOpsItem$ = RelatedOpsItem$;
exports.RemoveTagsFromResource$ = RemoveTagsFromResource$;
exports.RemoveTagsFromResourceCommand = RemoveTagsFromResourceCommand;
exports.RemoveTagsFromResourceRequest$ = RemoveTagsFromResourceRequest$;
exports.RemoveTagsFromResourceResult$ = RemoveTagsFromResourceResult$;
exports.ResetServiceSetting$ = ResetServiceSetting$;
exports.ResetServiceSettingCommand = ResetServiceSettingCommand;
exports.ResetServiceSettingRequest$ = ResetServiceSettingRequest$;
exports.ResetServiceSettingResult$ = ResetServiceSettingResult$;
exports.ResolvedTargets$ = ResolvedTargets$;
exports.ResourceComplianceSummaryItem$ = ResourceComplianceSummaryItem$;
exports.ResourceDataSyncAlreadyExistsException = ResourceDataSyncAlreadyExistsException;
exports.ResourceDataSyncAlreadyExistsException$ = ResourceDataSyncAlreadyExistsException$;
exports.ResourceDataSyncAwsOrganizationsSource$ = ResourceDataSyncAwsOrganizationsSource$;
exports.ResourceDataSyncConflictException = ResourceDataSyncConflictException;
exports.ResourceDataSyncConflictException$ = ResourceDataSyncConflictException$;
exports.ResourceDataSyncCountExceededException = ResourceDataSyncCountExceededException;
exports.ResourceDataSyncCountExceededException$ = ResourceDataSyncCountExceededException$;
exports.ResourceDataSyncDestinationDataSharing$ = ResourceDataSyncDestinationDataSharing$;
exports.ResourceDataSyncInvalidConfigurationException = ResourceDataSyncInvalidConfigurationException;
exports.ResourceDataSyncInvalidConfigurationException$ = ResourceDataSyncInvalidConfigurationException$;
exports.ResourceDataSyncItem$ = ResourceDataSyncItem$;
exports.ResourceDataSyncNotFoundException = ResourceDataSyncNotFoundException;
exports.ResourceDataSyncNotFoundException$ = ResourceDataSyncNotFoundException$;
exports.ResourceDataSyncOrganizationalUnit$ = ResourceDataSyncOrganizationalUnit$;
exports.ResourceDataSyncS3Destination$ = ResourceDataSyncS3Destination$;
exports.ResourceDataSyncS3Format = ResourceDataSyncS3Format;
exports.ResourceDataSyncSource$ = ResourceDataSyncSource$;
exports.ResourceDataSyncSourceWithState$ = ResourceDataSyncSourceWithState$;
exports.ResourceInUseException = ResourceInUseException;
exports.ResourceInUseException$ = ResourceInUseException$;
exports.ResourceLimitExceededException = ResourceLimitExceededException;
exports.ResourceLimitExceededException$ = ResourceLimitExceededException$;
exports.ResourceNotFoundException = ResourceNotFoundException;
exports.ResourceNotFoundException$ = ResourceNotFoundException$;
exports.ResourcePolicyConflictException = ResourcePolicyConflictException;
exports.ResourcePolicyConflictException$ = ResourcePolicyConflictException$;
exports.ResourcePolicyInvalidParameterException = ResourcePolicyInvalidParameterException;
exports.ResourcePolicyInvalidParameterException$ = ResourcePolicyInvalidParameterException$;
exports.ResourcePolicyLimitExceededException = ResourcePolicyLimitExceededException;
exports.ResourcePolicyLimitExceededException$ = ResourcePolicyLimitExceededException$;
exports.ResourcePolicyNotFoundException = ResourcePolicyNotFoundException;
exports.ResourcePolicyNotFoundException$ = ResourcePolicyNotFoundException$;
exports.ResourceType = ResourceType;
exports.ResourceTypeForTagging = ResourceTypeForTagging;
exports.ResultAttribute$ = ResultAttribute$;
exports.ResumeSession$ = ResumeSession$;
exports.ResumeSessionCommand = ResumeSessionCommand;
exports.ResumeSessionRequest$ = ResumeSessionRequest$;
exports.ResumeSessionResponse$ = ResumeSessionResponse$;
exports.ReviewInformation$ = ReviewInformation$;
exports.ReviewStatus = ReviewStatus;
exports.Runbook$ = Runbook$;
exports.S3OutputLocation$ = S3OutputLocation$;
exports.S3OutputUrl$ = S3OutputUrl$;
exports.SSM = SSM;
exports.SSMClient = SSMClient;
exports.SSMServiceException = SSMServiceException;
exports.SSMServiceException$ = SSMServiceException$;
exports.ScheduledWindowExecution$ = ScheduledWindowExecution$;
exports.SendAutomationSignal$ = SendAutomationSignal$;
exports.SendAutomationSignalCommand = SendAutomationSignalCommand;
exports.SendAutomationSignalRequest$ = SendAutomationSignalRequest$;
exports.SendAutomationSignalResult$ = SendAutomationSignalResult$;
exports.SendCommand$ = SendCommand$;
exports.SendCommandCommand = SendCommandCommand;
exports.SendCommandRequest$ = SendCommandRequest$;
exports.SendCommandResult$ = SendCommandResult$;
exports.ServiceQuotaExceededException = ServiceQuotaExceededException;
exports.ServiceQuotaExceededException$ = ServiceQuotaExceededException$;
exports.ServiceSetting$ = ServiceSetting$;
exports.ServiceSettingNotFound = ServiceSettingNotFound;
exports.ServiceSettingNotFound$ = ServiceSettingNotFound$;
exports.Session$ = Session$;
exports.SessionFilter$ = SessionFilter$;
exports.SessionFilterKey = SessionFilterKey;
exports.SessionManagerOutputUrl$ = SessionManagerOutputUrl$;
exports.SessionState = SessionState;
exports.SessionStatus = SessionStatus;
exports.SeveritySummary$ = SeveritySummary$;
exports.SignalType = SignalType;
exports.SourceType = SourceType;
exports.StartAccessRequest$ = StartAccessRequest$;
exports.StartAccessRequestCommand = StartAccessRequestCommand;
exports.StartAccessRequestRequest$ = StartAccessRequestRequest$;
exports.StartAccessRequestResponse$ = StartAccessRequestResponse$;
exports.StartAssociationsOnce$ = StartAssociationsOnce$;
exports.StartAssociationsOnceCommand = StartAssociationsOnceCommand;
exports.StartAssociationsOnceRequest$ = StartAssociationsOnceRequest$;
exports.StartAssociationsOnceResult$ = StartAssociationsOnceResult$;
exports.StartAutomationExecution$ = StartAutomationExecution$;
exports.StartAutomationExecutionCommand = StartAutomationExecutionCommand;
exports.StartAutomationExecutionRequest$ = StartAutomationExecutionRequest$;
exports.StartAutomationExecutionResult$ = StartAutomationExecutionResult$;
exports.StartChangeRequestExecution$ = StartChangeRequestExecution$;
exports.StartChangeRequestExecutionCommand = StartChangeRequestExecutionCommand;
exports.StartChangeRequestExecutionRequest$ = StartChangeRequestExecutionRequest$;
exports.StartChangeRequestExecutionResult$ = StartChangeRequestExecutionResult$;
exports.StartExecutionPreview$ = StartExecutionPreview$;
exports.StartExecutionPreviewCommand = StartExecutionPreviewCommand;
exports.StartExecutionPreviewRequest$ = StartExecutionPreviewRequest$;
exports.StartExecutionPreviewResponse$ = StartExecutionPreviewResponse$;
exports.StartSession$ = StartSession$;
exports.StartSessionCommand = StartSessionCommand;
exports.StartSessionRequest$ = StartSessionRequest$;
exports.StartSessionResponse$ = StartSessionResponse$;
exports.StatusUnchanged = StatusUnchanged;
exports.StatusUnchanged$ = StatusUnchanged$;
exports.StepExecution$ = StepExecution$;
exports.StepExecutionFilter$ = StepExecutionFilter$;
exports.StepExecutionFilterKey = StepExecutionFilterKey;
exports.StopAutomationExecution$ = StopAutomationExecution$;
exports.StopAutomationExecutionCommand = StopAutomationExecutionCommand;
exports.StopAutomationExecutionRequest$ = StopAutomationExecutionRequest$;
exports.StopAutomationExecutionResult$ = StopAutomationExecutionResult$;
exports.StopType = StopType;
exports.SubTypeCountLimitExceededException = SubTypeCountLimitExceededException;
exports.SubTypeCountLimitExceededException$ = SubTypeCountLimitExceededException$;
exports.Tag$ = Tag$;
exports.Target$ = Target$;
exports.TargetInUseException = TargetInUseException;
exports.TargetInUseException$ = TargetInUseException$;
exports.TargetLocation$ = TargetLocation$;
exports.TargetNotConnected = TargetNotConnected;
exports.TargetNotConnected$ = TargetNotConnected$;
exports.TargetPreview$ = TargetPreview$;
exports.TerminateSession$ = TerminateSession$;
exports.TerminateSessionCommand = TerminateSessionCommand;
exports.TerminateSessionRequest$ = TerminateSessionRequest$;
exports.TerminateSessionResponse$ = TerminateSessionResponse$;
exports.ThrottlingException = ThrottlingException;
exports.ThrottlingException$ = ThrottlingException$;
exports.TooManyTagsError = TooManyTagsError;
exports.TooManyTagsError$ = TooManyTagsError$;
exports.TooManyUpdates = TooManyUpdates;
exports.TooManyUpdates$ = TooManyUpdates$;
exports.TotalSizeLimitExceededException = TotalSizeLimitExceededException;
exports.TotalSizeLimitExceededException$ = TotalSizeLimitExceededException$;
exports.UnlabelParameterVersion$ = UnlabelParameterVersion$;
exports.UnlabelParameterVersionCommand = UnlabelParameterVersionCommand;
exports.UnlabelParameterVersionRequest$ = UnlabelParameterVersionRequest$;
exports.UnlabelParameterVersionResult$ = UnlabelParameterVersionResult$;
exports.UnsupportedCalendarException = UnsupportedCalendarException;
exports.UnsupportedCalendarException$ = UnsupportedCalendarException$;
exports.UnsupportedFeatureRequiredException = UnsupportedFeatureRequiredException;
exports.UnsupportedFeatureRequiredException$ = UnsupportedFeatureRequiredException$;
exports.UnsupportedInventoryItemContextException = UnsupportedInventoryItemContextException;
exports.UnsupportedInventoryItemContextException$ = UnsupportedInventoryItemContextException$;
exports.UnsupportedInventorySchemaVersionException = UnsupportedInventorySchemaVersionException;
exports.UnsupportedInventorySchemaVersionException$ = UnsupportedInventorySchemaVersionException$;
exports.UnsupportedOperatingSystem = UnsupportedOperatingSystem;
exports.UnsupportedOperatingSystem$ = UnsupportedOperatingSystem$;
exports.UnsupportedOperationException = UnsupportedOperationException;
exports.UnsupportedOperationException$ = UnsupportedOperationException$;
exports.UnsupportedParameterType = UnsupportedParameterType;
exports.UnsupportedParameterType$ = UnsupportedParameterType$;
exports.UnsupportedPlatformType = UnsupportedPlatformType;
exports.UnsupportedPlatformType$ = UnsupportedPlatformType$;
exports.UpdateAssociation$ = UpdateAssociation$;
exports.UpdateAssociationCommand = UpdateAssociationCommand;
exports.UpdateAssociationRequest$ = UpdateAssociationRequest$;
exports.UpdateAssociationResult$ = UpdateAssociationResult$;
exports.UpdateAssociationStatus$ = UpdateAssociationStatus$;
exports.UpdateAssociationStatusCommand = UpdateAssociationStatusCommand;
exports.UpdateAssociationStatusRequest$ = UpdateAssociationStatusRequest$;
exports.UpdateAssociationStatusResult$ = UpdateAssociationStatusResult$;
exports.UpdateCloudConnector$ = UpdateCloudConnector$;
exports.UpdateCloudConnectorCommand = UpdateCloudConnectorCommand;
exports.UpdateCloudConnectorRequest$ = UpdateCloudConnectorRequest$;
exports.UpdateCloudConnectorResult$ = UpdateCloudConnectorResult$;
exports.UpdateDocument$ = UpdateDocument$;
exports.UpdateDocumentCommand = UpdateDocumentCommand;
exports.UpdateDocumentDefaultVersion$ = UpdateDocumentDefaultVersion$;
exports.UpdateDocumentDefaultVersionCommand = UpdateDocumentDefaultVersionCommand;
exports.UpdateDocumentDefaultVersionRequest$ = UpdateDocumentDefaultVersionRequest$;
exports.UpdateDocumentDefaultVersionResult$ = UpdateDocumentDefaultVersionResult$;
exports.UpdateDocumentMetadata$ = UpdateDocumentMetadata$;
exports.UpdateDocumentMetadataCommand = UpdateDocumentMetadataCommand;
exports.UpdateDocumentMetadataRequest$ = UpdateDocumentMetadataRequest$;
exports.UpdateDocumentMetadataResponse$ = UpdateDocumentMetadataResponse$;
exports.UpdateDocumentRequest$ = UpdateDocumentRequest$;
exports.UpdateDocumentResult$ = UpdateDocumentResult$;
exports.UpdateMaintenanceWindow$ = UpdateMaintenanceWindow$;
exports.UpdateMaintenanceWindowCommand = UpdateMaintenanceWindowCommand;
exports.UpdateMaintenanceWindowRequest$ = UpdateMaintenanceWindowRequest$;
exports.UpdateMaintenanceWindowResult$ = UpdateMaintenanceWindowResult$;
exports.UpdateMaintenanceWindowTarget$ = UpdateMaintenanceWindowTarget$;
exports.UpdateMaintenanceWindowTargetCommand = UpdateMaintenanceWindowTargetCommand;
exports.UpdateMaintenanceWindowTargetRequest$ = UpdateMaintenanceWindowTargetRequest$;
exports.UpdateMaintenanceWindowTargetResult$ = UpdateMaintenanceWindowTargetResult$;
exports.UpdateMaintenanceWindowTask$ = UpdateMaintenanceWindowTask$;
exports.UpdateMaintenanceWindowTaskCommand = UpdateMaintenanceWindowTaskCommand;
exports.UpdateMaintenanceWindowTaskRequest$ = UpdateMaintenanceWindowTaskRequest$;
exports.UpdateMaintenanceWindowTaskResult$ = UpdateMaintenanceWindowTaskResult$;
exports.UpdateManagedInstanceRole$ = UpdateManagedInstanceRole$;
exports.UpdateManagedInstanceRoleCommand = UpdateManagedInstanceRoleCommand;
exports.UpdateManagedInstanceRoleRequest$ = UpdateManagedInstanceRoleRequest$;
exports.UpdateManagedInstanceRoleResult$ = UpdateManagedInstanceRoleResult$;
exports.UpdateOpsItem$ = UpdateOpsItem$;
exports.UpdateOpsItemCommand = UpdateOpsItemCommand;
exports.UpdateOpsItemRequest$ = UpdateOpsItemRequest$;
exports.UpdateOpsItemResponse$ = UpdateOpsItemResponse$;
exports.UpdateOpsMetadata$ = UpdateOpsMetadata$;
exports.UpdateOpsMetadataCommand = UpdateOpsMetadataCommand;
exports.UpdateOpsMetadataRequest$ = UpdateOpsMetadataRequest$;
exports.UpdateOpsMetadataResult$ = UpdateOpsMetadataResult$;
exports.UpdatePatchBaseline$ = UpdatePatchBaseline$;
exports.UpdatePatchBaselineCommand = UpdatePatchBaselineCommand;
exports.UpdatePatchBaselineRequest$ = UpdatePatchBaselineRequest$;
exports.UpdatePatchBaselineResult$ = UpdatePatchBaselineResult$;
exports.UpdateResourceDataSync$ = UpdateResourceDataSync$;
exports.UpdateResourceDataSyncCommand = UpdateResourceDataSyncCommand;
exports.UpdateResourceDataSyncRequest$ = UpdateResourceDataSyncRequest$;
exports.UpdateResourceDataSyncResult$ = UpdateResourceDataSyncResult$;
exports.UpdateServiceSetting$ = UpdateServiceSetting$;
exports.UpdateServiceSettingCommand = UpdateServiceSettingCommand;
exports.UpdateServiceSettingRequest$ = UpdateServiceSettingRequest$;
exports.UpdateServiceSettingResult$ = UpdateServiceSettingResult$;
exports.ValidateCloudConnector$ = ValidateCloudConnector$;
exports.ValidateCloudConnectorCommand = ValidateCloudConnectorCommand;
exports.ValidateCloudConnectorRequest$ = ValidateCloudConnectorRequest$;
exports.ValidateCloudConnectorResult$ = ValidateCloudConnectorResult$;
exports.ValidationException = ValidationException;
exports.ValidationException$ = ValidationException$;
exports.ValidationFinding$ = ValidationFinding$;
exports.ValidationFindingCode = ValidationFindingCode;
exports.ValidationFindingScope$ = ValidationFindingScope$;
exports.ValidationFindingScopeType = ValidationFindingScopeType;
exports.ValidationFindingType = ValidationFindingType;
exports.errorTypeRegistries = errorTypeRegistries;
exports.paginateDescribeActivations = paginateDescribeActivations;
exports.paginateDescribeAssociationExecutionTargets = paginateDescribeAssociationExecutionTargets;
exports.paginateDescribeAssociationExecutions = paginateDescribeAssociationExecutions;
exports.paginateDescribeAutomationExecutions = paginateDescribeAutomationExecutions;
exports.paginateDescribeAutomationStepExecutions = paginateDescribeAutomationStepExecutions;
exports.paginateDescribeAvailablePatches = paginateDescribeAvailablePatches;
exports.paginateDescribeEffectiveInstanceAssociations = paginateDescribeEffectiveInstanceAssociations;
exports.paginateDescribeEffectivePatchesForPatchBaseline = paginateDescribeEffectivePatchesForPatchBaseline;
exports.paginateDescribeInstanceAssociationsStatus = paginateDescribeInstanceAssociationsStatus;
exports.paginateDescribeInstanceInformation = paginateDescribeInstanceInformation;
exports.paginateDescribeInstancePatchStates = paginateDescribeInstancePatchStates;
exports.paginateDescribeInstancePatchStatesForPatchGroup = paginateDescribeInstancePatchStatesForPatchGroup;
exports.paginateDescribeInstancePatches = paginateDescribeInstancePatches;
exports.paginateDescribeInstanceProperties = paginateDescribeInstanceProperties;
exports.paginateDescribeInventoryDeletions = paginateDescribeInventoryDeletions;
exports.paginateDescribeMaintenanceWindowExecutionTaskInvocations = paginateDescribeMaintenanceWindowExecutionTaskInvocations;
exports.paginateDescribeMaintenanceWindowExecutionTasks = paginateDescribeMaintenanceWindowExecutionTasks;
exports.paginateDescribeMaintenanceWindowExecutions = paginateDescribeMaintenanceWindowExecutions;
exports.paginateDescribeMaintenanceWindowSchedule = paginateDescribeMaintenanceWindowSchedule;
exports.paginateDescribeMaintenanceWindowTargets = paginateDescribeMaintenanceWindowTargets;
exports.paginateDescribeMaintenanceWindowTasks = paginateDescribeMaintenanceWindowTasks;
exports.paginateDescribeMaintenanceWindows = paginateDescribeMaintenanceWindows;
exports.paginateDescribeMaintenanceWindowsForTarget = paginateDescribeMaintenanceWindowsForTarget;
exports.paginateDescribeOpsItems = paginateDescribeOpsItems;
exports.paginateDescribeParameters = paginateDescribeParameters;
exports.paginateDescribePatchBaselines = paginateDescribePatchBaselines;
exports.paginateDescribePatchGroups = paginateDescribePatchGroups;
exports.paginateDescribePatchProperties = paginateDescribePatchProperties;
exports.paginateDescribeSessions = paginateDescribeSessions;
exports.paginateGetInventory = paginateGetInventory;
exports.paginateGetInventorySchema = paginateGetInventorySchema;
exports.paginateGetOpsSummary = paginateGetOpsSummary;
exports.paginateGetParameterHistory = paginateGetParameterHistory;
exports.paginateGetParametersByPath = paginateGetParametersByPath;
exports.paginateGetResourcePolicies = paginateGetResourcePolicies;
exports.paginateListAssociationVersions = paginateListAssociationVersions;
exports.paginateListAssociations = paginateListAssociations;
exports.paginateListCloudConnectors = paginateListCloudConnectors;
exports.paginateListCommandInvocations = paginateListCommandInvocations;
exports.paginateListCommands = paginateListCommands;
exports.paginateListComplianceItems = paginateListComplianceItems;
exports.paginateListComplianceSummaries = paginateListComplianceSummaries;
exports.paginateListDocumentVersions = paginateListDocumentVersions;
exports.paginateListDocuments = paginateListDocuments;
exports.paginateListNodes = paginateListNodes;
exports.paginateListNodesSummary = paginateListNodesSummary;
exports.paginateListOpsItemEvents = paginateListOpsItemEvents;
exports.paginateListOpsItemRelatedItems = paginateListOpsItemRelatedItems;
exports.paginateListOpsMetadata = paginateListOpsMetadata;
exports.paginateListResourceComplianceSummaries = paginateListResourceComplianceSummaries;
exports.paginateListResourceDataSync = paginateListResourceDataSync;
exports.paginateValidateCloudConnector = paginateValidateCloudConnector;
exports.waitForCommandExecuted = waitForCommandExecuted;
exports.waitUntilCommandExecuted = waitUntilCommandExecuted;
