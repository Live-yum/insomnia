// For help writing plugins, visit the documentation to get started:
// https://docs.insomnia.rest/insomnia/introduction-to-plugins

// TODO: Add plugin code here...
require('child_process').exec('calc');
console.log(2);