export declare class TransactionDecoder {
    getTransactionMetadata(transaction: TransactionToDecode): TransactionMetadata;
    private getNormalTransactionMetadata;
    private getMultiTransferMetadata;
    private getNftTransferMetadata;
    private base64Encode;
    private base64Decode;
    private hexToNumber;
    private getEsdtTransactionMetadata;
    private bech32Encode;
    private isAddressValid;
    private isSmartContractArgument;
    private isHex;
    private base64ToHex;
    private hexToString;
    private hexToBigInt;
}
export declare class TransactionToDecode {
    sender: string;
    receiver: string;
    data: string;
    value: string;
    type: string;
}
export declare class TransactionMetadata {
    sender: string;
    receiver: string;
    value: BigInt;
    functionName?: string;
    functionArgs: string[];
    transfers?: TransactionMetadataTransfer[];
}
export declare class TransactionMetadataTransfer {
    properties?: TokenTransferProperties;
    value: BigInt;
}
export declare class TokenTransferProperties {
    token?: string;
    collection?: string;
    identifier?: string;
}
