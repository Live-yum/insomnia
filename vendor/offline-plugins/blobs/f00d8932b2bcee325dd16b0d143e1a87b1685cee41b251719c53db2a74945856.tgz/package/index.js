module.exports.responseHooks = [
  async context => {
    try {
      const requestUrl = context.request.getUrl();
      console.log(`[login-handler] Checking response for URL: ${requestUrl}`);

      if (!requestUrl.includes('/auth')) {
        console.log('[login-handler] Skipping non-auth request');
        return;
      }

      const bodyBuffer = await context.response.getBody();
      const body = bodyBuffer.toString();
      const json = JSON.parse(body);

      for (const [key, value] of Object.entries(json)) {
        await context.store.setItem(`env:${key}`, value);
        console.log(`[login-handler] Set env: ${key} = ${value}`);
      }

    } catch (e) {
      console.error('[login-handler] Failed to parse response or set env vars', e);
    }
  }
];
