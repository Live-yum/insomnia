'use strict'

const { generateKeyPairSignature } = require('@fulll/signature')

module.exports.templateTags = [
  {
    name: 'signaturev2',
    displayName: 'APISignature-Fulll',
    description: 'Apply api signature using @fulll/signature',
    args: [
      {
        displayName: 'api key',
        type: 'string',
        placeholder: 'the api key',
      },
      {
        displayName: 'api secret key',
        type: 'string',
        placeholder: 'the api secret key',
      },
      {
        displayName: 'ttl in seconds',
        type: 'number',
        placeholder: 'Optional TTL value in second',
      },
    ],
    async run(context, apiKey = '', apiSecretKey = '', ttl = 120) {
      const { meta } = context

      const request = await context.util.models.request.getById(meta.requestId)
      const httpMethod = request.method

      const signature = generateKeyPairSignature(apiKey, apiSecretKey, ttl)

      return `${signature}`
    },
  },
]
