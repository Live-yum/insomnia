
module.exports.templateTags = [
  {
    displayName: 'getObjValue',
    name: 'getObjValue',
    description: 'Given an obj path X, an key path Y and a target Z, it does X[Y][Z]',
    args: [
      {
        displayName: 'object path',
        description: "The object's path that will be used",
        type: 'string',
        defaultValue: 'all_env'
      },
      {
        displayName: 'key path',
        description: "The key's path",
        type: 'string',
        defaultValue: 'curr_env'
      },
      {
        displayName: 'target path',
        description: 'path',
        type: 'string',
        placeholder: "parent.child"
      }
    ],
    run(context, obj_path, key_path, target_path) {
      let selected_key = ""
      try {
        selected_key = get(context.context, key_path)
      } catch {
        throw "ERROR: invalid key path <" + key_path + ">"
      }

      let selected_obj = ""
      try {
        selected_obj = get(context.context, obj_path)
      } catch {
        throw "ERROR: invalid obj path <" + obj_path + ">"
      }

      if (typeof selected_obj !== "object") {
        throw "ERROR: obj path does not point to an object"
      }
      let env_vars = selected_obj[selected_key]
      if (env_vars == null) {
        throw "ERROR: not found key on object"
      }

      let path = []
      if (target_path !== "") {
        path = target_path.split('.')
      }
      previous_env_vars = env_vars;
      last_elem = path.length - 1;
      for (i = 0; i < path.length; i++) {
        previous_env_vars = env_vars;
        env_vars = env_vars[path[i]];
      }
      if (typeof env_vars !== "string") {
        let props = getPropsStartingWith(env_vars, path[last_elem]);
        if (props === "") {
          props = getPropsStartingWith(previous_env_vars, path[last_elem]);
        }
        throw "SELECT AN OPTION:\n" + props;
      }
      return env_vars;
    }
  }
];


function get(obj, path) {
  let v = []
  if (path !== "") {
    v = path.split('.')
  }
  for (i = 0; i < v.length; i++) {
    if (obj.hasOwnProperty(v[i])) {
      obj = obj[v[i]];
    } else {
      throw path
    }
  }
  return obj
}

function getPropsStartingWith(target, prefix) {
  let result = []
  let get_all = (
      (prefix === null) ||
      (prefix === undefined) ||
      (prefix === ""))
  for (const prop in target) {
      if (get_all || prop.startsWith(prefix)) {
          if (target.hasOwnProperty(prop)) {
              if (typeof target[prop] === 'object') {
                  result.push(`- ${prop}.`);
              } else {
                  result.push(`- ${prop}`);
              }
          }
      }
  }
  result = result.sort();
  return result.join("\n");
}