# get obj value Plugin

An Insomnia plugin that extracts values from nested objects using dynamic object, key, and target paths with dot notation.


## Example
given the environment variables:
```json
{
    "all_env": {
        "production": {
            "url": {
                "serviceA": "http://serviceA-production.acme.com"
            },
        },
        "sandbox": {
            "url": {
                "serviceA": "http://serviceA-sandbox.acme.com"
            }
        }
    }
}
```

Where:
- `object path`: `all_env`
- `key path`: `production`
- `target path`: `url.serviceA`

it returns: `http://serviceA-production.acme.com`
