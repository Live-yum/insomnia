export declare const name = "@azure/msal-common";
export declare const version = "16.8.0";
//# sourceMappingURL=packageMetadata.d.ts.map