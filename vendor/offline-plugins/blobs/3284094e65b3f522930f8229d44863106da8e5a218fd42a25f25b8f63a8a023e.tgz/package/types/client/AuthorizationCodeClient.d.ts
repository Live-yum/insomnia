import { CommonAuthorizationCodeRequest } from "../request/CommonAuthorizationCodeRequest.js";
import { Authority } from "../authority/Authority.js";
import { ClientConfiguration, CommonClientConfiguration } from "../config/ClientConfiguration.js";
import { AuthenticationResult } from "../response/AuthenticationResult.js";
import { CommonEndSessionRequest } from "../request/CommonEndSessionRequest.js";
import { AuthorizationCodePayload } from "../response/AuthorizationCodePayload.js";
import { IPerformanceClient } from "../telemetry/performance/IPerformanceClient.js";
import { ServerTelemetryManager } from "../telemetry/server/ServerTelemetryManager.js";
import { Logger } from "../logger/Logger.js";
import { ICrypto } from "../crypto/ICrypto.js";
import { CacheManager } from "../cache/CacheManager.js";
import { INetworkModule } from "../network/INetworkModule.js";
/**
 * Oauth2.0 Authorization Code client
 * @internal
 */
export declare class AuthorizationCodeClient {
    protected includeRedirectUri: boolean;
    private oidcDefaultScopes;
    logger: Logger;
    protected config: CommonClientConfiguration;
    protected cryptoUtils: ICrypto;
    protected cacheManager: CacheManager;
    protected networkClient: INetworkModule;
    protected serverTelemetryManager: ServerTelemetryManager | null;
    authority: Authority;
    protected performanceClient: IPerformanceClient;
    constructor(configuration: ClientConfiguration, performanceClient: IPerformanceClient);
    /**
     * API to acquire a token in exchange of 'authorization_code` acquired by the user in the first leg of the
     * authorization_code_grant
     * @param request
     */
    acquireToken(request: CommonAuthorizationCodeRequest, apiId: number, authCodePayload?: AuthorizationCodePayload): Promise<AuthenticationResult>;
    /**
     * Used to log out the current user, and redirect the user to the postLogoutRedirectUri.
     * Default behaviour is to redirect the user to `window.location.href`.
     * @param authorityUri
     */
    getLogoutUri(logoutRequest: CommonEndSessionRequest): string;
    /**
     * Executes POST request to token endpoint
     * @param authority
     * @param request
     */
    private executeTokenRequest;
    /**
     * Generates a map for all the params to be sent to the service
     * @param request
     */
    private createTokenRequestBody;
    /**
     * This API validates the `EndSessionRequest` and creates a URL
     * @param request
     */
    private createLogoutUrlQueryString;
    /**
     * Updates the authority to the cloud instance provided in the authorization response
     * @param cloudInstanceHostName - cloud instance host name from authorization code payload
     * @param correlationId - request correlation id
     */
    private updateTokenEndpointAuthority;
}
//# sourceMappingURL=AuthorizationCodeClient.d.ts.map