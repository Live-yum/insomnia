/*! @azure/msal-common v16.8.0 2026-06-10 */
'use strict';
/*
 * Copyright (c) Microsoft Corporation. All rights reserved.
 * Licensed under the MIT License.
 */
const cacheQuotaExceeded = "cache_quota_exceeded";
const cacheErrorUnknown = "cache_error_unknown";

export { cacheErrorUnknown, cacheQuotaExceeded };
//# sourceMappingURL=CacheErrorCodes.mjs.map
