/*! @azure/msal-common v16.8.0 2026-06-10 */
'use strict';
/*
 * Copyright (c) Microsoft Corporation. All rights reserved.
 * Licensed under the MIT License.
 */
const missingKidError = "missing_kid_error";
const missingAlgError = "missing_alg_error";

export { missingAlgError, missingKidError };
//# sourceMappingURL=JoseHeaderErrorCodes.mjs.map
