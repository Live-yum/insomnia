/*! @azure/msal-common v16.8.0 2026-06-10 */
'use strict';
/* eslint-disable header/header */
const name = "@azure/msal-common";
const version = "16.8.0";

export { name, version };
//# sourceMappingURL=packageMetadata.mjs.map
