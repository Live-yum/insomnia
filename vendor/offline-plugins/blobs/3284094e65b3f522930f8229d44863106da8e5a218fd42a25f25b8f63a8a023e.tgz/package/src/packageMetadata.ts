/* eslint-disable header/header */
export const name = "@azure/msal-common";
export const version = "16.8.0";
