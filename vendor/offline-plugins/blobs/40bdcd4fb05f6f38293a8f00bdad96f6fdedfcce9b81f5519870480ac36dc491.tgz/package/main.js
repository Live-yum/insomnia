module.exports.requestHooks = [
    (context) => {
        const req = context.request;
        var url = req.getUrl().replace("http://", "");
        if (url.startsWith("/")) {
            url = url.substring(1);
        }
        const isLocal = req.getEnvironmentVariable("isLocal");
        const baseUrl = req.getEnvironmentVariable("url");
        const tokenUrl = req.getEnvironmentVariable("tokenUrl");
        const serviceName = req.getEnvironmentVariable("serviceName");
        const tokenApi = req.getEnvironmentVariable("tokenApi");
        if (url && tokenApi && url === tokenApi && tokenUrl) {
            req.setUrl(`${tokenUrl}/${url}`);
            return;
        }
        const urls = [];
        baseUrl && urls.push(baseUrl);
        !isLocal && serviceName && urls.push(serviceName);
        urls.push(url);
        req.setUrl(`${urls.join("/")}`);
    }
];