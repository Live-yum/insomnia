
## Installation
Install the `insomnia-plugin-pre-url` plugin from Preferences > Plugins.

## Usage

### You can define the base variable 
- url: the base domain url, like "https://www.xxxx.com"(<font color="#dd0000">required</font>)
- tokenUrl: get token domain url, like "https://token.xxxx.com"
- tokenApi: get token api, like "get/token"
- serviceName: subdomain, like "subdomain"
- isLocal: is local environment
```
{
	"url": "https://www.xxxx.com",
	"tokenUrl": "https://token.xxxx.com",
	"tokenApi": "get/token",
	"serviceName": "subdomain",
	"isLocal":false
}
```

### You can get different full api through different environment

```javascript
api: "/api"
method: "get"
```

```javascript
Local environment
{
	"url": "http://localhost:8080",
	"tokenUrl": "https://dev-token.xxxx.com",
	"tokenApi": "get/token",
	"serviceName": "subdomain",
	"isLocal":true
}
Full api: "http://localhost:8080/api"
```

```javascript
Dev environment
{
	"url": "https://dev.xxxx.com",
	"tokenUrl": "https://dev-token.xxxx.com",
	"tokenApi": "get/token",
	"serviceName": "subdomain",
	"isLocal":false
}
Full api: "https://dev.xxxx.com/subdomain/api"
```

```javascript
Live environment
{
	"url": "https://live.xxxx.com",
	"tokenUrl": "https://live-token.xxxx.com",
	"tokenApi": "get/token",
	"serviceName": "subdomain",
	"isLocal":false
}
Full api: "https://live.xxxx.com/subdomain/api"
```

## Scope
- Pre handle domain url through environment variable