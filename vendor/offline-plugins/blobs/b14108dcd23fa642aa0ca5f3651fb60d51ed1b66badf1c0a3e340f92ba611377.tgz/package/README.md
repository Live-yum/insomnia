Plugin for aplication Insomnia. Allows sending request with authorization via HMAC through two headers: HMAC-accessKey, HMAC-signingKey. Prefix HMAC is there to avoid collisions.
