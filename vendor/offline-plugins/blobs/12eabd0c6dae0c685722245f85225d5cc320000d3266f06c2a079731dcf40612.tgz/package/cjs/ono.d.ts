import { OnoConstructor, OnoSingleton } from "./types";
declare const onoConstructor: OnoConstructor;
declare const onoSingleton: OnoSingleton;
export { onoConstructor as Ono, onoSingleton as ono };
