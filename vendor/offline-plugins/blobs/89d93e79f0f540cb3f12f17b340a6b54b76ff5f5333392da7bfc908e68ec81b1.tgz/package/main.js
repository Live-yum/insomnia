// For help writing plugins, visit the documentation to get started:
//   https://support.insomnia.rest/article/26-plugins

// TODO: Add plugin code here...
const fs = require('fs');
const os = require('os');
const moment = require('moment');
const path = require('path');

module.exports.workspaceActions = [
	{
		label  : '导出全部空间数据',
		icon   : 'fa-download',
		action : async (context, models) => {
			const ex = await context.data.export.insomnia({
				includePrivate : false,
				format         : 'json'
			});

			exportData(ex, 'ALL');
		}
	},
	{
		label  : '导出当前工作空间数据',
		icon   : 'fa-download',
		action : async (context, models) => {
			const ex = await context.data.export.insomnia({
				includePrivate : false,
				format         : 'json',
				workspace      : models.workspace
			});

			exportData(ex, models.workspace.name);
		}
	},
	{
		label  : '导入git的数据',
		icon   : 'fa-upload',
		action : async (context, models) => {
			context.app.alert('导入git的数据', '功能尚未完成，敬请期待')
		}
	},
	{
		label  : '插件集合配置',
		icon   : 'fa-cogs',
		action : async (context, models) => {
			await loadConfiguration(context, true);
		}
	}
];

/**
 * 导出insomnia的内容
 * @param {*} insomniaContext 等待导出的insomnial的json内容
 * @param {*} workspaceName  当前的工作空间的名字
 */
const exportData = function (insomniaContext, workspaceName) {
	const homedir = os.homedir();
	const today = moment().format('YYYY-MM-DD');
	const fullFileName = path.join(homedir, 'Insomnia-' + today + '-' + workspaceName + '.json');
	fs.writeFileSync(fullFileName, insomniaContext);
};

/**
 * 
 * @param {*} context insomnia 上下文
 * @param {*} forceUpdate 是否强制更新
 */
const loadConfiguration = async function (context, forceUpdate) {
	const oldConfig = await context.store.getItem('my-action:config');

	if (!oldConfig || forceUpdate) {
		// 加载配置文件
		try {
			// gitRepoPath git远程仓库的配置
			// currentPath 当前机器上要保存的路径
			// gitToken 访问token
			var config = await context.app.prompt('my-action全局配置', {
				// label        : 'my-action全局配置',
				defaultValue : oldConfig || '{ "gitRepoPath": "","gitToken":"","currentPath":""}',
				submitName   : '提交',
				cancelable   : true
			});
		} catch (e) {
			return false;
		}

		// 校验下当前的配置文件是否合法
		try {
			JSON.parse(config);
		} catch (e) {
			context.app.alert('Invalid JSON!', 'Error: ' + e.message);
			return false;
		}

		// 保存当前的配置文件到insomnia中
		await context.store.setItem('my-action:config', config);
		return config;
	}

	// 如果没有老的配置
	return JSON.parse(oldConfig);
};
