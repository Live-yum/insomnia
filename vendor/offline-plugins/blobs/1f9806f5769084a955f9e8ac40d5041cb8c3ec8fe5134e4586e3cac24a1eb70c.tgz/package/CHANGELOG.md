## [1.1.5](https://github.com/drg-adaptive/insomnia-plugin-cloudformation-output/compare/v1.1.4...v1.1.5) (2020-04-23)


### Bug Fixes

* ignore extra files in npm ([45ab4a2](https://github.com/drg-adaptive/insomnia-plugin-cloudformation-output/commit/45ab4a26bfadd35b3d85a92969ae85754773cb33))
* logic error ([4fd2631](https://github.com/drg-adaptive/insomnia-plugin-cloudformation-output/commit/4fd2631cd65e03b1c636346a5cee8f81216b3e49))
