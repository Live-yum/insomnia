export declare function nonenumerable(target: Object, key: string): void;
