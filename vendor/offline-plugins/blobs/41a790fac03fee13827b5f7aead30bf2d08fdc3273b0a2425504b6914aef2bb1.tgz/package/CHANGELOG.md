# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [6.3.20](https://github.com/aws-amplify/amplify-js/compare/amazon-cognito-identity-js@6.3.19...amazon-cognito-identity-js@6.3.20) (2026-07-04)

**Note:** Version bump only for package amazon-cognito-identity-js

## [6.3.19](https://github.com/aws-amplify/amplify-js/compare/amazon-cognito-identity-js@6.3.18...amazon-cognito-identity-js@6.3.19) (2026-07-04)

**Note:** Version bump only for package amazon-cognito-identity-js

## [6.3.18](https://github.com/aws-amplify/amplify-js/compare/amazon-cognito-identity-js@6.3.17...amazon-cognito-identity-js@6.3.18) (2026-06-15)

### Bug Fixes

- complete partial v5-stable LTS release (publish remaining packages) ([#14843](https://github.com/aws-amplify/amplify-js/issues/14843)) ([b17999d](https://github.com/aws-amplify/amplify-js/commit/b17999d4be1e39c2a3127cf83bf509fb8ca807bc)), closes [#14842](https://github.com/aws-amplify/amplify-js/issues/14842)

## [6.3.17](https://github.com/aws-amplify/amplify-js/compare/amazon-cognito-identity-js@6.3.16...amazon-cognito-identity-js@6.3.17) (2026-06-12)

### Bug Fixes

- resolve dependency security vulnerabilities (axios, js-cookie, fast-xml-parser, qs) in v5 ([#14832](https://github.com/aws-amplify/amplify-js/issues/14832)) ([7b1f9af](https://github.com/aws-amplify/amplify-js/commit/7b1f9af686ffd26b6a8b326e5097e253dce61f45))

## [6.3.16](https://github.com/aws-amplify/amplify-js/compare/amazon-cognito-identity-js@6.3.15...amazon-cognito-identity-js@6.3.16) (2025-11-10)

### Bug Fixes

- **amazon-cognito-identity-js:** Use JavaScript fallbacks when RNAWSCognito not available. ([356c0b8](https://github.com/aws-amplify/amplify-js/commit/356c0b83b0ce3affcd836361179fbd3341ca7085))

## [6.3.15](https://github.com/aws-amplify/amplify-js/compare/amazon-cognito-identity-js@6.3.14...amazon-cognito-identity-js@6.3.15) (2025-02-05)

### Bug Fixes

- **amazon-cognito-identity-js:** not using latest tag ([#14156](https://github.com/aws-amplify/amplify-js/issues/14156)) ([7f259d6](https://github.com/aws-amplify/amplify-js/commit/7f259d65ebe020469350b0b7f67e0bf9125defee))

## [6.3.14](https://github.com/aws-amplify/amplify-js/compare/amazon-cognito-identity-js@6.3.13...amazon-cognito-identity-js@6.3.14) (2024-10-15)

### Bug Fixes

- **auth:** request initiateAuth with retry ([#13854](https://github.com/aws-amplify/amplify-js/issues/13854)) ([33640c4](https://github.com/aws-amplify/amplify-js/commit/33640c488b75b76ddd3c5b13889e9a1f736c842a))

## 6.3.13 (2024-03-21)

### Bug Fixes

- **auth:** storage not synced before accessing when the app boots from killed state ([#13005](https://github.com/aws-amplify/amplify-js/issues/13005)) ([a2dbd86](https://github.com/aws-amplify/amplify-js/commit/a2dbd86bcf29f58d9e28d68a0f501c5c0e7a7cc7))

## 6.3.12 (2024-03-06)

**Note:** Version bump only for package amazon-cognito-identity-js

## 6.3.11 (2024-02-20)

**Note:** Version bump only for package amazon-cognito-identity-js

## 6.3.10 (2024-01-09)

**Note:** Version bump only for package amazon-cognito-identity-js

## 6.3.9 (2024-01-05)

### Bug Fixes

- **auth:** replace window history with current browser session's state ([#12782](https://github.com/aws-amplify/amplify-js/issues/12782)) ([c393316](https://github.com/aws-amplify/amplify-js/commit/c3933168d156023e634a83382d3c035118061195))

## 6.3.8 (2023-12-04)

### Bug Fixes

- prevent memory leak in withSSRContext ([#12570](https://github.com/aws-amplify/amplify-js/issues/12570)) ([f963a11](https://github.com/aws-amplify/amplify-js/commit/f963a119f00503a9f4e193f7b9fea231f1fc958e))

## 6.3.7 (2023-11-06)

### Bug Fixes

- **api-rest:** infinite retry when clock skew go back and forth ([#12488](https://github.com/aws-amplify/amplify-js/issues/12488)) ([095efac](https://github.com/aws-amplify/amplify-js/commit/095efac51abc14a4e805ccb71d1fa9f46fde4065))

## 6.3.6 (2023-09-14)

**Note:** Version bump only for package amazon-cognito-identity-js

## 6.3.5 (2023-08-23)

**Note:** Version bump only for package amazon-cognito-identity-js

## 6.3.4 (2023-08-22)

**Note:** Version bump only for package amazon-cognito-identity-js

## 6.3.3 (2023-08-17)

**Note:** Version bump only for package amazon-cognito-identity-js

## 6.3.2 (2023-08-10)

**Note:** Version bump only for package amazon-cognito-identity-js

## [6.3.1](https://github.com/aws-amplify/amplify-js/compare/amazon-cognito-identity-js@6.3.0...amazon-cognito-identity-js@6.3.1) (2023-06-21)

### Bug Fixes

- Update getAmplifyUserAgent to retain original interface ([#11535](https://github.com/aws-amplify/amplify-js/issues/11535)) ([dc84cc8](https://github.com/aws-amplify/amplify-js/commit/dc84cc8bfa7811b5f4f8ac2f7e5ea1b5edc54fe1))

# [6.3.0](https://github.com/aws-amplify/amplify-js/compare/amazon-cognito-identity-js@6.2.0...amazon-cognito-identity-js@6.3.0) (2023-06-20)

### Bug Fixes

- Broken test ([#11521](https://github.com/aws-amplify/amplify-js/issues/11521)) ([d815c7b](https://github.com/aws-amplify/amplify-js/commit/d815c7b22f9ef5eba65f07b1d2e94a8e70516989))
- PR comments ([#11520](https://github.com/aws-amplify/amplify-js/issues/11520)) ([1ca73b1](https://github.com/aws-amplify/amplify-js/commit/1ca73b1431d4bb737890ac95004f10c3e572ba8b))

### Features

- user agent enhancements - auth reduction ([#11465](https://github.com/aws-amplify/amplify-js/issues/11465)) ([f73abd2](https://github.com/aws-amplify/amplify-js/commit/f73abd2f3c9a377a4d14832c68ea2880a1372020))
- user agent enhancements - part1 cognito ([#11324](https://github.com/aws-amplify/amplify-js/issues/11324)) ([4f541d2](https://github.com/aws-amplify/amplify-js/commit/4f541d28cb586cb66acd22b90f87fd515fd9cb4e))

# [6.2.0](https://github.com/aws-amplify/amplify-js/compare/amazon-cognito-identity-js@6.1.2...amazon-cognito-identity-js@6.2.0) (2023-03-23)

### Features

- **cognito:** make cookiestorage constructor parameter optional ([9b8e759](https://github.com/aws-amplify/amplify-js/commit/9b8e75973762ce498269de0162a3e70038238f0f))
- **cognito:** remove required domain param when create CookieStorage ([c985454](https://github.com/aws-amplify/amplify-js/commit/c985454b0af9f2205941ab95d6ec8c42748ab63d))

## [6.1.2](https://github.com/aws-amplify/amplify-js/compare/amazon-cognito-identity-js@6.1.1...amazon-cognito-identity-js@6.1.2) (2022-12-27)

### Bug Fixes

- **amazon-cognito-identity-js:** sets no-store header for cognito user pools ([#10804](https://github.com/aws-amplify/amplify-js/issues/10804)) ([b9ec192](https://github.com/aws-amplify/amplify-js/commit/b9ec1926c8ba3d2d0b2289a9b84090fb5d724ad9))

## [6.1.1](https://github.com/aws-amplify/amplify-js/compare/amazon-cognito-identity-js@6.1.0...amazon-cognito-identity-js@6.1.1) (2022-12-16)

### Bug Fixes

- **amazon-cognito-identity-js:** specify the correct userAgent/deviceName when remembering devices (React Native) ([#10724](https://github.com/aws-amplify/amplify-js/issues/10724)) ([01a5b84](https://github.com/aws-amplify/amplify-js/commit/01a5b84ea010f7fb66c4e19e73301cce82fc7370))

# [6.1.0](https://github.com/aws-amplify/amplify-js/compare/amazon-cognito-identity-js@6.0.1...amazon-cognito-identity-js@6.1.0) (2022-12-15)

### Bug Fixes

- **core:** add cache-control header to cognito identity client ([#10753](https://github.com/aws-amplify/amplify-js/issues/10753)) ([dfbabaf](https://github.com/aws-amplify/amplify-js/commit/dfbabaf54dda902f1f77c4501e78f49e6a9397af))

### Features

- **auth,cognito-identity-js:** returning code delivery details as part of callback for updateAttributes, adds hub event to Auth.updateUserAttributes ([#10731](https://github.com/aws-amplify/amplify-js/issues/10731)) ([fc4940b](https://github.com/aws-amplify/amplify-js/commit/fc4940bc17e0deeb9e9ca2a00bed101e8ff7d3df))

## [6.0.1](https://github.com/aws-amplify/amplify-js/compare/amazon-cognito-identity-js@6.0.0...amazon-cognito-identity-js@6.0.1) (2022-11-11)

**Note:** Version bump only for package amazon-cognito-identity-js

# [6.0.0](https://github.com/aws-amplify/amplify-js/compare/amazon-cognito-identity-js@5.2.12...amazon-cognito-identity-js@6.0.0) (2022-11-09)

### Features

- Migrate auth and amazon-cognito-identity-js to use @aws-crypto/sha256-js ([#10523](https://github.com/aws-amplify/amplify-js/pull/10523))
- add a typescript coverage report mechanism ([#10551](https://github.com/aws-amplify/amplify-js/issues/10551)) ([8e8df55](https://github.com/aws-amplify/amplify-js/commit/8e8df55b449f8bae2fe962fe282613d1b818cc5a)), closes [#10379](https://github.com/aws-amplify/amplify-js/issues/10379)

## [5.2.12](https://github.com/aws-amplify/amplify-js/compare/amazon-cognito-identity-js@5.2.11...amazon-cognito-identity-js@5.2.12) (2022-10-25)

### Bug Fixes

- Update .d.ts file to match the actual code ([#8825](https://github.com/aws-amplify/amplify-js/issues/8825)) ([272c2c6](https://github.com/aws-amplify/amplify-js/commit/272c2c607cc4adb5ddc9421444887bdb382227a0))

## [5.2.11](https://github.com/aws-amplify/amplify-js/compare/amazon-cognito-identity-js@5.2.10...amazon-cognito-identity-js@5.2.11) (2022-10-14)

**Note:** Version bump only for package amazon-cognito-identity-js

## [5.2.10](https://github.com/aws-amplify/amplify-js/compare/amazon-cognito-identity-js@5.2.9...amazon-cognito-identity-js@5.2.10) (2022-07-07)

### Bug Fixes

- **amazon-cognito-identity-js:** Missing cognito user challenge name … ([#10047](https://github.com/aws-amplify/amplify-js/issues/10047)) ([de0441b](https://github.com/aws-amplify/amplify-js/commit/de0441b4fa67409ccbc630c42890e2c58ee779fb)), closes [#6974](https://github.com/aws-amplify/amplify-js/issues/6974)

## [5.2.9](https://github.com/aws-amplify/amplify-js/compare/amazon-cognito-identity-js@5.2.8...amazon-cognito-identity-js@5.2.9) (2022-05-23)

### Bug Fixes

- docs for amazon-cognito-identity-js ([#9909](https://github.com/aws-amplify/amplify-js/issues/9909)) ([08e01b1](https://github.com/aws-amplify/amplify-js/commit/08e01b1c09cfab73f2eb1b1b18fe1a696e2a028f))

## [5.2.8](https://github.com/aws-amplify/amplify-js/compare/amazon-cognito-identity-js@5.2.7...amazon-cognito-identity-js@5.2.8) (2022-03-10)

**Note:** Version bump only for package amazon-cognito-identity-js

## [5.2.7](https://github.com/aws-amplify/amplify-js/compare/amazon-cognito-identity-js@5.2.6...amazon-cognito-identity-js@5.2.7) (2022-02-28)

### Bug Fixes

- pin async storage to 1.15.17 ([#9570](https://github.com/aws-amplify/amplify-js/issues/9570)) ([bc5235a](https://github.com/aws-amplify/amplify-js/commit/bc5235ac0d15242f7a13457f40999b5331823395))
- pin babel-core and babel-cli version ([#9593](https://github.com/aws-amplify/amplify-js/issues/9593)) ([a0fc830](https://github.com/aws-amplify/amplify-js/commit/a0fc830626ea5466555f2f60d66cc496145a5d1b))

## [5.2.6](https://github.com/aws-amplify/amplify-js/compare/amazon-cognito-identity-js@5.2.5...amazon-cognito-identity-js@5.2.6) (2022-02-03)

**Note:** Version bump only for package amazon-cognito-identity-js

## [5.2.5](https://github.com/aws-amplify/amplify-js/compare/amazon-cognito-identity-js@5.2.4...amazon-cognito-identity-js@5.2.5) (2022-01-27)

### Bug Fixes

- pin jsdoc version ([#9510](https://github.com/aws-amplify/amplify-js/issues/9510)) ([98aec09](https://github.com/aws-amplify/amplify-js/commit/98aec098539535c47afb117bc802eba06ae2c1b2))

### Reverts

- Revert "chore(amplify-js): consolidate react-native dependencies (#9451)" (#9473) ([9924a31](https://github.com/aws-amplify/amplify-js/commit/9924a31397761fccd03f53336d754b98367199a8)), closes [#9451](https://github.com/aws-amplify/amplify-js/issues/9451) [#9473](https://github.com/aws-amplify/amplify-js/issues/9473)

## [5.2.4](https://github.com/aws-amplify/amplify-js/compare/amazon-cognito-identity-js@5.2.3...amazon-cognito-identity-js@5.2.4) (2022-01-07)

### Bug Fixes

- **amazon-cognito-identity-js:** added missing method param ([#9276](https://github.com/aws-amplify/amplify-js/issues/9276)) ([6c4d4b5](https://github.com/aws-amplify/amplify-js/commit/6c4d4b5fc737652f88dcdfa26bdb02a1defdfa2e)), closes [#9275](https://github.com/aws-amplify/amplify-js/issues/9275)

## [5.2.3](https://github.com/aws-amplify/amplify-js/compare/amazon-cognito-identity-js@5.2.2...amazon-cognito-identity-js@5.2.3) (2021-11-09)

**Note:** Version bump only for package amazon-cognito-identity-js

## [5.2.2](https://github.com/aws-amplify/amplify-js/compare/amazon-cognito-identity-js@5.2.1...amazon-cognito-identity-js@5.2.2) (2021-10-28)

**Note:** Version bump only for package amazon-cognito-identity-js

## [5.2.1](https://github.com/aws-amplify/amplify-js/compare/amazon-cognito-identity-js@5.2.0...amazon-cognito-identity-js@5.2.1) (2021-10-21)

### Bug Fixes

- **amazon-cognito-identity-js): Revert "feat(amazon-cognito-identity-js:** Clears "\_\_uploadInProgress" from local storage" ([#8998](https://github.com/aws-amplify/amplify-js/issues/8998)) ([91590e3](https://github.com/aws-amplify/amplify-js/commit/91590e353af09667ccbd4c4fb6860322a095ef23))

# [5.2.0](https://github.com/aws-amplify/amplify-js/compare/amazon-cognito-identity-js@5.1.2...amazon-cognito-identity-js@5.2.0) (2021-09-30)

### Features

- **amazon-cognito-identity-js:** Clears "\_\_uploadInProgress" from local storage ([f21c2d1](https://github.com/aws-amplify/amplify-js/commit/f21c2d146fcabacf0584918b286ec68a644bec20))

## [5.1.2](https://github.com/aws-amplify/amplify-js/compare/amazon-cognito-identity-js@5.1.1...amazon-cognito-identity-js@5.1.2) (2021-09-24)

**Note:** Version bump only for package amazon-cognito-identity-js

## [5.1.1](https://github.com/aws-amplify/amplify-js/compare/amazon-cognito-identity-js@5.1.0...amazon-cognito-identity-js@5.1.1) (2021-09-17)

### Bug Fixes

- **amazon-cognito-identity-js:** Fix UserPoolId validation ReDoS ([#8915](https://github.com/aws-amplify/amplify-js/issues/8915)) ([f405f0e](https://github.com/aws-amplify/amplify-js/commit/f405f0ec6f0766bf66bc77d1450579c61f587979))

# [5.1.0](https://github.com/aws-amplify/amplify-js/compare/amazon-cognito-identity-js@5.0.6...amazon-cognito-identity-js@5.1.0) (2021-08-19)

### Features

- **@aws-amplify/auth:** Add a 'SUCCESS' response on successful call to forgotPasswordSubmit and verifyUserAttributes([#8744](https://github.com/aws-amplify/amplify-js/issues/8744)) ([1bd6c35](https://github.com/aws-amplify/amplify-js/commit/1bd6c35c115321d77f48a3954942dd57d7cf9056))

## [5.0.6](https://github.com/aws-amplify/amplify-js/compare/amazon-cognito-identity-js@5.0.5...amazon-cognito-identity-js@5.0.6) (2021-07-22)

### Bug Fixes

- **amazon-cognito-identity-is, @aws-amplify/auth:** upgrade crypto-js to 4.1.1 to fix bundle size issue ([#8626](https://github.com/aws-amplify/amplify-js/issues/8626)) ([b16f8e7](https://github.com/aws-amplify/amplify-js/commit/b16f8e7801790a59a8ad0c40b598f4962aada60e))
- **amazon-cognito-identity-js:** Adding Session param for DEVICE_SRP_AUTH and user agent fix ([#8591](https://github.com/aws-amplify/amplify-js/issues/8591)) ([190bd50](https://github.com/aws-amplify/amplify-js/commit/190bd501236a59b16318802b51a0494f7374d299))

## [5.0.5](https://github.com/aws-amplify/amplify-js/compare/amazon-cognito-identity-js@5.0.4...amazon-cognito-identity-js@5.0.5) (2021-07-16)

### Bug Fixes

- **amazon-cognito-identity-js:** refresh cached user after deleting attributes ([#8578](https://github.com/aws-amplify/amplify-js/issues/8578)) ([bf78611](https://github.com/aws-amplify/amplify-js/commit/bf78611b8e4dbc4c8b774516c765cb6d1add8ea7))

## [5.0.4](https://github.com/aws-amplify/amplify-js/compare/amazon-cognito-identity-js@5.0.3...amazon-cognito-identity-js@5.0.4) (2021-07-08)

### Bug Fixes

- **amazon-cognito-identity-js:** rewrite retry as promise based method ([#8524](https://github.com/aws-amplify/amplify-js/issues/8524)) ([a84978d](https://github.com/aws-amplify/amplify-js/commit/a84978d61960907957699882bc16724287dd522f))

## [5.0.3](https://github.com/aws-amplify/amplify-js/compare/amazon-cognito-identity-js@5.0.2...amazon-cognito-identity-js@5.0.3) (2021-06-10)

### Bug Fixes

- remove RN-specific peerDeps to correctly hoist core in npm@7 ([#8368](https://github.com/aws-amplify/amplify-js/issues/8368)) ([9cc5218](https://github.com/aws-amplify/amplify-js/commit/9cc52186e687d6782b41581959380bd7f534e5d2))

## [5.0.2](https://github.com/aws-amplify/amplify-js/compare/amazon-cognito-identity-js@5.0.1...amazon-cognito-identity-js@5.0.2) (2021-05-26)

**Note:** Version bump only for package amazon-cognito-identity-js

## [5.0.1](https://github.com/aws-amplify/amplify-js/compare/amazon-cognito-identity-js@5.0.0...amazon-cognito-identity-js@5.0.1) (2021-05-14)

**Note:** Version bump only for package amazon-cognito-identity-js

# [5.0.0](https://github.com/aws-amplify/amplify-js/compare/amazon-cognito-identity-js@4.6.1...amazon-cognito-identity-js@5.0.0) (2021-05-11)

- chore!: Upgrade to @react-native-async-storage/async-storage (#8250) ([1de4853](https://github.com/aws-amplify/amplify-js/commit/1de48531b68e3c53c3b7dbf4487da4578cb79888)), closes [#8250](https://github.com/aws-amplify/amplify-js/issues/8250)

### BREAKING CHANGES

- Upgrade from React Native AsyncStorage to @react-native-async-storage/async-storage

Co-authored-by: Ashish Nanda <ashish.nanda.5591@gmail.com>
Co-authored-by: Ivan Artemiev <29709626+iartemiev@users.noreply.github.com>

## [4.6.1](https://github.com/aws-amplify/amplify-js/compare/amazon-cognito-identity-js@4.6.0...amazon-cognito-identity-js@4.6.1) (2021-05-06)

### Bug Fixes

- **amazon-cognito-identity-js:** resolve missing getRandomBase64 implementation in expo >= 41 ([#8162](https://github.com/aws-amplify/amplify-js/issues/8162)) ([2d4052d](https://github.com/aws-amplify/amplify-js/commit/2d4052da555709fe0f759fecb2df4b4b9604461c))

# [4.6.0](https://github.com/aws-amplify/amplify-js/compare/amazon-cognito-identity-js@4.5.14...amazon-cognito-identity-js@4.6.0) (2021-03-18)

### Features

- Improve Next.js/CRA/Angular bundle sizes ([#7842](https://github.com/aws-amplify/amplify-js/issues/7842)) ([2e0dc61](https://github.com/aws-amplify/amplify-js/commit/2e0dc61fa9e4399351a59a7e8fe801027b6587d5))

## [4.5.14](https://github.com/aws-amplify/amplify-js/compare/amazon-cognito-identity-js@4.5.13...amazon-cognito-identity-js@4.5.14) (2021-03-12)

### Bug Fixes

- **amazon-cognito-identity-js:** update podspec dep ([#7873](https://github.com/aws-amplify/amplify-js/issues/7873)) ([6c9c4ef](https://github.com/aws-amplify/amplify-js/commit/6c9c4efde6d4da48f5add075ef2f4c3d112c7dea))
- **amazon-cognito-identity-js:** update sendMFACode callback type ([#7801](https://github.com/aws-amplify/amplify-js/issues/7801)) ([5cce7e6](https://github.com/aws-amplify/amplify-js/commit/5cce7e66ddc5de1ffa190710a7d5847851ec83e5))

## [4.5.13](https://github.com/aws-amplify/amplify-js/compare/amazon-cognito-identity-js@4.5.12...amazon-cognito-identity-js@4.5.13) (2021-03-08)

### Bug Fixes

- **amazon-cognito-identity-js:** set userDataKey with updated username ([#7903](https://github.com/aws-amplify/amplify-js/issues/7903)) ([8d30ce5](https://github.com/aws-amplify/amplify-js/commit/8d30ce5633fd19acadf621cedc338a4e7504481b))

## [4.5.12](https://github.com/aws-amplify/amplify-js/compare/amazon-cognito-identity-js@4.5.11...amazon-cognito-identity-js@4.5.12) (2021-02-25)

**Note:** Version bump only for package amazon-cognito-identity-js

## [4.5.11](https://github.com/aws-amplify/amplify-js/compare/amazon-cognito-identity-js@4.5.10...amazon-cognito-identity-js@4.5.11) (2021-02-18)

### Bug Fixes

- AuthenticationHelper - Handle negative BigIntegers ([#7618](https://github.com/aws-amplify/amplify-js/issues/7618)) ([104b278](https://github.com/aws-amplify/amplify-js/commit/104b2783cbf0f94b78f543c94956b98e3611aa4f))

## [4.5.10](https://github.com/aws-amplify/amplify-js/compare/amazon-cognito-identity-js@4.5.9...amazon-cognito-identity-js@4.5.10) (2021-02-03)

### Bug Fixes

- **amazon-cognito-identity-js:** add default value for options ([#7664](https://github.com/aws-amplify/amplify-js/issues/7664)) ([4ecf425](https://github.com/aws-amplify/amplify-js/commit/4ecf4256e54db42e49c55db8ca14f7dd2b206af1))

## [4.5.9](https://github.com/aws-amplify/amplify-js/compare/amazon-cognito-identity-js@4.5.8...amazon-cognito-identity-js@4.5.9) (2021-02-01)

### Bug Fixes

- **amazon-cognito-identity-js:** make options optional ([#7654](https://github.com/aws-amplify/amplify-js/issues/7654)) ([08277af](https://github.com/aws-amplify/amplify-js/commit/08277aff76688c091e05c593cb802f90a9c771a6))

## [4.5.8](https://github.com/aws-amplify/amplify-js/compare/amazon-cognito-identity-js@4.5.7...amazon-cognito-identity-js@4.5.8) (2021-01-29)

### Bug Fixes

- **@aws-amplify/auth, amazon-cognito-identity-js:** Include clientMetadata for token refresh ([#7633](https://github.com/aws-amplify/amplify-js/issues/7633)) ([3a9efb0](https://github.com/aws-amplify/amplify-js/commit/3a9efb0b596cf2795d7e1424f011f8e59058ecfb))
- **amazon-cognito-identity-js:** add .web.js version for cryptoSecureRandomInt ([#7521](https://github.com/aws-amplify/amplify-js/issues/7521)) ([13b7ccd](https://github.com/aws-amplify/amplify-js/commit/13b7ccd49b3314580b597dc177f400c1b68e930f))

## [4.5.7](https://github.com/aws-amplify/amplify-js/compare/amazon-cognito-identity-js@4.5.6...amazon-cognito-identity-js@4.5.7) (2021-01-07)

**Note:** Version bump only for package amazon-cognito-identity-js

## [4.5.6](https://github.com/aws-amplify/amplify-js/compare/amazon-cognito-identity-js@4.5.5...amazon-cognito-identity-js@4.5.6) (2020-12-17)

**Note:** Version bump only for package amazon-cognito-identity-js

## [4.5.5](https://github.com/aws-amplify/amplify-js/compare/amazon-cognito-identity-js@4.5.4...amazon-cognito-identity-js@4.5.5) (2020-11-20)

**Note:** Version bump only for package amazon-cognito-identity-js

## [4.5.4](https://github.com/aws-amplify/amplify-js/compare/amazon-cognito-identity-js@4.5.3...amazon-cognito-identity-js@4.5.4) (2020-11-13)

### Bug Fixes

- **amazon-cognito-identity-js:** set crypto for Node ([#7136](https://github.com/aws-amplify/amplify-js/issues/7136)) ([5173a99](https://github.com/aws-amplify/amplify-js/commit/5173a9911096627ce1b45067808af249668b260b))

## [4.5.3](https://github.com/aws-amplify/amplify-js/compare/amazon-cognito-identity-js@4.5.2...amazon-cognito-identity-js@4.5.3) (2020-11-03)

**Note:** Version bump only for package amazon-cognito-identity-js

## [4.5.2](https://github.com/aws-amplify/amplify-js/compare/amazon-cognito-identity-js@4.5.1...amazon-cognito-identity-js@4.5.2) (2020-10-31)

### Bug Fixes

- **amazon-cognito-identity-js:** update random implementation ([#7090](https://github.com/aws-amplify/amplify-js/issues/7090)) ([7048453](https://github.com/aws-amplify/amplify-js/commit/70484532da8a9953384b00b223b2b3ba0c0e845e))

## [4.5.1](https://github.com/aws-amplify/amplify-js/compare/amazon-cognito-identity-js@4.5.0...amazon-cognito-identity-js@4.5.1) (2020-10-29)

**Note:** Version bump only for package amazon-cognito-identity-js

# [4.5.0](https://github.com/aws-amplify/amplify-js/compare/amazon-cognito-identity-js@4.4.0...amazon-cognito-identity-js@4.5.0) (2020-10-15)

### Features

- Patch JKBigInteger to use NSSecureCoding ([#6843](https://github.com/aws-amplify/amplify-js/issues/6843)) ([53be43d](https://github.com/aws-amplify/amplify-js/commit/53be43d7a0049e04a47e7fece5dcd726c7a414fe))

# [4.4.0](https://github.com/aws-amplify/amplify-js/compare/amazon-cognito-identity-js@4.3.5...amazon-cognito-identity-js@4.4.0) (2020-09-03)

### Bug Fixes

- **amazon-cognito-identity-js:** add "none" to sameSite possible values ([#6682](https://github.com/aws-amplify/amplify-js/issues/6682)) ([cffb932](https://github.com/aws-amplify/amplify-js/commit/cffb932dfd2c7bb1ca246adc451cc7f6dea2a1f6))

### Features

- **SSR:** withSSRContext ([#6146](https://github.com/aws-amplify/amplify-js/issues/6146)) ([1cb1afd](https://github.com/aws-amplify/amplify-js/commit/1cb1afd1e56135908dceb2ef6403f0b3e78067fe))

## [4.3.5](https://github.com/aws-amplify/amplify-js/compare/amazon-cognito-identity-js@4.3.4...amazon-cognito-identity-js@4.3.5) (2020-09-01)

### Bug Fixes

- **@aws-amplify/auth:** incorrect return type for Auth.resendSignUp ([#5112](https://github.com/aws-amplify/amplify-js/issues/5112)) ([9164b37](https://github.com/aws-amplify/amplify-js/commit/9164b37cb7669c9dd08927dde58dccbefad25194))
- **amazon-cognito-identity-js:** fix parameters in sendMFASelectionAnswer ([#6418](https://github.com/aws-amplify/amplify-js/issues/6418)) ([794c1da](https://github.com/aws-amplify/amplify-js/commit/794c1da170cd98d3def4651751b851f28810bb6e))

## [4.3.4](https://github.com/aws-amplify/amplify-js/compare/amazon-cognito-identity-js@4.3.3...amazon-cognito-identity-js@4.3.4) (2020-08-19)

**Note:** Version bump only for package amazon-cognito-identity-js

## [4.3.3](https://github.com/aws-amplify/amplify-js/compare/amazon-cognito-identity-js@4.3.2...amazon-cognito-identity-js@4.3.3) (2020-07-07)

**Note:** Version bump only for package amazon-cognito-identity-js

## [4.3.2](https://github.com/aws-amplify/amplify-js/compare/amazon-cognito-identity-js@4.3.1...amazon-cognito-identity-js@4.3.2) (2020-06-18)

### Bug Fixes

- **amazon-cognito-identity-js:** allow storage to return missing items ([#5877](https://github.com/aws-amplify/amplify-js/issues/5877)) ([1fd8336](https://github.com/aws-amplify/amplify-js/commit/1fd83360138be0359505c25bce2890f959c1000e))

## [4.3.1](https://github.com/aws-amplify/amplify-js/compare/amazon-cognito-identity-js@4.3.0...amazon-cognito-identity-js@4.3.1) (2020-06-03)

**Note:** Version bump only for package amazon-cognito-identity-js

# [4.3.0](https://github.com/aws-amplify/amplify-js/compare/amazon-cognito-identity-js@4.2.4...amazon-cognito-identity-js@4.3.0) (2020-05-22)

### Features

- **amazon-cognito-identity-js:** Add support for fetch options ([#3017](https://github.com/aws-amplify/amplify-js/issues/3017)) ([45a649d](https://github.com/aws-amplify/amplify-js/commit/45a649d6e9b80eeef4cc7badcbb86ece10686996))

## [4.2.4](https://github.com/aws-amplify/amplify-js/compare/amazon-cognito-identity-js@4.2.3...amazon-cognito-identity-js@4.2.4) (2020-05-14)

### Bug Fixes

- **amazon-cognito-identity-js:** Not refresh token immediately after sign in ([#5747](https://github.com/aws-amplify/amplify-js/issues/5747)) ([466a14d](https://github.com/aws-amplify/amplify-js/commit/466a14d958a07519d5a59cf330771f744c8db8f6)), closes [#5397](https://github.com/aws-amplify/amplify-js/issues/5397)

## [4.2.3](https://github.com/aws-amplify/amplify-js/compare/amazon-cognito-identity-js@4.2.2...amazon-cognito-identity-js@4.2.3) (2020-04-30)

### Bug Fixes

- update declaration for CognitoUserPool.signup and add the clientMetadata parameter. ([#5005](https://github.com/aws-amplify/amplify-js/issues/5005)) ([35e9e0d](https://github.com/aws-amplify/amplify-js/commit/35e9e0d89b35a5738481b2e2a6b0d6d0d0bf54fb))
- **amazon-cognito-identity-js:** Added client metadata so signup ([#5542](https://github.com/aws-amplify/amplify-js/issues/5542)) ([7bfcb25](https://github.com/aws-amplify/amplify-js/commit/7bfcb2520e90ce3589e37a57315ab042fa847878)), closes [#5541](https://github.com/aws-amplify/amplify-js/issues/5541)

## [4.2.2](https://github.com/aws-amplify/amplify-js/compare/amazon-cognito-identity-js@4.2.1...amazon-cognito-identity-js@4.2.2) (2020-04-24)

### Bug Fixes

- **auth:** refresh user after updating attributes ([bfc5f9f](https://github.com/aws-amplify/amplify-js/commit/bfc5f9fb312510d8f8202411e9e367b6eadab2d7))

## [4.2.1](https://github.com/aws-amplify/amplify-js/compare/amazon-cognito-identity-js@4.2.0...amazon-cognito-identity-js@4.2.1) (2020-04-07)

**Note:** Version bump only for package amazon-cognito-identity-js

# [4.2.0](https://github.com/aws-amplify/amplify-js/compare/amazon-cognito-identity-js@4.1.0...amazon-cognito-identity-js@4.2.0) (2020-04-02)

### Features

- **@aws-amplify/ui-components:** User agent tracking for UI component packages ([#4804](https://github.com/aws-amplify/amplify-js/issues/4804)) ([15a0a2f](https://github.com/aws-amplify/amplify-js/commit/15a0a2fadeb96543721a6733faeb509efc26e1e2))

# [4.1.0](https://github.com/aws-amplify/amplify-js/compare/amazon-cognito-identity-js@3.2.7...amazon-cognito-identity-js@4.1.0) (2020-03-31)

### Bug Fixes

- **amazon-cognito-identity-js:** linting config ([#4097](https://github.com/aws-amplify/amplify-js/issues/4097)) ([7674f96](https://github.com/aws-amplify/amplify-js/commit/7674f96f8a99bcc7b73ee4eb1c2a84db7de28ae3))
- **amazon-cognito-identity-js:** linting config ([#4097](https://github.com/aws-amplify/amplify-js/issues/4097)) ([173baf5](https://github.com/aws-amplify/amplify-js/commit/173baf5bd14c0e52e61e35ea44b8d3dc4c703c4c))

### Features

- **@aws-amplify/core:** [Delivers [#168673137](https://github.com/aws-amplify/amplify-js/issues/168673137)] Migrate core category to aws sdk V3 ([#4077](https://github.com/aws-amplify/amplify-js/issues/4077)) ([beb73a4](https://github.com/aws-amplify/amplify-js/commit/beb73a4b1c051654750f5bdc3b20cde3a3aba37d))

### Reverts

- Revert "Publish" ([1319d31](https://github.com/aws-amplify/amplify-js/commit/1319d319b69717e76660fbfa6f1a845195c6d635))

## [3.2.7](https://github.com/aws-amplify/amplify-js/compare/amazon-cognito-identity-js@3.2.6...amazon-cognito-identity-js@3.2.7) (2020-03-30)

**Note:** Version bump only for package amazon-cognito-identity-js

## [3.2.6](https://github.com/aws-amplify/amplify-js/compare/amazon-cognito-identity-js@3.2.5...amazon-cognito-identity-js@3.2.6) (2020-03-25)

**Note:** Version bump only for package amazon-cognito-identity-js

## [3.2.5](https://github.com/aws-amplify/amplify-js/compare/amazon-cognito-identity-js@3.2.4...amazon-cognito-identity-js@3.2.5) (2020-02-28)

**Note:** Version bump only for package amazon-cognito-identity-js

## [3.2.4](https://github.com/aws-amplify/amplify-js/compare/amazon-cognito-identity-js@3.2.2...amazon-cognito-identity-js@3.2.4) (2020-02-07)

**Note:** Version bump only for package amazon-cognito-identity-js

## [3.2.2](https://github.com/aws-amplify/amplify-js/compare/amazon-cognito-identity-js@3.2.1...amazon-cognito-identity-js@3.2.2) (2020-01-10)

### Bug Fixes

- **amazon-cognito-identity-js:** Local & CI tests ([#4616](https://github.com/aws-amplify/amplify-js/issues/4616)) ([bc8ae26](https://github.com/aws-amplify/amplify-js/commit/bc8ae262040d7961a28513a25013c2d306908874))

## [3.2.1](https://github.com/aws-amplify/amplify-js/compare/amazon-cognito-identity-js@3.2.0...amazon-cognito-identity-js@3.2.1) (2019-12-18)

**Note:** Version bump only for package amazon-cognito-identity-js

# [3.2.0](https://github.com/aws-amplify/amplify-js/compare/amazon-cognito-identity-js@3.1.3...amazon-cognito-identity-js@3.2.0) (2019-10-29)

### Features

- **@aws-amplify/auth:** clientMetadata ([#4149](https://github.com/aws-amplify/amplify-js/issues/4149)) ([ac34816](https://github.com/aws-amplify/amplify-js/commit/ac34816df326331cfe04474fdf35790c52f4a1d3))

## [3.1.3](https://github.com/aws-amplify/amplify-js/compare/amazon-cognito-identity-js@3.1.2...amazon-cognito-identity-js@3.1.3) (2019-10-23)

**Note:** Version bump only for package amazon-cognito-identity-js

## [3.1.2](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@3.1.0...amazon-cognito-identity-js@3.1.2) (2019-10-10)

**Note:** Version bump only for package amazon-cognito-identity-js

# [3.1.0](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@3.0.15...amazon-cognito-identity-js@3.1.0) (2019-10-10)

### Bug Fixes

- **amazon-cognito-identity-js:** linting config ([#4097](https://github.com/aws/aws-amplify/issues/4097)) ([82b1dd8](https://github.com/aws/aws-amplify/commit/82b1dd8acc9b1dc165707945d585ce282fce60ba))

### Features

- Added Prettier formatting ([4dfd9aa](https://github.com/aws/aws-amplify/commit/4dfd9aa9ab900307c9d17c68448a6ca4aa08fd5a))

## [3.0.15](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@3.0.14...amazon-cognito-identity-js@3.0.15) (2019-07-30)

**Note:** Version bump only for package amazon-cognito-identity-js

## [3.0.14](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@3.0.13...amazon-cognito-identity-js@3.0.14) (2019-07-18)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="3.0.13"></a>

## [3.0.13](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@3.0.13-unstable.0...amazon-cognito-identity-js@3.0.13) (2019-06-17)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="3.0.13-unstable.0"></a>

## [3.0.13-unstable.0](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@3.0.12...amazon-cognito-identity-js@3.0.13-unstable.0) (2019-05-28)

### Bug Fixes

- **@amazon-cognito-identity-js:** Adds sendMFASelectionAnswer to types ([6c32ef3](https://github.com/aws/aws-amplify/commit/6c32ef3))

<a name="3.0.12"></a>

## [3.0.12](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@3.0.12-unstable.3...amazon-cognito-identity-js@3.0.12) (2019-05-06)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="3.0.12-unstable.3"></a>

## [3.0.12-unstable.3](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@3.0.12-unstable.2...amazon-cognito-identity-js@3.0.12-unstable.3) (2019-04-26)

### Features

- **@aws-amplify/amazon-cognito-identity-js:** for signUp, returns CodeDeliveryDetails from response ([7728e11](https://github.com/aws/aws-amplify/commit/7728e11))

<a name="3.0.12-unstable.2"></a>

## [3.0.12-unstable.2](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@3.0.12-unstable.1...amazon-cognito-identity-js@3.0.12-unstable.2) (2019-04-16)

### Bug Fixes

- **@aws-amplify/auth:** throw error when passing empty object to storage or cookieStorage in configuration ([816a827](https://github.com/aws/aws-amplify/commit/816a827))

<a name="3.0.12-unstable.1"></a>

## [3.0.12-unstable.1](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@3.0.12-unstable.0...amazon-cognito-identity-js@3.0.12-unstable.1) (2019-04-12)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="3.0.12-unstable.0"></a>

## [3.0.12-unstable.0](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@3.0.11...amazon-cognito-identity-js@3.0.12-unstable.0) (2019-04-12)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="3.0.11"></a>

## [3.0.11](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@3.0.11-unstable.0...amazon-cognito-identity-js@3.0.11) (2019-04-09)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="3.0.11-unstable.0"></a>

## [3.0.11-unstable.0](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@3.0.10...amazon-cognito-identity-js@3.0.11-unstable.0) (2019-04-07)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="3.0.10"></a>

## [3.0.10](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@3.0.10-unstable.0...amazon-cognito-identity-js@3.0.10) (2019-03-28)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="3.0.10-unstable.0"></a>

## [3.0.10-unstable.0](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@3.0.9...amazon-cognito-identity-js@3.0.10-unstable.0) (2019-03-18)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="3.0.9"></a>

## [3.0.9](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@3.0.9-unstable.0...amazon-cognito-identity-js@3.0.9) (2019-03-06)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="3.0.9-unstable.0"></a>

## [3.0.9-unstable.0](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@3.0.8...amazon-cognito-identity-js@3.0.9-unstable.0) (2019-03-04)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="3.0.8"></a>

## [3.0.8](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@3.0.8-unstable.4...amazon-cognito-identity-js@3.0.8) (2019-03-04)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="3.0.8-unstable.4"></a>

## [3.0.8-unstable.4](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@3.0.8-unstable.3...amazon-cognito-identity-js@3.0.8-unstable.4) (2019-03-04)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="3.0.8-unstable.3"></a>

## [3.0.8-unstable.3](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@3.0.8-unstable.2...amazon-cognito-identity-js@3.0.8-unstable.3) (2019-03-01)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="3.0.8-unstable.2"></a>

## [3.0.8-unstable.2](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@3.0.8-unstable.1...amazon-cognito-identity-js@3.0.8-unstable.2) (2019-02-27)

### Bug Fixes

- **build:** Prevent tree-shaking of crypto-js/lib-typedarrays ([#2718](https://github.com/aws/aws-amplify/issues/2718)) ([3134a64](https://github.com/aws/aws-amplify/commit/3134a64)), closes [#1181](https://github.com/aws/aws-amplify/issues/1181)

<a name="3.0.8-unstable.1"></a>

## [3.0.8-unstable.1](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@3.0.8-unstable.0...amazon-cognito-identity-js@3.0.8-unstable.1) (2019-01-21)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="3.0.8-unstable.0"></a>

## [3.0.8-unstable.0](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@3.0.7...amazon-cognito-identity-js@3.0.8-unstable.0) (2019-01-18)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="3.0.7"></a>

## [3.0.7](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@3.0.6...amazon-cognito-identity-js@3.0.7) (2019-01-10)

### Bug Fixes

- **amazon-cognito-identity-js:** return error instead of undefined ([19c3c4e](https://github.com/aws/aws-amplify/commit/19c3c4e))
- **amazon-cognito-identity-js:** Update Android Gradle Config ([a08f100](https://github.com/aws/aws-amplify/commit/a08f100))

<a name="3.0.6"></a>

## [3.0.6](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@3.0.6-unstable.2...amazon-cognito-identity-js@3.0.6) (2018-12-13)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="3.0.6-unstable.2"></a>

## [3.0.6-unstable.2](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@3.0.6-unstable.1...amazon-cognito-identity-js@3.0.6-unstable.2) (2018-12-13)

### Features

- **@aws-amplify/auth:** add the option to pass validation data when signing in ([13093e9](https://github.com/aws/aws-amplify/commit/13093e9))

<a name="3.0.6-unstable.1"></a>

## [3.0.6-unstable.1](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@3.0.6-unstable.0...amazon-cognito-identity-js@3.0.6-unstable.1) (2018-12-13)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="3.0.6-unstable.0"></a>

## [3.0.6-unstable.0](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@3.0.5...amazon-cognito-identity-js@3.0.6-unstable.0) (2018-12-07)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="3.0.5"></a>

## [3.0.5](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@3.0.4...amazon-cognito-identity-js@3.0.5) (2018-12-07)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="3.0.5-unstable.0"></a>

## [3.0.5-unstable.0](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@3.0.4...amazon-cognito-identity-js@3.0.5-unstable.0) (2018-12-07)

### Features

- **amazon-cognito-identity-js:** cache the user data ([f4dd225](https://github.com/aws/aws-amplify/commit/f4dd225))

<a name="3.0.4"></a>

## [3.0.4](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@3.0.4-unstable.5...amazon-cognito-identity-js@3.0.4) (2018-12-03)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="3.0.4-unstable.5"></a>

## [3.0.4-unstable.5](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@3.0.4-unstable.4...amazon-cognito-identity-js@3.0.4-unstable.5) (2018-11-19)

### Bug Fixes

- **amazon-cognito-identity-js:** Added missing type declarations for setting MFA preferences and token payloads ([080630d](https://github.com/aws/aws-amplify/commit/080630d))

<a name="3.0.4-unstable.4"></a>

## [3.0.4-unstable.4](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@3.0.4-unstable.3...amazon-cognito-identity-js@3.0.4-unstable.4) (2018-11-19)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="3.0.4-unstable.3"></a>

## [3.0.4-unstable.3](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@3.0.4-unstable.2...amazon-cognito-identity-js@3.0.4-unstable.3) (2018-11-17)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="3.0.4-unstable.2"></a>

## [3.0.4-unstable.2](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@3.0.4-unstable.1...amazon-cognito-identity-js@3.0.4-unstable.2) (2018-11-16)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="3.0.4-unstable.1"></a>

## [3.0.4-unstable.1](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@3.0.4-unstable.0...amazon-cognito-identity-js@3.0.4-unstable.1) (2018-11-16)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="3.0.4-unstable.0"></a>

## [3.0.4-unstable.0](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@3.0.3...amazon-cognito-identity-js@3.0.4-unstable.0) (2018-11-13)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="3.0.3"></a>

## [3.0.3](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@3.0.3-unstable.0...amazon-cognito-identity-js@3.0.3) (2018-10-17)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="3.0.3-unstable.0"></a>

## [3.0.3-unstable.0](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@3.0.2-unstable.0...amazon-cognito-identity-js@3.0.3-unstable.0) (2018-10-05)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="3.0.2"></a>

## [3.0.2](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@3.0.2-unstable.0...amazon-cognito-identity-js@3.0.2) (2018-10-04)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="3.0.2-unstable.0"></a>

## [3.0.2-unstable.0](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.31-unstable.2...amazon-cognito-identity-js@3.0.2-unstable.0) (2018-10-03)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="3.0.1"></a>

## [3.0.1](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.31-unstable.2...amazon-cognito-identity-js@3.0.1) (2018-10-03)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.31-unstable.2"></a>

## [2.0.31-unstable.2](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.31-unstable.1...amazon-cognito-identity-js@2.0.31-unstable.2) (2018-09-27)

### Bug Fixes

- **amazon-cognito-identity-js:** replace crypto-browserify with crypto-js ([4d2409a](https://github.com/aws/aws-amplify/commit/4d2409a))

<a name="2.0.31-unstable.1"></a>

## [2.0.31-unstable.1](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.31-unstable.0...amazon-cognito-identity-js@2.0.31-unstable.1) (2018-09-27)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.31-unstable.0"></a>

## [2.0.31-unstable.0](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.30...amazon-cognito-identity-js@2.0.31-unstable.0) (2018-09-27)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.30"></a>

## [2.0.30](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.30-unstable.9...amazon-cognito-identity-js@2.0.30) (2018-09-27)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.30-unstable.9"></a>

## [2.0.30-unstable.9](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.30-unstable.8...amazon-cognito-identity-js@2.0.30-unstable.9) (2018-09-26)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.30-unstable.8"></a>

## [2.0.30-unstable.8](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.30-unstable.7...amazon-cognito-identity-js@2.0.30-unstable.8) (2018-09-26)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.30-unstable.7"></a>

## [2.0.30-unstable.7](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.30-unstable.6...amazon-cognito-identity-js@2.0.30-unstable.7) (2018-09-26)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.30-unstable.6"></a>

## [2.0.30-unstable.6](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.30-unstable.4...amazon-cognito-identity-js@2.0.30-unstable.6) (2018-09-26)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.30-unstable.5"></a>

## [2.0.30-unstable.5](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.30-unstable.4...amazon-cognito-identity-js@2.0.30-unstable.5) (2018-09-25)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.30-unstable.4"></a>

## [2.0.30-unstable.4](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.30-unstable.3...amazon-cognito-identity-js@2.0.30-unstable.4) (2018-09-25)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.30-unstable.3"></a>

## [2.0.30-unstable.3](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.30-unstable.2...amazon-cognito-identity-js@2.0.30-unstable.3) (2018-09-24)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.30-unstable.2"></a>

## [2.0.30-unstable.2](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.30-unstable.1...amazon-cognito-identity-js@2.0.30-unstable.2) (2018-09-22)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.30-unstable.1"></a>

## [2.0.30-unstable.1](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.30-unstable.0...amazon-cognito-identity-js@2.0.30-unstable.1) (2018-09-22)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.30-unstable.0"></a>

## [2.0.30-unstable.0](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.29...amazon-cognito-identity-js@2.0.30-unstable.0) (2018-09-22)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.29"></a>

## [2.0.29](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.29-unstable.0...amazon-cognito-identity-js@2.0.29) (2018-09-21)

### Bug Fixes

- **amazon-cognito-identity-js:** clean clockDrift item when signing out ([f07d800](https://github.com/aws/aws-amplify/commit/f07d800))

<a name="2.0.29-unstable.0"></a>

## [2.0.29-unstable.0](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.28-unstable.3...amazon-cognito-identity-js@2.0.29-unstable.0) (2018-09-21)

### Bug Fixes

- bumping version for deploying on unstable tag ([#1706](https://github.com/aws/aws-amplify/issues/1706)) ([b5d6468](https://github.com/aws/aws-amplify/commit/b5d6468))

<a name="2.0.28"></a>

## [2.0.28](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.27...amazon-cognito-identity-js@2.0.28) (2018-09-21)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.28-unstable.3"></a>

## [2.0.28-unstable.3](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.28-unstable.2...amazon-cognito-identity-js@2.0.28-unstable.3) (2018-09-20)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.28-unstable.2"></a>

## [2.0.28-unstable.2](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.28-unstable.1...amazon-cognito-identity-js@2.0.28-unstable.2) (2018-09-20)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.28-unstable.1"></a>

## [2.0.28-unstable.1](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.28-unstable.0...amazon-cognito-identity-js@2.0.28-unstable.1) (2018-09-17)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.28-unstable.0"></a>

## [2.0.28-unstable.0](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.27...amazon-cognito-identity-js@2.0.28-unstable.0) (2018-09-17)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.27"></a>

## [2.0.27](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.26...amazon-cognito-identity-js@2.0.27) (2018-09-17)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.26"></a>

## [2.0.26](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.25...amazon-cognito-identity-js@2.0.26) (2018-09-12)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.25"></a>

## [2.0.25](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.25-unstable.0...amazon-cognito-identity-js@2.0.25) (2018-09-09)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.25-unstable.0"></a>

## [2.0.25-unstable.0](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.24...amazon-cognito-identity-js@2.0.25-unstable.0) (2018-09-09)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.24"></a>

## [2.0.24](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.24-unstable.11...amazon-cognito-identity-js@2.0.24) (2018-09-09)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.24-unstable.11"></a>

## [2.0.24-unstable.11](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.24-unstable.10...amazon-cognito-identity-js@2.0.24-unstable.11) (2018-09-08)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.24-unstable.10"></a>

## [2.0.24-unstable.10](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.24-unstable.9...amazon-cognito-identity-js@2.0.24-unstable.10) (2018-09-07)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.24-unstable.9"></a>

## [2.0.24-unstable.9](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.24-unstable.8...amazon-cognito-identity-js@2.0.24-unstable.9) (2018-09-07)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.24-unstable.8"></a>

## [2.0.24-unstable.8](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.24-unstable.7...amazon-cognito-identity-js@2.0.24-unstable.8) (2018-09-07)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.24-unstable.7"></a>

## [2.0.24-unstable.7](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.24-unstable.6...amazon-cognito-identity-js@2.0.24-unstable.7) (2018-09-06)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.24-unstable.6"></a>

## [2.0.24-unstable.6](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.24-unstable.5...amazon-cognito-identity-js@2.0.24-unstable.6) (2018-09-06)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.24-unstable.5"></a>

## [2.0.24-unstable.5](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.24-unstable.4...amazon-cognito-identity-js@2.0.24-unstable.5) (2018-09-05)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.24-unstable.4"></a>

## [2.0.24-unstable.4](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.24-unstable.3...amazon-cognito-identity-js@2.0.24-unstable.4) (2018-09-05)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.24-unstable.3"></a>

## [2.0.24-unstable.3](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.23...amazon-cognito-identity-js@2.0.24-unstable.3) (2018-08-31)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.24-unstable.2"></a>

## [2.0.24-unstable.2](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.23...amazon-cognito-identity-js@2.0.24-unstable.2) (2018-08-30)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.24-unstable.1"></a>

## [2.0.24-unstable.1](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.23...amazon-cognito-identity-js@2.0.24-unstable.1) (2018-08-30)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.23"></a>

## [2.0.23](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.22-unstable.26...amazon-cognito-identity-js@2.0.23) (2018-08-28)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.22-unstable.26"></a>

## [2.0.22-unstable.26](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.22-unstable.25...amazon-cognito-identity-js@2.0.22-unstable.26) (2018-08-28)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.22-unstable.25"></a>

## [2.0.22-unstable.25](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.22-unstable.24...amazon-cognito-identity-js@2.0.22-unstable.25) (2018-08-27)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.22-unstable.24"></a>

## [2.0.22-unstable.24](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.22-unstable.23...amazon-cognito-identity-js@2.0.22-unstable.24) (2018-08-27)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.22-unstable.23"></a>

## [2.0.22-unstable.23](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.22-unstable.21...amazon-cognito-identity-js@2.0.22-unstable.23) (2018-08-27)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.22-unstable.22"></a>

## [2.0.22-unstable.22](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.22-unstable.21...amazon-cognito-identity-js@2.0.22-unstable.22) (2018-08-25)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.22-unstable.21"></a>

## [2.0.22-unstable.21](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.22-unstable.20...amazon-cognito-identity-js@2.0.22-unstable.21) (2018-08-24)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.22-unstable.20"></a>

## [2.0.22-unstable.20](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.22-unstable.19...amazon-cognito-identity-js@2.0.22-unstable.20) (2018-08-24)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.22-unstable.19"></a>

## [2.0.22-unstable.19](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.22-unstable.17...amazon-cognito-identity-js@2.0.22-unstable.19) (2018-08-24)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.22-unstable.18"></a>

## [2.0.22-unstable.18](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.22-unstable.17...amazon-cognito-identity-js@2.0.22-unstable.18) (2018-08-24)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.22-unstable.17"></a>

## [2.0.22-unstable.17](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.22-unstable.15...amazon-cognito-identity-js@2.0.22-unstable.17) (2018-08-24)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.22-unstable.16"></a>

## [2.0.22-unstable.16](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.22-unstable.15...amazon-cognito-identity-js@2.0.22-unstable.16) (2018-08-24)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.22-unstable.15"></a>

## [2.0.22-unstable.15](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.22-unstable.14...amazon-cognito-identity-js@2.0.22-unstable.15) (2018-08-24)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.22-unstable.14"></a>

## [2.0.22-unstable.14](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.22-unstable.13...amazon-cognito-identity-js@2.0.22-unstable.14) (2018-08-24)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.22-unstable.13"></a>

## [2.0.22-unstable.13](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.22-unstable.11...amazon-cognito-identity-js@2.0.22-unstable.13) (2018-08-23)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.22-unstable.12"></a>

## [2.0.22-unstable.12](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.22-unstable.11...amazon-cognito-identity-js@2.0.22-unstable.12) (2018-08-23)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.22-unstable.11"></a>

## [2.0.22-unstable.11](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.22-unstable.10...amazon-cognito-identity-js@2.0.22-unstable.11) (2018-08-23)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.22-unstable.10"></a>

## [2.0.22-unstable.10](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.22-unstable.9...amazon-cognito-identity-js@2.0.22-unstable.10) (2018-08-23)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.22-unstable.9"></a>

## [2.0.22-unstable.9](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.22-unstable.8...amazon-cognito-identity-js@2.0.22-unstable.9) (2018-08-23)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.22-unstable.8"></a>

## [2.0.22-unstable.8](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.22-unstable.7...amazon-cognito-identity-js@2.0.22-unstable.8) (2018-08-22)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.22-unstable.7"></a>

## [2.0.22-unstable.7](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.22-unstable.6...amazon-cognito-identity-js@2.0.22-unstable.7) (2018-08-22)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.22-unstable.6"></a>

## [2.0.22-unstable.6](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.22-unstable.5...amazon-cognito-identity-js@2.0.22-unstable.6) (2018-08-21)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.22-unstable.5"></a>

## [2.0.22-unstable.5](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.22-unstable.4...amazon-cognito-identity-js@2.0.22-unstable.5) (2018-08-21)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.22-unstable.4"></a>

## [2.0.22-unstable.4](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.22-unstable.3...amazon-cognito-identity-js@2.0.22-unstable.4) (2018-08-20)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.22-unstable.3"></a>

## [2.0.22-unstable.3](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.22-unstable.2...amazon-cognito-identity-js@2.0.22-unstable.3) (2018-08-19)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.22-unstable.2"></a>

## [2.0.22-unstable.2](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.22-unstable.1...amazon-cognito-identity-js@2.0.22-unstable.2) (2018-08-18)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.22-unstable.1"></a>

## [2.0.22-unstable.1](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.22-unstable.0...amazon-cognito-identity-js@2.0.22-unstable.1) (2018-08-16)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.22-unstable.0"></a>

## [2.0.22-unstable.0](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.21...amazon-cognito-identity-js@2.0.22-unstable.0) (2018-08-15)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.21"></a>

## [2.0.21](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.21-unstable.5...amazon-cognito-identity-js@2.0.21) (2018-08-14)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.21-unstable.5"></a>

## [2.0.21-unstable.5](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.21-unstable.4...amazon-cognito-identity-js@2.0.21-unstable.5) (2018-08-14)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.21-unstable.4"></a>

## [2.0.21-unstable.4](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.21-unstable.3...amazon-cognito-identity-js@2.0.21-unstable.4) (2018-08-13)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.21-unstable.3"></a>

## [2.0.21-unstable.3](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.21-unstable.2...amazon-cognito-identity-js@2.0.21-unstable.3) (2018-08-13)

### Bug Fixes

- **amazon-cognito-identity-js:** throw network error if in the offline ([d5808f1](https://github.com/aws/aws-amplify/commit/d5808f1))

<a name="2.0.21-unstable.2"></a>

## [2.0.21-unstable.2](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.21-unstable.1...amazon-cognito-identity-js@2.0.21-unstable.2) (2018-08-09)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.21-unstable.1"></a>

## [2.0.21-unstable.1](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.21-unstable.0...amazon-cognito-identity-js@2.0.21-unstable.1) (2018-08-07)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.21-unstable.0"></a>

## [2.0.21-unstable.0](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.20...amazon-cognito-identity-js@2.0.21-unstable.0) (2018-08-07)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.20"></a>

## [2.0.20](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.20-unstable.7...amazon-cognito-identity-js@2.0.20) (2018-08-06)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.20-unstable.7"></a>

## [2.0.20-unstable.7](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.20-unstable.6...amazon-cognito-identity-js@2.0.20-unstable.7) (2018-08-06)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.20-unstable.6"></a>

## [2.0.20-unstable.6](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.20-unstable.5...amazon-cognito-identity-js@2.0.20-unstable.6) (2018-08-06)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.20-unstable.5"></a>

## [2.0.20-unstable.5](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.20-unstable.3...amazon-cognito-identity-js@2.0.20-unstable.5) (2018-08-06)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.20-unstable.3"></a>

## [2.0.20-unstable.3](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.20-unstable.2...amazon-cognito-identity-js@2.0.20-unstable.3) (2018-07-31)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.20-unstable.2"></a>

## [2.0.20-unstable.2](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.20-unstable.1...amazon-cognito-identity-js@2.0.20-unstable.2) (2018-07-31)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.20-unstable.1"></a>

## [2.0.20-unstable.1](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.20-unstable.0...amazon-cognito-identity-js@2.0.20-unstable.1) (2018-07-30)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.20-unstable.0"></a>

## [2.0.20-unstable.0](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.19...amazon-cognito-identity-js@2.0.20-unstable.0) (2018-07-30)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.19"></a>

## [2.0.19](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.19-unstable.1...amazon-cognito-identity-js@2.0.19) (2018-07-28)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.19-unstable.1"></a>

## [2.0.19-unstable.1](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.18-unstable.0...amazon-cognito-identity-js@2.0.19-unstable.1) (2018-07-28)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.18-unstable.0"></a>

## [2.0.18-unstable.0](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.17-unstable.14...amazon-cognito-identity-js@2.0.18-unstable.0) (2018-07-27)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.17-unstable.15"></a>

## [2.0.17-unstable.15](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.17-unstable.14...amazon-cognito-identity-js@2.0.17-unstable.15) (2018-07-27)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.17-unstable.14"></a>

## [2.0.17-unstable.14](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.17-unstable.13...amazon-cognito-identity-js@2.0.17-unstable.14) (2018-07-27)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.17-unstable.13"></a>

## [2.0.17-unstable.13](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.17-unstable.12...amazon-cognito-identity-js@2.0.17-unstable.13) (2018-07-26)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.17-unstable.12"></a>

## [2.0.17-unstable.12](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.17-unstable.11...amazon-cognito-identity-js@2.0.17-unstable.12) (2018-07-26)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.17-unstable.11"></a>

## [2.0.17-unstable.11](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.17-unstable.10...amazon-cognito-identity-js@2.0.17-unstable.11) (2018-07-26)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.17-unstable.10"></a>

## [2.0.17-unstable.10](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.17-unstable.9...amazon-cognito-identity-js@2.0.17-unstable.10) (2018-07-26)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.17-unstable.9"></a>

## [2.0.17-unstable.9](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.17-unstable.8...amazon-cognito-identity-js@2.0.17-unstable.9) (2018-07-25)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.17-unstable.8"></a>

## [2.0.17-unstable.8](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.17-unstable.7...amazon-cognito-identity-js@2.0.17-unstable.8) (2018-07-25)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.17-unstable.7"></a>

## [2.0.17-unstable.7](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.17-unstable.6...amazon-cognito-identity-js@2.0.17-unstable.7) (2018-07-25)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.17-unstable.6"></a>

## [2.0.17-unstable.6](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.17-unstable.5...amazon-cognito-identity-js@2.0.17-unstable.6) (2018-07-24)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.17-unstable.5"></a>

## [2.0.17-unstable.5](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.17-unstable.4...amazon-cognito-identity-js@2.0.17-unstable.5) (2018-07-23)

### Bug Fixes

- **amazon-cognito-identity-js:** add mfa setting type and fix setUserMfaPreference method ([0f8f9aa](https://github.com/aws/aws-amplify/commit/0f8f9aa))

<a name="2.0.17-unstable.4"></a>

## [2.0.17-unstable.4](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.17-unstable.3...amazon-cognito-identity-js@2.0.17-unstable.4) (2018-07-23)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.17-unstable.3"></a>

## [2.0.17-unstable.3](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.17-unstable.2...amazon-cognito-identity-js@2.0.17-unstable.3) (2018-07-23)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.17-unstable.2"></a>

## [2.0.17-unstable.2](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.17-unstable.1...amazon-cognito-identity-js@2.0.17-unstable.2) (2018-07-20)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.17-unstable.1"></a>

## [2.0.17-unstable.1](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.17-unstable.0...amazon-cognito-identity-js@2.0.17-unstable.1) (2018-07-20)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.17-unstable.0"></a>

## [2.0.17-unstable.0](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.16...amazon-cognito-identity-js@2.0.17-unstable.0) (2018-07-20)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.16"></a>

## [2.0.16](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.16-unstable.1...amazon-cognito-identity-js@2.0.16) (2018-07-19)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.16-unstable.1"></a>

## [2.0.16-unstable.1](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.15...amazon-cognito-identity-js@2.0.16-unstable.1) (2018-07-19)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.16-unstable.0"></a>

## [2.0.16-unstable.0](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.15...amazon-cognito-identity-js@2.0.16-unstable.0) (2018-07-19)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.15"></a>

## [2.0.15](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.15-unstable.4...amazon-cognito-identity-js@2.0.15) (2018-07-18)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.15-unstable.4"></a>

## [2.0.15-unstable.4](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.15-unstable.3...amazon-cognito-identity-js@2.0.15-unstable.4) (2018-07-18)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.15-unstable.3"></a>

## [2.0.15-unstable.3](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.15-unstable.2...amazon-cognito-identity-js@2.0.15-unstable.3) (2018-07-18)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.15-unstable.2"></a>

## [2.0.15-unstable.2](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.15-unstable.1...amazon-cognito-identity-js@2.0.15-unstable.2) (2018-07-18)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.15-unstable.1"></a>

## [2.0.15-unstable.1](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.15...amazon-cognito-identity-js@2.0.15-unstable.1) (2018-07-18)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.15-unstable.0"></a>

## [2.0.15-unstable.0](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.15...amazon-cognito-identity-js@2.0.15-unstable.0) (2018-07-18)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.14-unstable.1"></a>

## [2.0.14-unstable.1](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.14-unstable.0...amazon-cognito-identity-js@2.0.14-unstable.1) (2018-07-03)

### Bug Fixes

- **amazon-cognito-identity-js:** attach raw message for unknown errors ([203d50b](https://github.com/aws/aws-amplify/commit/203d50b))
- **amazon-cognito-identity-js:** attach raw message for unknown errors ([69be072](https://github.com/aws/aws-amplify/commit/69be072))

<a name="2.0.14-unstable.0"></a>

## [2.0.14-unstable.0](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.13...amazon-cognito-identity-js@2.0.14-unstable.0) (2018-07-02)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.13"></a>

## [2.0.13](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.13-unstable.5...amazon-cognito-identity-js@2.0.13) (2018-06-29)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.13-unstable.5"></a>

## [2.0.13-unstable.5](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.13-unstable.4...amazon-cognito-identity-js@2.0.13-unstable.5) (2018-06-29)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.13-unstable.4"></a>

## [2.0.13-unstable.4](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.13-unstable.3...amazon-cognito-identity-js@2.0.13-unstable.4) (2018-06-29)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.13-unstable.3"></a>

## [2.0.13-unstable.3](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.13-unstable.2...amazon-cognito-identity-js@2.0.13-unstable.3) (2018-06-28)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.13-unstable.2"></a>

## [2.0.13-unstable.2](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.13-unstable.1...amazon-cognito-identity-js@2.0.13-unstable.2) (2018-06-27)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.13-unstable.1"></a>

## [2.0.13-unstable.1](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.13-unstable.0...amazon-cognito-identity-js@2.0.13-unstable.1) (2018-06-27)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.13-unstable.0"></a>

## [2.0.13-unstable.0](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.12-unstable.2...amazon-cognito-identity-js@2.0.13-unstable.0) (2018-06-27)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.12"></a>

## [2.0.12](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.12-unstable.2...amazon-cognito-identity-js@2.0.12) (2018-06-27)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.12-unstable.2"></a>

## [2.0.12-unstable.2](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.12-unstable.1...amazon-cognito-identity-js@2.0.12-unstable.2) (2018-06-26)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.12-unstable.1"></a>

## [2.0.12-unstable.1](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.12-unstable.0...amazon-cognito-identity-js@2.0.12-unstable.1) (2018-06-22)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.12-unstable.0"></a>

## [2.0.12-unstable.0](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.11...amazon-cognito-identity-js@2.0.12-unstable.0) (2018-06-22)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.11"></a>

## [2.0.11](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.10-unstable.3...amazon-cognito-identity-js@2.0.11) (2018-06-21)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.10"></a>

## [2.0.10](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.7-unstable.49...amazon-cognito-identity-js@2.0.10) (2018-06-20)

<a name="2.0.10-unstable.3"></a>

## [2.0.10-unstable.3](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.10-unstable.2...amazon-cognito-identity-js@2.0.10-unstable.3) (2018-06-21)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.10-unstable.2"></a>

## [2.0.10-unstable.2](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.10-unstable.1...amazon-cognito-identity-js@2.0.10-unstable.2) (2018-06-21)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.10-unstable.1"></a>

## [2.0.10-unstable.1](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.10-unstable.0...amazon-cognito-identity-js@2.0.10-unstable.1) (2018-06-20)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.10-unstable.0"></a>

## [2.0.10-unstable.0](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.7-unstable.49...amazon-cognito-identity-js@2.0.10-unstable.0) (2018-06-20)

### Bug Fixes

- **pushnotification:** revert change in pr 952 ([257fc40](https://github.com/aws/aws-amplify/commit/257fc40))

<a name="2.0.9"></a>

## [2.0.9](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.7-unstable.35...amazon-cognito-identity-js@2.0.9) (2018-06-04)

### Bug Fixes

- **pushnotification:** revert change in pr 952 ([257fc40](https://github.com/aws/aws-amplify/commit/257fc40))

<a name="2.0.8"></a>

## [2.0.8](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.7...amazon-cognito-identity-js@2.0.8) (2018-06-02)

<a name="2.0.7-unstable.49"></a>

## [2.0.7-unstable.49](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.7-unstable.48...amazon-cognito-identity-js@2.0.7-unstable.49) (2018-06-19)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.7-unstable.48"></a>

## [2.0.7-unstable.48](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.7-unstable.47...amazon-cognito-identity-js@2.0.7-unstable.48) (2018-06-18)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.7-unstable.47"></a>

## [2.0.7-unstable.47](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.7-unstable.46...amazon-cognito-identity-js@2.0.7-unstable.47) (2018-06-18)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.7-unstable.46"></a>

## [2.0.7-unstable.46](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.7-unstable.45...amazon-cognito-identity-js@2.0.7-unstable.46) (2018-06-16)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.7-unstable.45"></a>

## [2.0.7-unstable.45](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.7-unstable.44...amazon-cognito-identity-js@2.0.7-unstable.45) (2018-06-13)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.7-unstable.44"></a>

## [2.0.7-unstable.44](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.7-unstable.43...amazon-cognito-identity-js@2.0.7-unstable.44) (2018-06-13)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.7-unstable.43"></a>

## [2.0.7-unstable.43](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.7-unstable.42...amazon-cognito-identity-js@2.0.7-unstable.43) (2018-06-12)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.7-unstable.42"></a>

## [2.0.7-unstable.42](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.7-unstable.41...amazon-cognito-identity-js@2.0.7-unstable.42) (2018-06-11)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.7-unstable.41"></a>

## [2.0.7-unstable.41](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.7-unstable.40...amazon-cognito-identity-js@2.0.7-unstable.41) (2018-06-08)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.7-unstable.40"></a>

## [2.0.7-unstable.40](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.7-unstable.39...amazon-cognito-identity-js@2.0.7-unstable.40) (2018-06-08)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.7-unstable.39"></a>

## [2.0.7-unstable.39](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.7-unstable.38...amazon-cognito-identity-js@2.0.7-unstable.39) (2018-06-07)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.7-unstable.38"></a>

## [2.0.7-unstable.38](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.7-unstable.37...amazon-cognito-identity-js@2.0.7-unstable.38) (2018-06-06)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.7-unstable.37"></a>

## [2.0.7-unstable.37](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.7-unstable.36...amazon-cognito-identity-js@2.0.7-unstable.37) (2018-06-05)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.7-unstable.36"></a>

## [2.0.7-unstable.36](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.7-unstable.35...amazon-cognito-identity-js@2.0.7-unstable.36) (2018-06-04)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.7-unstable.35"></a>

## [2.0.7-unstable.35](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.7-unstable.34...amazon-cognito-identity-js@2.0.7-unstable.35) (2018-06-04)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.7"></a>

## [2.0.7](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.7-unstable.32...amazon-cognito-identity-js@2.0.7) (2018-06-01)

<a name="2.0.7-unstable.34"></a>

## [2.0.7-unstable.34](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.7-unstable.33...amazon-cognito-identity-js@2.0.7-unstable.34) (2018-06-04)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.7-unstable.33"></a>

## [2.0.7-unstable.33](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.7-unstable.32...amazon-cognito-identity-js@2.0.7-unstable.33) (2018-06-02)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.7-unstable.32"></a>

## [2.0.7-unstable.32](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.7-unstable.31...amazon-cognito-identity-js@2.0.7-unstable.32) (2018-06-01)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.7-unstable.31"></a>

## [2.0.7-unstable.31](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.7-unstable.30...amazon-cognito-identity-js@2.0.7-unstable.31) (2018-06-01)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.7-unstable.30"></a>

## [2.0.7-unstable.30](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.7-unstable.29...amazon-cognito-identity-js@2.0.7-unstable.30) (2018-06-01)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.7-unstable.29"></a>

## [2.0.7-unstable.29](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.7-unstable.28...amazon-cognito-identity-js@2.0.7-unstable.29) (2018-05-31)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.7-unstable.28"></a>

## [2.0.7-unstable.28](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.7-unstable.23...amazon-cognito-identity-js@2.0.7-unstable.28) (2018-05-31)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.7-unstable.23"></a>

## [2.0.7-unstable.23](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.7-unstable.22...amazon-cognito-identity-js@2.0.7-unstable.23) (2018-05-31)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.7-unstable.22"></a>

## [2.0.7-unstable.22](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.7-unstable.21...amazon-cognito-identity-js@2.0.7-unstable.22) (2018-05-31)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.7-unstable.21"></a>

## [2.0.7-unstable.21](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.7-unstable.20...amazon-cognito-identity-js@2.0.7-unstable.21) (2018-05-30)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.7-unstable.20"></a>

## [2.0.7-unstable.20](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.7-unstable.19...amazon-cognito-identity-js@2.0.7-unstable.20) (2018-05-29)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.7-unstable.19"></a>

## [2.0.7-unstable.19](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.7-unstable.18...amazon-cognito-identity-js@2.0.7-unstable.19) (2018-05-29)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.7-unstable.18"></a>

## [2.0.7-unstable.18](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.7-unstable.17...amazon-cognito-identity-js@2.0.7-unstable.18) (2018-05-29)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.7-unstable.17"></a>

## [2.0.7-unstable.17](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.7-unstable.16...amazon-cognito-identity-js@2.0.7-unstable.17) (2018-05-24)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.7-unstable.16"></a>

## [2.0.7-unstable.16](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.7-unstable.15...amazon-cognito-identity-js@2.0.7-unstable.16) (2018-05-24)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.7-unstable.15"></a>

## [2.0.7-unstable.15](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.7-unstable.14...amazon-cognito-identity-js@2.0.7-unstable.15) (2018-05-24)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.7-unstable.14"></a>

## [2.0.7-unstable.14](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.7-unstable.13...amazon-cognito-identity-js@2.0.7-unstable.14) (2018-05-24)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.7-unstable.13"></a>

## [2.0.7-unstable.13](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.7-unstable.12...amazon-cognito-identity-js@2.0.7-unstable.13) (2018-05-24)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.7-unstable.12"></a>

## [2.0.7-unstable.12](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.7-unstable.11...amazon-cognito-identity-js@2.0.7-unstable.12) (2018-05-24)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.7-unstable.11"></a>

## [2.0.7-unstable.11](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.7-unstable.10...amazon-cognito-identity-js@2.0.7-unstable.11) (2018-05-24)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.7-unstable.10"></a>

## [2.0.7-unstable.10](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.6...amazon-cognito-identity-js@2.0.7-unstable.10) (2018-05-24)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.7-unstable.9"></a>

## [2.0.7-unstable.9](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.7-unstable.8...amazon-cognito-identity-js@2.0.7-unstable.9) (2018-05-24)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.7-unstable.8"></a>

## [2.0.7-unstable.8](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.7-unstable.7...amazon-cognito-identity-js@2.0.7-unstable.8) (2018-05-24)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.7-unstable.7"></a>

## [2.0.7-unstable.7](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.7-unstable.6...amazon-cognito-identity-js@2.0.7-unstable.7) (2018-05-24)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.7-unstable.6"></a>

## [2.0.7-unstable.6](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.7-unstable.5...amazon-cognito-identity-js@2.0.7-unstable.6) (2018-05-24)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.7-unstable.5"></a>

## [2.0.7-unstable.5](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.7-unstable.4...amazon-cognito-identity-js@2.0.7-unstable.5) (2018-05-24)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.7-unstable.4"></a>

## [2.0.7-unstable.4](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.7-unstable.3...amazon-cognito-identity-js@2.0.7-unstable.4) (2018-05-24)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.7-unstable.3"></a>

## [2.0.7-unstable.3](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.7-unstable.2...amazon-cognito-identity-js@2.0.7-unstable.3) (2018-05-24)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.7-unstable.2"></a>

## [2.0.7-unstable.2](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.7-unstable.1...amazon-cognito-identity-js@2.0.7-unstable.2) (2018-05-24)

**Note:** Version bump only for package amazon-cognito-identity-js

<a name="2.0.7-unstable.1"></a>

## [2.0.7-unstable.1](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.7-unstable.0...amazon-cognito-identity-js@2.0.7-unstable.1) (2018-05-24)

**Note:** Version bump only for package amazon-cognito-identity-js
<a name="2.0.7-unstable.0"></a>

## [2.0.7-unstable.0](https://github.com/aws/aws-amplify/compare/amazon-cognito-identity-js@2.0.6...amazon-cognito-identity-js@2.0.7-unstable.0) (2018-05-23)

**Note:** Version bump only for package amazon-cognito-identity-js
