/* LibTomMath, multiple-precision integer library -- Tom St Denis
 *
 * LibTomMath is a library that provides multiple-precision
 * integer arithmetic as well as number theoretic functionality.
 *
 * The library was designed directly after the MPI library by
 * Michael Fromberger but has been written from scratch with
 * additional optimizations in place.
 *
 * The library is free for all purposes without any express
 * guarantee it works.
 *
 * Tom St Denis, tomstdenis@gmail.com, http://math.libtomcrypt.com
 */
#ifndef BN_H_
#define BN_H_

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <limits.h>

#include "tommath_class.h"

#ifndef MIN
   #define MIN(x,y) ((x)<(y)?(x):(y))
#endif

#ifndef MAX
   #define MAX(x,y) ((x)>(y)?(x):(y))
#endif

#ifdef __cplusplus
extern "C" {

/* C++ compilers don't like assigning void * to mp_digit * */
#define  OPT_CAST(x)  (x *)

#else

/* C on the other hand doesn't care */
#define  OPT_CAST(x)

#endif


/* detect 64-bit mode if possible */
#if defined(__x86_64__) 
   #if !(defined(MP_64BIT) && defined(MP_16BIT) && defined(MP_8BIT))
      #define MP_64BIT
   #endif
#endif

/* some default configurations.
 *
 * A "mp_digit" must be able to hold DIGIT_BIT + 1 bits
 * A "mp_word" must be able to hold 2*DIGIT_BIT + 1 bits
 *
 * At the very least a mp_digit must be able to hold 7 bits
 * [any size beyond that is ok provided it doesn't overflow the data type]
 */
#ifdef MP_8BIT
   typedef unsigned char      mp_digit;
   typedef unsigned short     mp_word;
#elif defined(MP_16BIT)
   typedef unsigned short     mp_digit;
   typedef unsigned long      mp_word;
#elif defined(MP_64BIT)
   /* for GCC only on supported platforms */
#ifndef CRYPT
   typedef unsigned long long ulong64;
   typedef signed long long   long64;
#endif

   typedef unsigned long      mp_digit;
   typedef unsigned long      mp_word __attribute__ ((mode(TI)));

   #define DIGIT_BIT          60
#else
   /* this is the default case, 28-bit digits */
   
   /* this is to make porting into LibTomCrypt easier :-) */
#ifndef CRYPT
   #if defined(_MSC_VER) || defined(__BORLANDC__) 
      typedef unsigned __int64   ulong64;
      typedef signed __int64     long64;
   #else
      typedef unsigned long long ulong64;
      typedef signed long long   long64;
   #endif
#endif

   typedef unsigned long      mp_digit;
   typedef ulong64            mp_word;

#ifdef MP_31BIT   
   /* this is an extension that uses 31-bit digits */
   #define DIGIT_BIT          31
#else
   /* default case is 28-bit digits, defines MP_28BIT as a handy macro to test */
   #define DIGIT_BIT          28
   #define MP_28BIT
#endif   
#endif

/* define heap macros */
#ifndef CRYPT
   /* default to libc stuff */
   #ifndef XMALLOC 
       #define XMALLOC  malloc
       #define XFREE    free
       #define XREALLOC realloc
       #define XCALLOC  calloc
   #else
      /* prototypes for our heap functions */
      extern void *XMALLOC(size_t n);
      extern void *XREALLOC(void *p, size_t n);
      extern void *XCALLOC(size_t n, size_t s);
      extern void XFREE(void *p);
   #endif
#endif


/* otherwise the bits per digit is calculated automatically from the size of a mp_digit */
#ifndef DIGIT_BIT
   #define DIGIT_BIT     ((int)((CHAR_BIT * sizeof(mp_digit) - 1)))  /* bits per digit */
#endif

#define MP_DIGIT_BIT     DIGIT_BIT
#define MP_MASK          ((((mp_digit)1)<<((mp_digit)DIGIT_BIT))-((mp_digit)1))
#define MP_DIGIT_MAX     MP_MASK

/* equalities */
#define MP_LT        -1   /* less than */
#define MP_EQ         0   /* equal to */
#define MP_GT         1   /* greater than */

#define MP_ZPOS       0   /* positive integer */
#define MP_NEG        1   /* negative */

#define MP_OKAY       0   /* ok result */
#define MP_MEM        -2  /* out of mem */
#define MP_VAL        -3  /* invalid input */
#define MP_RANGE      MP_VAL

#define MP_YES        1   /* yes response */
#define MP_NO         0   /* no response */

/* Primality generation flags */
#define LTM_PRIME_BBS      0x0001 /* BBS style prime */
#define LTM_PRIME_SAFE     0x0002 /* Safe prime (p-1)/2 == prime */
#define LTM_PRIME_2MSB_ON  0x0008 /* force 2nd MSB to 1 */

typedef int           mp_err;

/* you'll have to tune these... */
extern int KARATSUBA_MUL_CUTOFF,
           KARATSUBA_SQR_CUTOFF,
           TOOM_MUL_CUTOFF,
           TOOM_SQR_CUTOFF;

/* define this to use lower memory usage routines (exptmods mostly) */
/* #define MP_LOW_MEM */

/* default precision */
#ifndef MP_PREC
   #ifndef MP_LOW_MEM
      #define MP_PREC                 32     /* default digits of precision */
   #else
      #define MP_PREC                 8      /* default digits of precision */
   #endif   
#endif

/* size of comba arrays, should be at least 2 * 2**(BITS_PER_WORD - BITS_PER_DIGIT*2) */
#define MP_WARRAY               (1 << (sizeof(mp_word) * CHAR_BIT - 2 * DIGIT_BIT + 1))

/* the infamous mp_int structure */
typedef struct  {
    int used, alloc, sign;
    mp_digit *dp;
} mp_int;

/* callback for mp_prime_random, should fill dst with random bytes and return how many read [upto len] */
typedef int ltm_prime_callback(unsigned char *dst, int len, void *dat);


#define USED(m)    ((m)->used)
#define DIGIT(m,k) ((m)->dp[(k)])
#define SIGN(m)    ((m)->sign)

/* error code to char* string */
char *mp_error_to_string(int code);

/* ---> init and deinit bignum functions <--- */
/* init a bignum */
int mp_init(mp_int *a);

/* free a bignum */
void mp_clear(mp_int *a);

/* init a null terminated series of arguments */
int mp_init_multi(mp_int *mp, ...);

/* clear a null terminated series of arguments */
void mp_clear_multi(mp_int *mp, ...);

/* exchange two ints */
void mp_exch(mp_int *a, mp_int *b);

/* shrink ram required for a bignum */
int mp_shrink(mp_int *a);

/* grow an int to a given size */
int mp_grow(mp_int *a, int size);

/* init to a given number of digits */
int mp_init_size(mp_int *a, int size);

/* ---> Basic Manipulations <--- */
#define mp_iszero(a) (((a)->used == 0) ? MP_YES : MP_NO)
#define mp_iseven(a) (((a)->used > 0 && (((a)->dp[0] & 1) == 0)) ? MP_YES : MP_NO)
#define mp_isodd(a)  (((a)->used > 0 && (((a)->dp[0] & 1) == 1)) ? MP_YES : MP_NO)

/* set to zero */
void mp_zero(mp_int *a);

/* set to a digit */
void mp_set(mp_int *a, mp_digit b);

/* set a 32-bit const */
int mp_set_int(mp_int *a, unsigned long b);

/* get a 32-bit value */
unsigned long mp_get_int(mp_int * a);

/* initialize and set a digit */
int mp_init_set (mp_int * a, mp_digit b);

/* initialize and set 32-bit value */
int mp_init_set_int (mp_int * a, unsigned long b);

/* copy, b = a */
int mp_copy(mp_int *a, mp_int *b);

/* inits and copies, a = b */
int mp_init_copy(mp_int *a, mp_int *b);

/* trim unused digits */
void mp_clamp(mp_int *a);

/* ---> digit manipulation <--- */

/* right shift by "b" digits */
void mp_rshd(mp_int *a, int b);

/* left shift by "b" digits */
int mp_lshd(mp_int *a, int b);

/* c = a / 2**b */
int mp_div_2d(mp_int *a, int b, mp_int *c, mp_int *d);

/* b = a/2 */
int mp_div_2(mp_int *a, mp_int *b);

/* c = a * 2**b */
int mp_mul_2d(mp_int *a, int b, mp_int *c);

/* b = a*2 */
int mp_mul_2(mp_int *a, mp_int *b);

/* c = a mod 2**d */
int mp_mod_2d(mp_int *a, int b, mp_int *c);

/* computes a = 2**b */
int mp_2expt(mp_int *a, int b);

/* Counts the number of lsbs which are zero before the first zero bit */
int mp_cnt_lsb(mp_int *a);

/* I Love Earth! */

/* makes a pseudo-random int of a given size */
int mp_rand(mp_int *a, int digits);

/* ---> binary operations <--- */
/* c = a XOR b  */
int mp_xor(mp_int *a, mp_int *b, mp_int *c);

/* c = a OR b */
int mp_or(mp_int *a, mp_int *b, mp_int *c);

/* c = a AND b */
int mp_and(mp_int *a, mp_int *b, mp_int *c);

/* ---> Basic arithmetic <--- */

/* b = -a */
int mp_neg(mp_int *a, mp_int *b);

/* b = |a| */
int mp_abs(mp_int *a, mp_int *b);

/* compare a to b */
int mp_cmp(mp_int *a, mp_int *b);

/* compare |a| to |b| */
int mp_cmp_mag(mp_int *a, mp_int *b);

/* c = a + b */
int mp_add(mp_int *a, mp_int *b, mp_int *c);

/* c = a - b */
int mp_sub(mp_int *a, mp_int *b, mp_int *c);

/* c = a * b */
int mp_mul(mp_int *a, mp_int *b, mp_int *c);

/* b = a*a  */
int mp_sqr(mp_int *a, mp_int *b);

/* a/b => cb + d == a */
int mp_div(mp_int *a, mp_int *b, mp_int *c, mp_int *d);

/* c = a mod b, 0 <= c < b  */
int mp_mod(mp_int *a, mp_int *b, mp_int *c);

/* ---> single digit functions <--- */

/* compare against a single digit */
int mp_cmp_d(mp_int *a, mp_digit b);

/* c = a + b */
int mp_add_d(mp_int *a, mp_digit b, mp_int *c);

/* c = a - b */
int mp_sub_d(mp_int *a, mp_digit b, mp_int *c);

/* c = a * b */
int mp_mul_d(mp_int *a, mp_digit b, mp_int *c);

/* a/b => cb + d == a */
int mp_div_d(mp_int *a, mp_digit b, mp_int *c, mp_digit *d);

/* a/3 => 3c + d == a */
int mp_div_3(mp_int *a, mp_int *c, mp_digit *d);

/* c = a**b */
int mp_expt_d(mp_int *a, mp_digit b, mp_int *c);

/* c = a mod b, 0 <= c < b  */
int mp_mod_d(mp_int *a, mp_digit b, mp_digit *c);

/* ---> number theory <--- */

/* d = a + b (mod c) */
int mp_addmod(mp_int *a, mp_int *b, mp_int *c, mp_int *d);

/* d = a - b (mod c) */
int mp_submod(mp_int *a, mp_int *b, mp_int *c, mp_int *d);

/* d = a * b (mod c) */
int mp_mulmod(mp_int *a, mp_int *b, mp_int *c, mp_int *d);

/* c = a * a (mod b) */
int mp_sqrmod(mp_int *a, mp_int *b, mp_int *c);

/* c = 1/a (mod b) */
int mp_invmod(mp_int *a, mp_int *b, mp_int *c);

/* c = (a, b) */
int mp_gcd(mp_int *a, mp_int *b, mp_int *c);

/* produces value such that U1*a + U2*b = U3 */
int mp_exteuclid(mp_int *a, mp_int *b, mp_int *U1, mp_int *U2, mp_int *U3);

/* c = [a, b] or (a*b)/(a, b) */
int mp_lcm(mp_int *a, mp_int *b, mp_int *c);

/* finds one of the b'th root of a, such that |c|**b <= |a|
 *
 * returns error if a < 0 and b is even
 */
int mp_n_root(mp_int *a, mp_digit b, mp_int *c);

/* special sqrt algo */
int mp_sqrt(mp_int *arg, mp_int *ret);

/* is number a square? */
int mp_is_square(mp_int *arg, int *ret);

/* computes the jacobi c = (a | n) (or Legendre if b is prime)  */
int mp_jacobi, mp_digit b, mp_int e*/
int �p_digitC%!�*a, mp_in-int *c, mp_int *d);moduli, etc...
  educM_PRIMrink(d(mp_ifdef ust *a, mp_digi educe_);mod
/* a/b => cb + d == a */
inetc...
 ReducM_PR,t mp_2expt(m(mp_int ped] i  
#emp_2exdU2*b = c a mp_dissum) (oratod_d
int= bs onnot mp_j0 > a > -(b*b)uli,n6-bit RSAmerelbut hemp_2exuli,  educM_PRIasefin*digi educe( *b);

a)) [iven sd dei].
*a, mp_digi educep_int *c);

/* finds one of the b'th ro);mod (or Lmontgomt be educM_PRIa, mp_digit ntgomt b_);mod
/* a/b => cb +er theomp */
int mp_2expt(mp_B**nnt mp_guarantee/

   /*mp_lteger aicshift usefulIMriut hnor*/
#M's mmp_is_brarya Montgomt besystem.
*a, mp_digit ntgomt b_ fro_nor*/
#Mshift
/* compare |a| to |b| */
int mp2exptx/R_intxm(mp_iN) via Montgomt beReducM_PRIa, mp_digit ntgomt b_ educep_int *c);

/* findsm cb +er themp */
intnd b is 1 */
ines muP_RANGDRifdef usta, mp_int *rint fdef usa digit */
void mp_s (or L2*b = of "d"/
int mp_shrinnt *ri educe*a, int b);
dr_);mod
/* a/b => cb +er theod */
intnd*a + Uaifdef  *a,ump_d(or LDiminished Radix methodta, mp_int *ri educep_int *c);

/* finds one oer themp */
intnd b is true */
in RSAb,  educ.  
   digi educe_2k*a, mp_digi educe_is_2n int to a given sssibentses kL2*b = hrin2ke educM_PRIa, mp_digi educe_2k_);mod
/* a/b => cb +er theod */
intnd*a + Uaifdef  *a,wpass acobiuch tha  ty_intp - k [d_d(ma]Ia, mp_digi educe_2k
int �p_digitC%!�*a, mpb +er thed */
intnd b is true */
in RSAb,  educ.  
   digi educe_2k_l*a, mp_digi educe_is_2n_l int to a given sssibentses kL2*b = hrin2ke educM_PRIa, mp_digi educe_2k_);mod_mp_int *c);

/* b = ad */
intnd*a + Uaifdef  *a,wpass acobiuch tha  ty_intp - k [d_d(ma]Ia, mp_digi educe_2k_mp_int *c);

/* b = an* b (mod c) */
int mp_m err(mp_int *a, mp_intdefine p_int *c, mp_int *d);

/* c = a * a (mod b) */
int*/

/gs *eainst a single zero befops *eaiedef unsigned char   a)->used Safe pIZP_YES  ase is 28-bia)->used Safe pIZP_YES  256a arrays, shtany sofp_cnt_l Safe pIZP_ps *eaiede_CUTOFFmp_intb +er thened char *tab[]*/
intnd    =1 */
ines /

   ny sby a, such tha_cnt_l Safe pIZP_ps *eaiede mp_intchar *is_/

   ny 

/* ---> binary*nd    ch that er  typea, sFermatT_BIT of "a",ump_d(bfine"b".
*a S_s (       to 0 */
t mpne Memp_l1 */
probany schar 
iede mp_intchar *fermatp_int *c, mp_int *d);

nary*nd    ch that er  typea, sMiller-RabinT_BIT of "a",ump_d(bfine"b".
*a S_s (       to 0 */
t mpne Memp_l1 */
probany schar 
iede mp_intchar *miller_rabinp_int *c, mp_int *d);

nary*nd    ch that in fd(mps [Mrink(d(mp_i_intnt *]h are zero befotrials/
int mp_
*a  *
 * retuMiller-RabinTd(mps a
probsofp_ail
   nes (e     2^-96 
iede mp_intchar *rabin*miller_trialst andnipulations er  typetly)  of afuMiller-RabinTon "a",ump_d( tha_cnt_
*a tIME_2MSbfins.  Ancti er  type/
intvalue sievebefotrial
*a /

   /*.  Dsibentses if "a",obi, mp_ 
   dprobani
#de
*a of even
 no m/
int an (1/4)**tt be ablS_s (       to 1 */
probanyyi, mp_mod_igit is c
iede mp_intchar *istchar 

/* ---> binaryt

nary*nd    ch thatot of  are extIME_2MS
 * Michae zero b"a",ump_d("t"otrials
*a of Miller-Rabint be ablbbs_TM_PRI= 1you canchaeME_2MSits
 * [congruet mp_g3nt mp4
iede mp_intchar * exttchar 

/* ---> binaryt

narybbs_TM_PRch thatt of a gtruly how manME_2MSp_rand(mp_int *a(y rea),ut he exp
   dbbsI= 1yif6-bitwant digits* [congruet mp_g3nt mp4  be ablYr RSA key wifnd by
andom, shoe firses abrarya buffereturn how many rea.  "dat"nes muparamsibe6-bit RS ablSA keff. int *dchaendom, sho(e.g.squataMemp_lons.ns cl)aks in fmpare agta type]
outi"dat"netself
*a  o dig RSAb, NULLee for all ME_2MSine LTM.  
 llAb, lan fro     2^(8*nipul.
*a, a)->used > l dst with rint tn void,dbbs, cb,P_8B)d > l dst with r_exint tn (BIT -_BIT8)mp_i, (bbs==1)?1 /* BBS styl:0, cb,P_8B) thatt of a gtruly how manME_2MSp_rand(mp_int *a(yerat,ee for FE_BBSit */ */
llows:for for  01 /* BBS style prim-mCrypt E_2MScongruet mp_g3nt mp4
ie  01 /* BBS sprime (p--won't exceeine LTM_obi, mp_ tic func(impl mp_1 /* BBS styl)
ie  01 /* BBS s 2nd MFF--won't chae inthighBIT _intsb(m
ie  01 /* BBS s 2nd MN --won't chae inthighBIT _intone be ablYr RSA key wifnd by
andom, shoe firses abrarya buffereturn how many rea.  "dat"nes muparamsibe6-bit RS ablSA keff. int *dchaendom, sho(e.g.squataMemp_lons.ns cl)aks in fmpare agta type]
outi"dat"netself
*a  o dig RSAb, NULLee forde mp_intchar *rath r_exi
/* ---> binaryt

naryvoid,dnaryME_BB,gned char *dst, int cb,PED(m)    ((m)int*/

/radix conversift by "b" di_int *b)unt_yera int to a givei_int *py, b = _bin*);

/* ---> Ba); mp_digi ead*py, b = _bini
/* ---> bimp_intlen, void *dat);

naryc); mp_digito*py, b = _bini
/* ---> bilen, void *dat);); mp_digito*py, b = _bin_nong b);

/* copy, b = a *dat);

py, b = a */
i*outlengivei_int *, b = _bin*);

/* ---> Ba); mp_digi ead*, b = _bini
/* ---> bimp_intlen, void *dat);

naryc); mp_digito*, b = _bini
/* ---> biilen, void *dat);); mp_digito*, b = _bin_nong b);

/* copy, b = a *dat);

py, b = a */
i*outlengivei_int * ead*radixi
/* ---> bimp_int *dat)str

naryradix); mp_digitoradixi
/* ---> bim*dat)str

naryradix); mp_digitoradix_nng b);

/* com*dat)str

naryradix

narymaxlengivi_int * adix_);

/* ---> Basic Maradix

nary*nipulatii_int *f ead/* ---> Basic Maradix

FILEt)streamgivi_int *fh
 *
/* ---> Basic Maradix

FILEt)streamgiv a)->used >  ead*ra
/* , str

lengdigi ead*, b = _bini(mp), (str), (leng((a)->used > raw_);

/* )ou'll have to , b = _bin*);

/* ((a)->used > tora
/* , str)'ll have to to*, b = _bini(mp), (str)) a)->used >  ead*);

/*, str

lengdigi ead*py, b = _bini(mp), (str), (leng((a)->used > mag_);

/* )ou'll have to py, b = _bin*);

/* ((a)->used > to);

/*, str)'ll have to to*py, b = _bini(mp), (str))
(a)->used > to/
/* c(M, S) digitoradixi(M), (S), 2((a)->used > tooctal(M, S) ddigitoradixi(M), (S), 8((a)->used > todec */
(M, S) igitoradixi(M), (S), 10((a)->used > tohex(M, S) ddddigitoradixi(M), (S), 16) thatlowleve 142KiB in , dohere wall!b" di_ins_ *b, mp_int *c);

/* c = a - b */
int mp_i_ins_ *b, mp_int *c);

/* c = a * b */
int mp_a)->useds_ *b, mpnt *,int s_ *b, m+er spnt *,in, dp[0] & 1)+ (b[0] & 1)+ 1)_i_infast_s_ *b, m+er sp_int *c, mp_int *d);

/* c = a * iary opsmp_i_ins_ *b, m+er sp_int *c, mp_int *d);

/* c = a * iary opsmp_i_infast_s_ *b, m+high+er sp_int *c, mp_int *d);

/* c = a * iary opsmp_i_ins_ *b, m+high+er sp_int *c, mp_int *d);

/* c = a * iary opsmp_i_infast_s_ *b);

/* a/b => cb + d == a *i_ins_ *b,;

/* a/b => cb + d == a *i_inmp_karatsubab, mp_int *c);

/* b = a*a  */
int mp_smp_digitoomb, mp_int *c);

/* b = a*a  */
int mp_smp_digikaratsubab,;

/* a/b => cb + d == a *i_inmp_toomb,;

/* a/b => cb + d == a *i_infast_int *b, mp_int *c);

/* c = (a, b) */
int mpimp_int *b, m_sifde;

/* initialize* inita, b) */
inyc); mp_dfast_intt ntgomt b_ educep_int *c);

/* findsm cb +er themp */imp_intdefine _fastp_int *c)G

/* findsX

/* findsP

/* findsY

narymdeiniti_ins_ *bdefine e;

/* initG

/* finds X

/* finds P

/* finds Y

narymdeinitED(m)bn_reverse len, void *dat)s
#define giv _CUTOFFmp_int(int codes_rmap;ern "C" {

/* C++ com   }rce$ */
/* $Revission: 0.36 $ */
/* $Date: 2005-08901 16:37:28 +0000 $6-04