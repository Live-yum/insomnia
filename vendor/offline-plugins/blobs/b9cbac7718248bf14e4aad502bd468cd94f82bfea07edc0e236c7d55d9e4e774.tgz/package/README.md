# Holibob Request Signing for Insomnia

**This plugin allows communication with the Holibob GraphQL API.**

## Usage

The following variables must be added to your environment, it is recommended not to add them to the base environment but rather create a specific environment as the plugin may cause requests going to other domains to fail:

-   `holibobApiKey` – Your API key
-   `holibobSecret` – Your API secret

As an example (substitute your own values, of course):

```
{
    "holibobApiKey": "api_key",
    "holibobSecret": "secret"
}
```

When these variables are present in the environment, all requests will this include the following headers, which are required by the API:

-   `x-api-key`
-   `x-holibob-date`
-   `x-holibob-signature`

This plugin checks all outgoing requests to see if

-   the request is a POST request which contains a query
-   the required environment variables (see above) are set.

## Disclaimer

This plugin comes with **absolutely no warranty**!

## Development

If something does go wrong, you will be able to see debugging log messages in the Developer Tools console to help diagnose the issue.
