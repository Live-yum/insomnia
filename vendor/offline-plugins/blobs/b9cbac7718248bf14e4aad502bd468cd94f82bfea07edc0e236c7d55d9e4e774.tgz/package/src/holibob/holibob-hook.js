const crypto = require("crypto");
const loggerConsts = { plugin: "insomnia-plugin-holibob-auth" };

const secretEnvironmentVariableName = "holibobSecret";
const apiKeyEnvironmentVariableName = "holibobApiKey";

const logInfo = (context, inputs, redactedInputs, message) => {
    console.log(
        JSON.stringify({
            ...loggerConsts,
            context,
            inputs,
            redactedInputs,
            message,
        })
    );
};

const generateHashSignature = ({ algorithm = "sha1", secret, date, apiKey, method, path, body }) => {
    logInfo("#generateHashSignature()", { algorithm, date, method, path, body }, ["secret", "apiKey"]);

    const hmac = crypto.createHmac(algorithm, secret);

    hmac.update(date);
    hmac.update(apiKey);
    hmac.update(method);
    hmac.update(path);
    hmac.update(body);

    return hmac.digest("base64");
};

const preprocessBody = (bodyText) => {
    logInfo("#preprocessBody()", { bodyText }, []);

    let bodyObj;

    if (typeof bodyText === "object") {
        bodyObj = bodyText;
    } else {
        bodyObj = JSON.parse(bodyText);
    }

    if (!bodyObj.variables) {
        return JSON.stringify(bodyObj);
    }

    if (typeof bodyObj.variables === "string") {
        bodyObj.variables = JSON.parse(bodyObj.variables);
    }

    return JSON.stringify(bodyObj);
};

const getHmacVariables = (request) => ({
    apiKey: request.getEnvironmentVariable(apiKeyEnvironmentVariableName),
    secret: request.getEnvironmentVariable(secretEnvironmentVariableName),
    date: new Date().toISOString(),
    method: request.getMethod(),
    body: request.getBody(),
    path: new URL(request.getUrl()).pathname,
});

const checkRequiredEnvironmentVariables = (secret, apiKey) => {
    if (!secret || !apiKey) {
        logInfo(
            "#checkRequiredEnvironmentVariables()",
            {},
            ["secret", "apiKey"],
            `Required environment variables are missing. Please ensure ${apiKeyEnvironmentVariableName} and ${secretEnvironmentVariableName} are set in your environment to use this plugin`
        );
        return false;
    }
    return true;
};

const isGraphQLRequest = (method, body) => {
    if (method !== "POST") {
        logInfo("#isGraphQLRequest()", { method }, [], "Method is not POST, assuming this is not a GraphQL Request");
        return false;
    }

    try {
        const parsedBody = JSON.parse(body);
        if (!parsedBody.query) {
            logInfo(
                "#isGraphQLRequest()",
                { body: parsedBody },
                [],
                "Body does not contain query, assuming this is not a GraphQL Request"
            );
            return false;
        }
    } catch (e) {
        return false;
    }

    return true;
};

module.exports = (context) => {
    const { apiKey, secret, date, method, body, path } = getHmacVariables(context.request);

    if (!checkRequiredEnvironmentVariables(secret, apiKey)) {
        return;
    }

    const processedBodyText = preprocessBody(body.text);

    if (!isGraphQLRequest(method, processedBodyText)) {
        return;
    }

    const hash = generateHashSignature({
        secret,
        apiKey,
        date,
        method,
        path,
        body: processedBodyText,
    });

    context.request.setBodyText(processedBodyText);
    context.request.setHeader("x-api-key", apiKey);
    context.request.setHeader("x-holibob-date", date);
    context.request.setHeader("x-holibob-signature", hash);
};
