const { promisify } = require('util');
const os = require('os');
const exec = promisify(require('child_process').exec);

let ip = null;

module.exports.templateTags = [{
  name: 'minikubeClusterIp',
  displayName: 'minikubeClusterIp',
  description: 'The IP address of a locally running MiniKube cluster',
  async run (context) {
    if (ip) {
      return ip;
    }

    return exec('minikube ip', { env: Object.assign({}, process.env, { PATH: `${process.env.PATH}:/usr/local/bin` } ) })
      .then((out) => {
        ip = out.trim();
        return ip;
      });
  }
}];
