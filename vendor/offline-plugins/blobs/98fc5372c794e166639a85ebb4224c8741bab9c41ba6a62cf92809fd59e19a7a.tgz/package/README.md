# insomnia-plugin-minikube

Retrieves data from local [minikube](https://github.com/kubernetes/minikube) cluster for use in
[Insomnia](https://insomnia.rest/)
