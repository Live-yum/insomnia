// For help writing plugins, visit the documentation to get started:
//   https://support.insomnia.rest/article/26-plugins

// TODO: Add plugin code here...

module.exports.requestHooks = [
    (context) => {

        const req = context.request;

        let credential = [
            ["Username: 'Banana', Password: 'password1'"],
            ["Username: 'Orange', Password: 'password2'"]
        ];

        var cLen = credential.length;

        for (var j=0; j<cLen; j++) {
            req.setUrl("https://tripsplit-backend.herokuapp.com/api/auth/login");
            req.setBody(credential[j]);

            const response = context.network.sendRequest(request);
            const style =
            response.statusCode !== 200
                ? "padding:5px; color: var(--color-font-danger); background: var(--color-danger)"
                : "padding:5px; color: var(--color-font-success); background: var(--color-success)";
            results.push(
                `<li style="margin: 5px">${request.name}: <span style="${style}")>${response.statusCode}</span></li>`
            );
        }

        const html = `<ul style="column-count: ${
            results.length > 10 ? 2 : 1
          };">${results.join("\n")}</ul>`;
    
          context.app.showGenericModalDialog("Results", { html });
    },
];