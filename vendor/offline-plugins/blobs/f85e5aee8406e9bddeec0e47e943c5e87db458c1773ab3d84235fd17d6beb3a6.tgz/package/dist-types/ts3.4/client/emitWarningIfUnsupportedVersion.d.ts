export declare const emitWarningIfUnsupportedVersion: (version: string) => void;
