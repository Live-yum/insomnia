# Insomnia DogeCash signature generator

This plugin allows to make authenticated requests to the DogeCash API.

## Installation

1. Add the npm package to Insomnia `@dogecash/insomnia-plugin-dogecash-signature-generator`
2. Add this property to your DogeCash enviroment:

```json
"dogecashSignature": {
    "enabled": true,
    "secret": "your-secret-key"
}
```