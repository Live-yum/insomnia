const { toQueryParams, addSsoParameters, getFormattedTimestamp } = require('./epicSso');

describe(toQueryParams, () => {
  const testData = {
    provider: {
      role: "Physician",
      first: "John",
      last: "Doe",
      npi: "1234567890",
      license: {
        type: "ADM",
        state: "OH",
        value: "123",
      },
    },
    facility: {
      name: "XYZ Hospital",
      npi: "0987654321",
      state: "OH"
    },
    patient: {
      first: "Alice",
      last: "Testpatient",
      zip: "45123",
      dob: "01/30/1990",
      mrn: "12345"
    },
  };

  test('converts raw data to Epic SSO query params', () => {
    const expected = {
      patientfirstname: "Alice",
      patientlastname: "Testpatient",
      patientdob: "01/30/1990",
      patientmrn: "12345",
      patientzip: "45123",
      providerrole: "Physician",
      providerfirstname: "John",
      providerlastname: "Doe",
      providernpi: "1234567890",
      providerdea: undefined,
      providerprofessionallicensetype: "ADM",
      providerprofessionallicensevalue: "123",
      providerprofessionallicensestate: "OH",
      facilityname: "XYZ Hospital",
      facilitystate: "OH",
      facilitynpi: "0987654321",
      facilitydea: undefined,
      timestamp: expect.any(String),
    };

    expect(toQueryParams(testData)).toEqual(expected);
  })
})

describe(getFormattedTimestamp, () => {
  test("returns a properly formatted timestamp based on the passed date", () => {
    const expected = "20181102032147";
    const actual = getFormattedTimestamp(new Date(Date.UTC(2018, 10, 2, 3, 21, 47)));

    expect(actual).toEqual(expected);
  })
})

describe(addSsoParameters, () => {
  const context = {
    request: {
      getEnvironmentVariable: jest.fn(() => 'thing'),
      addParameter: jest.fn(),
      getBodyText: jest.fn(() => ""),
    }
  };

  test('adds necessary query parameters', () => {
    addSsoParameters(context);
    expect(context.request.addParameter).toHaveBeenCalledWith('web_service_user', 'thing');
    expect(context.request.addParameter).toHaveBeenCalledWith('data', expect.any(String));
  })
})