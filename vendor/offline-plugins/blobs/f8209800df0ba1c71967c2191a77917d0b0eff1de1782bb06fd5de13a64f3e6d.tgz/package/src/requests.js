module.exports.isV51 = request => !!request.getUrl().match(/5_1/);

module.exports.isEpicSso = request => !!request.getUrl().match(/\/v5\/report\/epic/);