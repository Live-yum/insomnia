const { pipe } = require('ramda');
const querystring = require('querystring');
const { parseYaml } = require('./utils');
const { encrypt } = require('./epicSsoEncryption');

const getFormattedTimestamp = date => [
  date.getUTCFullYear().toString(),
  (date.getUTCMonth() + 1).toString().padStart(2, '0'),
  date.getUTCDate().toString().padStart(2, '0'),
  date.getUTCHours().toString().padStart(2, '0'),
  date.getUTCMinutes().toString().padStart(2, '0'),
  date.getUTCSeconds().toString().padStart(2, '0')
].join('')

const toQueryParams = (data = {}) => {
  const {
    patient = {},
    provider = {},
    facility = {},
  } = data;

  const license = provider.license || {};

  return {
    timestamp: getFormattedTimestamp(new Date()),
    patientfirstname: patient.first,
    patientlastname: patient.last,
    patientdob: patient.dob,
    patientmrn: patient.mrn || Math.random().toString(),
    patientzip: patient.zip,
    providerrole: provider.role,
    providerfirstname: provider.first,
    providerlastname: provider.last,
    providerdea: provider.dea,
    providernpi: provider.npi,
    providerprofessionallicensetype: license.type,
    providerprofessionallicensestate: license.state,
    providerprofessionallicensevalue: license.value,
    facilityname: facility.name,
    facilitystate: facility.state,
    facilitydea: facility.dea,
    facilitynpi: facility.npi,
  };
}

const getDataPayload = context => pipe(
  context.request.getBodyText,
  parseYaml,
  toQueryParams,
  querystring.stringify,
  encrypt(context.request.getEnvironmentVariable('password'))
)();

const addSsoParameters = context => {
  context.request.addParameter("data", getDataPayload(context));
  context.request.addParameter("web_service_user", context.request.getEnvironmentVariable('username'));
}

module.exports = {
  toQueryParams,
  getDataPayload,
  addSsoParameters,
  getFormattedTimestamp,
};