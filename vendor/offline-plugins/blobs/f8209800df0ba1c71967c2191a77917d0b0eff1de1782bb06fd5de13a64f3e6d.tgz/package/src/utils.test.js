const { parseYaml } = require('./utils');

describe(parseYaml, () => {
  test("parses basic yaml", () => {
    expect(parseYaml("key: value")).toEqual({ key: "value" });
  });

  test("handles tabs in the body by converting them to spaces before parsing", () => {
    const body = "patient:\n\tfirst: Alice\n\tlast: Testpatient";

    expect(parseYaml(body)).toEqual({ patient: { first: "Alice", last: "Testpatient" }});
  });
})
