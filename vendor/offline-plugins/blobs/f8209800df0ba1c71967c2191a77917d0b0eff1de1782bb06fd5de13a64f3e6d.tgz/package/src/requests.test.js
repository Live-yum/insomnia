const { isV51, isEpicSso } = require('./requests');

describe('isV51', () => {
  test('returns true for v5.1 requests', () => {
    const epicSsoUrls = [
      "https://pmpgateway.net/v5_1/patient",
      "https://mutualauth.pmpgateway.net/v5_1/report/92834234",
      "https://gateway-ssl-prep.pmp.appriss.com/v5_1/patient"
    ];

    epicSsoUrls.map(url => {
      const request = {
        getUrl: jest.fn(() => url)
      }

      expect(isV51(request)).toBe(true);
    });
  });

  test('returns false for non-v5.1 requests', () => {
    const nonepicSsoUrls = [
      "https://pmpgateway.net/v5/patient",
      "https://mutualauth.pmpgateway.net/v5/report/92834234",
      "https://gateway-ssl-prep.pmp.appriss.com/v5/patient",
      "https://gateway-prep.pmp.appriss.com/v5/report/epic"
    ];

    nonepicSsoUrls.map(url => {
      const request = {
        getUrl: jest.fn(() => url)
      }

      expect(isV51(request)).toBe(false);
    });
  });
});

describe('isEpicSso', () => {
  test('returns true for Epic SSO requests', () => {
    const epicSsoUrls = [
      "https://pmpgateway.net/v5/report/epic",
      "https://mutualauth.pmpgateway.net/v5/report/epic",
      "https://gateway-ssl-prep.pmp.appriss.com/v5/report/epic"
    ];

    epicSsoUrls.map(url => {
      const request = {
        getUrl: jest.fn(() => url)
      }

      expect(isEpicSso(request)).toBe(true);
    });
  });

  test('returns false for non-v5.1 requests', () => {
    const nonepicSsoUrls = [
      "https://pmpgateway.net/v5/patient",
      "https://mutualauth.pmpgateway.net/v5_1/report/92834234",
      "https://gateway-ssl-prep.pmp.appriss.com/v5/patient",
      "https://gateway-prep.pmp.appriss.com/v5/report/1231"
    ];

    nonepicSsoUrls.map(url => {
      const request = {
        getUrl: jest.fn(() => url)
      }

      expect(isEpicSso(request)).toBe(false);
    });
  });
});