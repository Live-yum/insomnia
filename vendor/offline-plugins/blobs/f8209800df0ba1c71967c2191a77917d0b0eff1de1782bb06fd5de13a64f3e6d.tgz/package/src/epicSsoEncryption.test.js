const { encrypt } = require('./epicSsoEncryption');

describe(encrypt, () => {
  test("propery encrypts a query string", () => {
    const queryString = 'patientfirstname=Abby&patientlastname=Testpatient&patientdob=07%2F01%2F1970&patientmrn=225566261487&patientzip=43209&providerrole=Physician&providerfirstname=Appriss&providerlastname=Test&providerdea=AD1111119&facilityname=Appriss+General+Hospital&facilitystate=OH&facilitydea=AB1234579&timestamp=20181102032147';
    const expected = 'W1/bBfgugbyjX6FQC/QOHP0JJEZnwYk/nz34MiM8eDx1SfiFvsXx11Uqn+3QPUuaPfUHzn0ez9t8A3ihOZaXvZ7mrEg20rRTag+I3edcTU165+aj8IjKszt7EAG8mOAhhDYerE08zYeK6prIMA1jXpbHjzTjb+iNjpuAgOQe6f3uSESqRsqR4h68VpAP/z9aZFj91eIuppR6FHmtYL92PAmNmsAM8mYwOr1vSjr4GAqWRb4ydG+OmuUlp8TfbsGix/zhC1Ib9szNexqN3UGdHgfYfGghxPIfnBQTmzxjl8o12nXmCxDZDgS7/wZovnxYACCaO0hUvLMLyHyQzkfr2X3azYjnYmxG5dKVm8OZ+efyzeKI++yrLdF+OT0AQg5wgxyNxx+EH4Uxl0ICguVXoXyzLQSOU2JkybLapXY1kL4=';

    const actual = encrypt('Password1!')(queryString);
    expect(actual).toEqual(expected);
  })
})