const yaml = require('js-yaml');

module.exports.parseYaml = text => yaml.safeLoad(text.replace(/\t/g, "  "));
