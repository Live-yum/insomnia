const crypto = require('crypto');

const keyLength = 16;
const hashAlgorithm = 'sha1';
const algorithm = 'aes-128-cbc';

const getIv = () => Buffer.alloc(keyLength);

const hash = (input, encoding = 'utf8') => {
  const hash = crypto.createHash(hashAlgorithm);
  hash.update(input, encoding);
  return hash.digest();
}

// Follows the key derivation algorithm described in the Remarks section at https://docs.microsoft.com/en-us/windows/desktop/api/wincrypt/nf-wincrypt-cryptderivekey
const deriveKey = secret => {
  const hBaseData = hash(secret, 'utf8');

  // 1a. Form a 64-byte buffer by repeating the constant 0x36 64 times
  const step1Buffer = Buffer.alloc(64, 0x36);

  // 1b. Let k be the length of the hash value that is represented by the input parameter hBaseData. Set the first k bytes of the buffer to the result of an XOR operation of the first k bytes of the buffer with the hash value that is represented by the input parameter hBaseData.
  for (let i = 0; i < hBaseData.length; i++) {
    step1Buffer[i] = step1Buffer[i] ^ hBaseData[i]
  }

  // 2a. Form a 64-byte buffer by repeating the constant 0x5C 64 times.
  const step2Buffer = Buffer.alloc(64, 0x5C);

  // 2b. Set the first k bytes of the buffer to the result of an XOR operation of the first k bytes of the buffer with the hash value that is represented by the input parameter hBaseData.
  for (let i = 0; i < hBaseData.length; i++) {
    step2Buffer[i] = step2Buffer[i] ^ hBaseData[i]
  }

  // 3. Hash the result of step 1 by using the same hash algorithm as that used to compute the hash value that is represented by the hBaseData parameter.
  const step1Result = hash(step1Buffer.toString('base64'), 'base64');

  // 4. Hash the result of step 2 by using the same hash algorithm as that used to compute the hash value that is represented by the hBaseData parameter.
  const step2Result = hash(step2Buffer.toString('base64'), 'base64');

  // 5. Concatenate the result of step 3 with the result of step 4
  const fullResult = Buffer.concat([step1Result, step2Result]);

  // 6. Use the first n bytes of the result of step 5 as the derived key.
  return fullResult.slice(0, keyLength);
}

const encrypt = password => data => {
  const key = deriveKey(password);
  const iv = getIv();
  const cipher = crypto.createCipheriv(algorithm, key, iv);
  cipher.setAutoPadding(true);
  return cipher.update(data, 'utf8', 'base64') + cipher.final('base64');
}

module.exports = {
  encrypt,
};