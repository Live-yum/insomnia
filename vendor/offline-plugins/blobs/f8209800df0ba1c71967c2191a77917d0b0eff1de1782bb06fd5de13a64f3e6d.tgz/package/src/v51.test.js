const { addCustomAuthHeaders } = require('./v51');

describe("addCustomAuthHeaders", () => {
  const context = {
    request: {
      getEnvironmentVariable: jest.fn(() => 'thing'),
      addHeader: jest.fn()
    }
  };

  test("adds all 4 auth headers", () => {
    const headers = [
      'X-Auth-Username',
      'X-Auth-Timestamp',
      'X-Auth-Nonce',
      'X-Auth-PasswordDigest'
    ];

    addCustomAuthHeaders(context);

    headers.forEach(header => {
      expect(context.request.addHeader).toHaveBeenCalledWith('X-Auth-Username', expect.any(String));
    });
  });
});