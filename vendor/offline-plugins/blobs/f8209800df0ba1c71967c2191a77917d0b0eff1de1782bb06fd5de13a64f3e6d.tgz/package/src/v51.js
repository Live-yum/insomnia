const uuid = require('uuid');
const crypto = require('crypto');

module.exports.addCustomAuthHeaders = context =>  {
  // Add custom digest auth headers to v5.1 requests
  const username = context.request.getEnvironmentVariable('username');
  const password = context.request.getEnvironmentVariable('password');
  const nonce = uuid();
  const timestamp = Math.floor(Date.now() / 1000);
  const authString = `${password}:${nonce}:${timestamp}`;
  const hash = crypto.createHash('sha256').update(authString).digest('hex');

  context.request.addHeader('X-Auth-Timestamp', timestamp);
  context.request.addHeader('X-Auth-Nonce', nonce);
  context.request.addHeader('X-Auth-PasswordDigest', hash);
  context.request.addHeader('X-Auth-Username', username);
};
