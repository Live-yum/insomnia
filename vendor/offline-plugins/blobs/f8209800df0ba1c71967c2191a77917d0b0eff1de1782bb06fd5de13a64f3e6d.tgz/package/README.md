# PMP Gateway Insomnia plugin

## Installation

Open Insomnia preferences. Go to the plugins tab. In the box for the npm package name, enter `insomnia-plugin-pmp-gateway`. Click "Install Plugin."

## Expected environment variables

You must set the following environment variables for the plugin to work.

- `username`: Your web service username for PMP Gateway.
- `password`: Your password for PMP Gateway.

## V5.1 authentication

Authentication headers will be added to any v5.1 request. For now, you're on your own with client certificates.

## Epic SSO

Any Epic SSO request will have query parameters set based on the environment variables and the request body. The request body is expected to be in YAML format (use Text -> Other for the body). For example:

```yaml
provider:
  role: Physician
  first: John
  last: Doe
  npi: 1234567890
  dea: AB1234567
  license:
    type: ADM
    value: 123123
    state: OH
facility:
  name: XYZ Hospital
  npi: 0309485394
  dea: AB1234567
  state: OH
patient:
  first: Alice
  last: Testpatient
  zip: 67203
  dob: 01/01/1900
```

The information in the body will be automatically converted to an encrypted payload, and the body will be removed before the request is sent.