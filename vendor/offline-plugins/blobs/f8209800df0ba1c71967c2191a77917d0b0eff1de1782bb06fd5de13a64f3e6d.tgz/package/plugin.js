const { addCustomAuthHeaders } = require('./src/v51');
const { addSsoParameters } = require('./src/epicSso');
const { isV51, isEpicSso } = require('./src/requests');

module.exports.requestHooks = [
  context => {
    if (isV51(context.request)) {
      addCustomAuthHeaders(context);
    }
  },
  context => {
    if (isEpicSso(context.request)) {
      addSsoParameters(context);
      context.request.setBodyText("");
    }
  }
];