"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.default = void 0;var _events = require("events");
var _debug = _interopRequireDefault(require("debug"));
var _nodeFetchRetry = _interopRequireDefault(require("@adobe/node-fetch-retry"));

var _envConfig = _interopRequireDefault(require("../../envConfig"));function _interopRequireDefault(obj) {return obj && obj.__esModule ? obj : { default: obj };}

const dlog = (0, _debug.default)('that:api:graphql:lifecycle:events');
const { influx } = _envConfig.default;
const url = `${influx.host}/api/v2/write?org=${influx.orgId}&bucket=${influx.bucketId}&precision=ms`;

function lifecycleEvents() {
  dlog('user event emitter created');
  const lifecycleEventEmitter = new _events.EventEmitter();

  function buildLineProtocol({ measurement, tags, fields }) {
    return `${measurement},${tags.toString()} ${fields.toString()}`;
  }

  function callFetch(payload) {
    return (0, _nodeFetchRetry.default)(url, {
      method: 'POST',
      body: payload,
      headers: { Authorization: `Token ${influx.token}` }
    }).catch((e) =>
    process.nextTick(() => lifecycleEventEmitter.emit('error', e))
    );
  }

  function executionDidStart({ service, requestContext }) {
    dlog('executionDidStart');

    const { operation, context } = requestContext;
    const userId = context.user ? context.user.sub : 'ANON';

    const data = buildLineProtocol({
      measurement: 'executionDidStart',
      tags: [
      `userId=${userId}`,
      `service=${service}`,
      `operationKind=${operation.operation}`,
      `queryHash=${requestContext.queryHash}`],

      fields: ['called=1']
    });

    callFetch(data);
  }

  lifecycleEventEmitter.on('error', (err) => {
    throw new Error(err);
  });

  lifecycleEventEmitter.on('executionDidStart', executionDidStart);

  return lifecycleEventEmitter;
}var _default = exports.default =

lifecycleEvents();
//# sourceMappingURL=lifecycleEvents.js.map