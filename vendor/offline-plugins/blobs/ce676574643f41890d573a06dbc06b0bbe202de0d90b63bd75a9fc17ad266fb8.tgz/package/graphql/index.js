"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.default = void 0;var _auth = _interopRequireDefault(require("./directives/auth"));
var _upperCase = _interopRequireDefault(require("./directives/upperCase"));
var _lowerCase = _interopRequireDefault(require("./directives/lowerCase"));
var _date = _interopRequireDefault(require("./scalars/date"));
var _slug = _interopRequireDefault(require("./scalars/slug"));function _interopRequireDefault(obj) {return obj && obj.__esModule ? obj : { default: obj };}var _default = exports.default =

{
  directives: { auth: _auth.default, upperCase: _upperCase.default, lowerCase: _lowerCase.default },
  events: {},
  scalars: { date: _date.default, slug: _slug.default }
};
//# sourceMappingURL=index.js.map