"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.default = void 0;var _date = _interopRequireDefault(require("./date"));
var _slug = _interopRequireDefault(require("./slug"));function _interopRequireDefault(obj) {return obj && obj.__esModule ? obj : { default: obj };}var _default = exports.default =

{
  ..._date.default,
  ..._slug.default
};
//# sourceMappingURL=index.js.map