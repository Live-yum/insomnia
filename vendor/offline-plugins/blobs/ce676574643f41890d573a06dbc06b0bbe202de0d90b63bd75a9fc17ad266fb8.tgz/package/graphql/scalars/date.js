"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.default = void 0;var _moment = _interopRequireDefault(require("moment"));
var _lodash = _interopRequireDefault(require("lodash"));
var _debug = _interopRequireDefault(require("debug"));

var _graphql = require("graphql");
var _error = require("graphql/error");
var _language = require("graphql/language");function _interopRequireDefault(obj) {return obj && obj.__esModule ? obj : { default: obj };}

const dlog = (0, _debug.default)('that:api:scalars:date');

const isDate = (value) => {
  if (!(0, _moment.default)(value).valueOf()) {
    throw new TypeError('Value is not Date or Moment Object');
  }

  return true;
};

const validateDateFormat = (value) => {
  const results = (0, _moment.default)(value, true).isValid();
  if (results) return true;

  throw new TypeError();
};

const validateString = (value) => {
  if (!_lodash.default.isString(value)) {
    throw new TypeError('Value is not string');
  }
  return true;
};var _default = exports.default =

{
  Date: new _graphql.GraphQLScalarType({
    name: 'Date',
    description: 'Date custom scalar type',

    // value from the client
    parseValue(value) {
      dlog('parsedValue %o', value);
      validateString(value);
      validateDateFormat(value);

      const parsedDate = new Date(value);
      dlog('parsed Date', parsedDate);

      return parsedDate;
    },

    // sent to the client
    serialize(value) {
      dlog('serialize %o', value);

      let result;
      if (value && value.toDate) {
        result = value.toDate();
      } else if (isDate(value)) {
        result = value;
      }

      return result;
    },

    parseLiteral(ast) {
      dlog('parseLiteral');
      if (ast.kind !== _language.Kind.STRING) {
        throw new _error.GraphQLError(
          `Can only validate strings as date but got a: ${ast.kind}`
        );
      }

      validateDateFormat(ast.value);
      return ast.value;
    }
  })
};
//# sourceMappingURL=date.js.map