"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.default = void 0;var _graphql = require("graphql");
var _error = require("graphql/error");
var _language = require("graphql/language");
var _debug = _interopRequireDefault(require("debug"));function _interopRequireDefault(obj) {return obj && obj.__esModule ? obj : { default: obj };}

const dlog = (0, _debug.default)('that:api:scalars:slug');

const isString = (value) => {
  if (typeof value !== 'string') {
    throw new TypeError('Value is not of type string');
  }

  return true;
};

const validateSlug = (slug) => {
  dlog('validateSlug');
  const regexp = /^[a-zA-Z0-9-_]+$/g;
  const v = slug.match(regexp);
  if (!v) {
    throw new TypeError('Slug contains invalid characters');
  }
  return true;
};var _default = exports.default =

{
  Slug: new _graphql.GraphQLScalarType({
    name: 'Slug',
    description: 'Slug custom scalar type',

    // value from cliemt
    parseValue(value) {
      dlog('parse value');
      isString(value);
      validateSlug(value);
      return value.toLowerCase();
    },

    // value to client
    serialize(value) {
      dlog('serialize');
      isString(value);
      return value.toLowerCase();
    },

    parseLiteral(ast) {
      dlog('parseLiteral');
      if (ast.kind !== _language.Kind.STRING) {
        throw new _error.GraphQLError(`Slugs must be string but got ${ast.kind}`);
      }

      validateSlug(ast.value);
      return ast.value.toLowerCase();
    }
  })
};
//# sourceMappingURL=slug.js.map