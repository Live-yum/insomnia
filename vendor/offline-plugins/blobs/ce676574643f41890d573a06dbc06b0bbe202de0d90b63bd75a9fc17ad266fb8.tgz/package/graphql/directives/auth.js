"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.default = void 0;var _utils = require("@graphql-tools/utils");
var _graphql = require("graphql");
var _debug = _interopRequireDefault(require("debug"));function _interopRequireDefault(obj) {return obj && obj.__esModule ? obj : { default: obj };}

const { defaultFieldResolver } = require('graphql');

const dlog = (0, _debug.default)('that:api:directive:auth');

function authDirectiveMapper(directiveName = 'auth') {
  dlog('authDirectiveMapper called as %s', directiveName);

  const typeDirectiveArgumentMaps = {};

  return {
    authDirectiveTransformer: (schema) =>
    (0, _utils.mapSchema)(schema, {
      [_utils.MapperKind.TYPE]: (type) => {
        dlog('type resolved: %s', type?.name);

        const authDirective = (0, _utils.getDirective)(schema, type, directiveName)?.[0];

        if (authDirective) {
          typeDirectiveArgumentMaps[type.name] = authDirective;
        }

        return undefined;
      },
      // eslint-disable-next-line consistent-return
      [_utils.MapperKind.OBJECT_FIELD]: (fieldConfig, _fieldName, typeName) => {
        dlog('resolve %s', typeName);
        const authDirective =
        (0, _utils.getDirective)(schema, fieldConfig, directiveName)?.[0] ??
        typeDirectiveArgumentMaps[typeName];

        if (authDirective) {
          const { requires } = authDirective;

          if (requires) {
            const { resolve = defaultFieldResolver } = fieldConfig;

            // eslint-disable-next-line no-param-reassign
            fieldConfig.resolve = (source, args, context, info) => {
              const { user } = context;

              if (!user) {
                dlog('no user destructured from context');
                throw new _graphql.GraphQLError('context contains no user', {
                  extensions: { code: 'FORBIDDEN' }
                });
              }

              dlog('user perm %o', user.permissions);

              if (!user.permissions) {
                dlog('user does not have any permissions defined');
                throw new _graphql.GraphQLError('user has no permissions.', {
                  extensions: { code: 'FORBIDDEN' }
                });
              }

              if (!user.permissions.includes(requires)) {
                dlog(
                  'user missing required role to access resource, %s',
                  requires
                );

                throw new _graphql.GraphQLError(
                  'not authorized to perform requested action',
                  {
                    extensions: { code: 'FORBIDDEN' }
                  }
                );
              }

              return resolve(source, args, context, info);
            };

            return fieldConfig;
          }
        }
      }
    })
  };
}var _default = exports.default =

authDirectiveMapper;
//# sourceMappingURL=auth.js.map