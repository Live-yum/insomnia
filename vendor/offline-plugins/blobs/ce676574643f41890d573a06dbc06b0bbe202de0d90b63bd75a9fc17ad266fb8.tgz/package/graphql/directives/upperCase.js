"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.default = void 0;var _utils = require("@graphql-tools/utils");
var _graphql = require("graphql");
var _debug = _interopRequireDefault(require("debug"));function _interopRequireDefault(obj) {return obj && obj.__esModule ? obj : { default: obj };}

const dlog = (0, _debug.default)('that:api:directive:upperCase');

function upperCaseDirectiveMapper(directiveName = 'upperCase') {
  dlog('upperCaseDirectiveMapper called as %s', directiveName);

  return {
    upperCaseDirectiveTransformer: (schema) =>
    (0, _utils.mapSchema)(schema, {
      [_utils.MapperKind.OBJECT_FIELD]: (fieldConfig) => {
        const upperDirective = (0, _utils.getDirective)(
          schema,
          fieldConfig,
          directiveName
        )?.[0];
        if (upperDirective) {
          dlog('resolve: %s', fieldConfig?.astNode?.name?.value);
          const { resolve = _graphql.defaultFieldResolver } = fieldConfig;
          return {
            ...fieldConfig,
            async resolve(source, args, context, info) {
              const result = await resolve(source, args, context, info);
              if (typeof result === 'string') {
                dlog('setting value to upper case');
                return result.toUpperCase();
              }

              return result;
            }
          };
        }

        return fieldConfig;
      }
    })
  };
}var _default = exports.default =

upperCaseDirectiveMapper;
//# sourceMappingURL=upperCase.js.map