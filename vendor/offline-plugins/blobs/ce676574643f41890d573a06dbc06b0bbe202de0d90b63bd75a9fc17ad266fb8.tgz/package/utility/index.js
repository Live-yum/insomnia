"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.default = void 0;var _firestoreDateForge = _interopRequireDefault(require("./firestoreDateForge"));
var _getValueAtPath = _interopRequireDefault(require("./getValueAtPath"));
var _setValueAtPath = _interopRequireDefault(require("./setValueAtPath"));function _interopRequireDefault(obj) {return obj && obj.__esModule ? obj : { default: obj };}var _default = exports.default =

{
  firestoreDateForge: _firestoreDateForge.default,
  getValueAtPath: _getValueAtPath.default,
  setValueAtPath: _setValueAtPath.default
};
//# sourceMappingURL=index.js.map