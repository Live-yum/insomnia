"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.default = getValueAtPath;var _debug = _interopRequireDefault(require("debug"));function _interopRequireDefault(obj) {return obj && obj.__esModule ? obj : { default: obj };}

const dlog = (0, _debug.default)('that:api:utility');

function getValueAtPath(obj, path) {
  dlog('getValueAtPath (%s)', path);
  let data = obj;
  const pathParts = path.split('.');
  for (let i = 0; i < pathParts.length; i += 1) {
    data = data[pathParts[i]];
    if (!data) break;
  }
  return data;
}
//# sourceMappingURL=getValueAtPath.js.map