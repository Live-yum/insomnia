"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.default = setValueAtPath;var _debug = _interopRequireDefault(require("debug"));function _interopRequireDefault(obj) {return obj && obj.__esModule ? obj : { default: obj };}

const dlog = (0, _debug.default)('that:api:utility');

function setValueAtPath(obj, path, value) {
  dlog('setValueAtPath (%s) (%s)', value, path);
  if (value === '__proto__' || value === 'constructor') return obj;
  if (path.includes('__proto__') || path.includes('constructor')) return obj;
  let data = obj;
  const pathParts = path.split('.');
  if (pathParts.length === 1) {
    data[path] = value;
  } else {
    const setPathLength = pathParts.length - 1;
    let i;
    for (i = 0; i < setPathLength; i += 1) {
      if (data[pathParts[i]] === undefined) {
        data[pathParts[i]] = {};
      }
      data = data[pathParts[i]];
    }
    data[pathParts[i]] = value;
  }

  return obj;
}
//# sourceMappingURL=setValueAtPath.js.map