"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.default = void 0;var _requestLogger = _interopRequireDefault(require("./requestLogger"));function _interopRequireDefault(obj) {return obj && obj.__esModule ? obj : { default: obj };}var _default = exports.default =

{
  requestLogger: _requestLogger.default
};
//# sourceMappingURL=index.js.map