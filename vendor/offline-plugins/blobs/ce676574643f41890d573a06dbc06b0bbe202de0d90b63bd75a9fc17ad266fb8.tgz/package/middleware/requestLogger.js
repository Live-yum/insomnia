"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.default = void 0;var _debug = _interopRequireDefault(require("debug"));
var _requestIp = _interopRequireDefault(require("request-ip"));
var _events = _interopRequireDefault(require("../events"));function _interopRequireDefault(obj) {return obj && obj.__esModule ? obj : { default: obj };}

const dlog = (0, _debug.default)('that:api:middleware:request');
const { influx } = _events.default;

function requestLogger(service) {
  dlog('requestLogger', service);

  function handler(req, res, next) {
    const clientIp = _requestIp.default.getClientIp(req);

    const log = {
      measurement: 'apiRequest',
      tags: [`ip=${clientIp},host=${req.headers.host},service=${service}`],
      fields: [`called=1`]
    };

    dlog('handler %O', log);
    influx.emit('capture', log);

    next();
  }

  return { handler };
}var _default = exports.default =

requestLogger;
//# sourceMappingURL=requestLogger.js.map