"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.default = favoritesEvent;var _events = require("events");
var _debug = _interopRequireDefault(require("debug"));

var _favoritesCache = _interopRequireDefault(require("../dataSources/cloudFirestore/favoritesCache"));function _interopRequireDefault(obj) {return obj && obj.__esModule ? obj : { default: obj };} // import { dataSources } from '@thatconference/api';

const dlog = (0, _debug.default)('that:api:sessions:events:favCache');

function favoritesEvent({ firestore, sentry }) {
  const favEventEmitter = new _events.EventEmitter();
  dlog('favorites event emitter created');

  function purgeFavoritesCache(memberId) {
    dlog('purging/deleting cache for %s', memberId);
    try {
      const favCacheStore = (0, _favoritesCache.default)(firestore);
      return favCacheStore.deleteFavoritesCache(memberId);
    } catch (err) {
      return process.nextTick(() => favEventEmitter.emit('error', err));
    }
  }

  function cacheFavorites({ memberId, data }) {
    dlog('caching favoites for %s. data size: %d', memberId, data.length);

    try {
      const favCacheStore = (0, _favoritesCache.default)(firestore);
      return favCacheStore.addFavoritesCache({ memberId, icsData: data });
    } catch (err) {
      return process.nextTick(() => favEventEmitter.emit('error', err));
    }
  }

  // ****************************
  // initalize emitters
  favEventEmitter.on('editFavorite', purgeFavoritesCache);
  favEventEmitter.on('newFavorite', cacheFavorites);

  favEventEmitter.on('error', (err) => {
    sentry.setTag('section', 'favoritesEventEmitter');
    sentry.captureException(err);
  });

  return favEventEmitter;
}
//# sourceMappingURL=favorites.js.map