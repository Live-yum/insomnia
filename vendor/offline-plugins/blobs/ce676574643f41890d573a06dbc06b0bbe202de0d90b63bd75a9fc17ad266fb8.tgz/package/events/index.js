"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.default = void 0;var _graphCdn = _interopRequireDefault(require("./graphCdn"));
var _favorites = _interopRequireDefault(require("./favorites"));function _interopRequireDefault(obj) {return obj && obj.__esModule ? obj : { default: obj };}var _default = exports.default =

{
  graphCdn: _graphCdn.default,
  favorites: _favorites.default
};
//# sourceMappingURL=index.js.map