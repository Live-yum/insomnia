"use strict";var _constants = _interopRequireDefault(require("../../../constants"));
var _purgeEntityMutations = _interopRequireDefault(require("../purgeEntityMutations"));function _interopRequireDefault(obj) {return obj && obj.__esModule ? obj : { default: obj };}

describe('validate purgeEntityMutations', () => {
  describe('All constant entries have an associated mutation', () => {
    const graphCdnPurge = _constants.default.GRAPHCDN.PURGE;
    const keys = Object.keys(graphCdnPurge);
    const vals = Object.values(graphCdnPurge);

    vals.forEach((val, idx) => {
      it(`will find a mutation for key, ${keys[idx]}`, () => {
        const find = _purgeEntityMutations.default[val];
        expect(find).not.toBeUndefined();
      });
    });
  });
});
//# sourceMappingURL=graphcdn.test.js.map