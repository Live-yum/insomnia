"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.default = graphCdnEvents;require("dotenv/config");
var _events = require("events");
var _debug = _interopRequireDefault(require("debug"));
var _nodeFetchRetry = _interopRequireDefault(require("@adobe/node-fetch-retry"));

var _envConfig = require("../../envConfig");
var _errors = require("../../lib/errors");
var _constants = _interopRequireDefault(require("../../constants"));
var _purgeEntityMutations = _interopRequireDefault(require("./purgeEntityMutations"));function _interopRequireDefault(obj) {return obj && obj.__esModule ? obj : { default: obj };}

const dlog = (0, _debug.default)('that:api:graphCdn:event');

function graphCdnEvents(Sentry) {
  const graphCdnEmitter = new _events.EventEmitter();
  const graphCdn = (0, _envConfig.getGraphCdn)();
  dlog('graphCDN emitter created');

  if (Sentry?.SDK_VERSION?.length < 2) {
    throw new Error(
      'A valid, initialized `@sentry/node` object is required to instantiate emitter'
    );
  }

  function sendReqToGraphCdn(payload) {
    Sentry.addBreadcrumb({
      category: 'graphCdn',
      message: 'post purge request',
      level: 'info',
      data: payload
    });
    const headers = {
      'Content-Type': 'application/json',
      Accept: 'application/json',
      'graphcdn-token': graphCdn.token
    };

    return (0, _nodeFetchRetry.default)(graphCdn.api, {
      method: 'POST',
      body: JSON.stringify(payload),
      headers,
      retryInitialDelay: 250,
      retryBackoff: 2.0
    }).
    then((res) => {
      if (res.ok) return res.json();
      Sentry.setContext('response error', JSON.stringify(res));
      throw new _errors.GraphCdnError(`Non-200 request result: ${res.statusText}`);
    }).
    then((json) => {
      dlog('purge result: %o', json);
      // TODO: validate this?
    });
  }

  /**
   * entityType values defined in constants
   */
  function purgeEntityType(entityType, id) {
    dlog('purge entity type %s, id(s): %o', entityType, id);
    const vals = Object.values(_constants.default.GRAPHCDN.PURGE);
    if (!vals.includes(entityType)) {
      process.nextTick(() =>
      graphCdnEmitter.emit(
        'error',
        new Error(
          `Entity provided doesn't match defined constants. Ensure constants are used from 'that-api'`
        )
      )
      );
      return false;
    }

    const payload = {
      query: _purgeEntityMutations.default[entityType],
      variables: {
        id
      }
    };

    return sendReqToGraphCdn(payload).catch((err) =>
    process.nextTick(() => {
      dlog('Error making purge call:\n%O', err);
      graphCdnEmitter.emit('error', err);
    })
    );
  }

  function purgeOnCreateSession({ eventId, memberIds }) {
    // On creating a session we need to purge entities which reference it
    // events, and members (speakers)
    const payload = {
      query: _purgeEntityMutations.default.onCreatedSession,
      variables: {
        eventId,
        memberIds
      }
    };

    return sendReqToGraphCdn(payload).catch((err) =>
    process.nextTick(() => {
      dlog('Error making purge call:\n%O', err);
      graphCdnEmitter.emit('error', err);
    })
    );
  }

  function purgeOnCreateProduct({ eventId }) {
    const payload = {
      query: _purgeEntityMutations.default.onCreateProduct,
      variables: {
        eventId
      }
    };

    return sendReqToGraphCdn(payload).catch((err) =>
    process.nextTick(() => {
      dlog('Error making purge call:\n%O', err);
      graphCdnEmitter.emit('error', err);
    })
    );
  }

  graphCdnEmitter.on(_constants.default.GRAPHCDN.EVENT_NAME.PURGE, purgeEntityType);
  graphCdnEmitter.on(
    _constants.default.GRAPHCDN.EVENT_NAME.CREATED_SESSION,
    purgeOnCreateSession
  );
  graphCdnEmitter.on(
    _constants.default.GRAPHCDN.EVENT_NAME.CREATED_PRODUCT,
    purgeOnCreateProduct
  );

  graphCdnEmitter.on('error', (err) => {
    dlog('error: %O', err);
    Sentry.setTag('section', 'cdnEventEmitter');
    Sentry.captureException(err);
  });

  return graphCdnEmitter;
}
//# sourceMappingURL=index.js.map