"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.default = void 0;var yup = _interopRequireWildcard(require("yup"));function _getRequireWildcardCache(e) {if ("function" != typeof WeakMap) return null;var r = new WeakMap(),t = new WeakMap();return (_getRequireWildcardCache = function (e) {return e ? t : r;})(e);}function _interopRequireWildcard(e, r) {if (!r && e && e.__esModule) return e;if (null === e || "object" != typeof e && "function" != typeof e) return { default: e };var t = _getRequireWildcardCache(r);if (t && t.has(e)) return t.get(e);var n = { __proto__: null },a = Object.defineProperty && Object.getOwnPropertyDescriptor;for (var u in e) if ("default" !== u && Object.prototype.hasOwnProperty.call(e, u)) {var i = a ? Object.getOwnPropertyDescriptor(e, u) : null;i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u];}return n.default = e, t && t.set(e, n), n;}

const lineItemSchema = yup.object().shape({
  productId: yup.string().min(19).required(),
  quantity: yup.
  number().
  min(1).
  required().
  when('isBulkPurchase', { is: false, then: yup.number().max(1) }),
  isBulkPurchase: yup.boolean().required()
});

const manualOrderSchema = yup.object().shape({
  id: yup.
  string().
  required().
  matches(/^thatev_.*/, { message: 'invalid THAT event id' }),
  eventId: yup.string().required().min(12),
  created: yup.
  string().
  transform((epoch) => epoch.toString()).
  required().
  max(10),
  order: yup.object({
    createdBy: yup.string().required().min(9),
    event: yup.string().required().min(12),
    lineItems: yup.array().min(1).max(6).required().of(lineItemSchema),
    member: yup.string().required().min(9),
    orderDate: yup.string().min(24).required(),
    status: yup.string().strict().min(3).uppercase()
  }),
  type: yup.string().required().min(5),
  livemode: yup.boolean().required()
});var _default =

(manualOrder) =>
manualOrderSchema.
validate(manualOrder).
then(() => true).
catch((err) => {
  throw err;
});exports.default = _default;
//# sourceMappingURL=manualOrderEvent.js.map