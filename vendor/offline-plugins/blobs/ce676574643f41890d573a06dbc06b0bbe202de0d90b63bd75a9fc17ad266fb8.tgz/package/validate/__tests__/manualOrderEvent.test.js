"use strict";
var _index = require("../index");
var _manualThatOrderCreated = _interopRequireDefault(require("./data/manualThatOrderCreated.json"));
var _manualThatOrder = _interopRequireDefault(require("./data/manualThatOrder.json"));function _interopRequireDefault(obj) {return obj && obj.__esModule ? obj : { default: obj };} /* eslint-disable arrow-body-style */

describe('Test manual order event object validation', () => {
  it('validates checkoutCompleteEvent.json correctly', () => {
    return (0, _index.manualOrderEvent)(_manualThatOrderCreated.default).then((result) => {
      expect(result).toBe(true);
    });
  });
  it('will pass without a status property', () => {
    delete _manualThatOrderCreated.default.order.status;
    return (0, _index.manualOrderEvent)(_manualThatOrderCreated.default).then((result) => {
      expect(result).toBe(true);
    });
  });
  it('throws on wrong isBulkPurchase quantity (> 1)', () => {
    _manualThatOrderCreated.default.order.lineItems[0].quantity = 3;
    return expect((0, _index.manualOrderEvent)(_manualThatOrderCreated.default)).rejects.toThrow(
      'order.lineItems[0].quantity must be less than or equal to 1'
    );
  });
  it('throws when order.event is too short', () => {
    _manualThatOrderCreated.default.order.lineItems[0].quantity = 1;
    _manualThatOrderCreated.default.order.event = 'short_id';
    return expect((0, _index.manualOrderEvent)(_manualThatOrderCreated.default)).rejects.toThrow(
      'order.event must be at least 12 characters'
    );
  });
  it('throws when eventId is too short', () => {
    _manualThatOrderCreated.default.order.lineItems[0].quantity = 1;
    _manualThatOrderCreated.default.order.event = 'eventId_@_12';
    _manualThatOrderCreated.default.eventId = 'short_id';
    return expect((0, _index.manualOrderEvent)(_manualThatOrderCreated.default)).rejects.toThrow(
      'eventId must be at least 12 characters'
    );
  });
  it('throws when order id format is incorrect', () => {
    return expect((0, _index.manualOrderEvent)(_manualThatOrder.default)).rejects.toThrow(
      'invalid THAT event id'
    );
  });
  it(`throws when livemode doesn't exist`, () => {
    delete _manualThatOrder.default.livemode;
    return expect((0, _index.manualOrderEvent)(_manualThatOrder.default)).rejects.toThrow(
      'livemode is a required field'
    );
  });
  it(`throws when type is too short`, () => {
    _manualThatOrder.default.livemode = false;
    _manualThatOrder.default.type = 'abcd';
    return expect((0, _index.manualOrderEvent)(_manualThatOrder.default)).rejects.toThrow(
      'type must be at least 5 characters'
    );
  });
  it(`throws when type is missing`, () => {
    delete _manualThatOrder.default.type;
    return expect((0, _index.manualOrderEvent)(_manualThatOrder.default)).rejects.toThrow(
      'type is a required field'
    );
  });
});

// these tests are a bit fragile
//# sourceMappingURL=manualOrderEvent.test.js.map