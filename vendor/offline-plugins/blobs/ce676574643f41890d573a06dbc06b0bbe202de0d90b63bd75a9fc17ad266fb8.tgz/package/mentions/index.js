"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.default = void 0;var _parseToToken = _interopRequireDefault(require("./parseToToken"));
var _parseToSlug = _interopRequireDefault(require("./parseToSlug"));function _interopRequireDefault(obj) {return obj && obj.__esModule ? obj : { default: obj };}var _default = exports.default =

{
  parseToToken: _parseToToken.default,
  parseToSlug: _parseToSlug.default
};
//# sourceMappingURL=index.js.map