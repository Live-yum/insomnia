"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.default = void 0;




var _dataSources = _interopRequireDefault(require("../dataSources"));
var _parseToToken = _interopRequireDefault(require("./parseToToken"));function _interopRequireDefault(obj) {return obj && obj.__esModule ? obj : { default: obj };} /*
 * Parse to slug parses mentions from string returning an array of
 * slug objects.
 * Mentions not found in slug collection are not returned at all.
 */const slugStore = _dataSources.default.cloudFirestore.slug;var _default = async ({ text, firestore, isRetainCase }) => {
  if (typeof text !== 'string') return [];
  const tokens = (0, _parseToToken.default)(text);
  let mentions = [...new Set(tokens)];

  if (mentions.length > 10)
  throw new Error(
    `A maximum of 10 mentions can be parsed. total ${mentions.length}`
  );

  let result = [];
  if (mentions.length > 0) {
    if (!isRetainCase) mentions = mentions.map((m) => m.toLowerCase());
    const slugs = await slugStore(firestore).findFromArray(mentions);
    result = slugs.filter((slug) => slug && slug.slug);
  }

  return result;
};exports.default = _default;
//# sourceMappingURL=parseToSlug.js.map