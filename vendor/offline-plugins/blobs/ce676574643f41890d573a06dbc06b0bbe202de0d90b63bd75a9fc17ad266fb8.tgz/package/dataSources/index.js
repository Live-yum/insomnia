"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.default = void 0;var _favorite = _interopRequireDefault(require("./cloudFirestore/favorite"));
var _slug = _interopRequireDefault(require("./cloudFirestore/slug"));
var _asset = _interopRequireDefault(require("./cloudFirestore/asset"));
var _memberExternal = _interopRequireDefault(require("./cloudFirestore/memberExternal"));
var _product = _interopRequireDefault(require("./cloudFirestore/product"));
var _history = _interopRequireDefault(require("./cloudFirestore/history"));
var _event = _interopRequireDefault(require("./cloudFirestore/event"));
var _eventSpeaker = _interopRequireDefault(require("./cloudFirestore/eventSpeaker"));
var _partner = _interopRequireDefault(require("./cloudFirestore/partner"));
var _favoritesCache = _interopRequireDefault(require("./cloudFirestore/favoritesCache"));
var _order = _interopRequireDefault(require("./cloudFirestore/order"));function _interopRequireDefault(obj) {return obj && obj.__esModule ? obj : { default: obj };}var _default = exports.default =

{
  cloudFirestore: {
    favorites: _favorite.default,
    slug: _slug.default,
    assets: _asset.default,
    member: _memberExternal.default,
    product: _product.default,
    history: _history.default,
    event: _event.default,
    eventSpeaker: _eventSpeaker.default,
    partner: _partner.default,
    favoritesCache: _favoritesCache.default,
    order: _order.default
  }
};
//# sourceMappingURL=index.js.map