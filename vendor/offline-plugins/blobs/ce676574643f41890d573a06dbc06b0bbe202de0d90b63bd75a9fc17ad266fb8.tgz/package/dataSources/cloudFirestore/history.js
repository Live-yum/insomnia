"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.default = void 0;var _debug = _interopRequireDefault(require("debug"));
var _firestore = require("@google-cloud/firestore");function _interopRequireDefault(obj) {return obj && obj.__esModule ? obj : { default: obj };}

const dlog = (0, _debug.default)('that:api:datasources:firebase:history');

const stripeEventCollectionName = 'stripeEventHistory';
const thatEventCollectionName = 'thatEventHistory';

const history = (dbInstance) => {
  dlog('instance created');

  const stripeEventHistoryCollection = dbInstance.collection(
    stripeEventCollectionName
  );
  const thatEventHistoryCollection = dbInstance.collection(
    thatEventCollectionName
  );

  // adds new history record, updates counter if already exists
  async function stripeEventSet(stripeEvent) {
    dlog('stripeEventSet called, eventId: %s', stripeEvent.id);

    const docReference = stripeEventHistoryCollection.doc(stripeEvent.id);
    const newRecord = {
      data: stripeEvent,
      eventType: stripeEvent.type,
      seenCount: _firestore.Firestore.FieldValue.increment(1),
      lastSeenAt: new Date()
    };
    dlog('writing record %o', newRecord);

    return docReference.set(newRecord, { merge: true });
  }

  // adds new history record, updates counter if already exists
  async function thatEventSet(thatEvent) {
    dlog('thatEventSet called, eventId: %s', thatEvent.id);

    const docReference = thatEventHistoryCollection.doc(thatEvent.id);
    const newRecord = {
      data: thatEvent,
      eventType: thatEvent.type,
      seenCount: _firestore.Firestore.FieldValue.increment(1),
      lastSeenAt: new Date()
    };
    dlog('writing record %o', newRecord);

    return docReference.set(newRecord, { merge: true });
  }

  return { stripeEventSet, thatEventSet };
};var _default = exports.default =

history;
//# sourceMappingURL=history.js.map