"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.default = void 0;var _debug = _interopRequireDefault(require("debug"));function _interopRequireDefault(obj) {return obj && obj.__esModule ? obj : { default: obj };}

const dlog = (0, _debug.default)('that:api:datasources:firebase:asset');

const assignmentColName = 'assetAssignments';

const assets = (dbInstance) => {
  dlog('Asset instance created');
  const assignmentCollection = dbInstance.collection(assignmentColName);

  async function findEntityAssets({ entityId, entityType }) {
    dlog('findEntityAsset %s, %s', entityId, entityType);
    const { docs } = await assignmentCollection.
    where('entityId', '==', entityId).
    where('entityType', '==', entityType).
    select('assetId').
    get();

    return docs.map((doc) => ({
      id: doc.get('assetId')
    }));
  }

  return {
    findEntityAssets
  };
};var _default = exports.default =

assets;
//# sourceMappingURL=asset.js.map