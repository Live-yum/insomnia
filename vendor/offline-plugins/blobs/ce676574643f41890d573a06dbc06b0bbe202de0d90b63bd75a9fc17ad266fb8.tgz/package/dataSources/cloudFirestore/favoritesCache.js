"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.default = void 0;var _debug = _interopRequireDefault(require("debug"));
var _firestoreDateForge = _interopRequireDefault(require("../../utility/firestoreDateForge"));function _interopRequireDefault(obj) {return obj && obj.__esModule ? obj : { default: obj };}

const dlog = (0, _debug.default)('that:api:datasources:firebase:favoritesCache');

const collectionName = 'favoritesCache';
const { entityDateForge } = _firestoreDateForge.default;
const forgeFields = ['cachedAt'];

const favoritesCache = (dbInstance) => {
  dlog('favorite cloudFirestore instance created');

  const favCacheCollection = dbInstance.collection(collectionName);
  const favCacheDateForge = entityDateForge({ fields: forgeFields });

  // returns cache entry
  function findFavoritesCache(memberId) {
    dlog('find favoritesCache for %s', memberId);
    return favCacheCollection.
    doc(memberId).
    get().
    then((docSnap) => {
      let r = null;
      if (docSnap.exists) {
        r = {
          id: docSnap.id,
          ...docSnap.data()
        };
      }

      return favCacheDateForge(r);
    });
  }

  // Adds or updates cache entry
  function addFavoritesCache({ memberId, icsData }) {
    dlog('add favorites cache for %s, ics size: %d', memberId, icsData.length);
    const data = {
      memberId,
      icsData,
      favoriteType: 'session',
      cachedAt: new Date()
    };

    return favCacheCollection.
    doc(memberId).
    set(data, { merge: false }).
    then(() => true);
  }

  function deleteFavoritesCache(memberId) {
    dlog('delete favorite cache for %s', memberId);

    return favCacheCollection.
    doc(memberId).
    delete().
    then(() => true);
  }

  return {
    findFavoritesCache,
    addFavoritesCache,
    deleteFavoritesCache
  };
};var _default = exports.default =

favoritesCache;
//# sourceMappingURL=favoritesCache.js.map