"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.default = void 0;var _debug = _interopRequireDefault(require("debug"));function _interopRequireDefault(obj) {return obj && obj.__esModule ? obj : { default: obj };}

const dlog = (0, _debug.default)('that:api:datasources:firebase:member');

const collectionName = 'members';

const member = (dbInstance) => {
  dlog('instance created');

  async function find(memberId) {
    dlog('find %s', memberId);
    const docRef = await dbInstance.doc(`${collectionName}/${memberId}`).get();
    let result = null;
    if (docRef.exists)
    result = {
      id: docRef.id,
      canFeature: docRef.get('canFeature'),
      isDeactivated: docRef.get('isDeactivated')
    };

    return result;
  }

  function findBatch(memberIds) {
    dlog('findBatch of %d', memberIds.length);

    const docFuncs = memberIds.map((id) => find(id));

    return Promise.all(docFuncs);
  }

  return { find, findBatch };
};var _default = exports.default =

member;
//# sourceMappingURL=member.js.map