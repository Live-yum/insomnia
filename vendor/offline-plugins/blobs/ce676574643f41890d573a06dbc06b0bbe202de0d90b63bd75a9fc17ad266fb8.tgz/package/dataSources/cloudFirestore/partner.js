"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.default = void 0;var _debug = _interopRequireDefault(require("debug"));
var _utility = _interopRequireDefault(require("../../utility"));function _interopRequireDefault(obj) {return obj && obj.__esModule ? obj : { default: obj };}

const dlog = (0, _debug.default)('that:api:datasources:firebase:partner');
const { partners: partnerDateForge } = _utility.default.firestoreDateForge;

const collectionName = 'partners';

const partner = (dbInstance) => {
  dlog('instance created');

  const partnerCollection = dbInstance.collection(collectionName);

  function get(partnerId) {
    dlog('get partner %s', partnerId);
    return partnerCollection.
    doc(partnerId).
    get().
    then((docRef) => {
      let result = null;
      if (docRef.exists) {
        result = {
          id: docRef.id,
          ...docRef.data()
        };
        result = partnerDateForge(result);
      }

      return result;
    });
  }

  function getBatch(partnerIds) {
    if (!Array.isArray(partnerIds))
    throw new Error('getBatch parameter, partnerIds, must be an array');
    dlog('get many partners (batch), %d', partnerIds.length);
    const docRefs = partnerIds.map((id) =>
    dbInstance.doc(`${collectionName}/${id}`)
    );
    return dbInstance.getAll(...docRefs).then((docSnaps) =>
    docSnaps.map((docSnap) => {
      let result = null;
      if (docSnap.exists) {
        result = {
          id: docSnap.id,
          ...docSnap.data()
        };
        result = partnerDateForge(result);
      }
      return result;
    })
    );
  }

  // returns memberIds of contacts
  function findPartnerPrimaryContacts(partnerId) {
    dlog('findPartnerCompanyContacts, %s', partnerId);
    const subCollectionName = 'members';
    return partnerCollection.
    doc(partnerId).
    collection(subCollectionName).
    where('isPrimaryContact', '==', true).
    get().
    then((querySnap) => querySnap.docs.map((doc) => doc.id));
  }

  // returns full partner-member records for partner
  function getAllPartnerMembers(partnerId) {
    dlog('getAllPartnerMembers for %s', partnerId);
    const subCollectionName = 'members';
    return partnerCollection.
    doc(partnerId).
    collection(subCollectionName).
    get().
    then((querySnap) =>
    querySnap.docs.map((doc) => ({
      id: doc.id,
      ...doc.data()
    }))
    );
  }

  return {
    get,
    getBatch,
    findPartnerPrimaryContacts,
    getAllPartnerMembers
  };
};var _default = exports.default =

partner;
//# sourceMappingURL=partner.js.map