"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.default = void 0;var _debug = _interopRequireDefault(require("debug"));
var _utility = _interopRequireDefault(require("../../utility"));function _interopRequireDefault(obj) {return obj && obj.__esModule ? obj : { default: obj };}

const dlog = (0, _debug.default)('that:api:datasources:firebase:orders');
const allocationDateForge = _utility.default.firestoreDateForge.orderAllocations;

const allocationCollectionName = 'orderAllocations';

const order = (dbInstance) => {
  dlog('order instance initiated');

  const allocationCollection = dbInstance.collection(allocationCollectionName);

  function findPin({ partnerPin, eventId }) {
    dlog('findPin called for PIN %s, in event %s', partnerPin, eventId);

    return allocationCollection.
    where('partnerPin', '==', partnerPin).
    where('event', '==', eventId).
    get().
    then((querySnap) => {
      if (querySnap.size > 1)
      throw new Error(`Multiple allocations found with PIN ${partnerPin}.`);
      return querySnap.docs.map((d) => {
        const r = {
          id: d.id,
          ...d.data()
        };

        return allocationDateForge(r);
      });
    });
  }

  return { findPin };
};var _default = exports.default =

order;
//# sourceMappingURL=order.js.map