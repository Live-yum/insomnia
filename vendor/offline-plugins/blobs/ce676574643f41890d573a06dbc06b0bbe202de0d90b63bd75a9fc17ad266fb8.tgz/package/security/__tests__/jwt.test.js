"use strict";var _jwt = _interopRequireDefault(require("../jwt"));function _interopRequireDefault(obj) {return obj && obj.__esModule ? obj : { default: obj };}

describe('jwt creation tests', () => {
  const OLD_ENV = process.env;

  beforeEach(() => {
    jest.resetModules();
    process.env = { ...OLD_ENV };
  });

  it('can create jwt', () => {
    process.env.AUTH0_JWKS_URI = 'http://foo.bar';
    process.env.AUTH0_AUDIENCE = 'http://foo.bar';
    process.env.AUTH0_ISSUER = 'http://foo.bar';
    const x = (0, _jwt.default)();

    expect(x).toBeDefined();
  });

  it('jwt creation will fail when JWKS_URI is missing', () => {
    process.env.AUTH0_AUDIENCE = 'http://foo.bar';
    process.env.AUTH0_ISSUER = 'http://foo.bar';

    expect(() => {
      (0, _jwt.default)();
    }).toThrow();
  });

  it('jwt creation will fail when JWKS_AUDIENCE is missing', () => {
    process.env.AUTH0_JWKS_URI = 'http://foo.bar';
    process.env.AUTH0_ISSUER = 'http://foo.bar';

    expect(() => {
      (0, _jwt.default)();
    }).toThrow();
  });

  it('jwt creation will fail when AUTH0_ISSUER is missing', () => {
    process.env.AUTH0_JWKS_URI = 'http://foo.bar';
    process.env.AUTH0_AUDIENCE = 'http://foo.bar';

    expect(() => {
      (0, _jwt.default)();
    }).toThrow();
  });
});
//# sourceMappingURL=jwt.test.js.map