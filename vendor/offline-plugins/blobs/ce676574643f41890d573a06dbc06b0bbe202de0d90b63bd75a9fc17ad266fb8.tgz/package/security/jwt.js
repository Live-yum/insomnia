"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.default = void 0;var _jsonwebtoken = _interopRequireDefault(require("jsonwebtoken"));
var _debug = _interopRequireDefault(require("debug"));
var _jwksRsa = _interopRequireDefault(require("jwks-rsa"));
var _graphql = require("graphql");function _interopRequireDefault(obj) {return obj && obj.__esModule ? obj : { default: obj };}

const dlog = (0, _debug.default)('that:api:jwt');

function configMissing(configKey) {
  throw new Error(`missing required .env setting for ${configKey}`);
}

function jwt() {
  const requiredConfig = {
    jwksUri: process.env.AUTH0_JWKS_URI || configMissing('AUTH0_JWKS_URI'),
    audience: process.env.AUTH0_AUDIENCE || configMissing('AUTH0_AUDIENCE'),
    issuer: process.env.AUTH0_ISSUER || configMissing('AUTH0_ISSUER')
  };

  const client = (0, _jwksRsa.default)({
    rateLimit: JSON.parse(process.env.JWKS_RATE_LIMIT || true),
    jwksRequestsPerMinute: process.env.JWKS_RPM || 5,
    jwksUri: requiredConfig.jwksUri
  });

  function verify(bearerToken) {
    return new Promise((resolve, reject) => {
      const options = {
        audience: requiredConfig.audience,
        issuer: requiredConfig.issuer,
        algorithms: ['RS256']
      };

      dlog('jwt verify called');

      if (!bearerToken) {
        reject(
          new _graphql.GraphQLError('credentials_required', {
            extensions: { code: 'UNAUTHENTICATED' }
          })
        );
      }

      let token;
      const parts = bearerToken.split(' ');

      if (parts.length === 2) {
        const scheme = parts[0];
        const credentials = parts[1];

        if (/^Bearer$/i.test(scheme)) {
          token = credentials;
        } else {
          reject(
            new _graphql.GraphQLError('credentials_bad_scheme', {
              extensions: { code: 'UNAUTHENTICATED' }
            })
          );
        }
      } else {
        reject(
          new _graphql.GraphQLError('credentials_bad_format', {
            extensions: { code: 'UNAUTHENTICATED' }
          })
        );
      }

      function getKey(header, callback) {
        client.getSigningKey(header.kid, (err, key) => {
          if (err && !key) {
            callback(err);
          } else {
            const signingKey = key.publicKey || key.rsaPublicKey;
            callback(null, signingKey);
          }
        });
      }

      _jsonwebtoken.default.verify(token, getKey, options, (e, t) => {
        dlog('decoded token %o', t);
        if (e) reject(e);

        resolve(t);
      });
    });
  }

  return { verify };
}var _default = exports.default =

jwt;
//# sourceMappingURL=jwt.js.map