# @thees/insomnia-plugin-jwt-tokengenerator

Generates a JWT token

- **JWTurl**: the URL where the JWT is generated.
- **JWTemail**: the email.
- **JWTpassword**: the password.
- **_fieldname**: the json field of the response which contains the generated token
