Built on CircleCI https://circleci.com/gh/ExodusMovement/libsodium-exodus

Repo is here: https://github.com/ExodusMovement/libsodium-exodus

Default export is a `wasm` only build. The `libsodium.native.js` is an `asm.js` only build used in React Native.

To audit:

- Trigger a new build on CI https://circleci.com/gh/ExodusMovement/libsodium-exodus/tree/master or run the docker container locally
- When your build is done, go to `Artifacts > dist > shasums.txt`
- Compare the shasums of your new build with https://github.com/ExodusMovement/libsodium-exodus/tree/master/libsodium-wrappers, they should match
