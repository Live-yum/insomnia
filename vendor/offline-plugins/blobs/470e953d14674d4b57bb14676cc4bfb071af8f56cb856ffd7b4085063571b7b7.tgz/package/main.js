// For help writing plugins, visit the documentation to get started:
//   https://support.insomnia.rest/article/173-plugins

// TODO: Add plugin code here...
module.exports.requestHooks = [
  async context => {
    // get the token field name response from api
    const isAuthPath = context.request.getUrl().includes('login') || context.request.getUrl().includes('register');

    // do not set header authorization header when path is 'login' or 'register'
    if (!isAuthPath) {
      const jwt = await context.store.getItem('jwt');
      context.request.addHeader('Authorization', `Bearer ${jwt}`);
    }
  }
];

module.exports.responseHooks = [
  async context => {
    // get the token field name response from api
    const tokenName = context.request.getEnvironmentVariable('access_token');
    

    // check if current route is login
    const isLoginPath = context.request.getUrl().includes('login');

    // persistent jwt on the storage
    if (isLoginPath) {
      const res = context.response.getBody().toString();
      const data = JSON.parse(res);
      const token = data[tokenName];

      console.log(tokenName);
      console.log(token);
      await context.store.setItem('jwt', token);
    }
  }
];