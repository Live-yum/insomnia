# insomnia-plugin-auto-set-bearer-token
insomnia plugin that can auto set authorization header after get jwt

## how to use ?
set `access_token` variable to your environment variable, the value should be the jwt get from login api.

![env variable](./example-1.png "env variable")
![token name](./example-2.png "token name")   
the response jwt is stored in `token` variable, so you need to set environment variable `access_token` with value `token`.   
every time you send a request to get jwt, the jwt will refresh in the insomnia storage.

when request was send to other route, the Authorization header will be set. you can check it at timeline tab.   
![response header](./example-3.png "response header")