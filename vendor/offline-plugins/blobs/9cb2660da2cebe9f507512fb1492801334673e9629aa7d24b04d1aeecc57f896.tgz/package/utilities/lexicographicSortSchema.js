"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.lexicographicSortSchema = lexicographicSortSchema;

var _objectValues = _interopRequireDefault(require("../polyfills/objectValues.js"));

var _inspect = _interopRequireDefault(require("../jsutils/inspect.js"));

var _invariant = _interopRequireDefault(require("../jsutils/invariant.js"));

var _keyValMap = _interopRequireDefault(require("../jsutils/keyValMap.js"));

var _naturalCompare = _interopRequireDefault(require("../jsutils/naturalCompare.js"));

var _schema = require("../type/schema.js");

var _directives = require("../type/directives.js");

var _introspection = require("../type/introspection.js");

var _definition = require("../type/definition.js");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/**
 * Sort GraphQLSchema.
 *
 * This function returns a sorted copy of the given GraphQLSchema.
 */
function lexicographicSortSchema(schema) {
  var schemaConfig = schema.toConfig();
  var typeMap = (0, _keyValMap.default)(sortByName(schemaConfig.types), function (type) {
    return type.name;
  }, sortNamedType);
  return new _schema.GraphQLSchema(_objectSpread(_objectSpread({}, schemaConfig), {}, {
    types: (0, _objectValues.default)(typeMap),
    directives: sortByName(schemaConfig.directives).map(sortDirective),
    query: replaceMaybeType(schemaConfig.query),
    mutation: replaceMaybeType(schemaConfig.mutation),
    subscription: replaceMaybeType(schemaConfig.subscription)
  }));

  function replaceType(type) {
    if ((0, _definition.isListType)(type)) {
      // $FlowFixMe[incompatible-return]
      return new _definition.GraphQLList(replaceType(type.ofType));
    } else if ((0, _definition.isNonNullType)(type)) {
      // $FlowFixMe[incompatible-return]
      return new _definition.GraphQLNonNull(replaceType(type.ofType));
    }

    return replaceNamedType(type);
  }

  function replaceNamedType(type) {
    return typeMap[type.name];
  }

  function replaceMaybeType(maybeType) {
    return maybeType && replaceNamedType(maybeType);
  }

  function sortDirective(directive) {
    var config = directive.toConfig();
    return new _directives.GraphQLDirective(_objectSpread(_objectSpread({}, config), {}, {
      locations: sortBy(config.locations, function (x) {
        return x;
      }),
      args: sortArgs(config.args)
    }));
  }

  function sortArgs(args) {
    return sortObjMap(args, function (arg) {
      return _objectSpread(_objectSpread({}, arg), {}, {
        type: replaceType(arg.type)
      });
    });
  }

  function sortFields(fieldsMap) {
    return sortObjMap(fieldsMap, function (field) {
      return _objectSpread(_objectSpread({}, field), {}, {
        type: replaceType(field.type),
        args: sortArgs(field.args)
      });
    });
  }

  function sortInputFields(fieldsMap) {
    return sortObjMap(fieldsMap, function (field) {
      return _objectSpread(_objectSpread({}, field), {}, {
        type: replaceType(field.type)
      });
    });
  }

  function sortTypes(arr) {
    return sortByName(arr).map(laceNamedType(maturnDs_+ma.
 *
 * This function returns a sorted copy of tb   locations: sorThis fu.Trce,pes, _introspectinition.isNonNullamedType(tyCharCode(code), "ion returns a sort { if pectinition.isNonNullive(directive{
   r config = direcmpatible-return]
      return ne { if pectives.GraphQLDirective(_objectSpread(_objectSpread({},   hex rftByseturn {
   hex rftBys(ocations, fun sortTypes(a
  }

      ahex rftBysne, _col, prplaceType(   reteturn {
      ret(ocations, fun sortTypes(a
  func      a   retne, _col, prelaceTypetCharCode(code), "ion returns a sortIex rftBypectinition.isNonNullive(_directive{
   r config = ddirecmpatible-return]
      return neIex rftBypectives.GraphQLDirective(_objectSpre_ad(_objectSpread({},   hex rftByseturn {
   hex rftBys(ocations, fun sortTypes(a
  }

_      ahex rftBysne, _col, prplaceType(   reteturn {
      ret(ocations, fun sortTypes(a
  func_      a   retne, _col, prelaceTypetCharCode(code), "ion returns a sortUnrospectinition.isNonNullive(_direct2ive{
   r config = ddirecmpatible-return]
      return neUnrospectives.GraphQLDirective(_objectSpre_ad(_ob2bjectSpread({}, fieldteturn {
   ieldt(ocations, fun sortTypes(a
  }

_      2rtByName, _col, prelaceTypetCharCode(code), "ion returns a sortEey,pectinition.isNonNullive(_direct3ive{
   r config = ddirecmpatible-return]
      return neEey,pectives.GraphQLDirective(_objectSpre_ad(_ob3bjectSpread({}, f } elld.typeap) {
 _ad(_ob3 typeNs: sortArgstringValue)(SUBSCRIPTION;
  type.(Sed),'https://github.   /.
 */ql/.
 */ql-js/isseNs/2618')
e(code), "ion returns a sortIe }
 { if pectinition.isNonNullive(_ad(_ob4ive{
   r config = ddirecmpatible-return]
      return neIe }
 { if pectives.GraphQLDirective(_objectSpre_ad(_ob4bjectSpread({}, f   reteturn {
      ret(ocations, fun sortTypes(a
  }

  func_ad(_ob4a   retne, _col, prelaceTypetCharCodion.SUBSCRIPTION;
  } // istanbul ignore next (Not reachable. All possible types have e been considered)


  false || (0, _invariant.defield),nexpected operation: ' + (t(replaceTEFINITION;
   typeap) {
 mrn stype   tyFnreadToken(lefuncoConfichema.getTypeMap() : ObjectlefuncKumerab, {
   leOnly) { vamValutBy(config.locationsnction (x) {} = Object.create(null)ocument(lefuncKumecontext$getDocument$2.lengj, k=(lefuncKumecontextt$2.leng var codmVatrue xtt$2.lefuncoCotrue });type   tyFnaultype   tyFnSystemDerty(obj
  ) {
    ++poslefuncoCo;FINITION;
   typerr) {
    aydardTypeName(t {
      ayutBy(config. valuetionsnction obj)e) {
    );FINITION;
   typerr    ayutmVaToKeydardTypeName(   ayline, c).type(By(config. va1, obj2ument$2.lengj, 1codmVaToKey. va1= body.charj, 2codmVaToKey. va2= directive.toected(require("../json: ' + (j, 1ct.de2= dir}ExtensionNode)(value));
}
