const crypto = require('crypto');

module.exports.templateTags = [{
  name: 'generateSasToken',
  displayName: 'Generate SAS Token',
  description: 'Generates a SAS token for Azure Service Bus using environment variables',
  args: [],
  async run(global) {
    const { context } = global;

    // Retrieve the necessary environment variables
    const namespace = context?.serviceBusNamespace;
    const resourceName = context?.topicName || context?.queueName; // Support for both topic and queue
    const policyName = context?.serviceBusPolicyName;
    const policyKey = context?.serviceBusKey;
    const timeToLive = context?.ExpireTimeInSeconds || 3600; // Default 1 hour

    if (!namespace) {
      throw new Error('Missing required environment variable: serviceBusNamespace');
    }
    if (!resourceName) {
      throw new Error('Missing required environment variable: topicName or queueName');
    }
    if (!policyName) {
      throw new Error('Missing required environment variable: serviceBusPolicyName');
    }
    if (!policyKey) {
      throw new Error('Missing required environment variable: serviceBusKey');
    }

    log('Generating SAS Token', 'info');

    // Construct the URI for the resource (topic or queue)
    const resourceUri = `https://${namespace}.servicebus.windows.net/${resourceName}`.toLowerCase(); // Lowercase as per MSFT spec

    log(`Resource URI: ${resourceUri}`, 'info');
    log(`Shared Access Policy Name: ${policyName}`, 'info');
    log(`Shared Access Key: ${policyKey}`, 'info');

    var encoded = encodeURIComponent(resourceUri); 
    var now = new Date();
    var ttl = Math.round(now.getTime() / 1000) + timeToLive;
    log(`Time to live in seconds: ${ttl}`, 'info');
    var signature = encoded + '\n' + ttl; 
    var hash = crypto.createHmac('sha256', policyKey).update(signature, 'utf8').digest('base64');
    return 'SharedAccessSignature sr=' + encoded + '&sig=' + encodeURIComponent(hash) + '&se=' + ttl + '&skn=' + policyName;
  }
}];

// Helper log function
function log(message, level = 'info') {
  const logLevel = process.env.LOG_LEVEL || 'info'; 
  if (['debug', 'info', 'warn', 'error'].indexOf(level) >= ['debug', 'info', 'warn', 'error'].indexOf(logLevel)) {
    console.log(`[${level}] - ${message}`);
  }
}
