# Insomnia Plugin – Service Bus SAS Token Generator

[![cover.png](https://i.postimg.cc/sfmmNGnY/cover.png)](https://postimg.cc/QVBcBCZC)

This [Insomnia](https://insomnia.rest/) plugin generates a **Shared Access Signature (SAS) Token** for Azure **Service Bus** using environment variables, simplifying the process of sending messages to a **queue** or **topic**.

## Features

- 🔐 Securely generates SAS tokens at request-time.
- ⚙️ Uses standard Insomnia [Environment Variables](https://docs.insomnia.rest/insomnia/environment-variables).
- ✅ Supports **topics** and **queues**.
- 🧩 Easy to install and use as a tag in your requests.

---

## How it works

This plugin generates a valid `Authorization` header with a SAS token based on your environment variables, allowing you to send messages directly to Azure Service Bus without manually crafting the token.

### Environment Variables

📚 [Regenerating keys](https://learn.microsoft.com/en-us/azure/service-bus-messaging/service-bus-sas?WT.mc_id=Portal-Microsoft_Azure_ServiceBus#regenerating-keys).

```json
{
  "serviceBusNamespace": "spsbusns1128",
  "serviceBusKey": "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX",
  "serviceBusPolicyName": "SendPolicy",
  "topicName": "test", // or use "queueName",
  "ExpireTimeInSeconds": 3600 // optional
}
```

**Note**: The ExpireTimeInSeconds environment variable is **optional**. If not provided, it defaults to 3600 seconds, which represents 1 hour.

## How to Use

Install the plugin from the [Insomnia Plugin Hub](https://insomnia.rest/plugins/insomnia-plugin-service-bus-sas-token-generator).

In your `POST request` to the topic or queue endpoint, use the tag `Generate SAS Token` in the `Authorization` header.

### Example Request Setup in Insomnia

[![sample-request.png](https://i.postimg.cc/zGJQWMfL/sample-request.png)](https://postimg.cc/56RpWsL1)

### Tag Function in Use

[![custom-tag.png](https://i.postimg.cc/Fsq0cr6X/custom-tag.png)](https://postimg.cc/0bY61sxV)

The plugin will output the SAS token in place of the tag during request execution.

## References

📚 [Microsoft Docs – Service Bus SAS Authentication](https://learn.microsoft.com/en-us/azure/service-bus-messaging/service-bus-sas?WT.mc_id=Portal-Microsoft_Azure_ServiceBus).

🔧 [Generate SAS Token with Node.js](https://learn.microsoft.com/en-us/rest/api/eventhub/generate-sas-token#nodejs).