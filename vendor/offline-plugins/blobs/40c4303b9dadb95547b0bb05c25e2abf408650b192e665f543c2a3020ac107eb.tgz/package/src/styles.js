class XdebugStyles {
  container() {
    return `
        float: right; 
        display: contents; 
        height: 100%; 
        min-width: 60px;
       	width: 100%; 
        text-align: center;
    `;
  }

  switch() {
    return `
      float: right; 
      display: inline-block; 
      height: 100%; 
      padding: 0 5px; 
      line-height: 45px;
      text-align: center;
    `;
  }
}

module.exports = new XdebugStyles();
