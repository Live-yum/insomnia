export declare const getHomeDir: () => string;
