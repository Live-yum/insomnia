//return eol from a data chunk.
var eol = require("os").EOL;
module.exports = function(data, param) {
  if (!param.eol && data) {
    for (var i = 0, len = data.length; i < len; i++) {
      if (data[i] === "\r") {
        if (data[i + 1] === "\n") {
          param.eol = "\r\n";
        } else if (data[i + 1]) {
          param.eol = "\r";
        }
        return param.eol;
      } else if (data[i] === "\n") {
        param.eol = "\n";
        return param.eol;
      }
    }
  }
  return param.eol;
};
