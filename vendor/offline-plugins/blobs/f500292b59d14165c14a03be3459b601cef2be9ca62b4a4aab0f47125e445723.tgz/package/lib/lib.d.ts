import { SignatureError } from "./error";
export declare const enum HttpMethod {
    Post = "POST",
    Get = "GET",
    Patch = "PATCH",
    Put = "PUT",
    Delete = "DELETE"
}
declare type SignBaseArguments = {
    kid: string;
    method?: HttpMethod;
    path: string;
    headers?: Record<string, string>;
    body?: string;
};
/**
 * @typedef {Object} SignWithPemArguments
 * @property {string} kid - Private key kid.
 * @property {string} [method="POST"] - Request method, e.g. "POST".
 * @property {string} path - Request path, e.g. "/payouts".
 * @property {Record<string, string>} [headers={}] - Request headers to be signed.
 * @property {string} [body=""] - Request body.
 * @property {string} privateKeyPem - Private key pem.
 */
export declare type SignWithPemArguments = SignBaseArguments & {
    privateKeyPem: string;
};
/**
 * @typedef {Object} SignWithFunctionArguments
 * @property {string} kid - Private key kid.
 * @property {string} [method="POST"] - Request method, e.g. "POST".
 * @property {string} path - Request path, e.g. "/payouts".
 * @property {Record<string, string>} [headers={}] - Request headers to be signed.
 * @property {string} [body=""] - Request body.
 * @property {(string) => Promise<string>} signingFunction - Function to sign using a KMS/HSM.
 */
export declare type SignWithFunctionArguments = SignBaseArguments & {
    signingFunction: (message: string) => Promise<string>;
};
export declare type SignArguments = SignWithPemArguments | SignWithFunctionArguments;
/** Sign/verification error
 * SignatureError: SignatureError,
 * Produce a JWS `Tl-Signature` v2 header value.
 * @param {SignWithPemArguments} args - Arguments.
 * @returns {string} Tl-Signature header value.
 * @throws {SignatureError} Will throw if signing fails.
 */
export declare function sign(args: SignWithPemArguments): string;
/** Sign/verification error
 * SignatureError: SignatureError,
 * Produce a JWS `Tl-Signature` v2 header value.
 * @param {SignWithFunctionArguments} args - Arguments.
 * @returns {Promise<string>} Tl-Signature header value.
 * @throws {SignatureError} Will throw if signing fails.
 */
export declare function sign(args: SignWithFunctionArguments): Promise<string>;
declare type BaseParameters = {
    signature: string;
    method: HttpMethod;
    path: string;
    body?: string;
    requiredHeaders?: string[];
    headers?: Record<string, string>;
};
/**
 * @typedef {Object} JwkVerifyParameters
 * @property {string} args.jwks - Public key JWKs JSON response data, alternative to `publicKeyPem`.
 * @property {string} args.signature - Tl-Signature header value.
 * @property {string} args.method - Request method, e.g. "POST".
 * @property {string} args.path - Request path, e.g. "/payouts".
 * @property {string} [args.body=""] - Request body.
 * @property {string[]} [args.requiredHeaders=[]] - List of headers that must be
 *   included in the signature, or else verification will fail.
 * @property {Object} [args.headers={}] - Request headers from which values will
 *   be selectively taken to verify the signature based on what was actually signed.
 */
export declare type JwkVerifyParameters = BaseParameters & {
    jwks: string;
};
/**
 * @typedef {Object} PublicKeyParameters
 * @param {string} args.publicKeyPem - Public key pem, must be provided unless providing `jwks`.
 * @property {string} args.signature - Tl-Signature header value.
 * @property {string} args.method - Request method, e.g. "POST".
 * @property {string} args.path - Request path, e.g. "/payouts".
 * @property {string} [args.body=""] - Request body.
 * @property {string[]} [args.requiredHeaders=[]] - List of headers that must be
 *   included in the signature, or else verification will fail.
 * @property {Object} [args.headers={}] - Request headers from which values will
 *   be selectively taken to verify the signature based on what was actually signed.
 */
export declare type PublicKeyParameters = BaseParameters & {
    publicKeyPem: string;
};
/**
* Parameters to verify a given `TL-signature` header value
* @typedef {(JwkVerifyParameters | PublicKeyParameters)} VerifyParameters
*/
export declare type VerifyParameters = JwkVerifyParameters | PublicKeyParameters;
/**
 * Verify the given `Tl-Signature` header value.
 * @param {VerifyParameters} args
 * @throws {SignatureError} Will throw if signature could not be verified.
 */
export declare function verify(args: JwkVerifyParameters): any;
export declare function verify(args: PublicKeyParameters): any;
/**
 * Extract kid from unverified jws Tl-Signature.
 * @param {string} tlSignature - Tl-Signature header value.
 * @returns {string} Tl-Signature header kid.
 * @throws {SignatureError} Will throw if signature is invalid.
 */
export declare function extractKid(tlSignature: string): string;
/**
 * Extract jku from unverified jws Tl-Signature.
 * @param {string} tlSignature - Tl-Signature header value.
 * @returns {string?} Tl-Signature header jku.
 * @throws {SignatureError} Will throw if signature is invalid.
 */
export declare function extractJku(tlSignature: string): string | undefined;
export { SignatureError };
