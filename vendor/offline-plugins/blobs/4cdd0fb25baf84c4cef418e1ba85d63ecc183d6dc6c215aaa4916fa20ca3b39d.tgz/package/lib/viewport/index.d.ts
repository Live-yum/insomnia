import { Styler } from '../styler/types';
export { Styler };
declare const _default: ({ ...props }?: import("stylefire/src/styler/types").Props) => Styler;
export default _default;
