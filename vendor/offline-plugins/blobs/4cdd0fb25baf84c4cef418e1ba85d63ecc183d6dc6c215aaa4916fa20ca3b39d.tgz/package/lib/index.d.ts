import createStylerFactory from './styler';
import { buildStyleProperty } from './css/build-styles';
import { buildSVGAttrs } from './svg/build';
import { transformProps, isTransformProp } from './css/transform-props';
import { Styler, Props } from './styler/types';
export default function (nodeOrSelector: Element | string | Window, props?: Props): Styler;
export { createStylerFactory, Styler, buildStyleProperty, buildSVGAttrs, transformProps, isTransformProp };
