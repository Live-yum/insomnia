export declare const transformProps: string[];
export declare function isTransformProp(key: string): boolean;
export declare function sortTransformProps(a: string, b: string): number;
export declare function isTransformOriginProp(key: string): boolean;
