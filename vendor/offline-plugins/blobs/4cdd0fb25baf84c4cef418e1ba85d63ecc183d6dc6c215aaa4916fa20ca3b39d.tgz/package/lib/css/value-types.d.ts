import { ValueType } from 'style-value-types';
export declare const getValueType: (key: string) => ValueType;
export declare const getValueAsType: (value: any, type?: ValueType) => any;
