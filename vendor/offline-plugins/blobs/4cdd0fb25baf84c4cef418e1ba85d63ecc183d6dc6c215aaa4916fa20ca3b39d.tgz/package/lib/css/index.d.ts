import { Styler, ResolvedState, State } from '../styler/types';
declare type Props = {
    enableHardwareAcceleration?: boolean;
    preparseOutput?: boolean;
    allowTransformNone?: boolean;
};
export declare type CssStylerOptions = {
    element: HTMLElement;
    preparseOutput: boolean;
    buildStyles: (state: State) => ResolvedState;
    hasCSSVariable?: boolean;
};
export default function createCssStyler(element: HTMLElement, { enableHardwareAcceleration, allowTransformNone, ...props }?: Props): Styler;
export {};
