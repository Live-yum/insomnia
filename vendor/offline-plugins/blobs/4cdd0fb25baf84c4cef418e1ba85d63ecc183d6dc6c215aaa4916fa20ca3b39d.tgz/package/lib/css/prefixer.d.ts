declare const prefixer: (key: string, asDashCase?: boolean) => any;
export default prefixer;
