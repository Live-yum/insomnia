export declare const SCROLL_LEFT = "scrollLeft";
export declare const SCROLL_TOP = "scrollTop";
export declare const scrollKeys: Set<string>;
