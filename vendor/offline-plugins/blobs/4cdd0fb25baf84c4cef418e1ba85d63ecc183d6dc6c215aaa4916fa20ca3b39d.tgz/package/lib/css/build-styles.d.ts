import { State, ResolvedState } from '../styler/types';
declare function buildStyleProperty(state: State, enableHardwareAcceleration?: boolean, styles?: ResolvedState, transform?: ResolvedState, transformOrigin?: ResolvedState, transformKeys?: string[], isDashCase?: boolean, allowTransformNone?: boolean): ResolvedState;
declare function createStyleBuilder({ enableHardwareAcceleration, isDashCase, allowTransformNone }?: {
    enableHardwareAcceleration?: boolean;
    isDashCase?: boolean;
    allowTransformNone?: boolean;
}): (state: State) => ResolvedState;
export { buildStyleProperty, createStyleBuilder };
