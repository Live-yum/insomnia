import { State } from '../styler/types';
export declare type AliasMap = {
    [key: string]: string;
};
export declare const aliasMap: AliasMap;
export default function buildStylePropertyString(state: State, changedValues: string[] | true, enableHardwareAcceleration: boolean, blacklist: Set<string>): string;
