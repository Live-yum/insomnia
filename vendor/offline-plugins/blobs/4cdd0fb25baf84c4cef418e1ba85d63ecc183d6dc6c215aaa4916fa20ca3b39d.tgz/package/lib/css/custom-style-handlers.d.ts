import { ResolvedState } from '../styler/types';
interface CustomStyleHandler {
    get?: string;
    set: (output: ResolvedState, value: any) => void;
}
export declare const customStyleHandlers: {
    [key: string]: CustomStyleHandler;
};
export {};
