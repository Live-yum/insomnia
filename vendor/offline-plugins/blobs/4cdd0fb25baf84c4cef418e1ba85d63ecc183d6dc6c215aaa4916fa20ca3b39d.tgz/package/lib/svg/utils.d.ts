import { Dimensions } from './types';
export declare const getDimensions: (element: SVGElement | SVGPathElement) => Dimensions;
export declare const getSVGElementDimensions: (element: SVGElement | SVGPathElement) => Dimensions;
