export declare const camelCaseAttributes: Set<string>;
