export declare type Dimensions = {
    x: number;
    y: number;
    width: number;
    height: number;
};
export declare type SVGState = {
    [key: string]: string | number;
};
export declare type TransformState = {
    translate: string;
    scale: string;
    rotate: string;
    skewX: string;
    skewY: string;
    [key: string]: string;
};
