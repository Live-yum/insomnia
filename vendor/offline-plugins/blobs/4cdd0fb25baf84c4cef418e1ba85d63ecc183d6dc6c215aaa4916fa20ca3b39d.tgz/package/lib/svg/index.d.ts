import { Styler } from '../styler/types';
declare const _default: (element: SVGElement | SVGPathElement) => Styler;
export default _default;
