import { ValueType } from 'style-value-types';
declare const _default: (key: string) => ValueType;
export default _default;
