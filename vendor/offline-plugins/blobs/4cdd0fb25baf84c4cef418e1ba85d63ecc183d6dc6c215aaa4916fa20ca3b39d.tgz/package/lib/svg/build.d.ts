import { Dimensions, SVGState } from './types';
import { State, ResolvedState } from '../styler/types';
export declare type SVGAttrs = {
    [key: string]: any;
    style?: {
        transform?: string;
        transformOrigin?: string;
    };
};
export declare function buildSVGAttrs({ attrX, attrY, originX, originY, pathLength, pathSpacing, pathOffset, ...state }: State & SVGState, dimensions?: Dimensions, totalPathLength?: number | undefined, cssBuilder?: (state: State) => ResolvedState, attrs?: SVGAttrs, isDashCase?: boolean): SVGAttrs;
export declare function createAttrBuilder(dimensions: Dimensions, totalPathLength?: number, isDashCase?: boolean): (state: State & SVGState) => SVGAttrs;
