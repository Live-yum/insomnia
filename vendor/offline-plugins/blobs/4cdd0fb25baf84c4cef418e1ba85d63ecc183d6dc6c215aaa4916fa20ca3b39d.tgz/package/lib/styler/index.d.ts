import { Config, Props, Styler } from './types';
declare const createStyler: ({ onRead, onRender, uncachedValues, useCache }: Config) => ({ ...props }?: Props) => Styler;
export default createStyler;
