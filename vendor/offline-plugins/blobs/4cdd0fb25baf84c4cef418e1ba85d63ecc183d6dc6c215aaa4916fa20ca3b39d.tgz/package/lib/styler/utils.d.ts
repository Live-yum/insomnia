export declare const camelToDash: (str: string) => string;
