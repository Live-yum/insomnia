# insomnia-plugin-random-item

Insomnia plugin to pick a random value from a set.

## Usage

Add the template tag to your request like a variable.

The plugin takes 2 arguments:

 1. The set of values, this can be delimited using any character
 2. The separator character. If not provided a comma (`,`) is used. This must be a single character.