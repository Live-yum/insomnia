const createInsomnia = require('./src/hcl-parser')
const { downloadBinary } = require('./src/downloadBinary')
const Server = require('./src/server')
const openConfig = require('./src/openConfig');
const fs = require('fs');
const path = require('path');

const configPath = `${path.join(__dirname, '../config.hcl')}`

const server = new Server();

process.on("unhandledRejection", (error, __promise) => {
  console.log("Unhandled rejection:", error);
});

let workspaceActions = [{
  label: 'Download API Mocked Binary',
  icon: 'fa-download',
  action: downloadHook,
}];

const importOption = {
  label: 'Import Collection',
  icon: 'fa-star',
  id: 'importCollection',
  action: importHook,
};

const configOption = {
  label: 'Open Config file',
  icon: 'fa fa-file-text',
  id: 'openConfigFile',
  action: openConfigHook,
};

const serverOption = {
  label: 'Run Server',
  icon: 'fa fa-server',
  id: 'toggleServer',
  action: toggleServerHook,
};

async function importHook(context) {
  if (fs.existsSync(configPath)) {
    createInsomniaObj = new createInsomnia(context)
    const importData = await createInsomniaObj.createInsomniaJson();
    await context.data.import.raw(JSON.stringify(importData))
    context.app.alert('Success!', "Your APIs have been successfully imported as a collection.")
  } else {
    context.app.alert('Alert!', "Config file not found. Click on Download Binary to get config file.")
  }
};

async function downloadHook(context) {
  const toggleBtn = document.querySelector('#dropdowns-container > div.dropdown__menu.theme--dropdown__menu.dropdown__menu--open > div.dropdown__list > ul > li:nth-child(8) > button')
  if (toggleBtn) toggleBtn.disabled = true;
  try {

    const platform = process.platform || '';
    await downloadBinary(platform).then(() => {
      const isServer = workspaceActions.find((e) => e.id === serverOption.id)
      if (isServer) workspaceActions = workspaceActions.filter(e => !e.id)
      workspaceActions.push(importOption);
      workspaceActions.push(configOption);
      workspaceActions.push(serverOption);
      server.reset();
      serverOption.label = 'Run Server';

      context.app.alert('Success!', 'You have successfully downloaded API-Mocked. Please select the "Run Server" to run the binary.')
      if (toggleBtn) toggleBtn.disabled = false;
    }).catch(() => {
      context.app.alert('Error!', 'Something went wrong!')
    })

  } catch (err) {
    context.app.alert('Error!', 'Something went wrong!')
    if (toggleBtn) toggleBtn.disabled = false;
  }
};

async function startServerHook(context) {
  try {
    const platform = process.platform || '';

    server.start(platform).then(res => {
      serverOption.label = `Stop Server`
      context.app.alert('Success!', res);
    }).catch(err => {
      context.app.alert('Error!', err)
    })

  } catch (err) {
    console.log("Something went wrong!", err)
  }
};

async function stopServerHook(context) {
  try {
    serverOption.label = `Run Server`
    server.stop();
    context.app.alert('Success!', 'Server has been stopped!')
  } catch (err) {
    console.log("Something went wrong!", err)
  }
};

async function toggleServerHook(context) {
  const isRunning = isServerRunning();
  if (isRunning) {
    await stopServerHook(context);
  } else {
    await startServerHook(context);
  }
};

async function openConfigHook(context) {
  try {
    await openConfig()
  } catch (err) {
    context.app.alert('Error', err)
  }
};

function isServerRunning() {
  return process.env.processId ? true : false;
}

if (fs.existsSync(configPath)) {
  workspaceActions.push(importOption)
  workspaceActions.push(configOption)
  workspaceActions.push(serverOption)
  const isRunning = isServerRunning();
  if (isRunning) serverOption.label = 'Stop Server'
  else serverOption.label = 'Run Server'
}

module.exports = {
  workspaceActions
};