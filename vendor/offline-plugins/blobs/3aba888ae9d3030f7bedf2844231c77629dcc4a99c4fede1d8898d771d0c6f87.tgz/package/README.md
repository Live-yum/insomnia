# Insomnia Plugin - API Mocked.

[Insomnia](https://insomnia.rest) plugin for API Mocked.

- Import Collection & Requests.
- Download Binary to run the server.