const HCL = require("js-hcl-parser")
const fs = require("fs")
const path = require("path")
const uuid = require('uuid');

class createInsomnia {

  constructor(context) {
    this.context = context
    this.importJsonObject = {
      _type: "export",
      __export_format: 4,
    }

    this.requestsArr = [];
    this.baseUrl = "https://localhost"
    this.httpServices = [];
    this.createCollection()
    this.createBaseEnvironment()
  }

  createInsomniaJson() {
    return new Promise(async (resolve, reject) => {
      let config = path.join(__dirname, '../../config.hcl')
      fs.readFile(config, "utf8", async (error, data) => {
        if (error) {
          throw error;
        }
        const hclInput = data.toString();
        const hclObj = JSON.parse(HCL.parse(hclInput))

        this.httpServices = hclObj.http;
        
        await this.createEnvironment();
        // console.log("==========", this.requestsArr)
        await Promise.all(hclObj.path.map(async route => {
          for (const property in route) {
            let pathDescription = route[property][0].path_description;
            
            const pathRoute = property;
            let reqName = pathRoute
            if (reqName.includes('/')) {
              reqName = reqName.replace(/\//g, "")
              reqName = reqName.toUpperCase()
            }
            return await Promise.all(route[property].map(async requests => {
              let reqObjFirst = await Promise.all(requests.request.map(async request => {
                let reqObj = {}
                for (const method in request) {
                  let name = `${reqName}_${method.toUpperCase()}`
                  let req_uuid = await this.context.store.getItem(name);

                  if (!req_uuid) {
                    req_uuid = `req_${uuid.v4().replace(/-/g, "")}`;
                    await this.context.store.setItem(name, req_uuid);
                  }
                  reqObj = {
                    _id: req_uuid,
                    parentId: this.collection._id,
                    method,
                    url: `{{ _.base_url }}:{{ _.port }}${pathRoute}`,
                    name: pathDescription,
                    description: pathDescription,
                    body: {},
                    parameters: [],
                    headers: [],
                    authentication: {},
                    isPrivate: false,
                    settingStoreCookies: true,
                    settingSendCookies: true,
                    settingDisableRenderRequestBody: false,
                    settingEncodeUrl: true,
                    settingRebuildPath: true,
                    settingFollowRedirects: "global",
                    _type: "request"
                  }
                  return reqObj
                }
              }))
              this.requestsArr.push(reqObjFirst[0])
              return
            }))
          }
        }))

        this.importJsonObject = { ...this.importJsonObject, resources: this.requestsArr }
        resolve(this.importJsonObject)
      });
    })
  }

  async createCollection() {
    let name = 'API Mocked'
    let wrk_uuid = await this.context.store.getItem(name);
    if (!wrk_uuid) {
      wrk_uuid = `wrk_${uuid.v4().replace(/-/g, "")}`;
      await this.context.store.setItem(name, wrk_uuid);
    }
    this.collection = {
      _id: wrk_uuid,
      parentId: null,
      name: "API Mocked",
      description: "",
      scope: "collection",
      _type: "workspace"
    }
    this.requestsArr.push(this.collection)
  }

  async createBaseEnvironment() {
    let name = 'API Mocked Base Environment'
    let env_uuid = await this.context.store.getItem(name);
    if (!env_uuid) {
      env_uuid = `env_${uuid.v4().replace(/-/g, "")}`;
      await this.context.store.setItem(name, env_uuid);
    }
    this.baseEnv = {
      _id: env_uuid,
      parentId: this.collection._id,
      name,
      data: {},
      dataPropertyOrder: null,
      color: null,
      isPrivate: false,
      _type: "environment"
    }
    this.requestsArr.push(this.baseEnv)
  }

  async createEnvironment() {
    let index = 0;
    for (const request of this.httpServices) {
      let name = request.service[0].name || `API Mocked Environment ${ index ? index : '' }`
      let env_uuid = await this.context.store.getItem(name);
      index += 1;
      if (!env_uuid) {
        env_uuid = `env_${uuid.v4().replace(/-/g, "")}`;
        await this.context.store.setItem(name, env_uuid);
      }
      // const stamp = new Date().getTime();
      const newEnv = {
        _id: env_uuid,
        parentId: this.baseEnv._id,
        name,
        data: {
          "base_url": "https://localhost",
          "port": request.service[0].host.replace(/:/g, "")
        },
        dataPropertyOrder: {
          "&": [
            "base_url",
            "port"
          ]
        },
        color: null,
        isPrivate: false,
        _type: "environment",
        // modified: stamp,
        // created: stamp,
        // metaSortKey: stamp
      }
      this.requestsArr.push(newEnv);
    }
  }
}

module.exports = createInsomnia