http "service" {
    host = ":8888"
    ssl {
        # lets_encrypt = ["service.api-mocked.com"]
    }
}

path "/ping" {
    _-= "A simple endpoint to check if things are working"
    path_description = "Ping server."

    request "get" {
        order = "random"
        response "200" {
            body = "OK"
        }

        response "200" {
            body = "Works"
        }

        response "200" {
            body = "Pong"
        }

        # Sometimes return a 500, to see what happens with our application
        response "500" {
            body = "Internal Server Error (OK)"
        }
    }
}

path "/users" {
    _-= "A simple endpoint to check if things are working"
    
    path_description="Get the list of users."

    request "get" {
        order = "random"
        response "200" {
            body = "OK"
        }

        response "200" {
            body = "Works"
        }

        response "200" {
            body = "Pong"
        }

        # Sometimes return a 500, to see what happens with our application
        response "500" {
            body = "Internal Server Error (OK)"
        }
    }
}

path "/events" {
    _-= "A simple endpoint to check if things are working"
    path_description = "Get list of events."

    request "get" {
        order = "random"
        response "200" {
            body = "OK"
        }

        response "200" {
            body = "Works"
        }

        response "200" {
            body = "Pong"
        }

        # Sometimes return a 500, to see what happens with our application
        response "500" {
            body = "Internal Server Error (OK)"
        }
    }
}

path "/devices" {
    _-= "A simple endpoint to check if things are working"
    path_description = "Get active devices."

    request "get" {
        order = "random"
        response "200" {
            body = "OK"
        }

        response "200" {
            body = "Works"
        }

        response "200" {
            body = "Pong"
        }

        # Sometimes return a 500, to see what happens with our application
        response "500" {
            body = "Internal Server Error (OK)"
        }
    }
}