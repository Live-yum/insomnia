const fs = require('fs');
const path = require('path')
const { execSync } = require('child_process');

const getCommandLine = () => {
  switch (process.platform) {
    case 'darwin': return 'open -e';
    case 'win32': return 'start';
    case 'win64': return 'start';
    default: return 'xdg-open';
  }
}

const openConfig = () => {
  return new Promise(async (resolve, reject) => {
    let config = path.join(__dirname, '../../config.hcl')
    try {
      if (fs.existsSync(config)) {
        config = process.platform == 'darwin' ? `"${config}"` : config;
        try {
          execSync(`${getCommandLine()} ${config}`);
          resolve()
        } catch (e) {
          console.log(e);
          reject('Something went wrong.')
        }
      } else {
        reject('Config file not found.')
      }
    } catch (err) {
      reject('Something went wrong.')
    }
  })
}

module.exports = openConfig
