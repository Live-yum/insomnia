const fs = require('fs');
const path = require('path')
const { exec, execFile } = require('child_process');
class Server {

  processId = null;
  config = path.join(__dirname, '../../config.hcl')

  messages = {
    success: 'Server started successfully.',
    running: 'Server is already running.',
    error: 'Something went wrong!'
  }
  isWin = ["win32", "win64"].includes(process.platform)

  constructor() {
    this.executable = path.join(__dirname, `../../api-mocked${this.isWin ? '.exe' : ''}`)
  }

  start() {
    return new Promise(async (resolve, reject) => {
      try {
        if (this.processId) {
          reject(this.messages.running)
          return;
        }
        this.executeCommand(this.executable, this.config).then(response => {
          resolve(this.messages.success)
        }).catch(e => { reject(this.messages.error) });
      } catch (e) {
        reject(this.messages.error)
      }
    })
  }

  reset() {
    this.processId = null;
  }

  async stop() {
    if (this.processId) {
      await this.processId.kill()
      this.processId = null
    } else if (process.env.processId) {
      let command = `kill -9 ${process.env.processId}`
      if (this.isWin) command = `taskkill /F /PID ${process.env.processId}`
      await exec(command);
    };
    delete process.env.processId;
  }

  executeCommand(executable, config) {
    return new Promise(async (resolve, reject) => {
      try {
        if (fs.existsSync(executable) && fs.existsSync(config)) {
          this.processId = await execFile(executable, ['-config', config], {
            cwd: `${path.join(__dirname, './')}`,
          }, (err, stdout, stderr) => {
            if (err) {
              reject()
            }
            resolve()
          });
          if (this.processId && this.processId.pid) {
            process.env.processId = this.processId.pid;
            await localStorage.setItem('processId', this.processId.pid)
          }
          resolve()
        } else {
          reject()
        }
      } catch (e) {
        reject()
      }
    })
  }
}

module.exports = Server