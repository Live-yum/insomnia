global.XMLHttpRequest = undefined;
const fs = require('fs');
const path = require('path')
const axios = require('axios')
const decompress = require('decompress')
const { exec } = require('child_process');

const downloadBinary = async (platform) => {
	return new Promise(async (resolve, reject) => {
		try {
			let ext = 'tar.gz'
			const isWin = ["win32", "win64"].includes(platform);
			if (isWin) {
				platform = 'windows'
				ext = 'zip'
			}

			const version = '0.1.0'

			let fileName = `api-mocked-v${version}-${platform}-amd64.${ext}`

			const fileStream = fs.createWriteStream(path.join(__dirname, `../../${fileName}`));

			const url = `https://github.com/njones/api-mocked/releases/download/v${version}/${fileName}`

			fs.copyFileSync(path.join(__dirname, 'config.hcl'), path.join(__dirname, '../../config.hcl'));

			const response = await axios({
				method: 'GET',
				url: url,
				responseType: 'stream'
			})

			response.data.pipe(fileStream).on('close', async function () {
				console.log('File written!');
				try {
					if (process.env.processId) {
						let command = `kill -9 ${process.env.processId}`
						if (isWin) command = `taskkill /F /PID ${process.env.processId}`
						await exec(command);
						delete process.env.processId;
					}
					await decompress(path.join(__dirname, `../../${fileName}`), path.join(__dirname, '../../'))
					resolve()
				} catch (err) {
					console.log('extraxt error', err)
					reject()
				}
			});

		} catch (e) {
			console.log(e)
			reject()
		}
	})

}

module.exports = {
	downloadBinary
}