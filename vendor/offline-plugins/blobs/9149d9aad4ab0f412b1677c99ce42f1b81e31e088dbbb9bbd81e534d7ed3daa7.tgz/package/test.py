import hkdf

print "hoooo"

blah = hkdf.HKDF('initialKeyingMaterial', 42)
ret = "".join("{:02x}".format(ord(c)) for c in blah)

#print len(ret)
print ret

#hkdf.power_on_self_test()
