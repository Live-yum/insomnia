"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// node_modules/@babel/runtime/helpers/extends.js
var require_extends = __commonJS({
  "node_modules/@babel/runtime/helpers/extends.js"(exports, module2) {
    function _extends() {
      module2.exports = _extends = Object.assign ? Object.assign.bind() : function(target) {
        for (var i = 1; i < arguments.length; i++) {
          var source = arguments[i];
          for (var key in source) {
            if (Object.prototype.hasOwnProperty.call(source, key)) {
              target[key] = source[key];
            }
          }
        }
        return target;
      }, module2.exports.__esModule = true, module2.exports["default"] = module2.exports;
      return _extends.apply(this, arguments);
    }
    module2.exports = _extends, module2.exports.__esModule = true, module2.exports["default"] = module2.exports;
  }
});

// node_modules/@babel/runtime/helpers/arrayWithHoles.js
var require_arrayWithHoles = __commonJS({
  "node_modules/@babel/runtime/helpers/arrayWithHoles.js"(exports, module2) {
    function _arrayWithHoles(arr) {
      if (Array.isArray(arr))
        return arr;
    }
    module2.exports = _arrayWithHoles, module2.exports.__esModule = true, module2.exports["default"] = module2.exports;
  }
});

// node_modules/@babel/runtime/helpers/iterableToArrayLimit.js
var require_iterableToArrayLimit = __commonJS({
  "node_modules/@babel/runtime/helpers/iterableToArrayLimit.js"(exports, module2) {
    function _iterableToArrayLimit(arr, i) {
      var _i = null == arr ? null : "undefined" != typeof Symbol && arr[Symbol.iterator] || arr["@@iterator"];
      if (null != _i) {
        var _s, _e, _x, _r, _arr = [], _n = true, _d = false;
        try {
          if (_x = (_i = _i.call(arr)).next, 0 === i) {
            if (Object(_i) !== _i)
              return;
            _n = false;
          } else
            for (; !(_n = (_s = _x.call(_i)).done) && (_arr.push(_s.value), _arr.length !== i); _n = true)
              ;
        } catch (err) {
          _d = true, _e = err;
        } finally {
          try {
            if (!_n && null != _i["return"] && (_r = _i["return"](), Object(_r) !== _r))
              return;
          } finally {
            if (_d)
              throw _e;
          }
        }
        return _arr;
      }
    }
    module2.exports = _iterableToArrayLimit, module2.exports.__esModule = true, module2.exports["default"] = module2.exports;
  }
});

// node_modules/@babel/runtime/helpers/arrayLikeToArray.js
var require_arrayLikeToArray = __commonJS({
  "node_modules/@babel/runtime/helpers/arrayLikeToArray.js"(exports, module2) {
    function _arrayLikeToArray(arr, len) {
      if (len == null || len > arr.length)
        len = arr.length;
      for (var i = 0, arr2 = new Array(len); i < len; i++)
        arr2[i] = arr[i];
      return arr2;
    }
    module2.exports = _arrayLikeToArray, module2.exports.__esModule = true, module2.exports["default"] = module2.exports;
  }
});

// node_modules/@babel/runtime/helpers/unsupportedIterableToArray.js
var require_unsupportedIterableToArray = __commonJS({
  "node_modules/@babel/runtime/helpers/unsupportedIterableToArray.js"(exports, module2) {
    var arrayLikeToArray = require_arrayLikeToArray();
    function _unsupportedIterableToArray(o, minLen) {
      if (!o)
        return;
      if (typeof o === "string")
        return arrayLikeToArray(o, minLen);
      var n = Object.prototype.toString.call(o).slice(8, -1);
      if (n === "Object" && o.constructor)
        n = o.constructor.name;
      if (n === "Map" || n === "Set")
        return Array.from(o);
      if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n))
        return arrayLikeToArray(o, minLen);
    }
    module2.exports = _unsupportedIterableToArray, module2.exports.__esModule = true, module2.exports["default"] = module2.exports;
  }
});

// node_modules/@babel/runtime/helpers/nonIterableRest.js
var require_nonIterableRest = __commonJS({
  "node_modules/@babel/runtime/helpers/nonIterableRest.js"(exports, module2) {
    function _nonIterableRest() {
      throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
    }
    module2.exports = _nonIterableRest, module2.exports.__esModule = true, module2.exports["default"] = module2.exports;
  }
});

// node_modules/@babel/runtime/helpers/slicedToArray.js
var require_slicedToArray = __commonJS({
  "node_modules/@babel/runtime/helpers/slicedToArray.js"(exports, module2) {
    var arrayWithHoles = require_arrayWithHoles();
    var iterableToArrayLimit = require_iterableToArrayLimit();
    var unsupportedIterableToArray = require_unsupportedIterableToArray();
    var nonIterableRest = require_nonIterableRest();
    function _slicedToArray(arr, i) {
      return arrayWithHoles(arr) || iterableToArrayLimit(arr, i) || unsupportedIterableToArray(arr, i) || nonIterableRest();
    }
    module2.exports = _slicedToArray, module2.exports.__esModule = true, module2.exports["default"] = module2.exports;
  }
});

// node_modules/@babel/runtime/helpers/typeof.js
var require_typeof = __commonJS({
  "node_modules/@babel/runtime/helpers/typeof.js"(exports, module2) {
    function _typeof(obj) {
      "@babel/helpers - typeof";
      return module2.exports = _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(obj2) {
        return typeof obj2;
      } : function(obj2) {
        return obj2 && "function" == typeof Symbol && obj2.constructor === Symbol && obj2 !== Symbol.prototype ? "symbol" : typeof obj2;
      }, module2.exports.__esModule = true, module2.exports["default"] = module2.exports, _typeof(obj);
    }
    module2.exports = _typeof, module2.exports.__esModule = true, module2.exports["default"] = module2.exports;
  }
});

// node_modules/@babel/runtime/helpers/toPrimitive.js
var require_toPrimitive = __commonJS({
  "node_modules/@babel/runtime/helpers/toPrimitive.js"(exports, module2) {
    var _typeof = require_typeof()["default"];
    function _toPrimitive(input, hint) {
      if (_typeof(input) !== "object" || input === null)
        return input;
      var prim = input[Symbol.toPrimitive];
      if (prim !== void 0) {
        var res = prim.call(input, hint || "default");
        if (_typeof(res) !== "object")
          return res;
        throw new TypeError("@@toPrimitive must return a primitive value.");
      }
      return (hint === "string" ? String : Number)(input);
    }
    module2.exports = _toPrimitive, module2.exports.__esModule = true, module2.exports["default"] = module2.exports;
  }
});

// node_modules/@babel/runtime/helpers/toPropertyKey.js
var require_toPropertyKey = __commonJS({
  "node_modules/@babel/runtime/helpers/toPropertyKey.js"(exports, module2) {
    var _typeof = require_typeof()["default"];
    var toPrimitive = require_toPrimitive();
    function _toPropertyKey(arg) {
      var key = toPrimitive(arg, "string");
      return _typeof(key) === "symbol" ? key : String(key);
    }
    module2.exports = _toPropertyKey, module2.exports.__esModule = true, module2.exports["default"] = module2.exports;
  }
});

// node_modules/@babel/runtime/helpers/defineProperty.js
var require_defineProperty = __commonJS({
  "node_modules/@babel/runtime/helpers/defineProperty.js"(exports, module2) {
    var toPropertyKey = require_toPropertyKey();
    function _defineProperty(obj, key, value2) {
      key = toPropertyKey(key);
      if (key in obj) {
        Object.defineProperty(obj, key, {
          value: value2,
          enumerable: true,
          configurable: true,
          writable: true
        });
      } else {
        obj[key] = value2;
      }
      return obj;
    }
    module2.exports = _defineProperty, module2.exports.__esModule = true, module2.exports["default"] = module2.exports;
  }
});

// node_modules/@babel/runtime/helpers/objectSpread.js
var require_objectSpread = __commonJS({
  "node_modules/@babel/runtime/helpers/objectSpread.js"(exports, module2) {
    var defineProperty = require_defineProperty();
    function _objectSpread(target) {
      for (var i = 1; i < arguments.length; i++) {
        var source = arguments[i] != null ? Object(arguments[i]) : {};
        var ownKeys = Object.keys(source);
        if (typeof Object.getOwnPropertySymbols === "function") {
          ownKeys.push.apply(ownKeys, Object.getOwnPropertySymbols(source).filter(function(sym) {
            return Object.getOwnPropertyDescriptor(source, sym).enumerable;
          }));
        }
        ownKeys.forEach(function(key) {
          defineProperty(target, key, source[key]);
        });
      }
      return target;
    }
    module2.exports = _objectSpread, module2.exports.__esModule = true, module2.exports["default"] = module2.exports;
  }
});

// node_modules/@babel/runtime/helpers/classCallCheck.js
var require_classCallCheck = __commonJS({
  "node_modules/@babel/runtime/helpers/classCallCheck.js"(exports, module2) {
    function _classCallCheck(instance, Constructor) {
      if (!(instance instanceof Constructor)) {
        throw new TypeError("Cannot call a class as a function");
      }
    }
    module2.exports = _classCallCheck, module2.exports.__esModule = true, module2.exports["default"] = module2.exports;
  }
});

// node_modules/@babel/runtime/helpers/createClass.js
var require_createClass = __commonJS({
  "node_modules/@babel/runtime/helpers/createClass.js"(exports, module2) {
    var toPropertyKey = require_toPropertyKey();
    function _defineProperties(target, props) {
      for (var i = 0; i < props.length; i++) {
        var descriptor = props[i];
        descriptor.enumerable = descriptor.enumerable || false;
        descriptor.configurable = true;
        if ("value" in descriptor)
          descriptor.writable = true;
        Object.defineProperty(target, toPropertyKey(descriptor.key), descriptor);
      }
    }
    function _createClass(Constructor, protoProps, staticProps) {
      if (protoProps)
        _defineProperties(Constructor.prototype, protoProps);
      if (staticProps)
        _defineProperties(Constructor, staticProps);
      Object.defineProperty(Constructor, "prototype", {
        writable: false
      });
      return Constructor;
    }
    module2.exports = _createClass, module2.exports.__esModule = true, module2.exports["default"] = module2.exports;
  }
});

// node_modules/@babel/runtime/helpers/assertThisInitialized.js
var require_assertThisInitialized = __commonJS({
  "node_modules/@babel/runtime/helpers/assertThisInitialized.js"(exports, module2) {
    function _assertThisInitialized(self) {
      if (self === void 0) {
        throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
      }
      return self;
    }
    module2.exports = _assertThisInitialized, module2.exports.__esModule = true, module2.exports["default"] = module2.exports;
  }
});

// node_modules/@babel/runtime/helpers/possibleConstructorReturn.js
var require_possibleConstructorReturn = __commonJS({
  "node_modules/@babel/runtime/helpers/possibleConstructorReturn.js"(exports, module2) {
    var _typeof = require_typeof()["default"];
    var assertThisInitialized = require_assertThisInitialized();
    function _possibleConstructorReturn(self, call) {
      if (call && (_typeof(call) === "object" || typeof call === "function")) {
        return call;
      } else if (call !== void 0) {
        throw new TypeError("Derived constructors may only return object or undefined");
      }
      return assertThisInitialized(self);
    }
    module2.exports = _possibleConstructorReturn, module2.exports.__esModule = true, module2.exports["default"] = module2.exports;
  }
});

// node_modules/@babel/runtime/helpers/getPrototypeOf.js
var require_getPrototypeOf = __commonJS({
  "node_modules/@babel/runtime/helpers/getPrototypeOf.js"(exports, module2) {
    function _getPrototypeOf(o) {
      module2.exports = _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function _getPrototypeOf2(o2) {
        return o2.__proto__ || Object.getPrototypeOf(o2);
      }, module2.exports.__esModule = true, module2.exports["default"] = module2.exports;
      return _getPrototypeOf(o);
    }
    module2.exports = _getPrototypeOf, module2.exports.__esModule = true, module2.exports["default"] = module2.exports;
  }
});

// node_modules/@babel/runtime/helpers/setPrototypeOf.js
var require_setPrototypeOf = __commonJS({
  "node_modules/@babel/runtime/helpers/setPrototypeOf.js"(exports, module2) {
    function _setPrototypeOf(o, p) {
      module2.exports = _setPrototypeOf = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function _setPrototypeOf2(o2, p2) {
        o2.__proto__ = p2;
        return o2;
      }, module2.exports.__esModule = true, module2.exports["default"] = module2.exports;
      return _setPrototypeOf(o, p);
    }
    module2.exports = _setPrototypeOf, module2.exports.__esModule = true, module2.exports["default"] = module2.exports;
  }
});

// node_modules/@babel/runtime/helpers/inherits.js
var require_inherits = __commonJS({
  "node_modules/@babel/runtime/helpers/inherits.js"(exports, module2) {
    var setPrototypeOf = require_setPrototypeOf();
    function _inherits(subClass, superClass) {
      if (typeof superClass !== "function" && superClass !== null) {
        throw new TypeError("Super expression must either be null or a function");
      }
      subClass.prototype = Object.create(superClass && superClass.prototype, {
        constructor: {
          value: subClass,
          writable: true,
          configurable: true
        }
      });
      Object.defineProperty(subClass, "prototype", {
        writable: false
      });
      if (superClass)
        setPrototypeOf(subClass, superClass);
    }
    module2.exports = _inherits, module2.exports.__esModule = true, module2.exports["default"] = module2.exports;
  }
});

// node_modules/invariant/invariant.js
var require_invariant = __commonJS({
  "node_modules/invariant/invariant.js"(exports, module2) {
    "use strict";
    var NODE_ENV = process.env.NODE_ENV;
    var invariant = function(condition, format, a, b, c, d, e, f) {
      if (NODE_ENV !== "production") {
        if (format === void 0) {
          throw new Error("invariant requires an error message argument");
        }
      }
      if (!condition) {
        var error;
        if (format === void 0) {
          error = new Error(
            "Minified exception occurred; use the non-minified dev environment for the full error message and additional helpful warnings."
          );
        } else {
          var args = [a, b, c, d, e, f];
          var argIndex = 0;
          error = new Error(
            format.replace(/%s/g, function() {
              return args[argIndex++];
            })
          );
          error.name = "Invariant Violation";
        }
        error.framesToPop = 1;
        throw error;
      }
    };
    module2.exports = invariant;
  }
});

// node_modules/@babel/runtime/helpers/arrayWithoutHoles.js
var require_arrayWithoutHoles = __commonJS({
  "node_modules/@babel/runtime/helpers/arrayWithoutHoles.js"(exports, module2) {
    var arrayLikeToArray = require_arrayLikeToArray();
    function _arrayWithoutHoles(arr) {
      if (Array.isArray(arr))
        return arrayLikeToArray(arr);
    }
    module2.exports = _arrayWithoutHoles, module2.exports.__esModule = true, module2.exports["default"] = module2.exports;
  }
});

// node_modules/@babel/runtime/helpers/iterableToArray.js
var require_iterableToArray = __commonJS({
  "node_modules/@babel/runtime/helpers/iterableToArray.js"(exports, module2) {
    function _iterableToArray(iter) {
      if (typeof Symbol !== "undefined" && iter[Symbol.iterator] != null || iter["@@iterator"] != null)
        return Array.from(iter);
    }
    module2.exports = _iterableToArray, module2.exports.__esModule = true, module2.exports["default"] = module2.exports;
  }
});

// node_modules/@babel/runtime/helpers/nonIterableSpread.js
var require_nonIterableSpread = __commonJS({
  "node_modules/@babel/runtime/helpers/nonIterableSpread.js"(exports, module2) {
    function _nonIterableSpread() {
      throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
    }
    module2.exports = _nonIterableSpread, module2.exports.__esModule = true, module2.exports["default"] = module2.exports;
  }
});

// node_modules/@babel/runtime/helpers/toConsumableArray.js
var require_toConsumableArray = __commonJS({
  "node_modules/@babel/runtime/helpers/toConsumableArray.js"(exports, module2) {
    var arrayWithoutHoles = require_arrayWithoutHoles();
    var iterableToArray = require_iterableToArray();
    var unsupportedIterableToArray = require_unsupportedIterableToArray();
    var nonIterableSpread = require_nonIterableSpread();
    function _toConsumableArray(arr) {
      return arrayWithoutHoles(arr) || iterableToArray(arr) || unsupportedIterableToArray(arr) || nonIterableSpread();
    }
    module2.exports = _toConsumableArray, module2.exports.__esModule = true, module2.exports["default"] = module2.exports;
  }
});

// node_modules/react-is/cjs/react-is.production.min.js
var require_react_is_production_min = __commonJS({
  "node_modules/react-is/cjs/react-is.production.min.js"(exports) {
    "use strict";
    var b = "function" === typeof Symbol && Symbol.for;
    var c = b ? Symbol.for("react.element") : 60103;
    var d = b ? Symbol.for("react.portal") : 60106;
    var e = b ? Symbol.for("react.fragment") : 60107;
    var f = b ? Symbol.for("react.strict_mode") : 60108;
    var g = b ? Symbol.for("react.profiler") : 60114;
    var h = b ? Symbol.for("react.provider") : 60109;
    var k = b ? Symbol.for("react.context") : 60110;
    var l = b ? Symbol.for("react.async_mode") : 60111;
    var m = b ? Symbol.for("react.concurrent_mode") : 60111;
    var n = b ? Symbol.for("react.forward_ref") : 60112;
    var p = b ? Symbol.for("react.suspense") : 60113;
    var q = b ? Symbol.for("react.suspense_list") : 60120;
    var r = b ? Symbol.for("react.memo") : 60115;
    var t = b ? Symbol.for("react.lazy") : 60116;
    var v = b ? Symbol.for("react.block") : 60121;
    var w = b ? Symbol.for("react.fundamental") : 60117;
    var x = b ? Symbol.for("react.responder") : 60118;
    var y = b ? Symbol.for("react.scope") : 60119;
    function z(a) {
      if ("object" === typeof a && null !== a) {
        var u = a.$$typeof;
        switch (u) {
          case c:
            switch (a = a.type, a) {
              case l:
              case m:
              case e:
              case g:
              case f:
              case p:
                return a;
              default:
                switch (a = a && a.$$typeof, a) {
                  case k:
                  case n:
                  case t:
                  case r:
                  case h:
                    return a;
                  default:
                    return u;
                }
            }
          case d:
            return u;
        }
      }
    }
    function A(a) {
      return z(a) === m;
    }
    exports.AsyncMode = l;
    exports.ConcurrentMode = m;
    exports.ContextConsumer = k;
    exports.ContextProvider = h;
    exports.Element = c;
    exports.ForwardRef = n;
    exports.Fragment = e;
    exports.Lazy = t;
    exports.Memo = r;
    exports.Portal = d;
    exports.Profiler = g;
    exports.StrictMode = f;
    exports.Suspense = p;
    exports.isAsyncMode = function(a) {
      return A(a) || z(a) === l;
    };
    exports.isConcurrentMode = A;
    exports.isContextConsumer = function(a) {
      return z(a) === k;
    };
    exports.isContextProvider = function(a) {
      return z(a) === h;
    };
    exports.isElement = function(a) {
      return "object" === typeof a && null !== a && a.$$typeof === c;
    };
    exports.isForwardRef = function(a) {
      return z(a) === n;
    };
    exports.isFragment = function(a) {
      return z(a) === e;
    };
    exports.isLazy = function(a) {
      return z(a) === t;
    };
    exports.isMemo = function(a) {
      return z(a) === r;
    };
    exports.isPortal = function(a) {
      return z(a) === d;
    };
    exports.isProfiler = function(a) {
      return z(a) === g;
    };
    exports.isStrictMode = function(a) {
      return z(a) === f;
    };
    exports.isSuspense = function(a) {
      return z(a) === p;
    };
    exports.isValidElementType = function(a) {
      return "string" === typeof a || "function" === typeof a || a === e || a === m || a === g || a === f || a === p || a === q || "object" === typeof a && null !== a && (a.$$typeof === t || a.$$typeof === r || a.$$typeof === h || a.$$typeof === k || a.$$typeof === n || a.$$typeof === w || a.$$typeof === x || a.$$typeof === y || a.$$typeof === v);
    };
    exports.typeOf = z;
  }
});

// node_modules/react-is/cjs/react-is.development.js
var require_react_is_development = __commonJS({
  "node_modules/react-is/cjs/react-is.development.js"(exports) {
    "use strict";
    if (process.env.NODE_ENV !== "production") {
      (function() {
        "use strict";
        var hasSymbol = typeof Symbol === "function" && Symbol.for;
        var REACT_ELEMENT_TYPE = hasSymbol ? Symbol.for("react.element") : 60103;
        var REACT_PORTAL_TYPE = hasSymbol ? Symbol.for("react.portal") : 60106;
        var REACT_FRAGMENT_TYPE = hasSymbol ? Symbol.for("react.fragment") : 60107;
        var REACT_STRICT_MODE_TYPE = hasSymbol ? Symbol.for("react.strict_mode") : 60108;
        var REACT_PROFILER_TYPE = hasSymbol ? Symbol.for("react.profiler") : 60114;
        var REACT_PROVIDER_TYPE = hasSymbol ? Symbol.for("react.provider") : 60109;
        var REACT_CONTEXT_TYPE = hasSymbol ? Symbol.for("react.context") : 60110;
        var REACT_ASYNC_MODE_TYPE = hasSymbol ? Symbol.for("react.async_mode") : 60111;
        var REACT_CONCURRENT_MODE_TYPE = hasSymbol ? Symbol.for("react.concurrent_mode") : 60111;
        var REACT_FORWARD_REF_TYPE = hasSymbol ? Symbol.for("react.forward_ref") : 60112;
        var REACT_SUSPENSE_TYPE = hasSymbol ? Symbol.for("react.suspense") : 60113;
        var REACT_SUSPENSE_LIST_TYPE = hasSymbol ? Symbol.for("react.suspense_list") : 60120;
        var REACT_MEMO_TYPE = hasSymbol ? Symbol.for("react.memo") : 60115;
        var REACT_LAZY_TYPE = hasSymbol ? Symbol.for("react.lazy") : 60116;
        var REACT_BLOCK_TYPE = hasSymbol ? Symbol.for("react.block") : 60121;
        var REACT_FUNDAMENTAL_TYPE = hasSymbol ? Symbol.for("react.fundamental") : 60117;
        var REACT_RESPONDER_TYPE = hasSymbol ? Symbol.for("react.responder") : 60118;
        var REACT_SCOPE_TYPE = hasSymbol ? Symbol.for("react.scope") : 60119;
        function isValidElementType(type) {
          return typeof type === "string" || typeof type === "function" || // Note: its typeof might be other than 'symbol' or 'number' if it's a polyfill.
          type === REACT_FRAGMENT_TYPE || type === REACT_CONCURRENT_MODE_TYPE || type === REACT_PROFILER_TYPE || type === REACT_STRICT_MODE_TYPE || type === REACT_SUSPENSE_TYPE || type === REACT_SUSPENSE_LIST_TYPE || typeof type === "object" && type !== null && (type.$$typeof === REACT_LAZY_TYPE || type.$$typeof === REACT_MEMO_TYPE || type.$$typeof === REACT_PROVIDER_TYPE || type.$$typeof === REACT_CONTEXT_TYPE || type.$$typeof === REACT_FORWARD_REF_TYPE || type.$$typeof === REACT_FUNDAMENTAL_TYPE || type.$$typeof === REACT_RESPONDER_TYPE || type.$$typeof === REACT_SCOPE_TYPE || type.$$typeof === REACT_BLOCK_TYPE);
        }
        function typeOf(object) {
          if (typeof object === "object" && object !== null) {
            var $$typeof = object.$$typeof;
            switch ($$typeof) {
              case REACT_ELEMENT_TYPE:
                var type = object.type;
                switch (type) {
                  case REACT_ASYNC_MODE_TYPE:
                  case REACT_CONCURRENT_MODE_TYPE:
                  case REACT_FRAGMENT_TYPE:
                  case REACT_PROFILER_TYPE:
                  case REACT_STRICT_MODE_TYPE:
                  case REACT_SUSPENSE_TYPE:
                    return type;
                  default:
                    var $$typeofType = type && type.$$typeof;
                    switch ($$typeofType) {
                      case REACT_CONTEXT_TYPE:
                      case REACT_FORWARD_REF_TYPE:
                      case REACT_LAZY_TYPE:
                      case REACT_MEMO_TYPE:
                      case REACT_PROVIDER_TYPE:
                        return $$typeofType;
                      default:
                        return $$typeof;
                    }
                }
              case REACT_PORTAL_TYPE:
                return $$typeof;
            }
          }
          return void 0;
        }
        var AsyncMode = REACT_ASYNC_MODE_TYPE;
        var ConcurrentMode = REACT_CONCURRENT_MODE_TYPE;
        var ContextConsumer = REACT_CONTEXT_TYPE;
        var ContextProvider = REACT_PROVIDER_TYPE;
        var Element = REACT_ELEMENT_TYPE;
        var ForwardRef = REACT_FORWARD_REF_TYPE;
        var Fragment = REACT_FRAGMENT_TYPE;
        var Lazy = REACT_LAZY_TYPE;
        var Memo = REACT_MEMO_TYPE;
        var Portal = REACT_PORTAL_TYPE;
        var Profiler = REACT_PROFILER_TYPE;
        var StrictMode = REACT_STRICT_MODE_TYPE;
        var Suspense = REACT_SUSPENSE_TYPE;
        var hasWarnedAboutDeprecatedIsAsyncMode = false;
        function isAsyncMode(object) {
          {
            if (!hasWarnedAboutDeprecatedIsAsyncMode) {
              hasWarnedAboutDeprecatedIsAsyncMode = true;
              console["warn"]("The ReactIs.isAsyncMode() alias has been deprecated, and will be removed in React 17+. Update your code to use ReactIs.isConcurrentMode() instead. It has the exact same API.");
            }
          }
          return isConcurrentMode(object) || typeOf(object) === REACT_ASYNC_MODE_TYPE;
        }
        function isConcurrentMode(object) {
          return typeOf(object) === REACT_CONCURRENT_MODE_TYPE;
        }
        function isContextConsumer(object) {
          return typeOf(object) === REACT_CONTEXT_TYPE;
        }
        function isContextProvider(object) {
          return typeOf(object) === REACT_PROVIDER_TYPE;
        }
        function isElement(object) {
          return typeof object === "object" && object !== null && object.$$typeof === REACT_ELEMENT_TYPE;
        }
        function isForwardRef(object) {
          return typeOf(object) === REACT_FORWARD_REF_TYPE;
        }
        function isFragment(object) {
          return typeOf(object) === REACT_FRAGMENT_TYPE;
        }
        function isLazy(object) {
          return typeOf(object) === REACT_LAZY_TYPE;
        }
        function isMemo(object) {
          return typeOf(object) === REACT_MEMO_TYPE;
        }
        function isPortal(object) {
          return typeOf(object) === REACT_PORTAL_TYPE;
        }
        function isProfiler(object) {
          return typeOf(object) === REACT_PROFILER_TYPE;
        }
        function isStrictMode(object) {
          return typeOf(object) === REACT_STRICT_MODE_TYPE;
        }
        function isSuspense(object) {
          return typeOf(object) === REACT_SUSPENSE_TYPE;
        }
        exports.AsyncMode = AsyncMode;
        exports.ConcurrentMode = ConcurrentMode;
        exports.ContextConsumer = ContextConsumer;
        exports.ContextProvider = ContextProvider;
        exports.Element = Element;
        exports.ForwardRef = ForwardRef;
        exports.Fragment = Fragment;
        exports.Lazy = Lazy;
        exports.Memo = Memo;
        exports.Portal = Portal;
        exports.Profiler = Profiler;
        exports.StrictMode = StrictMode;
        exports.Suspense = Suspense;
        exports.isAsyncMode = isAsyncMode;
        exports.isConcurrentMode = isConcurrentMode;
        exports.isContextConsumer = isContextConsumer;
        exports.isContextProvider = isContextProvider;
        exports.isElement = isElement;
        exports.isForwardRef = isForwardRef;
        exports.isFragment = isFragment;
        exports.isLazy = isLazy;
        exports.isMemo = isMemo;
        exports.isPortal = isPortal;
        exports.isProfiler = isProfiler;
        exports.isStrictMode = isStrictMode;
        exports.isSuspense = isSuspense;
        exports.isValidElementType = isValidElementType;
        exports.typeOf = typeOf;
      })();
    }
  }
});

// node_modules/react-is/index.js
var require_react_is = __commonJS({
  "node_modules/react-is/index.js"(exports, module2) {
    "use strict";
    if (process.env.NODE_ENV === "production") {
      module2.exports = require_react_is_production_min();
    } else {
      module2.exports = require_react_is_development();
    }
  }
});

// node_modules/object-assign/index.js
var require_object_assign = __commonJS({
  "node_modules/object-assign/index.js"(exports, module2) {
    "use strict";
    var getOwnPropertySymbols = Object.getOwnPropertySymbols;
    var hasOwnProperty = Object.prototype.hasOwnProperty;
    var propIsEnumerable = Object.prototype.propertyIsEnumerable;
    function toObject(val) {
      if (val === null || val === void 0) {
        throw new TypeError("Object.assign cannot be called with null or undefined");
      }
      return Object(val);
    }
    function shouldUseNative() {
      try {
        if (!Object.assign) {
          return false;
        }
        var test1 = new String("abc");
        test1[5] = "de";
        if (Object.getOwnPropertyNames(test1)[0] === "5") {
          return false;
        }
        var test2 = {};
        for (var i = 0; i < 10; i++) {
          test2["_" + String.fromCharCode(i)] = i;
        }
        var order2 = Object.getOwnPropertyNames(test2).map(function(n) {
          return test2[n];
        });
        if (order2.join("") !== "0123456789") {
          return false;
        }
        var test3 = {};
        "abcdefghijklmnopqrst".split("").forEach(function(letter) {
          test3[letter] = letter;
        });
        if (Object.keys(Object.assign({}, test3)).join("") !== "abcdefghijklmnopqrst") {
          return false;
        }
        return true;
      } catch (err) {
        return false;
      }
    }
    module2.exports = shouldUseNative() ? Object.assign : function(target, source) {
      var from;
      var to = toObject(target);
      var symbols;
      for (var s = 1; s < arguments.length; s++) {
        from = Object(arguments[s]);
        for (var key in from) {
          if (hasOwnProperty.call(from, key)) {
            to[key] = from[key];
          }
        }
        if (getOwnPropertySymbols) {
          symbols = getOwnPropertySymbols(from);
          for (var i = 0; i < symbols.length; i++) {
            if (propIsEnumerable.call(from, symbols[i])) {
              to[symbols[i]] = from[symbols[i]];
            }
          }
        }
      }
      return to;
    };
  }
});

// node_modules/prop-types/lib/ReactPropTypesSecret.js
var require_ReactPropTypesSecret = __commonJS({
  "node_modules/prop-types/lib/ReactPropTypesSecret.js"(exports, module2) {
    "use strict";
    var ReactPropTypesSecret = "SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED";
    module2.exports = ReactPropTypesSecret;
  }
});

// node_modules/prop-types/lib/has.js
var require_has = __commonJS({
  "node_modules/prop-types/lib/has.js"(exports, module2) {
    module2.exports = Function.call.bind(Object.prototype.hasOwnProperty);
  }
});

// node_modules/prop-types/checkPropTypes.js
var require_checkPropTypes = __commonJS({
  "node_modules/prop-types/checkPropTypes.js"(exports, module2) {
    "use strict";
    var printWarning = function() {
    };
    if (process.env.NODE_ENV !== "production") {
      ReactPropTypesSecret = require_ReactPropTypesSecret();
      loggedTypeFailures = {};
      has = require_has();
      printWarning = function(text) {
        var message = "Warning: " + text;
        if (typeof console !== "undefined") {
          console.error(message);
        }
        try {
          throw new Error(message);
        } catch (x) {
        }
      };
    }
    var ReactPropTypesSecret;
    var loggedTypeFailures;
    var has;
    function checkPropTypes(typeSpecs, values, location, componentName, getStack) {
      if (process.env.NODE_ENV !== "production") {
        for (var typeSpecName in typeSpecs) {
          if (has(typeSpecs, typeSpecName)) {
            var error;
            try {
              if (typeof typeSpecs[typeSpecName] !== "function") {
                var err = Error(
                  (componentName || "React class") + ": " + location + " type `" + typeSpecName + "` is invalid; it must be a function, usually from the `prop-types` package, but received `" + typeof typeSpecs[typeSpecName] + "`.This often happens because of typos such as `PropTypes.function` instead of `PropTypes.func`."
                );
                err.name = "Invariant Violation";
                throw err;
              }
              error = typeSpecs[typeSpecName](values, typeSpecName, componentName, location, null, ReactPropTypesSecret);
            } catch (ex) {
              error = ex;
            }
            if (error && !(error instanceof Error)) {
              printWarning(
                (componentName || "React class") + ": type specification of " + location + " `" + typeSpecName + "` is invalid; the type checker function must return `null` or an `Error` but returned a " + typeof error + ". You may have forgotten to pass an argument to the type checker creator (arrayOf, instanceOf, objectOf, oneOf, oneOfType, and shape all require an argument)."
              );
            }
            if (error instanceof Error && !(error.message in loggedTypeFailures)) {
              loggedTypeFailures[error.message] = true;
              var stack = getStack ? getStack() : "";
              printWarning(
                "Failed " + location + " type: " + error.message + (stack != null ? stack : "")
              );
            }
          }
        }
      }
    }
    checkPropTypes.resetWarningCache = function() {
      if (process.env.NODE_ENV !== "production") {
        loggedTypeFailures = {};
      }
    };
    module2.exports = checkPropTypes;
  }
});

// node_modules/prop-types/factoryWithTypeCheckers.js
var require_factoryWithTypeCheckers = __commonJS({
  "node_modules/prop-types/factoryWithTypeCheckers.js"(exports, module2) {
    "use strict";
    var ReactIs = require_react_is();
    var assign = require_object_assign();
    var ReactPropTypesSecret = require_ReactPropTypesSecret();
    var has = require_has();
    var checkPropTypes = require_checkPropTypes();
    var printWarning = function() {
    };
    if (process.env.NODE_ENV !== "production") {
      printWarning = function(text) {
        var message = "Warning: " + text;
        if (typeof console !== "undefined") {
          console.error(message);
        }
        try {
          throw new Error(message);
        } catch (x) {
        }
      };
    }
    function emptyFunctionThatReturnsNull() {
      return null;
    }
    module2.exports = function(isValidElement, throwOnDirectAccess) {
      var ITERATOR_SYMBOL = typeof Symbol === "function" && Symbol.iterator;
      var FAUX_ITERATOR_SYMBOL = "@@iterator";
      function getIteratorFn(maybeIterable) {
        var iteratorFn = maybeIterable && (ITERATOR_SYMBOL && maybeIterable[ITERATOR_SYMBOL] || maybeIterable[FAUX_ITERATOR_SYMBOL]);
        if (typeof iteratorFn === "function") {
          return iteratorFn;
        }
      }
      var ANONYMOUS = "<<anonymous>>";
      var ReactPropTypes = {
        array: createPrimitiveTypeChecker("array"),
        bigint: createPrimitiveTypeChecker("bigint"),
        bool: createPrimitiveTypeChecker("boolean"),
        func: createPrimitiveTypeChecker("function"),
        number: createPrimitiveTypeChecker("number"),
        object: createPrimitiveTypeChecker("object"),
        string: createPrimitiveTypeChecker("string"),
        symbol: createPrimitiveTypeChecker("symbol"),
        any: createAnyTypeChecker(),
        arrayOf: createArrayOfTypeChecker,
        element: createElementTypeChecker(),
        elementType: createElementTypeTypeChecker(),
        instanceOf: createInstanceTypeChecker,
        node: createNodeChecker(),
        objectOf: createObjectOfTypeChecker,
        oneOf: createEnumTypeChecker,
        oneOfType: createUnionTypeChecker,
        shape: createShapeTypeChecker,
        exact: createStrictShapeTypeChecker
      };
      function is(x, y) {
        if (x === y) {
          return x !== 0 || 1 / x === 1 / y;
        } else {
          return x !== x && y !== y;
        }
      }
      function PropTypeError(message, data) {
        this.message = message;
        this.data = data && typeof data === "object" ? data : {};
        this.stack = "";
      }
      PropTypeError.prototype = Error.prototype;
      function createChainableTypeChecker(validate) {
        if (process.env.NODE_ENV !== "production") {
          var manualPropTypeCallCache = {};
          var manualPropTypeWarningCount = 0;
        }
        function checkType(isRequired, props, propName, componentName, location, propFullName, secret) {
          componentName = componentName || ANONYMOUS;
          propFullName = propFullName || propName;
          if (secret !== ReactPropTypesSecret) {
            if (throwOnDirectAccess) {
              var err = new Error(
                "Calling PropTypes validators directly is not supported by the `prop-types` package. Use `PropTypes.checkPropTypes()` to call them. Read more at http://fb.me/use-check-prop-types"
              );
              err.name = "Invariant Violation";
              throw err;
            } else if (process.env.NODE_ENV !== "production" && typeof console !== "undefined") {
              var cacheKey = componentName + ":" + propName;
              if (!manualPropTypeCallCache[cacheKey] && // Avoid spamming the console because they are often not actionable except for lib authors
              manualPropTypeWarningCount < 3) {
                printWarning(
                  "You are manually calling a React.PropTypes validation function for the `" + propFullName + "` prop on `" + componentName + "`. This is deprecated and will throw in the standalone `prop-types` package. You may be seeing this warning due to a third-party PropTypes library. See https://fb.me/react-warning-dont-call-proptypes for details."
                );
                manualPropTypeCallCache[cacheKey] = true;
                manualPropTypeWarningCount++;
              }
            }
          }
          if (props[propName] == null) {
            if (isRequired) {
              if (props[propName] === null) {
                return new PropTypeError("The " + location + " `" + propFullName + "` is marked as required " + ("in `" + componentName + "`, but its value is `null`."));
              }
              return new PropTypeError("The " + location + " `" + propFullName + "` is marked as required in " + ("`" + componentName + "`, but its value is `undefined`."));
            }
            return null;
          } else {
            return validate(props, propName, componentName, location, propFullName);
          }
        }
        var chainedCheckType = checkType.bind(null, false);
        chainedCheckType.isRequired = checkType.bind(null, true);
        return chainedCheckType;
      }
      function createPrimitiveTypeChecker(expectedType) {
        function validate(props, propName, componentName, location, propFullName, secret) {
          var propValue = props[propName];
          var propType = getPropType(propValue);
          if (propType !== expectedType) {
            var preciseType = getPreciseType(propValue);
            return new PropTypeError(
              "Invalid " + location + " `" + propFullName + "` of type " + ("`" + preciseType + "` supplied to `" + componentName + "`, expected ") + ("`" + expectedType + "`."),
              { expectedType }
            );
          }
          return null;
        }
        return createChainableTypeChecker(validate);
      }
      function createAnyTypeChecker() {
        return createChainableTypeChecker(emptyFunctionThatReturnsNull);
      }
      function createArrayOfTypeChecker(typeChecker) {
        function validate(props, propName, componentName, location, propFullName) {
          if (typeof typeChecker !== "function") {
            return new PropTypeError("Property `" + propFullName + "` of component `" + componentName + "` has invalid PropType notation inside arrayOf.");
          }
          var propValue = props[propName];
          if (!Array.isArray(propValue)) {
            var propType = getPropType(propValue);
            return new PropTypeError("Invalid " + location + " `" + propFullName + "` of type " + ("`" + propType + "` supplied to `" + componentName + "`, expected an array."));
          }
          for (var i = 0; i < propValue.length; i++) {
            var error = typeChecker(propValue, i, componentName, location, propFullName + "[" + i + "]", ReactPropTypesSecret);
            if (error instanceof Error) {
              return error;
            }
          }
          return null;
        }
        return createChainableTypeChecker(validate);
      }
      function createElementTypeChecker() {
        function validate(props, propName, componentName, location, propFullName) {
          var propValue = props[propName];
          if (!isValidElement(propValue)) {
            var propType = getPropType(propValue);
            return new PropTypeError("Invalid " + location + " `" + propFullName + "` of type " + ("`" + propType + "` supplied to `" + componentName + "`, expected a single ReactElement."));
          }
          return null;
        }
        return createChainableTypeChecker(validate);
      }
      function createElementTypeTypeChecker() {
        function validate(props, propName, componentName, location, propFullName) {
          var propValue = props[propName];
          if (!ReactIs.isValidElementType(propValue)) {
            var propType = getPropType(propValue);
            return new PropTypeError("Invalid " + location + " `" + propFullName + "` of type " + ("`" + propType + "` supplied to `" + componentName + "`, expected a single ReactElement type."));
          }
          return null;
        }
        return createChainableTypeChecker(validate);
      }
      function createInstanceTypeChecker(expectedClass) {
        function validate(props, propName, componentName, location, propFullName) {
          if (!(props[propName] instanceof expectedClass)) {
            var expectedClassName = expectedClass.name || ANONYMOUS;
            var actualClassName = getClassName(props[propName]);
            return new PropTypeError("Invalid " + location + " `" + propFullName + "` of type " + ("`" + actualClassName + "` supplied to `" + componentName + "`, expected ") + ("instance of `" + expectedClassName + "`."));
          }
          return null;
        }
        return createChainableTypeChecker(validate);
      }
      function createEnumTypeChecker(expectedValues) {
        if (!Array.isArray(expectedValues)) {
          if (process.env.NODE_ENV !== "production") {
            if (arguments.length > 1) {
              printWarning(
                "Invalid arguments supplied to oneOf, expected an array, got " + arguments.length + " arguments. A common mistake is to write oneOf(x, y, z) instead of oneOf([x, y, z])."
              );
            } else {
              printWarning("Invalid argument supplied to oneOf, expected an array.");
            }
          }
          return emptyFunctionThatReturnsNull;
        }
        function validate(props, propName, componentName, location, propFullName) {
          var propValue = props[propName];
          for (var i = 0; i < expectedValues.length; i++) {
            if (is(propValue, expectedValues[i])) {
              return null;
            }
          }
          var valuesString = JSON.stringify(expectedValues, function replacer(key, value2) {
            var type = getPreciseType(value2);
            if (type === "symbol") {
              return String(value2);
            }
            return value2;
          });
          return new PropTypeError("Invalid " + location + " `" + propFullName + "` of value `" + String(propValue) + "` " + ("supplied to `" + componentName + "`, expected one of " + valuesString + "."));
        }
        return createChainableTypeChecker(validate);
      }
      function createObjectOfTypeChecker(typeChecker) {
        function validate(props, propName, componentName, location, propFullName) {
          if (typeof typeChecker !== "function") {
            return new PropTypeError("Property `" + propFullName + "` of component `" + componentName + "` has invalid PropType notation inside objectOf.");
          }
          var propValue = props[propName];
          var propType = getPropType(propValue);
          if (propType !== "object") {
            return new PropTypeError("Invalid " + location + " `" + propFullName + "` of type " + ("`" + propType + "` supplied to `" + componentName + "`, expected an object."));
          }
          for (var key in propValue) {
            if (has(propValue, key)) {
              var error = typeChecker(propValue, key, componentName, location, propFullName + "." + key, ReactPropTypesSecret);
              if (error instanceof Error) {
                return error;
              }
            }
          }
          return null;
        }
        return createChainableTypeChecker(validate);
      }
      function createUnionTypeChecker(arrayOfTypeCheckers) {
        if (!Array.isArray(arrayOfTypeCheckers)) {
          process.env.NODE_ENV !== "production" ? printWarning("Invalid argument supplied to oneOfType, expected an instance of array.") : void 0;
          return emptyFunctionThatReturnsNull;
        }
        for (var i = 0; i < arrayOfTypeCheckers.length; i++) {
          var checker = arrayOfTypeCheckers[i];
          if (typeof checker !== "function") {
            printWarning(
              "Invalid argument supplied to oneOfType. Expected an array of check functions, but received " + getPostfixForTypeWarning(checker) + " at index " + i + "."
            );
            return emptyFunctionThatReturnsNull;
          }
        }
        function validate(props, propName, componentName, location, propFullName) {
          var expectedTypes = [];
          for (var i2 = 0; i2 < arrayOfTypeCheckers.length; i2++) {
            var checker2 = arrayOfTypeCheckers[i2];
            var checkerResult = checker2(props, propName, componentName, location, propFullName, ReactPropTypesSecret);
            if (checkerResult == null) {
              return null;
            }
            if (checkerResult.data && has(checkerResult.data, "expectedType")) {
              expectedTypes.push(checkerResult.data.expectedType);
            }
          }
          var expectedTypesMessage = expectedTypes.length > 0 ? ", expected one of type [" + expectedTypes.join(", ") + "]" : "";
          return new PropTypeError("Invalid " + location + " `" + propFullName + "` supplied to " + ("`" + componentName + "`" + expectedTypesMessage + "."));
        }
        return createChainableTypeChecker(validate);
      }
      function createNodeChecker() {
        function validate(props, propName, componentName, location, propFullName) {
          if (!isNode(props[propName])) {
            return new PropTypeError("Invalid " + location + " `" + propFullName + "` supplied to " + ("`" + componentName + "`, expected a ReactNode."));
          }
          return null;
        }
        return createChainableTypeChecker(validate);
      }
      function invalidValidatorError(componentName, location, propFullName, key, type) {
        return new PropTypeError(
          (componentName || "React class") + ": " + location + " type `" + propFullName + "." + key + "` is invalid; it must be a function, usually from the `prop-types` package, but received `" + type + "`."
        );
      }
      function createShapeTypeChecker(shapeTypes) {
        function validate(props, propName, componentName, location, propFullName) {
          var propValue = props[propName];
          var propType = getPropType(propValue);
          if (propType !== "object") {
            return new PropTypeError("Invalid " + location + " `" + propFullName + "` of type `" + propType + "` " + ("supplied to `" + componentName + "`, expected `object`."));
          }
          for (var key in shapeTypes) {
            var checker = shapeTypes[key];
            if (typeof checker !== "function") {
              return invalidValidatorError(componentName, location, propFullName, key, getPreciseType(checker));
            }
            var error = checker(propValue, key, componentName, location, propFullName + "." + key, ReactPropTypesSecret);
            if (error) {
              return error;
            }
          }
          return null;
        }
        return createChainableTypeChecker(validate);
      }
      function createStrictShapeTypeChecker(shapeTypes) {
        function validate(props, propName, componentName, location, propFullName) {
          var propValue = props[propName];
          var propType = getPropType(propValue);
          if (propType !== "object") {
            return new PropTypeError("Invalid " + location + " `" + propFullName + "` of type `" + propType + "` " + ("supplied to `" + componentName + "`, expected `object`."));
          }
          var allKeys = assign({}, props[propName], shapeTypes);
          for (var key in allKeys) {
            var checker = shapeTypes[key];
            if (has(shapeTypes, key) && typeof checker !== "function") {
              return invalidValidatorError(componentName, location, propFullName, key, getPreciseType(checker));
            }
            if (!checker) {
              return new PropTypeError(
                "Invalid " + location + " `" + propFullName + "` key `" + key + "` supplied to `" + componentName + "`.\nBad object: " + JSON.stringify(props[propName], null, "  ") + "\nValid keys: " + JSON.stringify(Object.keys(shapeTypes), null, "  ")
              );
            }
            var error = checker(propValue, key, componentName, location, propFullName + "." + key, ReactPropTypesSecret);
            if (error) {
              return error;
            }
          }
          return null;
        }
        return createChainableTypeChecker(validate);
      }
      function isNode(propValue) {
        switch (typeof propValue) {
          case "number":
          case "string":
          case "undefined":
            return true;
          case "boolean":
            return !propValue;
          case "object":
            if (Array.isArray(propValue)) {
              return propValue.every(isNode);
            }
            if (propValue === null || isValidElement(propValue)) {
              return true;
            }
            var iteratorFn = getIteratorFn(propValue);
            if (iteratorFn) {
              var iterator = iteratorFn.call(propValue);
              var step;
              if (iteratorFn !== propValue.entries) {
                while (!(step = iterator.next()).done) {
                  if (!isNode(step.value)) {
                    return false;
                  }
                }
              } else {
                while (!(step = iterator.next()).done) {
                  var entry = step.value;
                  if (entry) {
                    if (!isNode(entry[1])) {
                      return false;
                    }
                  }
                }
              }
            } else {
              return false;
            }
            return true;
          default:
            return false;
        }
      }
      function isSymbol(propType, propValue) {
        if (propType === "symbol") {
          return true;
        }
        if (!propValue) {
          return false;
        }
        if (propValue["@@toStringTag"] === "Symbol") {
          return true;
        }
        if (typeof Symbol === "function" && propValue instanceof Symbol) {
          return true;
        }
        return false;
      }
      function getPropType(propValue) {
        var propType = typeof propValue;
        if (Array.isArray(propValue)) {
          return "array";
        }
        if (propValue instanceof RegExp) {
          return "object";
        }
        if (isSymbol(propType, propValue)) {
          return "symbol";
        }
        return propType;
      }
      function getPreciseType(propValue) {
        if (typeof propValue === "undefined" || propValue === null) {
          return "" + propValue;
        }
        var propType = getPropType(propValue);
        if (propType === "object") {
          if (propValue instanceof Date) {
            return "date";
          } else if (propValue instanceof RegExp) {
            return "regexp";
          }
        }
        return propType;
      }
      function getPostfixForTypeWarning(value2) {
        var type = getPreciseType(value2);
        switch (type) {
          case "array":
          case "object":
            return "an " + type;
          case "boolean":
          case "date":
          case "regexp":
            return "a " + type;
          default:
            return type;
        }
      }
      function getClassName(propValue) {
        if (!propValue.constructor || !propValue.constructor.name) {
          return ANONYMOUS;
        }
        return propValue.constructor.name;
      }
      ReactPropTypes.checkPropTypes = checkPropTypes;
      ReactPropTypes.resetWarningCache = checkPropTypes.resetWarningCache;
      ReactPropTypes.PropTypes = ReactPropTypes;
      return ReactPropTypes;
    };
  }
});

// node_modules/prop-types/factoryWithThrowingShims.js
var require_factoryWithThrowingShims = __commonJS({
  "node_modules/prop-types/factoryWithThrowingShims.js"(exports, module2) {
    "use strict";
    var ReactPropTypesSecret = require_ReactPropTypesSecret();
    function emptyFunction() {
    }
    function emptyFunctionWithReset() {
    }
    emptyFunctionWithReset.resetWarningCache = emptyFunction;
    module2.exports = function() {
      function shim(props, propName, componentName, location, propFullName, secret) {
        if (secret === ReactPropTypesSecret) {
          return;
        }
        var err = new Error(
          "Calling PropTypes validators directly is not supported by the `prop-types` package. Use PropTypes.checkPropTypes() to call them. Read more at http://fb.me/use-check-prop-types"
        );
        err.name = "Invariant Violation";
        throw err;
      }
      ;
      shim.isRequired = shim;
      function getShim() {
        return shim;
      }
      ;
      var ReactPropTypes = {
        array: shim,
        bigint: shim,
        bool: shim,
        func: shim,
        number: shim,
        object: shim,
        string: shim,
        symbol: shim,
        any: shim,
        arrayOf: getShim,
        element: shim,
        elementType: shim,
        instanceOf: getShim,
        node: shim,
        objectOf: getShim,
        oneOf: getShim,
        oneOfType: getShim,
        shape: getShim,
        exact: getShim,
        checkPropTypes: emptyFunctionWithReset,
        resetWarningCache: emptyFunction
      };
      ReactPropTypes.PropTypes = ReactPropTypes;
      return ReactPropTypes;
    };
  }
});

// node_modules/prop-types/index.js
var require_prop_types = __commonJS({
  "node_modules/prop-types/index.js"(exports, module2) {
    if (process.env.NODE_ENV !== "production") {
      ReactIs = require_react_is();
      throwOnDirectAccess = true;
      module2.exports = require_factoryWithTypeCheckers()(ReactIs.isElement, throwOnDirectAccess);
    } else {
      module2.exports = require_factoryWithThrowingShims()();
    }
    var ReactIs;
    var throwOnDirectAccess;
  }
});

// node_modules/react-sortable-hoc/dist/react-sortable-hoc.js
var require_react_sortable_hoc = __commonJS({
  "node_modules/react-sortable-hoc/dist/react-sortable-hoc.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    function _interopDefault(ex) {
      return ex && typeof ex === "object" && "default" in ex ? ex["default"] : ex;
    }
    var _extends = _interopDefault(require_extends());
    var _slicedToArray = _interopDefault(require_slicedToArray());
    var _objectSpread = _interopDefault(require_objectSpread());
    var _classCallCheck = _interopDefault(require_classCallCheck());
    var _createClass = _interopDefault(require_createClass());
    var _possibleConstructorReturn = _interopDefault(require_possibleConstructorReturn());
    var _getPrototypeOf = _interopDefault(require_getPrototypeOf());
    var _inherits = _interopDefault(require_inherits());
    var _assertThisInitialized = _interopDefault(require_assertThisInitialized());
    var _defineProperty = _interopDefault(require_defineProperty());
    var React8 = require("react");
    var reactDom = require("react-dom");
    var invariant = _interopDefault(require_invariant());
    var _toConsumableArray = _interopDefault(require_toConsumableArray());
    var PropTypes = _interopDefault(require_prop_types());
    var Manager = function() {
      function Manager2() {
        _classCallCheck(this, Manager2);
        _defineProperty(this, "refs", {});
      }
      _createClass(Manager2, [{
        key: "add",
        value: function add(collection, ref) {
          if (!this.refs[collection]) {
            this.refs[collection] = [];
          }
          this.refs[collection].push(ref);
        }
      }, {
        key: "remove",
        value: function remove(collection, ref) {
          var index = this.getIndex(collection, ref);
          if (index !== -1) {
            this.refs[collection].splice(index, 1);
          }
        }
      }, {
        key: "isActive",
        value: function isActive() {
          return this.active;
        }
      }, {
        key: "getActive",
        value: function getActive() {
          var _this = this;
          return this.refs[this.active.collection].find(function(_ref) {
            var node = _ref.node;
            return node.sortableInfo.index == _this.active.index;
          });
        }
      }, {
        key: "getIndex",
        value: function getIndex(collection, ref) {
          return this.refs[collection].indexOf(ref);
        }
      }, {
        key: "getOrderedRefs",
        value: function getOrderedRefs() {
          var collection = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : this.active.collection;
          return this.refs[collection].sort(sortByIndex);
        }
      }]);
      return Manager2;
    }();
    function sortByIndex(_ref2, _ref3) {
      var index1 = _ref2.node.sortableInfo.index;
      var index2 = _ref3.node.sortableInfo.index;
      return index1 - index2;
    }
    function arrayMove(array, from, to) {
      if (process.env.NODE_ENV !== "production") {
        if (typeof console !== "undefined") {
          console.warn("Deprecation warning: arrayMove will no longer be exported by 'react-sortable-hoc' in the next major release. Please install the `array-move` package locally instead. https://www.npmjs.com/package/array-move");
        }
      }
      array = array.slice();
      array.splice(to < 0 ? array.length + to : to, 0, array.splice(from, 1)[0]);
      return array;
    }
    function omit(obj, keysToOmit) {
      return Object.keys(obj).reduce(function(acc, key) {
        if (keysToOmit.indexOf(key) === -1) {
          acc[key] = obj[key];
        }
        return acc;
      }, {});
    }
    var events = {
      end: ["touchend", "touchcancel", "mouseup"],
      move: ["touchmove", "mousemove"],
      start: ["touchstart", "mousedown"]
    };
    var vendorPrefix = function() {
      if (typeof window === "undefined" || typeof document === "undefined") {
        return "";
      }
      var styles = window.getComputedStyle(document.documentElement, "") || ["-moz-hidden-iframe"];
      var pre = (Array.prototype.slice.call(styles).join("").match(/-(moz|webkit|ms)-/) || styles.OLink === "" && ["", "o"])[1];
      switch (pre) {
        case "ms":
          return "ms";
        default:
          return pre && pre.length ? pre[0].toUpperCase() + pre.substr(1) : "";
      }
    }();
    function setInlineStyles(node, styles) {
      Object.keys(styles).forEach(function(key) {
        node.style[key] = styles[key];
      });
    }
    function setTranslate3d(node, translate) {
      node.style["".concat(vendorPrefix, "Transform")] = translate == null ? "" : "translate3d(".concat(translate.x, "px,").concat(translate.y, "px,0)");
    }
    function setTransitionDuration(node, duration) {
      node.style["".concat(vendorPrefix, "TransitionDuration")] = duration == null ? "" : "".concat(duration, "ms");
    }
    function closest(el, fn) {
      while (el) {
        if (fn(el)) {
          return el;
        }
        el = el.parentNode;
      }
      return null;
    }
    function limit(min, max, value2) {
      return Math.max(min, Math.min(value2, max));
    }
    function getPixelValue(stringValue) {
      if (stringValue.substr(-2) === "px") {
        return parseFloat(stringValue);
      }
      return 0;
    }
    function getElementMargin(element) {
      var style = window.getComputedStyle(element);
      return {
        bottom: getPixelValue(style.marginBottom),
        left: getPixelValue(style.marginLeft),
        right: getPixelValue(style.marginRight),
        top: getPixelValue(style.marginTop)
      };
    }
    function provideDisplayName(prefix, Component) {
      var componentName = Component.displayName || Component.name;
      return componentName ? "".concat(prefix, "(").concat(componentName, ")") : prefix;
    }
    function getScrollAdjustedBoundingClientRect(node, scrollDelta) {
      var boundingClientRect = node.getBoundingClientRect();
      return {
        top: boundingClientRect.top + scrollDelta.top,
        left: boundingClientRect.left + scrollDelta.left
      };
    }
    function getPosition(event) {
      if (event.touches && event.touches.length) {
        return {
          x: event.touches[0].pageX,
          y: event.touches[0].pageY
        };
      } else if (event.changedTouches && event.changedTouches.length) {
        return {
          x: event.changedTouches[0].pageX,
          y: event.changedTouches[0].pageY
        };
      } else {
        return {
          x: event.pageX,
          y: event.pageY
        };
      }
    }
    function isTouchEvent(event) {
      return event.touches && event.touches.length || event.changedTouches && event.changedTouches.length;
    }
    function getEdgeOffset(node, parent) {
      var offset = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {
        left: 0,
        top: 0
      };
      if (!node) {
        return void 0;
      }
      var nodeOffset = {
        left: offset.left + node.offsetLeft,
        top: offset.top + node.offsetTop
      };
      if (node.parentNode === parent) {
        return nodeOffset;
      }
      return getEdgeOffset(node.parentNode, parent, nodeOffset);
    }
    function getTargetIndex(newIndex, prevIndex, oldIndex) {
      if (newIndex < oldIndex && newIndex > prevIndex) {
        return newIndex - 1;
      } else if (newIndex > oldIndex && newIndex < prevIndex) {
        return newIndex + 1;
      } else {
        return newIndex;
      }
    }
    function getLockPixelOffset(_ref) {
      var lockOffset = _ref.lockOffset, width = _ref.width, height = _ref.height;
      var offsetX = lockOffset;
      var offsetY = lockOffset;
      var unit = "px";
      if (typeof lockOffset === "string") {
        var match = /^[+-]?\d*(?:\.\d*)?(px|%)$/.exec(lockOffset);
        invariant(match !== null, 'lockOffset value should be a number or a string of a number followed by "px" or "%". Given %s', lockOffset);
        offsetX = parseFloat(lockOffset);
        offsetY = parseFloat(lockOffset);
        unit = match[1];
      }
      invariant(isFinite(offsetX) && isFinite(offsetY), "lockOffset value should be a finite. Given %s", lockOffset);
      if (unit === "%") {
        offsetX = offsetX * width / 100;
        offsetY = offsetY * height / 100;
      }
      return {
        x: offsetX,
        y: offsetY
      };
    }
    function getLockPixelOffsets(_ref2) {
      var height = _ref2.height, width = _ref2.width, lockOffset = _ref2.lockOffset;
      var offsets = Array.isArray(lockOffset) ? lockOffset : [lockOffset, lockOffset];
      invariant(offsets.length === 2, "lockOffset prop of SortableContainer should be a single value or an array of exactly two values. Given %s", lockOffset);
      var _offsets = _slicedToArray(offsets, 2), minLockOffset = _offsets[0], maxLockOffset = _offsets[1];
      return [getLockPixelOffset({
        height,
        lockOffset: minLockOffset,
        width
      }), getLockPixelOffset({
        height,
        lockOffset: maxLockOffset,
        width
      })];
    }
    function isScrollable(el) {
      var computedStyle = window.getComputedStyle(el);
      var overflowRegex = /(auto|scroll)/;
      var properties = ["overflow", "overflowX", "overflowY"];
      return properties.find(function(property) {
        return overflowRegex.test(computedStyle[property]);
      });
    }
    function getScrollingParent(el) {
      if (!(el instanceof HTMLElement)) {
        return null;
      } else if (isScrollable(el)) {
        return el;
      } else {
        return getScrollingParent(el.parentNode);
      }
    }
    function getContainerGridGap(element) {
      var style = window.getComputedStyle(element);
      if (style.display === "grid") {
        return {
          x: getPixelValue(style.gridColumnGap),
          y: getPixelValue(style.gridRowGap)
        };
      }
      return {
        x: 0,
        y: 0
      };
    }
    var KEYCODE = {
      TAB: 9,
      ESC: 27,
      SPACE: 32,
      LEFT: 37,
      UP: 38,
      RIGHT: 39,
      DOWN: 40
    };
    var NodeType = {
      Anchor: "A",
      Button: "BUTTON",
      Canvas: "CANVAS",
      Input: "INPUT",
      Option: "OPTION",
      Textarea: "TEXTAREA",
      Select: "SELECT"
    };
    function cloneNode(node) {
      var selector = "input, textarea, select, canvas, [contenteditable]";
      var fields = node.querySelectorAll(selector);
      var clonedNode = node.cloneNode(true);
      var clonedFields = _toConsumableArray(clonedNode.querySelectorAll(selector));
      clonedFields.forEach(function(field, i) {
        if (field.type !== "file") {
          field.value = fields[i].value;
        }
        if (field.type === "radio" && field.name) {
          field.name = "__sortableClone__".concat(field.name);
        }
        if (field.tagName === NodeType.Canvas && fields[i].width > 0 && fields[i].height > 0) {
          var destCtx = field.getContext("2d");
          destCtx.drawImage(fields[i], 0, 0);
        }
      });
      return clonedNode;
    }
    function sortableHandle(WrappedComponent) {
      var _class, _temp;
      var config = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {
        withRef: false
      };
      return _temp = _class = function(_React$Component) {
        _inherits(WithSortableHandle, _React$Component);
        function WithSortableHandle() {
          var _getPrototypeOf2;
          var _this;
          _classCallCheck(this, WithSortableHandle);
          for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
          }
          _this = _possibleConstructorReturn(this, (_getPrototypeOf2 = _getPrototypeOf(WithSortableHandle)).call.apply(_getPrototypeOf2, [this].concat(args)));
          _defineProperty(_assertThisInitialized(_assertThisInitialized(_this)), "wrappedInstance", React8.createRef());
          return _this;
        }
        _createClass(WithSortableHandle, [{
          key: "componentDidMount",
          value: function componentDidMount() {
            var node = reactDom.findDOMNode(this);
            node.sortableHandle = true;
          }
        }, {
          key: "getWrappedInstance",
          value: function getWrappedInstance() {
            invariant(config.withRef, "To access the wrapped instance, you need to pass in {withRef: true} as the second argument of the SortableHandle() call");
            return this.wrappedInstance.current;
          }
        }, {
          key: "render",
          value: function render() {
            var ref = config.withRef ? this.wrappedInstance : null;
            return React8.createElement(WrappedComponent, _extends({
              ref
            }, this.props));
          }
        }]);
        return WithSortableHandle;
      }(React8.Component), _defineProperty(_class, "displayName", provideDisplayName("sortableHandle", WrappedComponent)), _temp;
    }
    function isSortableHandle(node) {
      return node.sortableHandle != null;
    }
    var AutoScroller = function() {
      function AutoScroller2(container, onScrollCallback) {
        _classCallCheck(this, AutoScroller2);
        this.container = container;
        this.onScrollCallback = onScrollCallback;
      }
      _createClass(AutoScroller2, [{
        key: "clear",
        value: function clear() {
          if (this.interval == null) {
            return;
          }
          clearInterval(this.interval);
          this.interval = null;
        }
      }, {
        key: "update",
        value: function update(_ref) {
          var _this = this;
          var translate = _ref.translate, minTranslate = _ref.minTranslate, maxTranslate = _ref.maxTranslate, width = _ref.width, height = _ref.height;
          var direction = {
            x: 0,
            y: 0
          };
          var speed = {
            x: 1,
            y: 1
          };
          var acceleration = {
            x: 10,
            y: 10
          };
          var _this$container = this.container, scrollTop = _this$container.scrollTop, scrollLeft = _this$container.scrollLeft, scrollHeight = _this$container.scrollHeight, scrollWidth = _this$container.scrollWidth, clientHeight = _this$container.clientHeight, clientWidth = _this$container.clientWidth;
          var isTop = scrollTop === 0;
          var isBottom = scrollHeight - scrollTop - clientHeight === 0;
          var isLeft = scrollLeft === 0;
          var isRight = scrollWidth - scrollLeft - clientWidth === 0;
          if (translate.y >= maxTranslate.y - height / 2 && !isBottom) {
            direction.y = 1;
            speed.y = acceleration.y * Math.abs((maxTranslate.y - height / 2 - translate.y) / height);
          } else if (translate.x >= maxTranslate.x - width / 2 && !isRight) {
            direction.x = 1;
            speed.x = acceleration.x * Math.abs((maxTranslate.x - width / 2 - translate.x) / width);
          } else if (translate.y <= minTranslate.y + height / 2 && !isTop) {
            direction.y = -1;
            speed.y = acceleration.y * Math.abs((translate.y - height / 2 - minTranslate.y) / height);
          } else if (translate.x <= minTranslate.x + width / 2 && !isLeft) {
            direction.x = -1;
            speed.x = acceleration.x * Math.abs((translate.x - width / 2 - minTranslate.x) / width);
          }
          if (this.interval) {
            this.clear();
            this.isAutoScrolling = false;
          }
          if (direction.x !== 0 || direction.y !== 0) {
            this.interval = setInterval(function() {
              _this.isAutoScrolling = true;
              var offset = {
                left: speed.x * direction.x,
                top: speed.y * direction.y
              };
              _this.container.scrollTop += offset.top;
              _this.container.scrollLeft += offset.left;
              _this.onScrollCallback(offset);
            }, 5);
          }
        }
      }]);
      return AutoScroller2;
    }();
    function defaultGetHelperDimensions(_ref) {
      var node = _ref.node;
      return {
        height: node.offsetHeight,
        width: node.offsetWidth
      };
    }
    function defaultShouldCancelStart(event) {
      var interactiveElements = [NodeType.Input, NodeType.Textarea, NodeType.Select, NodeType.Option, NodeType.Button];
      if (interactiveElements.indexOf(event.target.tagName) !== -1) {
        return true;
      }
      if (closest(event.target, function(el) {
        return el.contentEditable === "true";
      })) {
        return true;
      }
      return false;
    }
    var propTypes = {
      axis: PropTypes.oneOf(["x", "y", "xy"]),
      contentWindow: PropTypes.any,
      disableAutoscroll: PropTypes.bool,
      distance: PropTypes.number,
      getContainer: PropTypes.func,
      getHelperDimensions: PropTypes.func,
      helperClass: PropTypes.string,
      helperContainer: PropTypes.oneOfType([PropTypes.func, typeof HTMLElement === "undefined" ? PropTypes.any : PropTypes.instanceOf(HTMLElement)]),
      hideSortableGhost: PropTypes.bool,
      keyboardSortingTransitionDuration: PropTypes.number,
      lockAxis: PropTypes.string,
      lockOffset: PropTypes.oneOfType([PropTypes.number, PropTypes.string, PropTypes.arrayOf(PropTypes.oneOfType([PropTypes.number, PropTypes.string]))]),
      lockToContainerEdges: PropTypes.bool,
      onSortEnd: PropTypes.func,
      onSortMove: PropTypes.func,
      onSortOver: PropTypes.func,
      onSortStart: PropTypes.func,
      pressDelay: PropTypes.number,
      pressThreshold: PropTypes.number,
      keyCodes: PropTypes.shape({
        lift: PropTypes.arrayOf(PropTypes.number),
        drop: PropTypes.arrayOf(PropTypes.number),
        cancel: PropTypes.arrayOf(PropTypes.number),
        up: PropTypes.arrayOf(PropTypes.number),
        down: PropTypes.arrayOf(PropTypes.number)
      }),
      shouldCancelStart: PropTypes.func,
      transitionDuration: PropTypes.number,
      updateBeforeSortStart: PropTypes.func,
      useDragHandle: PropTypes.bool,
      useWindowAsScrollContainer: PropTypes.bool
    };
    var defaultKeyCodes = {
      lift: [KEYCODE.SPACE],
      drop: [KEYCODE.SPACE],
      cancel: [KEYCODE.ESC],
      up: [KEYCODE.UP, KEYCODE.LEFT],
      down: [KEYCODE.DOWN, KEYCODE.RIGHT]
    };
    var defaultProps = {
      axis: "y",
      disableAutoscroll: false,
      distance: 0,
      getHelperDimensions: defaultGetHelperDimensions,
      hideSortableGhost: true,
      lockOffset: "50%",
      lockToContainerEdges: false,
      pressDelay: 0,
      pressThreshold: 5,
      keyCodes: defaultKeyCodes,
      shouldCancelStart: defaultShouldCancelStart,
      transitionDuration: 300,
      useWindowAsScrollContainer: false
    };
    var omittedProps = Object.keys(propTypes);
    function validateProps(props) {
      invariant(!(props.distance && props.pressDelay), "Attempted to set both `pressDelay` and `distance` on SortableContainer, you may only use one or the other, not both at the same time.");
    }
    function _finallyRethrows(body, finalizer) {
      try {
        var result = body();
      } catch (e) {
        return finalizer(true, e);
      }
      if (result && result.then) {
        return result.then(finalizer.bind(null, false), finalizer.bind(null, true));
      }
      return finalizer(false, value);
    }
    var SortableContext = React8.createContext({
      manager: {}
    });
    function sortableContainer(WrappedComponent) {
      var _class, _temp;
      var config = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {
        withRef: false
      };
      return _temp = _class = function(_React$Component) {
        _inherits(WithSortableContainer, _React$Component);
        function WithSortableContainer(props) {
          var _this;
          _classCallCheck(this, WithSortableContainer);
          _this = _possibleConstructorReturn(this, _getPrototypeOf(WithSortableContainer).call(this, props));
          _defineProperty(_assertThisInitialized(_assertThisInitialized(_this)), "state", {});
          _defineProperty(_assertThisInitialized(_assertThisInitialized(_this)), "handleStart", function(event) {
            var _this$props = _this.props, distance = _this$props.distance, shouldCancelStart = _this$props.shouldCancelStart;
            if (event.button === 2 || shouldCancelStart(event)) {
              return;
            }
            _this.touched = true;
            _this.position = getPosition(event);
            var node = closest(event.target, function(el) {
              return el.sortableInfo != null;
            });
            if (node && node.sortableInfo && _this.nodeIsChild(node) && !_this.state.sorting) {
              var useDragHandle = _this.props.useDragHandle;
              var _node$sortableInfo = node.sortableInfo, index = _node$sortableInfo.index, collection = _node$sortableInfo.collection, disabled = _node$sortableInfo.disabled;
              if (disabled) {
                return;
              }
              if (useDragHandle && !closest(event.target, isSortableHandle)) {
                return;
              }
              _this.manager.active = {
                collection,
                index
              };
              if (!isTouchEvent(event) && event.target.tagName === NodeType.Anchor) {
                event.preventDefault();
              }
              if (!distance) {
                if (_this.props.pressDelay === 0) {
                  _this.handlePress(event);
                } else {
                  _this.pressTimer = setTimeout(function() {
                    return _this.handlePress(event);
                  }, _this.props.pressDelay);
                }
              }
            }
          });
          _defineProperty(_assertThisInitialized(_assertThisInitialized(_this)), "nodeIsChild", function(node) {
            return node.sortableInfo.manager === _this.manager;
          });
          _defineProperty(_assertThisInitialized(_assertThisInitialized(_this)), "handleMove", function(event) {
            var _this$props2 = _this.props, distance = _this$props2.distance, pressThreshold = _this$props2.pressThreshold;
            if (!_this.state.sorting && _this.touched && !_this._awaitingUpdateBeforeSortStart) {
              var position = getPosition(event);
              var delta = {
                x: _this.position.x - position.x,
                y: _this.position.y - position.y
              };
              var combinedDelta = Math.abs(delta.x) + Math.abs(delta.y);
              _this.delta = delta;
              if (!distance && (!pressThreshold || combinedDelta >= pressThreshold)) {
                clearTimeout(_this.cancelTimer);
                _this.cancelTimer = setTimeout(_this.cancel, 0);
              } else if (distance && combinedDelta >= distance && _this.manager.isActive()) {
                _this.handlePress(event);
              }
            }
          });
          _defineProperty(_assertThisInitialized(_assertThisInitialized(_this)), "handleEnd", function() {
            _this.touched = false;
            _this.cancel();
          });
          _defineProperty(_assertThisInitialized(_assertThisInitialized(_this)), "cancel", function() {
            var distance = _this.props.distance;
            var sorting = _this.state.sorting;
            if (!sorting) {
              if (!distance) {
                clearTimeout(_this.pressTimer);
              }
              _this.manager.active = null;
            }
          });
          _defineProperty(_assertThisInitialized(_assertThisInitialized(_this)), "handlePress", function(event) {
            try {
              var active = _this.manager.getActive();
              var _temp6 = function() {
                if (active) {
                  var _temp7 = function _temp72() {
                    var index = _node.sortableInfo.index;
                    var margin = getElementMargin(_node);
                    var gridGap = getContainerGridGap(_this.container);
                    var containerBoundingRect = _this.scrollContainer.getBoundingClientRect();
                    var dimensions = _getHelperDimensions({
                      index,
                      node: _node,
                      collection: _collection
                    });
                    _this.node = _node;
                    _this.margin = margin;
                    _this.gridGap = gridGap;
                    _this.width = dimensions.width;
                    _this.height = dimensions.height;
                    _this.marginOffset = {
                      x: _this.margin.left + _this.margin.right + _this.gridGap.x,
                      y: Math.max(_this.margin.top, _this.margin.bottom, _this.gridGap.y)
                    };
                    _this.boundingClientRect = _node.getBoundingClientRect();
                    _this.containerBoundingRect = containerBoundingRect;
                    _this.index = index;
                    _this.newIndex = index;
                    _this.axis = {
                      x: _axis.indexOf("x") >= 0,
                      y: _axis.indexOf("y") >= 0
                    };
                    _this.offsetEdge = getEdgeOffset(_node, _this.container);
                    if (_isKeySorting) {
                      _this.initialOffset = getPosition(_objectSpread({}, event, {
                        pageX: _this.boundingClientRect.left,
                        pageY: _this.boundingClientRect.top
                      }));
                    } else {
                      _this.initialOffset = getPosition(event);
                    }
                    _this.initialScroll = {
                      left: _this.scrollContainer.scrollLeft,
                      top: _this.scrollContainer.scrollTop
                    };
                    _this.initialWindowScroll = {
                      left: window.pageXOffset,
                      top: window.pageYOffset
                    };
                    _this.helper = _this.helperContainer.appendChild(cloneNode(_node));
                    setInlineStyles(_this.helper, {
                      boxSizing: "border-box",
                      height: "".concat(_this.height, "px"),
                      left: "".concat(_this.boundingClientRect.left - margin.left, "px"),
                      pointerEvents: "none",
                      position: "fixed",
                      top: "".concat(_this.boundingClientRect.top - margin.top, "px"),
                      width: "".concat(_this.width, "px")
                    });
                    if (_isKeySorting) {
                      _this.helper.focus();
                    }
                    if (_hideSortableGhost) {
                      _this.sortableGhost = _node;
                      setInlineStyles(_node, {
                        opacity: 0,
                        visibility: "hidden"
                      });
                    }
                    _this.minTranslate = {};
                    _this.maxTranslate = {};
                    if (_isKeySorting) {
                      var _ref = _useWindowAsScrollContainer ? {
                        top: 0,
                        left: 0,
                        width: _this.contentWindow.innerWidth,
                        height: _this.contentWindow.innerHeight
                      } : _this.containerBoundingRect, containerTop = _ref.top, containerLeft = _ref.left, containerWidth = _ref.width, containerHeight = _ref.height;
                      var containerBottom = containerTop + containerHeight;
                      var containerRight = containerLeft + containerWidth;
                      if (_this.axis.x) {
                        _this.minTranslate.x = containerLeft - _this.boundingClientRect.left;
                        _this.maxTranslate.x = containerRight - (_this.boundingClientRect.left + _this.width);
                      }
                      if (_this.axis.y) {
                        _this.minTranslate.y = containerTop - _this.boundingClientRect.top;
                        _this.maxTranslate.y = containerBottom - (_this.boundingClientRect.top + _this.height);
                      }
                    } else {
                      if (_this.axis.x) {
                        _this.minTranslate.x = (_useWindowAsScrollContainer ? 0 : containerBoundingRect.left) - _this.boundingClientRect.left - _this.width / 2;
                        _this.maxTranslate.x = (_useWindowAsScrollContainer ? _this.contentWindow.innerWidth : containerBoundingRect.left + containerBoundingRect.width) - _this.boundingClientRect.left - _this.width / 2;
                      }
                      if (_this.axis.y) {
                        _this.minTranslate.y = (_useWindowAsScrollContainer ? 0 : containerBoundingRect.top) - _this.boundingClientRect.top - _this.height / 2;
                        _this.maxTranslate.y = (_useWindowAsScrollContainer ? _this.contentWindow.innerHeight : containerBoundingRect.top + containerBoundingRect.height) - _this.boundingClientRect.top - _this.height / 2;
                      }
                    }
                    if (_helperClass) {
                      _helperClass.split(" ").forEach(function(className) {
                        return _this.helper.classList.add(className);
                      });
                    }
                    _this.listenerNode = event.touches ? event.target : _this.contentWindow;
                    if (_isKeySorting) {
                      _this.listenerNode.addEventListener("wheel", _this.handleKeyEnd, true);
                      _this.listenerNode.addEventListener("mousedown", _this.handleKeyEnd, true);
                      _this.listenerNode.addEventListener("keydown", _this.handleKeyDown);
                    } else {
                      events.move.forEach(function(eventName) {
                        return _this.listenerNode.addEventListener(eventName, _this.handleSortMove, false);
                      });
                      events.end.forEach(function(eventName) {
                        return _this.listenerNode.addEventListener(eventName, _this.handleSortEnd, false);
                      });
                    }
                    _this.setState({
                      sorting: true,
                      sortingIndex: index
                    });
                    if (_onSortStart) {
                      _onSortStart({
                        node: _node,
                        index,
                        collection: _collection,
                        isKeySorting: _isKeySorting,
                        nodes: _this.manager.getOrderedRefs(),
                        helper: _this.helper
                      }, event);
                    }
                    if (_isKeySorting) {
                      _this.keyMove(0);
                    }
                  };
                  var _this$props3 = _this.props, _axis = _this$props3.axis, _getHelperDimensions = _this$props3.getHelperDimensions, _helperClass = _this$props3.helperClass, _hideSortableGhost = _this$props3.hideSortableGhost, updateBeforeSortStart = _this$props3.updateBeforeSortStart, _onSortStart = _this$props3.onSortStart, _useWindowAsScrollContainer = _this$props3.useWindowAsScrollContainer;
                  var _node = active.node, _collection = active.collection;
                  var _isKeySorting = _this.manager.isKeySorting;
                  var _temp8 = function() {
                    if (typeof updateBeforeSortStart === "function") {
                      _this._awaitingUpdateBeforeSortStart = true;
                      var _temp9 = _finallyRethrows(function() {
                        var index = _node.sortableInfo.index;
                        return Promise.resolve(updateBeforeSortStart({
                          collection: _collection,
                          index,
                          node: _node,
                          isKeySorting: _isKeySorting
                        }, event)).then(function() {
                        });
                      }, function(_wasThrown, _result) {
                        _this._awaitingUpdateBeforeSortStart = false;
                        if (_wasThrown)
                          throw _result;
                        return _result;
                      });
                      if (_temp9 && _temp9.then)
                        return _temp9.then(function() {
                        });
                    }
                  }();
                  return _temp8 && _temp8.then ? _temp8.then(_temp7) : _temp7(_temp8);
                }
              }();
              return Promise.resolve(_temp6 && _temp6.then ? _temp6.then(function() {
              }) : void 0);
            } catch (e) {
              return Promise.reject(e);
            }
          });
          _defineProperty(_assertThisInitialized(_assertThisInitialized(_this)), "handleSortMove", function(event) {
            var onSortMove = _this.props.onSortMove;
            if (typeof event.preventDefault === "function" && event.cancelable) {
              event.preventDefault();
            }
            _this.updateHelperPosition(event);
            _this.animateNodes();
            _this.autoscroll();
            if (onSortMove) {
              onSortMove(event);
            }
          });
          _defineProperty(_assertThisInitialized(_assertThisInitialized(_this)), "handleSortEnd", function(event) {
            var _this$props4 = _this.props, hideSortableGhost = _this$props4.hideSortableGhost, onSortEnd = _this$props4.onSortEnd;
            var _this$manager = _this.manager, collection = _this$manager.active.collection, isKeySorting = _this$manager.isKeySorting;
            var nodes = _this.manager.getOrderedRefs();
            if (_this.listenerNode) {
              if (isKeySorting) {
                _this.listenerNode.removeEventListener("wheel", _this.handleKeyEnd, true);
                _this.listenerNode.removeEventListener("mousedown", _this.handleKeyEnd, true);
                _this.listenerNode.removeEventListener("keydown", _this.handleKeyDown);
              } else {
                events.move.forEach(function(eventName) {
                  return _this.listenerNode.removeEventListener(eventName, _this.handleSortMove);
                });
                events.end.forEach(function(eventName) {
                  return _this.listenerNode.removeEventListener(eventName, _this.handleSortEnd);
                });
              }
            }
            _this.helper.parentNode.removeChild(_this.helper);
            if (hideSortableGhost && _this.sortableGhost) {
              setInlineStyles(_this.sortableGhost, {
                opacity: "",
                visibility: ""
              });
            }
            for (var i = 0, len = nodes.length; i < len; i++) {
              var _node2 = nodes[i];
              var el = _node2.node;
              _node2.edgeOffset = null;
              _node2.boundingClientRect = null;
              setTranslate3d(el, null);
              setTransitionDuration(el, null);
              _node2.translate = null;
            }
            _this.autoScroller.clear();
            _this.manager.active = null;
            _this.manager.isKeySorting = false;
            _this.setState({
              sorting: false,
              sortingIndex: null
            });
            if (typeof onSortEnd === "function") {
              onSortEnd({
                collection,
                newIndex: _this.newIndex,
                oldIndex: _this.index,
                isKeySorting,
                nodes
              }, event);
            }
            _this.touched = false;
          });
          _defineProperty(_assertThisInitialized(_assertThisInitialized(_this)), "autoscroll", function() {
            var disableAutoscroll = _this.props.disableAutoscroll;
            var isKeySorting = _this.manager.isKeySorting;
            if (disableAutoscroll) {
              _this.autoScroller.clear();
              return;
            }
            if (isKeySorting) {
              var translate = _objectSpread({}, _this.translate);
              var scrollX = 0;
              var scrollY = 0;
              if (_this.axis.x) {
                translate.x = Math.min(_this.maxTranslate.x, Math.max(_this.minTranslate.x, _this.translate.x));
                scrollX = _this.translate.x - translate.x;
              }
              if (_this.axis.y) {
                translate.y = Math.min(_this.maxTranslate.y, Math.max(_this.minTranslate.y, _this.translate.y));
                scrollY = _this.translate.y - translate.y;
              }
              _this.translate = translate;
              setTranslate3d(_this.helper, _this.translate);
              _this.scrollContainer.scrollLeft += scrollX;
              _this.scrollContainer.scrollTop += scrollY;
              return;
            }
            _this.autoScroller.update({
              height: _this.height,
              maxTranslate: _this.maxTranslate,
              minTranslate: _this.minTranslate,
              translate: _this.translate,
              width: _this.width
            });
          });
          _defineProperty(_assertThisInitialized(_assertThisInitialized(_this)), "onAutoScroll", function(offset) {
            _this.translate.x += offset.left;
            _this.translate.y += offset.top;
            _this.animateNodes();
          });
          _defineProperty(_assertThisInitialized(_assertThisInitialized(_this)), "handleKeyDown", function(event) {
            var keyCode = event.keyCode;
            var _this$props5 = _this.props, shouldCancelStart = _this$props5.shouldCancelStart, _this$props5$keyCodes = _this$props5.keyCodes, customKeyCodes = _this$props5$keyCodes === void 0 ? {} : _this$props5$keyCodes;
            var keyCodes = _objectSpread({}, defaultKeyCodes, customKeyCodes);
            if (_this.manager.active && !_this.manager.isKeySorting || !_this.manager.active && (!keyCodes.lift.includes(keyCode) || shouldCancelStart(event) || !_this.isValidSortingTarget(event))) {
              return;
            }
            event.stopPropagation();
            event.preventDefault();
            if (keyCodes.lift.includes(keyCode) && !_this.manager.active) {
              _this.keyLift(event);
            } else if (keyCodes.drop.includes(keyCode) && _this.manager.active) {
              _this.keyDrop(event);
            } else if (keyCodes.cancel.includes(keyCode)) {
              _this.newIndex = _this.manager.active.index;
              _this.keyDrop(event);
            } else if (keyCodes.up.includes(keyCode)) {
              _this.keyMove(-1);
            } else if (keyCodes.down.includes(keyCode)) {
              _this.keyMove(1);
            }
          });
          _defineProperty(_assertThisInitialized(_assertThisInitialized(_this)), "keyLift", function(event) {
            var target = event.target;
            var node = closest(target, function(el) {
              return el.sortableInfo != null;
            });
            var _node$sortableInfo2 = node.sortableInfo, index = _node$sortableInfo2.index, collection = _node$sortableInfo2.collection;
            _this.initialFocusedNode = target;
            _this.manager.isKeySorting = true;
            _this.manager.active = {
              index,
              collection
            };
            _this.handlePress(event);
          });
          _defineProperty(_assertThisInitialized(_assertThisInitialized(_this)), "keyMove", function(shift) {
            var nodes = _this.manager.getOrderedRefs();
            var lastIndex = nodes[nodes.length - 1].node.sortableInfo.index;
            var newIndex = _this.newIndex + shift;
            var prevIndex = _this.newIndex;
            if (newIndex < 0 || newIndex > lastIndex) {
              return;
            }
            _this.prevIndex = prevIndex;
            _this.newIndex = newIndex;
            var targetIndex = getTargetIndex(_this.newIndex, _this.prevIndex, _this.index);
            var target = nodes.find(function(_ref2) {
              var node = _ref2.node;
              return node.sortableInfo.index === targetIndex;
            });
            var targetNode = target.node;
            var scrollDelta = _this.containerScrollDelta;
            var targetBoundingClientRect = target.boundingClientRect || getScrollAdjustedBoundingClientRect(targetNode, scrollDelta);
            var targetTranslate = target.translate || {
              x: 0,
              y: 0
            };
            var targetPosition = {
              top: targetBoundingClientRect.top + targetTranslate.y - scrollDelta.top,
              left: targetBoundingClientRect.left + targetTranslate.x - scrollDelta.left
            };
            var shouldAdjustForSize = prevIndex < newIndex;
            var sizeAdjustment = {
              x: shouldAdjustForSize && _this.axis.x ? targetNode.offsetWidth - _this.width : 0,
              y: shouldAdjustForSize && _this.axis.y ? targetNode.offsetHeight - _this.height : 0
            };
            _this.handleSortMove({
              pageX: targetPosition.left + sizeAdjustment.x,
              pageY: targetPosition.top + sizeAdjustment.y,
              ignoreTransition: shift === 0
            });
          });
          _defineProperty(_assertThisInitialized(_assertThisInitialized(_this)), "keyDrop", function(event) {
            _this.handleSortEnd(event);
            if (_this.initialFocusedNode) {
              _this.initialFocusedNode.focus();
            }
          });
          _defineProperty(_assertThisInitialized(_assertThisInitialized(_this)), "handleKeyEnd", function(event) {
            if (_this.manager.active) {
              _this.keyDrop(event);
            }
          });
          _defineProperty(_assertThisInitialized(_assertThisInitialized(_this)), "isValidSortingTarget", function(event) {
            var useDragHandle = _this.props.useDragHandle;
            var target = event.target;
            var node = closest(target, function(el) {
              return el.sortableInfo != null;
            });
            return node && node.sortableInfo && !node.sortableInfo.disabled && (useDragHandle ? isSortableHandle(target) : target.sortableInfo);
          });
          var manager = new Manager();
          validateProps(props);
          _this.manager = manager;
          _this.wrappedInstance = React8.createRef();
          _this.sortableContextValue = {
            manager
          };
          _this.events = {
            end: _this.handleEnd,
            move: _this.handleMove,
            start: _this.handleStart
          };
          return _this;
        }
        _createClass(WithSortableContainer, [{
          key: "componentDidMount",
          value: function componentDidMount() {
            var _this2 = this;
            var useWindowAsScrollContainer = this.props.useWindowAsScrollContainer;
            var container = this.getContainer();
            Promise.resolve(container).then(function(containerNode) {
              _this2.container = containerNode;
              _this2.document = _this2.container.ownerDocument || document;
              var contentWindow = _this2.props.contentWindow || _this2.document.defaultView || window;
              _this2.contentWindow = typeof contentWindow === "function" ? contentWindow() : contentWindow;
              _this2.scrollContainer = useWindowAsScrollContainer ? _this2.document.scrollingElement || _this2.document.documentElement : getScrollingParent(_this2.container) || _this2.container;
              _this2.autoScroller = new AutoScroller(_this2.scrollContainer, _this2.onAutoScroll);
              Object.keys(_this2.events).forEach(function(key) {
                return events[key].forEach(function(eventName) {
                  return _this2.container.addEventListener(eventName, _this2.events[key], false);
                });
              });
              _this2.container.addEventListener("keydown", _this2.handleKeyDown);
            });
          }
        }, {
          key: "componentWillUnmount",
          value: function componentWillUnmount() {
            var _this3 = this;
            if (this.helper && this.helper.parentNode) {
              this.helper.parentNode.removeChild(this.helper);
            }
            if (!this.container) {
              return;
            }
            Object.keys(this.events).forEach(function(key) {
              return events[key].forEach(function(eventName) {
                return _this3.container.removeEventListener(eventName, _this3.events[key]);
              });
            });
            this.container.removeEventListener("keydown", this.handleKeyDown);
          }
        }, {
          key: "updateHelperPosition",
          value: function updateHelperPosition(event) {
            var _this$props6 = this.props, lockAxis = _this$props6.lockAxis, lockOffset = _this$props6.lockOffset, lockToContainerEdges = _this$props6.lockToContainerEdges, transitionDuration = _this$props6.transitionDuration, _this$props6$keyboard = _this$props6.keyboardSortingTransitionDuration, keyboardSortingTransitionDuration = _this$props6$keyboard === void 0 ? transitionDuration : _this$props6$keyboard;
            var isKeySorting = this.manager.isKeySorting;
            var ignoreTransition = event.ignoreTransition;
            var offset = getPosition(event);
            var translate = {
              x: offset.x - this.initialOffset.x,
              y: offset.y - this.initialOffset.y
            };
            translate.y -= window.pageYOffset - this.initialWindowScroll.top;
            translate.x -= window.pageXOffset - this.initialWindowScroll.left;
            this.translate = translate;
            if (lockToContainerEdges) {
              var _getLockPixelOffsets = getLockPixelOffsets({
                height: this.height,
                lockOffset,
                width: this.width
              }), _getLockPixelOffsets2 = _slicedToArray(_getLockPixelOffsets, 2), minLockOffset = _getLockPixelOffsets2[0], maxLockOffset = _getLockPixelOffsets2[1];
              var minOffset = {
                x: this.width / 2 - minLockOffset.x,
                y: this.height / 2 - minLockOffset.y
              };
              var maxOffset = {
                x: this.width / 2 - maxLockOffset.x,
                y: this.height / 2 - maxLockOffset.y
              };
              translate.x = limit(this.minTranslate.x + minOffset.x, this.maxTranslate.x - maxOffset.x, translate.x);
              translate.y = limit(this.minTranslate.y + minOffset.y, this.maxTranslate.y - maxOffset.y, translate.y);
            }
            if (lockAxis === "x") {
              translate.y = 0;
            } else if (lockAxis === "y") {
              translate.x = 0;
            }
            if (isKeySorting && keyboardSortingTransitionDuration && !ignoreTransition) {
              setTransitionDuration(this.helper, keyboardSortingTransitionDuration);
            }
            setTranslate3d(this.helper, translate);
          }
        }, {
          key: "animateNodes",
          value: function animateNodes() {
            var _this$props7 = this.props, transitionDuration = _this$props7.transitionDuration, hideSortableGhost = _this$props7.hideSortableGhost, onSortOver = _this$props7.onSortOver;
            var containerScrollDelta = this.containerScrollDelta, windowScrollDelta = this.windowScrollDelta;
            var nodes = this.manager.getOrderedRefs();
            var sortingOffset = {
              left: this.offsetEdge.left + this.translate.x + containerScrollDelta.left,
              top: this.offsetEdge.top + this.translate.y + containerScrollDelta.top
            };
            var isKeySorting = this.manager.isKeySorting;
            var prevIndex = this.newIndex;
            this.newIndex = null;
            for (var i = 0, len = nodes.length; i < len; i++) {
              var _node3 = nodes[i].node;
              var index = _node3.sortableInfo.index;
              var width = _node3.offsetWidth;
              var height = _node3.offsetHeight;
              var offset = {
                height: this.height > height ? height / 2 : this.height / 2,
                width: this.width > width ? width / 2 : this.width / 2
              };
              var mustShiftBackward = isKeySorting && index > this.index && index <= prevIndex;
              var mustShiftForward = isKeySorting && index < this.index && index >= prevIndex;
              var translate = {
                x: 0,
                y: 0
              };
              var edgeOffset = nodes[i].edgeOffset;
              if (!edgeOffset) {
                edgeOffset = getEdgeOffset(_node3, this.container);
                nodes[i].edgeOffset = edgeOffset;
                if (isKeySorting) {
                  nodes[i].boundingClientRect = getScrollAdjustedBoundingClientRect(_node3, containerScrollDelta);
                }
              }
              var nextNode = i < nodes.length - 1 && nodes[i + 1];
              var prevNode = i > 0 && nodes[i - 1];
              if (nextNode && !nextNode.edgeOffset) {
                nextNode.edgeOffset = getEdgeOffset(nextNode.node, this.container);
                if (isKeySorting) {
                  nextNode.boundingClientRect = getScrollAdjustedBoundingClientRect(nextNode.node, containerScrollDelta);
                }
              }
              if (index === this.index) {
                if (hideSortableGhost) {
                  this.sortableGhost = _node3;
                  setInlineStyles(_node3, {
                    opacity: 0,
                    visibility: "hidden"
                  });
                }
                continue;
              }
              if (transitionDuration) {
                setTransitionDuration(_node3, transitionDuration);
              }
              if (this.axis.x) {
                if (this.axis.y) {
                  if (mustShiftForward || index < this.index && (sortingOffset.left + windowScrollDelta.left - offset.width <= edgeOffset.left && sortingOffset.top + windowScrollDelta.top <= edgeOffset.top + offset.height || sortingOffset.top + windowScrollDelta.top + offset.height <= edgeOffset.top)) {
                    translate.x = this.width + this.marginOffset.x;
                    if (edgeOffset.left + translate.x > this.containerBoundingRect.width - offset.width) {
                      if (nextNode) {
                        translate.x = nextNode.edgeOffset.left - edgeOffset.left;
                        translate.y = nextNode.edgeOffset.top - edgeOffset.top;
                      }
                    }
                    if (this.newIndex === null) {
                      this.newIndex = index;
                    }
                  } else if (mustShiftBackward || index > this.index && (sortingOffset.left + windowScrollDelta.left + offset.width >= edgeOffset.left && sortingOffset.top + windowScrollDelta.top + offset.height >= edgeOffset.top || sortingOffset.top + windowScrollDelta.top + offset.height >= edgeOffset.top + height)) {
                    translate.x = -(this.width + this.marginOffset.x);
                    if (edgeOffset.left + translate.x < this.containerBoundingRect.left + offset.width) {
                      if (prevNode) {
                        translate.x = prevNode.edgeOffset.left - edgeOffset.left;
                        translate.y = prevNode.edgeOffset.top - edgeOffset.top;
                      }
                    }
                    this.newIndex = index;
                  }
                } else {
                  if (mustShiftBackward || index > this.index && sortingOffset.left + windowScrollDelta.left + offset.width >= edgeOffset.left) {
                    translate.x = -(this.width + this.marginOffset.x);
                    this.newIndex = index;
                  } else if (mustShiftForward || index < this.index && sortingOffset.left + windowScrollDelta.left <= edgeOffset.left + offset.width) {
                    translate.x = this.width + this.marginOffset.x;
                    if (this.newIndex == null) {
                      this.newIndex = index;
                    }
                  }
                }
              } else if (this.axis.y) {
                if (mustShiftBackward || index > this.index && sortingOffset.top + windowScrollDelta.top + offset.height >= edgeOffset.top) {
                  translate.y = -(this.height + this.marginOffset.y);
                  this.newIndex = index;
                } else if (mustShiftForward || index < this.index && sortingOffset.top + windowScrollDelta.top <= edgeOffset.top + offset.height) {
                  translate.y = this.height + this.marginOffset.y;
                  if (this.newIndex == null) {
                    this.newIndex = index;
                  }
                }
              }
              setTranslate3d(_node3, translate);
              nodes[i].translate = translate;
            }
            if (this.newIndex == null) {
              this.newIndex = this.index;
            }
            if (isKeySorting) {
              this.newIndex = prevIndex;
            }
            var oldIndex = isKeySorting ? this.prevIndex : prevIndex;
            if (onSortOver && this.newIndex !== oldIndex) {
              onSortOver({
                collection: this.manager.active.collection,
                index: this.index,
                newIndex: this.newIndex,
                oldIndex,
                isKeySorting,
                nodes,
                helper: this.helper
              });
            }
          }
        }, {
          key: "getWrappedInstance",
          value: function getWrappedInstance() {
            invariant(config.withRef, "To access the wrapped instance, you need to pass in {withRef: true} as the second argument of the SortableContainer() call");
            return this.wrappedInstance.current;
          }
        }, {
          key: "getContainer",
          value: function getContainer() {
            var getContainer2 = this.props.getContainer;
            if (typeof getContainer2 !== "function") {
              return reactDom.findDOMNode(this);
            }
            return getContainer2(config.withRef ? this.getWrappedInstance() : void 0);
          }
        }, {
          key: "render",
          value: function render() {
            var ref = config.withRef ? this.wrappedInstance : null;
            return React8.createElement(SortableContext.Provider, {
              value: this.sortableContextValue
            }, React8.createElement(WrappedComponent, _extends({
              ref
            }, omit(this.props, omittedProps))));
          }
        }, {
          key: "helperContainer",
          get: function get() {
            var helperContainer = this.props.helperContainer;
            if (typeof helperContainer === "function") {
              return helperContainer();
            }
            return this.props.helperContainer || this.document.body;
          }
        }, {
          key: "containerScrollDelta",
          get: function get() {
            var useWindowAsScrollContainer = this.props.useWindowAsScrollContainer;
            if (useWindowAsScrollContainer) {
              return {
                left: 0,
                top: 0
              };
            }
            return {
              left: this.scrollContainer.scrollLeft - this.initialScroll.left,
              top: this.scrollContainer.scrollTop - this.initialScroll.top
            };
          }
        }, {
          key: "windowScrollDelta",
          get: function get() {
            return {
              left: this.contentWindow.pageXOffset - this.initialWindowScroll.left,
              top: this.contentWindow.pageYOffset - this.initialWindowScroll.top
            };
          }
        }]);
        return WithSortableContainer;
      }(React8.Component), _defineProperty(_class, "displayName", provideDisplayName("sortableList", WrappedComponent)), _defineProperty(_class, "defaultProps", defaultProps), _defineProperty(_class, "propTypes", propTypes), _temp;
    }
    var propTypes$1 = {
      index: PropTypes.number.isRequired,
      collection: PropTypes.oneOfType([PropTypes.number, PropTypes.string]),
      disabled: PropTypes.bool
    };
    var omittedProps$1 = Object.keys(propTypes$1);
    function sortableElement(WrappedComponent) {
      var _class, _temp;
      var config = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {
        withRef: false
      };
      return _temp = _class = function(_React$Component) {
        _inherits(WithSortableElement, _React$Component);
        function WithSortableElement() {
          var _getPrototypeOf2;
          var _this;
          _classCallCheck(this, WithSortableElement);
          for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
          }
          _this = _possibleConstructorReturn(this, (_getPrototypeOf2 = _getPrototypeOf(WithSortableElement)).call.apply(_getPrototypeOf2, [this].concat(args)));
          _defineProperty(_assertThisInitialized(_assertThisInitialized(_this)), "wrappedInstance", React8.createRef());
          return _this;
        }
        _createClass(WithSortableElement, [{
          key: "componentDidMount",
          value: function componentDidMount() {
            this.register();
          }
        }, {
          key: "componentDidUpdate",
          value: function componentDidUpdate(prevProps) {
            if (this.node) {
              if (prevProps.index !== this.props.index) {
                this.node.sortableInfo.index = this.props.index;
              }
              if (prevProps.disabled !== this.props.disabled) {
                this.node.sortableInfo.disabled = this.props.disabled;
              }
            }
            if (prevProps.collection !== this.props.collection) {
              this.unregister(prevProps.collection);
              this.register();
            }
          }
        }, {
          key: "componentWillUnmount",
          value: function componentWillUnmount() {
            this.unregister();
          }
        }, {
          key: "register",
          value: function register() {
            var _this$props = this.props, collection = _this$props.collection, disabled = _this$props.disabled, index = _this$props.index;
            var node = reactDom.findDOMNode(this);
            node.sortableInfo = {
              collection,
              disabled,
              index,
              manager: this.context.manager
            };
            this.node = node;
            this.ref = {
              node
            };
            this.context.manager.add(collection, this.ref);
          }
        }, {
          key: "unregister",
          value: function unregister() {
            var collection = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : this.props.collection;
            this.context.manager.remove(collection, this.ref);
          }
        }, {
          key: "getWrappedInstance",
          value: function getWrappedInstance() {
            invariant(config.withRef, "To access the wrapped instance, you need to pass in {withRef: true} as the second argument of the SortableElement() call");
            return this.wrappedInstance.current;
          }
        }, {
          key: "render",
          value: function render() {
            var ref = config.withRef ? this.wrappedInstance : null;
            return React8.createElement(WrappedComponent, _extends({
              ref
            }, omit(this.props, omittedProps$1)));
          }
        }]);
        return WithSortableElement;
      }(React8.Component), _defineProperty(_class, "displayName", provideDisplayName("sortableElement", WrappedComponent)), _defineProperty(_class, "contextType", SortableContext), _defineProperty(_class, "propTypes", propTypes$1), _defineProperty(_class, "defaultProps", {
        collection: 0
      }), _temp;
    }
    exports.SortableContainer = sortableContainer;
    exports.sortableContainer = sortableContainer;
    exports.SortableElement = sortableElement;
    exports.sortableElement = sortableElement;
    exports.SortableHandle = sortableHandle;
    exports.sortableHandle = sortableHandle;
    exports.arrayMove = arrayMove;
  }
});

// src/services/insomnia/connector/refs-common.ts
var currentInsomniaConnectionId = null;
var initConnection = () => {
  currentInsomniaConnectionId = Math.random().toString(36).substring(2);
  localStorage.setItem("insomniaConnectionId", currentInsomniaConnectionId);
};
var isCurrentConnectionStillActive = () => {
  if (currentInsomniaConnectionId === "")
    throw new Error("insomnia connection is not initialized");
  const result = currentInsomniaConnectionId === localStorage.getItem("insomniaConnectionId");
  if (!result)
    console.warn("[plugin-navigator]", "insomnia connection is not active", currentInsomniaConnectionId, localStorage.getItem("insomniaConnectionId"));
  return result;
};

// src/services/insomnia/connector/refs-router.ts
var internalRouter = {};
var initRouter = () => {
  const rootElement = document.querySelector("#root");
  if (!rootElement) {
    console.error("[plugin-navigator]", "root element not found");
    return false;
  }
  const containerElement = Object.getOwnPropertyNames(rootElement).findLast((x) => x.startsWith("__reactContainer"));
  if (!containerElement) {
    console.warn("[plugin-navigator]", "store container element not found");
    return false;
  }
  internalRouter = rootElement[containerElement].memoizedState.element.props.router;
  return true;
};
var getRouter = () => internalRouter;
var subscribeForRouteChanged = (callback) => {
  const routerUnsubscribeMethod = internalRouter.subscribe((data) => {
    if (!isCurrentConnectionStillActive()) {
      routerUnsubscribeMethod();
      return;
    }
    if (data.historyAction === "PUSH")
      callback(data.location?.pathname);
  });
};

// src/services/insomnia/events/request-deleted.ts
var listeners = /* @__PURE__ */ new Set();
var notifyRequestDeleted = (doc) => {
  listeners.forEach((listener) => listener(doc));
};
var onRequestDeleted = (listener) => {
  listeners.add(listener);
  return () => listeners.delete(listener);
};

// src/services/insomnia/events/request-updated.ts
var lastValue = {};
var listeners2 = /* @__PURE__ */ new Set();
var notifyRequestUpdated = (doc) => {
  let changed = false;
  for (const key in doc) {
    if (doc[key] != lastValue[key])
      changed = true;
  }
  if (!changed)
    return;
  listeners2.forEach((listener) => listener(doc));
  lastValue = doc;
};
var onRequestUpdated = (listener) => {
  listeners2.add(listener);
  return () => listeners2.delete(listener);
};

// src/services/insomnia/connector/refs-data.ts
var getData = () => getRouter().state.loaderData;
var getAllRequests = () => getData()[":workspaceId"]["collection"].map((x) => x.doc);
var getRequestOrUndefined = (requestId) => getAllRequests().find((x) => x._id === requestId);
var getActiveRequest = () => getData()["request/:requestId"]["activeRequest"];
var getActiveWorkspace = () => getData()[":workspaceId"] && getData()[":workspaceId"]["activeWorkspace"];
var getActiveProject = () => getData()[":workspaceId"]["activeProject"];
var getActiveOrgId = () => getRouter().state.location.pathname.match(/^\/organization\/(org_[^/]+)/)?.[1];
var getAllWorkspaces = () => getData()["/project/:projectId"]?.workspaces;

// src/services/insomnia/events/request-selected.ts
var lastValue2 = "";
var listeners3 = /* @__PURE__ */ new Set();
var notifyRequestSelected = (doc) => {
  const activeRequestId = doc._id;
  if (activeRequestId === lastValue2) {
    return;
  }
  lastValue2 = doc._id;
  listeners3.forEach((listener) => listener(doc));
};
var onRequestSelected = (listener) => {
  listeners3.add(listener);
  return () => listeners3.delete(listener);
};

// src/services/insomnia/events/debug-page-opened.ts
var lastValue3 = void 0;
var listeners4 = /* @__PURE__ */ new Set();
var notifyDebugPageOpenChanged = (opened) => {
  if (lastValue3 === opened)
    return;
  listeners4.forEach((listener) => listener(opened));
  lastValue3 = opened;
};
var onDebugPageOpenChanged = (listener) => {
  listeners4.add(listener);
  return () => listeners4.delete(listener);
};

// src/services/insomnia/connector/refs-events.ts
var initEvents = () => {
  subscibeForDbChangeEvents((doc, method) => {
    if (method === "update" && (doc.type === "Request" || doc.type === "GrpcRequest"))
      notifyRequestUpdated(doc);
    if (method === "remove" && (doc.type === "Request" || doc.type === "GrpcRequest"))
      notifyRequestDeleted(doc);
  });
  subscribeForRouteChanged((path2) => {
    if (isRouteDebugView(path2)) {
      notifyDebugPageOpenChanged(true);
      const requestId = extractRequestId(path2);
      if (!requestId) {
        console.warn("[plugin-navigator]", "cannot extract request id from router path", path2);
        return;
      }
      const doc = getRequestOrUndefined(requestId);
      if (!doc) {
        console.warn("[plugin-navigator]", "request not found", requestId);
        return;
      }
      notifyRequestSelected(doc);
    } else {
      notifyDebugPageOpenChanged(false);
    }
  });
};
var subscibeForDbChangeEvents = (callback) => {
  subscribeForChannelEvents("db.changes", (changes) => changes.forEach((data) => {
    if (data.length != 3) {
      console.warn("[plugin-navigator]", "unexpected data recevied in db.changes channel", data);
      return;
    }
    const method = data[0];
    const doc = data[1];
    if (!method || !doc) {
      console.warn("[plugin-navigator]", "unexpected method or doc recevied in db.changes channel", data);
      return;
    }
    callback(doc, method);
  }));
};
var subscribeForChannelEvents = (channelName, callback) => {
  const unsubscribeMethod = window.main.on(channelName, (_, data) => {
    if (!isCurrentConnectionStillActive()) {
      unsubscribeMethod();
      return;
    }
    callback(data);
  });
};
var isRouteDebugView = (route) => /\/organization\/org_[^/]+\/project\/proj_[^/]+\/workspace\/wrk_[^/]+\/debug/.test(route);
var extractRequestId = (route) => route.match(/\/((req_|greq_)[0-9a-z]+)$/)?.[1];

// src/services/insomnia/connector/index.ts
var connect = () => {
  initConnection();
  if (!initRouter())
    return false;
  initEvents();
  return true;
};

// src/ui/index.tsx
var import_react_dom = __toESM(require("react-dom"));

// src/ui/tabs-panel/tabs-panel.tsx
var import_react8 = __toESM(require("react"));

// src/ui/tabs-panel/tabs-panel.styles.scss
var css = `#plugin-request-navigator-hub .tabs-panel {
  display: flex;
  justify-content: space-between;
}
#plugin-request-navigator-hub .tabs-panel.hidden {
  display: none;
}
#plugin-request-navigator-hub .tabs-panel .items {
  display: flex;
  gap: 4px;
  padding: 1px 5px 0 6px;
  overflow: hidden;
}
#plugin-request-navigator-hub .tabs-panel .items ul.context-menu {
  position: absolute;
  z-index: 20;
  background-color: var(--color-bg);
  border: solid 1px var(--hl-xs);
}
#plugin-request-navigator-hub .tabs-panel .items ul.context-menu li {
  color: var(--hl);
  padding: 8px 22px;
  border-bottom: solid 1px var(--hl-xs);
  cursor: pointer;
  position: relative;
  white-space: nowrap;
}
#plugin-request-navigator-hub .tabs-panel .items ul.context-menu li:hover, #plugin-request-navigator-hub .tabs-panel .items ul.context-menu li.active {
  background-color: var(--hl-xs);
  color: var(--color-font);
}
#plugin-request-navigator-hub .tabs-panel .items ul.context-menu li:last-child {
  border-bottom: none;
}`;
document.head.appendChild(document.createElement("style")).appendChild(document.createTextNode(css));

// src/ui/tab-button/tab-button.tsx
var import_react3 = __toESM(require("react"));

// src/ui/tab-button/tab-button.styles.scss
var css2 = `.plugin-request-navigator-tab-button {
  position: relative;
  color: var(--hl);
  padding: 7px 21px 8px 14px;
  background-color: var(--hl-xs);
  border-radius: 3px 3px 0 0;
  cursor: pointer;
  border: 1px solid transparent;
  border-bottom: none;
  max-width: 200px;
  text-align: center;
  white-space: nowrap;
}
.plugin-request-navigator-tab-button .title {
  transition: margin-left 0.05s ease-in-out, margin-right 0.05s ease-in-out;
  overflow: hidden;
  text-overflow: ellipsis;
}
.plugin-request-navigator-tab-button .method {
  opacity: 0.6;
  color: var(--color-info);
  margin-right: 5px;
}
.plugin-request-navigator-tab-button .method.get {
  color: var(--color-surprise);
}
.plugin-request-navigator-tab-button .method.post {
  color: var(--color-success);
}
.plugin-request-navigator-tab-button .method.put {
  color: var(--color-warning);
}
.plugin-request-navigator-tab-button .method.patch {
  color: var(--color-notice);
}
.plugin-request-navigator-tab-button .method.delete {
  color: var(--color-danger);
}
.plugin-request-navigator-tab-button .btn-close {
  position: absolute;
  color: var(--hl);
  opacity: 0;
  top: 0;
  bottom: 0;
  right: 0;
  padding: 0 7px 0 5px;
  display: flex;
  align-items: center;
  padding-top: 1px;
  transition: color 0.2s ease-in-out, opacity 0.2s ease-in-out 0.1s;
}
.plugin-request-navigator-tab-button .btn-close:before {
  content: "";
  height: 100%;
  width: 8px;
  position: absolute;
  left: 0;
  margin-left: -8px;
  background: linear-gradient(90deg, transparent 0%, var(--hl-xs) 100%);
  opacity: 0;
}
.plugin-request-navigator-tab-button .btn-close:hover {
  opacity: 1;
  color: var(--color-font);
  background-color: var(--hl-xs);
}
.plugin-request-navigator-tab-button .btn-close:hover:before {
  opacity: 1;
}
.plugin-request-navigator-tab-button.active, .plugin-request-navigator-tab-button:hover {
  color: var(--color-font);
}
.plugin-request-navigator-tab-button.active .method, .plugin-request-navigator-tab-button:hover .method {
  opacity: 1;
}
.plugin-request-navigator-tab-button.active {
  border: 1px solid var(--hl-md);
  border-bottom: none;
}
.plugin-request-navigator-tab-button.active .btn-close {
  opacity: 1;
}
.plugin-request-navigator-tab-button.hidden {
  visibility: visible;
  pointer-events: none;
  opacity: 0.4;
  border: none;
  display: block !important;
}
.plugin-request-navigator-tab-button.hidden .title {
  opacity: 0;
}
.plugin-request-navigator-tab-button:has(.btn-close:hover) {
  color: var(--hl) !important;
}

#plugin-request-navigator-hub .plugin-request-navigator-tab-button {
  transition: color 0.1s ease-in-out, transform 0.2s ease-in-out;
}`;
document.head.appendChild(document.createElement("style")).appendChild(document.createTextNode(css2));

// src/ui/context-menu-container/context-menu-container.tsx
var import_react = __toESM(require("react"));
var ContextMenuContainerInternal = ({ children, menu }, ref) => {
  const [state, setState] = import_react.default.useState({
    isOpen: false,
    x: 0,
    y: 0
  });
  const internalRef = import_react.default.useRef(null);
  (0, import_react.useEffect)(() => {
    document.addEventListener("mousedown", onClickOutside);
    return () => document.removeEventListener("mousedown", onClickOutside);
  }, []);
  (0, import_react.useImperativeHandle)(ref, () => ({
    closeMenu: () => setState({
      isOpen: false,
      x: 0,
      y: 0
    })
  }));
  const onContextMenu = (x, y) => setState({
    isOpen: true,
    x,
    y
  });
  const onClickOutside = (event) => {
    if (internalRef?.current !== null && event.target !== internalRef.current && !internalRef.current.contains(event.target)) {
      setState({
        isOpen: false,
        x: 0,
        y: 0
      });
    }
  };
  return /* @__PURE__ */ import_react.default.createElement(import_react.default.Fragment, null, import_react.default.cloneElement(children, {
    onContextMenu: (event) => {
      event.preventDefault();
      onContextMenu(event.pageX, event.pageY);
    }
  }), state.isOpen && /* @__PURE__ */ import_react.default.createElement(
    "div",
    {
      ref: (menu2) => internalRef.current = menu2,
      style: {
        position: "absolute",
        left: state.x,
        top: state.y,
        margin: 0,
        padding: 0
      }
    },
    menu
  ));
};
var ContextMenuContainer = (0, import_react.forwardRef)(ContextMenuContainerInternal);

// src/ui/tab-button/tab-button.hook.ts
var import_react2 = __toESM(require("react"));
var useTabButton = ({ onClickClose, onClickButton, onClickCloseOthers, onClickCloseOnRight, onClickCloseAll }) => {
  const contextMenuRef = import_react2.default.useRef(null);
  const onClickButtonInternal = (e) => onClickButton ? onClickButton(e) : null;
  const onClickAuxInternal = (e) => {
    if (e.button === 1) {
      e.stopPropagation();
      if (onClickClose)
        onClickClose(e);
    }
  };
  const onClickCloseInternal = (e) => {
    e.stopPropagation();
    if (onClickClose)
      onClickClose(e);
  };
  const onContextCloseTab = (e) => {
    contextMenuRef.current?.closeMenu();
    if (onClickClose)
      onClickClose(e);
  };
  const onContextCloseOthers = (e) => {
    contextMenuRef.current?.closeMenu();
    if (onClickCloseOthers)
      onClickCloseOthers(e);
  };
  const onContextCloseOnRight = (e) => {
    contextMenuRef.current?.closeMenu();
    if (onClickCloseOnRight)
      onClickCloseOnRight(e);
  };
  const onContextCloseAll = (e) => {
    contextMenuRef.current?.closeMenu();
    if (onClickCloseAll)
      onClickCloseAll(e);
  };
  return {
    contextMenuRef,
    onClickButton: onClickButtonInternal,
    onClickAuxButton: onClickAuxInternal,
    onClickClose: onClickCloseInternal,
    onContextCloseTab,
    onContextCloseOthers,
    onContextCloseOnRight,
    onContextCloseAll
  };
};

// src/ui/tab-button/tab-button.tsx
var TabButton = (props) => {
  const { children, isActive, requestId, title, method, isHidden } = props;
  const { contextMenuRef, onClickButton, onClickAuxButton, onClickClose, onContextCloseTab, onContextCloseOthers, onContextCloseOnRight, onContextCloseAll } = useTabButton(props);
  return /* @__PURE__ */ import_react3.default.createElement(
    ContextMenuContainer,
    {
      ref: contextMenuRef,
      menu: /* @__PURE__ */ import_react3.default.createElement("ul", { className: "context-menu" }, /* @__PURE__ */ import_react3.default.createElement("li", { onClick: onContextCloseTab }, "Close tab"), /* @__PURE__ */ import_react3.default.createElement("li", { onClick: onContextCloseOnRight }, "Close on right"), /* @__PURE__ */ import_react3.default.createElement("li", { onClick: onContextCloseOthers }, "Close others"), /* @__PURE__ */ import_react3.default.createElement("li", { onClick: onContextCloseAll }, "Close all"))
    },
    /* @__PURE__ */ import_react3.default.createElement(
      "div",
      {
        className: `plugin-request-navigator-tab-button ${isActive ? "active" : ""} ${isHidden ? "hidden" : ""}`,
        onClick: onClickButton,
        onAuxClick: onClickAuxButton,
        "data-request-id": requestId,
        "data-title": title,
        "data-method": method
      },
      /* @__PURE__ */ import_react3.default.createElement("div", { className: "btn-close", onClick: onClickClose }, /* @__PURE__ */ import_react3.default.createElement("i", { className: "fa-solid fa-xmark" })),
      /* @__PURE__ */ import_react3.default.createElement("div", { className: "title" }, method && /* @__PURE__ */ import_react3.default.createElement("span", { className: `method ${method.toLocaleLowerCase()}` }, method.toUpperCase()), /* @__PURE__ */ import_react3.default.createElement("span", null, children))
    )
  );
};

// src/ui/tabs-panel/tabs-panel.hook.ts
var import_react4 = require("react");

// src/services/db/db.ts
var path = __toESM(require("path"));
var import_nedb = __toESM(require("nedb"));
var dbName = "Plugin.request-navigator";
var dbPath = path.join(window.app.getPath("userData"), `insomnia.${dbName}.db`);
var database = new import_nedb.default({
  filename: dbPath,
  autoload: true,
  corruptAlertThreshold: 0.9,
  inMemoryOnly: false
});

// src/services/helpers/insomnia-requests.ts
var getRequestMethodName = (requestInfo) => {
  let method = requestInfo.method;
  if (!method) {
    if (requestInfo.type === "GrpcRequest")
      method = "gRPC";
    else
      method = "N/A";
  }
  return method;
};

// src/ui/tabs-panel/tabs-panel.hook.ts
var useTabsPanel = () => {
  const tabDataRef = (0, import_react4.useRef)([]);
  const [tabs, _setTabs] = (0, import_react4.useState)([]);
  const [activeWorkspaceId, setActiveWorkspaceId] = (0, import_react4.useState)(void 0);
  (0, import_react4.useEffect)(() => {
    const unSubonDebugPageOpenChanged = onDebugPageOpenChanged((opened) => {
      if (opened) {
        setActiveWorkspaceId(getActiveWorkspace()?._id);
      } else {
        setActiveWorkspaceId(void 0);
        tryToCleanupDb();
      }
    });
    setActiveWorkspaceId(getActiveWorkspace()?._id);
    return () => {
      unSubonDebugPageOpenChanged();
    };
  }, []);
  (0, import_react4.useEffect)(() => {
    if (!activeWorkspaceId) {
      _setTabs([]);
      return;
    }
    database.findOne({ workspaceId: activeWorkspaceId }, (err, doc) => {
      if (err) {
        console.error("[plugin-navigator]", "cannot get workspace data from db", err);
        return;
      }
      const allRequests = getAllRequests();
      const loadedTabs = doc?.tabs.map((x) => {
        const request = allRequests.find((y) => y._id === x.requestId);
        if (!request)
          return null;
        const result = {
          requestId: request._id,
          title: request.name,
          isActive: x.isActive ?? false,
          method: getRequestMethodName(request)
        };
        return result;
      }).filter((x) => x) || [];
      setTabs(loadedTabs);
    });
  }, [activeWorkspaceId]);
  (0, import_react4.useEffect)(() => {
    tabDataRef.current = tabs;
  }, [tabs]);
  const setTabs = (x) => {
    const currentWorkspaceId = getActiveWorkspace()?._id;
    if (!currentWorkspaceId) {
      console.warn("[plugin-navigator]", "cannot get current workspace id");
      return;
    }
    database.findOne({ workspaceId: currentWorkspaceId }, (err, doc) => {
      if (err) {
        console.error("[plugin-navigator]", "cannot get workspace data from db", err);
        return;
      }
      doc = doc || { workspaceId: currentWorkspaceId, tabs: [] };
      doc.tabs = x.map((tab, index) => ({ requestId: tab.requestId, index, isActive: tab.isActive }));
      database.update({ workspaceId: currentWorkspaceId }, doc, { upsert: true }, (err2) => {
        if (err2)
          console.error("[plugin-navigator]", "cannot update workspace data in db", err2);
      });
    });
    _setTabs(x);
  };
  return {
    tabs,
    setTabs,
    tabDataRef
  };
};
var tryToCleanupDb = () => {
  const allWorkspaces = getAllWorkspaces();
  if (!allWorkspaces)
    return;
  try {
    const existsWorkspaces = allWorkspaces.map((x) => x._id);
    const storedWorkspaces = database.getAllData();
    const removeWorkspaces = storedWorkspaces.filter((x) => !existsWorkspaces.includes(x.workspaceId));
    removeWorkspaces.map((x) => database.remove(x, (err) => {
      if (err)
        console.error("[plugin-navigator]", "cleanupWorkspaces error", err);
    }));
  } catch (err) {
    console.error("[plugin-navigator]", "cleanupWorkspaces", err);
  }
};

// src/ui/tab-dropdown/tab-dropdown.tsx
var import_react5 = __toESM(require("react"));

// src/ui/tab-dropdown/tab-dropdown.styles.scss
var css3 = `#plugin-request-navigator-hub .tab-dropdown .button {
  padding: 8px 11px;
  border-radius: 3px 3px 0 0;
  cursor: pointer;
  border: 1px solid transparent;
  border-bottom: none;
  color: var(--hl);
  white-space: nowrap;
}
#plugin-request-navigator-hub .tab-dropdown .button .counter {
  margin-right: 5px;
}
#plugin-request-navigator-hub .tab-dropdown .button:hover {
  background-color: var(--hl-xs);
}
#plugin-request-navigator-hub .tab-dropdown ul {
  position: absolute;
  z-index: 1;
  right: 0;
  background-color: var(--color-bg);
  border: solid 1px var(--hl-xs);
  margin-top: 1px;
}
#plugin-request-navigator-hub .tab-dropdown ul li {
  color: var(--hl);
  padding: 9px 28px 9px 25px;
  background-color: var(--hl-xxs);
  border-bottom: solid 1px var(--hl-xs);
  cursor: pointer;
  position: relative;
}
#plugin-request-navigator-hub .tab-dropdown ul li .title .method {
  opacity: 0.6;
  color: var(--color-info);
  margin-right: 5px;
}
#plugin-request-navigator-hub .tab-dropdown ul li .title .method.get {
  color: var(--color-surprise);
}
#plugin-request-navigator-hub .tab-dropdown ul li .title .method.post {
  color: var(--color-success);
}
#plugin-request-navigator-hub .tab-dropdown ul li .title .method.put {
  color: var(--color-warning);
}
#plugin-request-navigator-hub .tab-dropdown ul li .title .method.patch {
  color: var(--color-notice);
}
#plugin-request-navigator-hub .tab-dropdown ul li .title .method.delete {
  color: var(--color-danger);
}
#plugin-request-navigator-hub .tab-dropdown ul li:last-child {
  border-bottom: none;
}
#plugin-request-navigator-hub .tab-dropdown ul li .btn-close {
  position: absolute;
  color: var(--hl);
  top: 0;
  bottom: 0;
  right: 0;
  padding: 0 9px 0 8px;
  display: flex;
  align-items: center;
  padding-top: 1px;
  opacity: 0;
  transition: color 0.1s ease-in-out, opacity 0.1s ease-in-out;
}
#plugin-request-navigator-hub .tab-dropdown ul li .btn-close:hover {
  color: var(--color-font);
  background-color: var(--hl-xs);
}
#plugin-request-navigator-hub .tab-dropdown ul li:hover .btn-close {
  opacity: 1;
}
#plugin-request-navigator-hub .tab-dropdown ul li:hover, #plugin-request-navigator-hub .tab-dropdown ul li.active {
  background-color: var(--hl-xs);
  color: var(--color-font);
}`;
document.head.appendChild(document.createElement("style")).appendChild(document.createTextNode(css3));

// src/ui/tab-dropdown/tab-dropdown.tsx
var id = Math.random().toString(36).substring(2);
var TabDropdown = ({ tabs, onMenuClicked, onCloseClicked }) => {
  const [listClass, setListClass] = import_react5.default.useState("hidden");
  (0, import_react5.useEffect)(() => {
    document.addEventListener("mousedown", onMouseClicked);
  }, []);
  (0, import_react5.useEffect)(() => {
    if (tabs.length === 0)
      setListClass("hidden");
  }, [tabs]);
  const switchMenuVisibility = () => {
    setListClass(listClass === "" ? "hidden" : "");
  };
  const onMouseClicked = (e) => {
    const component = document.getElementById(id);
    if (!component)
      return document.removeEventListener("mousedown", onMouseClicked);
    if (component.contains(e.target))
      return;
    setListClass("hidden");
  };
  const onMenuItemClicked = (tab) => {
    onMenuClicked(tab.requestId);
  };
  const onMenuItemCloseClicked = (e, tab) => {
    onCloseClicked(tab.requestId);
    e.stopPropagation();
  };
  return /* @__PURE__ */ import_react5.default.createElement("div", { className: `tab-dropdown ${tabs.length ? "" : "hidden"}`, id }, /* @__PURE__ */ import_react5.default.createElement("div", { className: "button", onClick: switchMenuVisibility }, tabs.length > 1 && /* @__PURE__ */ import_react5.default.createElement("span", { className: "counter" }, tabs.length), /* @__PURE__ */ import_react5.default.createElement("i", { className: "fa-solid fa-ellipsis-vertical" })), /* @__PURE__ */ import_react5.default.createElement("ul", { className: listClass }, tabs.map((tab) => /* @__PURE__ */ import_react5.default.createElement(
    "li",
    {
      key: tab.requestId,
      className: tab.isActive ? "active" : "",
      onClick: () => onMenuItemClicked(tab)
    },
    /* @__PURE__ */ import_react5.default.createElement("div", { className: "btn-close", onClick: (e) => onMenuItemCloseClicked(e, tab) }, /* @__PURE__ */ import_react5.default.createElement("i", { className: "fa-solid fa-xmark" })),
    /* @__PURE__ */ import_react5.default.createElement("div", { className: "title" }, /* @__PURE__ */ import_react5.default.createElement("span", { className: `method ${tab.method?.toLocaleLowerCase()}` }, tab.method?.toUpperCase()), /* @__PURE__ */ import_react5.default.createElement("span", { className: "text" }, tab.title))
  ))));
};

// src/ui/tabs-panel/tabs-panel.tsx
var import_react_sortable_hoc = __toESM(require_react_sortable_hoc());

// src/ui/tabs-panel/tabs-panel.hook.sortable.ts
var useSortable = ({ tabs, setTabs }) => {
  const onSortEnd = ({ oldIndex, newIndex }) => {
    const element = tabs.splice(oldIndex, 1)[0];
    tabs.splice(newIndex, 0, element);
    setTabs([...tabs]);
  };
  return {
    onSortEnd
  };
};

// src/ui/tabs-panel/tabs-panel.hook.contextmenu.ts
var useContextMenu = ({ tabs, setTabs, showTabContent }) => {
  const onCloseOthersClicked = (requestId) => {
    const tabData = tabs.find((tab) => tab.requestId == requestId);
    if (!tabData) {
      console.error("tab not found", requestId);
      return;
    }
    tabData.isActive = true;
    const updated = tabs.filter((tab) => tab.requestId === tabData.requestId);
    setTabs(updated);
    showTabContent(tabData.requestId);
  };
  const onClickCloseOnRight = (requestId) => {
    const tabData = tabs.find((tab) => tab.requestId == requestId);
    if (!tabData) {
      console.error("tab not found", requestId);
      return;
    }
    const closedTabIndex = tabs.findIndex((tab) => tab.requestId === tabData.requestId);
    const updated = tabs.slice(0, closedTabIndex + 1);
    const currentActive = updated.findIndex((tab) => tab.isActive);
    if (currentActive == -1)
      tabData.isActive = true;
    setTabs(updated);
    showTabContent(tabData.requestId);
  };
  const onClickCloseAll = () => {
    setTabs([]);
  };
  return {
    onCloseOthersClicked,
    onClickCloseOnRight,
    onClickCloseAll
  };
};

// src/ui/tabs-panel/tabs-panel.hook.dropdown.ts
var import_react6 = __toESM(require("react"));
var useDropdown = ({ tabs, id: id3 }) => {
  const [screenSize, setScreenSize] = import_react6.default.useState(0);
  const [collapsedTabs, setCollapsedTabs] = import_react6.default.useState([]);
  (0, import_react6.useEffect)(() => {
    const handleResize = () => {
      if (!isCurrentConnectionStillActive()) {
        window.removeEventListener("resize", handleResize);
        return;
      }
      setScreenSize(window.innerWidth);
    };
    window.addEventListener("resize", handleResize);
  }, []);
  (0, import_react6.useEffect)(() => {
    const root = document.getElementById(id3);
    const parent = root?.querySelector(".items");
    if (!parent) {
      return;
    }
    const children = parent.querySelectorAll(".plugin-request-navigator-tab-button");
    if (!children?.length) {
      return;
    }
    const parentRightBound = parent.getBoundingClientRect().right;
    if (!parentRightBound) {
      console.error("[plugin-navigator]", "parent has no right bound");
      return;
    }
    const tabsToCollapse = [];
    children.forEach((element) => {
      if (element.getBoundingClientRect().right > parentRightBound) {
        tabsToCollapse.push({
          method: element.getAttribute("data-method"),
          title: element.getAttribute("data-title"),
          requestId: element.getAttribute("data-request-id"),
          isActive: element.classList.contains("active")
        });
      }
    });
    setCollapsedTabs(tabsToCollapse);
  }, [tabs, screenSize]);
  return {
    collapsedTabs
  };
};

// src/ui/tabs-panel/tabs-panel.hook.request.ts
var import_react7 = require("react");
var useRequestHandlers = ({ setTabs, tabDataRef }) => {
  (0, import_react7.useEffect)(() => {
    const unsubOnRequestSelected = onRequestSelected(() => {
      const activeRequest = getActiveRequest();
      const workspaceId = getActiveWorkspace()?._id;
      if (!workspaceId) {
        console.warn("[plugin-navigator]", "no active workspace found");
        return;
      }
      const tabs = [...tabDataRef.current];
      const existsTab = tabs.find((x) => x.requestId === activeRequest?._id);
      if (!existsTab) {
        tabs.push({
          requestId: activeRequest._id,
          title: activeRequest.name,
          isActive: true,
          method: getRequestMethodName(activeRequest)
        });
      }
      tabs.forEach((x) => x.isActive = x.requestId === activeRequest?._id);
      setTabs(tabs);
    });
    return () => {
      unsubOnRequestSelected();
    };
  }, []);
  (0, import_react7.useEffect)(() => {
    onRequestUpdated((doc) => {
      const requestId = doc._id;
      if (!requestId) {
        console.warn("onRequestUpdated", "unexpected doc, request id not found", doc);
        return;
      }
      const updatedList = [...tabDataRef.current];
      const tab = updatedList.find((tab2) => tab2.requestId == requestId);
      if (!tab)
        return;
      if (tab.title == doc.name)
        return;
      tab.title = doc.name;
      setTabs(updatedList);
    });
  }, []);
  (0, import_react7.useEffect)(() => {
    onRequestDeleted((doc) => {
      const requestId = doc._id;
      if (!requestId) {
        console.warn("onRequestUpdated", "unexpected doc, request id not found", doc);
        return;
      }
      const updatedList = [...tabDataRef.current].filter((tab) => tab.requestId != requestId);
      setTabs(updatedList);
    });
  }, []);
};

// src/services/insomnia/navigator/index.ts
var navigateToRequest = (requestId) => {
  const activeOrg = getActiveOrgId();
  const activeProject = getActiveProject()?._id;
  const activeWorkspace = getActiveWorkspace()?._id;
  if (!activeOrg || !activeProject || !activeWorkspace) {
    console.warn("[plugin-navigator]", "cannot navigate to request", requestId, "because active org, project or workspace not found");
    return false;
  }
  const url = `/organization/${activeOrg}/project/${activeProject}/workspace/${activeWorkspace}/debug/request/${requestId}`;
  getRouter().navigate(url);
  return true;
};

// src/ui/tabs-panel/tabs-panel.hook.tabs.ts
var useTabs = ({ tabs, setTabs }) => {
  const onTabClicked = (requestId) => {
    const tabData = tabs.find((tab) => tab.requestId == requestId);
    if (!tabData) {
      console.warn("tab not found", requestId);
      return;
    }
    if (tabData.isActive)
      return;
    tabs.forEach((x) => x.isActive = x === tabData);
    setTabs([...tabs]);
    showTabContent(tabData.requestId);
  };
  const onCloseClicked = (requestId) => {
    const tabData = tabs.find((tab) => tab.requestId == requestId);
    if (!tabData) {
      console.warn("tab not found", requestId);
      return;
    }
    const updated = tabs.filter((tab) => tab.requestId !== tabData.requestId);
    if (tabData.isActive && updated.length) {
      const closedTabIndex = tabs.findIndex((tab) => tab.requestId === tabData.requestId);
      const activeTabIndex = Math.min(updated.length - 1, closedTabIndex);
      updated[activeTabIndex].isActive = true;
      showTabContent(updated[activeTabIndex].requestId);
    }
    setTabs(updated);
  };
  const showTabContent = (requestId) => {
    const tabData = tabs.find((tab) => tab.requestId == requestId);
    if (!tabData) {
      console.warn("tab not found", requestId);
      return;
    }
    const navigated = navigateToRequest(requestId);
    if (!navigated) {
      console.warn("Cannot navigate to request", requestId);
    }
  };
  return {
    onTabClicked,
    onCloseClicked,
    showTabContent
  };
};

// src/ui/tabs-panel/tabs-panel.tsx
var id2 = Math.random().toString(36).substring(2);
var TabsPanel = () => {
  const {
    tabs,
    setTabs,
    tabDataRef
  } = useTabsPanel();
  const { onSortEnd } = useSortable({ tabs, setTabs });
  const { collapsedTabs } = useDropdown({ tabs, id: id2 });
  const { onCloseClicked, onTabClicked, showTabContent } = useTabs({ tabs, setTabs });
  const { onClickCloseAll, onClickCloseOnRight, onCloseOthersClicked } = useContextMenu({ tabs, setTabs, showTabContent });
  useRequestHandlers({ setTabs, tabDataRef });
  (0, import_react8.useEffect)(() => {
    if (tabs.length > 0) {
      const activeTab = tabs.find((x) => x.isActive);
      if (activeTab)
        showTabContent(activeTab.requestId);
    }
  }, []);
  const SortableItem = (0, import_react_sortable_hoc.SortableElement)(({ tab }) => /* @__PURE__ */ import_react8.default.createElement(
    TabButton,
    {
      onClickButton: () => onTabClicked(tab.requestId),
      onClickClose: () => onCloseClicked(tab.requestId),
      onClickCloseOthers: () => onCloseOthersClicked(tab.requestId),
      onClickCloseOnRight: () => onClickCloseOnRight(tab.requestId),
      onClickCloseAll: () => onClickCloseAll(),
      isHidden: collapsedTabs.findIndex((x) => x.requestId === tab.requestId) !== -1 ? true : false,
      ...tab
    },
    tab.title
  ));
  const SortableList = (0, import_react_sortable_hoc.SortableContainer)(({ items }) => {
    return /* @__PURE__ */ import_react8.default.createElement("div", { className: "items" }, items.map((value2, index) => /* @__PURE__ */ import_react8.default.createElement(SortableItem, { key: `item-${value2.requestId}`, index, tab: value2 })));
  });
  return /* @__PURE__ */ import_react8.default.createElement("div", { className: `tabs-panel ${!tabs?.length ? "hidden" : ""}`, id: id2 }, /* @__PURE__ */ import_react8.default.createElement(SortableList, { items: tabs, lockAxis: "x", axis: "x", onSortEnd, distance: 10 }), /* @__PURE__ */ import_react8.default.createElement("div", { className: "dropdown" }, /* @__PURE__ */ import_react8.default.createElement(TabDropdown, { tabs: collapsedTabs, onMenuClicked: onTabClicked, onCloseClicked })));
};

// src/ui/index.tsx
var import_react9 = __toESM(require("react"));

// src/ui/index.styles.scss
var css4 = `#plugin-request-navigator-hub {
  grid-column: 1/4;
}`;
document.head.appendChild(document.createElement("style")).appendChild(document.createTextNode(css4));

// src/ui/index.tsx
var renderAsync = () => new Promise((resolve, reject) => {
  const header = document.querySelector(".\\[grid-area\\:Header\\]");
  if (!header) {
    reject(new Error("App header not found"));
    return;
  }
  const existsRoot = document.querySelector("#plugin-request-navigator-hub");
  if (existsRoot) {
    console.warn("Plugin Request Navigator is already loaded. Removing old version...");
    existsRoot.remove();
  }
  const root = document.createElement("div");
  root.id = "plugin-request-navigator-hub";
  header.appendChild(root);
  import_react_dom.default.render(
    /* @__PURE__ */ import_react9.default.createElement(TabsPanel, null),
    root,
    () => resolve()
  );
});

// src/index.ts
var initAsync = async () => {
  await renderAsync();
  window.dev = {
    router: getRouter(),
    database
  };
};
var tries = 0;
var waitForConnectionAsync = async () => {
  if (!connect()) {
    if (tries++ < 25)
      window.setTimeout(waitForConnectionAsync, 200);
    else
      console.error("[plugin-navigator]", "cannot connect to Insomnia");
  } else
    await initAsync();
};
waitForConnectionAsync();
/*! Bundled license information:

react-is/cjs/react-is.production.min.js:
  (** @license React v16.13.1
   * react-is.production.min.js
   *
   * Copyright (c) Facebook, Inc. and its affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *)

react-is/cjs/react-is.development.js:
  (** @license React v16.13.1
   * react-is.development.js
   *
   * Copyright (c) Facebook, Inc. and its affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *)

object-assign/index.js:
  (*
  object-assign
  (c) Sindre Sorhus
  @license MIT
  *)
*/
