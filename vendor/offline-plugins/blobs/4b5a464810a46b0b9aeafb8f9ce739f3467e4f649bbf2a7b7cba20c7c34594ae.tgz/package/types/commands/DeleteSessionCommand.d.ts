import { LexRuntimeServiceClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes } from "../LexRuntimeServiceClient";
import { DeleteSessionRequest, DeleteSessionResponse } from "../models/models_0";
import { Command as $Command } from "@aws-sdk/smithy-client";
import { Handler, MiddlewareStack, HttpHandlerOptions as __HttpHandlerOptions, MetadataBearer as __MetadataBearer } from "@aws-sdk/types";
export declare type DeleteSessionCommandInput = DeleteSessionRequest;
export declare type DeleteSessionCommandOutput = DeleteSessionResponse & __MetadataBearer;
/**
 * <p>Removes session information for a specified bot, alias, and user ID. </p>
 */
export declare class DeleteSessionCommand extends $Command<DeleteSessionCommandInput, DeleteSessionCommandOutput, LexRuntimeServiceClientResolvedConfig> {
    readonly input: DeleteSessionCommandInput;
    constructor(input: DeleteSessionCommandInput);
    /**
     * @internal
     */
    resolveMiddleware(clientStack: MiddlewareStack<ServiceInputTypes, ServiceOutputTypes>, configuration: LexRuntimeServiceClientResolvedConfig, options?: __HttpHandlerOptions): Handler<DeleteSessionCommandInput, DeleteSessionCommandOutput>;
    private serialize;
    private deserialize;
}
