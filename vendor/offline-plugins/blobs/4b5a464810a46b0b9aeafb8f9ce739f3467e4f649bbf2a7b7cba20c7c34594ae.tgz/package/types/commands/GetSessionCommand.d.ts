import { LexRuntimeServiceClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes } from "../LexRuntimeServiceClient";
import { GetSessionRequest, GetSessionResponse } from "../models/models_0";
import { Command as $Command } from "@aws-sdk/smithy-client";
import { Handler, MiddlewareStack, HttpHandlerOptions as __HttpHandlerOptions, MetadataBearer as __MetadataBearer } from "@aws-sdk/types";
export declare type GetSessionCommandInput = GetSessionRequest;
export declare type GetSessionCommandOutput = GetSessionResponse & __MetadataBearer;
/**
 * <p>Returns session information for a specified bot, alias, and user ID.</p>
 */
export declare class GetSessionCommand extends $Command<GetSessionCommandInput, GetSessionCommandOutput, LexRuntimeServiceClientResolvedConfig> {
    readonly input: GetSessionCommandInput;
    constructor(input: GetSessionCommandInput);
    /**
     * @internal
     */
    resolveMiddleware(clientStack: MiddlewareStack<ServiceInputTypes, ServiceOutputTypes>, configuration: LexRuntimeServiceClientResolvedConfig, options?: __HttpHandlerOptions): Handler<GetSessionCommandInput, GetSessionCommandOutput>;
    private serialize;
    private deserialize;
}
