declare type SHA1Encoding = 'base64' | 'latin1' | 'hex';
declare class UsernameToken {
    private _created;
    private _nonce;
    private _password;
    private _sha1encoding;
    private _username;
    constructor({ username, password, created, nonce, sha1encoding }: {
        username: string;
        password: string;
        created?: string;
        nonce?: string;
        sha1encoding?: SHA1Encoding;
    });
    getCreated(): string;
    getNonce(): string;
    getNonceBase64(): string;
    getPassword(): string;
    getPasswordDigest(): string;
    getUsername(): string;
    getWSSEHeader(options?: {
        nonceBase64?: boolean;
    }): string;
    newToken(): UsernameToken;
    toString(options?: {
        nonceBase64?: boolean;
    }): string;
    private _base64;
    private _sha1;
    private _newCreated;
    private _newNonce;
}
declare const usernameToken: ({ username, password }: {
    username: string;
    password: string;
}) => UsernameToken;
export default usernameToken;
export { UsernameToken };
