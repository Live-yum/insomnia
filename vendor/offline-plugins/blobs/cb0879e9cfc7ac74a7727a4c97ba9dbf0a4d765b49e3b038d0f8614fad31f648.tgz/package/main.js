const fs = require('fs');

function decodeBase64(content) {
    return Buffer.from(content, 'base64');
}

function bufferToString(buffer) {
    return buffer.toString('utf8');
}

async function saveGrpcStreamAsFile(context, location, response) {
    try {
        const fileContent = fs.readFileSync(response.bodyPath, 'utf8');
        const contents = bufferToString(fileContent);
        const appended = [];

        contents.split('\n').forEach(content => {
            if (content == '' || content == null) {
                return;
            }
            const parsedContent = JSON.parse(content);
            const decodedContent = decodeBase64(parsedContent.content);
            appended.push(decodedContent);
        });

        const bytes = Buffer.concat(appended);
        const outputStream = fs.createWriteStream(location);
        outputStream.write(bytes);
        outputStream.close();

        context.app.alert('File successfully saved: ' + location);
    } catch (error) {
        context.app.alert('Error occurred while saving file');
    }
}

async function handleSaveDialog(context, data) {
    try {
        const location = await context.app.showSaveDialog();
        if (!location) {
            context.app.alert('Error occurred while choosing file location');
            return;
        }

        const { request } = data;
        const response = await context.network.sendRequest(request);
        await saveGrpcStreamAsFile(context, location, response);
    } catch (error) {
        context.app.alert('Error occurred during file save process');
    }
}

module.exports.requestActions = [
    {
        label: 'Save grpc stream as file',
        action: async (context, data) => {
            await handleSaveDialog(context, data);
        },
    }
];
