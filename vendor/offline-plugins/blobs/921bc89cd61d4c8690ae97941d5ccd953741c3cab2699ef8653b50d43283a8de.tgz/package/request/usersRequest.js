module.exports = function (context) {
    
    let results = [];

    results.push("{Username: 'Banana', Password: 'password1'}");
    results.push("{Username: 'Orange', Password: 'password2'}");

    var cLen = results.length;

    for (var j=0; j<cLen; j++) {
        context.request.setUrl("https://tripsplit-backend.herokuapp.com/api/auth/login");
        context.request.setBody(results[j]);

        const response = await context.network.sendRequest(context.jrequest);
        
        const style =
          response.statusCode !== 200
            ? "padding:5px; color: var(--color-font-danger); background: var(--color-danger)"
            : "padding:5px; color: var(--color-font-success); background: var(--color-success)";
        results.push(
          `<li style="margin: 5px">${request.name}: <span style="${style}")>${response.statusCode}</span></li>`
        );

        const html = `<ul style="column-count: ${
            results.length > 10 ? 2 : 1
          };">${results.join("\n")}</ul>`;
    
          context.app.showGenericModalDialog("Results", { html });
    
    }
};