// For help writing plugins, visit the documentation to get started:
//   https://support.insomnia.rest/article/26-plugins

// TODO: Add plugin code here...

module.exports.requestHooks = [
    /*name: 'userloadtest',
    displayName: 'userloadtest',
    description: 'Automate Load test',*/
  
    /*async run (context) {*/
    (context) => {

      const request = require('request');

      let user = ["Banana", "Orange", "Apple", "Grape", "Kiwi"];
      //let pwd = ["password1", "password2", "password3", "password4", "password5"];
        
      var uLen, utext, udatabase;
      //var ptext, pdatabase;

      uLen = user.length;
      //pLen = pwd.length;

      udatabase = new Array();
      //pdatabase = new Array();

      for (var j=0; j<uLen; j++) {
        utext = ''.concat(user[j], '');
        udatabase.push(utext);

        //ptext = ''.concat(pwd[j], '');
        //pdatabase.push(ptext);
      }

      for (var i in udatabase) {
        if( typeof udatabase[i] == 'string' ) {

          request.post('https://tripsplit-backend.herokuapp.com/api/auth/login', {
            json: {
              username: udatabase[i]
              //password: pdatabase[i],
            }
            
          }, (error, res, body) => {
            if (error) {
              console.error(error)
              return
            }
            console.log(`statusCode: ${res.statusCode}`)
            console.log(body)
          });
          //return context.store.getItem(udatabase[i]);
        }
      }
      //return udatabase[i];
    },
];
