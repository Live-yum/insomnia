module.exports.themes = [
  {
    name: "monokai", // theme name in kebab-case
    displayName: "Monokai", // formatted theme name
    theme: {
      // Background, foreground, and highlight values nested directly in the theme
      // object will serve as the default overwrites for all properties you add.
      background: {
        default: "#272822", // primary background color
        success: "#00FF00", // POST request, 200 OK, parameter names
        notice: "#E8F086", // PATCH request
        warning: "#A691AE", // PUT request
        danger: "#FF0000", // DELETE request
        surprise: "#FF8000", // accent (Dashboard link, GET request,
        // SEND button, branch button, add plugin button)
        info: "#58A6FF", // OPTIONS AND HEAD request
      },
      foreground: {
        default: "#fff", // primary font color
        success: "#fff", // secondary font color for success background
        notice: "#000", // secondary font color for notice background
        warning: "#fff", // secondary font color for warning background
        danger: "#fff", // secondary font color for danger background
        surprise: "#000", // secondary font color for surprise background
        info: "#000", // secondary font color for info background
      },
      highlight: {
        default: "#D3D3D3", // sidebar highlight color
      },
      // The styles object targets sub-components of the Insomnia application.
      styles: {
        appHeader: {
          foreground: {
            surprise: "#000", // header branch button font color
          },
        },
        paneHeader: {
          foreground: {
            surprise: "#000", // pane accent font color
            info: "#000", // pane response font color
          },
        },
        editor: {
          foreground: {
            default: "#000", // primary editor font color
            surprise: "#000", // editor accent font color
            info: "#000", // editor response font color
          },
        },
        dialog: {
          background: {
            default: "#2E4052", // modal primary background color
          },
          foreground: {
            default: "#fff", // modal primary font color
          },
        },
      },
    },
  },
];
