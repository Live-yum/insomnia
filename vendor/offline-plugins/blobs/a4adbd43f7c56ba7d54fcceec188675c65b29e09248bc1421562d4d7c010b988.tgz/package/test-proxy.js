import { HttpsProxyAgent } from 'https-proxy-agent';
const fetch = require('node-fetch');

async function testProxy() {
  const response = await window.fetch('http://10.192.37.45/sonar/projects', {
    method: 'GET',
    mode: 'same-origin',
    agent: new HttpsProxyAgent('http://proxyparfil.si.fr.intraorange:8080')
  });
  console.log(response.json());
}

testProxy();