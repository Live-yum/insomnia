const HttpsProxyAgent = require('https-proxy-agent');
const fetch = require('node-fetch');

class gitlab {
  constructor(context, config) {
    this.context = context
    this.loadConfig(config)
    console.log("Loaded config@gitlab", this.config)
  }

  getFetchOptions() {
    return {
      method: 'GET',
      headers: { 'Authorization': `Bearer ${this.config.token}`, 'Content-Type': 'application/json' },
      agent: new HttpsProxyAgent(this.config.proxy)
    };
  }

  async getGist() {
    try {
      const res = await fetch(`${this.config.api_url}/snippets/${this.config.gist_id}/raw`, this.getFetchOptions());
      console.log('gist received', res);
      return res.json();
    } catch (e) {
      console.log('gist receive err', e);
      throw "Retreiving of the file failed"
    }
  }

  async createGist(content) {
    const fetchOptions = this.getFetchOptions();
    fetchOptions.method = 'POST';
    fetchOptions.body = JSON.stringify({
      title: 'Insomnia sync data',

      file_name: 'insomnia_data.json',
      content: content,

      visibility: this.config.visibility,
    });

    const response = await fetch(this.config.api_url, fetchOptions);

    // Update gist ID on config
    this.config.gist_id = response.json().id

    // Update saved config gist ID
    // TODO, move this to a provider interface, instead of modifying it per-provider
    let conf = await this.context.store.getItem('gist-sync:config');
    let config = JSON.parse(conf);
    config.gistID = response.id
    conf = JSON.stringify(config)
    await this.context.store.setItem('gist-sync:config', conf);
  }

  async updateGist(content) {
    const fetchOptions = this.getFetchOptions();
    fetchOptions.method = 'PUT';
    fetchOptions.body = JSON.stringify({
      content: content,
    });

    await fetch(`${this.config.api_url}/snippets/${this.config.gist_id}`, fetchOptions);
  }

  /**
   * Validate is the configuration parameters are complete, and set defaults if required.
   * Then, save the configuration in the instance of the class
   * @param {configObject} config
   * @returns boolean Tells if the configuration is correct
   */
  loadConfig(config) {
    this.config = []
    if (typeof (config.token) !== "string" || config.token == "")
      throw "Invalid token";
    this.config.token = config.token

    if (typeof (config.gistID) === undefined || config.gistID == "") {
      this.config.gist_id = null;
    } else {
      this.config.gist_id = config.gistID;
    }

    if (typeof (config.baseURL) !== "string" || config.baseURL == "") {
      this.config.base_url = "https://gitlab.com"
    } else {
      this.config.base_url = config.baseURL;
    }

    if (typeof (config.projectID) !== "string" || config.projectID == "") {
      this.config.project_id = null
    } else {
      this.config.project_id = config.projectID;
    }

    if (typeof (config.visibility) !== "string" || config.visibility == "") {
      this.config.visibility = "private"
    } else {
      this.config.visibility = config.visibility;
    }

    if (this.config.project_id === null) {
      this.config.api_url = `${this.config.base_url}/api/v4`
    } else {
      this.config.api_url = `${this.config.base_url}/api/v4/projects/${this.config.project_id}`
    }

    if (typeof (config.timeout) !== "number" || config.timeout == "") {
      this.config.timeout = 5000;
    } else {
      this.config.timeout = config.timeout;
    }

    if (typeof (config.proxy) !== "string" || config.proxy == "") {
      this.config.proxy = null;
    } else {
      this.config.proxy = config.proxy;
    }

    if (typeof (config.workspace) !== "string" || config.workspace == "") {
      this.config.workspace = null;
    } else {
      this.config.workspace = config.workspace;
    }
  }
}

module.exports = gitlab
