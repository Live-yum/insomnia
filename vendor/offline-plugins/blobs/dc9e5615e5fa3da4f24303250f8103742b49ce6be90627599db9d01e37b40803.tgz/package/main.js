const linkAjaHmac = require('./helpers/linkAjaHmac');

const httpVersion = "HTTP/1.1";
const date = (new Date()).toUTCString();
const url = 'http://partner-dev.linkaja.com/v1/oauth/create';
const method = 'GET';

let params = {
    httpVersion: httpVersion,
    date: date,
    url: url,
    method: method,
    username: "",
    secret: "",          
    data: "",
    contentType: ""
}

function setParams(context) {
    const requestUrl    = context.request.getUrl();
    const requestBody   = context.request.getBody();
    const httpMethod    = context.request.getMethod().toUpperCase();

    params.url      = requestUrl;
    params.method   = httpMethod;
    params.date     = (new Date()).toUTCString();

    if (httpMethod === 'POST' || httpMethod === 'UPDATE') {
        params.data         = requestBody.text != undefined ? requestBody.text : '';
        params.contentType  = context.request.getHeader('Content-Type');
    }
}

module.exports.templateTags = [         
    {
        name: 'LinkAja',
        displayName: 'LinkAja HMAC Generator',
        description: 'Generate Signature for Authorization, Digest & Date LinkAja',
        args: [
            {
                displayName: 'Username',
                type: 'string',
                placeholder: 'Entry Username'
            },
            {
                displayName: 'Secret',
                type: 'string',
                placeholder: 'Entry SHA256-Key'
            },
        ],
        async run(context, username, secret) {        
            params.username = username;
            params.secret   = secret;

            let headers = linkAjaHmac.getSignatureBaseString(params);    
            return headers.Authorization;   
        }
    }
];

module.exports.requestHooks = [
    context => {
        setParams(context);
        let headers = linkAjaHmac.getSignatureBaseString(params);
        console.log(headers);
        console.log(params);

        context.request.getHeaders().forEach(h => {
            if (h.name === 'Authorization') {
                context.request.setHeader('Authorization', headers.Authorization);
                context.request.setHeader('Host', headers.Host);
                context.request.setHeader('Date', headers.Date);

                if (params.method === 'POST' || params.method === 'UPDATE') {
                    context.request.setHeader('Digest', headers.Digest);
                    context.request.setHeader('Content-Type', headers['Content-Type']);
                }
            }
        });
    }
];


