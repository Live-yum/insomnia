# insomnia-plugin-idtoken
Plugin for Insomnia that provides access to a request id token
