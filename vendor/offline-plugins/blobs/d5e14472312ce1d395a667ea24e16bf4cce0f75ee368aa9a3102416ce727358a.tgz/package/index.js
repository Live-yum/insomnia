module.exports.templateTags = [require('./src/id-token'), require('./src/auth-prefix')];
