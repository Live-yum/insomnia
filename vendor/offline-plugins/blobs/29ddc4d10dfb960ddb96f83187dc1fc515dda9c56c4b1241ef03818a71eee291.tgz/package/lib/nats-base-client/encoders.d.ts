export declare const Empty: Uint8Array<ArrayBuffer>;
export declare const TE: TextEncoder;
export declare const TD: TextDecoder;
export declare function encode(...a: string[]): Uint8Array;
export declare function decode(a: Uint8Array): string;
