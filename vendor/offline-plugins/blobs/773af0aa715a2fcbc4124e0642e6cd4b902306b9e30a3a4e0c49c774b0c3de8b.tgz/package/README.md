# insomnia-plugin-env-diff

[![npm version](https://img.shields.io/npm/v/insomnia-plugin-env-diff.svg)](https://www.npmjs.com/package/insomnia-plugin-env-diff)
[![license: MIT](https://img.shields.io/badge/license-MIT-green.svg)](LICENSE)

Local-only environment comparison for Insomnia. v1.1.2 hardens Markdown table escaping and records export diagnostics/fallback metadata in the JSON sidecar.

Env Diff exports a redacted Markdown report showing environment drift: missing keys, prod/dev URL mismatches, duplicate environment names, empty or short secret-like values, and suspicious same values across environments.

## Why

API teams often keep Base, Dev, Staging, and Production environments in one workspace. Over time those environments drift: keys go missing, staging points to prod, prod points to sandbox, and copied secrets leak into the wrong place.

## Features

- Adds robust Markdown escaping for report table cells
- Adds a priority fixes section for high/medium findings
- Adds source diagnostics and fallback metadata to the JSON sidecar
- Adds a key matrix across all exposed environments
- Adds desktop export diagnostics and paste-JSON fallback
- Writes a redacted JSON sidecar next to every Markdown report
- Compares all Insomnia environments in the workspace
- Flags keys missing from one or more environments
- Flags dev/staging environments pointing at production-like hosts
- Flags production environments pointing at dev/test hosts
- Flags empty or suspiciously short secret-like values
- Flags same non-secret values across environments
- Flags duplicate environment names
- Exports a local redacted Markdown report
- No cloud, no telemetry, no backend, no dependencies

## Install

From Insomnia:

1. Open **Preferences** → **Plugins**
2. Enter `insomnia-plugin-env-diff`
3. Click **Install Plugin**

Manual macOS install:

```bash
cd "$HOME/Library/Application Support/Insomnia/plugins"
npm install insomnia-plugin-env-diff
```

## Usage

Run:

```text
Env Diff: Export Report
```

The action is exposed through `workspaceActions`, `requestGroupActions`, and `requestActions`. In Insomnia 13 it may appear in the New Request dropdown.

Each export writes two local files:

```text
insomnia-env-diff.md
insomnia-env-diff.json
```

The JSON sidecar uses schema `insomnia-env-diff/v1` and includes:

```json
{
  "schema": "insomnia-env-diff/v1",
  "generatedAt": "...",
  "sourceDiagnostics": {
    "bytes": 1234,
    "topKeys": ["resources"],
    "environments": 2
  },
  "usedFallback": false,
  "summary": {
    "environmentsCompared": 2,
    "keysCompared": 5,
    "totalFindings": 3,
    "high": 1,
    "medium": 1,
    "low": 1
  },
  "priority": [],
  "matrix": [],
  "findings": []
}
```

## Example report

```markdown
# Insomnia Env Diff Report

## Summary

- High: 1
- Medium: 2
- Low: 3

| Severity | Type | Location | Message | Preview |
|---|---|---|---|---|
| high | dev-points-to-prod | Dev.base_url | Development/staging environment points at production-like host | Dev: api.production.example.com |
```

## Desktop validation notes

In some Insomnia Desktop menu contexts, `context.data.export.insomnia()` may expose zero environment resources. Env Diff now reports `env-export-empty` and prompts for pasted environment JSON when Insomnia does not expose environments. Paste either a single environment object or `{ "Dev": {...}, "Prod": {...} }` to run full pairwise diff locally.

## Privacy

- Local-only
- No network calls
- No analytics
- No account required
- Exports with `includePrivate: false`
- Secret-like values are redacted in reports

## Development

```bash
git clone https://github.com/oliviajohns5/insomnia-plugin-env-diff.git
cd insomnia-plugin-env-diff
npm test
npm run test:hard
npm run test:packaged
npm pack --dry-run
```

## Verified QA

- `node --check main.js`
- `node --check test.js`
- `node --check hard-qa.js`
- `node --check real-insomnia-packaged-test.js`
- `node --check qa-packaged.js`
- `npm test`
- `npm run test:hard`
- `npm run test:packaged`
- `npm pack --dry-run`
- isolated tarball install
- package metadata validation
- credential literal scan

## Requirements

- Insomnia
- Node.js/npm only for development or publishing

## License

MIT

## Changelog

### 1.1.3

- Report export now supports Electron-style save dialog results and still writes the JSON sidecar.


### 1.1.2

- Escapes Markdown table cells consistently for environment names, keys, finding types, locations, messages, and previews.
- Adds a priority fixes section and JSON `priority` entries for top high/medium findings.
- Adds JSON sidecar `sourceDiagnostics` and `usedFallback` metadata.

### 1.1.1

- Adds type-drift detection for environment keys whose values change type across environments.
