var forge = require("node-forge");
var fs = require("fs");

createMessageSignature = function (request, privKeyLoc) {

    // Read the private key from a file
    let privateKey = fs.readFileSync(privKeyLoc);
    var decryptedPrivateKey = forge.pki.decryptRsaPrivateKey(privateKey);
    var md = forge.md.sha256.create();
    md.update(JSON.stringify(request));
    var signature = decryptedPrivateKey.sign(md);
 
    return forge.util.bytesToHex(signature);

};

module.exports.templateTags = [
    {
        name: "Create_Message_Signature",
        displayName: "Create Message Signature",
        description: "RSA Encode Request Payload using node-forge",
        args: [
            {
                displayName: "Request Message",
                type: "string",
                placeholder: "-- request payload --"               
            },
            {
                displayName: "Directory with private key (PEM) file",
                type: "string",
                placeholder: "-- c:/users/<userId>/.ssh/mySubFolder/myPrivateKey.pem --"
            }
        ],
        run(context, request = "", keyLocation = "") {
            return createMessageSignature(request, keyLocation);
        }
    }
];
