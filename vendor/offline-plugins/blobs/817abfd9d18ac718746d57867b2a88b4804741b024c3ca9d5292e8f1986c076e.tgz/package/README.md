# insomnia-plugin-create-message-signature

The Create Message Signature plugin for for [Insomnia](https://insomnia.rest) takes the body of a request message, uses the private key, and encodes the payload as SHA256withRSA encrypted string.

## Installing

Go to the `Application>Preferences` menu in Insomnia, then go to the `Plugins` tab, search for `insomnia-plugin-create-message-signature` and install it.

If that doesn't work, execute the following command from a command line terminal:  npm i insomnia-plugin-create-message-signature

There is always the option of manually adding the plugin to the C:\Users\<userId>\AppData\Roaming\Insomnia\plugins directory.

## Usage

On the plugin dialog...

Provide:

1. the request body (highly recommend using the Insomnia plugin "insomnia-plugin-request-body" to fetch the payload)
2. the full directory location of the private key (PEM) file
