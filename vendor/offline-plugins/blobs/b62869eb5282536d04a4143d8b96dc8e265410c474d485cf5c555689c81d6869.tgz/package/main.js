var CryptoJS = require("crypto-js");

var secretKey;

module.exports.templateTags = [
  {
    name: "Des",
    displayName: "Des",
    description: "encrypt or decrypt values",
    args: [
      {
        displayName: "Input",
        type: "string",
        placeholder: "input some text",
      },
      {
        displayName: "Type",
        type: "enum",
        options: [
          {
            displayName: "Encrypt",
            value: "encrypt",
          },
          {
            displayName: "Decrypt",
            value: "decrypt",
          },
        ],
      },
    ],
    run(context, input, type) {
      secretKey = context.context?.getMeta()?.workspaceId;
      if (input && type && type == "encrypt") {
        return desEncrypt(input);
      }
      if (input && type && type == "decrypt") {
        return desDecrypt(input);
      }
      return "...";
    },
  },
];

const desEncrypt = (text) => {
  const { key, iv, source } = initDes(text, true);
  const encrypted = CryptoJS.DES.encrypt(source, key, {
    iv: iv,
    mode: CryptoJS.mode.CBC,
    padding: CryptoJS.pad.Pkcs7,
  });
  return encrypted.toString();
};

const desDecrypt = (text) => {
  const { key, iv, source } = initDes(text);
  const decrypted = CryptoJS.DES.decrypt(source, key, {
    iv: iv,
    mode: CryptoJS.mode.CBC,
    padding: CryptoJS.pad.Pkcs7,
  });
  return decrypted.toString(CryptoJS.enc.Utf8);
};

const initDes = (text, isEncrypt) => {
  const desKey = secretKey;
  const desIv = "0123456789ABCDEFG";
  return {
    key: CryptoJS.enc.Utf8.parse(desKey),
    iv: CryptoJS.enc.Utf8.parse(desIv),
    source: isEncrypt ? CryptoJS.enc.Utf8.parse(text) : text,
  };
};
