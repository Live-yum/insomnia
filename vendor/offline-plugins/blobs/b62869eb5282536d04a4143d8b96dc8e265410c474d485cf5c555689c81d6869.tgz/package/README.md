
## Installation
Install the `insomnia-plugin-des` plugin from Preferences > Plugins.

## Usage

### You can encrypt values
```
{
    "text":"{% Des 'world', 'encrypt' %}"
}
```


### You can decrypt values
```
{
    "text": "{% Des '************************', 'decrypt' %}"
}
```

## Scope
- Encrypt or decrypt your password or something.