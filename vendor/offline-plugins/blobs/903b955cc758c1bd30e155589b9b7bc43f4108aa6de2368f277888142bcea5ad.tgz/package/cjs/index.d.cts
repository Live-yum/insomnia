declare class Token {
    private value;
    constructor(value: string);
    toString(): string;
}

declare class DisplayString {
    private value;
    constructor(value: string);
    toString(): string;
}

/**
 * Lists are arrays of zero or more members, each of which can be an Item
 * or an Inner List, both of which can be Parameterized
 */
type List = (InnerList | Item)[];
/**
 * An Inner List is an array of zero or more Items. Both the individual Items
 * and the Inner List itself can be Parameterized.
 */
type InnerList = [Item[], Parameters];
/**
 * Parameters are an ordered map of key-value pairs that are associated with
 * an Item or Inner List. The keys are unique within the scope of the
 * Parameters they occur within, and the values are bare items (i.e., they
 * themselves cannot be parameterized
 */
type Parameters = Map<string, BareItem>;
/**
 * Dictionaries are ordered maps of key-value pairs, where the keys are short
 * textual strings and the values are Items or arrays of Items, both of which
 * can be Parameterized.
 *
 * There can be zero or more members, and their keys are unique in the scope
 * of the Dictionary they occur within.
 */
type Dictionary = Map<string, Item | InnerList>;
/**
 * Another representatation of a Dictionary.
 *
 * Serialize functions also accept an Object instead of a Map for a
 * Dictionary. Parse functions will always return the Map however.
 */
type DictionaryObject = Record<string, BareItem | Item | InnerList>;
/**
 * A standalone value: the value of an Item, or of a parameter.
 *
 * A Byte Sequence may be serialized from any `BufferSource`, so a
 * `Uint8Array`, a Node `Buffer` or a `DataView` can be passed as-is. Parsing
 * always returns an `ArrayBuffer`.
 */
type BareItem = number | string | Token | BufferSource | Date | boolean | DisplayString;
type Item = [BareItem, Parameters];

declare class SerializeError extends Error {
}
declare function serializeList(input: List): string;
declare function serializeDictionary(input: Dictionary | DictionaryObject): string;
/**
 * Serialize a Structured Fields Item.
 *
 * An Item is a standalone value like a string, number of date, followed by
 * an optional set of parameters.
 *
 * You can either pass the value in the first argument and parameters in the second, or pass both as a tuple. The later exists for symmetry with parseItem.
 */
declare function serializeItem(input: Item): string;
declare function serializeItem(input: BareItem, params?: Parameters): string;
declare function serializeInnerList(input: InnerList): string;
declare function serializeBareItem(input: BareItem): string;
declare function serializeInteger(input: number): string;
declare function serializeDecimal(input: number): string;
declare function serializeString(input: string): string;
declare function serializeDisplayString(input: DisplayString): string;
declare function serializeBoolean(input: boolean): string;
declare function serializeByteSequence(input: BufferSource): string;
declare function serializeToken(input: Token): string;
declare function serializeDate(input: Date): string;
declare function serializeParameters(input: Parameters): string;
declare function serializeKey(input: string): string;

declare function parseDictionary(input: string): Dictionary;
declare function parseList(input: string): List;
declare function parseItem(input: string): Item;
declare class ParseError extends Error {
    constructor(position: number, message: string);
}

declare function isAscii(str: string): boolean;
declare function isValidTokenStr(str: string): boolean;
declare function isValidKeyStr(str: string): boolean;
declare function isInnerList(input: Item | InnerList): input is InnerList;
declare function arrayBufferToBase64(input: BufferSource): string;
declare function base64ToArrayBuffer(b64: string): ArrayBuffer;

export { type BareItem, type Dictionary, type DictionaryObject, DisplayString, type InnerList, type Item, type List, type Parameters, ParseError, SerializeError, Token, arrayBufferToBase64, base64ToArrayBuffer, isAscii, isInnerList, isValidKeyStr, isValidTokenStr, parseDictionary, parseItem, parseList, serializeBareItem, serializeBoolean, serializeByteSequence, serializeDate, serializeDecimal, serializeDictionary, serializeDisplayString, serializeInnerList, serializeInteger, serializeItem, serializeKey, serializeList, serializeParameters, serializeString, serializeToken };
