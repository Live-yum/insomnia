export declare const name = "@azure/msal-node";
export declare const version = "5.2.4";
//# sourceMappingURL=packageMetadata.d.ts.map