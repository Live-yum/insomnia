# Change Log

## 4.5.2

### Patch Changes

- 99c3f91: Restore npm provenance attestations. No functional changes.
- Updated dependencies [99c3f91]
  - @smithy/core@3.33.2
  - @smithy/types@4.17.2

## 4.5.1

### Patch Changes

- d774f8d: chore: build packages with typescript 7. Packages continue to be compatible with TypeScript 3.4 through 7.0 in consumer applications.
- Updated dependencies [b3958ad]
- Updated dependencies [d774f8d]
  - @smithy/core@3.33.1
  - @smithy/types@4.17.1

## 4.5.0

### Minor Changes

- ec9b4b2: chore: update builds to use typescript 6. This should not affect consumers, who may continue to use TypeScript 3.4 through 7.0 as of this version.

### Patch Changes

- Updated dependencies [ec9b4b2]
  - @smithy/types@4.17.0
  - @smithy/core@3.32.0

## 4.4.16

### Patch Changes

- Updated dependencies [fcf1366]
  - @smithy/core@3.31.1

## 4.4.15

### Patch Changes

- Updated dependencies [a14bb71]
  - @smithy/core@3.31.0

## 4.4.14

### Patch Changes

- Updated dependencies [54040ef]
- Updated dependencies [155bb56]
  - @smithy/core@3.30.0

## 4.4.13

### Patch Changes

- Updated dependencies [d6e6f8b]
  - @smithy/core@3.29.8

## 4.4.12

### Patch Changes

- Updated dependencies [44b21e6]
  - @smithy/core@3.29.7

## 4.4.11

### Patch Changes

- Updated dependencies [3248fbd]
  - @smithy/core@3.29.6

## 4.4.10

### Patch Changes

- Updated dependencies [b44cb0a]
  - @smithy/core@3.29.5

## 4.4.9

### Patch Changes

- Updated dependencies [5fca3a0]
  - @smithy/core@3.29.4

## 4.4.8

### Patch Changes

- Updated dependencies [a97abc3]
  - @smithy/types@4.16.1
  - @smithy/core@3.29.3

## 4.4.7

### Patch Changes

- 273e480: types updates for isolatedModules=true
- Updated dependencies [273e480]
- Updated dependencies [74b3d45]
  - @smithy/types@4.16.0
  - @smithy/core@3.29.2

## 4.4.6

### Patch Changes

- Updated dependencies [1fac409]
  - @smithy/core@3.29.1

## 4.4.5

### Patch Changes

- Updated dependencies [12bceb2]
- Updated dependencies [4395dad]
  - @smithy/core@3.29.0
  - @smithy/types@4.15.1

## 4.4.4

### Patch Changes

- Updated dependencies [d366537]
- Updated dependencies [c0d7f5d]
  - @smithy/core@3.28.0

## 4.4.3

### Patch Changes

- Updated dependencies [c9575e1]
- Updated dependencies [2dcefdb]
- Updated dependencies [91280a5]
  - @smithy/core@3.27.0

## 4.4.2

### Patch Changes

- Updated dependencies [3cfda3b]
  - @smithy/core@3.26.0

## 4.4.1

### Patch Changes

- Updated dependencies [63ddca4]
  - @smithy/core@3.25.1

## 4.4.0

### Minor Changes

- 17e50e9: update dist-cjs output format to use plain require/exports statements

### Patch Changes

- Updated dependencies [17e50e9]
  - @smithy/types@4.15.0
  - @smithy/core@3.25.0

## 4.3.9

### Patch Changes

- 1e5bdd3: Update author URL in package.json to be more specific
- bcbadbc: package json updates
- Updated dependencies [1e5bdd3]
- Updated dependencies [13e74d6]
- Updated dependencies [3bc3322]
- Updated dependencies [bcbadbc]
  - @smithy/core@3.24.7
  - @smithy/types@4.14.4

## 4.3.8

### Patch Changes

- 9ea5ce5: import node:http,https,http2 using default export object (writable)

## 4.3.7

### Patch Changes

- Updated dependencies [776bc52]
- Updated dependencies [5b92a54]
  - @smithy/types@4.14.3
  - @smithy/core@3.24.6

## 4.3.6

### Patch Changes

- dfa58f2: switch from node:url->parse to new URL() for parsing URI

## 4.3.5

### Patch Changes

- Updated dependencies [721fbed]
  - @smithy/core@3.24.5

## 4.3.4

### Patch Changes

- Updated dependencies [9eaa5c6]
  - @smithy/core@3.24.4

## 4.3.3

### Patch Changes

- Updated dependencies [cf00244]
  - @smithy/types@4.14.2
  - @smithy/core@3.24.3

## 4.3.2

### Patch Changes

- Updated dependencies [6d4eb8a]
  - @smithy/core@3.24.2

## 4.3.1

### Patch Changes

- Updated dependencies [2dc5cf6]
- Updated dependencies [1d0ff86]
  - @smithy/core@3.24.1

## 4.3.0

### Minor Changes

- 4f30af1: consolidation for core/protocols
- 62fed78: package consolidation for core/config

### Patch Changes

- Updated dependencies [ee92b6b]
- Updated dependencies [540aeb4]
- Updated dependencies [0be0b36]
- Updated dependencies [4f30af1]
- Updated dependencies [8963b91]
- Updated dependencies [fb323fb]
- Updated dependencies [9194e9f]
- Updated dependencies [7ec62a0]
- Updated dependencies [62fed78]
- Updated dependencies [cad44fc]
- Updated dependencies [545589a]
- Updated dependencies [f21bf6b]
- Updated dependencies [7fd6ac0]
  - @smithy/core@3.24.0

## 4.2.14

### Patch Changes

- Updated dependencies [131fce4]
- Updated dependencies [52b4789]
  - @smithy/types@4.14.1
  - @smithy/node-config-provider@4.3.14
  - @smithy/property-provider@4.2.14
  - @smithy/url-parser@4.2.14

## 4.2.13

### Patch Changes

- Updated dependencies [cffd868]
  - @smithy/types@4.14.0
  - @smithy/node-config-provider@4.3.13
  - @smithy/property-provider@4.2.13
  - @smithy/url-parser@4.2.13

## 4.2.12

### Patch Changes

- Updated dependencies [5340b11]
  - @smithy/types@4.13.1
  - @smithy/node-config-provider@4.3.12
  - @smithy/property-provider@4.2.12
  - @smithy/url-parser@4.2.12

## 4.2.11

### Patch Changes

- a4d95e6: Set downlevel types to be used in typescript@'<4.5'
- Updated dependencies [a4d95e6]
  - @smithy/node-config-provider@4.3.11
  - @smithy/property-provider@4.2.11
  - @smithy/url-parser@4.2.11

## 4.2.10

### Patch Changes

- Updated dependencies [d0954cc]
  - @smithy/types@4.13.0
  - @smithy/node-config-provider@4.3.10
  - @smithy/property-provider@4.2.10
  - @smithy/url-parser@4.2.10

## 4.2.9

### Patch Changes

- 03c3dc8: update for rollup build externalLiveBindings=false
- Updated dependencies [03c3dc8]
  - @smithy/node-config-provider@4.3.9
  - @smithy/property-provider@4.2.9
  - @smithy/types@4.12.1
  - @smithy/url-parser@4.2.9

## 4.2.8

### Patch Changes

- Updated dependencies [745867a]
  - @smithy/types@4.12.0
  - @smithy/node-config-provider@4.3.8
  - @smithy/property-provider@4.2.8
  - @smithy/url-parser@4.2.8

## 4.2.7

### Patch Changes

- Updated dependencies [9ccb841]
  - @smithy/types@4.11.0
  - @smithy/node-config-provider@4.3.7
  - @smithy/property-provider@4.2.7
  - @smithy/url-parser@4.2.7

## 4.2.6

### Patch Changes

- Updated dependencies [5a56762]
  - @smithy/types@4.10.0
  - @smithy/node-config-provider@4.3.6
  - @smithy/property-provider@4.2.6
  - @smithy/url-parser@4.2.6

## 4.2.5

### Patch Changes

- Updated dependencies [3926fd7]
  - @smithy/types@4.9.0
  - @smithy/node-config-provider@4.3.5
  - @smithy/property-provider@4.2.5
  - @smithy/url-parser@4.2.5

## 4.2.4

### Patch Changes

- Updated dependencies [6da0ab3]
  - @smithy/types@4.8.1
  - @smithy/node-config-provider@4.3.4
  - @smithy/property-provider@4.2.4
  - @smithy/url-parser@4.2.4

## 4.2.3

### Patch Changes

- Updated dependencies [8a2a912]
  - @smithy/types@4.8.0
  - @smithy/node-config-provider@4.3.3
  - @smithy/property-provider@4.2.3
  - @smithy/url-parser@4.2.3

## 4.2.2

### Patch Changes

- Updated dependencies [052d261]
  - @smithy/types@4.7.1
  - @smithy/node-config-provider@4.3.2
  - @smithy/property-provider@4.2.2
  - @smithy/url-parser@4.2.2

## 4.2.1

### Patch Changes

- Updated dependencies [761d89c]
- Updated dependencies [7f8af58]
  - @smithy/types@4.7.0
  - @smithy/node-config-provider@4.3.1
  - @smithy/property-provider@4.2.1
  - @smithy/url-parser@4.2.1

## 4.2.0

### Minor Changes

- 45ee67f: update dist-cjs generation to use rollup

### Patch Changes

- Updated dependencies [45ee67f]
  - @smithy/node-config-provider@4.3.0
  - @smithy/property-provider@4.2.0
  - @smithy/types@4.6.0
  - @smithy/url-parser@4.2.0

## 4.1.2

### Patch Changes

- @smithy/node-config-provider@4.2.2

## 4.1.1

### Patch Changes

- Updated dependencies [bb7c1c1]
  - @smithy/types@4.5.0
  - @smithy/node-config-provider@4.2.1
  - @smithy/property-provider@4.1.1
  - @smithy/url-parser@4.1.1

## 4.1.0

### Minor Changes

- 64cda93: set sideEffects bundler metadata

### Patch Changes

- f884df7: enforce consistent-type-imports
- Updated dependencies [64cda93]
- Updated dependencies [f884df7]
  - @smithy/node-config-provider@4.2.0
  - @smithy/property-provider@4.1.0
  - @smithy/url-parser@4.1.0
  - @smithy/types@4.4.0

## 4.0.7

### Patch Changes

- Updated dependencies [64e033f]
  - @smithy/types@4.3.2
  - @smithy/node-config-provider@4.1.4
  - @smithy/property-provider@4.0.5
  - @smithy/url-parser@4.0.5

## 4.0.6

### Patch Changes

- Updated dependencies [358c1ff]
  - @smithy/types@4.3.1
  - @smithy/node-config-provider@4.1.3
  - @smithy/property-provider@4.0.4
  - @smithy/url-parser@4.0.4

## 4.0.5

### Patch Changes

- Updated dependencies [0547fab]
  - @smithy/types@4.3.0
  - @smithy/node-config-provider@4.1.2
  - @smithy/property-provider@4.0.3
  - @smithy/url-parser@4.0.3

## 4.0.4

### Patch Changes

- Updated dependencies [9f8d075]
  - @smithy/node-config-provider@4.1.1

## 4.0.3

### Patch Changes

- Updated dependencies [acefcf5]
- Updated dependencies [9ff783b]
  - @smithy/node-config-provider@4.1.0

## 4.0.2

### Patch Changes

- Updated dependencies [e917e61]
  - @smithy/types@4.2.0
  - @smithy/node-config-provider@4.0.2
  - @smithy/property-provider@4.0.2
  - @smithy/url-parser@4.0.2

## 4.0.1

### Patch Changes

- Updated dependencies [2aff9df]
- Updated dependencies [000b2ae]
  - @smithy/types@4.1.0
  - @smithy/node-config-provider@4.0.1
  - @smithy/property-provider@4.0.1
  - @smithy/url-parser@4.0.1

## 4.0.0

### Major Changes

- 20d99be: major version bump for dropping node16 support

### Patch Changes

- Updated dependencies [20d99be]
  - @smithy/node-config-provider@4.0.0
  - @smithy/property-provider@4.0.0
  - @smithy/types@4.0.0
  - @smithy/url-parser@4.0.0

## 3.2.8

### Patch Changes

- Updated dependencies [b52b4e8]
  - @smithy/types@3.7.2
  - @smithy/node-config-provider@3.1.12
  - @smithy/property-provider@3.1.11
  - @smithy/url-parser@3.0.11

## 3.2.7

### Patch Changes

- Updated dependencies [fcd5ca8]
  - @smithy/types@3.7.1
  - @smithy/node-config-provider@3.1.11
  - @smithy/property-provider@3.1.10
  - @smithy/url-parser@3.0.10

## 3.2.6

### Patch Changes

- Updated dependencies [cd1929b]
  - @smithy/types@3.7.0
  - @smithy/node-config-provider@3.1.10
  - @smithy/property-provider@3.1.9
  - @smithy/url-parser@3.0.9

## 3.2.5

### Patch Changes

- Updated dependencies [84bec05]
  - @smithy/types@3.6.0
  - @smithy/node-config-provider@3.1.9
  - @smithy/property-provider@3.1.8
  - @smithy/url-parser@3.0.8

## 3.2.4

### Patch Changes

- Updated dependencies [a4c1285]
  - @smithy/types@3.5.0
  - @smithy/node-config-provider@3.1.8
  - @smithy/property-provider@3.1.7
  - @smithy/url-parser@3.0.7

## 3.2.3

### Patch Changes

- Updated dependencies [e7b438b]
  - @smithy/types@3.4.2
  - @smithy/node-config-provider@3.1.7
  - @smithy/property-provider@3.1.6
  - @smithy/url-parser@3.0.6

## 3.2.2

### Patch Changes

- Updated dependencies [cf9257e]
  - @smithy/types@3.4.1
  - @smithy/node-config-provider@3.1.6
  - @smithy/property-provider@3.1.5
  - @smithy/url-parser@3.0.5

## 3.2.1

### Patch Changes

- Updated dependencies [2dad138]
- Updated dependencies [9f3f2f5]
  - @smithy/types@3.4.0
  - @smithy/node-config-provider@3.1.5
  - @smithy/property-provider@3.1.4
  - @smithy/url-parser@3.0.4

## 3.2.0

### Minor Changes

- 3d72b04: sources accountId from IMDS

## 3.1.4

### Patch Changes

- @smithy/node-config-provider@3.1.4

## 3.1.3

### Patch Changes

- Updated dependencies [4784fb9]
  - @smithy/types@3.3.0
  - @smithy/node-config-provider@3.1.3
  - @smithy/property-provider@3.1.3
  - @smithy/url-parser@3.0.3

## 3.1.2

### Patch Changes

- Updated dependencies [c16e014]
- Updated dependencies [c2a5595]
  - @smithy/types@3.2.0
  - @smithy/node-config-provider@3.1.2
  - @smithy/property-provider@3.1.2
  - @smithy/url-parser@3.0.2

## 3.1.1

### Patch Changes

- Updated dependencies [38da9009]
  - @smithy/types@3.1.0
  - @smithy/node-config-provider@3.1.1
  - @smithy/property-provider@3.1.1
  - @smithy/url-parser@3.0.1

## 3.1.0

### Minor Changes

- 1cdd3be0: new logging-compatible signature for CredentialsProviderError

### Patch Changes

- Updated dependencies [1cdd3be0]
  - @smithy/node-config-provider@3.1.0
  - @smithy/property-provider@3.1.0

## 3.0.0

### Major Changes

- 671aa704: update to node16 minimum

### Patch Changes

- Updated dependencies [7a7c84d3]
- Updated dependencies [671aa704]
  - @smithy/types@3.0.0
  - @smithy/node-config-provider@3.0.0
  - @smithy/property-provider@3.0.0
  - @smithy/url-parser@3.0.0

## 2.3.0

### Minor Changes

- 38f9a61f: Update package dependencies

### Patch Changes

- Updated dependencies [38f9a61f]
- Updated dependencies [661f1d60]
  - @smithy/node-config-provider@2.3.0
  - @smithy/property-provider@2.2.0
  - @smithy/url-parser@2.2.0
  - @smithy/types@2.12.0

## 2.2.6

### Patch Changes

- Updated dependencies [43f3e1e2]
  - @smithy/types@2.11.0
  - @smithy/node-config-provider@2.2.5
  - @smithy/property-provider@2.1.4
  - @smithy/url-parser@2.1.4

## 2.2.5

### Patch Changes

- eea7af7d: fix: credential expiration extension log message
- e136eb93: exporting Endpoint from credential-provider-imds to use for JSv3 EC2 IMDS utils

## 2.2.4

### Patch Changes

- @smithy/node-config-provider@2.2.4

## 2.2.3

### Patch Changes

- Updated dependencies [dd0d9b4b]
  - @smithy/types@2.10.1
  - @smithy/node-config-provider@2.2.3
  - @smithy/property-provider@2.1.3
  - @smithy/url-parser@2.1.3

## 2.2.2

### Patch Changes

- Updated dependencies [d70a00ac]
- Updated dependencies [1e23f967]
  - @smithy/types@2.10.0
  - @smithy/node-config-provider@2.2.2
  - @smithy/property-provider@2.1.2
  - @smithy/url-parser@2.1.2

## 2.2.1

### Patch Changes

- 2b1bf055: generate dist-cjs with runtime list of export names for esm
- Updated dependencies [2b1bf055]
  - @smithy/node-config-provider@2.2.1
  - @smithy/property-provider@2.1.1
  - @smithy/types@2.9.1
  - @smithy/url-parser@2.1.1

## 2.2.0

### Minor Changes

- 9939f823: bundle dist-cjs index

### Patch Changes

- Updated dependencies [9939f823]
  - @smithy/node-config-provider@2.2.0
  - @smithy/property-provider@2.1.0
  - @smithy/url-parser@2.1.0
  - @smithy/types@2.9.0

## 2.1.5

### Patch Changes

- Updated dependencies [590af6b7]
  - @smithy/types@2.8.0
  - @smithy/node-config-provider@2.1.9
  - @smithy/property-provider@2.0.17
  - @smithy/url-parser@2.0.16

## 2.1.4

### Patch Changes

- @smithy/node-config-provider@2.1.8

## 2.1.3

### Patch Changes

- Updated dependencies [340634a5]
  - @smithy/types@2.7.0
  - @smithy/node-config-provider@2.1.7
  - @smithy/property-provider@2.0.16
  - @smithy/url-parser@2.0.15

## 2.1.2

### Patch Changes

- Updated dependencies [9bfc64ed]
- Updated dependencies [9579a9a0]
  - @smithy/types@2.6.0
  - @smithy/node-config-provider@2.1.6
  - @smithy/property-provider@2.0.15
  - @smithy/url-parser@2.0.14

## 2.1.1

### Patch Changes

- Updated dependencies [8044a814]
  - @smithy/types@2.5.0
  - @smithy/node-config-provider@2.1.5
  - @smithy/property-provider@2.0.14
  - @smithy/url-parser@2.0.13

## 2.1.0

### Minor Changes

- 4693031d: Add IMDSv1 toggle.

### Patch Changes

- @smithy/node-config-provider@2.1.4

## 2.0.18

### Patch Changes

- Updated dependencies [5e9fd6ce]
- Updated dependencies [05f5d42c]
  - @smithy/types@2.4.0
  - @smithy/node-config-provider@2.1.3
  - @smithy/property-provider@2.0.13
  - @smithy/url-parser@2.0.12

## 2.0.17

### Patch Changes

- @smithy/node-config-provider@2.1.2

## 2.0.16

### Patch Changes

- Updated dependencies [d6b4c090]
  - @smithy/types@2.3.5
  - @smithy/node-config-provider@2.1.1
  - @smithy/property-provider@2.0.12
  - @smithy/url-parser@2.0.11

## 2.0.15

### Patch Changes

- Updated dependencies [7b568c39]
  - @smithy/node-config-provider@2.1.0

## 2.0.14

### Patch Changes

- @smithy/node-config-provider@2.0.14

## 2.0.13

### Patch Changes

- Updated dependencies [2f70f105]
- Updated dependencies [9a562d37]
  - @smithy/types@2.3.4
  - @smithy/node-config-provider@2.0.13
  - @smithy/property-provider@2.0.11
  - @smithy/url-parser@2.0.10

## 2.0.12

### Patch Changes

- Updated dependencies [ea0635d6]
  - @smithy/types@2.3.3
  - @smithy/node-config-provider@2.0.12
  - @smithy/property-provider@2.0.10
  - @smithy/url-parser@2.0.9

## 2.0.11

### Patch Changes

- Updated dependencies [fbfeebee]
- Updated dependencies [c0b17a13]
  - @smithy/types@2.3.2
  - @smithy/node-config-provider@2.0.11
  - @smithy/property-provider@2.0.9
  - @smithy/url-parser@2.0.8

## 2.0.10

### Patch Changes

- Updated dependencies [b9265813]
- Updated dependencies [6d1c2fb1]
  - @smithy/types@2.3.1
  - @smithy/node-config-provider@2.0.10
  - @smithy/property-provider@2.0.8
  - @smithy/url-parser@2.0.7

## 2.0.9

### Patch Changes

- @smithy/node-config-provider@2.0.9

## 2.0.8

### Patch Changes

- Updated dependencies [88bcec3d]
  - @smithy/types@2.3.0
  - @smithy/node-config-provider@2.0.8
  - @smithy/property-provider@2.0.7
  - @smithy/url-parser@2.0.6

## 2.0.7

### Patch Changes

- @smithy/node-config-provider@2.0.7

## 2.0.6

### Patch Changes

- Updated dependencies [a7598a5d]
  - @smithy/property-provider@2.0.6
  - @smithy/node-config-provider@2.0.6

## 2.0.5

### Patch Changes

- Updated dependencies [b753dd4c]
- Updated dependencies [6c8ffa27]
  - @smithy/types@2.2.2
  - @smithy/node-config-provider@2.0.5
  - @smithy/property-provider@2.0.5
  - @smithy/url-parser@2.0.5

## 2.0.4

### Patch Changes

- Updated dependencies [381e03c4]
  - @smithy/types@2.2.1
  - @smithy/node-config-provider@2.0.4
  - @smithy/property-provider@2.0.4
  - @smithy/url-parser@2.0.4

## 2.0.3

### Patch Changes

- Updated dependencies [f6cb949d]
  - @smithy/types@2.2.0
  - @smithy/node-config-provider@2.0.3
  - @smithy/property-provider@2.0.3
  - @smithy/url-parser@2.0.3

## 2.0.2

### Patch Changes

- Updated dependencies [59548ba9]
- Updated dependencies [3e1ab589]
  - @smithy/types@2.1.0
  - @smithy/node-config-provider@2.0.2
  - @smithy/property-provider@2.0.2
  - @smithy/url-parser@2.0.2

## 2.0.1

### Patch Changes

- Updated dependencies [1b951769]
  - @smithy/types@2.0.2
  - @smithy/node-config-provider@2.0.1
  - @smithy/property-provider@2.0.1
  - @smithy/url-parser@2.0.1

## 2.0.0

### Major Changes

- 9d53bc76: update to 2.x major versions

### Patch Changes

- Updated dependencies [9d53bc76]
  - @smithy/node-config-provider@2.0.0
  - @smithy/property-provider@2.0.0
  - @smithy/url-parser@2.0.0
  - @smithy/types@2.0.1

## 1.1.0

### Minor Changes

- e3cbb3cc: set types to the 1.x line

### Patch Changes

- Updated dependencies [e3cbb3cc]
  - @smithy/node-config-provider@1.1.0
  - @smithy/property-provider@1.2.0
  - @smithy/types@1.2.0
  - @smithy/url-parser@1.1.0

## 1.0.3

### Patch Changes

- Updated dependencies [8cd89c75]
- Updated dependencies [4ad43c6a]
- Updated dependencies [d90a45b5]
- Updated dependencies [5f7bcc79]
  - @smithy/types@2.0.0
  - @smithy/property-provider@1.1.0
  - @smithy/node-config-provider@1.0.3
  - @smithy/url-parser@1.0.3

## 1.0.2

### Patch Changes

- 6e312329: restore downlevel types
- Updated dependencies [6e312329]
  - @smithy/node-config-provider@1.0.2
  - @smithy/property-provider@1.0.2
  - @smithy/url-parser@1.0.2
  - @smithy/types@1.1.1

## 1.0.1

### Patch Changes

- 2c57033f: Set correct publishConfig directory
- Updated dependencies [2c57033f]
  - @smithy/node-config-provider@1.0.1
  - @smithy/property-provider@1.0.1
  - @smithy/url-parser@1.0.1

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

See [@aws-sdk/credential-provider-imds](https://github.com/aws/aws-sdk-js-v3/blob/main/packages/credential-provider-imds/CHANGELOG.md) for additional history.
