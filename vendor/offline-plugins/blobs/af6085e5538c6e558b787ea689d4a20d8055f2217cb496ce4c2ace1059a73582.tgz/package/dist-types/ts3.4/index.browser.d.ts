export { fromCognitoIdentity } from "./fromCognitoIdentity";
export {
  FromCognitoIdentityParameters,
  CognitoIdentityCredentialProvider,
} from "./fromCognitoIdentity";
export { fromCognitoIdentityPool } from "./fromCognitoIdentityPool";
export { FromCognitoIdentityPoolParameters } from "./fromCognitoIdentityPool";
export { fromHttp } from "./fromHttp";
export { FromHttpOptions, HttpProviderCredentials } from "./fromHttp";
export { fromTemporaryCredentials } from "./fromTemporaryCredentials.browser";
export { FromTemporaryCredentialsOptions } from "./fromTemporaryCredentials.browser";
export { fromWebToken } from "./fromWebToken";
