export { FromTemporaryCredentialsOptions } from "./fromTemporaryCredentials.base";
export { fromTemporaryCredentials } from "./fromTemporaryCredentials.base";
