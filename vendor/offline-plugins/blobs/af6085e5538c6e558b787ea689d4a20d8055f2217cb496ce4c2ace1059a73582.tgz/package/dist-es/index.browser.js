export { fromCognitoIdentity } from "./fromCognitoIdentity";
export { fromCognitoIdentityPool } from "./fromCognitoIdentityPool";
export { fromHttp } from "./fromHttp";
export { fromTemporaryCredentials } from "./fromTemporaryCredentials.browser";
export { fromWebToken } from "./fromWebToken";
