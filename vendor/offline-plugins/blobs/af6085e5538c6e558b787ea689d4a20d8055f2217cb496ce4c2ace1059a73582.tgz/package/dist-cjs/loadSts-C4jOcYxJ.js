const { AssumeRoleCommand, STSClient } = require("@aws-sdk/nested-clients/sts");
exports.AssumeRoleCommand = AssumeRoleCommand;
exports.STSClient = STSClient;
