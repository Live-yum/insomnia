const md5 = require("md5");

module.exports.templateTags = [{
    name: 'md5',
    displayName: 'MD5',
    description: 'Generate a MD5 hash.',
    args: [
        {
            displayName: 'String',
            description: 'string',
            type: 'string',
        }
    ],
    async run(context, string) {
        return md5(string);
    }
}];