To use Insomnia -> Preferences -> Plugins -> npm-package-name = 
insomnia-plugin-phoenix -> Install Plugin -> Enjoy

