/*
 * Phoenix Insomnia plugin code
 */

module.exports.currentFranchiseId = "";
module.exports.currentJwtToken = "";
module.exports.responseTypes = {};

module.exports.templateTags = [
    {
        name: 'phxjwt',
        displayName: 'Session JWT',
        description: 'Replaces with a ready to go JWT string',
        args: [],
        async run (context) {
            return module.exports.currentJwtToken;
        }
    },
];

module.exports.requestHooks = [
    ({request}) => {
        const mthd = request.getMethod().toLowerCase();
        const urlPart = request.getUrl().replace("://", "");
        const uri = urlPart.substr(urlPart.indexOf("/"));
        const requestId = request.getId();

        const type = (() => {
            // Register
            if (mthd === "post" && uri === "/api/user") return ["AUTH_TOKEN"];
            // Login
            if (mthd === "post" && uri === "/api/user/login") return ["AUTH_TOKEN"];
            // Login to agency
            if (mthd === "post" && uri === "/api/user/login_to_agency") return ["AUTH_TOKEN"];
            // Switch agency
            if (mthd === "post" && uri === "/api/user/switch_agency") return ["AUTH_TOKEN"];
        })();

        if (module.exports.currentJwtToken !== undefined) {
            request.setAuthenticationParameter('token', module.exports.currentJwtToken);
        }

        if (type !== undefined) {
            module.exports.responseTypes[requestId] = type;
        }
    }
];

module.exports.responseHooks = [
    ({response}) => {
        const requestId = response.getRequestId();
        if (module.exports.responseTypes[requestId] === undefined) return;

        const json = JSON.parse(response.getBody().toString());

        module.exports.responseTypes[requestId].forEach(e => {
            switch (e) {
                case "AUTH_TOKEN":
                    if (json.authToken !== undefined) {
                        module.exports.currentJwtToken = json.authToken;
                    }
                    break;
            }
        });

        module.exports.responseTypes[requestId] = undefined;
    }
];
