# Send and Download Folder

This plugin essentially adds the advanced "Send And Download" command to each folder's drop-down menu. Running this command will send every request inside the selected folder and download all the responses.

Now updated with a folder browser dialogue so you can specify where responses are downloaded to! 

To use the plugin, simply install it in Insomnia Core with the button on this page or directly from your [insomnia.rest](https://insomnia.rest/) client by going into **Preferences -> Plugins**, entering `insomnia-plugin-2muchspicy` and clicking "Install Plugin".

To specify the download path for the request responses, click the **Send & Download Folder - Set Path** option in the **Workspace Actions** drop-down. If no download path is specified, the plugin downloads all responses to `Documents/Insomnia` by default.

All credit to [Daniel Castro](https://github.com/LunaticoCR) and [Greg Schier](https://github.com/gschier) as this plugin is a modified version of the [insomnia-plugin-run-folder](https://insomnia.rest/plugins/insomnia-plugin-run-folder) plugin by Daniel Castro. 