const fs = require('fs');
const homedir = require('os').homedir();
const pluginPath = "AppData/Roaming/Insomnia/plugins/insomnia-plugin-2muchspicy"

async function getDownloadPath(context) {
  var downloadFolder;
  var downloadPathFile = `${homedir}/${pluginPath}/dlPath.txt`;

  if (fs.existsSync(downloadPathFile)) {
    downloadFolder = fs.readFileSync(downloadPathFile);

    if (!fs.existsSync(downloadFolder)){
      await context.app.alert('Save & Download Folder Plugin - Error!', "Saved download path no longer exists! Using default Documents/Insomnia path instead.");
      fs.unlinkSync(downloadPathFile);
      downloadFolder = `${homedir}\\Documents\\Insomnia`;
      fs.mkdirSync(downloadFolder, {recursive: true});
    }
    return downloadFolder;
  } else {
    downloadFolder = `${homedir}\\Documents\\Insomnia`;

    if (!fs.existsSync(downloadFolder)){
      fs.mkdirSync(downloadFolder, {recursive: true});
    }
    return downloadFolder;
  }
}

module.exports.workspaceActions = [{
  label: 'Send & Download Folder - Set Path',
  icon: 'fa-cog',
  action: async (context, models) => {
    downloadFolder = await context.app.showSaveDialog({defaultPath: models.workspace.name});
    downloadFolder = downloadFolder.substr(0, downloadFolder.lastIndexOf('\\'));
    fs.writeFileSync(`${homedir}/${pluginPath}/dlPath.txt`, downloadFolder);
  },
}];

module.exports.requestGroupActions = [
  {
    label: 'Send & DL All Requests',
    action: async (context, data) => {
      downloadFolder = await getDownloadPath(context);
      const { requests } = data;

      let results = [];
      results.push(`<tr>
                      <th>Request</th>
                      <th>Status Code</th>
                      <th>Time</th>
                      <th>Bytes</th>
                    </tr>`);
      for (const request of requests) {
        // Request hook to save response to file
        module.exports.responseHooks = [
          context => {
          context.response.getBodyStream().pipe(
              fs.createWriteStream(`${downloadFolder}/${request.name}.json`)
            );
          }
        ];
        const response = await context.network.sendRequest(request);
        var color = getStatusCodeColor(response.statusCode);
        var time = millisecToHumanReadable(response.elapsedTime);
        results.push(`<tr>
                        <td id="td_left"><font color="${color}">[${request.method}] ${request.name}</td>
                        <td id="td_right"><font color="${color}">${response.statusCode} ${response.statusMessage}</font></td>
                        <td id="td_right">${time}</td>
                        <td id="td_right">${response.bytesRead}</td>
                      </tr>`);
      }

      const css = `table { margin: 0 auto 0 auto; }
                   th, .label--small, label > small { text-align: left; padding: 10px 10px 10px 15px !important; padding-bottom: none !important; font-size: 15px !important; border: 1px solid #4B505C; }
                   td { border: 1px solid #4B505C; }
                   #td_left { text-align: left; padding: 3px 40px 3px 10px; }
                   #td_right { text-align: center; padding: 3px 3px 3px 3px; }`
      const html = `<html><head><style>${css}</style></head><body><table bgcolor="#282D35">${results.join('\n')}</table></body></html>`;

      context.app.showGenericModalDialog(`Results downloaded to: ${downloadFolder}`, { html });
    },
  },
];

function getStatusCodeColor(statusCode) {
  if (statusCode.toString().startsWith("2")) {
    return "#8AB46C";
  } else if (statusCode.toString().startsWith("4")) {
    return "#D19A66";
  } else if (statusCode.toString().startsWith("5")) {
    return "#D8696F";
  }
}

function millisecToHumanReadable(millisec) {
  var seconds = (millisec / 1000).toFixed(2);

  if (millisec < 1000) {
    return millisec.toFixed(0) + " ms";
  } else if (seconds < 60) {
    return seconds + " s";
  }
}