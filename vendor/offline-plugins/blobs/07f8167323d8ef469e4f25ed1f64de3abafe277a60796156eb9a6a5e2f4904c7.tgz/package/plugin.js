const http = require('http');
const https = require('https');
const URL = require('url');
const fs = require('fs');

function get_token(authenticate_url, authenticate_payload) {
    const b = URL.parse(authenticate_url);
    const body = JSON.stringify(authenticate_payload);
    const options = {
	protocol: b.protocol,
	hostname: b.host,
	path: b.path,
	method: 'POST',
	headers: {
	    'Content-Type': 'application/json',
	    'Content-Length': Buffer.byteLength(body),
	}
    }
    const module = b.protocol === 'http:' ? http : https;
    const req = module.request(options, res => {
	res.setEncoding('utf8');
	var buffer = '';
	res.on('data', chunk => {
	    buffer += chunk;
	});
	res.on('end', () => {
	    const body = JSON.parse(buffer);
	    const access_token = body.access_token;
            if (!access_token) {
                alert("Failed to get access_token");
            }
	    tokens[authenticate_url] = access_token;
	    save();
	});
    });
    req.write(body);
    req.end();
}

const config = __dirname + "/config";

function load() {
    try {
	const content = fs.readFileSync(config);
	return JSON.parse(content);
    } catch (err) {
	return {};
    }
}

function save() {
    try {
	const content = JSON.stringify(tokens);
	fs.writeFileSync(config, content);
    } catch (err) {
    }
}

const tokens = load();
const request_id_to_authenticate_config = {};

function get_authenticate_config(request) {
    return {
        url: request.getEnvironmentVariable("authenticate_url"),
        payload: request.getEnvironmentVariable("authenticate_payload"),
    };
}

module.exports.requestHooks = [
    context => {
	const request = context.request;
	if (!request.hasHeader("Authorization")) {
            const authenticate_config = get_authenticate_config(request);
            if (authenticate_config.url && authenticate_config.payload) {
                request_id_to_authenticate_config[request.getId()] = authenticate_config;
	        if (tokens[authenticate_config.url]) {
		    request.setHeader("Authorization", "Bearer " + tokens[authenticate_config.url]);
	        } else {
		    get_token(authenticate_config.url, authenticate_config.payload);
	        }
            }
	}
    }
]

module.exports.responseHooks = [
    context => {
	const response = context.response;
        if (response.getStatusCode() === 401) {
            const authenticate_config = request_id_to_authenticate_config[response.getRequestId()];
            if (authenticate_config) {
                get_token(authenticate_config.url, authenticate_config.payload);
                delete request_id_to_authenticate_config[response.getRequestId()];
            }
        }
    }
]
