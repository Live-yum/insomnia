'use strict'

const { generateSignature } = require('@ied/signature')

module.exports.templateTags = [
  {
    name: 'signature',
    displayName: 'HMAC-IED',
    description: 'Apply HMAC to a value with @ied/signature',
    args: [
      {
        displayName: 'Key',
        type: 'string',
        placeholder: 'HMAC Secret Key',
      },
      {
        displayName: 'ttl in seconds',
        type: 'number',
        placeholder: 'Optional TTL value in second',
      },
      {
        displayName: 'query string',
        type: 'boolean',
        placeholder: 'whether the signature is used as query string or not',
      },
    ],
    async run(context, key = '', ttl = undefined, queryString = false) {
      const { meta } = context

      const request = await context.util.models.request.getById(meta.requestId)
      const httpMethod = request.method

      // const url = await context.util.render(request.url);
      const [noQueryStringURL] = request.url.split('?')
      let url = await context.util.render(noQueryStringURL)
      url = new URL(url.replace(/^http:/, 'https:'))

      const body = request.body.text

      const restQuery = {
        body,
        method: httpMethod,
        url,
      }

      const signature = generateSignature(restQuery, key, ttl)

      if (queryString) {
        const [part1, part2] = signature.split(':')
        return `_signature=${part2 || part1}${part2 && part1 ? `&_signature_ttl=${part1}` : ''}`
      }

      return `${signature}`
    },
  },
]
