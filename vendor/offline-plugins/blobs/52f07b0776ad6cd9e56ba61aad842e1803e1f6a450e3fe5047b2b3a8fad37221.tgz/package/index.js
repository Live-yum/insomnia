const fs = require('fs');

async function promptApiKey(context, model, forceReprompt) {
    const fileKeyPath = 'sync:file-path-' + model.workspace.name;
    const oldFilePath = await context.store.getItem(fileKeyPath);
    if (!oldFilePath || forceReprompt) {
        try {
            const apiKey = await context.app.prompt(
                'Sync - Configuration - file path',
                {
                    label: 'Put your file path here:',
                    defaultValue: oldFilePath,
                    submitName: 'Save',
                    cancelable: true,
                },
            );
            const sanitizedApiKey = apiKey.trim();
            if (sanitizedApiKey === '') {
                context.store.removeItem(fileKeyPath);
                return null;
            }
            await context.store.setItem(fileKeyPath, sanitizedApiKey);
            return sanitizedApiKey;
        } catch {}
    }
    return oldFilePath;
}

module.exports.workspaceActions = [
    {
        label: 'Sync - Send',
        icon: 'fa-upload',
        action: async (context, models) => {
            const apiKey = await promptApiKey(context, models, false);
            if (!apiKey) {
                await context.app.alert(
                    'Configuration error',
                    'The File path must be configured',
                );
                return;
            }
            const data = await context.data.export.insomnia({
                includePrivate: false,
                format: 'json',
                workspace: models.workspace,
            });
            const content = JSON.stringify(JSON.parse(data), null, 2);
            fs.writeFile(apiKey, content, async function(err) {
                if (err) {
                    await context.app.alert(
                        'Configuration error',
                        'The File path must be configured',
                    );
                }
            });
        },
    },
    {
        label: 'Sync - Receive',
        icon: 'fa-download',
        action: async (context, models) => {
            const apiKey = await promptApiKey(context, models, false);
            console.log('apiKey', apiKey);
            if (!apiKey) {
                console.log('apiKey', apiKey);
                await context.app.alert(
                    'Configuration error',
                    'The GitHub API Key must be configured',
                );
                return;
            }
            const content = fs.readFileSync(apiKey,  'utf8');
            await context.data.import.raw(content);
        },
    },
    {
        label: 'Sync - Configure',
        icon: 'fa-cogs',
        action: async (context, models) => {
            await promptApiKey(context, models, true);
        },
    },
];