import { ApiPropertyOptions } from "@nestjs/swagger";
export declare class SwaggerUtils {
    static amountPropertyOptions(extraOptions?: ApiPropertyOptions): ApiPropertyOptions;
}
