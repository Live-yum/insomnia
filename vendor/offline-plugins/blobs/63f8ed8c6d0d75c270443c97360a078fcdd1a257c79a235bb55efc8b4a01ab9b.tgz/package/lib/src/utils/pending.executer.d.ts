export declare class PendingExecuter {
    private readonly dictionary;
    execute<TOut>(key: string, executer: () => Promise<TOut>): Promise<TOut>;
}
