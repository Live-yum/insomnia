export declare class BatchUtils {
    static batchGet<TIN, TOUT>(elements: TIN[], identifierFunc: (element: TIN) => string, funcs: ({
        getter: (elements: TIN[]) => Promise<{
            [key: string]: TOUT;
        }>;
        setter?: (elements: {
            [key: string]: TOUT;
        }) => Promise<void>;
    }[]) | ((elements: TIN[]) => Promise<{
        [key: string]: TOUT;
    }>), chunkSize: number): Promise<{
        [key: string]: TOUT;
    }>;
    static batchGetSimple<TIN, TOUT>(elements: TIN[], identifierFunc: (element: TIN) => string, getter: (elements: TIN[]) => Promise<{
        [key: string]: TOUT;
    }>, chunkSize: number): Promise<{
        found: {
            [key: string]: TOUT;
        };
        remaining: TIN[];
    }>;
    static splitArrayIntoChunks<T>(elements: T[], chunkSize: number): T[][];
    static splitObjectIntoChunks<T>(elements: {
        [key: string]: T;
    }, chunkSize: number): {
        [key: string]: T;
    }[];
}
