export declare class ApiUtils {
    static mergeObjects<T extends object>(obj1: T, obj2: any): T;
    static cleanupApiValueRecursively(obj: any): any;
    static replaceUri(uri: string, pattern: string, replacer: string): string;
}
