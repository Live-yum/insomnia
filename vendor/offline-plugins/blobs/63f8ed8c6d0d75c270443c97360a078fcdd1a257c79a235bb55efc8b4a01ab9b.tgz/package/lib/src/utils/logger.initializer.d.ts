import { Logger } from "@nestjs/common";
export declare class LoggerInitializer {
    static initialize(logger: Logger): void;
}
