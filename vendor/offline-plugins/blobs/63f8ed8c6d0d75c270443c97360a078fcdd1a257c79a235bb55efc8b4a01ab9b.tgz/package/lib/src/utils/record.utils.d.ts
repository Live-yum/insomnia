export declare class RecordUtils {
    static mapKeys<T>(obj: Record<string, T>, predicate: (key: string) => string): Record<string, T>;
}
