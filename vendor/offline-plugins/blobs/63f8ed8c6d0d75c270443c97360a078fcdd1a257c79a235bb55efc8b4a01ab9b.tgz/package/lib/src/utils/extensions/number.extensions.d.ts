declare interface Number {
    toRounded(digits?: number): number;
    in(...elements: number[]): boolean;
}
