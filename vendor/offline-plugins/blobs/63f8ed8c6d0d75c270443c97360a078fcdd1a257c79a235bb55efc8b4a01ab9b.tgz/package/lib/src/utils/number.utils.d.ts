export declare class NumberUtils {
    static denominate(value: BigInt, decimals?: number): number;
    static denominateString(value: string, decimals?: number): number;
    static toDenominatedString(amount: BigInt, decimals?: number): string;
    static numberDecode(encoded: string): string;
}
