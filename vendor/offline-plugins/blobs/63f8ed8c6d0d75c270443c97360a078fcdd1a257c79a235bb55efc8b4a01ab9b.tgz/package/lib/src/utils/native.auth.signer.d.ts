import { NativeAuthClientConfig } from '@elrondnetwork/native-auth-client/lib/src/entities/native.auth.client.config';
export declare class NativeAuthSignerConfig extends NativeAuthClientConfig {
    signerPrivateKeyPath?: string | undefined;
    privateKey?: string | undefined;
}
export declare class AccessTokenInfo {
    token: string;
    expiryDate: Date;
}
export declare class NativeAuthSigner {
    private readonly config;
    private readonly nativeAuthClient;
    private userSigner?;
    private accessTokenInfo?;
    constructor(config: Partial<NativeAuthSignerConfig>);
    getToken(): Promise<AccessTokenInfo>;
    private getUserSigner;
    private getSignableToken;
    private getSignableMessage;
}
