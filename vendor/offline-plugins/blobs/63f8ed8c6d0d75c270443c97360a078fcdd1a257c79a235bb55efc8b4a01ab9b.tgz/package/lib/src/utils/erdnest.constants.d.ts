export declare const ERDNEST_CONFIG_SERVICE = "ErdnestConfigService";
