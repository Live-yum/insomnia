declare interface Date {
    toISODateString(): string;
    isToday(): boolean;
    isGreaterThan(other: Date): boolean;
    isLessThan(other: Date): boolean;
    startOfHour(): Date;
    startOfDay(): Date;
    startOfMonth(): Date;
    startOfYear(): Date;
    addSeconds(seconds: number): Date;
    addMinutes(minutes: number): Date;
    addHours(hours: number): Date;
    addDays(days: number): Date;
}
