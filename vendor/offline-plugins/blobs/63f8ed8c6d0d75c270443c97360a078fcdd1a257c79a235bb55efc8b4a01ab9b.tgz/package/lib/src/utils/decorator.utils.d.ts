import { Type } from "@nestjs/common";
export declare class DecoratorUtils {
    static registerMethodDecorator<T>(type: Type<T>): (options?: T) => MethodDecorator;
    static registerClassDecorator<T>(type: Type, metadata: T): ClassDecorator;
    static registerPropertyDecorator<T>(type: Type, metadata: T): PropertyDecorator;
    static getMethodDecorator<T>(type: Type<T>, target: Function): T | undefined;
    static getClassDecorator<TClass, TResult>(type: Type<TResult>, target: Type<TClass>): TResult | undefined;
    static getPropertyDecorators<T>(type: Type<T>, target: Type): Record<string, T>;
}
