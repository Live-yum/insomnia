export declare class Constants {
    static oneSecond(): number;
    static oneMinute(): number;
    static oneHour(): number;
    static oneDay(): number;
    static oneWeek(): number;
    static oneMonth(): number;
}
