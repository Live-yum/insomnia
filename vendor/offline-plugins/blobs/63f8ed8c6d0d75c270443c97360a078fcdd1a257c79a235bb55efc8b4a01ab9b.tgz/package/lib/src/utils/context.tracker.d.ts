export declare class ContextTracker {
    private static readonly asyncHookDict;
    private static readonly contextDict;
    private static hook?;
    static assign(value: Object): void;
    static get(): any;
    static unassign(): void;
    private static ensureIsTracking;
}
