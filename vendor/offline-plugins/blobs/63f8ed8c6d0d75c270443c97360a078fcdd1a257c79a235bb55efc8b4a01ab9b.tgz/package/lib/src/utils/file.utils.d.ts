/// <reference types="node" />
export declare class FileUtils {
    static getDirectories(source: string): any;
    static getFiles(source: string): any;
    static parseJSONFile(source: string): any;
    static writeFile(buffer: Buffer, path: string): Promise<void>;
    static readFile(path: string): Promise<Buffer>;
    static deleteFile(path: string): Promise<void>;
    static getFileSize(path: string): Promise<number>;
    static exists(path: string): Promise<boolean>;
}
