export declare class DateUtils {
    static createUTC(year: number, month?: number, day?: number, hours?: number, minutes?: number, seconds?: number, milliseconds?: number): Date;
    static create(year: number, month?: number, day?: number, hours?: number, minutes?: number, seconds?: number, milliseconds?: number): Date;
}
