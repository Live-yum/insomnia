import { LoggerService } from "@nestjs/common";
export declare class OriginLogger implements LoggerService {
    private readonly context;
    private readonly logger;
    constructor(context: string);
    private getContext;
    log(message: any, ..._optionalParams: any[]): void;
    error(message: any, ..._optionalParams: any[]): void;
    warn(message: any, ..._optionalParams: any[]): void;
}
