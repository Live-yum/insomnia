export declare class CpuProfiler {
    private static readonly asyncHookDict;
    private static readonly profilerDict;
    private static hook?;
    private readonly contextId;
    private readonly logger;
    private readonly performanceProfiler;
    constructor();
    private start;
    stop(description?: string): number;
    static enable(): void;
    static disable(): void;
    private static ensureIsProfiling;
    private static now;
}
