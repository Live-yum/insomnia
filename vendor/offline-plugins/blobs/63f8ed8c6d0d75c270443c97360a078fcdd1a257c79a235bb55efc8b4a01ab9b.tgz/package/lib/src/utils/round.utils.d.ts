export declare class RoundUtils {
    static roundToEpoch(round: number): number;
    static getExpires(epochs: number, roundsPassed: number, roundsPerEpoch: number, roundDuration: number): number;
}
