declare interface String {
    removePrefix(prefix: string): string;
    removeSuffix(suffix: string): string;
    in(...elements: string[]): boolean;
}
