export declare class MatchUtils {
    static getTagsFromBase64Attributes(attributes: string): RegExpMatchArray | null;
    static getMetadataFromBase64Attributes(attributes: string): RegExpMatchArray | null;
}
