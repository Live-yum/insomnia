export declare class StringUtils {
    static isFunctionName(value: string): boolean;
    static isHex(value: string): boolean;
}
