export declare class Locker {
    private static lockArray;
    static lock(key: string, func: () => Promise<void>, log?: boolean): Promise<LockResult>;
}
export declare enum LockResult {
    SUCCESS = "success",
    ALREADY_RUNNING = "alreadyRunning",
    ERROR = "error"
}
