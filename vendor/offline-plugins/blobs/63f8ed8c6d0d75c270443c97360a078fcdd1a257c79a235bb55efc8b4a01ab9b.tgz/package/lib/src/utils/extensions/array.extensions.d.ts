declare interface Array<T> {
    groupBy(predicate: (item: T) => any): any;
    selectMany<TOUT>(predicate: (item: T) => TOUT[]): TOUT[];
    first(predicate?: (item: T) => boolean): T | undefined;
    mapIndexed<TOUT>(items: TOUT[], predicate: (item: TOUT) => T): (TOUT | undefined)[];
    firstOrUndefined(predicate?: (item: T) => boolean): T | undefined;
    last(predicate?: (item: T) => boolean): T;
    lastOrUndefined(predicate?: (item: T) => boolean): T | undefined;
    single(predicate?: (item: T) => boolean): T | undefined;
    singleOrUndefined(predicate?: (item: T) => boolean): T | undefined;
    zip<TSecond, TResult>(second: TSecond[], predicate: (first: T, second: TSecond) => TResult): TResult[];
    except(second: T[]): T[];
    distinct<TResult>(predicate?: (element: T) => TResult): T[];
    sorted(...predicates: ((item: T) => number)[]): T[];
    sortedDescending(...predicates: ((item: T) => number)[]): T[];
    sum(predicate?: (item: T) => number): number;
    sumBigInt(predicate?: (item: T) => bigint): bigint;
    toRecord<TOUT>(keyPredicate: (item: T) => string, valuePredicate?: (item: T) => TOUT): Record<string, TOUT>;
    toRecordAsync<TOUT>(keyPredicate: (item: T) => string, valuePredicate: (item: T) => Promise<TOUT>): Promise<Record<string, TOUT>>;
    remove(element: T): void;
    shuffle(): T[];
}
