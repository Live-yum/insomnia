export declare class TokenUtils {
    static tokenValidateRegex: RegExp;
    static nftValidateRegex: RegExp;
    static isToken(identifier: string): boolean;
    static isCollection(identifier: string): boolean;
    static isNft(identifier: string): boolean;
}
