interface Matchers<R> {
    toHaveStructure(received: any, keys: string[]): R;
    toHaveProperties(received: any, args: any[]): R;
}
