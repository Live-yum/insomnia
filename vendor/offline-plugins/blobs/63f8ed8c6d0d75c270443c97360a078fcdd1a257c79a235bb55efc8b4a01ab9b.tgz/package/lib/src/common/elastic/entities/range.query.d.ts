import { AbstractQuery } from "./abstract.query";
import { QueryRange } from "./query.range";
export declare class RangeQuery extends AbstractQuery {
    private readonly key;
    private readonly ranges;
    constructor(key: string, ranges: QueryRange[]);
    getQuery(): any;
}
