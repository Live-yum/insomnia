/// <reference types="node" />
import Redis from 'ioredis';
import { MetricsService } from '../../../common/metrics/metrics.service';
export declare class RedisCacheService {
    private readonly redis;
    private readonly metricsService;
    private readonly logger;
    constructor(redis: Redis, metricsService: MetricsService);
    get<T>(key: string): Promise<T | undefined>;
    getMany<T>(keys: string[]): Promise<(T | undefined)[]>;
    setnx<T>(key: string, value: T): Promise<boolean>;
    set<T>(key: string, value: T, ttl?: number | null): Promise<void>;
    setMany<T>(keys: string[], values: T[], ttl: number): Promise<void>;
    expire(key: string, ttl: number): Promise<void>;
    pexpire(key: string, ttl: number): Promise<void>;
    delete(key: string): Promise<void>;
    deleteMany(keys: string[]): Promise<void>;
    deleteByPattern(keyPattern: string): void;
    flushDb(): Promise<void>;
    getOrSet<T>(key: string, createValueFunc: () => Promise<T>, ttl: number): Promise<T>;
    setOrUpdate<T>(key: string, createValueFunc: () => Promise<T>, ttl: number): Promise<T>;
    scan(pattern: string): Promise<string[]>;
    increment(key: string, ttl?: number | null): Promise<number>;
    decrement(key: string, ttl?: number | null): Promise<number>;
    hget<T>(hash: string, field: string): Promise<T | null>;
    hgetall<T>(hash: string): Promise<Record<string, T> | null>;
    hset<T>(hash: string, field: string, value: T): Promise<number>;
    zadd(setName: string, value: number, key: string, options?: string[]): Promise<string | number>;
    zincrby(setName: string, increment: number, key: string): Promise<string>;
    zrank(key: string, member: string): Promise<number | null>;
    zrevrank(key: string, member: string): Promise<number | null>;
    zrevrange(setName: string, start: number, stop: number, withScores?: boolean): Promise<string[]>;
    zrange(setName: string, start: number, stop: number, options?: {
        order?: 'REV' | undefined;
        withScores?: boolean;
    }): Promise<string[]>;
    zmscore(setName: string, ...args: string[]): Promise<(string | null)[]>;
    zcount(key: string, min: number | '-inf', max: number | '+inf'): Promise<number>;
    defineCommand(name: string, definition: {
        lua: string;
        numberOfKeys?: number;
        readOnly?: boolean;
    }): void;
    executeCommand(name: string, ...args: (string | Buffer | number)[]): Promise<unknown>;
    rpush(key: string, items: any): Promise<void>;
    lpop<T>(key: string): Promise<T[]>;
    private buildInternalCreateValueFunc;
}
