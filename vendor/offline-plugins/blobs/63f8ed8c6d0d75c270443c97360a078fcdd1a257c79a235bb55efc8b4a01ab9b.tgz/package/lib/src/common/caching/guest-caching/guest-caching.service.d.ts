import { CachingService } from '../caching.service';
import { IGuestCacheOptions } from '../entities/guest.caching';
export declare class GuestCachingService {
    private cacheService;
    constructor(cacheService: CachingService);
    getOrSetRequestCache(req: any, options?: IGuestCacheOptions): Promise<{
        fromCache: boolean;
        response?: undefined;
    } | {
        fromCache: boolean;
        response: any;
    }>;
}
