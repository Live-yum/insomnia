export declare class Amount extends String {
}
