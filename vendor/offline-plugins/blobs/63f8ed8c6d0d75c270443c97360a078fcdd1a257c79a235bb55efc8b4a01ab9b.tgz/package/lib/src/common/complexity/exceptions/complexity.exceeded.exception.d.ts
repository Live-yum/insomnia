import { BadRequestException } from "@nestjs/common";
export declare class ComplexityExceededException extends BadRequestException {
    constructor(complexity: number, threshold: number);
}
