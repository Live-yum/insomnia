import { AmqpConnection } from '@golevelup/nestjs-rabbitmq';
export declare class RabbitPublisherService {
    private readonly amqpConnection;
    private readonly logger;
    constructor(amqpConnection: AmqpConnection);
    publish(exchange: string, input: unknown): Promise<void>;
}
