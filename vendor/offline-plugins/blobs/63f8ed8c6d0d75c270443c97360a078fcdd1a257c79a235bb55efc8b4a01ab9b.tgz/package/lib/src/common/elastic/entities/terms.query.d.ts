import { AbstractQuery } from "./abstract.query";
export declare class TermsQuery extends AbstractQuery {
    private readonly key;
    private readonly value;
    constructor(key: string, value: string[]);
    getQuery(): any;
}
