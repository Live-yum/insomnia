import { CachingService } from '../caching.service';
import { IGuestCacheWarmerOptions } from '../entities/guest.caching';
export declare class GuestCachingWarmer {
    private readonly cachingService;
    constructor(cachingService: CachingService);
    private getReq;
    private postReq;
    recompute(options: IGuestCacheWarmerOptions): Promise<void>;
}
