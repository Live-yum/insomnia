export declare class ElasticPagination {
    from: number;
    size: number;
}
