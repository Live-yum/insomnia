import { AbstractQuery } from "./abstract.query";
export declare class MustQuery extends AbstractQuery {
    private readonly queries;
    private readonly mustNotQueries;
    constructor(queries: AbstractQuery[], mustNotQueries?: AbstractQuery[]);
    getQuery(): any;
}
