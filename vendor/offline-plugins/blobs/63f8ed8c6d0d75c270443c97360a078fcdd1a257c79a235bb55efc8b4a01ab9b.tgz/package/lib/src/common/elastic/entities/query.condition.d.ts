import { AbstractQuery } from "./abstract.query";
export declare class QueryCondition {
    must: AbstractQuery[];
    should: AbstractQuery[];
    must_not: AbstractQuery[];
}
