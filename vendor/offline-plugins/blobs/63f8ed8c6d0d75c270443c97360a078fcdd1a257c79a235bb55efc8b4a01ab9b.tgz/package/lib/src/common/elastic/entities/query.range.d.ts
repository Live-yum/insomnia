export declare abstract class QueryRange {
    readonly key: string;
    readonly value: number;
    constructor(key: string, value: number);
}
