export declare class LocalCacheService {
    private static readonly dictionary;
    private static lastPruneTime;
    setCacheValue<T>(key: string, value: T, ttl: number): T;
    getCacheValue<T>(key: string): T | undefined;
    deleteCacheKey(key: string): void;
    needsPrune(): boolean;
    prune(): void;
}
