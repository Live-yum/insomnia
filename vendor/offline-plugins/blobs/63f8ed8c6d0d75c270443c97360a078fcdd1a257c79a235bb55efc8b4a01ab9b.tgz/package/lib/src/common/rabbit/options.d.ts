import { ConnectionInitOptions, RabbitMQExchangeConfig } from '@golevelup/nestjs-rabbitmq';
export declare class RabbitModuleOptions {
    uri: string;
    connectionInitOptions?: ConnectionInitOptions | undefined;
    exchanges?: RabbitMQExchangeConfig[] | undefined;
    constructor(uri: string, exchanges?: string[] | undefined, connectionInitOptions?: ConnectionInitOptions | undefined);
    private getExchanges;
}
