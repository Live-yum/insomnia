import { Cache } from 'cache-manager';
export declare class InMemoryCacheService {
    private readonly cache;
    constructor(cache: Cache);
    get<T>(key: string): Promise<T | undefined>;
    getMany<T>(keys: string[]): Promise<(T | undefined)[]>;
    set<T>(key: string, value: T, ttl: number): Promise<void>;
    setMany<T>(keys: string[], values: T[], ttl: number): Promise<void>;
    delete(key: string): Promise<void>;
    getOrSet<T>(key: string, createValueFunc: () => Promise<T>, ttl: number): Promise<T>;
    setOrUpdate<T>(key: string, createValueFunc: () => Promise<T>, ttl: number): Promise<T>;
    private buildInternalCreateValueFunc;
}
