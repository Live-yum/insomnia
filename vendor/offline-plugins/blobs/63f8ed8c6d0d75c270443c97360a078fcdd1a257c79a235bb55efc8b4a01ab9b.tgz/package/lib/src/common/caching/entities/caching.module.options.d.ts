export declare class CachingModuleOptions {
    constructor(init?: Partial<CachingModuleOptions>);
    url: string;
    port: number;
    password: string | undefined;
    poolLimit: number;
    processTtl: number;
}
