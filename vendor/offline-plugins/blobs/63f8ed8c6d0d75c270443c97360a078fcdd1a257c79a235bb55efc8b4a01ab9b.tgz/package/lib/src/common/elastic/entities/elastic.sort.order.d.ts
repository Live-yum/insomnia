export declare enum ElasticSortOrder {
    descending = "desc",
    ascending = "asc"
}
