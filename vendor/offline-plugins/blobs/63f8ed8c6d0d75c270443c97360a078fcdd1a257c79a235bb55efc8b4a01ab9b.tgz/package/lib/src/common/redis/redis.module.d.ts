import { DynamicModule } from '@nestjs/common';
import { RedisModuleAsyncOptions, RedisModuleOptions } from './options';
export declare class RedisModule {
    static forRoot(connectionOptions: RedisModuleOptions): DynamicModule;
    static forRootAsync(connectOptions: RedisModuleAsyncOptions): DynamicModule;
    private static createConenctOptionsProviders;
    private static createConnectOptionsProvider;
}
