import { DynamicModule } from "@nestjs/common";
import { ApiModuleAsyncOptions } from "./entities/api.module.async.options";
import { ApiModuleOptions } from "./entities/api.module.options";
export declare class ApiModule {
    static forRoot(options: ApiModuleOptions): DynamicModule;
    static forRootAsync(options: ApiModuleAsyncOptions): DynamicModule;
}
