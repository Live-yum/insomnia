import { DynamicModule } from "@nestjs/common";
import { CachingModuleAsyncOptions } from "./entities/caching.module.async.options";
import { CachingModuleOptions } from "./entities/caching.module.options";
export declare class CachingModule {
    static forRoot(options: CachingModuleOptions): DynamicModule;
    static forRootAsync(options: CachingModuleAsyncOptions): DynamicModule;
}
