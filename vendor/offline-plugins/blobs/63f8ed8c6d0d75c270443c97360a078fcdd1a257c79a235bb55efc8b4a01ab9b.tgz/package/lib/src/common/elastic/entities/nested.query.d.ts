import { AbstractQuery } from "./abstract.query";
export declare class NestedQuery extends AbstractQuery {
    private readonly key;
    private readonly value;
    constructor(key: string, value: any);
    getQuery(): any;
}
