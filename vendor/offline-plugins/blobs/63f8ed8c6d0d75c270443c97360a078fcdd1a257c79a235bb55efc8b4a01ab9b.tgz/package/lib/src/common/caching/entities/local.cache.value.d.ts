export declare class LocalCacheValue {
    value: any;
    expires: number;
}
