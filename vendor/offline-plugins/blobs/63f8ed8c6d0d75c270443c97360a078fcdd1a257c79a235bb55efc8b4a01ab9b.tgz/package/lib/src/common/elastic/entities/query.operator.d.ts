export declare enum QueryOperator {
    AND = "AND",
    OR = "OR"
}
