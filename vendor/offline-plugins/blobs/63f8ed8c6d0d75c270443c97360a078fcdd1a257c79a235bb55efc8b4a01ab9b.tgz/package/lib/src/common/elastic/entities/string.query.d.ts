import { AbstractQuery } from "./abstract.query";
export declare class StringQuery extends AbstractQuery {
    private readonly key;
    private readonly value;
    constructor(key: string | string[], value: number | undefined);
    getQuery(): any;
}
