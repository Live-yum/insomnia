import { AbstractQuery } from "./abstract.query";
import { ElasticPagination } from "./elastic.pagination";
import { ElasticSortProperty } from "./elastic.sort.property";
import { MatchQuery } from "./match.query";
import { QueryCondition } from "./query.condition";
import { QueryConditionOptions } from "./query.condition.options";
import { QueryOperator } from "./query.operator";
import { QueryRange } from "./query.range";
import { RangeQuery } from "./range.query";
import { TermsQuery } from "./terms.query";
export declare class ElasticQuery {
    fields?: string[];
    pagination?: ElasticPagination;
    sort: ElasticSortProperty[];
    filter: AbstractQuery[];
    condition: QueryCondition;
    terms?: TermsQuery;
    extra?: Record<string, any>;
    static create(): ElasticQuery;
    withFields(fields: string[]): ElasticQuery;
    withPagination(pagination: ElasticPagination): ElasticQuery;
    withSort(sort: ElasticSortProperty[]): ElasticQuery;
    withMustMatchCondition(key: string, value: any | undefined, operator?: QueryOperator | undefined): ElasticQuery;
    withMustWildcardCondition(key: string, value: string | undefined): ElasticQuery;
    withMustMultiShouldCondition<T>(values: T[] | undefined, action: (value: T) => MatchQuery): ElasticQuery;
    withMustExistCondition(key: string): ElasticQuery;
    withMustNotExistCondition(key: string): ElasticQuery;
    withMustCondition(queries: AbstractQuery[] | AbstractQuery): ElasticQuery;
    withMustNotCondition(queries: AbstractQuery[] | AbstractQuery): ElasticQuery;
    withShouldCondition(queries: AbstractQuery[] | AbstractQuery): ElasticQuery;
    withSearchWildcardCondition(search: string | undefined, keys: string[]): ElasticQuery;
    withSearchCondition(search: string | undefined, func: (term: string) => AbstractQuery[]): ElasticQuery;
    withCondition(queryCondition: QueryConditionOptions, queries: AbstractQuery[] | AbstractQuery): ElasticQuery;
    withTerms(termsQuery: TermsQuery): ElasticQuery;
    withRangeFilter(key: string, ...ranges: QueryRange[]): ElasticQuery;
    withDateRangeFilter(key: string, before: number | undefined, after: number | undefined): ElasticQuery;
    withFilter(filter: RangeQuery): ElasticQuery;
    withExtra(extra: Record<string, any>): ElasticQuery;
    toJson(): {
        sort: any[];
        query: {
            bool: {
                filter: any[];
                must: any[];
                should: any[];
                must_not: any[];
                minimum_should_match: number | undefined;
            };
            terms: any;
        };
        from?: number | undefined;
        size?: number | undefined;
        _source: string[] | undefined;
    };
}
