import { ComplexityNode } from "./complexity.node";
export declare class ComplexityTree {
    root: ComplexityNode;
    constructor();
    addChildNode(identifier: string, complexity: number, parent: string, group?: string): void;
    updateNodeComplexityWithSize(identifier: string, size: number): void;
    getComplexity(): number;
}
