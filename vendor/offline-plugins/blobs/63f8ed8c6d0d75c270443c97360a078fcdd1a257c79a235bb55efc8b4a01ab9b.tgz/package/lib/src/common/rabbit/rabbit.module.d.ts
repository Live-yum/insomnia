import { DynamicModule } from '@nestjs/common';
import { RabbitModuleAsyncOptions } from './async-options';
import { RabbitModuleOptions } from './options';
export declare class RabbitModule {
    static forRoot(options: RabbitModuleOptions): DynamicModule;
    static forRootAsync(asyncOptions: RabbitModuleAsyncOptions): DynamicModule;
}
