import { ComplexityTree } from "./complexity.tree";
export declare class ComplexityUtils {
    static updateComplexityTree(previousComplexity: any, target: any, fields: string[], size: number): ComplexityTree;
    static getComplexityConfiguration(target: any): {
        [field: string]: number | any;
    };
}
