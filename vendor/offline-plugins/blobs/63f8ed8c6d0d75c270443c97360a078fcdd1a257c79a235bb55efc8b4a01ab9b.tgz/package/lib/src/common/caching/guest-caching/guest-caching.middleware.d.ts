import { NestMiddleware, Type } from '@nestjs/common';
import { IGuestCacheOptions } from '../entities/guest.caching';
export declare const GuestCachingMiddlewareCreator: (options?: IGuestCacheOptions) => Type<NestMiddleware>;
