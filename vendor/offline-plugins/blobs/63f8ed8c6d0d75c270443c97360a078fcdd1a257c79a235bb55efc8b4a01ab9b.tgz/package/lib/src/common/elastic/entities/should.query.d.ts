import { AbstractQuery } from "./abstract.query";
export declare class ShouldQuery extends AbstractQuery {
    private readonly queries;
    constructor(queries: AbstractQuery[]);
    getQuery(): any;
}
