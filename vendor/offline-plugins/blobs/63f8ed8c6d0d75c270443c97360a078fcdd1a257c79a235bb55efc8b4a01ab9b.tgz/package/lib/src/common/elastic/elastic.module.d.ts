import { DynamicModule } from "@nestjs/common";
import { ElasticModuleOptions } from "./entities/elastic.module.options";
import { ElasticModuleAsyncOptions } from "./entities/elastic.module.async.options";
export declare class ElasticModule {
    static forRoot(options: ElasticModuleOptions): DynamicModule;
    static forRootAsync(options: ElasticModuleAsyncOptions): DynamicModule;
}
