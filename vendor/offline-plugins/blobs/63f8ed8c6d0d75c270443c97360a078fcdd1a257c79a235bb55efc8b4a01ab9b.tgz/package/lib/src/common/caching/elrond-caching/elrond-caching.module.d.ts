import { DynamicModule } from '@nestjs/common';
import { RedisCacheModuleAsyncOptions, RedisCacheModuleOptions } from '../redis-cache/options';
export declare class ElrondCachingModule {
    static forRoot(redisCacheModuleOptions: RedisCacheModuleOptions): DynamicModule;
    static forRootAsync(redisCacheModuleAsyncOptions: RedisCacheModuleAsyncOptions): DynamicModule;
}
