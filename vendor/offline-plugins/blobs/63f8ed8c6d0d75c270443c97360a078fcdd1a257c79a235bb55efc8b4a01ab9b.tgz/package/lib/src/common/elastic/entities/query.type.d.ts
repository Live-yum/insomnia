import { AbstractQuery } from "./abstract.query";
import { ExistsQuery } from "./exists.query";
import { MatchQuery } from "./match.query";
import { MustQuery } from "./must.query";
import { NestedQuery } from "./nested.query";
import { QueryOperator } from "./query.operator";
import { QueryRange } from "./query.range";
import { RangeQuery } from "./range.query";
import { ShouldQuery } from "./should.query";
import { WildcardQuery } from "./wildcard.query";
import { StringQuery } from "./string.query";
export declare class QueryType {
    static Match: (key: string, value: any | undefined, operator?: QueryOperator | undefined) => MatchQuery;
    static Exists: (key: string) => ExistsQuery;
    static Range: (key: string, ...ranges: QueryRange[]) => RangeQuery;
    static Wildcard: (key: string, value: string) => WildcardQuery;
    static Nested: (key: string, value: any | undefined) => NestedQuery;
    static Should: (queries: AbstractQuery[]) => ShouldQuery;
    static Must: (queries: AbstractQuery[], mustNotQueries?: AbstractQuery[]) => MustQuery;
    static String: (key: string | string[], value: any | undefined) => StringQuery;
}
