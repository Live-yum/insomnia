export declare class ApplyComplexityOptions {
    constructor(init?: Partial<ApplyComplexityOptions>);
    target: any;
}
export declare const ApplyComplexity: (options?: ApplyComplexityOptions | undefined) => MethodDecorator;
