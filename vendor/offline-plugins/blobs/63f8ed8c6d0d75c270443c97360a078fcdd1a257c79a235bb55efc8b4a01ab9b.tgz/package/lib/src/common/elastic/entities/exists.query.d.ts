import { AbstractQuery } from "./abstract.query";
export declare class ExistsQuery extends AbstractQuery {
    private readonly key;
    constructor(key: string);
    getQuery(): any;
}
