import { ElasticSortOrder } from "./elastic.sort.order";
export declare class ElasticSortProperty {
    name: string;
    order: ElasticSortOrder | undefined;
}
