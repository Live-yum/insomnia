import { RabbitConsumerConfig } from './consumer-config';
export declare const CompetingRabbitConsumer: (config: RabbitConsumerConfig) => <TFunction extends Function, Y>(target: object | TFunction, propertyKey?: string | symbol | undefined, descriptor?: TypedPropertyDescriptor<Y> | undefined) => void;
export declare const PublicRabbitConsumer: (config: RabbitConsumerConfig) => <TFunction extends Function, Y>(target: object | TFunction, propertyKey?: string | symbol | undefined, descriptor?: TypedPropertyDescriptor<Y> | undefined) => void;
