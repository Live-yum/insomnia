import { LocalCacheService } from "./local.cache.service";
import { MetricsService } from "../metrics/metrics.service";
import { CachingModuleOptions } from "./entities/caching.module.options";
export declare class CachingService {
    private readonly options;
    private readonly localCacheService;
    private readonly metricsService;
    protected client: import("redis").RedisClient;
    private asyncSet;
    private asyncGet;
    private asyncIncr;
    private asyncExpire;
    private asyncFlushDb;
    private asyncMGet;
    private asyncZIncrBy;
    private asyncZRange;
    private asyncSAdd;
    private asyncSCard;
    private asyncMulti;
    private asyncDel;
    private asyncKeys;
    private readonly logger;
    constructor(options: CachingModuleOptions, localCacheService: LocalCacheService, metricsService: MetricsService);
    getKeys(key: string | undefined): Promise<any>;
    incrementRemote(key: string): Promise<number>;
    setTtlRemote(key: string, ttl: number): Promise<void>;
    setCacheRemote<T>(key: string, value: T, ttl?: number): Promise<T>;
    pendingPromises: {
        [key: string]: Promise<any>;
    };
    private executeWithPendingPromise;
    getCacheRemote<T>(key: string): Promise<T | undefined>;
    setCacheLocal<T>(key: string, value: T, ttl?: number): Promise<T>;
    getCacheLocal<T>(key: string): Promise<T | undefined>;
    refreshCacheLocal<T>(key: string, ttl?: number): Promise<T | undefined>;
    getCache<T>(key: string): Promise<T | undefined>;
    setCache<T>(key: string, value: T, ttl?: number): Promise<T>;
    zIncrBy<T>(key: string, increment: number, member: string): Promise<T | undefined>;
    zRange<T>(key: string, from: number, to: number | string, type: string): Promise<T>;
    batchProcess<IN, OUT>(payload: IN[], cacheKeyFunction: (element: IN) => string, handler: (generator: IN) => Promise<OUT>, ttl?: number, skipCache?: boolean): Promise<OUT[]>;
    batchProcessChunk<IN, OUT>(payload: IN[], cacheKeyFunction: (element: IN) => string, handler: (generator: IN) => Promise<OUT>, ttl?: number, skipCache?: boolean): Promise<OUT[]>;
    private spreadTtl;
    batchSetCache(keys: string[], values: any[], ttls: number[], setLocalCache?: boolean, spreadTtl?: boolean): Promise<void>;
    batchDelCache(keys: string[]): Promise<void>;
    setAdd(key: string, ...values: string[]): Promise<void>;
    setCount(key: string): Promise<number>;
    batchGetCacheRemote<T>(keys: string[]): Promise<T[]>;
    batchApplyAll<TIN, TOUT>(elements: TIN[], cacheKeyFunc: (element: TIN) => string, getter: (element: TIN) => Promise<TOUT>, setter: (element: TIN, value: TOUT) => void, ttl: number, chunkSize?: number): Promise<void>;
    batchApply<TIN, TOUT>(elements: TIN[], cacheKeyFunc: (element: TIN) => string, getter: (elements: TIN[]) => Promise<{
        [key: string]: TOUT;
    }>, setter: (element: TIN, value: TOUT) => void, ttl: number, chunkSize?: number): Promise<void>;
    batchGetAll<TIN, TOUT>(elements: TIN[], cacheKeyFunc: (element: TIN) => string, getter: (element: TIN) => Promise<TOUT>, ttl: number, chunkSize?: number): Promise<{
        [key: string]: TOUT;
    }>;
    batchGet<TIN, TOUT>(elements: TIN[], cacheKeyFunc: (element: TIN) => string, getter: (elements: TIN[]) => Promise<{
        [key: string]: TOUT;
    }>, ttl: number, chunkSize?: number): Promise<{
        [key: string]: TOUT;
    }>;
    getOrSetCache<T>(key: string, promise: () => Promise<T>, remoteTtl?: number, localTtl?: number | undefined, forceRefresh?: boolean): Promise<T>;
    deleteInCacheLocal(key: string): Promise<void>;
    deleteInCache(key: string): Promise<string[]>;
    flushDb(): Promise<any>;
    private getCacheTtl;
}
