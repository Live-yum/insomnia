import { ApiService } from "../api/api.service";
import { MetricsService } from "../../common/metrics/metrics.service";
import { ElasticQuery } from "./entities/elastic.query";
import { ElasticModuleOptions } from "./entities/elastic.module.options";
export declare class ElasticService {
    private readonly options;
    private readonly apiService;
    private readonly metricsService;
    constructor(options: ElasticModuleOptions, apiService: ApiService, metricsService: MetricsService);
    getCount(collection: string, elasticQuery?: ElasticQuery | undefined): Promise<any>;
    getItem(collection: string, key: string, identifier: string): Promise<any>;
    private formatItem;
    getList(collection: string, key: string, elasticQuery: ElasticQuery, overrideUrl?: string): Promise<any[]>;
    getScrollableList(collection: string, key: string, elasticQuery: ElasticQuery, action: (items: any[]) => Promise<void>): Promise<void>;
    getCustomValue(collection: string, identifier: string, attribute: string): Promise<any>;
    setCustomValue<T>(collection: string, identifier: string, attribute: string, value: T): Promise<void>;
    get(url: string): Promise<any>;
    post(url: string, body: any): Promise<any>;
    delete(url: string, body: any): Promise<any>;
}
