export declare class InMemoryCacheModule {
}
