import { AbstractQuery } from "./abstract.query";
import { QueryOperator } from "./query.operator";
export declare class MatchQuery extends AbstractQuery {
    private readonly key;
    private readonly value;
    private readonly operator;
    constructor(key: string, value: any, operator?: QueryOperator | undefined);
    getQuery(): any;
}
