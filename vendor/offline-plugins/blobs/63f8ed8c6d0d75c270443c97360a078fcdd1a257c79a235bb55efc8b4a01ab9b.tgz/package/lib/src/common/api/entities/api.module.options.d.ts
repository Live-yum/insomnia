export declare class ApiModuleOptions {
    constructor(init?: Partial<ApiModuleOptions>);
    useKeepAliveAgent: boolean;
    axiosTimeout: number;
    serverTimeout: number;
    rateLimiterSecret?: string;
}
