import { ExecutionContext } from '@nestjs/common';
export declare class RabbitContextCheckerService {
    check(context: ExecutionContext): boolean;
}
