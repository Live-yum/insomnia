export declare abstract class AbstractQuery {
    abstract getQuery(): any;
}
