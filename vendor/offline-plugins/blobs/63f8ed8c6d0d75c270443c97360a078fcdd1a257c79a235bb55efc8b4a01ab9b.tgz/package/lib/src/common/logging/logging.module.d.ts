export declare class LoggingModule {
}
