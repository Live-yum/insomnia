export declare class ElasticModuleOptions {
    constructor(init?: Partial<ElasticModuleOptions>);
    url: string;
    customValuePrefix?: string;
}
