export declare enum GuestCacheMethodEnum {
    GET = "GET",
    POST = "POST"
}
export interface IGuestCacheEntity {
    method: GuestCacheMethodEnum;
    body?: any;
    path: string;
}
export interface IGuestCacheWarmerOptions {
    cacheTtl?: number;
    targetUrl: string;
    cacheTriggerHitsThreshold?: number;
}
export interface IGuestCacheOptions {
    batchSize?: number;
    ignoreAuthorizationHeader?: boolean;
}
export declare const DATE_FORMAT = "YYYY-MM-DD_HH:mm";
export declare const REDIS_PREFIX = "guestCache";
