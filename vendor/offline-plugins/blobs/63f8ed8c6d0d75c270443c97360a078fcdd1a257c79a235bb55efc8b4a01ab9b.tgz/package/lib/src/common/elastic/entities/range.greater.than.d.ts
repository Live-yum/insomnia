import { QueryRange } from "./query.range";
export declare class RangeGreaterThan extends QueryRange {
    constructor(value: number);
}
