import { QueryRange } from "./query.range";
export declare class RangeLowerThan extends QueryRange {
    constructor(value: number);
}
