export declare class ParentNodeNotFoundException extends Error {
    constructor(identifier: string);
}
