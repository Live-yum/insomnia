export declare const jitter: (ttlSeconds: number, slidingPercentage?: number) => number;
