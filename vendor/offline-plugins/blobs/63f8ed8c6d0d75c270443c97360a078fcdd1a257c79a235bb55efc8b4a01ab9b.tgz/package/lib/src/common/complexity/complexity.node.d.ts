export declare class ComplexityNode {
    identifier: string;
    complexity: number;
    group: string | undefined;
    children: {
        [identifier: string]: ComplexityNode;
    };
    constructor(identifier: string, complexity: number, group: string);
    addChild(identifier: string, complexity: number, group: string): void;
}
