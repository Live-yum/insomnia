import { MetricsService } from "../../common/metrics/metrics.service";
import { ApiSettings } from "./entities/api.settings";
import { ApiModuleOptions } from "./entities/api.module.options";
export declare class ApiService {
    private readonly options;
    private readonly metricsService;
    private readonly defaultTimeout;
    private keepaliveAgent;
    constructor(options: ApiModuleOptions, metricsService: MetricsService);
    private getKeepAliveAgent;
    private getConfig;
    private requestsExecuter;
    get(url: string, settings?: ApiSettings, errorHandler?: (error: any) => Promise<boolean>): Promise<any>;
    put(url: string, data: any, settings?: ApiSettings, errorHandler?: (error: any) => Promise<boolean>): Promise<any>;
    post(url: string, data: any, settings?: ApiSettings, errorHandler?: (error: any) => Promise<boolean>): Promise<any>;
    delete(url: string, data: any, settings?: ApiSettings, errorHandler?: (error: any) => Promise<boolean>): Promise<any>;
    head(url: string, settings?: ApiSettings, errorHandler?: (error: any) => Promise<boolean>): Promise<any>;
    private getHostname;
    private getCustomError;
}
