import { ModuleMetadata } from '@nestjs/common';
export declare class RedisCacheModuleOptions {
    config: {
        host?: string | undefined;
        port?: number | undefined;
        username?: string | undefined;
        password?: string | undefined;
        sentinelUsername?: string | undefined;
        sentinelPassword?: string | undefined;
        sentinels?: Array<{
            host: string;
            port: number;
        }> | undefined;
        connectTimeout?: number | undefined;
        name?: string | undefined;
    };
    constructor(options: RedisCacheModuleOptions['config']);
}
export interface RedisCacheModuleAsyncOptions extends Pick<ModuleMetadata, 'imports'> {
    useFactory: (...args: any[]) => Promise<RedisCacheModuleOptions> | RedisCacheModuleOptions;
    inject?: any[];
}
