import { DynamicModule } from '@nestjs/common';
import { RedisCacheModuleOptions, RedisCacheModuleAsyncOptions } from './options';
export declare class RedisCacheModule {
    static forRoot(options: RedisCacheModuleOptions): DynamicModule;
    static forRootAsync(asyncOptions: RedisCacheModuleAsyncOptions): DynamicModule;
}
