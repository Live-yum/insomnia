import { QueryRange } from "./query.range";
export declare class RangeLowerThanOrEqual extends QueryRange {
    constructor(value: number);
}
