import { QueryRange } from "./query.range";
export declare class RangeGreaterThanOrEqual extends QueryRange {
    constructor(value: number);
}
