import "reflect-metadata";
export declare class ComplexityEstimationOptions {
    group?: string;
    value?: number;
    alternatives?: string[];
}
export declare function ComplexityEstimation(options?: ComplexityEstimationOptions): PropertyDecorator;
