import { ArgumentMetadata, PipeTransform } from "@nestjs/common";
export declare class ParseEnumArrayPipe<T extends {
    [name: string]: any;
}> implements PipeTransform<string | undefined, Promise<string[] | undefined>> {
    private readonly type;
    constructor(type: T);
    transform(value: string | undefined, metadata: ArgumentMetadata): Promise<string[] | undefined>;
    private getValues;
}
