import { ArgumentMetadata, PipeTransform } from "@nestjs/common";
export declare class ParseArrayPipe implements PipeTransform<string | undefined, Promise<string[] | undefined>> {
    private readonly maxArraySize;
    constructor(maxArraySize?: number);
    transform(value: string | undefined, metadata: ArgumentMetadata): Promise<string[] | undefined>;
}
