import { ParseHashPipe } from "./parse.hash.pipe";
export declare class ParseBlockHashPipe extends ParseHashPipe {
    constructor();
}
