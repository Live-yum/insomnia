import { ArgumentMetadata, PipeTransform } from "@nestjs/common";
export declare class ParseBoolPipe implements PipeTransform<string | boolean, Promise<boolean | undefined>> {
    transform(value: string | boolean, metadata: ArgumentMetadata): Promise<boolean | undefined>;
}
