import { ArgumentMetadata, PipeTransform } from "@nestjs/common";
export declare class ParseIntPipe implements PipeTransform<string | undefined, Promise<number | undefined>> {
    transform(value: string | undefined, metadata: ArgumentMetadata): Promise<number | undefined>;
}
