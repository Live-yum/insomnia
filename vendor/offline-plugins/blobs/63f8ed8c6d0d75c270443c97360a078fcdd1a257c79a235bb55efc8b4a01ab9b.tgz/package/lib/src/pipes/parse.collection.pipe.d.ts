import { ParseRegexPipe } from "./parse.regex.pipe";
export declare class ParseCollectionPipe extends ParseRegexPipe {
    constructor();
}
