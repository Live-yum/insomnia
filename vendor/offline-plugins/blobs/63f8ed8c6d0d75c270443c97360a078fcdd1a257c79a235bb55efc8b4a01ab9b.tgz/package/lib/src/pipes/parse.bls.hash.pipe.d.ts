import { ParseHashPipe } from "./parse.hash.pipe";
export declare class ParseBlsHashPipe extends ParseHashPipe {
    constructor();
}
