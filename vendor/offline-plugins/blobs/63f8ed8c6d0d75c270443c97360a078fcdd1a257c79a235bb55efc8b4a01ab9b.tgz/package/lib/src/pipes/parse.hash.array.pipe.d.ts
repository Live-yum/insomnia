import { ArgumentMetadata, PipeTransform } from "@nestjs/common";
export declare class ParseHashArrayPipe implements PipeTransform<string | string[] | undefined, Promise<string | string[] | undefined>> {
    private entity;
    private length;
    constructor(entity: string, length: number);
    transform(value: string | string[] | undefined, metadata: ArgumentMetadata): Promise<string | string[] | undefined>;
}
