import { ParseRegexPipe } from "./parse.regex.pipe";
export declare class ParseTokenOrNftPipe extends ParseRegexPipe {
    constructor();
}
