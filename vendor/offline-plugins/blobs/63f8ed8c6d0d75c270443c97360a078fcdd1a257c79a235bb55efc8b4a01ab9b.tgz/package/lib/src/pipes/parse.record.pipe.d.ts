import { ArgumentMetadata, PipeTransform } from "@nestjs/common";
export declare class ParseRecordPipe implements PipeTransform<string | undefined, Promise<Record<string, string> | undefined>> {
    transform(value: string | undefined, metadata: ArgumentMetadata): Promise<Record<string, string> | undefined>;
}
