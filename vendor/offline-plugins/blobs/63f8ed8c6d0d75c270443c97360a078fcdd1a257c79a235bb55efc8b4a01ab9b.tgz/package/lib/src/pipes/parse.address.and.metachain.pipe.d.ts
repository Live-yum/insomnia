import { ArgumentMetadata, PipeTransform } from "@nestjs/common";
export declare class ParseAddressAndMetachainPipe implements PipeTransform<string | undefined, Promise<string | undefined>> {
    transform(value: string | undefined, metadata: ArgumentMetadata): Promise<string | undefined>;
}
