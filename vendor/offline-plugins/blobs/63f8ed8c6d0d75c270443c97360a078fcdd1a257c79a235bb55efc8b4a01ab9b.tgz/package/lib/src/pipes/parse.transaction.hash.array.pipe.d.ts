import { ParseHashArrayPipe } from "./parse.hash.array.pipe";
export declare class ParseTranasctionHashArrayPipe extends ParseHashArrayPipe {
    constructor();
}
