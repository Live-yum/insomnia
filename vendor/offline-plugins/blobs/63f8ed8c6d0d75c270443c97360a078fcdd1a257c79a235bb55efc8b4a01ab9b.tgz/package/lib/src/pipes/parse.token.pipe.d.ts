import { ParseRegexPipe } from "./parse.regex.pipe";
export declare class ParseTokenPipe extends ParseRegexPipe {
    constructor();
}
