import { ArgumentMetadata, PipeTransform } from "@nestjs/common";
export declare class ParseRegexPipe implements PipeTransform<string | undefined, Promise<string | undefined>> {
    private readonly message;
    private readonly regexes;
    constructor(regex: RegExp | RegExp[], message?: string);
    transform(value: string | undefined, metadata: ArgumentMetadata): Promise<string | undefined>;
}
