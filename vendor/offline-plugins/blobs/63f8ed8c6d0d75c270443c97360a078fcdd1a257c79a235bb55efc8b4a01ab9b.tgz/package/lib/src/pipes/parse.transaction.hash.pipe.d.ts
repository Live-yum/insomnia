import { ParseHashPipe } from "./parse.hash.pipe";
export declare class ParseTransactionHashPipe extends ParseHashPipe {
    constructor();
}
