import { ParseRegexPipe } from "./parse.regex.pipe";
export declare class ParseNftPipe extends ParseRegexPipe {
    constructor();
}
