import { Interaction, SmartContract, TypedOutcomeBundle } from "@elrondnetwork/erdjs/out";
import { INetworkProvider } from "@elrondnetwork/erdjs-network-providers/out/interface";
export declare class ContractQueryRunner {
    private readonly logger;
    private readonly proxy;
    private readonly parser;
    constructor(proxy: INetworkProvider);
    runQuery(contract: SmartContract, interaction: Interaction): Promise<TypedOutcomeBundle>;
}
