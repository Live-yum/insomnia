import { INetworkProvider } from "@elrondnetwork/erdjs-network-providers/out/interface";
import { IAddress, Interaction, Transaction } from "@elrondnetwork/erdjs/out";
export declare class ContractTransactionGenerator {
    private readonly logger;
    private readonly proxy;
    private networkConfig;
    constructor(proxy: INetworkProvider);
    private loadNetworkConfig;
    private getNetworkConfig;
    createTransaction(interaction: Interaction, signerAddress: IAddress): Promise<Transaction>;
}
