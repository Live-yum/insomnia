import { SmartContract } from "@elrondnetwork/erdjs/out";
export declare class ContractLoader {
    private readonly logger;
    private readonly abiPath;
    private readonly contractInterface;
    private abi;
    constructor(abiPath: string, contractInterface: string);
    private load;
    getContract(contractAddress: string): Promise<SmartContract>;
}
