export declare class NoAuthOptions {
}
export declare const NoAuth: (options?: NoAuthOptions | undefined) => MethodDecorator;
