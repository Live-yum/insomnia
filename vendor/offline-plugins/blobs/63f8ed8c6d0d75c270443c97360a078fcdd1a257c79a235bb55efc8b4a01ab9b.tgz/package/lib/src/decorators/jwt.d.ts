export declare const Jwt: (...dataOrPipes: any[]) => ParameterDecorator;
