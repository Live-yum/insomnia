export interface LockOptions {
    name?: string;
    verbose?: boolean;
}
export declare function Lock(options?: LockOptions): (_target: Object, _key: string | symbol, descriptor: PropertyDescriptor) => PropertyDescriptor;
