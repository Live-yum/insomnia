export declare class NoCacheOptions {
}
export declare const NoCache: (options?: NoCacheOptions | undefined) => MethodDecorator;
