export declare const NativeAuth: (...dataOrPipes: any[]) => ParameterDecorator;
