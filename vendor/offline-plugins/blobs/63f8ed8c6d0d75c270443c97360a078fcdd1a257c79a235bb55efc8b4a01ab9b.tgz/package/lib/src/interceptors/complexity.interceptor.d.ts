import { CallHandler, ExecutionContext, NestInterceptor } from "@nestjs/common";
import { Observable } from "rxjs";
export declare class ComplexityInterceptor implements NestInterceptor {
    private readonly complexityThreshold;
    constructor(complexityThreshold?: number);
    intercept(context: ExecutionContext, next: CallHandler): Observable<any>;
    private handleHttpRequest;
}
