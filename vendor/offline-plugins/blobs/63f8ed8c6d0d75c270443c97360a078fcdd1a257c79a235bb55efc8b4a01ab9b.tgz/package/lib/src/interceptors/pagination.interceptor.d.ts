import { CallHandler, ExecutionContext, NestInterceptor } from "@nestjs/common";
import { Observable } from "rxjs";
export declare class PaginationInterceptor implements NestInterceptor {
    private readonly maxSize;
    constructor(maxSize?: number);
    intercept(context: ExecutionContext, next: CallHandler): Observable<any>;
}
