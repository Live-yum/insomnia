import { CallHandler, ExecutionContext, NestInterceptor } from "@nestjs/common";
import { Observable } from "rxjs";
import { IGuestCacheOptions } from "../common/caching/entities/guest.caching";
import { GuestCachingService } from "../common/caching/guest-caching/guest-caching.service";
export declare class GuestCachingInterceptor implements NestInterceptor {
    private readonly guestCachingService;
    private guestCachingOptions;
    constructor(guestCachingService: GuestCachingService, guestCachingOptions?: IGuestCacheOptions);
    intercept(context: ExecutionContext, next: CallHandler): Promise<Observable<any>>;
}
