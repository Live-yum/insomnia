import { CallHandler, ExecutionContext, NestInterceptor } from "@nestjs/common";
import { HttpAdapterHost } from "@nestjs/core";
import { Observable } from "rxjs";
export declare class LogRequestsInterceptor implements NestInterceptor {
    private readonly httpAdapterHost;
    private readonly logger;
    constructor(httpAdapterHost: HttpAdapterHost);
    intercept(context: ExecutionContext, next: CallHandler): Observable<any>;
}
