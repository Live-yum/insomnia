import { CallHandler, ExecutionContext, NestInterceptor } from "@nestjs/common";
import { HttpAdapterHost } from "@nestjs/core";
import { Observable } from "rxjs";
import { MetricsService } from "../common/metrics/metrics.service";
import { CachingService } from "../common/caching/caching.service";
import { ElrondCachingService } from "../common";
export declare class CachingInterceptor implements NestInterceptor {
    private readonly cachingService;
    private readonly httpAdapterHost;
    private readonly metricsService;
    private pendingRequestsDictionary;
    constructor(cachingService: CachingService | ElrondCachingService, httpAdapterHost: HttpAdapterHost, metricsService: MetricsService);
    intercept(context: ExecutionContext, next: CallHandler): Promise<Observable<any>>;
    getCacheKey(context: ExecutionContext): string | undefined;
}
