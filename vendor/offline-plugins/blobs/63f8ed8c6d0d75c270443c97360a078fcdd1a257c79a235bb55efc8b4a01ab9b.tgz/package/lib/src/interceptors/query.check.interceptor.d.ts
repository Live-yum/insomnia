import { CallHandler, ExecutionContext, HttpAdapterHost, NestInterceptor } from "@nestjs/common";
import { Observable } from "rxjs";
export declare class QueryCheckInterceptor implements NestInterceptor {
    private readonly httpAdapterHost;
    constructor(httpAdapterHost: HttpAdapterHost);
    intercept(context: ExecutionContext, next: CallHandler): Observable<any>;
}
