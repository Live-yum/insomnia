import { CanActivate, ExecutionContext } from '@nestjs/common';
import { CachingService } from '../common/caching/caching.service';
import { ErdnestConfigService } from '../common/config/erdnest.config.service';
export declare class JwtOrNativeAuthGuard implements CanActivate {
    private readonly erdnestConfigService;
    private readonly cachingService;
    constructor(erdnestConfigService: ErdnestConfigService, cachingService: CachingService);
    canActivate(context: ExecutionContext): Promise<boolean>;
}
