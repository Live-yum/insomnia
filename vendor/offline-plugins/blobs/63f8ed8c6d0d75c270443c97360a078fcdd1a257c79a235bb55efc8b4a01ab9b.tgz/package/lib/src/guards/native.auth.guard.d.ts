import { CanActivate, ExecutionContext } from '@nestjs/common';
import { CachingService } from '../common/caching/caching.service';
export declare class NativeAuthGuard implements CanActivate {
    private readonly logger;
    private readonly authServer;
    constructor(cachingService: CachingService);
    canActivate(context: ExecutionContext): Promise<boolean>;
}
