import { CanActivate, ExecutionContext } from '@nestjs/common';
import { ErdnestConfigService } from '../common/config/erdnest.config.service';
export declare class JwtAuthenticateGuard implements CanActivate {
    private readonly erdnestConfigService;
    private readonly logger;
    constructor(erdnestConfigService: ErdnestConfigService);
    canActivate(context: ExecutionContext): Promise<boolean>;
}
