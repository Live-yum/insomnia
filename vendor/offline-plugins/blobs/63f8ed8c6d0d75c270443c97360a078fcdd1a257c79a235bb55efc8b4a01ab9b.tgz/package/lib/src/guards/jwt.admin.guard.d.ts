import { CanActivate, ExecutionContext } from '@nestjs/common';
import { ErdnestConfigService } from '../common/config/erdnest.config.service';
export declare class JwtAdminGuard implements CanActivate {
    private readonly erdnestConfigService;
    constructor(erdnestConfigService: ErdnestConfigService);
    canActivate(context: ExecutionContext): Promise<boolean>;
}
