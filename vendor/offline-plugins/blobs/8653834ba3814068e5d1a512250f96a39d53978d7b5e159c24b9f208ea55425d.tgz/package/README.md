# insomnia-plugin-one-uuid
uuid plugin for insomnia
