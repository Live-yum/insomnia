const properCase = require("proper-case");
const {NIL: NIL_UUID, MAX: MAX_UUID} = require("uuid")
const {v1: uuidv1, v3: uuidv3, v4: uuidv4, v5: uuidv5, v6: uuidv6, v7: uuidv7} = require("uuid")


const supportedVersions = [
  "nil",
  "max",
  "v1",
  "v3",
  "v4",
  "v5",
  "v6",
  "v7"
];

renderInsomniaOptions = function (valueArray) {
  return valueArray.sort().map(function (key) {
    return {
      displayName: properCase(key),
      value: key,
    };
  });
};


module.exports.templateTags = [
{
  name: "auuid",
  displayName: "One UUID",
  description: "Generate various versions of UUID",
  args: [
    {
      displayName: "Type",
      type: "enum",
      options: renderInsomniaOptions(supportedVersions)
    },
  ],
  async run(_context, type) {
    let result;
    switch (type){
      case "nil":
        result = NIL_UUID;
        break
      case "max":
        result = MAX_UUID;
        break
      case "v1":
        result = uuidv1();
        break
      case "v3":
        result = uuidv3();
        break
      case "v4":
        result = uuidv4();
        break
      case "v5":
        result = uuidv5();
        break
      case "v6":
        result = uuidv6();
        break
      case "v7":
        result=uuidv7()
        break

    }
    return result
  },
},
];