// Taken from https://github.com/srcery-colors/srcery-web/blob/master/palette/srcery_javascript.js
// Corrected slightly:
//   Second xgray5 -> xgray6
//   borange -> brightorange
let colors = {
  black: "#505050",
  blue: "#13789c",
  cyan: "#33859d",
  green: "#26a98b",
  magenta: "#888BA5",
  orange: "#d26939",
  red: "#dc362c",
  white: "#98d1ce",
  yellow: "#edb54b",

  brightblack: "#62807f",
  brightblue: "#72b3ca",
  brightcyan: "#599caa",
  brightgreen: "#abe4bb",
  brightmagenta: "#b8bcdf",
  brightorange: "#FF8700",
  brightred: "#d26939",
  brightwhite: "#d3ebe9",
  brightyellow: "#f6d8a1",

  hard_black: "#0a0f14",
  soft_black: "#161D24",
  xgray1: "#262626",
  xgray2: "#303030",
  xgray3: "#3A3A3A",
  xgray4: "#444444",
  xgray5: "#4E4E4E",
  xgray6: "#585858",
};

module.exports.themes = [{
  name: "gotham",
  displayName: "Gotham",
  theme: {
    background: {
      default: "#273542",  // Primary
      success: colors.green,  // POST, 200 OK, parameter names
      notice: colors.yellow,  // PATCH
      warning: colors.orange, // PUT
      danger: colors.red,     // DELETE
      surprise: colors.blue,  // Dashboard link, GET, SEND button, branch button, add plugin button
      info: colors.white,    // OPTIONS, HEAD
    },
    foreground: {
      default: colors.white,        // Primary
      success: colors.brightgreen,  // Secondary font color
      notice: colors.brightyellow,  // Secondary font color
      warning: colors.brightorange, // Secondary font color
      danger: colors.brightred,     // Secondary font color
      surprise: colors.brightblue, // Secondary font color
      info: colors.white,          // Secondary font color for info background
    },
    highlight: {
      default: colors.white,        // Sidebar highlight color
    },

    // The styles object targets sub-components of the Insomnia application.
    styles: {
      sidebar: {
        background: {
          default: colors.soft_black,
        },
      },
      dialog: {
        background: {
          default: colors.soft_black,
        },
      },
      pane: {
        background: {
          default: colors.hard_black,
        },
      },
      paneHeader: {
        background: {
          default: colors.soft_black,
        },
        foreground: {
          default: colors.white,
        },
      },
      // TODO this isn't working. I'd like the send button to not be blue.
      editor: {
        background: {
          surprise: colors.black,
        },
      },
      transparentOverlay: {
        background: {
          default: `${colors.soft_black}80`
        },
      },
    },
  },
}];
