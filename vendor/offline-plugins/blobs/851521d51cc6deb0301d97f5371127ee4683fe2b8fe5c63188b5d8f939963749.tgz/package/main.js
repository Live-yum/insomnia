module.exports.templateTags = [{
    name: 'LoadTesting',
    displayName: 'Load Testing',
    description: 'Automate Load test',
  
    run (username) 
    {
	let myArray = [
    		['User1', 'Pswd1'],
    		['User2', 'Pswd2'],
    		['User3', 'Pswd3'],
    		['User4', 'Pswd4'],
    		['User5', 'Pswd5']
	];

	var arrayLength = myArray.length;
	var ds = 'username';

	for (var i = 0; i < arrayLength; i++)
  	{
  		ds = '"'.concat(myArray[i][0], '"',', "Password": "',myArray[i][1], '"');
  		return ds;
  	}
    }
}];

