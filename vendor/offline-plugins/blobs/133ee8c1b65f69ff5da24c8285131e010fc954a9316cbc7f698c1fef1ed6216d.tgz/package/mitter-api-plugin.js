const crypto = require('crypto')
const randomstring = require('randomstring')
const url = require('url')

const pluginConfigKey = "mitterPluginConfig"

const Headers = {
    Nonce: 'Nonce',
    Date: 'Date',
    ContentMD5: 'Content-Md5',
    ContentType: 'Content-Type'
}

function signRequest(key, digestParts) {
    const date = getDate(digestParts)
    const contentType = getContentType(digestParts)
    const nonce = getNonce(digestParts)

    const computePayload = [
        digestParts.method.toUpperCase(),
        contentType,
        digestParts.payloadMd5,
        date,
        digestParts.path,
        nonce
    ].join('\n')

    const digest = crypto
        .createHmac('SHA1', Buffer.from(key.accessSecret, 'base64'))
        .update(computePayload)
        .digest('base64')

    return { nonce, date, auth: `Auth ${key.accessKey}:${digest}`}
}

function getNonce(digestParts) {
    if (digestParts.nonce !== undefined && digestParts.nonce !== null) {
        return digestParts.nonce
    } else {
        return randomstring.generate(32)
    }
}

function getContentType(digestParts) {
    if (digestParts.contentType !== undefined && digestParts.contentType !== null) {
        return digestParts.contentType
    } else {
        return 'null'
    }
}

function getDate(digestParts) {
    if (digestParts.date !== undefined && digestParts.date !== null) {
        return digestParts.date
    } else {
        return new Date().toUTCString()
    }
}

module.exports.requestHooks = [
    context => {
        const env = context.request.getEnvironment();
        const request = context.request;

        if (pluginConfigKey in env) {
            try {
                const config = env[pluginConfigKey].find(cfg => request.getUrl().startsWith(cfg.url))

                if (config !== undefined) {
                    const accessKey = config.accessKey
                    const accessSecret = config.accessSecret
                    const contentMd5 = crypto.createHash('md5').update(request.getBodyText()).digest('base64')

                    const computedDigest = signRequest(
                        {
                            accessKey,
                            accessSecret
                        },
                        {
                            method: request.getMethod(),
                            date: request.getHeader("Date"),
                            nonce: request.getHeader("Nonce"),
                            path: url.parse(request.getUrl()).path,
                            contentType: request.getHeader("Content-Type"),
                            payloadMd5: contentMd5
                        }
                    )

                    request.setHeader("Date", computedDigest.date);
                    request.setHeader("Nonce", computedDigest.nonce);
                    request.setHeader("Authorization", computedDigest.auth);
                    request.setHeader("X-Mitter-Application-Access-Key", accessKey);
                    request.setHeader("Content-Md5", contentMd5);
                }
            } catch(e) {
                console.error(e);
                throw e;
            }
        }
    }
];
