// Folder actions are exported as an array of objects
var axios = require('axios')

let DEFAULT_SERVER = 'http://127.0.0.1:5000';

// 筛选出指定工作区的数据
function filterByWorkspace(data, workspace_id) {
  var resources = data.resources;
  var map = {};
  // 构造 map[resource._id] => resource
  for(var resource of resources) {
    map[resource._id] = resource;
    if(resource._type === 'workspace') {
      resource.workspace_id = resource._id
    }
  }

  for(var resource of resources) {
    if(resource.workspace_id) {
      continue;
    }
    // 否则不停查询父节点，直到找到 workspace_id
    var parent = resource;
    while (true) {
      parent = map[parent.parentId];
      if(parent.workspace_id) {
        resource.workspace_id = parent.workspace_id;
        break;
      }
    }
  }
  data.resources = resources.filter(item =>item.workspace_id === workspace_id)
}


async function getUrl(context, uri) {
  var server = await context.store.getItem('server');
  server = server || DEFAULT_SERVER;
  return server + uri;
}


module.exports.workspaceActions = [
  {
    label: '发布当前工作区文档',
    action: async (context, data) => {
      const { requests } = data;
      let resp = await axios.post(await getUrl(context, '/docs/api/publish'), data.workspace);
      if(resp.data) {
        context.app.prompt('发布成功', {
          defaultValue: resp.data.data,
          submitName: '确定',
          cancelable: false
        })
      } else {
        context.app.alert('发布失败', resp.data);
      }
    },
  },
  {
    label: '配置文档服务器...',
    action: async (context, data) => {
      var server = await context.app.prompt('服务器地址：', {
        defaultValue: await getUrl(context, ''),
        submitName: '保存',
        cancelable: false
      })

      context.store.setItem('server', server);
    },
  }
];