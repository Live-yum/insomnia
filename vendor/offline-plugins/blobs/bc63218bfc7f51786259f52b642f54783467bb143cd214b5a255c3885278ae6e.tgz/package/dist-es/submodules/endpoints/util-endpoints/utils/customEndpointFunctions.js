export const customEndpointFunctions = {};
