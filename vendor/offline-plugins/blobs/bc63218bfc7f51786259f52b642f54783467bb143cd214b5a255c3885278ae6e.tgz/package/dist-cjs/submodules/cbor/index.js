const { nv, NumericValue, calculateBodyLength, generateIdempotencyToken, fromBase64, _parseEpochTimestamp } = require("@smithy/core/serde");
const { hasOwn, getSmithyContext } = require("@smithy/core/transport");
const { HttpRequest, collectBody, SerdeContext, RpcProtocol } = require("@smithy/core/protocols");
const { NormalizedSchema, deref, TypeRegistry } = require("@smithy/core/schema");

const majorUint64 = 0;
const majorNegativeInt64 = 1;
const majorUnstructuredByteString = 2;
const majorUtf8String = 3;
const majorList = 4;
const majorMap = 5;
const majorTag = 6;
const majorSpecial = 7;
const specialFalse = 20;
const specialTrue = 21;
const specialNull = 22;
const specialUndefined = 23;
const extendedOneByte = 24;
const extendedFloat16 = 25;
const extendedFloat32 = 26;
const extendedFloat64 = 27;
const minorIndefinite = 31;
function alloc(size) {
    return typeof Buffer !== "undefined" ? Buffer.alloc(size) : new Uint8Array(size);
}
const tagSymbol = Symbol("@smithy/core/cbor::tagSymbol");
function tag(data) {
    data[tagSymbol] = true;
    return data;
}

const USE_BUFFER$3 = typeof Buffer !== "undefined";
const textDecoder$1 = new TextDecoder();
let payload$1 = alloc(0);
let isBuffer$1 = false;
let dataView$2 = new DataView(payload$1.buffer, payload$1.byteOffset, payload$1.byteLength);
let _offset = 0;
function setPayload(bytes) {
    payload$1 = bytes;
    isBuffer$1 = USE_BUFFER$3 && payload$1 instanceof Buffer;
    dataView$2 = new DataView(payload$1.buffer, payload$1.byteOffset, payload$1.byteLength);
}
function decode(at, to) {
    if (at >= to) {
        throw new Error("unexpected end of (decode) payload.");
    }
    const major = (payload$1[at] & 0b1110_0000) >> 5;
    const minor = payload$1[at] & 0b0001_1111;
    if (minor === minorIndefinite && 2 <= major && major <= 5) {
        return decodeIndefinite(at, to);
    }
    switch (major) {
        case majorUint64:
        case majorNegativeInt64:
        case majorTag: {
            let unsignedInt;
            let offset;
            if (minor < 24) {
                unsignedInt = minor;
                offset = 1;
            }
            else {
                switch (minor) {
                    case extendedOneByte:
                        if (to - at < 2) {
                            overflow$1(1);
                        }
                        unsignedInt = payload$1[at + 1];
                        offset = 2;
                        break;
                    case extendedFloat16:
                        if (to - at < 3) {
                            overflow$1(2);
                        }
                        unsignedInt = dataView$2.getUint16(at + 1);
                        offset = 3;
                        break;
                    case extendedFloat32:
                        if (to - at < 5) {
                            overflow$1(4);
                        }
                        unsignedInt = dataView$2.getUint32(at + 1);
                        offset = 5;
                        break;
                    case extendedFloat64:
                        if (to - at < 9) {
                            overflow$1(8);
                        }
                        {
                            const hi = dataView$2.getUint32(at + 1);
                            if (hi < 0x00200000) {
                                unsignedInt = hi * 4294967296 + dataView$2.getUint32(at + 5);
                            }
                            else {
                                unsignedInt = dataView$2.getBigUint64(at + 1);
                            }
                        }
                        offset = 9;
                        break;
                    default:
                        unexpectedMinor(minor);
                }
            }
            if (major === majorUint64) {
                _offset = offset;
                return castBigInt$1(unsignedInt);
            }
            else if (major === majorNegativeInt64) {
                let negativeInt;
                if (typeof unsignedInt === "bigint") {
                    negativeInt = BigInt(-1) - unsignedInt;
                }
                else {
                    negativeInt = -1 - unsignedInt;
                }
                _offset = offset;
                return castBigInt$1(negativeInt);
            }
            else {
                return decodeTagValue(at, to, minor, unsignedInt, offset);
            }
        }
        case majorUtf8String:
            return decodeUtf8String(at, to);
        case majorMap:
            return decodeMap(at, to);
        case majorList:
            return decodeList(at, to);
        case majorUnstructuredByteString:
            return decodeUnstructuredByteString(at, to);
        default:
            return decodeSpecial(at, to);
    }
}
function decodeIndefinite(at, to) {
    const major = (payload$1[at] & 0b1110_0000) >> 5;
    const minor = payload$1[at] & 0b0001_1111;
    if (minor === minorIndefinite) {
        switch (major) {
            case majorUtf8String:
                return decodeUtf8StringIndefinite(at, to);
            case majorMap:
                return decodeMapIndefinite(at, to);
            case majorList:
                return decodeListIndefinite(at, to);
            case majorUnstructuredByteString:
                return decodeUnstructuredByteStringIndefinite(at, to);
        }
    }
}
function bytesToFloat16$1(a, b) {
    const sign = a >> 7;
    const exponent = (a & 0b0111_1100) >> 2;
    const fraction = ((a & 0b0000_0011) << 8) | b;
    const scalar = sign === 0 ? 1 : -1;
    if (exponent === 0b00000) {
        if (fraction === 0) {
            return 0;
        }
        return scalar * (Math.pow(2, 1 - 15) * (fraction / 1024));
    }
    else if (exponent === 0b11111) {
        if (fraction === 0) {
            return scalar * Infinity;
        }
        return NaN;
    }
    return scalar * (Math.pow(2, exponent - 15) * (1 + fraction / 1024));
}
function decodeMap(at, to) {
    const mapDataLength = decodeCount$1(at, to);
    if (mapDataLength < 25) {
        return decodeMapSmall(at, to, mapDataLength);
    }
    return decodeMapLarge(at, to, mapDataLength);
}
function decodeMapLarge(at, to, mapDataLength) {
    const offset = _offset;
    at += offset;
    const base = at;
    const map = Object.create(null);
    for (let i = 0; i < mapDataLength; ++i) {
        const key = decodeUtf8String(at, to);
        at += _offset;
        const valMajor = (payload$1[at] & 0b1110_0000) >> 5;
        if (valMajor === majorUtf8String) {
            map[key] = decodeUtf8String(at, to);
        }
        else {
            map[key] = decode(at, to);
        }
        at += _offset;
    }
    _offset = offset + (at - base);
    Object.setPrototypeOf(map, Object.prototype);
    return map;
}
function decodeMapSmall(at, to, mapDataLength) {
    const offset = _offset;
    at += offset;
    const base = at;
    const map = {};
    for (let i = 0; i < mapDataLength; ++i) {
        const key = decodeUtf8String(at, to);
        at += _offset;
        map[key] = decode(at, to);
        at += _offset;
    }
    _offset = offset + (at - base);
    return map;
}
function decodeList(at, to) {
    const listDataLength = decodeCount$1(at, to);
    const offset = _offset;
    at += offset;
    const base = at;
    const list = Array(listDataLength);
    for (let i = 0; i < listDataLength; ++i) {
        list[i] = decode(at, to);
        at += _offset;
    }
    _offset = offset + (at - base);
    return list;
}
function decodeUtf8String(at, to) {
    const length = decodeCount$1(at, to);
    const offset = _offset;
    at += offset;
    if (to - at < length) {
        overflow$1(length);
    }
    _offset = offset + length;
    if (length < 24) {
        return decodeUtf8StringCached(at, length);
    }
    if (isBuffer$1) {
        return payload$1.toString("utf-8", at, at + length);
    }
    return textDecoder$1.decode(payload$1.subarray(at, at + length));
}
const stringCache$1 = new Array(2048);
const stringCacheEpochs$1 = new Uint16Array(2048);
let cacheEpoch$1 = 0;
function advanceDecodingEpoch() {
    cacheEpoch$1 = (cacheEpoch$1 + 1) & 0b1111_1111_1111_1111;
}
function decodeUtf8StringCached(at, length) {
    let h = length;
    for (let i = 0; i < length; ++i) {
        h = (h * 31 + payload$1[at + i]) | 0;
    }
    const slot = (h >>> 0) & 2047;
    const cached = stringCache$1[slot];
    if (cached !== undefined) {
        if (cached.length === length) {
            let match = true;
            for (let i = 0; i < length; ++i) {
                if (cached.charCodeAt(i) !== payload$1[at + i]) {
                    match = false;
                    break;
                }
            }
            if (match) {
                stringCacheEpochs$1[slot] = cacheEpoch$1;
                return cached;
            }
        }
    }
    const result = isBuffer$1
        ? payload$1.toString("utf-8", at, at + length)
        : textDecoder$1.decode(payload$1.subarray(at, at + length));
    if (stringCacheEpochs$1[slot] !== cacheEpoch$1) {
        stringCache$1[slot] = result;
        stringCacheEpochs$1[slot] = cacheEpoch$1;
    }
    return result;
}
function decodeUnstructuredByteString(at, to) {
    const length = decodeCount$1(at, to);
    const offset = _offset;
    at += offset;
    if (to - at < length) {
        overflow$1(length);
    }
    const value = payload$1.subarray(at, at + length);
    _offset = offset + length;
    return value;
}
function decodeTagValue(at, to, minor, unsignedInt, offset) {
    if (minor === 2 || minor === 3) {
        const length = decodeCount$1(at + offset, to);
        let b = BigInt(0);
        const start = at + offset + _offset;
        for (let i = start; i < start + length; ++i) {
            b = (b << BigInt(8)) | BigInt(payload$1[i]);
        }
        _offset = offset + _offset + length;
        return minor === 3 ? -b - BigInt(1) : b;
    }
    else if (minor === 4) {
        const decimalFraction = decode(at + offset, to);
        const [rawExponent, mantissa] = decimalFraction;
        const normalizer = mantissa < 0 ? -1 : 1;
        const absMantissa = BigInt(normalizer) * BigInt(mantissa);
        const mantissaDigits = String(absMantissa);
        const sign = mantissa < 0 ? "-" : "";
        let numericString;
        const isSmallExponent = typeof rawExponent === "number" && Math.abs(rawExponent) <= 2 ** 28;
        if (isSmallExponent) {
            const exponent = rawExponent;
            const mantissaStr = "0".repeat(Math.abs(exponent) + 1) + mantissaDigits;
            numericString =
                exponent === 0
                    ? mantissaStr
                    : mantissaStr.slice(0, mantissaStr.length + exponent) + "." + mantissaStr.slice(exponent);
            numericString = numericString.replace(/^0+/g, "");
            if (numericString === "") {
                numericString = "0";
            }
            if (numericString[0] === ".") {
                numericString = "0" + numericString;
            }
            numericString = sign + numericString;
        }
        else {
            const bigExponent = BigInt(rawExponent);
            if (mantissaDigits.length === 1) {
                numericString = sign + mantissaDigits + "e" + String(bigExponent);
            }
            else {
                const adjustedExp = bigExponent + BigInt(mantissaDigits.length - 1);
                numericString = sign + mantissaDigits[0] + "." + mantissaDigits.slice(1) + "e" + String(adjustedExp);
            }
        }
        _offset = offset + _offset;
        return nv(numericString);
    }
    else {
        const value = decode(at + offset, to);
        const valueOffset = _offset;
        _offset = offset + valueOffset;
        return tag({ tag: castBigInt$1(unsignedInt), value });
    }
}
function decodeSpecial(at, to) {
    const minor = payload$1[at] & 0b0001_1111;
    switch (minor) {
        case specialTrue:
        case specialFalse:
            _offset = 1;
            return minor === specialTrue;
        case specialNull:
            _offset = 1;
            return null;
        case specialUndefined:
            _offset = 1;
            return null;
        case extendedFloat16:
            if (to - at < 3) {
                throw new Error("incomplete float16 at end of buf.");
            }
            _offset = 3;
            return bytesToFloat16$1(payload$1[at + 1], payload$1[at + 2]);
        case extendedFloat32:
            if (to - at < 5) {
                throw new Error("incomplete float32 at end of buf.");
            }
            _offset = 5;
            return dataView$2.getFloat32(at + 1);
        case extendedFloat64:
            if (to - at < 9) {
                throw new Error("incomplete float64 at end of buf.");
            }
            _offset = 9;
            return dataView$2.getFloat64(at + 1);
        default:
            unexpectedMinor(minor);
    }
}
function decodeCount$1(at, to) {
    const minor = payload$1[at] & 0b0001_1111;
    if (minor < 24) {
        _offset = 1;
        return minor;
    }
    switch (minor) {
        case extendedOneByte:
            if (to - at < 2) {
                overflow$1(1);
            }
            _offset = 2;
            return payload$1[at + 1];
        case extendedFloat16:
            if (to - at < 3) {
                overflow$1(2);
            }
            _offset = 3;
            return dataView$2.getUint16(at + 1);
        case extendedFloat32:
            if (to - at < 5) {
                overflow$1(4);
            }
            _offset = 5;
            return dataView$2.getUint32(at + 1);
        case extendedFloat64:
            if (to - at < 9) {
                overflow$1(8);
            }
            _offset = 9;
            return demote(dataView$2.getBigUint64(at + 1));
        default:
            unexpectedMinor(minor);
    }
}
function decodeMapIndefinite(at, to) {
    at += 1;
    const base = at;
    const map = {};
    for (; at < to;) {
        if (payload$1[at] === 0b1111_1111) {
            _offset = at - base + 2;
            return map;
        }
        const key = decodeUtf8String(at, to);
        at += _offset;
        map[key] = decode(at, to);
        at += _offset;
    }
    throw new Error("expected break marker.");
}
function decodeListIndefinite(at, to) {
    at += 1;
    const list = [];
    for (const base = at; at < to;) {
        if (payload$1[at] === 0b1111_1111) {
            _offset = at - base + 2;
            return list;
        }
        list.push(decode(at, to));
        at += _offset;
    }
    throw new Error("expected break marker.");
}
function decodeUtf8StringIndefinite(at, to) {
    at += 1;
    const vector = [];
    for (const base = at; at < to;) {
        if (payload$1[at] === 0b1111_1111) {
            const data = alloc(vector.length);
            data.set(vector, 0);
            _offset = at - base + 2;
            if (USE_BUFFER$3) {
                return data.toString("utf-8", 0, data.length);
            }
            return textDecoder$1.decode(data);
        }
        const major = (payload$1[at] & 0b1110_0000) >> 5;
        const minor = payload$1[at] & 0b0001_1111;
        if (major !== majorUtf8String) {
            unexpectedMajorInIndefiniteString(major);
        }
        if (minor === minorIndefinite) {
            throw new Error("nested indefinite string.");
        }
        const bytes = decodeUnstructuredByteString(at, to);
        const length = _offset;
        at += length;
        for (let i = 0; i < bytes.length; ++i) {
            vector.push(bytes[i]);
        }
    }
    throw new Error("expected break marker.");
}
function decodeUnstructuredByteStringIndefinite(at, to) {
    at += 1;
    const vector = [];
    for (const base = at; at < to;) {
        if (payload$1[at] === 0b1111_1111) {
            const data = alloc(vector.length);
            data.set(vector, 0);
            _offset = at - base + 2;
            return data;
        }
        const major = (payload$1[at] & 0b1110_0000) >> 5;
        const minor = payload$1[at] & 0b0001_1111;
        if (major !== majorUnstructuredByteString) {
            unexpectedMajorInIndefiniteString(major);
        }
        if (minor === minorIndefinite) {
            throw new Error("nested indefinite string.");
        }
        const bytes = decodeUnstructuredByteString(at, to);
        const length = _offset;
        at += length;
        for (let i = 0; i < bytes.length; ++i) {
            vector.push(bytes[i]);
        }
    }
    throw new Error("expected break marker.");
}
function castBigInt$1(bigInt) {
    if (typeof bigInt === "number") {
        return bigInt;
    }
    const num = Number(bigInt);
    if (Number.MIN_SAFE_INTEGER <= num && num <= Number.MAX_SAFE_INTEGER) {
        return num;
    }
    return bigInt;
}
function demote(bigInteger) {
    const num = Number(bigInteger);
    if (num < Number.MIN_SAFE_INTEGER || Number.MAX_SAFE_INTEGER < num) {
        console.warn(new Error(`@smithy/core/cbor - truncating BigInt(${bigInteger}) to ${num} with loss of precision.`));
    }
    return num;
}
function overflow$1(n) {
    throw new Error(`length ${n} greater than remaining buf len.`);
}
function unexpectedMinor(minor) {
    throw new Error(`unexpected minor value ${minor}.`);
}
function unexpectedMajorInIndefiniteString(major) {
    throw new Error(`unexpected major type ${major} in indefinite string.`);
}

const USE_BUFFER$2 = typeof Buffer !== "undefined";
const encodeStringCache = new Map();
let encodeCacheEpoch$1 = 0;
let encodeCacheSaturated$1 = false;
const initialSize = 2048;
let data = alloc(initialSize);
let dataView$1 = new DataView(data.buffer, data.byteOffset, data.byteLength);
let cursor$1 = 0;
function encode(_input) {
    const encodeStack = [_input];
    while (encodeStack.length) {
        const input = encodeStack.pop();
        if (typeof input === "string") {
            const len = input.length;
            if (USE_BUFFER$2) {
                ensureSpace(len * 3 + 9);
                if (len > 23) {
                    encodeHeader$1(majorUtf8String, Buffer.byteLength(input));
                    cursor$1 += data.write(input, cursor$1);
                }
                else {
                    encodeStringCached(input);
                }
            }
            else {
                const maxBytes = len * 3;
                ensureSpace(maxBytes + 9);
                const headerPos = cursor$1;
                const result = new TextEncoder().encodeInto(input, data.subarray(cursor$1 + 9));
                const byteLen = result.written;
                let headerSize;
                if (byteLen < 24) {
                    headerSize = 1;
                }
                else if (byteLen < 256) {
                    headerSize = 2;
                }
                else if (byteLen < 65536) {
                    headerSize = 3;
                }
                else if (byteLen < 4294967296) {
                    headerSize = 5;
                }
                else {
                    headerSize = 9;
                }
                if (headerSize < 9) {
                    data.copyWithin(headerPos + headerSize, headerPos + 9, headerPos + 9 + byteLen);
                }
                cursor$1 = headerPos;
                encodeInteger(majorUtf8String, byteLen);
                cursor$1 += byteLen;
            }
            continue;
        }
        if (data.byteLength - cursor$1 < 9) {
            ensureSpace(64);
        }
        if (typeof input === "number") {
            if (Number.isInteger(input) && input >= -9007199254740992 && input <= 0x1fffffffffffff) {
                const nonNegative = input >= 0;
                const major = nonNegative ? majorUint64 : majorNegativeInt64;
                const value = nonNegative ? input : -input - 1;
                if (value < 24) {
                    data[cursor$1++] = (major << 5) | value;
                }
                else if (value < 256) {
                    data[cursor$1++] = (major << 5) | 24;
                    data[cursor$1++] = value;
                }
                else if (value < 65536) {
                    data[cursor$1++] = (major << 5) | extendedFloat16;
                    data[cursor$1++] = value >> 8;
                    data[cursor$1++] = value & 0xff;
                }
                else if (value < 4294967296) {
                    data[cursor$1++] = (major << 5) | extendedFloat32;
                    dataView$1.setUint32(cursor$1, value);
                    cursor$1 += 4;
                }
                else {
                    data[cursor$1++] = (major << 5) | extendedFloat64;
                    const hi = (value / 4294967296) | 0;
                    const lo = (value - hi * 4294967296) | 0;
                    dataView$1.setUint32(cursor$1, hi);
                    dataView$1.setUint32(cursor$1 + 4, lo);
                    cursor$1 += 8;
                }
                continue;
            }
            data[cursor$1++] = (majorSpecial << 5) | extendedFloat64;
            dataView$1.setFloat64(cursor$1, input);
            cursor$1 += 8;
            continue;
        }
        else if (typeof input === "bigint") {
            const nonNegative = input >= 0;
            const major = nonNegative ? majorUint64 : majorNegativeInt64;
            const value = nonNegative ? input : -input - BigInt(1);
            if (value < BigInt("18446744073709551616")) {
                const n = Number(value);
                if (n < 4294967296) {
                    encodeInteger(major, n);
                }
                else {
                    data[cursor$1++] = (major << 5) | extendedFloat64;
                    dataView$1.setBigUint64(cursor$1, value);
                    cursor$1 += 8;
                }
            }
            else {
                const binaryBigInt = value.toString(2);
                const bigIntBytes = new Uint8Array(Math.ceil(binaryBigInt.length / 8));
                let b = value;
                let i = 0;
                while (bigIntBytes.byteLength - ++i >= 0) {
                    bigIntBytes[bigIntBytes.byteLength - i] = Number(b & BigInt(255));
                    b >>= BigInt(8);
                }
                ensureSpace(bigIntBytes.byteLength * 2 + 16);
                data[cursor$1++] = nonNegative ? 0b110_00010 : 0b110_00011;
                encodeHeader$1(majorUnstructuredByteString, bigIntBytes.byteLength);
                data.set(bigIntBytes, cursor$1);
                cursor$1 += bigIntBytes.byteLength;
            }
            continue;
        }
        else if (input === null) {
            data[cursor$1++] = (majorSpecial << 5) | specialNull;
            continue;
        }
        else if (typeof input === "boolean") {
            data[cursor$1++] = (majorSpecial << 5) | (input ? specialTrue : specialFalse);
            continue;
        }
        else if (typeof input === "undefined") {
            throw new Error("@smithy/core/cbor: client may not serialize undefined value.");
        }
        else if (Array.isArray(input)) {
            encodeInteger(majorList, input.length);
            ensureSpace(input.length * 9 + 64);
            for (let i = input.length - 1; i >= 0; --i) {
                encodeStack.push(input[i]);
            }
            continue;
        }
        else if (typeof input.byteLength === "number") {
            ensureSpace(input.length * 2 + 9);
            encodeInteger(majorUnstructuredByteString, input.length);
            data.set(input, cursor$1);
            cursor$1 += input.byteLength;
            continue;
        }
        else if (typeof input === "object") {
            if (input instanceof NumericValue) {
                let str = input.string;
                let expOffset = BigInt(0);
                const eIndex = str.search(/[eE]/);
                if (eIndex !== -1) {
                    expOffset = BigInt(str.slice(eIndex + 1));
                    str = str.slice(0, eIndex);
                }
                const decimalIndex = str.indexOf(".");
                const fractionDigits = decimalIndex === -1 ? 0 : str.length - decimalIndex - 1;
                const exponent = expOffset - BigInt(fractionDigits);
                const mantissa = BigInt(str.replace(".", ""));
                data[cursor$1++] = 0b110_00100;
                encodeInteger(majorList, 2);
                encodeStack.push(mantissa);
                encodeStack.push(exponent >= -0x20000000000000n && exponent <= 0x1fffffffffffffn ? Number(exponent) : exponent);
                continue;
            }
            if (input[tagSymbol]) {
                if ("tag" in input && "value" in input) {
                    encodeStack.push(input.value);
                    encodeHeader$1(majorTag, input.tag);
                    continue;
                }
                else {
                    throw new Error("tag encountered with missing fields, need 'tag' and 'value', found: " + JSON.stringify(input));
                }
            }
            const keys = Object.keys(input);
            const len = keys.length;
            encodeInteger(majorMap, len);
            for (let i = len - 1; i >= 0; --i) {
                encodeStack.push(input[keys[i]]);
                encodeStack.push(keys[i]);
            }
            continue;
        }
        throw new Error(`data type ${input?.constructor?.name ?? typeof input} not compatible for encoding.`);
    }
}
function advanceEncodingEpoch() {
    encodeCacheEpoch$1 = (encodeCacheEpoch$1 + 1) & 0b1111_1111_1111_1111;
    encodeCacheSaturated$1 = false;
}
function toUint8Array() {
    const out = alloc(cursor$1);
    out.set(data.subarray(0, cursor$1), 0);
    cursor$1 = 0;
    return out;
}
function resize(size) {
    const old = data;
    data = alloc(size);
    if (old) {
        if (old.copy) {
            old.copy(data, 0, 0, old.byteLength);
        }
        else {
            data.set(old, 0);
        }
    }
    dataView$1 = new DataView(data.buffer, data.byteOffset, data.byteLength);
}
function encodeStringCached(input) {
    const cached = encodeStringCache.get(input);
    if (cached !== undefined) {
        data.set(cached.bytes, cursor$1);
        cursor$1 += cached.bytes.length;
        cached.epoch = encodeCacheEpoch$1;
        return;
    }
    const start = cursor$1;
    const byteLen = Buffer.byteLength(input);
    encodeInteger(majorUtf8String, byteLen);
    cursor$1 += data.write(input, cursor$1);
    const bytes = Uint8Array.prototype.slice.call(data, start, cursor$1);
    if (encodeStringCache.size >= 2048) {
        if (encodeCacheSaturated$1) {
            return;
        }
        let evicted = 0;
        for (const [key, entry] of encodeStringCache) {
            if (evicted >= 1024) {
                break;
            }
            if (entry.epoch !== encodeCacheEpoch$1) {
                encodeStringCache.delete(key);
                evicted++;
            }
        }
        if (evicted === 0) {
            encodeCacheSaturated$1 = true;
            return;
        }
    }
    if (encodeStringCache.size < 2048) {
        encodeStringCache.set(input, { epoch: encodeCacheEpoch$1, bytes });
    }
}
function ensureSpace(bytes) {
    const remaining = data.byteLength - cursor$1;
    if (remaining < bytes) {
        if (cursor$1 < 16_000_000) {
            resize(Math.max(data.byteLength * 4, data.byteLength + bytes));
        }
        else {
            resize(data.byteLength + bytes + 16_000_000);
        }
    }
}
function encodeHeader$1(major, value) {
    if (value < 24) {
        data[cursor$1++] = (major << 5) | value;
    }
    else if (value < 256) {
        data[cursor$1++] = (major << 5) | 24;
        data[cursor$1++] = value;
    }
    else if (value < 65536) {
        data[cursor$1++] = (major << 5) | extendedFloat16;
        dataView$1.setUint16(cursor$1, value);
        cursor$1 += 2;
    }
    else if (value < 4294967296) {
        data[cursor$1++] = (major << 5) | extendedFloat32;
        dataView$1.setUint32(cursor$1, value);
        cursor$1 += 4;
    }
    else {
        data[cursor$1++] = (major << 5) | extendedFloat64;
        dataView$1.setBigUint64(cursor$1, typeof value === "bigint" ? value : BigInt(value));
        cursor$1 += 8;
    }
}
function encodeInteger(major, value) {
    if (value < 24) {
        data[cursor$1++] = (major << 5) | value;
    }
    else if (value < 256) {
        data[cursor$1++] = (major << 5) | 24;
        data[cursor$1++] = value;
    }
    else if (value < 65536) {
        data[cursor$1++] = (major << 5) | extendedFloat16;
        data[cursor$1++] = value >> 8;
        data[cursor$1++] = value & 0xff;
    }
    else if (value < 4294967296) {
        data[cursor$1++] = (major << 5) | extendedFloat32;
        dataView$1.setUint32(cursor$1, value);
        cursor$1 += 4;
    }
    else {
        data[cursor$1++] = (major << 5) | extendedFloat64;
        const hi = (value / 4294967296) | 0;
        const lo = (value - hi * 4294967296) | 0;
        dataView$1.setUint32(cursor$1, hi);
        dataView$1.setUint32(cursor$1 + 4, lo);
        cursor$1 += 8;
    }
}

const cbor = {
    deserialize(payload) {
        advanceDecodingEpoch();
        setPayload(payload);
        return decode(0, payload.length);
    },
    serialize(input) {
        advanceEncodingEpoch();
        try {
            encode(input);
            return toUint8Array();
        }
        catch (e) {
            toUint8Array();
            throw e;
        }
    },
    resizeEncodingBuffer(size) {
        resize(size);
    },
};

const parseCborBody = (streamBody, context) => {
    return collectBody(streamBody, context).then(async (bytes) => {
        if (bytes.length) {
            try {
                return cbor.deserialize(bytes);
            }
            catch (e) {
                Object.defineProperty(e, "$responseBodyText", {
                    value: context.utf8Encoder(bytes),
                });
                throw e;
            }
        }
        return {};
    });
};
const dateToTag = (date) => {
    return tag({
        tag: 1,
        value: date.getTime() / 1000,
    });
};
const parseCborErrorBody = async (errorBody, context) => {
    const value = await parseCborBody(errorBody, context);
    value.message = value.message ?? value.Message;
    return value;
};
const loadSmithyRpcV2CborErrorCode = (output, data) => {
    const sanitizeErrorCode = (rawValue) => {
        let cleanValue = rawValue;
        if (typeof cleanValue === "number") {
            cleanValue = cleanValue.toString();
        }
        if (cleanValue.indexOf(",") >= 0) {
            cleanValue = cleanValue.split(",")[0];
        }
        if (cleanValue.indexOf(":") >= 0) {
            cleanValue = cleanValue.split(":")[0];
        }
        return cleanValue;
    };
    if (data["__type"] !== undefined) {
        return sanitizeErrorCode(data["__type"]);
    }
};
const checkCborResponse = (response) => {
    if (String(response.headers["smithy-protocol"]).toLowerCase() !== "rpc-v2-cbor") {
        throw new Error("Malformed RPCv2 CBOR response, status: " + response.statusCode);
    }
};
const buildHttpRpcRequest = async (context, headers, path, resolvedHostname, body) => {
    const endpoint = await context.endpoint();
    const { hostname, protocol = "https", port, path: basePath } = endpoint;
    const contents = {
        protocol,
        hostname,
        port,
        method: "POST",
        path: basePath.endsWith("/") ? basePath.slice(0, -1) + path : basePath + path,
        headers: {
            ...headers,
        },
    };
    if (resolvedHostname !== undefined) {
        contents.hostname = resolvedHostname;
    }
    if (endpoint.headers) {
        for (const name in endpoint.headers) {
            if (!hasOwn(endpoint.headers, name))
                continue;
            contents.headers[name] = endpoint.headers[name];
        }
    }
    if (body !== undefined) {
        contents.body = body;
        try {
            contents.headers["content-length"] = String(calculateBodyLength(body));
        }
        catch (ignored) { }
    }
    return new HttpRequest(contents);
};

class CborShapeSerializer2 extends SerdeContext {
    write(schema, value) {
        cursor = 0;
        const ns = NormalizedSchema.of(schema);
        writeValue(ns, value, undefined, this.serdeContext);
    }
    flush() {
        const result = buf.subarray(0, cursor);
        cursor = 0;
        buf = allocUnsafe(INITIAL_BUFFER_SIZE);
        view = new DataView(buf.buffer, buf.byteOffset, buf.byteLength);
        return result;
    }
}
const CBOR_STRUCT_CACHE = Symbol.for("@smithy/cbor-struct-cache");
function loadCborStructIterator(ns) {
    const schema = ns.getSchema();
    const existing = schema[CBOR_STRUCT_CACHE];
    if (existing) {
        return existing;
    }
    const memberNames = [];
    const memberSchemas = [];
    for (const [name, memberSchema] of ns.structIterator()) {
        memberNames.push(name);
        memberSchemas.push(memberSchema);
    }
    const encodedKeys = new Array(memberNames.length);
    for (let i = 0; i < memberNames.length; ++i) {
        encodedKeys[i] = encodeCborStringKey(memberNames[i]);
    }
    const cache = { memberNames, memberSchemas, encodedKeys };
    schema[CBOR_STRUCT_CACHE] = cache;
    return cache;
}
function encodeCborStringKey(s) {
    let utf8Bytes;
    if (USE_BUFFER$1) {
        utf8Bytes = Buffer.from(s, "utf-8");
    }
    else {
        utf8Bytes = new TextEncoder().encode(s);
    }
    const byteLen = utf8Bytes.length;
    let headerSize;
    if (byteLen < 24) {
        headerSize = 1;
    }
    else if (byteLen < 256) {
        headerSize = 2;
    }
    else {
        headerSize = 3;
    }
    const result = new Uint8Array(headerSize + byteLen);
    if (headerSize === 1) {
        result[0] = (majorUtf8String << 5) | byteLen;
    }
    else if (headerSize === 2) {
        result[0] = (majorUtf8String << 5) | 24;
        result[1] = byteLen;
    }
    else {
        result[0] = (majorUtf8String << 5) | extendedFloat16;
        result[1] = byteLen >> 8;
        result[2] = byteLen & 0xff;
    }
    result.set(utf8Bytes, headerSize);
    return result;
}
const USE_BUFFER$1 = typeof Buffer !== "undefined";
const textEncoder = new TextEncoder();
const INITIAL_BUFFER_SIZE = 2048;
let buf = USE_BUFFER$1 ? Buffer.allocUnsafe(INITIAL_BUFFER_SIZE) : new Uint8Array(INITIAL_BUFFER_SIZE);
let view = new DataView(buf.buffer, buf.byteOffset, buf.byteLength);
let cursor = 0;
const STRING_CACHE_MAX = 2048;
const stringEncodeCache = new Map();
let encodeCacheEpoch = 0;
let encodeCacheSaturated = false;
function allocUnsafe(size) {
    return USE_BUFFER$1 ? Buffer.allocUnsafe(size) : new Uint8Array(size);
}
function writeValue(ns, value, container, serdeContext) {
    if (value == null) {
        if (value === undefined && ns.isIdempotencyToken()) {
            writeString(generateIdempotencyToken());
            return;
        }
        ensure(1);
        buf[cursor++] = (majorSpecial << 5) | specialNull;
        return;
    }
    if (ns.isUnitSchema()) {
        ensure(1);
        encodeHeader(majorMap, 0);
        return;
    }
    const isObject = typeof value === "object";
    if (isObject) {
        if (ns.isBlobSchema()) {
            if (value instanceof Uint8Array) {
                writeBytes(value);
                return;
            }
        }
        if (ns.isTimestampSchema()) {
            if (value instanceof Date) {
                writeTimestamp(value);
                return;
            }
        }
        if (ns.isStructSchema()) {
            writeStruct(ns, value, serdeContext);
            return;
        }
        if (Array.isArray(value) && (ns.isListSchema() || ns.isDocumentSchema())) {
            writeList(ns, value, ns.isDocumentSchema(), serdeContext);
            return;
        }
        if (ns.isMapSchema()) {
            writeMap(ns, value, false, serdeContext);
            return;
        }
        if (value instanceof Date) {
            writeTimestamp(value);
            return;
        }
        if (value instanceof Uint8Array) {
            writeBytes(value);
            return;
        }
        if (value instanceof NumericValue) {
            writeNumericValue(value);
            return;
        }
        if (value[tagSymbol]) {
            const tagged = value;
            writeTag(tagged.tag, tagged.value);
            return;
        }
        if (ns.isDocumentSchema()) {
            if (Array.isArray(value)) {
                writeList(ns, value, true, serdeContext);
            }
            else {
                writeMap(ns, value, true, serdeContext);
            }
            return;
        }
        if (ns.isBigDecimalSchema()) {
            writeUntypedValue(value);
            return;
        }
        writeMap(ns, value, true, serdeContext);
        return;
    }
    if (typeof value === "string") {
        if (ns.isBlobSchema()) {
            const bytes = (serdeContext?.base64Decoder ?? fromBase64)(value);
            writeBytes(bytes);
            return;
        }
        writeString(value);
        return;
    }
    if (typeof value === "number") {
        ensure(9);
        if (Number.isInteger(value) && value >= -9007199254740992 && value <= 0x1fffffffffffff) {
            writeInteger(value);
        }
        else {
            writeFloat64(value);
        }
        return;
    }
    if (typeof value === "boolean") {
        ensure(1);
        buf[cursor++] = (majorSpecial << 5) | (value ? specialTrue : specialFalse);
        return;
    }
    if (typeof value === "bigint") {
        writeBigInt(value);
        return;
    }
    writeString(String(value));
}
function writeStruct(ns, value, serdeContext) {
    if (ns.isUnionSchema()) {
        let wrote = false;
        for (const [memberName, memberSchema] of ns.structIterator()) {
            const item = value[memberName];
            if (item != null) {
                ensure(9);
                encodeHeader(majorMap, 1);
                writeString(memberName);
                writeValue(memberSchema, item, ns, serdeContext);
                wrote = true;
                break;
            }
        }
        if (!wrote) {
            const { $unknown } = value;
            if (Array.isArray($unknown)) {
                ensure(9);
                encodeHeader(majorMap, 1);
                writeString($unknown[0]);
                writeUntypedValue($unknown[1]);
            }
            else {
                ensure(9);
                encodeHeader(majorMap, 0);
            }
        }
        return;
    }
    const cache = loadCborStructIterator(ns);
    const { memberNames, memberSchemas, encodedKeys } = cache;
    const z = memberNames.length;
    let headerSize;
    if (z < 24) {
        headerSize = 1;
    }
    else if (z < 256) {
        headerSize = 2;
    }
    else {
        headerSize = 3;
    }
    ensure(headerSize);
    const headerPos = cursor;
    cursor += headerSize;
    let count = 0;
    for (let i = 0; i < z; ++i) {
        const item = value[memberNames[i]];
        if (item == null && !memberSchemas[i].isIdempotencyToken()) {
            continue;
        }
        const key = encodedKeys[i];
        ensure(key.length);
        buf.set(key, cursor);
        cursor += key.length;
        writeValue(memberSchemas[i], item, ns, serdeContext);
        ++count;
    }
    if (typeof value.__type === "string") {
        for (const k in value) {
            if (!hasOwn(value, k))
                continue;
            if (!memberNames.includes(k)) {
                writeString(k);
                writeUntypedValue(value[k]);
                ++count;
            }
        }
    }
    if (headerSize === 1) {
        buf[headerPos] = (majorMap << 5) | count;
    }
    else if (headerSize === 2) {
        buf[headerPos] = (majorMap << 5) | 24;
        buf[headerPos + 1] = count;
    }
    else {
        buf[headerPos] = (majorMap << 5) | extendedFloat16;
        buf[headerPos + 1] = count >> 8;
        buf[headerPos + 2] = count & 0xff;
    }
}
function writeList(ns, value, isDocument, serdeContext) {
    const sparse = !!ns.getMergedTraits().sparse;
    const valueSchema = ns.getValueSchema();
    if (isDocument || sparse) {
        const items = [];
        for (let i = 0; i < value.length; ++i) {
            const item = value[i];
            if (isDocument) {
                if (item !== undefined) {
                    items.push(item);
                }
            }
            else {
                if (item != null || sparse) {
                    items.push(item);
                }
            }
        }
        ensure(9);
        encodeHeader(majorList, items.length);
        for (let i = 0; i < items.length; ++i) {
            writeValue(valueSchema, items[i], undefined, serdeContext);
        }
    }
    else {
        let count = 0;
        for (let i = 0; i < value.length; ++i) {
            if (value[i] != null) {
                ++count;
            }
        }
        ensure(9);
        encodeHeader(majorList, count);
        for (let i = 0; i < value.length; ++i) {
            if (value[i] != null) {
                writeValue(valueSchema, value[i], undefined, serdeContext);
            }
        }
    }
}
function writeMap(ns, value, isDocument, serdeContext) {
    const sparse = !!ns.getMergedTraits().sparse;
    const valueSchema = ns.getValueSchema();
    const keys = [];
    for (const k in value) {
        if (!hasOwn(value, k))
            continue;
        const v = value[k];
        if (isDocument ? v !== undefined : v != null || sparse) {
            keys.push(k);
        }
    }
    ensure(9);
    encodeHeader(majorMap, keys.length);
    for (let i = 0; i < keys.length; ++i) {
        const k = keys[i];
        writeString(k);
        writeValue(valueSchema, value[k], undefined, serdeContext);
    }
}
function writeUntypedValue(value) {
    if (value == null) {
        ensure(1);
        buf[cursor++] = (majorSpecial << 5) | specialNull;
        return;
    }
    if (typeof value === "string") {
        writeString(value);
        return;
    }
    if (typeof value === "number") {
        ensure(9);
        if (Number.isInteger(value) && value >= -9007199254740992 && value <= 0x1fffffffffffff) {
            writeInteger(value);
        }
        else {
            writeFloat64(value);
        }
        return;
    }
    if (typeof value === "boolean") {
        ensure(1);
        buf[cursor++] = (majorSpecial << 5) | (value ? specialTrue : specialFalse);
        return;
    }
    if (typeof value === "bigint") {
        writeBigInt(value);
        return;
    }
    if (value instanceof Uint8Array) {
        writeBytes(value);
        return;
    }
    if (value instanceof Date) {
        writeTimestamp(value);
        return;
    }
    if (value instanceof NumericValue) {
        writeNumericValue(value);
        return;
    }
    if (value[tagSymbol]) {
        const tagged = value;
        writeTag(tagged.tag, tagged.value);
        return;
    }
    if (Array.isArray(value)) {
        ensure(9);
        encodeHeader(majorList, value.length);
        for (let i = 0; i < value.length; ++i) {
            writeUntypedValue(value[i]);
        }
        return;
    }
    if (typeof value === "object") {
        const keys = Object.keys(value);
        ensure(9);
        encodeHeader(majorMap, keys.length);
        for (let i = 0; i < keys.length; ++i) {
            writeString(keys[i]);
            writeUntypedValue(value[keys[i]]);
        }
        return;
    }
    writeString(String(value));
}
function ensure(n) {
    if (cursor + n > buf.length) {
        let newSize = buf.length * 2;
        while (newSize < cursor + n) {
            newSize *= 2;
        }
        const next = allocUnsafe(newSize);
        next.set(buf.subarray(0, cursor));
        buf = next;
        view = new DataView(next.buffer, next.byteOffset, next.byteLength);
    }
}
function encodeHeader(major, value) {
    if (value < 24) {
        buf[cursor++] = (major << 5) | value;
    }
    else if (value < 256) {
        buf[cursor++] = (major << 5) | 24;
        buf[cursor++] = value;
    }
    else if (value < 65536) {
        buf[cursor++] = (major << 5) | extendedFloat16;
        buf[cursor++] = value >> 8;
        buf[cursor++] = value & 0xff;
    }
    else if (value < 4294967296) {
        buf[cursor++] = (major << 5) | extendedFloat32;
        view.setUint32(cursor, value);
        cursor += 4;
    }
    else {
        buf[cursor++] = (major << 5) | extendedFloat64;
        const hi = (value / 4294967296) | 0;
        const lo = (value - hi * 4294967296) | 0;
        view.setUint32(cursor, hi);
        view.setUint32(cursor + 4, lo);
        cursor += 8;
    }
}
function encodeBigHeader(major, value) {
    const n = Number(value);
    if (n < 4294967296) {
        encodeHeader(major, n);
        return;
    }
    buf[cursor++] = (major << 5) | extendedFloat64;
    view.setBigUint64(cursor, value);
    cursor += 8;
}
function writeString(s) {
    const len = s.length;
    if (len <= 23) {
        const cached = stringEncodeCache.get(s);
        if (cached) {
            ensure(cached.bytes.length);
            buf.set(cached.bytes, cursor);
            cursor += cached.bytes.length;
            cached.epoch = encodeCacheEpoch;
            return;
        }
        const start = cursor;
        writeStringUncached(s, len);
        const end = cursor;
        const bytes = Uint8Array.prototype.slice.call(buf, start, end);
        if (stringEncodeCache.size >= STRING_CACHE_MAX) {
            if (encodeCacheSaturated) {
                return;
            }
            let evicted = 0;
            for (const [key, entry] of stringEncodeCache) {
                if (evicted >= 1024) {
                    break;
                }
                if (entry.epoch !== encodeCacheEpoch) {
                    stringEncodeCache.delete(key);
                    ++evicted;
                }
            }
            if (evicted === 0) {
                encodeCacheSaturated = true;
                return;
            }
        }
        if (stringEncodeCache.size < STRING_CACHE_MAX) {
            stringEncodeCache.set(s, { epoch: encodeCacheEpoch, bytes });
        }
        return;
    }
    writeStringUncached(s, len);
}
function writeStringUncached(s, len) {
    if (USE_BUFFER$1) {
        const maxBytes = len * 3;
        ensure(maxBytes + 9);
        const byteLen = Buffer.byteLength(s);
        encodeHeader(majorUtf8String, byteLen);
        cursor += buf.write(s, cursor);
    }
    else {
        const maxBytes = len * 3;
        ensure(maxBytes + 9);
        const headerPos = cursor;
        const result = textEncoder.encodeInto(s, buf.subarray(headerPos + 9));
        const byteLen = result.written;
        let headerSize;
        if (byteLen < 24) {
            headerSize = 1;
        }
        else if (byteLen < 256) {
            headerSize = 2;
        }
        else if (byteLen < 65536) {
            headerSize = 3;
        }
        else if (byteLen < 4294967296) {
            headerSize = 5;
        }
        else {
            headerSize = 9;
        }
        if (headerSize < 9) {
            buf.copyWithin(headerPos + headerSize, headerPos + 9, headerPos + 9 + byteLen);
        }
        cursor = headerPos;
        encodeHeader(majorUtf8String, byteLen);
        cursor += byteLen;
    }
}
function writeFloat64(value) {
    ensure(9);
    buf[cursor++] = (majorSpecial << 5) | extendedFloat64;
    view.setFloat64(cursor, value);
    cursor += 8;
}
function writeInteger(value) {
    ensure(9);
    const nonNegative = value >= 0;
    const major = nonNegative ? majorUint64 : majorNegativeInt64;
    const abs = nonNegative ? value : -value - 1;
    encodeHeader(major, abs);
}
function writeBigInt(value) {
    const nonNegative = value >= 0;
    const major = nonNegative ? majorUint64 : majorNegativeInt64;
    const abs = nonNegative ? value : -value - BigInt(1);
    if (abs < BigInt("18446744073709551616")) {
        ensure(9);
        encodeBigHeader(major, abs);
    }
    else {
        const binaryStr = abs.toString(2);
        const byteLen = Math.ceil(binaryStr.length / 8);
        const bigIntBytes = new Uint8Array(byteLen);
        let b = abs;
        for (let i = byteLen - 1; i >= 0; --i) {
            bigIntBytes[i] = Number(b & BigInt(255));
            b >>= BigInt(8);
        }
        ensure(byteLen + 16);
        buf[cursor++] = nonNegative ? 0b110_00010 : 0b110_00011;
        encodeHeader(majorUnstructuredByteString, byteLen);
        buf.set(bigIntBytes, cursor);
        cursor += byteLen;
    }
}
function writeBytes(data) {
    ensure(data.length + 9);
    encodeHeader(majorUnstructuredByteString, data.length);
    buf.set(data, cursor);
    cursor += data.length;
}
function writeTag(tagValue, innerValue) {
    ensure(9);
    if (typeof tagValue === "bigint") {
        encodeBigHeader(majorTag, tagValue);
    }
    else {
        encodeHeader(majorTag, tagValue);
    }
    writeUntypedValue(innerValue);
}
function writeNumericValue(nv) {
    let str = nv.string;
    let expOffset = BigInt(0);
    const eIndex = str.search(/[eE]/);
    if (eIndex !== -1) {
        expOffset = BigInt(str.slice(eIndex + 1));
        str = str.slice(0, eIndex);
    }
    const decimalIndex = str.indexOf(".");
    const fractionDigits = decimalIndex === -1 ? 0 : str.length - decimalIndex - 1;
    const exponent = expOffset - BigInt(fractionDigits);
    const mantissa = BigInt(str.replace(".", ""));
    ensure(9);
    buf[cursor++] = 0b110_00100;
    encodeHeader(majorList, 2);
    ensure(9);
    if (exponent >= -0x20000000000000n && exponent <= 0x1fffffffffffffn) {
        writeInteger(Number(exponent));
    }
    else {
        writeBigInt(exponent);
    }
    writeBigInt(mantissa);
}
function writeTimestamp(date) {
    ensure(18);
    encodeHeader(majorTag, 1);
    const epochSecs = date.getTime() / 1000;
    if (Number.isInteger(epochSecs)) {
        writeInteger(epochSecs);
    }
    else {
        writeFloat64(epochSecs);
    }
}

class CborShapeDeserializer2 extends SerdeContext {
    read(schema, bytes) {
        payload = bytes;
        isBuffer = USE_BUFFER && bytes instanceof Buffer;
        dataView = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
        pos = 0;
        end = bytes.length;
        cacheEpoch = (cacheEpoch + 1) & 0xffff;
        return readValue(NormalizedSchema.of(schema));
    }
    readValue(_schema, value) {
        return transformObject(NormalizedSchema.of(_schema), value);
    }
}
const USE_BUFFER = typeof Buffer !== "undefined";
const textDecoder = new TextDecoder();
let payload = new Uint8Array(0);
let isBuffer = false;
let dataView = new DataView(new ArrayBuffer(0));
let pos = 0;
let end = 0;
const STRING_CACHE_SIZE = 2048;
const stringCache = new Array(STRING_CACHE_SIZE);
const stringCacheEpochs = new Uint16Array(STRING_CACHE_SIZE);
let cacheEpoch = 0;
function readValue(ns) {
    if (pos >= end) {
        throw new Error("unexpected end of CBOR payload.");
    }
    const major = (payload[pos] & 0b1110_0000) >> 5;
    const minor = payload[pos] & 0b0001_1111;
    if (minor === minorIndefinite && major >= 2 && major <= 5) {
        return readIndefinite(ns, major);
    }
    switch (major) {
        case majorUint64:
            return readUnsignedInt();
        case majorNegativeInt64:
            return readNegativeInt();
        case majorUnstructuredByteString:
            return readByteString();
        case majorUtf8String:
            return readUtf8String();
        case majorList:
            return readList(ns);
        case majorMap:
            return readMap(ns);
        case majorTag:
            return readTag();
        case majorSpecial:
            return readSpecial();
        default:
            throw new Error(`unexpected CBOR major type ${major}.`);
    }
}
function readList(ns) {
    const count = decodeCount();
    const memberSchema = ns.isListSchema() ? ns.getValueSchema() : ns;
    const list = Array(count);
    for (let i = 0; i < count; ++i) {
        list[i] = readValue(memberSchema);
    }
    return list;
}
function readMap(ns) {
    const count = decodeCount();
    if (ns.isStructSchema()) {
        const startPos = pos;
        return readStruct(ns, count, startPos);
    }
    const valueSchema = ns.isMapSchema() ? ns.getValueSchema() : ns;
    const map = {};
    for (let i = 0; i < count; ++i) {
        const key = readUtf8String();
        map[key] = readValue(valueSchema);
    }
    return map;
}
function readStruct(ns, count, startPos) {
    const isUnion = ns.isUnionSchema();
    const cache = loadCborStructIterator(ns);
    const { memberSchemas, encodedKeys, memberNames } = cache;
    const z = encodedKeys.length;
    const result = {};
    let unknownKey;
    let unknownValue;
    let unknownCount = 0;
    let hasType = false;
    let hint = 0;
    for (let i = 0; i < count; ++i) {
        const matchIdx = matchStructKey(encodedKeys, z, hint);
        if (matchIdx >= 0) {
            hint = matchIdx + 1;
            if (hint >= z) {
                hint = 0;
            }
            const val = readValue(memberSchemas[matchIdx]);
            if (val != null) {
                result[memberNames[matchIdx]] = val;
            }
        }
        else {
            const key = readUtf8String();
            const val = readValue(NormalizedSchema.of(15));
            if (key === "__type" && typeof val === "string") {
                hasType = true;
            }
            else {
                unknownKey = key;
                unknownValue = val;
                ++unknownCount;
            }
        }
    }
    if (isUnion) {
        let resultEmpty = true;
        for (const _ in result) {
            if (!hasOwn(result, _))
                continue;
            resultEmpty = false;
            break;
        }
        if (resultEmpty && unknownCount === 1) {
            result.$unknown = [unknownKey, unknownValue];
        }
    }
    else if (hasType) {
        pos = startPos;
        const docSchema = NormalizedSchema.of(15);
        for (let i = 0; i < count; ++i) {
            const key = readUtf8String();
            const val = readValue(docSchema);
            if (!(key in result)) {
                result[key] = val;
            }
        }
    }
    return result;
}
function readTag(ns) {
    const tagNum = decodeArgument();
    const tagNumber = typeof tagNum === "bigint" ? Number(tagNum) : tagNum;
    if (tagNumber === 1) {
        const docSchema = NormalizedSchema.of(15);
        const epochValue = readValue(docSchema);
        return _parseEpochTimestamp(epochValue);
    }
    if (tagNumber === 2 || tagNumber === 3) {
        const byteStr = readByteString();
        let b = BigInt(0);
        for (let i = 0; i < byteStr.length; ++i) {
            b = (b << BigInt(8)) | BigInt(byteStr[i]);
        }
        return tagNumber === 3 ? -b - BigInt(1) : b;
    }
    if (tagNumber === 4) {
        const docSchema = NormalizedSchema.of(15);
        const pair = readValue(docSchema);
        const [rawExponent, mantissa] = pair;
        const normalizer = mantissa < 0 ? -1 : 1;
        const absMantissa = BigInt(normalizer) * BigInt(mantissa);
        const mantissaDigits = String(absMantissa);
        const sign = mantissa < 0 ? "-" : "";
        let numericString;
        const isSmallExponent = typeof rawExponent === "number" && Math.abs(rawExponent) <= 2 ** 28;
        if (isSmallExponent) {
            const exponent = rawExponent;
            const mantissaStr = "0".repeat(Math.abs(exponent) + 1) + mantissaDigits;
            numericString =
                exponent === 0
                    ? mantissaStr
                    : mantissaStr.slice(0, mantissaStr.length + exponent) + "." + mantissaStr.slice(exponent);
            numericString = numericString.replace(/^0+/g, "");
            if (numericString === "") {
                numericString = "0";
            }
            if (numericString[0] === ".") {
                numericString = "0" + numericString;
            }
            numericString = sign + numericString;
        }
        else {
            const bigExponent = BigInt(rawExponent);
            if (mantissaDigits.length === 1) {
                numericString = sign + mantissaDigits + st bigExpnent = BigInt(rawExponen      nUint32(cursor, hi);
        view.setUif    bsMantidjustedEx
   nent = BigIn+(mantissa);
    length === 1) -              writeStString = sign + mantissaDigits + st b "." mantissaStr.slilength xponenntissxpnent = BigIidjustedEx
en      nUint32(cursor, h   return tagNumbnvcString[0] ===}
    const decimalIa = NormalizedSchema.of(15);
        consSmallEue);
}
fuValue(docSchema);
        con{};
    ,
    castmantiss : tagN, date.geEue);
}
fuV}ction readTag(ns)ite(ns, major);
    }    vie(major) {
        case majorUint64:
ng:
            return readUtf8String();
   ite(ns, maj    case majorUnstructuredByteString:
            return readByteString();
   ite(ns, maj    case majorUnstruc           return readList(ns);
 ite(ns, major    case majorMap:
            return readMap(ns);
 ite(ns, major    case ma:
            throw new Error(`unexpected CBOR maite && majo=== 1) t i ype ${}.`);
    }
}
function readList(nsing();
   ite(ns, maj     castart+= const exponenchunk
    for (coerictotalath.ce       newSizetart<
        throw n >= epos] & 0b000     x           writeIntart+= const e case majunt = dmbv != int8Array(0);
lettotalathen      nUint32erico BigInt(        for (const [ 0; i < count; +hunk
; ++i) {
            b = (b e majumbv !=ched.bhunk
defino BigI            writeSto BigIned.bhunk
def;
            cached.       if (numericFER = type             return;
     .from(s, "utfjumbv !=c bytes.bjumbv !=c et, bytes.bjumbv !=c et,;
     ng(2);
   );
    }
    e cached.       if (numtagNumbeder();
let.0, payljumbv !=    }
        cursor =tes = Uint8AreString();
        case majhunk
;;
   
            rettotalath.+.length;
        cac   curew Error("unexpecd CBOR ma      marker  }
 ion readList(nsing();
   ite(ns, maj     castart+= const exponenchunk
    for (coerictotalath.ce       newSizetart<
        throw n >= epos] & 0b000     x           writeIntart+= const e case majunt = dmbv != int8Array(0);
lettotalathen      nUint32erico BigInt(        for (const [ 0; i < count; +hunk
; ++i) {
            b = (b e majumbv !=ched.bhunk
defino BigI            writeSto BigIned.bhunk
def;
            cached.       if (numcollectBombv !=   }
        cursor =tes = Uint8AreString();
        case majhunk
;;
   
            rettotalath.+.length;
        cac   curew Error("unexpecd CBOR ma      marker  }
 ion readList(ns);
 ite(ns, major     castart+= const exponenchema = ns.isListSchema() ? ns.getValueSchema() : ns;
    const list = Array(c for (conewSizetart<
        throw n >= epos] & 0b000     x           writeIntart+= const e case malist;
}
funct }
        cursor 
fun;;
   ue(memberSchema);
    })   cac   curew Error("unexpecd CBOR ma      marker  }
 ion readList(ns;
 ite(ns, major     castart+= const eisStructSchema()) {
        const startPo loadCborStructIterator(ns);
    const {st startPorSchemas, encodedKeys, memberNames } = cache;
    const zst startPoodedKeys.length;
    const r t isSmallEx ns.isUnionSchema();
    const c t isSmall= {};
    let unk unknownKey;
    let unk unknownValue;
    let unk unknownCount = 0;
    let has hint = 0;
    for (le (conewSizetart<
        throw now n >= epos] & 0b000     x           writeInteIntart+= const e case ma isUnion) {
        let resssssssssssssultEmpty = true;
        for (cooooooooooooonst _ in result) {
            if (!ha case ma isUnion(result, _))
                continuuuuuuuuuuuuue;
            resultEEEEEEEEEEEEEmpty = false;
            break;












                }
                    if (ent resultEmpty && unknownCount === 1) {
            result.EEEEEEEEEEEEmpty =wn = [unknownKey, unknownValue];
        }
    } }
                    if (ent           if (entresult;
    }
}
con if (ent           if atchIdx = matchStructKey(encodedKeys, z, hint);
        if (mat matchIdx >= 0) {
            hint =   = matchIdx + 1;
            if (hin hint >= z) {
                hint =   = 0;
            }
     (ent           if (ental = readValue(memberSchemas[matchIdx]);
            if (val val != null) {
                result[ lt[memberNames[matchIdx]] = val;
            }
     (ent           if (cursor, hi);
        view.setUif    bsManteadUtf8String();
            const v(ental = readValue(memberSzedSchema.of(15));
            if (key key === "__!ype" && typ             result[ lt[Key = key;
                unknown ownValue = val;
                ++unkno knownCount;
            }
     (ent           if (cursor, h(cursor, hew Error("unexpecd CBOR ma      marker  }
    const decimalhema = ns.isMapSchema() ? ns.getValueSchema() : ns;
    const map = {};
    for (lenewSizetart<
        throw n >= epos] & 0b000     x           writeIntart+= const e case malist;
}functursor, h(cursor, hey = readUtf8String();
        map[key] = readValue(valueSchema);
    }
    return ew Error("unexpecd CBOR ma      marker  }
 ion readLisructKey(encodedKeys, z, hint);
     const tagNum     KcodedKeys[i];
       if (existinpaderSi   Kco === 1) <{
   es instanMuctKnpad,Si   Kco      const start+= i   Kco === 1)   return _parseEhi }
    else {
t i = 0; i < z; ++i) {
        const inion)0         const tursor, hey         }
        const key = eekdedKeys[i];
        ensure(stinpaderSek === 1) <{
   es instanMuctKnpad,Se               writart+= ek === 1)onst e case malist;
}i   }
    }
    else iflist;
}-1
 ion readLisnstanMuctKna;
   CBOR m const len = s.lengt  CBOR m;
    if (len <= epos] & atndefin  CBOR m        return readInd           lse {
t i = 0; i < 1; ++i)len{
        const inionepos] & at + indefin  CBOR m i          const treadInd              }
    else iflist;
}      ion readLisrgument();
    cconst len = s payload[pos] & 0b0001_1111;
    if (minor === min
            heatart+= const e caslist;
}f= mi      lse {
(major) {= mi     case majorUidFloat64Ondata)       throw nry.epod - tart<
2             result[overflow(             wri}          writart+= 2onst e case malist;
}[pos] & 0b0 -      ensure(jorUidFloat64;
            throw nry.epod - tart<
3             result[overflow(2            wri}          writart+= 3onst e case malist;
}w = new ueScrray(S(0b0 - 2    case majorMadFloat32;
            throw nry.epod - tart<
5             result[overflow(4            wri}          writart+= 5onst e case malist;
}w = new ueScrray32(0b0 - 4    case majorMadFloat32;
   64         ...headry.epod - tart<
          buf.copult[overflow(8            wri}          writart+= 9           wrii = (value w = new ueScrray32(0b0 - 8            writ >= z"-" x00000000             return;
     .94967296) | 0;
 +}w = new ueScrray32(0b0 - 4    case ma wri}          wrilist;
}w = new ueSc64(cursor,0b0 - 8           }         :
            throw new Error(`unexpected CBOR ma== min BigIn${== mi   }
}
function readLisount();
    iconst len = seadValrgument();
    const tlist;
} al === "string" ? Number(tagNum)val
        ion readList(nsiInt();
     const len = seadValrgument();
    const tlist;
}castmantissval
  ion readList(nseInt();
     const len = seadValrgument();
    const teof value === igint") {
        encodeB
     .fantiss    -          lse iflist;
}-1 -      ion readList(nsing();
   ( const len = s.le 1) {Count();
    if (ns.isStpod - tart<
 {
        let newoverflow(;
    buf.setonst decimal cursor;      rettart+= 
    if (lenlist;
}[pos] &ay(headerPend);
  curso+ ;
    bufion readList(nsing();
   ( const len = s.le 1) {Count();
    if (ns.isStpod - tart<
 {
        let newoverflow(;
    buf.setonst decimal cursor;      rettart+= 
    if (len <= 23) 1) <            healist;
}wunt()ing(C, len) nd);
 ;
    buf.setonst dnion) from(s         healist;
}[pos] &ag(2);
   );
    , end);
  curso+ ;
    buf    lse iflist;
}eder();
let.0, payl[pos] &ay(headerPend);
  curso+ ;
    b)  ion readLisrgumening(C, len)a;
 ;
    blet str = nh = 
    if (lent i = 0; i < z; ++i) ++i) {
            b =cheEp    31 + epos] & at + in        vieonst decimal lotheEp  >>>    & _CACHE_SIZE);
let  -         ached = stringEncodeCC, le[ lotif (existin= strin!fined && ns.isIdepoch ==== 1) {
   {
        let newSizeructK;
        for (const _ 0; i < z; ++i) ++i) {
            b =(existin= stri.charCmentt(i)n!finepos] & at + in             return;ructK;
             break;




            }
        }
        if (!wrote)ructK         stringEncodeCochs = new [ lotie;
    c            return;
     depoch          }
    else ifsSmall= {};
   ) from(s        }?}[pos] &ag(2);
   );
    , a;
 aso+ ;
    b        }:}eder();
let.0, payl[pos] &ay(headerPa;
 aso+ ;
    bif (ns.isStncodeCochs = new [ lotie!fincch) {
               ncodeCC, le[ lotilt.writte;         ncodeCC, le= new [ lotie;
    c           eturn result;
}
function readTag(ns)();
     const len = spor;      reten = s payload[pos] & 0001_1111;
    if (min(major) {= mi     case majorUiTrue : spec       throw ntartPop           if (hinlist;
}       case majorUiTrue : 
           throw ntartPop           if (hinlist;
}            brejorUiTrue :            throw ntartPop           if (hinlist;
}n      return;jorUiTrue : Ud && ns.       throw ntartPop           if (hinlist;
}n      return;jorUidFloat64;
              ...headry.epod - tt<
3             result[overflow(2            wri}          writartPop   3onst e case malist;
}nstanTo;
      epos] & 0 coun, epos] & 0 co2     }
        return jorMadFloat32;
              ...headry.epod - tt<
5             result[overflow(4            wri}          writartPop   5onst e case malist;
}w = new ueSc;
     (0 cou    }
        return jorMadFloat32;
   64         ...headry.epod - tt<
          buf.copult[overflow(8            wri}          writartPop   9onst e case malist;
}w = new ueSc;
   or,0 cou    }
        return :
            throw new Error(`unexpected CBOR ma== min BigIn${== mi  t i ype ${7  }
}
function readLisnstanTo;
      s) { const len = smantissa    7   reten = st = rawExpo(a01_11111
   5;
    2   reten = snDigits)xpo((a01_11100;
   1)Int(8    b   reten = sscalar + manti      ?     -if (minor =t === 0
      b00000            or =nDigits)xp
                enclist;
}0   }
        return list;
}scalar * bs(exppow(2, 1 - 15Int(=nDigits)x/{
    }
    else {
     or =t === 0
      b   i1            or =nDigits)xp
                enclist;
}scalar * Inns, my   }
        return list;
}NaN      eturn result;scalar * bs(exppow(2, t === 0
 - 15Int(=1 + nDigits)x/{
    }
 ion readLiscastmantissval   if (value <value === "number") {
        ensure(result;    }
    else iformalizcodeAvalue);
    if (n < 429isIntegMIN_SAFE_INTEGER <{
zcodsIdeum <{
isIntegMAX_SAFE_INTEGER     ensure(result;n if (tageturn result;    }
 ion readLisoverflow(      letew Error(`unexpecjor :s.le 1) ${n} greater thaag(nmainign  bytess.le 1)  }
}ion readLisrmObject(Normaliue, isDoc if (value <mestampSchema()) {
            if ue <value === "number") {
        ensure(urn result;pochTimestamp(epochVa
        }
        return;eof value === "object") {
   ue <= 0x1f!) {
        ensure(urn;eof ength;ta") {
 1ue <"ength"ue) {
            if (!haurn result;pochTimestamp(epochVa
    ;
            return;   }
    }
    if (isUnionobSchema()) {
            conresult;    }
    else ifeof value === "object"ed";
const ||      convalue === "boolean") {
    ||      convalue === "boolean && Math||      convalue === "boolean) {
    ||      convalue === "boolean"? Numbe||      convalue === "boolean) {
        ensure(result;    }
    else ifeof value === "ob!ect") {
   u||=== "boolea
        ensure(result;    }
    else ifeof " et,;
    "ue) {
            if result;    }
    else ifeof nstanceof Date) {
        writeTiresult;    }
    else ifeof nstanceof Date) {Value) {
        writeNuresult;    }
    else ifeof cumentSchema()) {
            if result;    }
    else ifeof cumenema() ? ns.g     const matchIdxhema = ns.isListSeSchema();
    const kst matchIdout        for (let i =sSmallEnulle === "o         if (!haoun;;
   rmObject(Normalichema, item, ns, s)    }
        return;result;out
    else iformalizewNormal    for (leeof cumenma() ? ns.g     const matchIdtarget= ns.isListSeSchema();
    const kst mnst k in valesult){
            if (!hasOwn(value, k))
    co        if (!haurn e;
            resultEzewNormal readValrmObject(Normalitarget= ns.i[k], undeey     }
        retlse {
     or =ructSchema()) {
        const startPoEx ns.isUnionSchema();
    const c t i 0; ]);
   ensure(stin) {
        let resssssObject.or(`Set         const vnst k in value) {
            if (!ha(!hasOwn(value, k))
                continuuuuue;
            resultEEEEE === _!ype" && typ             result[ lt[ngth;add              writeUn           if (cursor, h(cursor, hnst [key, entry] chema] of ns.structIterator()) {
            const inion) {
        let resssssssssngth;key);
                          if (numeric], undeey l) {
                result[zewNormal readValrmObject(Normalichema, item, n], undeey     }
      if (cursor, h(cursor, hnion) {
   ue <ngth? STRIN{
            result.Size = Normal true;
        for (cooooonst _ in result) = Normal         if (!ha(!hasOwn(value,  = Normal               continuuuuue;
            resultEEEEE = Normal true;
             break;




            }
        }
     (!hasOwn = Normal true         b = (b e majunkeys[i];
  ;
    rse;teLe().        writeTaultEEEEE = Normalwn = [unknownk[k], undef]   }
      if (cursor, h(cursor, h     or =value.__type === "string") {
        for (co t vnst k in value) {
            if (!ha(!hasOwn(value, k))
                continuuuuue;
            resultEEEEE ===!(kult) = Normal              result[ lt[zewNormal r]e[k];
        if (isDursor, h(cursor, h if (cursor, h(cursoeturn result;zewNormal;ss CborShapeDeCmencs SerdeContext {
    read(sccreateSer2 exten(     const startPozer2 extenct.or(`peDeseriaSer2 exten2         conzer2 extenchedntext {
    (this.ntext);
            }
 result;ser2 exten
    else iforeatelizer2 exten(     const startPodezer2 extenct.or(`peDeserializer2 extend     default:
zer2 extenchedntext {
    (this.ntext);
            }
 result;:
zer2 exten
}
functioCborShaSmithyRpcV2peDePe.slcols SerdeCoRpcPe.slcolsonst lenencst.or(`peDeCmenc     defzer2 extenct.this.enenc.createSer2 exten(    defdezer2 extenct.this.enenc.createlizer2 exten(    reten = ratoor({ :
     atchIpace, enexp
   Regi) {
sor)}            nuper({ :
     atchIpace, enexp
   Regi) {
so      }
 lse ifget=eriaId(         if result;"smithyype.slcols#rpcv2peDe"   }
 lse ifgetPpos] &Cmenc          if result;this.enenc   }
 lse ifasyncfzer2 exteRequest(op)) {ma();
   Valupus.bju{
    const s  ifsSmall= questissawait nuper.zer2 exteRequest(op)) {ma();
   Valupus.bju{
           }
 Normalwasmant(= quest.os;
  och:cursor, h if "ju{
 nt-& typ:;this.getD
     Cu{
 nt
   (),cursor, h if "smithy-pe.slcol": "rpc-v2-ceDe",cursor, h if accept:;this.getD
     Cu{
 nt
   (),cursor, h     }
      ===deref(op)) {ma();
   .lupus)bject"edit      for (co t vkey);
l= quest.bod            unkkey);
l= quest.os;
  o["ju{
 nt-& typ    }
    }
    e );
        view.setUif ===!= quest.bod              result[this.nte2 extenc, curs15, {}            writeUn= quest.bod ct.this.nte2 extencfl
                         if (numeric= quest.bod ceof Uint8Array) {
        writeBy writeUn= quest.os;
  o["ju{
 nt-.le 1)"]ng(absMant= quest.bod ngth);
        pos = 0 if (cursor, h(cursor, htartPorSservice, op)) {ma(che;
get=mithy {
    (ju{
           }
 air = re1) {C`/service/${service}/op)) {ma(/${op)) {ma(}`   }
      ==== quest.re1).rdeChead("/"              res= quest.re1)t+= re1).xponennt   }
    }
    e );
        view.setUif= quest.re1)t+= re1)   }
        return;result;= quest   }
 lse ifasyncfdezer2 exteResponse(op)) {ma();
   Vaju{
   ,;
}
ponse         if result;nuper.dezer2 exteResponse(op)) {ma();
   Vaju{
   ,;
}
ponse    }
 lse ifasyncfhandleunexpeop)) {ma();
   Vaju{
   ,;
}
ponselengthNormal  meta
    ensure( }
 air = enexpIdentifienct.s] &SmithyRpcV2peDeunexpCmen(
}
ponselengthNormal) ?? "U= [unk"       }
 air = rreferredatchIpace
    "*p    }
    }tartPorS:
     atchIpaceche;
this.op{ma(
   ensure(rreferredatchIpace
.unshift(:
     atchIpace    const [rawExpontchIpace, enexp=eriaatchjorSp() =>        ...headry.epnexpIdentifien.includes("#"              res if result;pnexpIdentifien.split("#"    case ma wri}          wrilist;
}[ed, serdeCopnexpIdentifien    }
    }
)(    }
      ===ntchIpace             writreferredatchIpace
.unshift(ntchIpace    const [   const key = eenexpMeta
                 wri$meta
   : meta
   ,cursor, h if $      ;
}
ponse.statusCment<
50 : ""clieumbe: "servee",cursor, h}       }
 air = rreferredRegi) {
so = [this.enmpositeunexpRegi) {y]   }
      ===ntchIpace             writreferredRegi) {
so;;
   
   Regi) {y.f
   tchIpace     const [   const ktreferredRegi) {
so;;
   
   Regi) {y.f
  :
     atchIpace     const [rawExpoenexp=;
   VaunexpCt);
 enexpModhjorSthis.resolveunexpeenexp=eriaatch,itreferredatchIpace
,ktreferredRegi) {
so    }
      ===enexpModhoolean t();
 u||=enexpModhooleansynthetic      for (co t v ===dgthNormal.Messag          if (!ha(!hadgthNormal.messag ue w = Normal.Messag    case ma wri}          wriey = eenexpngt nexpModhooleansynthetic etVar(`unexpCoor({  tch: enexp=eriaatch)}  :ror(`unexpeenexp=eriaatch    case ma wriew ErrNormalwasmant(enexp,eenexpMeta
   lengthNormal)   const [   const key = ensalizedSchema.of(15);
  enexp=;
       const mantissaessag ue w = Normal.aessag u?? w = Normal.Messag  ?? "U= [unk"       }
 air = excepts.isUnir(`unexpCoor({}    const mantissoutpu
    let unk unknst [key, enntch,ichema,.structIterator()) {
            const ioutpu
nntchjorSthis.:
zer2 extencue(memberSchemaslengthNormalnntchj)   const [   const kew ErrNormalwasmant(excepts.i,eenexpMeta
   le{cursor, h if $      ;stSeScMergedTraitrse;enexp,cursor, h if aessag ,cursor, h},ioutpu
    }
 lse ifgetD
     Cu{
 nt
   ()        if result;"applic {ma(/ceDe"   }
 lss CborShapeDeseriaSer2 extens SerdeContext {
    read(sc        wri, cursovalue) {
        return this.== "boo.this.nte2 extesovalue) {
       }
 lse ifnte2 extesovalue) source            ey = ensalizedSchema.of(15);
  s;
       const misStnource ) {
        ensure(urn;eof ionScIdempotencyToken           const i if result;gen)) {eIdempotencyToken     case ma wri}          wrilist;
}nource   }
        return;eof obSchema()) {
            con  ifeof value =nource ) ng") {
                hasTypelist;
}(this.ntext);
    ?.base64 = new T??  "utBase64)tnource    case ma wri}          wrilist;
}nource   }
        return;eof obSchmpSchema()) {
            if   ifeof value =nource ) ng" && Math|| value =nource ) ng") {
        encodeB     wrilist;
}tTimTo {
  View(ne((exponensource  
    i              if (key}          wrilist;
}w =mTo {
 nource    case ma   return;eof value =nource ) ng"n readLith|| value =nource ) ng") {
        const k t startPozourceNormal   nource   }
       ifeof cumenema() ? ns.gue <sArray(value))zourceNormal          const i if tartPozochTi = !!stSeScMergedTraitrse;zochTi           writeUnormalizewalue)        for (leeeeeeeee 0; i < z;  for (leeeeeeeeet i =sSmallEnulle =zourceNormal             result[ lt[ecimalhema oo.this.nte2 extesstSeSchema();
    c ns, s);  for (leeeeeeeee  ifeof nstanc) {
   h|| zochTi         result.EEEEEEEEEEEEzewalue)[ialue;
    }
    eeeeeeeeeeeeeeeee           if (ent           if (entresult;zewalue)                     if (numericzourceNormal eof Date) {
        writeTi if (entresult;w =mTo {
 nourceNormal)   const [           if (numormalizewNormal    for (le if (numericcumenma() ? ns.g     const m if (numormalizochTi = !!stSeScMergedTraitrse;zochTi           writeUnnst k in valesult)zourceNormal             result[ lt[sOwn(value, zourceNormal   co        if (!haurn  if (numorm            resultEEEEEEEEEecimalhema oo.this.nte2 extesstSeSchema();
    c nzourceNormaldeey     }
      if ult[ lt[sOwnnstanc) {
   h|| zochTi         result.EEEEEEEEEEEEzewNormal readVal    }
    eeeeeeeeeeeeeeeee           if (ent           if (cursor, hi);
     or =ructSchema()) {
        const sssssssssnst [key, entry] chema] of ns.structIterator()) {
            const iEEEEEEEEecimalhema oo.this.nte2 exteschema, item, nzourceNormaldeey     }
      if ult[ lt[sOwnnstanc) {
            result.EEEEEEEEEEEEzewNormal readVal    }
    eeeeeeeeeeeeeeeee           if (ent           if EEEEecimalEx ns.isUnionSchema();
    const c t iult[ lt[sOwn) {
   ue <sArray(value))zourceNormalwn = [unk          const iEEEEEEEEecimalnk[k]]   nourceNormalwn = [unk
    eeeeeeeeeeeeeeeeezewNormal r]e[k]   if (isDursor, h(cursor, h if  , h     or =value._nourceNormalw=== "string") {
        for (co t vvvvvvvvvnst k in value) zourceNormal             result[ lt[ lt[sOwn(value, zourceNormal               continuuuuuuuuuuuuue;
            resultEEEEEEEEEEEEE ===!(kult) = Normal              result[ lt[[[[[[[[[zewNormal r]e[kthis.nte2 extes15, zourceNormalde     }
      if ult[ lt[               if (ent res           if (ent           if (cursor, hi);
     or =ructStSchema()) {
            if EEEEEEEE ===sArray(value))zourceNormal          const i if  eUnormalizewalue)        for (leeeeeeeee eee 0; i < z;  for (leeeeeeeee eeet i =sSmallEnulle =zourceNormal             result[ lt[ EEEzewalue)[ialue;
this.nte2 extesstSeSchema();
    c ns, s);  for (leeeeeeeee  if           if (ent resresult;zewalue)                if           if (entnst k in valesult)zourceNormal             result[ lt[sOwn(value, zourceNormal   co        if (!haurn  if (numorm            resultEEEEEEEEEzewNormal readValrhis.nte2 extesstSeSchema();
    c nzourceNormaldeey     }
      if ult[           if (cursor, hi);
     or =ructSBigDndex -)) {
            if EEEEEEEElist;
}nourceNormal;s         if (cursor, hi);
result;zewNormal;s     if (cursor, hlist;
}nource   }
 lse {
tl
               ey = eb false;
ceDe.nte2 extesthis.== "b        retthis.== "boo.ed, serde       }
 result;b        datass CborShapeDeserializer2 extens SerdeContext {
    read(schema, bytes) {
        payloadtartPod      ceDe.:
zer2 exte 
            retresult;this.ue(memberS bytes) 
    f (tageturn re(_schema, value) {
        return ey = ensalizedSchema.of(15);
  _s;
       const misStobSchmpSchema()) {
            if   ifeof value === "number") {
        ensure(urn  retresult;pochTimestamp(epochVa
        }
      if (cursor, hi);
eof value === "object") {
            if EEEEEEEE ===ength;ta") {
 1ue <"ength"ue) {
            if (!haurn  retresult;pochTimestamp(epochVa
    ;
            return; if (cursor, hi);
(cursor, h(cursor, hnionobSchema()) {
            con  ifeof value === "boolean) {
                hasTypelist;
}(this.ntext);
    ?.base64 = new T??  "utBase64)t
        }
      if (cursor, hi);
result;    }
    er, h(cursor, hnionvalue === "object"ed";
const ||      con convalue === "boolean") {
    ||      con convalue === "boolean && Math||      con convalue === "boolean) {
    ||      con convalue === "boolean"? Numbe||      con convalue === "boolean) {
        ensure(i);
result;    }
    er, h(cursor, h     or =value.__typebject") {
            if EEEEsOwnnstancolea
        ensure(ure(i);
result;n      return; if (cursor, hi);
eof " et,;
    "ue) {
            if ure(i);
result;    }
    er, h if (cursor, hi);
eof nstanceof Date) {
        writeTiure(i);
result;    }
    er, h if (cursor, hi);
eof ructStSchema()) {
            if EEEEEEEEresult;    }
    er, h if (cursor, hi);
eof ructSema() ? ns.g     const mmmmmmmmmormalizewalue)        for (leeeeeeeeeatchIdxhema = ns.isListSeSchema();
    const kst mmmmmmmmmt i =sSmallEnulle === "o         if (!haeeeeeeeeatchIdEnul val;
  this.ue(memberSchema, item, ns, s)       resultEEEEEEEEEzewsArray;
   Enul val;        return; if (cursor, hi);
 entresult;zewalue)                     if (numormalizewNormal    for (le if (numericcumenma() ? ns.g     const m if (numormalitarget= ns.isListSeSchema();
    const kst mmmmmmmmmt i =sSmalllesult){
            if (!ha if (numeric(value, k))
    co        if (!haurn  if (numorm            resultEEEEEEEEEecimalEnul val;
  this.ue(memberStarget= ns.i[k], undeey     }
                 zewNormal readValEnul val;   }
      if ult[           if (cursor, hi);
     or =ructSchema()) {
        const sssssssssecimalEx ns.isUnionSchema();
    const c t iult[ lt[ 0; ]);
   ensure( if (numeric) {
        let resssssssssssssObject.or(`Set         const vvvvvvvvvnst k in value) {
            if (!ha(!ha if (numeric(value, k))
                continuuuuusssssssseci            resultEEEEEEEEEEEEE === _!ype" && typ             result[ lt[ssssssssObje;add              writeUnnnnnnnnn           if (ent res           if (ent           if  sssnst [key, entry] chema] of ns.structIterator()) {
            const iEEEEEEEEeric) {
        let resssssssssssss sssngth;key);
                   nnnnnnnn           if (ent reseric], undeey l) {
                result[[[[[[[[[zewNormal readValrhis.ue(memberSchema, item, n], undeey     }
                            if (ent           if  sssnion) {
   ue <ngth? STRIN{
            result.........Size = Normal true;
        for (cooooooooooooonst _ in result) = Normal         if (!ha(!ha if  sssnion(value,  = Normal               continuuuuuuuuuuuuueci            resultEEEEEEEEEEEEE = Normal true;
             break;












                }
                    if (ent resultE = Normal true         b = (b e mauuuuuuuuecikeys[i];
  ;
    rse;teLe().        writeTaultEEEEEEEEEEEEE = Normalwn = [unknownk[k], undef]   }
      if                    if (ent(cursor, h if  , h     or =value.__type === "string") {
        for (co t vvvvvvvvvnst k in value) {
            if (!ha(!ha if (numeric(value, k))
                continuuuuusssssssseci            resultEEEEEEEEEEEEE ===!(kult) = Normal              result[ lt[[[[[[[[[zewNormal r]e[k];
        if (isDursor, hhhhhhhhh           if (ent res           if (ent           if (cursor, hi);
     or =nstanceof Date) {Value) {
        writeNuuuuuuuuuresult;    }
    er, h if (cursor, hi);
result;zewNormal;s     if (cursor, h        view.setUif= sult;    }
    er, h(cursoass Ct ==rts.peDeCmencs=`peDeCmenc;Ct ==rts.peDeserializer2 extens=apeDeserializer2 exten;Ct ==rts.peDeserializer2 exten2s=apeDeserializer2 exten2;Ct ==rts.peDeseriaSer2 extens=apeDeseriaSer2 exten;Ct ==rts.peDeseriaSer2 exten2s=apeDeseriaSer2 exten2;Ct ==rts.SmithyRpcV2peDePe.slcols=aSmithyRpcV2peDePe.slcol;Ct ==rts.buildHttpRpcR questissbuildHttpRpcR quest;Ct ==rts.ceDe   ceDe;Ct ==rts.checkpeDeResponse   checkpeDeResponse;Ct ==rts.w =mTo {
ue w =mTo {
;Ct ==rts.s] &SmithyRpcV2peDeunexpCmenct.s] &SmithyRpcV2peDeunexpCmen;Ct ==rts.ochTipeDeBod ct.ochTipeDeBod ;Ct ==rts.ochTipeDeunexpBod ct.ochTipeDeunexpBod ;Ct ==rts.ta") ,
  ;Ct ==rts.ta"S {
  ) ,
  S