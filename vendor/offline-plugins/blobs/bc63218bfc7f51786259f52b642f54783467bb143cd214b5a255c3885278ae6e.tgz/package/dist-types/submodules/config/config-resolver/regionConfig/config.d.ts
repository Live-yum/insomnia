import type { LoadedConfigSelectors, LocalConfigOptions } from "../../node-config-provider/configLoader";
/**
 * @internal
 */
export declare const REGION_ENV_NAME = "AWS_REGION";
/**
 * @internal
 */
export declare const REGION_INI_NAME = "region";
/**
 * @internal
 */
export declare const NODE_REGION_CONFIG_OPTIONS: LoadedConfigSelectors<string>;
/**
 * @internal
 */
export declare const NODE_REGION_CONFIG_FILE_OPTIONS: LocalConfigOptions;
