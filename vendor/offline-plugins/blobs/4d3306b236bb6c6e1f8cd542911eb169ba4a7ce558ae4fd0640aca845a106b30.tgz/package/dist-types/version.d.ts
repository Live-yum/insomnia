export declare const VERSION = "2.11.0";
