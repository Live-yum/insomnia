const crypto = require('crypto');
const {isBuffer} = require('util');
const moment = require('moment');
const fs = require('fs');

const replacementContent = 'Will be replaced with HMAC of request body';
const settings = {
    privateKey: null,
    clientKey: null,
    secretKey: null,
    partnerKey: null,
};

function getPath(url) {
    const pathRegex = /.+?\:\/\/.+?(\/.+?)(?:#|\?|$)/;
    const result = url.match(pathRegex);
    return result && result.length > 1 ? result[1] : '';
}

function getQueryString(url) {
    const arrSplit = url.split('?');
    return arrSplit.length > 1 ? url.substring(url.indexOf('?') + 1) : '';
}

function generateUnauthorizedSignature(params) {
    const privateKey = fs.readFileSync(settings.privateKey, 'utf8');
    const stringToSign = `${params.clientKey}|${params.timestamp}`;
    const sign = crypto.sign('sha256', Buffer.from(stringToSign), {
        key: privateKey,
    });
    return sign.toString('base64');
}

function generateAuthorizedSignature(payload) {
    const sha256Body = crypto.createHash('sha256').update(payload.reqBody).digest('hex');
    const stringToSign = `${payload.httpMethod}:${payload.requestURI}:${payload.accessToken}:${sha256Body}:${payload.timestamp}`;
    const hmac = crypto.createHmac('sha512', settings.secretKey);
    const signature = hmac.update(new Buffer(stringToSign, 'utf-8')).digest('base64');
    console.log(signature);
    return signature;
}

module.exports.templateTags = [
    {
        name: 'LINKAJACONFIG',
        displayName: 'LINKAJACONFIG',
        description: 'CONFIG',
        args: [
            {
                displayName: 'PRIVATE KEY',
                type: 'file',
                placeholder: 'PRIVATE KEY'
            },
            {
                displayName: 'CLIENT KEY',
                type: 'string',
                placeholder: 'CLIENT KEY'
            },
            {
                displayName: 'SECRET KEY',
                type: 'string',
                placeholder: 'SECRET KEY'
            },
            {
                displayName: 'PARTNER KEY',
                type: 'string',
                placeholder: 'PARTNER KEY'
            },

        ],
        async run(context, privateKey, clientKey, secretKey, partnerKey) {
            settings.privateKey = privateKey;
            settings.clientKey = clientKey;
            settings.secretKey = secretKey;
            settings.partnerKey = partnerKey;
            return null;
        }
    }
];

module.exports.requestHooks = [
    context => {
        const requestUrl = context.request.getUrl();
        const requestBody = context.request.getBody();
        const httpMethod = context.request.getMethod().toUpperCase();
        const requestURI = getPath(requestUrl);
        const authentication = context.request.getAuthentication();
        const env = context.request.getEnvironment();

        let reqBody = null;

        if (httpMethod === 'GET') {
            reqBody = '';
        } else {
            reqBody = requestBody.text;
        }

        const timestamp = moment().format("YYYY-MM-DDTHH:mm:ssZ");

        let requestPath = getPath(requestUrl);
        let queryString = getQueryString(requestUrl);

        console.log('REQ BODY', reqBody);
        console.log('TIMESTAMP', timestamp);
        console.log('METHOD', httpMethod);
        console.log('URI', requestURI);

        if (Object.values(context.request.getHeaders()).find(({name}) => name === 'LinkAja')) { //check header exist linkaja
            let signature = null;
            if (authentication && Object.keys(authentication).length === 0 && Object.getPrototypeOf(authentication) === Object.prototype) { //check auth header
                signature = generateUnauthorizedSignature({
                    clientKey: settings.clientKey,
                    timestamp: timestamp
                })
            } else {
                signature = generateAuthorizedSignature({
                    httpMethod: httpMethod,
                    requestURI: requestURI,
                    accessToken: authentication?.token,
                    reqBody: reqBody,
                    timestamp: timestamp
                });
            }
            context.request.setHeader('X-SIGNATURE', signature);
            context.request.setHeader('X-TIMESTAMP', timestamp);
        }
    }
];
