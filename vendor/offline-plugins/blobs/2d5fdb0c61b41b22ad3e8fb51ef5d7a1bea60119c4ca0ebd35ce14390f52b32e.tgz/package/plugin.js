module.exports.requestHooks = [
  context => {
    let body = context.request.getBodyText()
    if (body != null && body.length > 0) {
      let newBody = JSON.stringify(JSON.parse(body))
      context.request.setBodyText(newBody)
    }
  }
];