# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [3.3.2](https://github.com/ExodusMovement/exodus-hydra/compare/@exodus/sodium-crypto@3.3.1...@exodus/sodium-crypto@3.3.2) (2025-05-10)

### Bug Fixes

- fix: tell bundler to ignore Node.js deps for libsodium-wrappers (#12314)
