"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true,
});
exports.getPackageEntryPoint = getPackageEntryPoint;
exports.matchSubpathFromMainFields = matchSubpathFromMainFields;
exports.redirectModulePath = redirectModulePath;
var _paths = require("./utils/paths");
var _nodePath = _interopRequireDefault(require("node:path"));
function _interopRequireDefault(e) {
  return e && e.__esModule ? e : { default: e };
}
function getPackageEntryPoint(context, packageInfo, platform) {
  const { mainFields } = context;
  const pkg = packageInfo.packageJson;
  let main = "index";
  for (const name of mainFields) {
    if (typeof pkg[name] === "string" && pkg[name].length) {
      main = pkg[name];
      break;
    }
  }
  const variants = [
    main,
    main.slice(0, 2) === "./" ? main.slice(2) : "./" + main,
  ].flatMap((variant) => [
    variant,
    variant + ".js",
    variant + ".json",
    variant.replace(/(\.js|\.json)$/, ""),
  ]);
  const replacement = matchSubpathFromMainFields(variants, pkg, mainFields);
  if (typeof replacement === "string") {
    return replacement;
  }
  return main;
}
function redirectModulePath(context, modulePath) {
  const { getPackageForModule, mainFields, originModulePath } = context;
  const isModulePathAbsolute = _nodePath.default.isAbsolute(modulePath);
  const containingPackage = getPackageForModule(
    isModulePathAbsolute ? modulePath : originModulePath,
  );
  if (containingPackage == null) {
    return modulePath;
  }
  let redirectedPath;
  if (modulePath.startsWith(".") || isModulePathAbsolute) {
    const packageRelativeModulePath = isModulePathAbsolute
      ? containingPackage.packageRelativePath
      : _nodePath.default.join(
          _nodePath.default.dirname(containingPackage.packageRelativePath),
          modulePath,
        );
    redirectedPath = matchSubpathFromMainFields(
      "./" + (0, _paths.systemToPosixPath)(packageRelativeModulePath),
      containingPackage.packageJson,
      mainFields,
    );
    if (typeof redirectedPath === "string") {
      redirectedPath = _nodePath.default.isAbsolute(redirectedPath)
        ? _nodePath.default.normalize(redirectedPath)
        : _nodePath.default.join(containingPackage.rootPath, redirectedPath);
    }
  } else {
    redirectedPath = matchSubpathFromMainFields(
      modulePath,
      containingPackage.packageJson,
      mainFields,
    );
  }
  if (redirectedPath != null) {
    return redirectedPath;
  }
  return modulePath;
}
function matchSubpathFromMainFields(subpath, pkg, mainFields) {
  let replacements = null;
  for (let i = mainFields.length - 1; i >= 0; i--) {
    const value = pkg[mainFields[i]];
    if (value != null && typeof value !== "string") {
      if (replacements == null) {
        replacements = {};
      }
      replacements = {
        ...replacements,
        ...value,
      };
    }
  }
  if (replacements == null) {
    return null;
  }
  const variants = Array.isArray(subpath)
    ? subpath
    : expandSubpathVariants(subpath);
  for (const variant of variants) {
    const replacement = replacements[variant];
    if (replacement != null) {
      return replacement;
    }
  }
  return null;
}
function expandSubpathVariants(subpath) {
  return [subpath, subpath + ".js", subpath + ".json"];
}
