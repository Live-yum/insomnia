// For help writing plugins, visit the documentation to get started:
// https://docs.insomnia.rest/insomnia/introduction-to-plugins

// TODO: Add plugin code here...
const fetch = require('node-fetch');

module.exports.requestActions = [
    {
        label: 'Import OpenAPI from URL',
        action: async (context) => {
            try {
                // Ask user for URL
                const url = await context.app.prompt(
                    'Enter OpenAPI / Swagger JSON URL',
                    ''
                );

                if (!url) return;

                // Fetch Swagger JSON
                const response = await fetch(url);
                if (!response.ok) {
                    throw new Error(`Failed to fetch: ${response.statusText}`);
                }

                const openapi = await response.json();

                if (!openapi.paths) {
                    throw new Error('Invalid OpenAPI document: No paths found.');
                }

                const workspaceId = context.workspace._id;

                // Create a request group
                const group = await context.store.requestGroups.create({
                    parentId: workspaceId,
                    name: openapi.info?.title || 'Imported API'
                });

                // Loop through all paths
                for (const path in openapi.paths) {
                    const methods = openapi.paths[path];

                    for (const method in methods) {
                        await context.store.requests.create({
                            parentId: group._id,
                            name: `${method.toUpperCase()} ${path}`,
                            method: method.toUpperCase(),
                            url: path
                        });
                    }
                }

                context.app.alert('Success', 'OpenAPI imported successfully!');
            } catch (err) {
                context.app.alert('Error', err.message);
            }
        }
    }
];