# Insomnia Plugin - Random Generator

![Screenshot](/readme-preview.png?raw=true)

Generates a random value from on [Chance.JS](http://chancejs.com/)

## Generators:
-  Email
- String
- CPF
- Natural Number

