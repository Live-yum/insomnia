const Chance = require('chance');
const chance = new Chance();

module.exports.templateTags = [{
  name: 'random',
  displayName: 'Random Value Generator',
  description: 'Generates a random value',
  args: [
    {
      displayName: 'Chance Function',
      type: 'string',
      placeholder: 'natural',
    },
    {
      displayName: 'Function Options',
      type: 'string',
      placeholder: '{ "max": 10 }',
    },
  ],
  async run(context, func = 'natural', opt = '{ "min": 10 }') {
    const options = JSON.parse(opt);
    return chance[func](options);
  }
}];
