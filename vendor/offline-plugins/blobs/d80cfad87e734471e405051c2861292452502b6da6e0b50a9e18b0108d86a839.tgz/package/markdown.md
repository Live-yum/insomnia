1. npm init -y
2. npm info gulp #查看线上gulp版本   gulpjs.com #gulp官网
3. yarn add gulp --dev 
4. yarn add gulp@2.7 --dev
5. npm outdated/yarn outdated  #显示过期的包
6. yarn list 
7. yarn list | grep gulp
8. npm config set registry https://registry.npmjs.org 切换到npm源
9. npm config set registry https://registry.npm.taobao.org NPM 切换淘宝源