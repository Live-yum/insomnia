const JSON5 = require('json5')

module.exports.requestHooks = [function(context) {
  try {
    var obj = JSON5.parse(context.request.getBodyText());
    context.request.setBodyText(JSON.stringify(obj));
  } catch (e) {
  }
}];
