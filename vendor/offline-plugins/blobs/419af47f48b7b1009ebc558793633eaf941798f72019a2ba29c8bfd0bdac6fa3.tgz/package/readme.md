# Insomnia Plugin - JSON Parse

This is a simple plugin that allows you to use JSON.parse() from within the
[Insomnia REST client](https://insomnia.rest/).

It's useful if, for example, you want to chain requests together but need to
remove JSON quotes from an earlier response. This plugin is built as a custom
[template tag](https://support.insomnia.rest/article/26-plugins#template-tags).
