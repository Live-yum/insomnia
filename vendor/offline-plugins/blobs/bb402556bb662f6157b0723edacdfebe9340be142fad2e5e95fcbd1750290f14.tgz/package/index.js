const crypto = require('crypto')

const generateEncodedSignature = (secret, stringToSign) => crypto.createHmac('sha1', secret).update(stringToSign).digest('base64')

module.exports.requestHooks = [
	(context) => {

		console.log('Starting Request')
		const username = context.request.getEnvironmentVariable('username')
		const secret = context.request.getEnvironmentVariable('secret')
		const date = new Date().toUTCString()
		const stringToSign = 'date: ' + date.trim()

		console.log('Generating Encoded Signature .... ')
		if (username && secret) {
			var encodedSignature = generateEncodedSignature(secret, stringToSign)
			console.log('Encoded Signature Generated Successfully')
			const hmacAuth = 'hmac username="' + username + '",algorithm="hmac-sha1",headers="date",signature="' + encodedSignature + '"'
			console.log('Setting Headers')
			context.request.setHeader('date', date)
			context.request.setHeader('Authorization', hmacAuth)
		} else {
			console.error('PLEASE SET ENVIRONMENT VARIABLES IN INSOMNIA')
		}	
	},
]