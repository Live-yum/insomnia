# insomnia-plugin-first-data-hmac
Insomnia Plugin to generate HMAC auth for interfacing with First Data API

## Install
Navigate to Insomnia options
Search for insomnia-plugin-first-data-hmac in Plugins

## Usage
The plugin requires some environment variables to be specified.
 - username
 - secret
