# convert UUID to base64 Plugin

An Insomnia plugin to convert a UUID from string to base64 format.

Example:
from:
`4a4d87f7-02c2-42d9-8674-45e5a0a737bd`
to:
`Sk2H9wLCQtmGdEXloKc3vQ==`