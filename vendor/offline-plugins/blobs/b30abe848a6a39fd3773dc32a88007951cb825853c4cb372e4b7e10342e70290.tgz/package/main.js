function uuidToBytes(uuidString) {
  // Remove hyphens from the UUID string
  const uuidWithoutHyphens = uuidString.replace(/-/g, '');

  // Convert the hexadecimal string to bytes
  const bytes = [];
  for (let i = 0; i < 32; i += 2) {
    bytes.push(parseInt(uuidWithoutHyphens.substr(i, 2), 16));
  }

  return bytes;
}

function bytesToBase64(bytes) {
  // Create a Uint8Array from the bytes
  const uint8Array = new Uint8Array(bytes);

  // Convert the Uint8Array to a string
  let binaryString = '';
  for (const byte of uint8Array) {
    binaryString += String.fromCharCode(byte);
  }

  // Use btoa to convert the binary string to Base64
  const base64String = btoa(binaryString);

  return base64String;
}

module.exports.templateTags = [
  {
    displayName: 'convertUUIDtoBase64',
    name: 'convertUUIDtoBase64',
    description: 'convert uuid string into a base64 string',
    args: [
      {
        displayName: 'uuid',
        description: 'uuid string format',
        type: 'string'
      } 
    ],
    run(context, uuidString) {
      console.log(`received: ${uuidString}`);
      const bytes = uuidToBytes(uuidString);
      const base64String = bytesToBase64(bytes);
      console.log(`converted: ${base64String}`);
      return base64String;
    }
  }
];
