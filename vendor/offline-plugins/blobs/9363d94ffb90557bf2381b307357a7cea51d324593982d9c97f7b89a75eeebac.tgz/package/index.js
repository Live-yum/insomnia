"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.templateTags = void 0;
var getCookie = function (context, cookieDomain, authCookieName) { return __awaiter(void 0, void 0, void 0, function () {
    var workspace, cookieJar, cookie;
    return __generator(this, function (_a) {
        switch (_a.label) {
            case 0: return [4 /*yield*/, context.util.models.workspace.getById(context.meta.workspaceId)];
            case 1:
                workspace = _a.sent();
                return [4 /*yield*/, context.util.models.cookieJar.getOrCreateForWorkspace(workspace)];
            case 2:
                cookieJar = _a.sent();
                cookie = cookieJar.cookies.find(function (c) { return c.key === authCookieName && c.domain.toLowerCase() === cookieDomain; });
                return [2 /*return*/, [cookie, cookieJar]];
        }
    });
}); };
var isCookieStale = function (cookie) {
    var now = Date.now();
    var expires = Date.parse(cookie.expires);
    return now > expires;
};
var isJwtStale = function (jwt) {
    if (!jwt || !jwt.access_token) {
        return true;
    }
    var token = jwt.access_token.split('.')[1];
    var decoded = atob(token);
    var json = JSON.parse(decoded);
    var now = Date.now();
    var expires = json.exp * 1000;
    return now > expires;
};
/**
 * The plugin definition that is used by Insomnia to configure and load the plugin
 */
exports.templateTags = [
    {
        name: 'CookieAuthToken',
        displayName: 'Cookie Auth Token',
        description: "Retrieve an auth token from the cookie of another request. This doesn't handle switching environments very well so be careful with that.",
        args: [
            {
                displayName: 'Request',
                type: 'model',
                model: 'Request',
                description: 'A request that should set the authentication cookie after successfully completing'
            },
            {
                displayName: 'Cookie Domain',
                type: 'string',
                description: 'The domain the cookie was issued for',
            },
            {
                displayName: 'Authentication Cookie Name',
                type: 'string',
                description: 'The name of the authentication cookie that should be set after the request.'
            }
        ],
        run: function (context, requestId, cookieDomain, authCookieName) {
            return __awaiter(this, void 0, void 0, function () {
                var request, _a, cookie, cookieJar, jwt, response;
                var _b;
                return __generator(this, function (_c) {
                    switch (_c.label) {
                        case 0:
                            if (!requestId) {
                                throw new Error("Request is required");
                            }
                            if (!cookieDomain) {
                                throw new Error("Cookie Domain is required");
                            }
                            if (!authCookieName) {
                                throw new Error("Authentication Cookie Name is required");
                            }
                            if (!requestId) {
                                console.log("No requestId");
                                throw new Error('No request provided');
                            }
                            return [4 /*yield*/, context.util.models.request.getById(requestId)];
                        case 1:
                            request = _c.sent();
                            if (!request) {
                                throw new Error("Could not find request for requestId: ".concat(requestId));
                            }
                            return [4 /*yield*/, getCookie(context, cookieDomain, authCookieName)];
                        case 2:
                            _a = _c.sent(), cookie = _a[0], cookieJar = _a[1];
                            jwt = (cookie === null || cookie === void 0 ? void 0 : cookie.value) ? JSON.parse(cookie.value) : null;
                            if (!(isJwtStale(jwt) || isCookieStale(cookie))) return [3 /*break*/, 5];
                            return [4 /*yield*/, context.network.sendRequest(request)];
                        case 3:
                            response = _c.sent();
                            if (response.statusCode !== 200) {
                                throw new Error("Dependent request ".concat(request.name, " failed. Status: ").concat(response.statusCode));
                            }
                            return [4 /*yield*/, getCookie(context, cookieDomain, authCookieName)];
                        case 4:
                            _b = _c.sent(), cookie = _b[0], cookieJar = _b[1];
                            jwt = (cookie === null || cookie === void 0 ? void 0 : cookie.value) ? JSON.parse(cookie.value) : null;
                            if (isJwtStale(jwt) || isCookieStale(cookie)) {
                                throw new Error("Got a stale/jwt cookie after an update: ".concat(cookie.expires));
                            }
                            _c.label = 5;
                        case 5:
                            if (jwt === null || jwt === void 0 ? void 0 : jwt.access_token) {
                                return [2 /*return*/, jwt.access_token];
                            }
                            console.log("No ".concat(authCookieName, " cookie for ").concat(cookieDomain, " found in Cookie Jar"), cookieJar);
                            throw new Error("No ".concat(authCookieName, " cookie for ").concat(cookieDomain, " found in Cookie Jar"));
                    }
                });
            });
        }
    }
];
//# sourceMappingURL=index.js.map